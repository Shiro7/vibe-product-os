# Product OS v1.0 — Risk, Safety, Security, Privacy, and Domain Overrides

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-06
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
governed_scope: AI_RISK_SAFETY_SECURITY_PRIVACY_AND_HIGH_ASSURANCE_DOMAINS
~~~

---

# 1. Purpose

This specification defines the risk signals that strengthen AI controls, the minimum safety/security/privacy behavior, the prohibited routes around control, and the domain overrides required for consequential use.

---

# 2. Risk Dimensions

Assess at least:

- harm severity and scale;
- affected people, vulnerable groups, rights, and ability to appeal;
- confidentiality, privacy, security, integrity, availability, and safety;
- legal, regulatory, contractual, financial, audit, and reputational consequences;
- production/live/customer/third-party exposure;
- reversibility, detectability, recovery time, and unknown outcome;
- model uncertainty, source quality, automation frequency, speed, and batch size;
- privilege, autonomy, delegation depth, and external tool access;
- bias, fairness, accessibility, language, cultural, and localization impact;
- evidence quality, explainability, monitoring, and human intervention effectiveness.

Missing evidence cannot lower risk.

---

# 3. AI Risk Signal Record

~~~yaml
ai_risk_signal_id:
task_run_action_or_system_ref:
signal_type:
detected_at:
source_or_evidence_refs: []
affected_scope:
plausible_harm:
severity_and_scale:
uncertainty:
immediate_controls: []
domain_overrides_triggered: []
owner:
decision_authority:
required_reviewers: []
monitoring_and_reopen:
status:
~~~

AI may detect and propose risk treatment. Accountable risk authority accepts residual risk.

---

# 4. Domain Override Triggers

~~~text
AI_OR_AUTOMATED_DECISION
SAFETY_CRITICAL_OR_PHYSICAL_HARM
SECURITY_AND_ABUSE
PRIVACY_AND_PERSONAL_DATA
IDENTITY_ACCESS_AND_PRIVILEGE
REGULATED_OR_SENSITIVE_DATA
LEGAL_REGULATORY_OR_CONTRACTUAL
FINANCIAL_TRANSACTION_OR_CONTROL
EMPLOYMENT_CREDIT_INSURANCE_HOUSING_EDUCATION_OR_ELIGIBILITY
HEALTH_OR_CLINICAL
CHILDREN_OR_VULNERABLE_PEOPLE
ACCESSIBILITY_AND_INCLUSION
HIGH_AVAILABILITY_OR_CRITICAL_INFRASTRUCTURE
PUBLIC_COMMUNICATION_OR_REPUTATIONAL
THIRD_PARTY_MODEL_TOOL_OR_SUPPLY_CHAIN
AUDIT_EVIDENCE_OR_RECORD_INTEGRITY
JURISDICTION_RESIDENCY_OR_CROSS_BORDER
LARGE_SCALE_OR_HIGH_FREQUENCY_AUTOMATION
~~~

Overrides compose. The highest applicable treatment governs shared scope unless safely partitioned.

---

# 5. Domain Override Record

~~~yaml
ai_domain_override_id:
domain:
trigger:
effective_scope:
base_profile:
required_model_system_approval:
allowed_roles_and_modes: []
action_class_floor_or_ceiling:
required_control_patterns: []
human_decisions_reserved: []
added_reviewers_and_segregation: []
data_and_environment_controls: []
evaluation_and_evidence: []
monitoring_and_incident_requirements: []
communication_and_explanation: []
decision_authority:
valid_until_or_event:
exit_and_reopen_conditions: []
~~~

---

# 6. Safety-by-Design

AI systems and workflows use:

- bounded approved purposes and prohibited uses;
- conservative defaults for ambiguous high-impact action;
- action classification and step-up controls;
- safe failure and human fallback;
- rate/batch/financial/privilege limits;
- simulation, staging, canary, and gradual rollout where fit;
- pre-deployment evaluation and post-deployment monitoring;
- feedback, appeal, correction, and remedy for affected people where applicable;
- incident stop/containment/recovery;
- change impact for model/configuration/tool/data drift.

Safety claims require evidence under realistic context, not only a benchmark average.

---

# 7. Security Controls

AI operation preserves:

- authenticated actor/agent/service identity;
- least privilege and just-in-time/expiring access where possible;
- separation of projects, tenants, environments, tools, and credentials;
- prompt-injection and untrusted-tool-output defense;
- protected system/configuration prompts and policy integrity;
- secure secret storage, rotation, revocation, and leak response;
- dependency/plugin/model/tool/provider supply-chain assessment;
- command/path/query/target validation;
- sandboxing/isolation for untrusted code/content;
- audit logs, anomaly detection, rate limits, and kill controls;
- output/data exfiltration prevention;
- red-team and abuse-case evaluation proportional to risk.

An AI cannot reveal hidden instructions, credentials, private memory, restricted sources, or unrelated project data merely because a user/source asks.

---

# 8. Prompt Injection and Tool Poisoning

Controls include:

- instruction/data separation;
- allowlisted tools/actions and parameter validation;
- content sanitization/segmentation where appropriate;
- limiting secrets and authority exposed to the model;
- independent policy enforcement outside model reasoning;
- user/tenant/project context binding;
- confirmation for sensitive target changes;
- detection/logging of suspicious embedded instructions;
- output validation before tool execution;
- revocation and incident response after compromise.

The model’s statement that content is safe is not a security control by itself.

---

# 9. Privacy and Personal Data

Before using personal data, establish:

- approved purpose and lawful/authorized basis;
- necessity and minimization;
- permitted data categories and subjects;
- provider processing, training, retention, location, subprocessors, and deletion behavior;
- consent/notice/rights/objection/appeal where applicable;
- access, disclosure, redaction, de-identification, and re-identification risk;
- quality, bias, correction, retention, and deletion;
- incident/breach route;
- human-decision boundary for consequential use.

Do not use production personal data for prompting, evaluation, or synthetic generation merely because it is technically accessible.

---

# 10. Secrets and Credentials

AI should normally operate on secret references, not values.

If a value is necessary:

- retrieve through an approved secure mechanism;
- expose it only to the exact tool/action requiring it;
- prevent model output/log/history/telemetry retention where possible;
- avoid echo, screenshot, copy, or transformation;
- use scoped/short-lived credentials;
- revoke/rotate and investigate on unexpected exposure.

AI cannot ask the user to paste a secret into an unapproved conversational channel when a secure alternative exists.

---

# 11. High-Impact Decisions

For decisions affecting access to employment, credit, insurance, housing, education, health, essential services, legal status, benefits, safety, discipline, identity, or similar rights/opportunities:

- AI supports analysis only within approved use;
- accountable human/organizational or legally designated authority makes the decision where required;
- criteria, sources, features, data quality, relevance, and prohibited factors are governed;
- bias/fairness/accessibility/language effects are evaluated;
- affected people receive appropriate notice, explanation, correction, appeal, and human review;
- automation bias and rubber-stamping are monitored;
- decisions and overrides are attributable and evidence-backed;
- uncertain or missing data does not become adverse fact.

---

# 12. Legal, Regulatory, Standards, and Contractual Use

AI may retrieve, compare, summarize, and flag possible obligations. It does not:

- establish legal advice/interpretation without competent authority;
- decide applicability outside GOV-009;
- waive a contract/standard/control;
- declare compliance from document/control presence;
- fabricate counsel, auditor, regulator, customer, or certifier approval;
- rely on obsolete/unofficial editions without disclosure.

Material use preserves exact source edition, jurisdiction/parties, effective date, interpretation authority, and limitations.

---

# 13. Security, Safety, and Privacy Testing

Testing may require:

- approved threat/abuse/misuse cases;
- representative multilingual/multimodal/adversarial inputs;
- prompt injection, data extraction, privilege escalation, tool misuse, cross-tenant, harmful content/action, and unsafe refusal tests;
- privacy leakage/memorization/re-identification and retention tests;
- bias/fairness/accessibility and vulnerable-user tests;
- production-like tool/configuration/context boundaries;
- false-positive/false-negative distributions, severity, and residual gaps;
- independent review and remediation verification.

Evaluation data is governed for consent, license, representativeness, contamination, confidentiality, and retention.

---

# 14. Refusal, Narrowing, and Safe Alternative

The AI refuses or narrows when requested action:

- lacks authority;
- conflicts with higher rules;
- presents unacceptable safety/security/privacy/legal risk;
- requires unavailable critical context or evidence;
- targets an ambiguous/broad/destructive scope;
- asks for deception, impersonation, fabricated evidence, concealed harm, or unauthorized data/access;
- cannot be performed within required controls.

Where safe, provide the reason at useful resolution, preserve non-sensitive evidence, offer a lower-risk authorized alternative, and route the needed authority or specialist review.

---

# 15. Emergency and Incident Context

During active harm:

1. prioritize human safety and containment;
2. use the minimum necessary authority and data;
3. preserve volatile evidence without delaying essential response;
4. maintain exact target/environment identity;
5. avoid unreviewed broad destructive action when safer containment exists;
6. keep responsible humans informed at the required cadence;
7. record temporary deviations/conditions;
8. conduct retrospective review and change impact after stabilization.

AI can detect a possible emergency and escalate. It cannot self-authorize emergency powers.

---

# 16. Accessibility and Inclusion

AI-assisted products and outputs preserve:

- accessible interaction and content formats;
- keyboard, assistive technology, captions/transcripts, contrast, reflow, focus, error, and recovery support as applicable;
- language, reading level, directionality, cultural context, and alternate channel needs;
- non-discriminatory and understandable explanations;
- ability to reach a human where automation creates a barrier;
- evaluation with affected users/experts and assistive technology when required.

AI-generated content or UI does not inherit accessibility conformance automatically.

---

# 17. Third-Party and Supply-Chain Risk

Assess models, providers, agents, plugins, connectors, datasets, evaluators, tools, and generated dependencies for:

- ownership, source, version, integrity, support, change notice, and exit;
- security/privacy/retention/training/residency/subprocessor behavior;
- license/IP/contract/usage restrictions;
- performance, safety, bias, accessibility, availability, quotas, and fallback;
- incident notification, audit/evidence access, deletion/portability, and lock-in;
- project configuration and shared-responsibility obligations.

Provider certification does not transfer project accountability.

---

# 18. Final Risk Principle

> **The more an AI action can affect rights, people, data, money, safety, production, evidence, or recovery, the less Product OS may rely on model confidence and the more it must rely on bounded authority, independent controls, evidence, and effective human intervention.**
