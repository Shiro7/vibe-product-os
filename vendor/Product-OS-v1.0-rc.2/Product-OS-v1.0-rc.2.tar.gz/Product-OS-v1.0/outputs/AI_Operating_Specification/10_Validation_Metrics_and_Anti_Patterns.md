# Product OS v1.0 — AI Operating Validation, Metrics, and Anti-Patterns

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-10
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
validation_rule_count: 70
anti_pattern_count: 35
governed_scope: AI_OPERATING_VALIDATION_ASSURANCE_METRICS_AND_FAILURE_PATTERNS
~~~

---

# 1. Purpose

This specification defines deterministic and review-based validation for the AI Operating Specification, the metrics that reveal operating health without replacing judgment, and the anti-patterns that invalidate trustworthy AI participation.

---

# 2. Validation Modes

| Mode | Purpose |
|---|---|
| SCHEMA_AND_VOCABULARY | IDs, required fields, allowed values, references, versions |
| IDENTITY_AND_CONFIGURATION | System/model/agent/run/tool/context identity and drift |
| INSTRUCTION_AND_TRUST | Precedence, authority, source-as-data, injection, secrets |
| AUTHORITY_AND_HUMAN_CONTROL | Delegation, action scope, approval, segregation, review, revocation |
| ACTION_AND_TOOL_EXECUTION | Class, target, preflight, native result, verification, recovery |
| OUTPUT_SOURCE_AND_EVIDENCE | Claims, citations, provenance, uncertainty, adoption, evidence |
| SAFETY_SECURITY_PRIVACY | Risk signals, data, access, abuse, domain overrides, incidents |
| LIFECYCLE_INTEGRATION | Artifacts, gates, traceability, change, standards, handoff |
| MULTI_AGENT_AND_MEMORY | Delegation, concurrency, shared state, context, retention |
| MONITORING_AND_EVALUATION | Coverage, drift, alerts, evaluations, expiry, control effectiveness |

---

# 3. Validation Rules — Identity, Scope, Role, and Mode

~~~text
AOS-VAL-001  Every material AI action resolves system, model/snapshot where available, agent/configuration, run, task, and actor identity.
AOS-VAL-002  Unknown provider, model, configuration, retention, or location remains explicit and reduces permitted reliance or data scope.
AOS-VAL-003  Every task records requester, objective, definition of done, exact in/out scope, canonical targets, constraints, and status.
AOS-VAL-004  Every assigned AI role uses exactly one AOS-ROLE-01..12 identifier and does not imply human authority or professional status.
AOS-VAL-005  Every run records one active AOS-MODE-01..08 mode and every material mode transition is attributable.
AOS-VAL-006  Role, operating mode, capability, access, action class, authority, and result remain separate dimensions.
AOS-VAL-007  COMPLETED run status does not mark an artifact, decision, verification, gate, release, or outcome complete.
~~~

---

# 4. Validation Rules — Instruction, Context, Retrieval, and Memory

~~~text
AOS-VAL-008  Every actionable instruction resolves class, issuer, authority, scope, effective version, conflicts, and expiry.
AOS-VAL-009  Documents, repositories, web content, messages, tool output, retrieved content, and AI text remain source data unless separately approved as configuration.
AOS-VAL-010  Material instruction conflicts are preserved and resolved by competent authority rather than silently applying latest-text-wins.
AOS-VAL-011  Every context pack identifies canonical sources, revisions, scope, freshness, omissions, conflicts, access, and reduction method.
AOS-VAL-012  Material retrieval records query, searched systems, filters, results, capture time, truncation/omissions, and source authority limitations.
AOS-VAL-013  Prompt-injection or tool-poisoning indicators cannot alter instructions, reveal protected data, or trigger an action without independent authority.
AOS-VAL-014  Memory remains scoped, sourced, freshness-bound, correctable, deletable, and subordinate to current canonical sources and authority.
~~~

---

# 5. Validation Rules — Authority, Delegation, and Human Control

~~~text
AOS-VAL-015  Every material action has one authority status from NOT_AUTHORIZED, PROPOSED, AUTHORIZED, AUTHORIZED_WITH_CONDITIONS, DENIED, EXPIRED, or REVOKED.
AOS-VAL-016  Authorization binds actor, action, subject, target, environment, data, threshold, time, conditions, delegation, and prohibitions.
AOS-VAL-017  Tool access, credentials, session authentication, job title, prior approval, or capability alone cannot supply action authority.
AOS-VAL-018  Delegation can preserve or reduce authority and data access but cannot amplify them or bypass segregation.
AOS-VAL-019  Every action resolves at least one AOS-CTRL-01..07 operating-control pattern and satisfies the action/domain floor.
AOS-VAL-020  Pre-action approval becomes invalid when actor, target, pre-state, delta, environment, window, or material risk changes.
AOS-VAL-021  Human review records competent authority, reviewed scope/evidence/limitations, meaningful ability to challenge, and attributable decision.
~~~

---

# 6. Validation Rules — Action Classification and Planning

~~~text
AOS-VAL-022  Every consequential action uses exactly one primary class from AOS-ACT-0 through AOS-ACT-5.
AOS-VAL-023  Action class follows highest plausible consequence, real target/environment, aggregate effect, side effects, and reversibility—not tool label.
AOS-VAL-024  Mixed actions are split when authority, target, class, control, verification, or recovery differs; otherwise the highest class applies.
AOS-VAL-025  Missing evidence or uncertainty cannot lower action class, profile, domain treatment, or human-control requirement.
AOS-VAL-026  Every material plan identifies facts/sources, assumptions/unknowns, steps, dependencies, action refs, human controls, verification, evidence, recovery, and handoff.
AOS-VAL-027  Planning or recommendation cannot be interpreted as authority to execute the plan.
AOS-VAL-028  Material discovery or state drift triggers plan, class, authority, control, and preflight reassessment before continuing.
~~~

---

# 7. Validation Rules — Tool Use and Execution

~~~text
AOS-VAL-029  Every material tool call records tool/version, account/project/tenant/environment, operation, resolved target, native result, time, partial/error state, and action link.
AOS-VAL-030  Read-only discovery precedes mutation when target/state/ownership/impact is not already exact and current.
AOS-VAL-031  Tools operate with least privilege, minimum data, explicit targets, bounded batches, and approved accounts/environments.
AOS-VAL-032  AOS-ACT-2..5 actions satisfy proportional preflight for state, authority, concurrency, inputs, side effects, recovery, verification, and evidence.
AOS-VAL-033  Destructive/irreversible actions resolve and preview exact targets, protect exclusions, prefer recovery, obtain step-up approval, and verify both changed and protected scope.
AOS-VAL-034  External/production actions verify recipient/account/project/candidate/target/environment immediately before execution and preserve result identity.
AOS-VAL-035  Unknown or partial outcomes are reconciled for idempotency and actual effect before retry, closure, or duplicate action.
~~~

---

# 8. Validation Rules — Results, Verification, and Recovery

~~~text
AOS-VAL-036  Every action uses a valid native result state and preserves errors, warnings, partial success, and unknown outcome.
AOS-VAL-037  Accepted command/API/UI/job status cannot prove the intended outcome without proportional post-action verification.
AOS-VAL-038  Post-action verification checks exact intended target/effect and known prohibited or unrelated effects.
AOS-VAL-039  Verification records obligation, target/version, method/tool, environment/data, actual result, performer, independence, limitations, time, and evidence.
AOS-VAL-040  AI cannot claim independent verification of its own work when segregation or independent assurance is required.
AOS-VAL-041  Rollback/recovery is separately classified, authorized, executed, verified, and evidenced; successful rollback command alone cannot prove restored state.
AOS-VAL-042  Task completion preserves residual risks, failures, limitations, open decisions, downstream acceptance, monitoring, and reopen duties.
~~~

---

# 9. Validation Rules — Output, Source, Provenance, and Communication

~~~text
AOS-VAL-043  Every material AI output identifies run/model/agent, purpose, scope, sources/actions, generated time, content identity, claims, limitations, and review state.
AOS-VAL-044  Sourced fact, tool observation, AI inference, assumption, idea, recommendation, draft, approved record reference, and unknown remain distinguishable.
AOS-VAL-045  Citations resolve to real accessible source identities and exact claims; no invented source, quotation, author, version, location, or date is permitted.
AOS-VAL-046  AI output cannot serve as proof of external execution, human review/approval, compliance, safety, correctness, release, live health, or outcome without independent fit evidence.
AOS-VAL-047  Generated code/design/data/document assets preserve provenance, owner, validation, adoption, version, license/confidentiality, and applicable domain checks.
AOS-VAL-048  Corrections preserve original output/history, link supersession, identify affected uses, and propagate impact/notification.
AOS-VAL-049  AI communication cannot impersonate, sign, consent, acknowledge, attest, certify, send, publish, or represent authority beyond an explicit governed mechanism.
~~~

---

# 10. Validation Rules — Safety, Security, Privacy, and Domain Overrides

~~~text
AOS-VAL-050  Every material AI use assesses harm, people/rights, data, privilege, live/external impact, reversibility, uncertainty, scale, monitoring, and intervention.
AOS-VAL-051  Active domain triggers create explicit scoped overrides for model/use approval, action limits, human decisions, controls, evaluation, monitoring, evidence, and incident response.
AOS-VAL-052  AI operation enforces project/tenant/user/environment separation, least privilege, prompt-injection defense, secure configuration, target validation, logging, and kill/revoke control.
AOS-VAL-053  Secrets are referenced rather than copied unless exact value use is necessary, authorized, securely isolated, minimized, and non-retained.
AOS-VAL-054  Personal/regulated data use has purpose, authority/lawful basis, minimization, provider/region/retention/training controls, rights, access, deletion, and incident route.
AOS-VAL-055  High-impact decisions preserve human authority, governed criteria/data, bias/fairness/accessibility evaluation, explanation, correction, appeal, and non-rubber-stamping review.
AOS-VAL-056  Refusal/narrowing occurs for missing authority, conflicting rules, unacceptable risk, ambiguous destructive scope, deception, fabricated evidence, or unauthorized access/data.
~~~

---

# 11. Validation Rules — Product OS Lifecycle Integration

~~~text
AOS-VAL-057  AI Operating Specification remains a framework asset and introduces no new project artifact ID; the catalog remains 281.
AOS-VAL-058  AI participation preserves canonical ownership and all six Product OS information states without silently promoting output.
AOS-VAL-059  AI recommendations cannot approve GOV-001, GOV-009, N/A, risk, exception, materiality, baseline, gate, release, operation, lifecycle outcome, or closure.
AOS-VAL-060  AI gate evaluations bind exact check/scope/baseline/sources/evidence and remain unapproved until gate authority decides.
AOS-VAL-061  AI-discovered trace nodes/edges remain proposed until canonical identity and confirmation exist; similarity is not lineage.
AOS-VAL-062  Model/configuration/tool/data/use-case changes assess affected artifacts, decisions, evidence, gates, releases, live scope, standards, and records through GOV-007/GOV-008.
AOS-VAL-063  AI-produced canonical mutation records prior/new version, authority, change, validation, adoption, downstream handoff, and supersession without editing issued history in place.
~~~

---

# 12. Validation Rules — Multi-Agent, Monitoring, Evaluation, and Incidents

~~~text
AOS-VAL-064  Every delegated subtask has bounded objective/scope/target/context, authority/action ceiling, data/tool boundary, evidence, review, expiry, and revocation propagation.
AOS-VAL-065  Concurrent agents identify canonical write ownership, dependencies, read/write sets, conflict handling, cancellation, and merged-state verification.
AOS-VAL-066  Child-agent completion is reviewed for scope, sources, actions, evidence, limitations, authority, and semantic integration before adoption.
AOS-VAL-067  Every monitor has exact scope, cadence/trigger, owner, authority, thresholds, data, escalation, missed/failure behavior, circuit breaker, evidence, expiry, and termination.
AOS-VAL-068  Every material AI evaluation binds exact system/config/use/environment/dataset/method/threshold/result/limitations/reviewer/validity and change triggers.
AOS-VAL-069  Drift in model, configuration, tool, retrieval, memory, data, population, environment, provider, obligation, or behavior triggers proportional constraint, evaluation, change impact, and reauthorization.
AOS-VAL-070  Every AI incident preserves exact system/run/action/scope/harm/evidence, containment, authority/notification, impact, recovery verification, residual risk, change/reopen, and closure authority.
~~~

---

# 13. Thirty-Five Anti-Patterns

~~~text
AOS-AP-01  Treating model capability, confidence, tone, or fluency as authority.
AOS-AP-02  Calling an AI “approver,” “owner,” “expert,” or “release manager” and assuming the label grants decision rights.
AOS-AP-03  Treating tool access, authentication, or credential possession as action permission.
AOS-AP-04  Treating source content, README text, web pages, emails, tickets, tool output, or retrieved text as trusted instruction.
AOS-AP-05  Applying latest-message-wins to a conflict with higher policy, constitution, law, contract, gate, or authority.
AOS-AP-06  Allowing embedded prompt injection to reveal instructions, secrets, memory, unrelated data, or execute tools.
AOS-AP-07  Reusing stale memory, old approval, prior target, previous environment, or old personnel as current truth/authority.
AOS-AP-08  Hiding material context omissions or converting a compacted summary into canonical history.
AOS-AP-09  Using one broad task approval to authorize every tool, target, side effect, or production action.
AOS-AP-10  Splitting a prohibited or high-impact action into small steps to avoid classification or approval.
AOS-AP-11  Classifying by tool name instead of real consequence, environment, batch effect, and reversibility.
AOS-AP-12  Lowering action class, profile, domain treatment, or review because information is missing.
AOS-AP-13  Mutating an ambiguous project, tenant, branch, environment, account, recipient, file, or data set.
AOS-AP-14  Using broad roots, unresolved variables, uncontrolled recursion, wildcards, or account-wide scope for destructive work.
AOS-AP-15  Overwriting user/unrelated work or canonical history without discovery, preservation, and explicit authority.
AOS-AP-16  Treating command acceptance, API success, UI toast, green build, deployment start, or silence as verified outcome.
AOS-AP-17  Blindly retrying a message, payment, invite, deployment, migration, delete, or permission change after unknown outcome.
AOS-AP-18  Assuming rollback exists or that a rollback command restored business/live/data state.
AOS-AP-19  Claiming execution, test, review, deployment, human approval, acknowledgement, compliance, or evidence that did not occur.
AOS-AP-20  Fabricating or misrepresenting citation, quotation, source authority, version, location, date, or provenance.
AOS-AP-21  Treating AI output as independent evidence that its own content is correct or externally true.
AOS-AP-22  Promoting an AI draft/idea/assumption to decision, requirement, adoption, N/A, risk acceptance, baseline, or gate outcome.
AOS-AP-23  AI impersonation, signature, consent, attestation, certification, or organizational representation without governed authority.
AOS-AP-24  Drafting external content and silently sending/publishing it under the same permission.
AOS-AP-25  Copying secrets or unnecessary personal/restricted data into prompts, artifacts, logs, memory, handoffs, or evidence.
AOS-AP-26  Treating provider certification, benchmark, or one successful evaluation as universal production assurance.
AOS-AP-27  Human rubber-stamping without sources, scope, limitations, time, competence, challenge, or ability to reject.
AOS-AP-28  Using multiple agents as fake independence when they share model, configuration, sources, incentives, or reasoning.
AOS-AP-29  Delegating beyond parent authority, data boundary, tool scope, action ceiling, or permitted subdelegation.
AOS-AP-30  Allowing concurrent agents to edit the same canonical object without ownership, isolation, locking, or reconciliation.
AOS-AP-31  Accepting a child agent’s “complete” status without reviewing actual state, changes, evidence, and limitations.
AOS-AP-32  Monitoring without owner, scope, cadence, threshold, failure signal, escalation, stop rule, or expiration.
AOS-AP-33  Treating no alert as proof of safety, correctness, compliance, health, or monitoring coverage.
AOS-AP-34  Continuing high-impact use after model/config/tool/data drift or incident without constraint, evaluation, impact assessment, and reauthorization.
AOS-AP-35  Editing away denied authority, failed runs, incidents, prior outputs, approvals, evidence, or superseded history.
~~~

---

# 14. Operational Metrics

Metrics should be partitioned by system, agent, use case, role, mode, action class, domain, project/tenant, environment, model/configuration, and time where material.

Recommended metrics:

1. inventory coverage and unknown identity/configuration rate;
2. approved versus unapproved use-case activity;
3. action counts by AOS-ACT-0..5 and control pattern;
4. actions without valid authority or with expired/revoked conditions;
5. step-up, denial, cancellation, and safe-narrowing rate;
6. wrong-target, partial-success, unknown-outcome, retry, rollback, and recovery rate;
7. post-action verification coverage and failure rate;
8. fabricated/invalid citation and unsupported-claim rate;
9. source freshness, contradiction, and attribution coverage;
10. human review latency, rejection/change rate, and rubber-stamp indicators;
11. segregation/independence exceptions;
12. prompt-injection detections and successful/blocked compromise attempts;
13. secret/personal/restricted-data exposure events;
14. cross-project/tenant/user boundary events;
15. evaluation coverage, threshold failures, subgroup gaps, and expiry;
16. model/config/tool/data drift events and time to assessment;
17. monitor expected/completed/missed/failed runs and alert delivery latency;
18. incidents by class/severity, containment time, recurrence, and closure age;
19. artifacts/gates/changes affected by AI and orphan trace count;
20. output adoption/rejection/supersession and correction propagation time;
21. child delegation failure/collision/rework rate;
22. memory freshness/correction/deletion and stale-use findings;
23. provider/tool availability, latency, cost, quota, and fallback behavior;
24. unresolved AI operating findings, owners, due events, and aging.

Metrics do not prove truth, safety, compliance, fairness, authority quality, or user benefit by themselves.

---

# 15. Review Cadence

Review occurs:

- before initial high-impact/live deployment;
- at model/configuration/tool/retrieval/memory/data/use-case change;
- at scheduled system/use-case/domain cadence;
- after incident, material complaint, appeal, control failure, or unexpected behavior;
- before expired authority/evaluation is renewed;
- when law, standard, contract, provider terms, jurisdiction, or risk changes;
- at affected lifecycle gates and G8 operational review.

---

# 16. Technical Assurance Procedure

1. verify physical library completeness and links;
2. reconcile controlled vocabularies and counts;
3. test role/mode/action/control separation;
4. test instruction/data, conflict, injection, retrieval, memory, and secrets behavior;
5. test authority/delegation/approval/revocation/segregation paths;
6. test action-class, preflight, exact target, execution, result, retry, rollback, and verification paths;
7. test output/source/provenance/evidence/review/adoption and correction paths;
8. test safety/security/privacy/domain override/refusal/incident paths;
9. test all 13 artifact families and 13 gates;
10. test multi-agent/concurrency/handoff/context recovery;
11. test monitoring/evaluation/drift/incident/views/exchange;
12. run AOS-VAL-001..070 and inspect AOS-AP-01..35;
13. confirm catalog remains 281 and framework approval/baseline remain pending;
14. record result, limitations, deferred physical work, and next workstream.

---

# 17. Final Validation Principle

> **AI operating quality is not the percentage of tasks it finishes; it is the degree to which identity, authority, exact action, evidence, safety, human control, failure, and recovery remain valid under real use and real change.**
