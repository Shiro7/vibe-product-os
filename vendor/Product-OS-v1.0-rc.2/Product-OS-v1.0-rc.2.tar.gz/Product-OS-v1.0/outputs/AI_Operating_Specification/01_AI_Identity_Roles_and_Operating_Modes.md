# Product OS v1.0 — AI Identity, Roles, and Operating Modes

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-01
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
role_count: 12
operating_mode_count: 8
governed_scope: AI_IDENTITY_ROLE_MODE_AND_RUN_STATE
~~~

---

# 1. Purpose

This specification defines which AI actor is operating, what responsibility it performs, how it is configured, which mode it currently uses, and how role and mode changes remain visible.

Identity, role, mode, capability, access, and authority are independent. Naming an agent “approver,” “security expert,” or “release manager” does not create the corresponding human or organizational authority.

---

# 2. AI Identity Layers

Every material AI run resolves the applicable layers:

| Layer | Required identity |
|---|---|
| Provider | Legal/service provider, service boundary, applicable terms and region where known |
| AI system | Product/service deployment, owner, approved purpose, data boundary, status |
| Model | Name, family, exact version/snapshot when available, capabilities, limitations |
| Runtime | Hosted/local execution environment, region, isolation, retention/training behavior |
| Agent | Stable agent/configuration ID, version, role capability, base instructions, tool policy |
| Session/run | Unique run identity, times, user/project/tenant boundary, context revision |
| Task | Objective, requester, canonical scope, authority, constraints, definition of done |
| Action | Exact target/effect, class, authority, control pattern, native result, verification |

If a provider hides model snapshot, parameters, or retention detail, record `UNKNOWN` and apply the approved reliance/data-access limitation.

---

# 3. Agent Configuration Record

~~~yaml
ai_agent_id:
agent_name:
agent_version:
ai_system_id:
owner:
purpose:
supported_roles: []
supported_modes: []
default_mode:
model_policy:
instruction_set_ref:
tool_policy_ref:
retrieval_policy_ref:
memory_policy_ref:
data_classes_allowed: []
project_tenant_boundary:
action_class_ceiling:
required_control_patterns: []
approved_use_cases: []
prohibited_use_cases: []
evaluation_refs: []
known_limitations: []
effective_at:
expires_or_reviews_at:
status:
change_ref:
~~~

Configuration identity includes system instructions, policy, tools, retrieval, memory, filters, routing, fallbacks, and output controls—not only the model name.

---

# 4. Canonical AI Roles

| ID | Role | Primary responsibility | Prohibited authority substitution |
|---|---|---|---|
| AOS-ROLE-01 | INTAKE_AND_CLASSIFICATION_ASSISTANT | Parse natural input, register sources, extract atomic items, identify state/profile/risk/applicability candidates, and prepare routing | Cannot approve intake state, profile, scope, risk, standards applicability, or G0 |
| AOS-ROLE-02 | RESEARCH_AND_SOURCE_ASSISTANT | Discover, retrieve, compare, register, cite, and qualify sources and contradictions | Cannot invent authority, treat popularity as reliability, or issue legal/standards interpretation |
| AOS-ROLE-03 | ANALYSIS_AND_MODELING_ASSISTANT | Analyze problems, domains, journeys, data, architecture, controls, relationships, and scenarios | Cannot silently resolve material ambiguity or approve business/product/technical meaning |
| AOS-ROLE-04 | SPECIFICATION_AND_DRAFTING_ASSISTANT | Draft artifacts, requirements, contracts, decisions, acceptance criteria, communications, and handoffs | Drafts remain proposals; cannot promote them to approved state or impersonate an owner |
| AOS-ROLE-05 | PLANNING_AND_DECOMPOSITION_ASSISTANT | Break outcomes into actions, dependencies, owners, checks, evidence, sequencing, rollback, and handoff | Cannot grant execution authority, commit owners, budgets, dates, or acceptance |
| AOS-ROLE-06 | DESIGN_AND_EXPERIENCE_ASSISTANT | Produce or inspect journeys, interaction logic, content, components, visual artifacts, accessibility and design-system mappings | Cannot approve user risk, brand, accessibility conformance, or canonical adoption by creation alone |
| AOS-ROLE-07 | IMPLEMENTATION_ASSISTANT | Modify authorized code, configuration, infrastructure, content, data definitions, tests, and technical artifacts | Cannot exceed action ceiling, authorize deployment, conceal deviations, or self-accept material risk |
| AOS-ROLE-08 | REVIEW_AND_CHALLENGE_ASSISTANT | Detect conflicts, defects, omissions, risks, stale links, policy failures, and evidence gaps | Cannot substitute for required independent human/specialist approval or close its own findings silently |
| AOS-ROLE-09 | VERIFICATION_ASSISTANT | Execute authorized checks, collect native results, compare expected/actual behavior, and assemble evidence | Cannot fabricate runs, overstate coverage, or claim independent verification where separation is required |
| AOS-ROLE-10 | RELEASE_AND_OPERATIONS_ASSISTANT | Prepare release/operation records, inspect health, perform authorized operational actions, assist incident/recovery work | Cannot authorize production exposure, G7/G8 outcome, risk acceptance, or unsafe continuation |
| AOS-ROLE-11 | MONITORING_AND_EVALUATION_ASSISTANT | Run bounded recurring checks, evaluate AI/product behavior, detect drift, and escalate signals | Cannot treat silence as health, expand monitored scope, or close alerts without required evidence/authority |
| AOS-ROLE-12 | ORCHESTRATION_AND_GOVERNANCE_ASSISTANT | Coordinate bounded agents/tasks, reconcile outputs, maintain records, traceability, coverage, and status | Cannot amplify authority, delegate outside scope, self-approve governance, or hide child-agent failure |

Roles describe responsibility, not professional licensure, employment, accountability, decision rights, or segregation satisfaction.

---

# 5. Role Assignment

A role assignment records:

~~~yaml
role_assignment_id:
ai_run_id:
role_id:
purpose:
scope:
canonical_objects: []
permitted_actions: []
prohibited_actions: []
action_class_ceiling:
required_reviewers: []
authority_refs: []
starts_at:
ends_at_or_event:
status:
~~~

The same run may hold multiple roles if:

- each role is explicit;
- the combination does not bypass required segregation;
- action classification and authority are resolved per action;
- outputs show which role produced which contribution;
- review of implementation by the same AI is labeled self-review when independence matters.

---

# 6. Canonical Operating Modes

| ID | Mode | Meaning | Typical outputs/actions |
|---|---|---|---|
| AOS-MODE-01 | ADVISORY | Answer, explain, recommend, or compare without changing governed state | Advice, options, tradeoffs, questions, suggested next step |
| AOS-MODE-02 | ANALYSIS | Inspect sources/state and derive reviewable findings | Findings, classifications, models, gaps, impact candidates |
| AOS-MODE-03 | DRAFTING | Create proposed content for later canonical review/adoption | Draft artifact, requirement, plan, communication, design content |
| AOS-MODE-04 | PLANNING | Decompose work and define sequence, controls, evidence, and handoffs | Action plan, dependencies, authority checkpoints, verification plan |
| AOS-MODE-05 | EXECUTION | Perform explicitly authorized actions that may change local/project/external state | Tool calls, edits, configuration, test runs, deployments under authority |
| AOS-MODE-06 | REVIEW | Challenge an existing proposal, artifact, action, result, or evidence set | Findings, validation results, contradictions, acceptance recommendation |
| AOS-MODE-07 | MONITORING | Observe recurring/event-driven scope and route signals | Monitoring result, alert, drift finding, escalation, health evidence |
| AOS-MODE-08 | ORCHESTRATION | Coordinate multiple tasks/agents/tools and reconcile state | Delegations, dependency routing, merged handoff, conflict resolution package |

Mode is not action class. `EXECUTION` may contain a read-only AOS-ACT-1 check or a critical AOS-ACT-5 action. `ADVISORY` may still create harm in a regulated/high-impact domain and require human-decision-only control.

---

# 7. Mode Transition Contract

~~~yaml
mode_transition_id:
ai_run_id:
from_mode:
to_mode:
reason:
trigger:
scope_change:
authority_rechecked:
new_action_classes: []
new_control_patterns: []
context_revision:
approved_by_or_policy_ref:
transitioned_at:
~~~

Mandatory step-up points include:

- advice/analysis becoming execution;
- drafting becoming canonical adoption;
- read-only inspection becoming mutation;
- local mutation becoming external/production action;
- routine work entering a security, privacy, safety, legal, financial, accessibility, regulated, or critical-operations domain;
- a single-agent run becoming orchestration;
- an interactive task becoming recurring monitoring;
- discovered emergency conditions changing normal sequence.

---

# 8. Role and Mode Compatibility

| Role family | Normal modes | Restricted transitions |
|---|---|---|
| Intake/research/analysis | ADVISORY, ANALYSIS, DRAFTING, REVIEW | EXECUTION limited to authorized source retrieval/record updates; no approval promotion |
| Planning/specification/design | ANALYSIS, DRAFTING, PLANNING, REVIEW | Adoption or canonical mutation requires owning-artifact authority and action classification |
| Implementation/verification | PLANNING, EXECUTION, REVIEW | Production, destructive, independent verification, and release decisions require stronger control |
| Release/operations/monitoring | ANALYSIS, EXECUTION, REVIEW, MONITORING | External/live action, incident response, and sustained automation require exact operational authority |
| Orchestration/governance | PLANNING, REVIEW, ORCHESTRATION, MONITORING | Cannot create authority, approve child output, or obscure ownership/segregation |

Compatibility is a default, not authority. Project rules may narrow it.

---

# 9. Human and AI Actor Separation

Every record uses an actor identity that distinguishes:

~~~text
HUMAN
ORGANIZATIONAL_AUTHORITY
AI_AGENT
DETERMINISTIC_AUTOMATION
EXTERNAL_SYSTEM
SERVICE_ACCOUNT
~~~

An AI acting through a human-owned account is still an `AI_AGENT`. The account owner is not automatically the performer or reviewer. A service account is not a decision authority.

---

# 10. Capability and Limitation Record

For each approved role/use case, record:

- supported input/output modalities;
- context, retrieval, and tool limits;
- language, locale, domain, and temporal limitations;
- probabilistic behavior and known failure modes;
- model knowledge/cutoff or freshness mechanism where relevant;
- safety/security/privacy controls;
- action class ceiling;
- required evaluation and monitoring;
- fallback or human route;
- invalidating model/configuration/tool change.

Do not infer capability from marketing name or one successful task.

---

# 11. Run Status

Use the following run lifecycle:

~~~text
RECEIVED
TRIAGED
PLANNED
AUTHORITY_CHECKED
READY
IN_PROGRESS
WAITING_FOR_INPUT
WAITING_FOR_APPROVAL
BLOCKED
VERIFYING
COMPLETED
FAILED
RECOVERING
CANCELLED
SUPERSEDED
~~~

`COMPLETED` means the run finished its authorized responsibility. It does not mean the artifact, change, gate, release, verification, or business outcome is approved or complete.

---

# 12. Identity Change and Drift

Create or link a change assessment when any material element changes:

- provider/model/snapshot or routing/fallback;
- agent/system instruction or policy;
- tools, permissions, connectors, accounts, or action ceiling;
- retrieval sources, memory behavior, data retention/training, residency, or filters;
- prompt templates, structured-output contract, evaluation thresholds, or monitoring;
- owner, approved use case, role, operating mode, audience, or domain scope.

Silent provider-side change is treated as unknown configuration drift until assessed.

---

# 13. P1/P2/P3 Treatment

- **P1:** compact system/agent/run record is acceptable when one bounded assistant and low-risk scope remain reconstructable.
- **P2:** separate inventory, assignments, runs, transitions, evaluations, and change events with automatic version checks.
- **P3:** approved model/configuration registry, environment isolation, independent evaluation, formal role/segregation mapping, immutable run/action audit, and drift monitoring where applicable.

No profile permits an ambiguous AI actor for a material action or decision-support output.

---

# 14. Final Identity Principle

> **Product OS must always be able to answer which AI acted, under which configuration, in which role and mode, on whose task, with what limits—before it asks whether the output was useful.**
