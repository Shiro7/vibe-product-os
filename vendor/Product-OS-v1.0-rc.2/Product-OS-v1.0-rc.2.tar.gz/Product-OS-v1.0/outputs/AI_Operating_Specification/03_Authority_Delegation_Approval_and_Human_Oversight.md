# Product OS v1.0 — Authority, Delegation, Approval, and Human Oversight

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-03
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
operating_control_pattern_count: 7
governed_scope: AI_AUTHORITY_DELEGATION_APPROVAL_SEGREGATION_AND_HUMAN_CONTROL
~~~

---

# 1. Purpose

This specification defines how AI action authority is established, bounded, delegated, checked, stepped up, supervised, reviewed, revoked, and evidenced.

Human control is not a decorative approval field. It must provide competent, informed, timely, and effective ability to permit, constrain, stop, challenge, reverse, or reject AI work.

---

# 2. Authority Dimensions

Authority binds all material dimensions:

| Dimension | Example |
|---|---|
| Actor | Exact AI system/agent/service account allowed to act |
| Action type | Read, edit, merge, deploy, send, delete, approve, monitor |
| Subject | Artifact, repository, project, record, user cohort, service |
| Target | File, branch, environment, tenant, account, domain, recipient |
| Domain | Product, technical, security, privacy, legal, financial, operations |
| Threshold | Monetary, risk, data volume, severity, downtime, materiality |
| Time | Session, window, due event, expiry, emergency period |
| Condition | Required checks, reviewer, rollback, evidence, notification |
| Delegation | Whether and how subdelegation is permitted |
| Prohibition | Explicit exclusions that remain forbidden |

Authority for one dimension never implies another.

---

# 3. Authority Status

Use:

~~~text
NOT_AUTHORIZED
PROPOSED
AUTHORIZED
AUTHORIZED_WITH_CONDITIONS
DENIED
EXPIRED
REVOKED
~~~

`PROPOSED` permits preparation of an approval request, not the proposed action. `AUTHORIZED_WITH_CONDITIONS` is valid only while every precondition and live condition remains satisfied.

---

# 4. Authority Record

~~~yaml
ai_authority_id:
authority_source:
issued_by:
issuer_authority_ref:
recipient_ai_system_or_agent:
permitted_roles: []
permitted_action_classes: []
permitted_actions: []
subjects_and_targets: []
projects_tenants_environments: []
data_classes: []
thresholds: []
conditions: []
prohibited_actions: []
required_control_patterns: []
required_reviewers: []
segregation_requirements: []
subdelegation:
effective_at:
expires_at_or_event:
revocation_route:
escalation_route:
evidence_and_logging:
status:
~~~

---

# 5. Authority Resolution Procedure

Before a material action:

1. identify the exact action and AOS-ACT class;
2. identify the actual actor, credentials, target, environment, data, audience, and plausible effect;
3. resolve GOV-001, GOV-009, gate/baseline, domain, provider/runtime, and tool restrictions;
4. locate an authority record covering every material dimension;
5. verify issuer authority, effective period, conditions, thresholds, and revocation status;
6. verify that delegation/subdelegation is permitted;
7. select the required operating-control pattern and segregation;
8. narrow action to the authorized intersection;
9. stop or request step-up authority for uncovered scope;
10. record the decision and evidence.

---

# 6. Delegation Contract

~~~yaml
ai_delegation_id:
parent_task_and_run:
delegator:
delegator_authority_ref:
recipient:
subtask_objective:
in_scope: []
out_of_scope: []
canonical_targets: []
inherited_constraints: []
permitted_action_classes: []
action_class_ceiling:
data_access_boundary:
tool_boundary:
required_control_patterns: []
subdelegation_allowed:
deliverable_and_evidence:
reviewer:
effective_at:
expires_or_stops_at:
revocation_propagation:
status:
~~~

Delegation can only preserve or reduce the delegator’s authority. It cannot create missing authority, widen data access, bypass segregation, or turn a proposal into approval.

---

# 7. Seven Operating-Control Patterns

| ID | Pattern | When used | Minimum behavior |
|---|---|---|---|
| AOS-CTRL-01 | POLICY_BOUND_AUTONOMY | Pre-approved, bounded, low/controlled consequence actions | Enforced policy, exact scope, logging, limits, verification, stop/revoke, exception escalation |
| AOS-CTRL-02 | HUMAN_DECISION_ONLY | Decision must remain human/organizational or professional authority | AI may prepare analysis; authorized human issues the decision and rationale |
| AOS-CTRL-03 | PRE_ACTION_APPROVAL | Exact proposed action must be approved before execution | Approval binds target, delta, version, environment, conditions, window, and actor |
| AOS-CTRL-04 | STEP_UP_CONFIRMATION | A previously authorized workflow reaches a materially stronger/ambiguous step | Pause, show exact step/effect/risk, obtain fresh confirmation, then revalidate state |
| AOS-CTRL-05 | SUPERVISED_EXECUTION | Human must observe or control a sensitive sequence | Checkpoints, visibility, pause/abort, limited batch, immediate discrepancy escalation |
| AOS-CTRL-06 | POST_ACTION_REVIEW | Timely retrospective review is acceptable for bounded actions | Complete attributable record, deadline, reviewer, discrepancy response, rollback/reopen |
| AOS-CTRL-07 | CONTINUOUS_MONITORING_AND_ESCALATION | Recurring/background/high-volume action under policy | Live limits, health/failure monitoring, alerts, circuit breaker, owner, termination and review |

Multiple patterns may apply. For example, a production rollout may require pre-action approval, supervised execution, continuous monitoring, and post-action review.

---

# 8. Default Control Floors by Action Class

| Action class | Default minimum | Typical escalation |
|---|---|---|
| AOS-ACT-0 OBSERVE_AND_REASON | AOS-CTRL-01 | AOS-CTRL-02 for regulated/high-impact human decisions |
| AOS-ACT-1 READ_ONLY_RETRIEVAL | AOS-CTRL-01 | AOS-CTRL-03 for restricted/sensitive access or cross-boundary disclosure |
| AOS-ACT-2 LOCAL_REVERSIBLE_CHANGE | AOS-CTRL-01 or AOS-CTRL-06 | AOS-CTRL-03/04 when overwriting user work or unclear target |
| AOS-ACT-3 GOVERNED_PROJECT_MUTATION | AOS-CTRL-03 or explicit policy-bound authority plus AOS-CTRL-06 | AOS-CTRL-05 where migration, shared state, security, or evidence integrity is material |
| AOS-ACT-4 EXTERNAL_OR_PRODUCTION_ACTION | AOS-CTRL-03 + AOS-CTRL-04/05/07 as applicable | Human decision/release/operational authority and independent checks |
| AOS-ACT-5 CRITICAL_IRREVERSIBLE_OR_REGULATED_ACTION | AOS-CTRL-02 plus AOS-CTRL-03/04/05/07 as applicable | Competent specialist/organizational authority, strong segregation, recovery and evidence |

Project rules, domain overrides, law, contract, standard, or incident state may raise these floors. They may not be lowered by convenience.

---

# 9. Pre-Action Approval Record

~~~yaml
ai_action_approval_id:
action_ref:
approver:
approver_authority_ref:
reviewed_action_class:
reviewed_target_and_pre_state:
reviewed_delta:
reviewed_environment_and_audience:
reviewed_risks_and_failure_modes: []
reviewed_data_and_people_impact: []
required_preflight_and_verification: []
conditions: []
prohibited_effects: []
execution_window:
approved_actor_and_tool:
rollback_or_recovery_ref:
decision:
decided_at:
expires_at_or_event:
~~~

An approval is invalid if the target, pre-state, delta, actor, environment, window, or material risk changed before execution.

---

# 10. Step-Up Confirmation

Step-up confirmation is required when:

- the target is more sensitive or broader than expected;
- a read becomes a write, a local write becomes shared/external, or a draft becomes a sent/published/adopted item;
- a destructive or irreversible operation becomes necessary;
- production/live users/data/services may be affected;
- authentication, permission, project, tenant, environment, or recipient identity is ambiguous;
- the action uses a secret, privileged credential, regulated data, or high-impact decision process;
- actual state materially differs from the approved pre-state;
- tool behavior or side effects exceed the plan;
- recovery/rollback is unavailable or unverified.

The confirmation states exact effect and meaningful risk. Generic “continue?” is insufficient for critical scope.

---

# 11. Meaningful Human Review

Human review is meaningful only when the reviewer:

- has valid authority and competence for the exact decision;
- knows content was AI-assisted and which parts were executed or inferred;
- receives the exact scope, target, sources, material changes, limitations, failures, and evidence;
- has time and access to challenge the work;
- is not manipulated by hidden defaults or misleading confidence;
- can reject, request correction, narrow, stop, or reverse;
- records an attributable decision and rationale where required.

Silence, inactivity, attendance, a reaction emoji, a default checkbox, unattended notification, automatic timeout, or blind approval does not satisfy human authority.

---

# 12. Segregation and Independence

Separate requester, planner, implementer, reviewer, verifier, releaser, risk accepter, and closer where required by P3, domain risk, GOV-001, standard, law, contract, or gate.

AI self-review can detect issues but does not satisfy independent verification. Multiple agents using the same model/configuration/source chain may not provide meaningful independence.

Where small-team constraints require combined human roles, document authority, conflict, compensating challenge, evidence, and why the combination is permitted.

---

# 13. Conflict of Interest and Incentive Risk

Reviewers and decision authorities disclose delivery, commercial, metric, personal, organizational, or model-vendor incentives that could distort judgment.

AI outputs designed to maximize engagement, completion rate, approval rate, or tool usage cannot optimize those metrics at the expense of truth, safety, user intent, or governance.

---

# 14. Revocation, Expiry, and Kill Control

Revocation or expiry:

- immediately blocks new covered actions;
- propagates to delegated agents, monitors, schedules, credentials, and sessions;
- does not erase completed action history;
- identifies in-flight actions and safe stop/rollback behavior;
- invalidates queued approvals where target/state/window changed;
- triggers access review and evidence preservation;
- records who revoked, why, when, and reactivation conditions.

Critical/recurring AI systems require a tested stop or constrain mechanism proportionate to consequence.

---

# 15. Emergency Authority

Emergency authority is:

- activated by a defined trigger;
- limited to containment, safety, service restoration, or evidence preservation necessary for the event;
- constrained by actor, target, environment, time, data, and action ceiling;
- monitored and recorded;
- revoked when the emergency window ends;
- followed by retrospective authority, privacy/security, impact, evidence, and gate review.

AI cannot declare its own emergency or broaden emergency scope.

---

# 16. Denied or Missing Authority

When authority is denied, missing, expired, revoked, or conflicted, the AI may:

- explain the blocked action and exact missing authority;
- continue safe read-only or drafting work that remains independently authorized;
- prepare an approval or escalation package;
- propose lower-impact alternatives;
- preserve state and evidence;
- monitor for the required decision if explicitly authorized.

It must not route around the control through another tool, agent, account, environment, or smaller hidden actions.

---

# 17. Final Authority Principle

> **Human control is real only when authority is exact, review is informed, intervention is effective, and the AI cannot bypass the boundary by changing tools, agents, accounts, or the size of the action.**
