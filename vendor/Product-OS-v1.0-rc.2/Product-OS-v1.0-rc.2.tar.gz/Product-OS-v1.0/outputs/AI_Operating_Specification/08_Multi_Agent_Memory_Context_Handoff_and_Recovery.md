# Product OS v1.0 — Multi-Agent, Memory, Context, Handoff, and Recovery

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-08
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
governed_scope: MULTI_AGENT_DELEGATION_SHARED_STATE_MEMORY_CONTEXT_CONTINUITY_HANDOFF_AND_RECOVERY
~~~

---

# 1. Purpose

This specification governs how AI work is decomposed across agents, how authority and data boundaries propagate, how concurrent work avoids collision, how memory supports continuity without becoming truth, and how context loss, agent failure, or interrupted execution is recovered.

---

# 2. When Multi-Agent Work Is Appropriate

Use multiple agents only when there are concrete, bounded subtasks that can proceed independently or require intentionally distinct roles.

Suitable patterns:

- independent source/domain reviews;
- parallel inspection of separate repositories/artifact families;
- implementation and separate challenge/verification with meaningful independence controls;
- decomposed content/design/code work with non-overlapping canonical targets;
- monitoring/evaluation partitions;
- orchestration of specialized tools or jurisdictions.

Avoid delegation when coordination cost, shared-state collision, authority ambiguity, sensitive-data spread, or review burden exceeds the benefit.

---

# 3. Multi-Agent Topology

~~~yaml
ai_orchestration_id:
parent_task_and_run:
orchestrator_agent:
objective:
decomposition_rationale:
subtasks: []
dependency_graph: []
canonical_write_owners: []
shared_read_sources: []
data_partitions: []
authority_and_action_class_limits: []
review_and_merge_strategy:
conflict_resolution:
stop_revocation_propagation:
status:
~~~

The orchestrator is a coordinator, not an approval authority.

---

# 4. Delegation Packet

Every agent receives:

- concrete objective and finished deliverable;
- exact in/out scope and canonical targets;
- current source/baseline/context revision;
- role, mode, action class ceiling, tools, data, and environment boundary;
- governing rules, prohibitions, required approvals, and stop conditions;
- dependencies and concurrent work;
- verification/evidence expectations;
- handoff format and receiving reviewer;
- expiry/cancel/revocation behavior.

Do not pass the entire conversation, repository, credential set, or sensitive data when a smaller context pack is sufficient.

---

# 5. No Authority Amplification

A child agent may operate only within the intersection of:

~~~text
parent authority
∩ explicit delegation
∩ child agent/tool policy
∩ project and domain controls
∩ current action approval
~~~

The child cannot:

- inherit a broader human account permission as action authority;
- subdelegate unless explicitly permitted;
- elevate action class or environment;
- access unrelated projects/tenants/data;
- approve the parent or sibling output;
- interpret silence as permission;
- route denied work through a different tool or agent.

---

# 6. Shared Filesystem and Canonical-State Ownership

When agents share files/repositories/systems:

- assign one canonical write owner per file/object/branch/record scope;
- make other agents read-only or use isolated branches/worktrees/copies where fit;
- inspect current state before mutation;
- preserve user and sibling changes;
- avoid simultaneous formatting/generated-file rewrites across shared targets;
- communicate material interface/schema changes promptly;
- rebase/reconcile through governed change review;
- verify the merged state, not only each isolated output.

A technically clean merge can still contain semantic contradiction.

---

# 7. Concurrency and Dependency Control

Parallel actions require:

- independent targets or explicit locking/transaction strategy;
- known read/write sets;
- dependency order and barrier conditions;
- shared version/baseline identity;
- duplicate action prevention;
- conflict detection and ownership;
- cancellation propagation;
- aggregate risk, rate, cost, data, and external-effect limits.

Do not parallelize actions whose order affects migration safety, release identity, evidence custody, approval validity, or recovery.

---

# 8. Child-Agent Output Review

The delegating/orchestrating agent reviews:

- subtask scope compliance;
- source and context validity;
- changes and action evidence;
- assumptions, uncertainties, failures, and prohibited-effect checks;
- interface/semantic consistency with siblings;
- validation and definition of done;
- authority boundaries and human decisions still required;
- canonical adoption/merge readiness.

A child’s “complete” status is a reported task state, not proof of correctness or adoption.

---

# 9. Independence Boundary

Separate agents improve coverage but do not automatically create independent assurance.

Independence assessment considers:

- different human/organizational authority;
- model/provider/configuration/tool separation;
- independent source/evidence chain;
- separate prompts and evaluation criteria;
- lack of shared incentive or copied reasoning;
- ability to challenge and reject;
- domain competence.

Two agents repeating one source or one model’s output provide corroboration only if relevant independence exists.

---

# 10. Memory Classes

| Memory class | Purpose | Authority |
|---|---|---|
| SESSION_CONTEXT | Current interaction/task continuity | Temporary context; not canonical |
| TASK_WORKING_MEMORY | Plans, findings, intermediate state, open actions | Task-scoped derived control |
| PROJECT_CONTINUITY_MEMORY | Stable project conventions, paths, decisions, prior evidence pointers | Reference aid; verify against canonical current sources |
| USER_PREFERENCE_MEMORY | User-approved communication/work preferences | Preference only; never action/approval authority |
| EVALUATION_MEMORY | Known model/tool failures, mitigations, test cases | Controlled evaluation/operations source |
| INCIDENT_MEMORY | Prior incidents, indicators, containment, recurrence controls | Restricted governed source |
| CANONICAL_PROJECT_RECORD | Artifact/decision/evidence in authoritative system | Not “memory”; canonical source referenced by memory |

---

# 11. Memory Record

~~~yaml
ai_memory_id:
memory_class:
owner:
subject_and_scope:
content_or_locator:
source_refs: []
created_at:
last_verified_at:
freshness_or_expiry:
authority_and_reliability:
confidentiality_and_data_subjects:
permitted_projects_users_agents_uses: []
prohibited_uses: []
correction_and_deletion_route:
supersedes_or_is_superseded_by: []
retention_and_disposal:
status:
~~~

---

# 12. Memory Use Rules

Before using memory:

- confirm project/user/tenant scope;
- check freshness and current canonical source where drift is plausible;
- preserve that the fact is memory-derived when not currently verified;
- do not treat a previous approval, credential, environment, owner, plan, or action as current authority;
- do not store secrets or unnecessary sensitive data;
- honor correction, deletion, consent, retention, and access restrictions;
- avoid reinforcing previous AI errors through repeated summaries.

Memory may propose where to look. It does not prove current state.

---

# 13. Context Handoff

When a run/agent continues another’s work, the handoff includes:

- current objective, scope, and user intent;
- authoritative instructions and active constraints;
- current plan and completed/pending/blocked actions;
- canonical source/artifact/baseline versions;
- exact changed state and verification;
- authority approvals consumed and still needed;
- unresolved assumptions/questions/conflicts/risks;
- tool sessions/background processes/monitors;
- next safe action and stop conditions;
- context omissions or uncertainty.

The receiver validates critical state before mutation.

---

# 14. Context Compaction Recovery

If detailed history is compacted or unavailable:

1. use the preserved task objective and latest state summary;
2. inspect current canonical files/systems rather than replaying completed work;
3. validate approvals, target identity, versions, and pending actions;
4. compare claimed changes with current state/evidence;
5. preserve uncertainty about missing rationale/history;
6. continue from the next uncompleted action;
7. avoid duplicate execution, duplicate messages, or repeated destructive work;
8. reconstruct only what is necessary and label backfilled lineage.

---

# 15. Agent Failure and Timeout

When an agent fails, stalls, disconnects, or returns incomplete work:

- capture last known status, tool/action state, partial outputs, and errors;
- determine whether any mutation/external effect may have occurred;
- stop/revoke descendants or credentials where needed;
- inspect shared/canonical state;
- classify outcome as failed, partial, blocked, or unknown;
- reconcile before retry or reassignment;
- preserve the failed attempt and evidence;
- assign recovery owner and communicate impact.

The orchestrator does not fill missing results with an invented success summary.

---

# 16. Human Handoff and Escalation

Escalate with a decision-ready package:

- exact question/action blocked;
- current state and urgency;
- authoritative sources and conflicts;
- options with consequences and recommendation;
- required authority/competence;
- safe interim restriction;
- decision deadline/event;
- actions that can continue independently.

Human escalation should reduce cognitive load without hiding material uncertainty.

---

# 17. Cancellation and Revocation Propagation

When task/authority is cancelled, revoked, expired, or superseded:

- signal every active agent/monitor/tool workflow;
- stop new actions immediately;
- safely finish/abort in-flight atomic actions according to risk;
- revoke temporary access and scheduled work;
- preserve outputs/history;
- identify external or shared effects already created;
- verify stop state;
- route rollback/correction/notification if required.

---

# 18. Final Multi-Agent and Memory Principle

> **More agents and more memory increase capacity, not authority or truth: every delegation must shrink to a bounded responsibility, every shared change must have one owner, and every remembered fact must yield to the current canonical source.**
