# Product OS v1.0 — Task Planning, Tool Use, and Action Execution

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-04
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
action_class_count: 6
governed_scope: AI_TASKS_PLANS_TOOLS_MUTATIONS_EXTERNAL_ACTIONS_AND_RECOVERY
~~~

---

# 1. Purpose

This specification governs how AI turns an authorized objective into bounded actions, selects and invokes tools, changes state, verifies effects, and recovers from failure.

It separates “the task is wanted” from “every means of achieving it is authorized.”

---

# 2. Task Intake

Before planning, resolve:

- requester identity and relationship to scope;
- desired outcome and user-visible definition of done;
- exact in-scope and out-of-scope objects;
- canonical project/repository/file/system/account/tenant/environment;
- current baseline, version, state, and concurrent work;
- constraints, prohibited outcomes, deadlines/due events, and dependencies;
- authority available and authority that may be needed;
- data classes, people, external recipients, and live systems affected;
- required evidence, review, handoff, and recovery.

Ambiguity is handled proportionately: investigate safe facts, make labeled low-impact assumptions, or ask/escalate before material divergence.

---

# 3. Definition of Done

~~~yaml
definition_of_done:
  output_produced: []
  state_changes_completed: []
  verification_passed: []
  prohibited_effects_absent: []
  evidence_recorded: []
  human_decisions_obtained: []
  downstream_acceptance: []
  residual_items_dispositioned: []
~~~

“Created,” “sent,” “ran,” “deployed,” “tested,” “reviewed,” and “closed” each require their own exact result and evidence.

---

# 4. Planning Record

~~~yaml
ai_plan_id:
task_ref:
plan_version:
current_state_summary:
facts_and_sources: []
assumptions_and_unknowns: []
canonical_targets: []
steps:
  - step_id:
    objective:
    dependencies: []
    action_refs: []
    owner_or_agent:
    authority_checkpoint:
    verification:
    evidence:
    status:
parallel_groups: []
critical_sequence: []
human_control_points: []
rollback_and_recovery: []
handoff:
updated_at:
change_reason:
~~~

Plans are living control views. They do not replace action authority, canonical changes, or evidence.

---

# 5. Action Decomposition

Split actions when they differ by:

- target or environment;
- action class;
- authority or operating control;
- tool/account/credential;
- reversibility or failure mode;
- people/data affected;
- verification method;
- owner/agent;
- external recipient or live exposure.

Do not hide a critical action inside a broad benign step such as “finish setup,” “clean up,” “publish changes,” or “fix production.”

---

# 6. Six Action Classes

## 6.1 AOS-ACT-0 — OBSERVE_AND_REASON

No tool-based access beyond already supplied context and no governed state change.

Examples:

- explain, summarize, translate, compare, or reason;
- draft a recommendation from provided material;
- classify a hypothetical scenario;
- plan without executing tools.

Risks may still be high when advice affects regulated, safety, legal, financial, health, employment, access, or other consequential decisions. Those decisions remain human-only where required.

## 6.2 AOS-ACT-1 — READ_ONLY_RETRIEVAL

Reads local or external state without intended mutation.

Examples:

- inspect files, code, designs, logs, deployments, tickets, documentation, dashboards, or metadata;
- search approved sources;
- run non-mutating status, query, diff, or preview operations.

Read-only does not mean harmless: restricted-data access, production queries, large exports, sensitive screenshots, and cross-tenant retrieval may require approval and evidence.

## 6.3 AOS-ACT-2 — LOCAL_REVERSIBLE_CHANGE

Changes a bounded local/private working state with straightforward recovery and no intended shared/external/live effect.

Examples:

- edit an authorized workspace draft;
- create local analysis files;
- format code or documents;
- run tests/builds that write disposable local artifacts;
- change a user-approved local preview.

It escalates if it overwrites user work, touches secrets, shared state, protected branches, signed assets, large data, or difficult-to-recreate content.

## 6.4 AOS-ACT-3 — GOVERNED_PROJECT_MUTATION

Changes shared or canonical project state but does not by itself expose a live production effect or external communication.

Examples:

- modify canonical specifications, source code, configuration, migrations, tests, design-library objects, project tickets, branches, commits, or pull requests;
- update shared development/staging data or infrastructure;
- change governed permissions/configuration below production.

Requires exact change scope, preservation of unrelated work, change/trace impact, review, evidence, and recovery.

## 6.5 AOS-ACT-4 — EXTERNAL_OR_PRODUCTION_ACTION

Creates an external communication, financial/contractual interaction, public/shared publication, production exposure, live-system effect, or action affecting users/customers/partners.

Examples:

- send email/message/invitation or publish content;
- open/update/merge an externally visible PR or issue where that action carries workflow authority;
- push, deploy, release, migrate, change production configuration/flags/permissions, or operate live services;
- purchase, subscribe, schedule, cancel, transfer, or invoke a third-party workflow.

Requires fresh target/recipient/environment verification, explicit authority, appropriate human control, monitoring, evidence, and rollback/recovery.

## 6.6 AOS-ACT-5 — CRITICAL_IRREVERSIBLE_OR_REGULATED_ACTION

Could create severe harm, permanent loss, legal/regulatory consequence, high-impact decision, large-scale external effect, privileged control change, or recovery uncertainty.

Examples:

- destroy or irreversibly overwrite material data/assets/history;
- rotate/revoke critical credentials or privileged access at high blast radius;
- make safety, legal, clinical, employment, credit, insurance, housing, education, eligibility, or similar consequential determinations;
- execute high-value financial transfer or binding legal action;
- perform critical incident containment with substantial outage/data effect;
- release an unrollbackable migration or broad irreversible production change.

AI may prepare and assist, but competent human/organizational authority owns the decision. Strong preflight, segregation, supervision, monitoring, evidence, and recovery are required.

---

# 7. Action Classification Decision

Class by the highest plausible consequence across:

- confidentiality, integrity, availability, safety, privacy, accessibility, legal/contract, finance, reputation, user rights, operations, evidence, and reversibility;
- real target and environment, not the tool’s label;
- aggregate/batch effect, not only one item;
- side effects and downstream automation;
- worst credible ambiguity until resolved.

If one operation mixes classes, split it. If splitting cannot isolate risk, use the highest class.

---

# 8. Tool Selection

Select tools using:

1. purpose fit;
2. exact scope and project identity;
3. minimum necessary privileges;
4. read/write/external/production behavior;
5. authentication, tenant, region, and data handling;
6. dry-run/preview/transaction/rollback support;
7. output completeness and error visibility;
8. logging, evidence, rate, cost, and auditability;
9. provider/tool injection and supply-chain risk;
10. approved tool policy and current version.

Prefer a purpose-built governed connector/API over fragile UI automation when both are authorized and equivalent. UI access does not broaden authority.

---

# 9. Tool Invocation Record

~~~yaml
tool_call_id:
ai_action_id:
tool_name_and_version:
connector_or_account:
project_tenant_environment:
operation:
input_scope_and_digest:
resolved_targets: []
credential_or_role_ref:
started_at:
ended_at:
native_status:
native_result_ref:
partial_or_paginated:
errors_and_warnings: []
side_effects_observed: []
data_disclosed_or_received: []
cost_or_quota_effect:
output_digest_or_locator:
verification_refs: []
~~~

Do not copy credentials or unnecessary sensitive payloads into the record.

---

# 10. Preflight Contract

Before AOS-ACT-2 through AOS-ACT-5 as applicable, confirm:

- canonical target exists and is not ambiguous;
- current pre-state/version/branch/environment matches the plan and approval;
- user/unrelated changes are identified and preserved;
- active locks, concurrent changes, freezes, incidents, conditions, or restricted windows are known;
- authority, control pattern, credentials, and data access remain valid;
- exact inputs/parameters/recipients are resolved without unsafe globs, roots, or hidden substitutions;
- side effects, dependencies, downstream automation, costs, and notifications are known;
- backup/snapshot/rollback/repair is available and proportionate;
- verification can distinguish success, partial success, failure, and unknown outcome;
- evidence capture will not leak sensitive data;
- abort and escalation paths are available.

Preflight failure blocks or narrows the action.

---

# 11. Least Privilege and Exact Targeting

Use:

- the smallest project/repository/folder/file/record/cohort/environment scope;
- scoped service accounts/roles/tokens;
- explicit identifiers and validated resolved paths;
- bounded batch sizes and rate limits;
- branch/protected-environment controls;
- minimum data fields and retention;
- temporary access with expiry where possible.

Avoid broad filesystem roots, unresolved variables, uncontrolled recursion, account-wide permissions, whole-database exports, default production context, or wildcard targets when exact scope is available.

---

# 12. Filesystem and Repository Mutations

Before editing:

- read applicable local/project instructions;
- inspect current file/repository state and ownership;
- preserve unrelated/uncommitted user work;
- use the canonical file and naming conventions;
- make the minimum coherent change;
- maintain schema, references, formatting, and generated-source boundaries;
- run proportionate validation;
- report actual files changed and residual limitations.

Do not overwrite generated/manual source boundaries, secrets, signing material, lockfiles, migrations, or user assets without explicit task fit.

---

# 13. Destructive and Irreversible Work

Before deletion, overwrite, reset, purge, revoke, rotate, migration, irreversible conversion, or large cleanup:

1. confirm explicit user/project authorization and action class;
2. resolve exact material targets through read-only checks;
3. measure/preview the affected set;
4. protect excluded and canonical source items;
5. prefer recoverable quarantine/trash/versioning over permanent deletion;
6. verify backup/restore or explain irreversibility;
7. obtain step-up approval on the exact target set;
8. execute in bounded groups when practical;
9. verify removed/changed items and protected items afterward;
10. record recoverability, retention/disposal evidence, and residual items.

Never use a broad root, home, workspace root, unresolved variable, or unvalidated wildcard as a destructive target.

---

# 14. External Communication and Publication

Before sending, posting, publishing, inviting, commenting, filing, or notifying:

- verify recipient/channel/audience/account/organization;
- confirm exact content, attachments, links, confidentiality, language, and accessibility;
- distinguish draft from send/publish;
- confirm authority to represent the person or organization;
- preserve approvals, source attribution, legal/brand requirements, and retention;
- prevent secret/personal/restricted-data disclosure;
- confirm whether the action is reversible/editable and how correction occurs;
- record sent identity/time/result.

AI may draft a message under drafting authority. Sending requires separate action authority.

---

# 15. Production and Live Actions

Before production/live action:

- verify canonical project, source revision, artifact/candidate digest, target environment, domain/alias, region, tenant, configuration, secrets identity, migration state, flags, traffic/cohort, and release window;
- confirm G7 or applicable operational authority and conditions;
- verify builds/tests/scans/evidence and known limitations;
- define health checks, telemetry, rollout stages, stop/rollback/repair thresholds, communications, and on-call ownership;
- preserve exact actor/tool/action identity;
- monitor during and after action;
- reconcile approved candidate → executed deployment → live state.

A successful build, accepted deployment request, or “ready” log does not prove live health.

---

# 16. Data and Schema Actions

For query, import, export, backfill, migration, deletion, retention, repair, or reconciliation:

- classify data and tenant/user scope;
- verify source/target schema and version;
- define selection predicate, affected count, invariants, constraints, and compatibility;
- use dry run/sample/staging where fit;
- address concurrency, idempotency, retry, partial failure, ordering, and unknown outcomes;
- define backup/restore or compensating repair;
- validate pre/post counts, integrity, isolation, rights, retention, and downstream effects;
- preserve migration/query/code identity and evidence without copying unnecessary data.

---

# 17. Dependency, Download, and Installation Actions

Before installing/downloading/enabling code, plugin, model, package, browser extension, action, container, or agent:

- verify source, publisher, version, checksum/signature where available, license, vulnerability/supply-chain status, maintenance, and necessity;
- inspect install scripts/hooks and permission/network/data behavior where material;
- use approved registries and lock versions;
- isolate evaluation when trust is uncertain;
- record added artifacts/configuration and removal/rollback path;
- validate resulting behavior and update change/evidence records.

---

# 18. Execution and Progress

During execution:

- operate only on the current approved action;
- maintain progress/state for multi-step work;
- report material discoveries or divergence without overwhelming the requester;
- reclassify and step up when scope/effect changes;
- stop at approval boundaries;
- avoid duplicate concurrent mutation;
- preserve partial results and native errors;
- cancel or revise obsolete actions rather than pretending completion.

---

# 19. Result States

Use:

~~~text
SUCCEEDED
SUCCEEDED_WITH_LIMITATIONS
PARTIALLY_SUCCEEDED
FAILED
BLOCKED
CANCELLED
UNKNOWN_OUTCOME
ROLLED_BACK
RECOVERED
~~~

Do not infer success from missing error. `UNKNOWN_OUTCOME` requires reconciliation before retry when duplication or harm is possible.

---

# 20. Post-Action Verification

Verification checks:

- intended target and version changed exactly as planned;
- desired functional/operational outcome occurred;
- prohibited or unrelated objects remain unchanged;
- data/control/security/privacy/accessibility/reliability invariants hold;
- external/live state matches canonical records;
- no unexpected notification, cost, credential, permission, migration, or retention effect occurred;
- evidence is complete and scoped;
- downstream references, tests, gates, monitors, and handoffs reflect the new state.

The verifier and independence level are explicit.

---

# 21. Retry and Unknown Outcome

Before retry:

- determine whether the first action took effect;
- assess idempotency/deduplication and duplicate side-effect risk;
- inspect tool/provider native status and target state;
- preserve the original attempt and errors;
- obtain fresh authority if target/state/window changed;
- choose retry, reconcile, compensate, rollback, or escalate.

Blind retries are prohibited for payments, messages, invites, deployments, migrations, deletes, permission changes, and other non-idempotent/high-impact actions.

---

# 22. Rollback and Recovery

Rollback is not assumed. The plan identifies whether recovery is:

~~~text
AUTOMATIC_ROLLBACK
MANUAL_ROLLBACK
FORWARD_REPAIR
DATA_RECONCILIATION
COMPENSATING_ACTION
RESTORE_FROM_BACKUP
CONTAIN_AND_REBUILD
NOT_REVERSIBLE
~~~

Recovery actions receive their own class, authority, preflight, execution, verification, and evidence. A rollback command succeeding does not prove restored business/live state.

---

# 23. Completion and Handoff

An AI task may be marked `COMPLETED` only when:

- every required action has a terminal result;
- verification and prohibited-effect checks are complete or explicitly limited;
- approvals/decisions outside the AI are not falsely claimed;
- changes, sources, evidence, errors, residual risk, and open items are recorded;
- downstream owner receives exact versions, conditions, and next actions;
- monitoring/reopen/recovery duties are active where required.

---

# 24. Final Execution Principle

> **Plan from the desired outcome, classify every consequential action, execute the smallest authorized change, and prove the actual effect on the exact target before calling the work complete.**
