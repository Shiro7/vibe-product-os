# Product OS v1.0 — Output, Attribution, Provenance, Evidence, and Communication

~~~yaml
document_id: FRAMEWORK-AI-OPERATING-05
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-AI-OPERATING-CONTRACT@0.1.0
source_evidence_contract: ../Source_Evidence_Model/00_Shared_Source_Evidence_Contract.md
governed_scope: AI_OUTPUTS_CLAIMS_ATTRIBUTION_PROVENANCE_EVIDENCE_AND_COMMUNICATION
~~~

---

# 1. Purpose

This specification governs what an AI output means, how it cites and attributes sources, how its generation and transformations remain reconstructable, what it can and cannot prove, and how results are communicated without impersonation or overstatement.

---

# 2. Output Types

| Type | Meaning | Default downstream status |
|---|---|---|
| ANSWER | Direct response grounded in supplied or retrieved context | Informative; not canonical unless adopted |
| SUMMARY | Condensed representation preserving material meaning and limits | Derived view |
| EXTRACTION | Atomic content taken from a source with location/provenance | Proposed extracted claim until reviewed as needed |
| CLASSIFICATION | Proposed application of controlled vocabulary | Proposed unless deterministic and policy-authorized |
| ANALYSIS | Interpretation, comparison, pattern, model, or impact finding | Derived/proposed |
| RECOMMENDATION | Suggested option or action with rationale/tradeoffs | Not a decision |
| DRAFT | Proposed artifact, requirement, code, design, message, or record | Not approved/adopted by creation |
| PLAN | Proposed sequence, actions, controls, evidence, and handoff | Does not grant action authority |
| GENERATED_ASSET | Code, design, document, image, data, configuration, or test material | Requires ownership, validation, provenance, and adoption |
| EXECUTION_REPORT | Attributable account of performed tool actions and native results | Evidence of recorded execution only when tool records support it |
| VERIFICATION_REPORT | Expected/actual comparison with method, target, result, limitations | Verification evidence when authorized and fit |
| MONITORING_ALERT | Signal from recurring/event-driven observation | Requires triage; not automatically incident truth or closure |

---

# 3. Output Record

~~~yaml
ai_output_id:
ai_run_id:
output_type:
purpose:
audience:
scope:
canonical_subject_refs: []
source_refs: []
tool_and_action_refs: []
prompt_instruction_context_refs: []
model_system_agent_identity:
generated_at:
content_locator_or_digest:
claims: []
citations_and_attributions: []
inferences_and_assumptions: []
uncertainties_and_limitations: []
known_conflicts: []
sensitive_data_classification:
human_review_status:
approved_downstream_uses: []
prohibited_uses: []
supersession_and_expiry:
~~~

Exact prompt/configuration content may be protected, but material instruction/context identities and restrictions remain traceable.

---

# 4. Claim-State Separation

Every material statement is distinguishable as:

~~~text
SOURCE_QUOTED_OR_EXTRACTED
OBSERVED_BY_TOOL
SUPPORTED_FACT
AI_INFERENCE
ASSUMPTION
REQUESTED_IDEA
RECOMMENDATION
DRAFT_DECISION
APPROVED_DECISION_REFERENCE
DRAFT_REQUIREMENT
APPROVED_REQUIREMENT_REFERENCE
UNKNOWN_OR_OPEN_QUESTION
~~~

The output cannot label a decision/requirement approved without an authoritative record reference.

---

# 5. Citation and Attribution

For material sourced claims:

- cite the direct canonical/primary source where available;
- bind claim to exact source identity, revision/edition, location, and capture time where relevant;
- distinguish quotation, paraphrase, synthesis, and inference;
- preserve author/publisher/system identity and authority limitations;
- cite near the supported claim in human-facing output where practical;
- do not cite search-result pages, summaries, or secondary sources when a direct source is required and available;
- do not fabricate a URL, title, author, section, line, date, or quotation;
- state when a source could not be accessed or current verification was not performed.

Citation proves where information came from, not that the source is authoritative, applicable, current, correct, or sufficient.

---

# 6. Quotation and Intellectual-Property Boundary

AI output observes:

- quotation limits and permitted use;
- copyright, license, confidentiality, contract, disclosure, and attribution restrictions;
- distinction between ideas/facts and protected expression;
- transformation/originality review for generated assets;
- provenance and license review for training/reference/generated code/assets where applicable.

When full reproduction is not permitted or necessary, provide a bounded excerpt and a faithful original summary.

---

# 7. Provenance Chain

~~~text
source/input revision
→ extraction/transformation operation
→ instruction/context/configuration revision
→ model/agent/run identity
→ tool/action records
→ generated output revision/digest
→ human review/adoption decision
→ canonical artifact/change/release/live object
→ downstream derivations and evidence
~~~

Every transformation records whether it selected, filtered, translated, summarized, normalized, merged, classified, inferred, generated, or redacted content.

---

# 8. AI Output as Source or Evidence

AI output may be:

- a registered source;
- a proposed extraction, analysis, classification, draft, or recommendation;
- evidence that the exact model/system produced the exact output under recorded conditions;
- a generated test input, simulation, or asset with explicit provenance;
- a report containing references to independent execution evidence.

AI output is not by itself evidence that:

- its claims or citations are true;
- a requirement/design/architecture/code/control is correct;
- an action executed outside the model;
- a test, deployment, review, approval, or user event occurred;
- a human agreed, signed, acknowledged, or accepted;
- compliance, safety, security, privacy, accessibility, quality, release health, or outcome exists.

---

# 9. Execution Evidence

An execution claim requires as applicable:

- action/tool identity;
- exact target/account/project/tenant/environment;
- input/parameter identity with sensitive values protected;
- start/end time;
- native result/status/error;
- changed object/version/digest;
- partial/unknown outcome handling;
- post-action observation;
- actor/credential role;
- chain to authority and change record.

The AI narrative is an index or explanation; native evidence is preferred for material execution claims.

---

# 10. Verification Evidence

A verification claim binds:

- obligation/claim and acceptance/expected result;
- exact target/version/config/environment/data/cohort;
- method/tool/procedure and version;
- performer and independence;
- actual result including failures and limitations;
- execution time and evidence integrity;
- coverage and exclusions;
- review/acceptance status;
- invalidation/reopen triggers.

AI can execute and report authorized tests. It cannot manufacture missing runs, infer unobserved coverage, or call its own implementation independently verified where segregation is required.

---

# 11. Confidence and Uncertainty

Use confidence as an explanation, not authority.

Material outputs state as applicable:

- source coverage and authority;
- freshness and completeness;
- contradictions;
- inference depth;
- model/tool limitations;
- ambiguity and unknowns;
- likely impact if wrong;
- what would confirm/refute the result;
- safe interim treatment.

False precision, unsupported numeric probability, or confident tone does not improve evidence.

---

# 12. Corrections and Supersession

When an output is wrong or stale:

1. preserve original identity and affected uses;
2. issue a corrected/superseding output linked to the original;
3. state what changed and why;
4. reassess dependent artifacts, decisions, actions, gates, evidence, and communications;
5. notify affected recipients/owners proportionately;
6. update memory/retrieval indexes where permitted;
7. do not edit issued evidence/approval history in place.

---

# 13. Human Review Status

Use:

~~~text
NOT_REQUIRED_BY_POLICY
PENDING
IN_REVIEW
ACCEPTED
ACCEPTED_WITH_CHANGES
REJECTED
SUPERSEDED
~~~

`ACCEPTED` identifies the accepted use and authority. It does not make every claim universally approved or true.

---

# 14. Communication Contract

Human-facing communication leads with the outcome/status and includes only the detail necessary for safe understanding and verification.

For material work, communicate:

- what was asked and exact scope handled;
- what was found/created/changed/executed;
- sources and evidence;
- approvals or authority still pending;
- failures, uncertainty, residual risk, and prohibited assumptions;
- verification performed and not performed;
- affected files/systems/versions/targets;
- next owner/action or reopen condition.

Intermediate updates are progress, not final evidence. Final handoff remains self-contained.

---

# 15. External Representation and Non-Impersonation

AI does not:

- claim to be a named human;
- sign, consent, attest, acknowledge, approve, or certify for a person/organization without an authorized mechanism that clearly identifies the actual actor and authority;
- create fake meeting attendance, review, interview, user research, test performance, or stakeholder quote;
- hide material AI generation where disclosure is required by policy, law, contract, platform, or audience expectation;
- send/publish content merely because it was asked to draft it.

An authorized communication may be sent through an organizational account only when the actual sender/automation identity and approval model are governed.

---

# 16. Generated Code, Design, Data, and Documents

Generated assets require:

- purpose, owner, source/reference provenance, and license/confidentiality review;
- fit with canonical requirements/design/architecture/system;
- security, privacy, accessibility, localization, safety, quality, and data checks as applicable;
- reproducible build/render/test or visual inspection where relevant;
- adoption/approval decision separate from generation;
- version, change, and traceability records;
- disclosure/labeling where required.

Generation success is not production readiness.

---

# 17. Handoff Record

~~~yaml
ai_handoff_id:
task_and_run_refs: []
from_actor:
to_owner_or_authority:
scope_completed:
outputs_and_versions: []
actions_and_results: []
sources_and_evidence: []
decisions_and_approvals: []
assumptions_unknowns_conflicts: []
failures_and_limitations: []
changes_and_impact_refs: []
conditions_restrictions_residual_risks: []
verification_status:
required_next_actions: []
reopen_triggers: []
acknowledgement_required:
handed_off_at:
~~~

Receiving-owner acknowledgement cannot be fabricated from delivery/read status.

---

# 18. Final Output Principle

> **A trustworthy AI output makes its sources, transformations, inferences, actions, evidence, limitations, and review state inspectable—and never asks tone, fluency, or confidence to stand in for truth or authority.**
