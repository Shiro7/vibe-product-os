# Product OS v1.0 — Reconcile, Graph, and Impact

~~~yaml
document_id: FRAMEWORK-AUTOMATION-RECONCILE-GRAPH-IMPACT
version: 0.1.0
status: WORKING_DRAFT
commands:
  - reconcile
  - graph
  - impact
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. `reconcile`

## 1.1 Purpose

Compare independently stored control identities and detect drift that individual schema validation cannot find.

## 1.2 Framework Reconciliation

- artifact catalog has exactly 281 unique logical IDs;
- gate catalog has exactly 13 unique gate IDs;
- profile catalog exposes P1, P2, and P3;
- declared catalog counts equal actual entries;
- schema catalog identities and local paths are unique and resolvable;
- SRV and artifact/profile treatment remain consistent with their canonical source.

## 1.3 Project Reconciliation

Cross-check project ID, framework release/version, selected profile, catalog digests, core control references, repository identities, and register relationships across the manifest, lock, repository index, profile composition, and Artifact Register.

A missing control file, mismatched project identity, stale catalog digest, or incompatible framework version is an error. Reconciliation does not automatically repair drift.

# 2. `graph`

## 2.1 Purpose

Validate the GOV-008 trace graph as a directed, typed, versioned evidence-bearing relationship model.

## 2.2 Checks

- unique node and edge IDs;
- unique or explicitly modeled subject references;
- source and target endpoint resolution;
- allowed edge types and directions;
- self-loop and duplicate relationship policy;
- orphan nodes and required critical-chain coverage;
- edge status, provenance, evidence, and temporal consistency where declared.

Graph output includes node, edge, orphan, duplicate, and missing-endpoint counts. Structural connectivity does not prove that the linked source or evidence is true.

# 3. `impact`

## 3.1 Purpose

Calculate bounded change-impact candidates from a trace node or subject reference.

## 3.2 Traversal

- `downstream`: consumers and derived obligations;
- `upstream`: sources, decisions, requirements, or evidence relied upon;
- `both`: union of upstream and downstream candidates;
- `--max-depth`: positive bounded traversal depth, default 10.

Each candidate records node identity, subject reference, distance, and traversal direction. The start may resolve by node ID or governed subject reference.

## 3.3 Authority Boundary

The command always reports:

~~~yaml
materiality_decision: NOT_PERFORMED
no_impact_decision: NOT_AUTHORIZED
~~~

Zero candidates produces a warning, not a `NO_IMPACT` decision. Materiality, required rework, gate reopening, risk treatment, and stakeholder notification remain governed human decisions.

# 4. Change Workflow

~~~text
proposed source or artifact change
  → reconcile current identities
  → graph conformance
  → impact traversal
  → human materiality and completeness review
  → GOV-007 change record update
  → affected artifacts/evidence/gates updated
  → graph and reconcile rerun
~~~

# 5. Determinism

Graph indexing sorts stable identities and traversal uses a bounded visited set. Equivalent graph bytes and options produce the same candidate set. Candidate order is presentation data; consumers should rely on IDs and distance rather than array position.

# 6. Failure Cases

- unresolved graph endpoint;
- duplicate node/edge identity;
- missing start reference;
- invalid direction or depth;
- schema-invalid graph;
- project/framework identity drift;
- digest mismatch between lock and catalog snapshot.

The commands remain read-only on all failures.

# 7. Evidence and Handoff

The full graph/impact JSON reports can support GOV-007 change review and gate evidence. A reviewer shall record whether the candidate set is complete, which impacts are material, which artifacts reopen, and which evidence must be regenerated. The command report is analysis evidence, not the decision itself.

# 8. Acceptance

This family passes when 281/13/P1-P3 counts reconcile, graph examples have no endpoint/orphan errors, traversal returns the expected bounded candidates, and automation cannot emit an authorized no-impact or materiality decision.
