# Product OS v1.0 — Migrate, Archive, and Doctor

~~~yaml
document_id: FRAMEWORK-AUTOMATION-MIGRATE-ARCHIVE-DOCTOR
version: 0.1.0
status: WORKING_DRAFT
commands:
  - migrate
  - archive
  - doctor
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. `migrate`

## 1.1 Purpose

Stage an explicit, reviewable repository/schema transformation into a new output root without changing canonical source.

## 1.2 Plan Contract

A migration plan contains:

- unique plan ID and version;
- source and target schema versions;
- one or more uniquely identified operations;
- source path, target path, and exact expected SHA-256 per operation;
- operation type `COPY` or `TRANSFORM_JSON`;
- declarative rename/set/remove rules for JSON transforms;
- rollback strategy and verification instructions.

Paths are project/output-root relative and containment-checked. Targets must be unique. Source digests are verified before staging.

## 1.3 Transform Boundary

The reference implementation supports deterministic JSON pointer rename, set, and remove operations. It does not execute scripts, templates, shell commands, network calls, or project code. If transformed content declares a known schema identity, it is schema-validated before publication.

## 1.4 Apply Behavior

Dry-run validates the plan and calculates the execution manifest. Apply builds a temporary directory, writes or copies every target exclusively, records source/staged digests, writes `migration-manifest.json`, then atomically renames the directory to the requested new root.

The report always states:

~~~yaml
canonical_cutover_performed: false
deletion_performed: false
overwrite_performed: false
~~~

Cutover, canonical pointer updates, and removal of the old version require a separate governed authority workflow after verification.

# 2. `archive`

## 2.1 Purpose

Create an additive, content-addressed preservation package from explicitly included project paths.

## 2.2 Manifest

Every file entry records source-relative path, SHA-256, byte size, file mode, modification time, media type, and object path. Identical bytes share one stored object. The manifest records total bytes, unique objects, payload digest, source identity, and restore rule.

## 2.3 Safety

- At least one include and a new output root are required.
- Includes must exist inside the project root.
- Symlinks and unsupported filesystem objects block the operation.
- Apply copies to a temporary tree, verifies every object digest, writes the manifest, and atomically publishes the archive.
- Source files are never deleted or moved.
- Existing archive output is never merged or overwritten.

Archive creation does not authorize source disposal and does not prove that the retention selection is legally sufficient.

# 3. `doctor`

## 3.1 Purpose

Produce a bounded readiness diagnosis before CI, project validation, or mutation.

## 3.2 Checks

- Node runtime meets the declared minimum;
- framework root, schema directory, catalogs, and 21 schema identities are available;
- project root exists and is readable;
- five core project control files exist;
- filesystem can perform the required read/new-file semantics;
- Git availability, checkout identity, branch/worktree, and dirty state are observed when applicable;
- runtime/package/framework versions can be reported.

Default mode treats missing project controls as warnings so the command can diagnose an uninitialized directory. `--strict` promotes them to errors for an expected initialized project.

## 3.3 Observation Boundary

Doctor reports what it can observe locally. It does not verify remote repository ownership, deployment identity, cloud variables, native-tool freshness, or live service health unless a future governed adapter supplies that evidence.

# 4. Recovery Procedures

| Operation | Failure recovery |
|---|---|
| Migration before publish | Temporary staging tree is removed; source remains canonical |
| Migration after publish | Discard the staged root after digest review; no cutover occurred |
| Archive before publish | Temporary archive is removed; sources remain untouched |
| Archive after publish | Verify manifest, then remove or retain the new archive through authorized retention workflow |
| Doctor failure | Correct runtime/root/control condition and rerun; no rollback required |

# 5. Restore Verification

An archive restore is outside v0.1.0 apply behavior. The authorized restore process must choose a new empty target, copy objects by recorded relative path, verify every digest and byte count, resolve path conflicts, validate restored governed files, and record authority/evidence. Restoration must not overwrite a live canonical repository by default.

# 6. Acceptance

This family passes when migration dry-run creates nothing, apply produces the exact transformed staging tree and manifest, archive apply verifies two or more content objects while preserving sources, existing targets block safely, and doctor distinguishes advisory from strict project readiness.
