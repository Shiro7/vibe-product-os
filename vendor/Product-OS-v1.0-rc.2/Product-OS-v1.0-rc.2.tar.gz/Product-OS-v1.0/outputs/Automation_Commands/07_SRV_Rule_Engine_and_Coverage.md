# Product OS v1.0 — SRV Rule Engine and Coverage

~~~yaml
document_id: FRAMEWORK-AUTOMATION-SRV-RULE-ENGINE
version: 0.1.0
status: WORKING_DRAFT
rule_range: SRV-001..SRV-080
rule_count: 80
deterministic_count: 43
assisted_count: 37
unmapped_count: 0
machine_catalog_ref: config/rule-catalog.json
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Purpose

The SRV catalog carries the 80 Schemas & Repository Standard validation rules into executable treatment. Every rule retains its original ID and description. Automation classification changes how evidence is produced, not the normative meaning of the rule.

# 2. Treatment Classes

| Class | Meaning | Permitted result |
|---|---|---|
| `DETERMINISTIC` | The complete rule can be evaluated from bounded machine-readable inputs | pass/fail finding with exact evidence |
| `ASSISTED` | Automation can verify structure, candidates, declared evidence, or contradictions but professional/authority judgment remains | observations/findings plus explicit authority required |

There is no `UNMAPPED` rule in v0.1.0. An assisted mapping counts as implemented only when the command produces the bounded machine-checkable part and documents the unautomated decision.

# 3. Primary Command Allocation

| Command | Principal rule domain |
|---|---|
| `validate` | schema dialect/identity/reference, syntax, schema instances, serialization |
| `reconcile` | catalog counts, cross-file identity, lock/profile/register drift |
| `lint` | repository hygiene, secrets, unfinished content, link/path signals |
| `graph` | trace node/edge integrity, endpoints, duplicates, orphan signals |
| `impact` | bounded traversal and change-candidate discovery |
| `gate` | gate record coverage, evidence declarations, blocker representation |
| `baseline` | member pins, digests, verification, reproducibility |
| `handoff` | transfer membership, obligations, blockers, acknowledgement fields |
| `init` | minimal control-plane construction and profile/topology recording |
| `migrate` | digest-pinned compatibility transformation and staged verification |
| `archive` | integrity, content addressing, retention package signals |
| `doctor` | framework/project/runtime/repository readiness observations |

Primary allocation does not prevent supporting checks in another command. Duplicate implementations must share the same rule meaning and severity policy.

# 4. Rule Evaluation Record

Each evaluated rule should be reconstructable from:

- rule ID and catalog version;
- command/package version;
- subject and input digest or revision;
- evaluation class;
- algorithm/configuration identity;
- finding result and severity;
- evidence references;
- authority boundary;
- timestamp and runner identity.

# 5. Deterministic Rule Requirements

A deterministic rule must:

1. use bounded inputs and stable comparison semantics;
2. reject ambiguous serialization;
3. expose exact expected and actual facts where safe;
4. avoid network-dependent fallback;
5. fail closed when an input required for the claim is absent;
6. have a positive and negative test or an equivalent audited fixture;
7. preserve the same rule ID across human and machine reports.

# 6. Assisted Rule Requirements

An assisted rule must identify:

- the machine-verifiable subcondition;
- the candidates or missing declarations found;
- the expertise or authority needed;
- the governed record where disposition belongs;
- why a zero-finding result is not a final approval or sufficiency claim.

Examples include materiality, evidence sufficiency, accessibility/legal/security judgment, retention disposition, and gate acceptance.

# 7. Severity and Blocking

Rule severity is based on the attempted claim and execution mode. Missing mandatory schema identity is an error. Missing project controls in non-strict doctor mode is a warning because the command may be running before initialization. Partial gate coverage may be a warning in explicit partial review but an error for readiness evaluation.

Changing severity based on convenience or profile is prohibited. Profile may change required physical packages only through the pinned composition rules.

# 8. Coverage Governance

[`config/rule-catalog.json`](config/rule-catalog.json) is generated from and reconciled with the canonical SRV source. The release audit shall prove:

- IDs SRV-001 through SRV-080 are contiguous and unique;
- declared rule count equals actual entries;
- deterministic plus assisted equals 80;
- every entry names an existing primary command;
- every coverage status is `IMPLEMENTED` or `ASSISTED_IMPLEMENTED` exactly as required by its treatment;
- every entry contains an authority boundary;
- descriptions remain synchronized with the normative source.

# 9. Rule Change

A wording-only clarification that does not change outcome may be patch-compatible. New inputs, changed pass/fail semantics, expanded authority, reduced evidence, or new default severity require versioned review. Rules are never silently renumbered; retirement records an alias/supersession path.

# 10. Acceptance

Coverage closes when the machine catalog proves 80 unique mapped rules, counts 43 deterministic and 37 assisted, runtime handlers emit the referenced IDs, tests exercise representative domains, and no assisted rule is described as an autonomous decision.
