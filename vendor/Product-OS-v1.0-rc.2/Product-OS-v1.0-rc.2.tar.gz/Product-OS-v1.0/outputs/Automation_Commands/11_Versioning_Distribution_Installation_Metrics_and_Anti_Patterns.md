# Product OS v1.0 — Versioning, Distribution, Installation, Metrics, and Anti-Patterns

~~~yaml
document_id: FRAMEWORK-AUTOMATION-VERSIONING-DISTRIBUTION-METRICS
version: 0.1.0
status: WORKING_DRAFT
package_name: "@product-os/automation-commands"
runtime_minimum: NODE_18
runtime_dependency_count: 0
anti_pattern_count: 40
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Version Axes

The package, command catalog, rule catalog, exit-code catalog, schemas, framework release, and project lock are versioned independently but reconciled. The project framework lock pins the compatible set.

Semantic versioning applies:

- **Patch:** compatible defect correction or diagnostic clarification.
- **Minor:** new optional command/field/check that preserves defaults, authority, and existing successful inputs.
- **Major:** changed default, removed/renamed command, new required input, exit-code meaning change, serialization change, mutation expansion, reduced safety, or authority change.

# 2. Distribution

The canonical package includes `bin/`, `lib/`, `config/`, normative documents, tests, package metadata, and release integrity metadata. Distribution shall be immutable and content-digested. Installing from an unpinned branch, mutable URL, or unverified copied folder cannot support baseline evidence.

The reference implementation has no third-party runtime dependency; this reduces supply-chain surface but does not remove the need to verify Node, package origin, and package digest.

# 3. Installation and Invocation

Supported installation patterns are a pinned framework bundle, a verified package archive, or a repository checkout at an exact revision. Use Node.js 18 or later. The executable may be invoked through the installed `product-os` binary or directly with `node bin/product-os.js`.

Installation must not auto-initialize a project, rewrite repositories, enable hooks, contact remote services, or schedule jobs. Those are separate explicit actions.

# 4. Compatibility Matrix

A release manifest shall state compatible Product OS framework, schema catalog, command/rule catalog, and Node ranges. Startup or `doctor` fails closed on a known incompatible major. A project may remain on an older compatible tool while planning migration; the mismatch and support window remain visible.

# 5. Deprecation

Deprecation requires announcement, replacement, compatibility window, migration guidance, detection rule, and removal version. Deprecated command behavior remains testable until removal. Silent aliases, argument reinterpretation, and warning-free behavioral drift are forbidden.

# 6. Service Metrics

Measure:

1. executions and result distribution by command/version;
2. deterministic error and assisted warning counts by SRV rule;
3. median and upper-percentile duration by scope;
4. drift detected by reconcile;
5. graph endpoint/orphan/candidate trends;
6. baseline reproducibility rate;
7. handoff blocker and acknowledgement latency;
8. dry-run-to-apply conversion for bounded mutation;
9. blocked overwrite/path/digest/symlink attempts;
10. stale report and cache-invalidated run counts;
11. false-positive/accepted-risk disposition where governed;
12. pilot coverage across P1/P2/P3 and lifecycle gates.

Metrics must not rank teams by low finding counts or reward bypassing validation.

# 7. Forty Prohibited Anti-Patterns

| ID | Anti-pattern |
|---|---|
| ACA-001 | Treating exit 0 as gate, compliance, release, or production approval |
| ACA-002 | Allowing a command to approve its own evidence or disposition its own finding |
| ACA-003 | Making a write-capable command apply by default |
| ACA-004 | Adding `force` behavior that overwrites an existing governed target |
| ACA-005 | Deleting or moving canonical source during migration staging |
| ACA-006 | Deleting source merely because archive creation passed |
| ACA-007 | Fetching unresolved schemas from the network |
| ACA-008 | Accepting duplicate JSON/YAML keys with last-write-wins semantics |
| ACA-009 | Enabling YAML tags, anchors, aliases, merge keys, or executable objects |
| ACA-010 | Loading project-provided runtime code as validation configuration |
| ACA-011 | Following symlinks outside the declared project or output root |
| ACA-012 | Inferring project identity from a generic folder when governed identity exists |
| ACA-013 | Creating all 281 artifact files during initialization |
| ACA-014 | Representing inactive artifacts as empty mandatory files |
| ACA-015 | Auto-approving `NOT_APPLICABLE` from missing files |
| ACA-016 | Converting zero impact candidates into an authorized `NO_IMPACT` decision |
| ACA-017 | Hiding partial gate coverage behind a successful schema check |
| ACA-018 | Calling a mutable or digest-unverified collection a baseline |
| ACA-019 | Auto-acknowledging a handoff for sender or recipient |
| ACA-020 | Repairing catalog drift silently during reconciliation |
| ACA-021 | Reporting suspected secret values instead of redacted locations/categories |
| ACA-022 | Truncating findings or replacing complete output with a summary |
| ACA-023 | Returning different result semantics between human and JSON modes |
| ACA-024 | Reusing cached results without all semantic dependency digests |
| ACA-025 | Retrying deterministic failures until a green run appears |
| ACA-026 | Overwriting evidence from an earlier CI attempt |
| ACA-027 | Running concurrent apply jobs against the same target namespace |
| ACA-028 | Publishing a multi-file output before every file verifies |
| ACA-029 | Leaving partial temporary output presented as successful canonical state |
| ACA-030 | Using absolute local paths as stable cross-system object identity |
| ACA-031 | Changing severity or evidence duty merely to make a profile pass |
| ACA-032 | Renumbering or repurposing SRV rules without versioned supersession |
| ACA-033 | Adding undocumented command aliases or positional shortcuts |
| ACA-034 | Treating lint absence of secret patterns as proof no secret exists |
| ACA-035 | Treating schema validity as proof of factual truth or freshness |
| ACA-036 | Treating doctor observations as remote ownership or live-health proof |
| ACA-037 | Performing canonical migration cutover inside the staging command |
| ACA-038 | Restoring an archive over a live repository without empty-target verification |
| ACA-039 | Shipping incompatible package/schema/catalog versions without a matrix |
| ACA-040 | Marking the library baselined before authority approval and pilot evidence |

# 8. Release Checklist

- package version and engine range are exact;
- catalog/document/runtime command lists reconcile;
- SRV counts and descriptions reconcile;
- all tests and syntax checks pass;
- generated reports contain no candidate secret values;
- no write command overwrites, deletes, or cuts over;
- changelog and compatibility/migration statements are complete;
- package digest and provenance are available;
- Working Draft/baseline/approval status is accurate;
- pilot evidence is linked before v1.0 final baseline.

# 9. Acceptance

Versioning and distribution pass when an exact package can be installed and reproduced from its pinned source, incompatibilities fail visibly, metrics preserve context and do not incentivize suppression, and all 40 anti-patterns are included in review and pilot negative testing.
