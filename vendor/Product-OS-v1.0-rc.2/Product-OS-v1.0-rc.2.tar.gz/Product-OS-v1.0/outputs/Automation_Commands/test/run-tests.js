'use strict';

const assert = require('assert');
const childProcess = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const packageRoot = path.resolve(__dirname, '..');
const workspaceRoot = path.resolve(packageRoot, '..', '..');
const frameworkRoot = path.resolve(packageRoot, '..', 'Schemas_Repository_Standard');
const { ProjectContext } = require('../lib/project-context');
const { parseDocument, parseYaml } = require('../lib/serialization');
const { sha256File } = require('../lib/fs-safe');
const validate = require('../lib/commands/validate');
const reconcile = require('../lib/commands/reconcile');
const graph = require('../lib/commands/graph');
const impact = require('../lib/commands/impact');
const gate = require('../lib/commands/gate');
const baseline = require('../lib/commands/baseline');
const handoff = require('../lib/commands/handoff');
const lint = require('../lib/commands/lint');
const init = require('../lib/commands/init');
const migrate = require('../lib/commands/migrate');
const archive = require('../lib/commands/archive');
const doctor = require('../lib/commands/doctor');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }
function context(project = workspaceRoot) { return new ProjectContext({ framework: frameworkRoot, project }); }
function expectPass(report) { assert.strictEqual(report.summary.errors, 0, JSON.stringify(report.findings, null, 2)); }
function writeJson(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`); }

test('JSON parser rejects duplicate keys', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'product-os-json-'));
  const file = path.join(directory, 'duplicate.json');
  fs.writeFileSync(file, '{"a":1,"a":2}\n');
  assert.throws(() => parseDocument(file), /Duplicate JSON key/);
  fs.rmSync(directory, { recursive: true, force: true });
});

test('restricted YAML parser rejects duplicate keys and aliases', () => {
  assert.throws(() => parseYaml('a: 1\na: 2\n', 'duplicate.yaml'), /Duplicate YAML key/);
  assert.throws(() => parseYaml('a: &x 1\nb: *x\n', 'alias.yaml'), /anchors, aliases/);
});

test('framework schemas, catalogs, and examples validate', () => {
  const report = validate({ scope: 'framework' }, context());
  expectPass(report);
  assert.strictEqual(report.data.selected_files, 19);
  assert.strictEqual(report.data.schema_count, 21);
  assert.strictEqual(report.data.local_reference_count, 485);
});

test('framework catalogs reconcile to canonical counts', () => {
  const report = reconcile({ scope: 'framework' }, context());
  expectPass(report);
  assert.strictEqual(report.data.framework.artifacts, 281);
  assert.strictEqual(report.data.framework.gates, 13);
  assert.deepStrictEqual(report.data.framework.profiles, ['P1', 'P2', 'P3']);
});

test('trace graph validates without endpoint or orphan errors', () => {
  const project = frameworkRoot;
  const report = graph({ file: 'examples/records/trace-graph.json' }, context(project));
  expectPass(report);
  assert.strictEqual(report.data.nodes, 2);
  assert.strictEqual(report.data.edges, 1);
});

test('impact traversal returns bounded candidates and no authority claim', () => {
  const project = frameworkRoot;
  const report = impact({ file: 'examples/records/trace-graph.json', from: 'NODE-EVD-001', direction: 'downstream', 'max-depth': '4' }, context(project));
  expectPass(report);
  assert.strictEqual(report.data.impact_candidate_count, 1);
  assert.strictEqual(report.data.no_impact_decision, 'NOT_AUTHORIZED');
});

test('gate command supports partial draft review without approving it', () => {
  const project = frameworkRoot;
  const report = gate({ file: 'examples/records/gate-decision.json', partial: true }, context(project));
  expectPass(report);
  assert.strictEqual(report.summary.warnings, 1);
  assert.strictEqual(report.data.automation_gate_decision, 'NOT_AUTHORIZED');
});

test('baseline command detects missing or unverified pinned content', () => {
  const project = frameworkRoot;
  const report = baseline({ file: 'examples/records/baseline.json' }, context(project));
  assert.ok(report.summary.errors > 0);
  assert.strictEqual(report.data.reproducibility_claim, 'NOT_ESTABLISHED');
});

test('handoff command validates acknowledged state and preserves authority boundary', () => {
  const project = frameworkRoot;
  const report = handoff({ file: 'examples/records/handoff.json' }, context(project));
  expectPass(report);
  assert.strictEqual(report.data.automation_acknowledgement, 'NOT_AUTHORIZED');
});

test('init dry-run and apply create only operational control files and catalog snapshots', () => {
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'product-os-init-'));
  const ctx = context(project);
  const options = { 'project-id': 'TEST-PRODUCT', 'project-name': 'Test Product', profile: 'P2', topology: 'FRAMEWORK_PLUS_PROJECT', target: '.' };
  const dryRun = init(options, ctx);
  expectPass(dryRun);
  assert.strictEqual(fs.existsSync(path.join(project, 'product-os.yaml')), false);
  const applied = init({ ...options, apply: true }, ctx);
  expectPass(applied);
  assert.strictEqual(applied.data.planned_files.length, 9);
  const projectValidation = validate({ scope: 'project' }, context(project));
  expectPass(projectValidation);
  const projectReconciliation = reconcile({ scope: 'all' }, context(project));
  expectPass(projectReconciliation);
  const diagnosis = doctor({ strict: true }, context(project));
  expectPass(diagnosis);
  assert.throws(() => init({ ...options, apply: true }, ctx), (error) => error && error.code === 'ACTION_BLOCKED' && error.exitCode === 4);
  fs.rmSync(project, { recursive: true, force: true });
});

test('lint passes a bounded clean project and does not emit secret values', () => {
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'product-os-lint-'));
  fs.writeFileSync(path.join(project, 'README.md'), '# Clean Project\n\nOperational content.\n');
  const report = lint({}, context(project));
  expectPass(report);
  assert.strictEqual(report.data.secret_values_emitted, false);
  fs.rmSync(project, { recursive: true, force: true });
});

test('migration stages digest-pinned JSON transform without cutover or overwrite', () => {
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'product-os-migrate-'));
  const source = path.join(project, 'source.json');
  writeJson(source, { schema_version: '0.1.0', name: 'before' });
  const plan = {
    plan_id: 'MIGRATION-TEST-001', plan_version: '0.1.0', source_schema_version: '0.1.0', target_schema_version: '0.2.0',
    operations: [{ operation_id: 'OP-001', type: 'TRANSFORM_JSON', source: 'source.json', target: 'records/source.json', expected_sha256: sha256File(source), transform: { rename: { '/name': '/display_name' }, set: { '/schema_version': '0.2.0' }, remove: [] } }],
    rollback_strategy: 'Discard the staged output because canonical source is unchanged.', verification: ['Validate staged JSON and compare source/staged digests.']
  };
  writeJson(path.join(project, 'plan.json'), plan);
  const dryRun = migrate({ plan: 'plan.json', output: 'staged' }, context(project));
  expectPass(dryRun);
  assert.strictEqual(fs.existsSync(path.join(project, 'staged')), false);
  const applied = migrate({ plan: 'plan.json', output: 'staged', apply: true }, context(project));
  expectPass(applied);
  const transformed = parseDocument(path.join(project, 'staged/records/source.json'));
  assert.deepStrictEqual(transformed, { schema_version: '0.2.0', display_name: 'before' });
  assert.strictEqual(applied.data.canonical_cutover_performed, false);
  fs.rmSync(project, { recursive: true, force: true });
});

test('archive creates content-addressed verified objects without deleting sources', () => {
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'product-os-archive-'));
  fs.mkdirSync(path.join(project, 'source'));
  fs.writeFileSync(path.join(project, 'source/a.txt'), 'alpha\n');
  fs.writeFileSync(path.join(project, 'source/b.txt'), 'beta\n');
  const dryRun = archive({ include: 'source', output: 'archive-out' }, context(project));
  expectPass(dryRun);
  assert.strictEqual(fs.existsSync(path.join(project, 'archive-out')), false);
  const applied = archive({ include: 'source', output: 'archive-out', apply: true }, context(project));
  expectPass(applied);
  assert.strictEqual(applied.data.file_count, 2);
  assert.strictEqual(fs.existsSync(path.join(project, 'source/a.txt')), true);
  const manifest = parseDocument(path.join(project, 'archive-out/archive-manifest.json'));
  manifest.entries.forEach((entry) => assert.strictEqual(sha256File(path.join(project, 'archive-out', entry.object_path)), entry.sha256));
  fs.rmSync(project, { recursive: true, force: true });
});

test('CLI exposes all twelve commands and returns usage error for unknown command', () => {
  const help = childProcess.spawnSync(process.execPath, [path.join(packageRoot, 'bin/product-os.js'), '--help'], { encoding: 'utf8' });
  assert.strictEqual(help.status, 0);
  ['init', 'validate', 'lint', 'reconcile', 'graph', 'impact', 'gate', 'baseline', 'handoff', 'migrate', 'archive', 'doctor'].forEach((command) => assert.ok(help.stdout.includes(command)));
  const unknown = childProcess.spawnSync(process.execPath, [path.join(packageRoot, 'bin/product-os.js'), 'unknown-command'], { encoding: 'utf8' });
  assert.strictEqual(unknown.status, 2);
});

let passed = 0;
const failures = [];
for (const item of tests) {
  try {
    item.fn();
    passed += 1;
    process.stdout.write(`PASS ${item.name}\n`);
  } catch (error) {
    failures.push({ name: item.name, error });
    process.stderr.write(`FAIL ${item.name}\n${error.stack}\n`);
  }
}
process.stdout.write(`SUMMARY tests=${tests.length} passed=${passed} failed=${failures.length}\n`);
if (failures.length) process.exitCode = 1;
