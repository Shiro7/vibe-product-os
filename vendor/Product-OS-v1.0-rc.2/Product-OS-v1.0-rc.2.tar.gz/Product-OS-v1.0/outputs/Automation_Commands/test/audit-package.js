'use strict';

const assert = require('assert');
const childProcess = require('child_process');
const fs = require('fs');
const path = require('path');

const packageRoot = path.resolve(__dirname, '..');
const outputsRoot = path.resolve(packageRoot, '..');
const { JsonReader } = require('../lib/serialization');
const { COMMANDS, helpText } = require('../lib/command-runner');

function filesBelow(root) {
  const result = [];
  const queue = [root];
  while (queue.length) {
    const directory = queue.shift();
    for (const name of fs.readdirSync(directory).sort()) {
      const target = path.join(directory, name);
      const stat = fs.lstatSync(target);
      if (stat.isDirectory()) queue.push(target);
      else if (stat.isFile()) result.push(target);
      else throw new Error(`Unsupported package filesystem object: ${target}`);
    }
  }
  return result.sort();
}

function parseJson(file) {
  return new JsonReader(fs.readFileSync(file, 'utf8'), file).parse();
}

const files = filesBelow(packageRoot);
const markdownFiles = files.filter((file) => file.endsWith('.md'));
const javascriptFiles = files.filter((file) => file.endsWith('.js'));
const jsonFiles = files.filter((file) => file.endsWith('.json'));

assert.strictEqual(files.length, 44, 'Package file count drifted.');
assert.strictEqual(markdownFiles.length, 14, 'Normative Markdown count must remain 14.');
assert.strictEqual(javascriptFiles.length, 26, 'JavaScript implementation/audit count must remain 26.');

for (const file of jsonFiles) parseJson(file);

for (const file of javascriptFiles) {
  const result = childProcess.spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  assert.strictEqual(result.status, 0, `JavaScript syntax failed for ${file}: ${result.stderr}`);
}

const commandCatalog = parseJson(path.join(packageRoot, 'config/command-catalog.json'));
const commandNames = commandCatalog.commands.map((entry) => entry.command);
assert.strictEqual(commandCatalog.command_count, 12);
assert.strictEqual(new Set(commandNames).size, 12);
assert.deepStrictEqual([...commandNames].sort(), Object.keys(COMMANDS).sort());
for (const command of commandNames) assert.ok(helpText().includes(`  ${command}`), `Help is missing ${command}.`);
for (const entry of commandCatalog.commands) {
  if (entry.mutation === 'NONE') assert.strictEqual(entry.default_mode, 'READ_ONLY');
  else assert.strictEqual(entry.default_mode, 'DRY_RUN');
}

const ruleCatalog = parseJson(path.join(packageRoot, 'config/rule-catalog.json'));
assert.strictEqual(ruleCatalog.rule_count, 80);
assert.strictEqual(ruleCatalog.entries.length, 80);
assert.strictEqual(ruleCatalog.deterministic_count, 43);
assert.strictEqual(ruleCatalog.assisted_count, 37);
assert.strictEqual(ruleCatalog.unmapped_count, 0);
for (let index = 0; index < 80; index += 1) {
  const entry = ruleCatalog.entries[index];
  assert.strictEqual(entry.rule_id, `SRV-${String(index + 1).padStart(3, '0')}`);
  assert.ok(commandNames.includes(entry.primary_command));
  assert.ok(['DETERMINISTIC', 'ASSISTED'].includes(entry.automation_treatment));
  assert.strictEqual(entry.coverage_status, entry.automation_treatment === 'DETERMINISTIC' ? 'IMPLEMENTED' : 'ASSISTED_IMPLEMENTED');
  assert.ok(entry.authority_boundary.length > 20);
}
assert.strictEqual(ruleCatalog.entries.filter((entry) => entry.automation_treatment === 'DETERMINISTIC').length, 43);
assert.strictEqual(ruleCatalog.entries.filter((entry) => entry.automation_treatment === 'ASSISTED').length, 37);

const exitCatalog = parseJson(path.join(packageRoot, 'config/exit-codes.json'));
assert.deepStrictEqual(exitCatalog.codes.map((entry) => entry.code), [0, 1, 2, 3, 4, 5]);
assert.strictEqual(new Set(exitCatalog.codes.map((entry) => entry.name)).size, 6);

const packageJson = parseJson(path.join(packageRoot, 'package.json'));
assert.deepStrictEqual(packageJson.dependencies, undefined);
assert.strictEqual(packageJson.engines.node, '>=18.0.0');
assert.ok((fs.statSync(path.join(packageRoot, 'bin/product-os.js')).mode & 0o111) !== 0, 'CLI entry point is not executable.');

const unfinished = /\b(?:TODO|TBD|FIXME)\b|for brevity|content omitted/i;
const linkPattern = /\[[^\]]+\]\(([^)]+)\)/g;
let checkedLinks = 0;
for (const file of markdownFiles) {
  const content = fs.readFileSync(file, 'utf8');
  assert.strictEqual((content.match(/^(?:```|~~~)/gm) || []).length % 2, 0, `Unbalanced Markdown fence in ${file}.`);
  assert.ok(!unfinished.test(content), `Unfinished authoring marker in ${file}.`);
  let match;
  while ((match = linkPattern.exec(content)) !== null) {
    let target = match[1].trim().replace(/^<|>$/g, '');
    if (target.startsWith('#') || /^[a-z]+:/i.test(target)) continue;
    target = target.split('#')[0];
    if (!target) continue;
    const resolved = path.resolve(path.dirname(file), decodeURIComponent(target));
    assert.ok(resolved.startsWith(outputsRoot + path.sep) || resolved === outputsRoot, `Link escapes Product OS outputs: ${file} -> ${target}`);
    assert.ok(fs.existsSync(resolved), `Broken Markdown link: ${file} -> ${target}`);
    checkedLinks += 1;
  }
}

process.stdout.write(`AUDIT PASS files=${files.length} markdown=${markdownFiles.length} javascript=${javascriptFiles.length} json=${jsonFiles.length} links=${checkedLinks} commands=${commandNames.length} rules=${ruleCatalog.entries.length} exits=${exitCatalog.codes.length}\n`);
