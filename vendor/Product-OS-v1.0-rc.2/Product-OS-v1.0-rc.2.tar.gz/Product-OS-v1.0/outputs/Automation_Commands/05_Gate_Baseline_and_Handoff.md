# Product OS v1.0 — Gate, Baseline, and Handoff

~~~yaml
document_id: FRAMEWORK-AUTOMATION-GATE-BASELINE-HANDOFF
version: 0.1.0
status: WORKING_DRAFT
commands:
  - gate
  - baseline
  - handoff
gate_scope_count: 13
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Shared Lifecycle Boundary

These commands prepare lifecycle records for accountable review. They validate record structure, required membership, evidence declarations, blockers, signatures/acknowledgements, and reproducibility. They do not perform lifecycle authority actions.

# 2. `gate`

## 2.1 Inputs and Checks

The command receives a gate-decision record and verifies:

- gate ID exists in the canonical 13-gate catalog;
- outcome, review state, authority references, review time, and decision basis are schema-valid;
- required artifact/evidence references are declared and coverage counts reconcile;
- blockers, conditions, waivers, and residual risks are represented rather than hidden;
- record identity and predecessor/baseline references are coherent.

`--partial` permits a draft readiness review. Missing coverage becomes a warning only where partial review is explicitly allowed; it never becomes approval.

## 2.2 Output Boundary

The report contains `automation_gate_decision: NOT_AUTHORIZED`. A zero-error result means the record is structurally ready for its declared authority process, not that the gate passed.

# 3. `baseline`

## 3.1 Purpose

Determine whether each declared baseline member is pinned to an exact identity/version/digest and whether required verification evidence is present.

## 3.2 Reproducibility Conditions

- unique baseline and member identities;
- exact artifact/native-object/source revision;
- immutable or verifiable content digest;
- member status compatible with baseline policy;
- required evidence and verification state declared;
- framework/schema/catalog versions pinned;
- supersession, retention, and restoration context represented.

If any required member is missing, mutable without a pin, digest-unverified, or references unresolved content, the command reports `reproducibility_claim: NOT_ESTABLISHED`.

## 3.3 Non-Claim

Reproducibility does not equal quality, acceptance, deployment readiness, or legal retention compliance. Baseline establishment remains an authorized governed action.

# 4. `handoff`

## 4.1 Purpose

Validate transfer from one accountable lifecycle owner/system to another.

## 4.2 Checks

- source and recipient identities and authority references;
- handoff state and acknowledgement fields;
- artifact, evidence, baseline, and unresolved-obligation membership;
- blockers, exceptions, access requirements, and due dates;
- sender/recipient expectations and reopen conditions;
- no silent loss of open questions, risks, assumptions, or change obligations.

The command reports `automation_acknowledgement: NOT_AUTHORIZED`. It cannot acknowledge receipt or accept responsibility for the recipient.

# 5. Canonical Sequence

~~~text
artifact and evidence update
  → validate / reconcile / graph
  → gate readiness report
  → authority gate decision
  → baseline reproducibility check
  → authority baseline establishment
  → handoff validation
  → sender and recipient acknowledgement
~~~

Each arrow is recorded; no successful command silently advances the project state.

# 6. Partial, Conditional, and Failed States

- Partial review remains review-only.
- Conditional gate outcomes require explicit conditions, owner, due date, and verification route.
- A failed or deferred gate cannot be masked by a valid baseline file.
- A handoff with open blockers may be structurally valid but is not complete unless policy and authorities explicitly permit that state.
- Missing evidence is never transformed into `NOT_APPLICABLE` by automation.

# 7. Evidence

The retained run package should include the input record digest, report, CLI/framework versions, project revision, and authority disposition that followed. The disposition is a separate governed record; it must not be written into the automation report after the fact.

# 8. Acceptance

This family passes when a partial gate produces a warning and no approval, an incomplete baseline fails reproducibility, a valid acknowledged handoff passes structural checks while preserving acknowledgement authority, and the 13 gate identities reconcile to the canonical catalog.
