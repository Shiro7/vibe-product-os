# Product OS v1.0 — Shared Automation and Command Contract

~~~yaml
contract_id: SHARED-AUTOMATION-COMMAND-CONTRACT
version: 0.1.0
status: WORKING_DRAFT
applies_to: ALL_PRODUCT_OS_COMMANDS
inherits:
  - SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
  - AI-OPERATING-SPECIFICATION@0.1.0
authority_effect: NONE
baseline_state: NOT_BASELINED
~~~

# 1. Contract Purpose

Every Product OS command inherits this contract. A specialized command may narrow inputs or add checks, but it may not weaken scope containment, authority separation, evidence integrity, dry-run protection, deterministic parsing, complete reporting, or failure semantics.

# 2. Required Command Anatomy

Every command definition shall declare:

1. stable command name and version;
2. action class: `READ_ONLY`, `BOUNDED_MUTATION`, or `STAGED_MUTATION`;
3. purpose and subjects inspected or created;
4. required and optional inputs with exact defaults;
5. preconditions and filesystem scope;
6. deterministic and assisted rules applied;
7. output report and optional files;
8. finding severities and exit behavior;
9. authority explicitly retained by humans or external governed systems;
10. side effects, idempotency, recovery, and evidence requirements.

# 3. Universal Preconditions

- The invoked command exists in the pinned command catalog.
- The runtime meets the package engine requirement.
- Project and framework roots resolve to explicit absolute locations.
- Governed files are contained by their declared root and are not followed through unapproved symlinks.
- Schema identities resolve from the local pinned schema catalog.
- Input serialization is valid UTF-8 JSON or restricted YAML where governed data is expected.
- Repeated scalar options that must be unique are rejected; repeated list options remain ordered.
- A write-capable command is a dry-run unless `--apply` is explicit.

# 4. Input Contract

Input precedence is:

~~~text
explicit CLI option
  → command-specific governed project control
  → pinned framework default
  → defined constant default
~~~

Ambient environment values may describe the runtime, but they may not silently change project identity, authority, profile, framework version, migration target, archive scope, or baseline membership. Secrets are never accepted as ordinary command output fields.

# 5. Output Contract

Every normal execution returns one complete report containing:

- command and subject;
- start and finish timestamps;
- result: `PASS`, `PASS_WITH_WARNINGS`, or `FAIL`;
- summary counts for errors, warnings, information findings, and total findings;
- all findings in deterministic order;
- command-specific data;
- `approval_claim: NONE`.

Human output is a presentation of the same report. `--json` emits the full machine report. `--quiet` suppresses normal human output but does not alter exit codes or side effects. Errors on stderr contain a stable error code and never claim approval.

# 6. Finding Contract

Each finding includes a stable finding ID, rule ID, severity, message, status, and optional subject, instance path, expected/actual values, remediation, blocking scope, and required authority. Findings may identify a block; only the relevant authority can dispose of the underlying decision.

Severity meaning:

| Severity | Meaning |
|---|---|
| `ERROR` | Deterministic failure prevents the requested conformance claim |
| `WARNING` | Reviewable gap, partial mode, ambiguity, or non-blocking risk |
| `INFO` | Positive observation or contextual evidence |

# 7. Conformance Layers

1. **Invocation conformance:** grammar and required options are valid.
2. **Serialization conformance:** governed data parses without duplicate keys or forbidden YAML features.
3. **Schema conformance:** the record matches the pinned schema.
4. **Catalog conformance:** IDs, versions, counts, and references reconcile.
5. **Graph conformance:** endpoints, identities, and traversal are valid.
6. **Lifecycle conformance:** gate, baseline, and handoff records are internally ready for authority review.
7. **Operational conformance:** mutations are bounded, verifiable, additive, and recoverable.

Passing one layer never implies passing a later layer.

# 8. Idempotency and Mutation

- Read-only commands must not change governed content.
- Dry-run must not create its intended output.
- Apply mode must reject an existing output rather than merge or overwrite it.
- Multi-file output is built in a temporary sibling directory and renamed only after successful verification.
- Partial output is removed on failure.
- Source deletion is outside the reference CLI.
- Repeating a read command over unchanged inputs produces equivalent findings, except timestamps and explicitly recorded runtime observations.

# 9. Authority Contract

Automation can establish structural facts, exact reference resolution, digests, graph reachability, count equality, and presence of declared evidence. It cannot establish truthfulness, sufficiency of professional judgment, business acceptance, risk acceptance, compliance, gate approval, or release authorization.

Fields such as `automation_gate_decision`, `materiality_decision`, `no_impact_decision`, and `automation_acknowledgement` shall remain explicitly unauthorized or not performed.

# 10. Security and Privacy

- Paths in reports are limited to operational subjects and must not expose unrelated user directories.
- Lint rules report the location and category of a suspected secret, never the candidate value.
- Remote schema retrieval and executable configuration are forbidden.
- YAML tags, anchors, aliases, merge keys, and multiple documents are rejected.
- Archives preserve original bytes and record media type, size, digest, and relative path.
- Sensitive evidence remains governed by project access and retention policy; the CLI does not weaken it.

# 11. Compatibility

Command behavior follows semantic versioning. Patch releases may correct diagnostics without changing successful canonical output. Minor releases may add optional fields or commands. Any change to defaults, authority boundary, exit meanings, accepted serialization, mutation scope, or required fields is breaking and requires a major version or an explicitly governed migration.

# 12. Acceptance Conditions

This shared contract is satisfied only when all commands are cataloged, all 80 SRV rules have an explicit automation treatment, mutation tests prove no-overwrite and no-delete behavior, machine reports are complete, and the closure review records exact test and audit evidence.
