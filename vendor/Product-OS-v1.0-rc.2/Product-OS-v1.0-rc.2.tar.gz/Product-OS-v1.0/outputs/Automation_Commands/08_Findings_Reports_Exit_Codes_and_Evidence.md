# Product OS v1.0 — Findings, Reports, Exit Codes, and Evidence

~~~yaml
document_id: FRAMEWORK-AUTOMATION-REPORTING-EVIDENCE
version: 0.1.0
status: WORKING_DRAFT
exit_code_count: 6
machine_catalog_ref: config/exit-codes.json
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Report Schema

Every command report contains:

~~~yaml
command: stable command name
subject: evaluated root, file, or reference
started_at: UTC timestamp
finished_at: UTC timestamp
result: PASS | PASS_WITH_WARNINGS | FAIL
summary:
  errors: integer
  warnings: integer
  info: integer
  total: integer
findings: ordered finding objects
data: command-specific complete output
approval_claim: NONE
~~~

`result` is derived: errors produce `FAIL`; no errors with warnings produces `PASS_WITH_WARNINGS`; otherwise `PASS`.

# 2. Finding Identity

A finding ID combines the governing rule ID with a deterministic per-report ordinal. Consumers should use `rule_id`, subject, and instance path to compare reruns; the ordinal is report-local. `status` begins `OPEN`. Disposition belongs in the relevant governance/change/risk/exception record, not by editing historical run output.

# 3. Finding Fields

| Field | Requirement |
|---|---|
| `finding_id`, `rule_id`, `severity`, `message`, `status` | always present |
| `subject_ref` | artifact/node/file/object identity when available |
| `instance_path` | schema/record/path location of failure |
| `expected`, `actual` | safe comparison facts; omit sensitive material |
| `remediation` | bounded repair guidance, not an unapproved write |
| `blocking_scope` | exact claim, gate, baseline, or operation affected |
| `authority_required` | role or authority needed for disposition |

# 4. Exit Codes

| Code | Name | Meaning |
|---:|---|---|
| 0 | `PASS` | Command completed with no conformance errors; warnings may be present |
| 1 | `CONFORMANCE_FAILED` | Evaluation completed and at least one deterministic error was found |
| 2 | `USAGE_ERROR` | Invocation grammar or required option is invalid |
| 3 | `CONFIGURATION_ERROR` | Governed data/runtime configuration could not be interpreted safely |
| 4 | `ACTION_BLOCKED` | Requested operation was prevented by safety preconditions |
| 5 | `INTERNAL_ERROR` | Unexpected implementation failure |

Warnings do not change code 0 because callers can inspect `result` or warning count. A CI policy may separately fail on warnings, but that policy must be explicit and versioned.

# 5. Error Channel

Usage, configuration, blocked-action, and internal failures that prevent a normal report are emitted on stderr as a compact structured error in JSON mode or a stable coded message in human mode. The message shall not include secret values or misleading partial-success claims.

# 6. Evidence Package

A reproducible retained run package contains:

1. raw JSON report;
2. invocation options with sensitive values redacted;
3. CLI package name/version/digest;
4. Node version and operating platform;
5. framework lock and catalog digests;
6. project repository/revision/worktree observation;
7. input record identities and digests;
8. CI run/job identity when executed in automation;
9. registration timestamp and evidence owner;
10. subsequent authority disposition reference when one exists.

The report is immutable evidence of what the command observed. The later disposition is linked, not inserted into the historical report.

# 7. Redaction and Sensitivity

- Suspected credential values are never included.
- Archive payloads are not embedded in normal reports; the manifest references content-addressed objects.
- Absolute paths are operational data and may require access classification.
- Error stacks are test/developer evidence, not default end-user output.
- JSON output must remain valid even when messages contain quotes or newlines.

# 8. Freshness

Run evidence is current only for the exact inputs and observation time recorded. Any source, schema, catalog, graph, gate record, baseline member, handoff state, repository revision, or CLI version change invalidates reuse unless a governed equivalence rule proves otherwise.

# 9. Metrics

Reports support counts for executions, result rates, warnings/errors by rule, mean evaluation duration, drift frequency, stale evidence, false-positive disposition, blocked unsafe actions, and profile coverage. Metrics must not reward suppression of findings or treating assisted rules as automated approvals.

# 10. Acceptance

The reporting model passes when human and JSON outputs derive from one report object, all six exit meanings are cataloged and tested, findings preserve rule identity and authority, no secret value is emitted, and evidence consumers can reproduce the exact evaluated subject.
