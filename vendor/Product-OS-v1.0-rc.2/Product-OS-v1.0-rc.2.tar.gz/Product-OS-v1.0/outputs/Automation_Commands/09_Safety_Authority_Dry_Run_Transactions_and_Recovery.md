# Product OS v1.0 — Safety, Authority, Dry Run, Transactions, and Recovery

~~~yaml
document_id: FRAMEWORK-AUTOMATION-SAFETY-AUTHORITY
version: 0.1.0
status: WORKING_DRAFT
write_capable_commands:
  - init
  - migrate
  - archive
default_write_mode: DRY_RUN
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Safety Invariants

1. Read-only commands perform no governed writes.
2. Write-capable commands create nothing without `--apply`.
3. Apply writes only inside the explicit project/target root.
4. Existing intended output blocks the operation.
5. Symlink escape and unsupported filesystem objects block the operation.
6. Canonical source is never deleted, moved, overwritten, or silently cut over.
7. Multi-file output is published only after complete verification.
8. Failure removes temporary output and preserves source.
9. Reports state actual side effects and never infer authorization from `--apply`.
10. External system writes are outside v0.1.0.

# 2. Dry-Run Contract

Dry-run performs every safe read and calculation needed to describe the action: scope resolution, source validation, digest verification, target collision check, transform calculation, planned file list, and execution manifest. It must produce enough detail for review without creating the requested target.

Dry-run success does not reserve the target or guarantee apply success; concurrent filesystem changes may intervene. Apply repeats all preconditions.

# 3. `--apply` Meaning

`--apply` authorizes only the bounded local creation already defined by the command. It does not authorize:

- gate/baseline/handoff approval;
- source deletion or canonical cutover;
- remote repository, Figma, CI, cloud, or deployment writes;
- acceptance of risk, compliance, or N/A;
- expansion beyond the declared project/target paths.

# 4. Transaction Model

The filesystem cannot supply a universal multi-volume transaction. The reference implementation therefore requires a same-parent temporary directory and final rename. All new files use exclusive creation. Verification occurs before the rename. Cross-device publication is not supported.

For single-file creation, exclusive new-file semantics prevent clobber. For catalog/control-plane bootstrap, preflight checks all nine targets before writing; any unexpected collision during write stops the run and reports the partial state for recovery.

# 5. Concurrency

- Multiple read-only commands may run concurrently over immutable inputs.
- A write command requires one logical project mutation lease in CI/orchestration.
- Two apply operations targeting the same path are unsupported; target-exists protection makes one fail closed.
- Read commands during a temporary build continue to see canonical source; after atomic publication they see the new complete staging/archive root.
- Canonical cutover must use a separate lock and governance process.

# 6. Recovery

| Condition | Required response |
|---|---|
| Temporary directory remains after interrupted run | Verify process absence and target identity; remove only the exact temporary directory under authorized cleanup |
| Init partially created files | Inventory the nine planned paths, retain evidence, validate created files, then either complete through reviewed recovery or remove exact new files with authority |
| Staged migration fails verification | Preserve manifest/log evidence, discard only staged root, correct plan/source, rerun dry-run |
| Archive object mismatch | Reject archive, preserve sources, discard exact new archive root, investigate storage/filesystem |
| Existing target | Treat as identity conflict; do not merge; choose a new versioned target or reconcile ownership |

# 7. Authority Matrix

| Action | Automation | Required external authority |
|---|---|---|
| Parse/validate/reconcile | execute and report | none for read; owner disposes findings |
| Generate impact candidates | execute | change authority decides materiality |
| Assess gate record completeness | execute | gate authority decides outcome |
| Assess baseline reproducibility | execute | baseline authority establishes/supersedes |
| Assess handoff structure | execute | sender/recipient acknowledge |
| Create local bootstrap/staging/archive | execute with `--apply` | workflow owner authorizes invocation and downstream use |
| Cut over migrated canonical state | forbidden | repository/data/product authorities |
| Delete source after archive | forbidden | retention/disposition authority |
| Release/deploy/production | forbidden | release/operations authorities |

# 8. Sensitive and Destructive Actions

The reference CLI contains no delete, overwrite, force, remote push, deployment, secret rotation, or database mutation command. A future addition in any of these classes requires a separate threat model, preview, exact-target resolution, authentication/authorization contract, audit evidence, recovery procedure, approval protocol, and negative tests.

# 9. Acceptance

Safety closes only when tests prove dry-run non-creation, apply new-root behavior, target collision blocking, source preservation, digest verification, no cutover, no deletion, no approval claim, and complete failure cleanup for every write-capable command.
