# Product OS v1.0 — Init, Validate, and Lint

~~~yaml
document_id: FRAMEWORK-AUTOMATION-INIT-VALIDATE-LINT
version: 0.1.0
status: WORKING_DRAFT
commands:
  - init
  - validate
  - lint
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. `init`

## 1.1 Purpose

Create the minimum operational Product OS control plane for a project while preserving the 281 logical artifact catalog and avoiding an uncontrolled mandatory file tree.

## 1.2 Inputs

- Required: project ID and project name.
- Optional: P1/P2/P3 profile, repository topology, lifecycle mode, and target path.
- Framework source: pinned schema, artifact, gate, and profile catalogs.

Project ID must be 2–64 characters and use uppercase letters, digits, periods, underscores, or hyphens. Profile must be P1, P2, or P3. The target must remain inside the project root.

## 1.3 Planned Output

Exactly nine files are created on apply:

1. `product-os.yaml`;
2. `.product-os/framework.lock.yaml`;
3. `.product-os/repository-index.yaml`;
4. `.product-os/profile-composition.yaml`;
5. `.product-os/artifact-register.yaml`;
6. `.product-os/state/catalogs/schema-catalog.json`;
7. `.product-os/state/catalogs/artifact-catalog.json`;
8. `.product-os/state/catalogs/gate-catalog.json`;
9. `.product-os/state/catalogs/profile-catalog.json`.

Owners, authority references, applicability, and artifact status begin explicitly unassigned or pending where no project decision exists. The command does not fabricate approvals, standards applicability, artifact content, or evidence.

## 1.4 Side Effects and Failure

Dry-run calculates the complete file list and creates nothing. Apply uses exclusive new-file writes and blocks if any planned file already exists. It records catalog digests in the framework lock. No live repository, remote tool, or branch is created.

## 1.5 Acceptance

The created control plane must pass project validation, all-scope reconciliation, and strict doctor checks. The command may establish bootstrap structure, not completion of Phase 00 or G0 approval.

# 2. `validate`

## 2.1 Purpose

Establish serialization and structural schema conformance for the selected scope.

## 2.2 Framework Checks

- all 21 schema files parse;
- each declares Draft 2020-12 and a unique canonical ID;
- the schema catalog resolves every ID locally;
- all `$ref` targets resolve without network access;
- artifact, gate, profile, and schema catalogs validate;
- all governed examples validate against their declared schema.

The current framework reference set contains 19 schema-bearing catalog/example instances and 485 local schema references.

## 2.3 Project Checks

The command discovers the five control YAML files, validates their declared schema IDs, and validates explicit governed files requested by `--file`. Missing project controls are errors for project scope. Unsupported extensions are rejected rather than guessed.

## 2.4 Claim Boundary

Schema success means the record has the required shape and allowed values. It does not confirm source truth, evidence sufficiency, freshness, approval, compliance, runtime health, or correct native-tool state.

# 3. `lint`

## 3.1 Purpose

Detect repository hygiene risks that schema validation cannot express.

## 3.2 Checks

- inaccessible or unsupported filesystem objects;
- unsafe symbolic links and hidden content when included;
- malformed governed JSON/YAML encountered in scope;
- broken relative Markdown links;
- unfinished authoring markers and empty operational content;
- secret-like assignments and credential patterns without emitting candidate values;
- generated/canonical boundary signals and path anomalies.

Lint is intentionally bounded to the selected root. It does not scan outside the project or retrieve secret values from external stores.

## 3.3 Secret Handling

A potential credential finding contains category, file, and line context only. The report sets `secret_values_emitted: false`. A finding is a review trigger; it does not prove that a value is valid, exposed, or still active.

# 4. Combined Use

~~~text
init dry-run
  → review identity/profile/topology
  → init --apply
  → validate --scope project
  → reconcile --scope all
  → lint
  → doctor --strict
  → authorized Phase 00 work
~~~

# 5. Negative Cases

The commands must reject duplicate JSON/YAML keys, YAML aliases, invalid project IDs, unsupported profiles, target escape, existing output, missing schemas, unresolved references, and secret-like output disclosure. A failed bootstrap leaves no partial published control plane.

# 6. Evidence

CI or a project evidence process may retain JSON reports together with CLI version, framework lock digest, project revision, invocation options, timestamp, and runner identity. Retaining a report does not itself register it as authoritative Product OS evidence; the Source / Evidence Model still governs registration and acceptance.

# 7. Acceptance

This command family passes when dry-run/apply behavior is tested, the new control plane validates and reconciles, all framework examples validate, ambiguity protections are exercised, lint redacts candidate secrets, and no command claims Phase 00 or gate completion.
