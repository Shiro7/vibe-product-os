# Product OS v1.0 — CI, Caching, Concurrency, and Reproducibility

~~~yaml
document_id: FRAMEWORK-AUTOMATION-CI-REPRODUCIBILITY
version: 0.1.0
status: WORKING_DRAFT
network_required_for_validation: false
default_ci_write_policy: READ_ONLY
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. CI Objectives

CI shall detect conformance drift early, produce complete machine evidence, and preserve the same authority boundary as local execution. A green job is evidence of the commands and subjects executed; it is not global project, gate, release, deployment, or production approval.

# 2. Recommended Pipeline

| Stage | Commands | Failure policy |
|---|---|---|
| Runtime preflight | `doctor --strict` | fail on error |
| Structural conformance | `validate --scope all --json` | fail on error |
| Repository hygiene | `lint --json` | fail on error; warning policy declared separately |
| Identity drift | `reconcile --scope all --json` | fail on error |
| Trace assurance | `graph --file <canonical-graph> --json` | fail on error |
| Change review | `impact` for changed governed subjects | publish candidates; authority disposition required |
| Lifecycle boundary | `gate`, `baseline`, or `handoff` on the candidate record | fail structural error; never auto-approve |
| Package tests | package test command | fail on any test failure |

Write-capable commands are disabled in ordinary pull-request CI. A dedicated authorized workflow may run dry-run. Apply requires an isolated job, exact new target, protected environment, artifact retention, and no automatic canonical cutover.

# 3. Required Run Metadata

- workflow, run, job, and attempt identity;
- trigger and actor identity;
- repository canonical identity, commit, branch/ref, and worktree status;
- CLI package/version and integrity source;
- Node/runtime image version;
- framework lock and catalog digests;
- project profile/topology;
- command and complete option map;
- input artifact/evidence digests;
- start/finish timestamps, exit code, and result;
- report artifact location, access class, and retention.

# 4. Cache Policy

Validation may cache immutable framework parsing and schema registry construction. Cache keys must include:

~~~text
CLI version
+ Node major version
+ framework lock digest
+ schema catalog digest
+ every schema file digest
+ command configuration digest
~~~

Project results, graph traversal, gate/baseline/handoff findings, migration plans, archive inventories, and live repository observations are not reused merely because filenames match. A cache hit must preserve the original input identity and cannot suppress current evidence freshness checks.

# 5. Concurrency Policy

- Read-only jobs may run in parallel when their input commit is immutable.
- Jobs producing reports use unique run/attempt output paths.
- One write-capable job per project and target namespace is permitted.
- Apply jobs use new versioned roots and reject pre-existing output.
- Reruns never overwrite prior evidence; attempt identity differentiates them.
- A branch update cancels or marks stale any lifecycle report for the previous commit.

# 6. Reproducibility Tiers

| Tier | Required pins |
|---|---|
| R1 structural | CLI, Node major, framework/schema/catalog digests, input files |
| R2 repository | R1 plus repository commit, topology, profile composition, control-plane digests |
| R3 lifecycle | R2 plus graph, evidence, gate/baseline/handoff member digests and authority record identities |
| R4 operational | R3 plus runner image, access context, native-tool observations, archive/staging manifest, environment evidence |

P1 normally requires R1/R2 for critical-chain checks; P2 requires R2/R3; P3 uses R3/R4 where risk, regulation, or operations demand it. Applicability can raise the tier.

# 7. Change-Aware Execution

Path filtering may select additional targeted commands, but it may not skip the shared control-plane validation needed to interpret the change. Changes to schemas, catalogs, command configuration, profile composition, GOV-008, gate specifications, evidence rules, or authority model invalidate all dependent targeted caches.

# 8. Reports and Artifacts

Every CI command uses JSON output and retains it even on conformance failure. Logs are presentation evidence; the JSON report is the structured result. Sensitive path or repository metadata follows project access policy. Reports are immutable and content-digested before registration.

# 9. Flake and Retry

Local deterministic validation should not be retried automatically to turn red into green. A retry is appropriate only for an identified runner/filesystem availability fault and remains a separate attempt. Conflicting results across identical input digests are an implementation incident requiring investigation.

# 10. Merge and Release Controls

A branch policy may require green structural jobs, but merge approval stays with repository authorities. Release workflows must also verify the candidate baseline, release identity, deployment target, required evidence, and release authority. Product OS command success is an input to those controls, not their replacement.

# 11. Acceptance

CI integration passes when the pipeline records complete input identity, runs read-only checks on immutable commits, invalidates caches on every semantic dependency, preserves all reports, prevents concurrent mutation, and visibly separates command success from gate/merge/release authority.
