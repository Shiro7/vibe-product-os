# Product OS v1.0 — Command Catalog, Invocation, Options, and Profiles

~~~yaml
document_id: FRAMEWORK-AUTOMATION-COMMAND-CATALOG-SPEC
version: 0.1.0
status: WORKING_DRAFT
command_count: 12
machine_catalog_ref: config/command-catalog.json
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Invocation Grammar

~~~text
product-os <command> [global-options] [command-options]
product-os --help
product-os --version
~~~

Long options accept `--key value` or `--key=value`. Boolean options are presence flags. `--no-<flag>` sets a supported flag to false. `--include` and `--file` may be repeated where the command defines list semantics. Undeclared positional arguments are rejected.

# 2. Global Options

| Option | Type | Default | Contract |
|---|---|---|---|
| `--project <path>` | path | current directory | Explicit project root for containment and project-relative references |
| `--framework <path>` | path | sibling `Schemas_Repository_Standard` | Pinned schema/catalog package to inspect |
| `--json` | boolean | false | Emit the complete report as JSON |
| `--quiet` | boolean | false | Suppress normal human report output |
| `--help` | boolean | false | Print usage and command authority boundary |
| `--version` | boolean | false | Print package version |

`--json` changes presentation only. `--project` and `--framework` change the declared subject roots and are therefore recorded inputs, not ambient discovery.

# 3. Specialized Options

| Command | Required options | Optional options |
|---|---|---|
| `init` | `--project-id`, `--project-name` | `--profile P1|P2|P3`, `--topology`, `--lifecycle-mode`, `--target`, `--apply` |
| `validate` | none | `--scope framework|project|files`, repeated `--file` |
| `lint` | none | `--root`, `--include-hidden` |
| `reconcile` | none | `--scope framework|project|all` |
| `graph` | `--file` | none |
| `impact` | `--file`, `--from` | `--direction upstream|downstream|both`, `--max-depth` |
| `gate` | `--file` | `--partial` |
| `baseline` | `--file` | none |
| `handoff` | `--file` | none |
| `migrate` | `--plan`, `--output` | `--apply` |
| `archive` | one or more `--include`, `--output` | `--apply` |
| `doctor` | none | `--strict` |

# 4. Command Composition

Recommended read-only progression:

~~~text
doctor
  → validate
  → lint
  → reconcile
  → graph
  → impact when change scope is being prepared
  → gate / baseline / handoff at lifecycle boundaries
~~~

Recommended mutation progression:

~~~text
dry-run
  → review complete report and planned files
  → obtain the authority needed for the surrounding workflow
  → --apply
  → validate created output
  → reconcile identities and digests
  → register evidence or perform an explicit authorized cutover outside the command
~~~

# 5. Profile Treatment

The 12 commands and 80 rules remain the same across P1/P2/P3. Profile changes physical packaging and evidence depth, not command meaning or authority.

| Profile | Execution treatment |
|---|---|
| P1 — Lean / Rapid | Composite artifacts, targeted validation, required critical-chain trace/gate checks, compact reports |
| P2 — Standard | Full control-plane validation, catalog reconciliation, modular graph/baseline/handoff checks, routine CI |
| P3 — Comprehensive | P2 plus stronger segregation, full evidence integrity, strict diagnostics, retention/archive checks, migration rehearsal, and continuous drift assurance |

`init --profile` records the chosen profile and copies the full canonical catalogs. It does not create inactive artifact files. Activation remains governed by the profile composition and Artifact Register.

# 6. Scope Semantics

- `framework` inspects the shared schema/catalog package and its governed examples.
- `project` inspects the project control plane and activated governed files available to the command.
- `all` performs framework checks first and then project reconciliation.
- `files` validates only explicit file options against their declared schema identities.

Reducing scope reduces the conformance claim. A targeted success must not be presented as whole-project readiness.

# 7. Output Modes

Human mode reports command, subject, result, finding summary, findings, and data. JSON mode is intended for CI, evidence registration, and downstream automation. The report is never truncated. Consumers must key on stable fields and exit codes, not parse presentation text.

# 8. Usage Examples

~~~bash
node bin/product-os.js doctor --project /workspace/product --strict
node bin/product-os.js validate --scope framework --json
node bin/product-os.js graph --project /workspace/product --file governance/GOV-008-trace-graph.json
node bin/product-os.js impact --project /workspace/product --file governance/GOV-008-trace-graph.json --from REQ-014 --direction downstream --max-depth 8
node bin/product-os.js init --project /workspace/new-product --project-id NEW-PRODUCT --project-name "New Product" --profile P2
node bin/product-os.js migrate --project /workspace/product --plan migration-plan.json --output staged-v2 --apply
~~~

The first `init` example remains a dry-run because `--apply` is absent. The migration example creates only `staged-v2`; it does not replace canonical files.

# 9. Catalog Governance

[`config/command-catalog.json`](config/command-catalog.json) is the machine inventory. Name, action class, mutation flag, default mode, and purpose shall match runtime help and handler behavior. A discrepancy is release-blocking. Command aliases are not canonical identities and are not supplied in v0.1.0.

# 10. Acceptance

The catalog specification passes when exactly 12 unique names appear in catalog, dispatcher, help, tests, and documentation; every mutating command defaults to dry-run; and profile guidance never changes artifact IDs, gate meaning, evidence obligations, or approval authority.
