# Product OS v1.0 — Automation / Commands Index

~~~yaml
document_id: FRAMEWORK-AUTOMATION-COMMANDS-INDEX
version: 0.1.0
status: WORKING_DRAFT
completion_state: AUTOMATION_COMMANDS_LIBRARY_COMPLETE
asset_class: PRODUCT_OS_FRAMEWORK_ASSET
project_artifact_count_impact: NONE
logical_artifact_scope: 281
gate_scope_count: 13
command_count: 12
srv_rule_count: 80
deterministic_rule_count: 43
assisted_rule_count: 37
runtime: NODE_JS_18_OR_LATER
external_runtime_dependency_count: 0
test_count: 14
shared_contract: SHARED-AUTOMATION-COMMAND-CONTRACT@0.1.0
predecessor: Schemas & Repository Standard v0.1.0
next_workstream: Product OS v1.0 Final Authority Decision
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-15
~~~

---

# 1. Purpose

This library converts the Product OS static contracts, schemas, catalogs, trace rules, gate rules, evidence model, and repository standard into bounded executable controls. It supplies a dependency-free reference CLI named `product-os`; it does not replace artifact owners, approvers, assurance specialists, or release authorities.

The operating chain is:

~~~text
governed source and project controls
  → deterministic parsing and local schema resolution
  → validation, reconciliation, graph, impact, gate, baseline, and handoff checks
  → structured findings and exit codes
  → human or authorized system decision
  → evidence registration and lifecycle continuation
~~~

# 2. Canonical Commands

| Command | Action class | Default | Canonical responsibility |
|---|---|---|---|
| `init` | bounded mutation | dry-run | Create the nine-file project control plane without expanding all 281 artifacts |
| `validate` | read-only | execute | Parse and schema-validate framework or project records |
| `lint` | read-only | execute | Inspect paths, links, secret-like content, unfinished markers, and repository hygiene |
| `reconcile` | read-only | execute | Compare catalogs, locks, manifests, and project control identities for drift |
| `graph` | read-only | execute | Validate trace endpoints, duplicates, orphans, and graph coverage |
| `impact` | read-only | execute | Traverse bounded upstream/downstream change candidates without deciding materiality |
| `gate` | read-only | execute | Verify a gate record and evidence coverage without approving the gate |
| `baseline` | read-only | execute | Test whether pinned baseline members are reproducible and verified |
| `handoff` | read-only | execute | Validate handoff membership, blockers, obligations, state, and acknowledgement fields |
| `migrate` | staged mutation | dry-run | Apply digest-pinned copy/JSON transforms into a new staging root only |
| `archive` | additive mutation | dry-run | Build a verified content-addressed archive without deleting source files |
| `doctor` | read-only | execute | Diagnose runtime, framework, project controls, filesystem, and Git observations |

# 3. Library Map

| No. | Specification | Responsibility |
|---:|---|---|
| 00 | [Shared Automation and Command Contract](00_Shared_Automation_and_Command_Contract.md) | Universal command invariants, scope, authority, input/output, and conformance |
| 01 | [Runtime Architecture, Trust, and Lifecycle](01_Runtime_Architecture_Trust_and_Command_Lifecycle.md) | Runtime layers, trust boundaries, execution stages, and failure containment |
| 02 | [Command Catalog, Invocation, Options, and Profiles](02_Command_Catalog_Invocation_Options_and_Profiles.md) | CLI grammar, global/command options, P1/P2/P3 treatment, and composition |
| 03 | [Init, Validate, and Lint](03_Init_Validate_and_Lint.md) | Bootstrap, schema conformance, and repository hygiene contracts |
| 04 | [Reconcile, Graph, and Impact](04_Reconcile_Graph_and_Impact.md) | Drift comparison, graph health, bounded traversal, and authority limits |
| 05 | [Gate, Baseline, and Handoff](05_Gate_Baseline_and_Handoff.md) | Lifecycle readiness checks without delegated approval |
| 06 | [Migrate, Archive, and Doctor](06_Migrate_Archive_and_Doctor.md) | Staging, additive preservation, diagnostics, and recovery boundaries |
| 07 | [SRV Rule Engine and Coverage](07_SRV_Rule_Engine_and_Coverage.md) | Mapping all SRV-001..080 to deterministic or assisted execution |
| 08 | [Findings, Reports, Exit Codes, and Evidence](08_Findings_Reports_Exit_Codes_and_Evidence.md) | Stable machine output, severities, results, evidence, and redaction |
| 09 | [Safety, Authority, Dry Run, Transactions, and Recovery](09_Safety_Authority_Dry_Run_Transactions_and_Recovery.md) | No-overwrite design, scope containment, atomicity, rollback, and human authority |
| 10 | [CI, Caching, Concurrency, and Reproducibility](10_CI_Caching_Concurrency_and_Reproducibility.md) | Pipeline use, cache keys, concurrency policy, hermeticity, and run evidence |
| 11 | [Versioning, Distribution, Installation, Metrics, and Anti-Patterns](11_Versioning_Distribution_Installation_Metrics_and_Anti_Patterns.md) | Release compatibility, installation, service metrics, and prohibited behaviors |
| Closure | [Coverage and Closure Review](Automation_Commands_Coverage_and_Closure_Review.md) | Implementation inventory, test evidence, authority audit, gaps, and closure status |

# 4. Executable Package

- Entry point: [`bin/product-os.js`](bin/product-os.js)
- Command dispatch: [`lib/command-runner.js`](lib/command-runner.js)
- Twelve handlers: [`lib/commands/`](lib/commands/)
- Governed command catalog: [`config/command-catalog.json`](config/command-catalog.json)
- SRV coverage catalog: [`config/rule-catalog.json`](config/rule-catalog.json)
- Exit-code catalog: [`config/exit-codes.json`](config/exit-codes.json)
- Integration tests: [`test/run-tests.js`](test/run-tests.js)

The package requires Node.js 18 or later and declares no third-party runtime dependency. Local schema resolution is mandatory; governed validation never fetches remote references.

# 5. Non-Negotiable Authority Boundary

No command may:

1. approve or reject a gate on behalf of its accountable authority;
2. accept residual risk or waive a control;
3. approve `NOT_APPLICABLE` or decide that evidence is unnecessary;
4. declare legal, regulatory, security, accessibility, or other compliance;
5. authorize release, deployment, production entry, rollback, or restoration;
6. decide change materiality or certify `NO_IMPACT`;
7. silently rewrite, delete, move, or overwrite canonical project state.

Automation reports conformance facts and bounded candidates. Authority remains explicit in governed records.

# 6. Mutation Model

`init`, `migrate`, and `archive` are dry-run by default and require `--apply`. Their apply mode remains restricted:

- `init` creates only absent files in an empty or compatible target and never overwrites.
- `migrate` writes a complete new staging directory, verifies inputs by SHA-256, and performs no cutover.
- `archive` creates a new content-addressed archive, verifies copied objects, and preserves all sources.

# 7. Release State

The implementation and its fourteen integration tests are technically passing at Working Draft level. The [Pilot](../Pilot/Pilot_Index.md) exercised P1/P2/P3, green and negative cases, authority handoff, migration staging, and archive evidence with 35/35 cases and 20/20 acceptance criteria. The library is not Product OS authority-approved or baselined. The Product OS v1.0 release candidate is technically finalized; the next action is the Product OS authority decision.

# 8. Final Principle

> **Automate what can be proved deterministically, expose what needs judgment, and never convert a successful command into authority it does not possess.**
