# Product OS v1.0 — Runtime Architecture, Trust, and Command Lifecycle

~~~yaml
document_id: FRAMEWORK-AUTOMATION-RUNTIME-ARCHITECTURE
version: 0.1.0
status: WORKING_DRAFT
runtime: NODE_JS_18_OR_LATER
network_dependency: NONE
third_party_runtime_dependencies: NONE
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Runtime Architecture

~~~text
bin/product-os.js
  → argument parser
  → command registry and project context
  → restricted JSON/YAML serialization
  → local schema registry and validator
  → command handler
  → findings/report model
  → human or JSON emitter
  → governed exit code
~~~

Supporting services provide path containment, safe filesystem writes, hashing, graph indexing/traversal, and bounded JSON migration transforms. Command handlers do not bypass these services for governed I/O.

# 2. Trust Zones

| Zone | Examples | Trust treatment |
|---|---|---|
| Pinned framework | schemas, catalogs, contracts | Verify local identity, version, references, and lock digests |
| Project control plane | manifest, framework lock, repository index, profile composition, artifact register | Parse strictly; validate; reconcile cross-file identity |
| Project artifacts | lifecycle, governance, evidence, mappings | Treat as untrusted until schema, reference, and authority checks pass |
| Native tools | Figma, GitHub, CI, cloud, test systems | Use registered identity and observed evidence; no implied synchronization |
| CLI process | code, runtime, working directory | Record version/runtime and bound roots; least privilege |
| Output/staging/archive | reports and created files | New paths only, verified content, explicit ownership and retention |

# 3. Command Lifecycle

Every invocation follows these stages:

1. **Parse:** recognize command, options, and global flags; reject unknown positional data.
2. **Bind:** resolve project and framework roots and load command metadata.
3. **Preflight:** verify required options, containment, target absence, runtime, and required control files.
4. **Load:** parse governed inputs with duplicate-key and restricted-YAML protection.
5. **Evaluate:** apply schema, catalog, graph, lifecycle, or operational rules.
6. **Plan:** calculate intended writes and digests without changing state.
7. **Apply:** only for an explicitly authorized `--apply` invocation of a write-capable command.
8. **Verify:** re-read or hash created output before publishing its directory.
9. **Report:** emit all findings, data, result, timestamps, and no-approval claim.
10. **Hand back:** return a governed exit code to the caller.

# 4. Parser Boundary

JSON is parsed by a recursive reader that rejects duplicate object keys rather than accepting last-write-wins behavior. Restricted YAML allows deterministic JSON-model scalars, arrays, and mappings while rejecting:

- tabs and non-two-space indentation;
- multi-document markers and directives;
- custom tags;
- anchors, aliases, and merge keys;
- duplicate mapping keys;
- parser-dependent `yes`, `no`, `on`, and `off` booleans;
- executable or implementation-specific object construction.

This subset makes authoring portable and prevents two validators from interpreting the same governed record differently.

# 5. Schema Resolution

The runtime loads all schema catalog entries, verifies unique canonical `$id` values and Draft 2020-12 declarations, maps canonical IDs to local files, and resolves `$ref` only through that registry. Network fallback is not implemented. A missing, duplicate, external, or unresolved reference is a configuration or conformance failure.

The dependency-free validator implements the Product OS keyword subset used by the 21 schemas, including types, required properties, closed objects, arrays, numeric/string constraints, formats, enumerations, constants, composition, conditionals, and local references.

# 6. Filesystem Boundary

All governed targets are resolved relative to an explicit root and checked for containment. Symlink traversal is blocked for write and archive scope. New file writes use exclusive creation. Multi-file mutation uses:

~~~text
validate source and target absence
  → create temporary sibling directory
  → write/copy exclusively
  → verify each digest or parsed result
  → write execution manifest
  → atomic directory rename
~~~

If any step fails, the temporary directory is removed and the canonical source remains unchanged.

# 7. Failure Classes

| Class | Example | Exit |
|---|---|---:|
| Conformance | schema error, missing graph endpoint | 1 |
| Usage | missing `--file`, invalid direction | 2 |
| Configuration | malformed YAML, unresolved schema registry | 3 |
| Action blocked | target exists, digest mismatch, symlink in archive | 4 |
| Internal | unexpected implementation fault | 5 |

A conformance failure is expected domain output. A configuration or action-blocked failure indicates that evaluation or mutation could not safely proceed. Internal errors disclose the message but not an approval claim.

# 8. Runtime Reproducibility

Reproducible execution requires the same CLI version, Node major compatibility, pinned framework lock, schema/catalog bytes, command options, project revision, and governed inputs. Timestamps, absolute checkout paths, filesystem modification times, and live Git observations are explicitly non-reproducible observations and must not be confused with semantic result drift.

# 9. Extensibility Rule

A new command must be added to the machine command catalog, dispatcher, help output, shared contract coverage, specialized specification, test suite, rule mapping, CI matrix, and closure audit. Runtime plugins or arbitrary code loaded from project YAML are prohibited. Extension occurs through reviewed package releases, schema versions, or bounded declarative migration operations.

# 10. Acceptance

The runtime architecture passes when all handlers execute through one context/report boundary, all schemas resolve locally, parsing rejects ambiguity, write commands prove dry-run and new-root behavior, all expected failure classes return stable exits, and tests cover both authority preservation and side-effect containment.
