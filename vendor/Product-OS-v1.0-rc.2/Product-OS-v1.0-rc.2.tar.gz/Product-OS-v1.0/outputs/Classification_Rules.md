# Product OS v1.0 — Classification Rules

~~~yaml
document_id: FRAMEWORK-CLASSIFICATION-RULES
version: 0.1.0
status: WORKING_DRAFT
completion_state: CLASSIFICATION_CONTRACT_COMPLETE
asset_class: PRODUCT_OS_FRAMEWORK_ASSET
project_artifact_count_impact: NONE
logical_artifact_scope: 281
source_catalog: Product OS Master Artifact Catalog v0.2
contract_library: Core Artifact Contracts through W14 technical closure
predecessor: Core Artifact Contracts Closure Review
next_workstream: Product OS v1.0 Final Authority Decision
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification defines the canonical classification system used by Product OS to decide:

1. what kind of thing has entered the system;
2. whether it belongs to the framework layer, project layer, object layer, source layer, evidence layer, or tool-representation layer;
3. which primary data class owns an artifact;
4. what activates the artifact;
5. whether the artifact is applicable to an exact project scope;
6. whether its contract must be independent, may live as a family section, or is sufficiently governed by the Shared Core Contract;
7. which delivery profile applies globally and by domain;
8. which product-state, risk, engagement, information-state, confidence, and lifecycle classifications apply;
9. who may make, approve, challenge, or reopen each classification;
10. how a classification affects gates, traceability, change impact, verification, evidence, and downstream work.

The intended outcome is deterministic routing. Two qualified reviewers using the same verified inputs should reach the same classification or identify the same explicit unresolved decision.

Classification is not labeling for reporting convenience. It controls obligations, ownership, review depth, evidence, packaging, escalation, and lifecycle routing.

---

# 2. Authority and Source Precedence

When classification sources conflict, use this order:

~~~text
Product OS Architecture and GOV-001 Product Constitution
→ Approved Product OS framework standards
→ Approved and baselined Classification Rules version
→ Current Phase 00–11 Methodology Specifications
→ Master Lifecycle Index
→ Master Artifact Catalog
→ Shared Core Artifact Contract Standard
→ Approved specialized Core Artifact Contracts
→ Project-specific approved decisions and GOV-009 applicability
→ Profile packaging and domain overrides
→ Tool-specific representations
~~~

This Working Draft consolidates and technically resolves the proposed cross-cutting classification semantics. It becomes the authoritative classification layer only after Product OS approval and baseline. Until then, any conflict with an approved higher source is a review issue rather than permission to override that source.

An approved Classification Rules version does not override a stronger constitutional, legal, regulatory, contractual, safety, security, privacy, accessibility, or evidence obligation.

The Project Blueprint System is a contributing packaging and project-instance source. Product OS remains authoritative for current phase IDs, artifact IDs, gate ownership, status semantics, and P1/P2/P3 terminology.

## 2.1 Normative source register

| Source | Classification use |
|---|---|
| [Master Artifact Catalog](Product_OS_Master_Artifact_Catalog.md) | Canonical 281 artifact IDs, data classes, activation classes, profile patterns, and phase ownership |
| [Shared Core Artifact Contract Standard](Core_Artifact_Contracts/00_Shared_Core_Artifact_Contract_Standard.md) | Inherited metadata, information states, applicability, statuses, sources, evidence, validation, and change obligations |
| [Core Artifact Contract Coverage Map](Core_Artifact_Contracts/Core_Artifact_Contract_Coverage_Map.md) | Current contract modes, W0–W14 dispositions, profile treatment, and 281-row reconciliation source |
| [Core Artifact Contracts Closure Review](Core_Artifact_Contracts/Core_Artifact_Contracts_Closure_Review.md) | W14 technical closure evidence and approval boundary |
| [Master Lifecycle Index](Master_Lifecycle_Index.md) | Lifecycle routes, profiles, domain override, phase and baseline chain |
| [Phase 00 — Initialization and Intake](Phase_00_Initialization_and_Intake_v1.1.md) | S0–S6, P1–P3 preliminary routing, R1–R4, E1–E6, confidence, and recovery override |
| [INIT-005 Contract](Core_Artifact_Contracts/phase-families/phase-00/05_INIT-005_Preliminary_Classification_Record.md) | Operational preliminary classification record and G0 boundary |
| [Phase 04 — Requirements Engineering](Phase_04_Requirements_Engineering.md) | Information promotion, SHALL / SHALL NOT normative language, and MUST / SHOULD / COULD / WONT_NOW priority separation |
| [GOV-009 Semantic Specification](GOV_009_Standards_and_Compliance_Applicability_Matrix.md) | Universal standard, conditional profile, capability module, applicability, propagation, and reopen ownership |
| [Gate Map](Gate_Map.md) | Lifecycle gate sequence, decision questions, pair boundaries, and phase-level gate vocabulary |
| [Gate Specifications](Gate_Specifications/Gate_Specifications_Index.md) | Complete Working Draft operational gate contracts, authority, evidence, outcomes, conditions, validity, and re-entry semantics |
| [Cross-Phase Traceability](Cross_Phase_Traceability.md) | Trace confidence, canonical ownership, relationship, and propagation boundaries |
| [Traceability Graph](Traceability_Graph/Traceability_Graph_Index.md) | Complete Working Draft node identity, edge vocabulary, domain/range/cardinality, temporal, coverage, gap, traversal, and view contracts |
| [Change Impact Rules](Change_Impact_Rules/Change_Impact_Rules_Index.md) | Complete Working Draft materiality, affected-object disposition, no-impact authority, remediation, proportional review, gate/baseline reopen, acknowledgement, and closure contracts |
| [Source / Evidence Model](Source_Evidence_Model/Source_Evidence_Model_Index.md) | Complete Working Draft source authority/reliability, claim, evidence, fitness/sufficiency/admissibility, provenance/custody/integrity, access/retention, and exchange contracts |
| [AI Operating Specification](AI_Operating_Specification/AI_Operating_Specification_Index.md) | Complete Working Draft AI identity, roles/modes, instructions/context, authority, six action classes, seven operating controls, tool execution, evidence, safety, multi-agent, monitoring, evaluation, and incident contracts |
| [Spec Kit + Figma + GitHub Mapping](Spec_Kit_Figma_GitHub_Mapping/Spec_Kit_Figma_GitHub_Mapping_Index.md) | Complete Working Draft named-tool roles, ownership, identity/versioning, 281-artifact dispositions, synchronization, cross-tool traceability, access, migration, exit, and validation contracts |

## 2.2 Project Blueprint contribution boundary

The Project Blueprint System contributes the stable macro-structure, L1/L2/L3 concept, framework versus project-instance separation, natural-input flow, physical packaging, composite-file behavior, domain overrides, and operational N/A semantics.

Those contributions become Product OS rules only when reconciled here or in another authoritative Product OS specification. Unreconciled external proposals remain sources for review, not instructions and not automatic baseline changes.

---

# 3. Scope

These rules apply to:

- all 281 logical project artifacts in the Master Artifact Catalog;
- future artifact-catalog change proposals;
- every activated artifact instance;
- nested governed objects inside artifacts;
- framework assets;
- natural input and external sources;
- evidence items and verification results;
- tool-specific views and synchronized representations;
- project-state, profile, risk, and engagement classification;
- standards and compliance applicability routing;
- AI-assisted classification;
- reclassification after change, incident, discovery, release, or operational evidence.

This specification is a Product OS framework asset. It is not added to the 281 project-artifact count and does not receive a GOV, INIT, DISC, BUS, PROD, REQ, EXP, DES, ARC, ENG, IMP, VRL, or OPS artifact ID.

---

# 4. Non-Scope and Workstream Boundaries

This specification does not define:

- operational gate outcomes, check contracts, authority, conditions, evidence, validity, and re-entry; these are defined by [Gate Specifications](Gate_Specifications/Gate_Specifications_Index.md);
- the complete edge vocabulary and graph cardinality; these are defined by [Traceability Graph](Traceability_Graph/Traceability_Graph_Index.md);
- final materiality, impact disposition, remediation, acknowledgement, no-impact authority, reopen, and closure rules; these are defined by [Change Impact Rules](Change_Impact_Rules/Change_Impact_Rules_Index.md);
- full source reliability, evidence integrity, custody, retention, and admissibility rules; these are defined by [Source / Evidence Model](Source_Evidence_Model/Source_Evidence_Model_Index.md);
- the complete AI execution, delegation, approval, and safety model; these are defined by [AI Operating Specification](AI_Operating_Specification/AI_Operating_Specification_Index.md);
- tool ownership for Spec Kit, Figma, and GitHub; these are defined by [Spec Kit + Figma + GitHub Mapping](Spec_Kit_Figma_GitHub_Mapping/Spec_Kit_Figma_GitHub_Mapping_Index.md), while external CI, test, deployment, cloud, release-provider, and observability mappings remain later tool mappings;
- physical JSON, YAML, database, or API schemas; those belong to Schemas & Repository Standard;
- command behavior and automated enforcement; those belong to Automation / Commands;
- pilot activation decisions; those belong to Pilot.

This file defines the classifications those later workstreams must implement.

---

# 5. Classification Principles

## 5.1 Separate dimensions

The following dimensions are independent and must not substitute for one another:

~~~text
Operating Layer
Primary Data Class
Activation Class
Applicability
Contract Mode
Contract Authoring Priority
Contract Implementation Wave
Contract Coverage Status
Delivery Profile
Domain Profile
Product State
Lifecycle Mode
Risk Class
Engagement Scope
Information State
Confidence
Artifact Status
Registry Lifecycle Status
Decision Workflow Status
Decision Lifecycle Disposition
Verification Status
Change-Impact Status
Trace Status
Trace Confidence
Approval Status
Gate Outcome
~~~

For example:

- CORE is an activation class, not proof of applicability completion;
- SOT is a data class, not proof that the artifact is approved;
- P1 is a packaging and assurance profile, not permission to remove obligations;
- COMPLETE is an artifact production state, not VERIFIED;
- APPROVED is a decision state, not evidence that implementation exists;
- NOT_APPLICABLE is a governed decision, not absence;
- SHARED_ONLY is a contract-mode decision, not omission of the logical artifact.

## 5.2 One primary classification per dimension

Every artifact has one primary data class, one activation class, and one target contract mode.

An artifact may have secondary characteristics, but secondary characteristics do not create multiple primary owners. If two primary responsibilities have independent owners, lifecycles, approvals, or change rates, split the logical artifact or register a catalog-change proposal.

## 5.3 Logical identity before physical packaging

Classification applies first to logical obligations and governed objects. Files, folders, pages, database tables, Figma nodes, tickets, and dashboards are representations.

Combining objects physically does not merge their IDs, applicability, owners, status, validation, or change impact.

## 5.4 Exact scope

Every classification is bound to exact scope:

- project or product;
- phase or lifecycle event;
- capability, domain, platform, channel, market, language, data class, user group, journey, release, environment, or operational service where relevant;
- version or evidence period;
- owner and decision authority.

An unscoped classification is incomplete.

## 5.5 Evidence before confidence

Classification confidence reflects source clarity, authority, consistency, corroboration, and recency. It does not reflect how strongly a human or AI feels about the answer.

Missing evidence cannot lower risk, remove an obligation, prove N/A, approve a decision, or create verification.

## 5.6 Safe uncertainty

When classification cannot be resolved safely:

- preserve the unknown;
- use PENDING where applicability is unresolved;
- record the missing evidence;
- identify the owner and due event;
- apply the safer temporary route;
- block the affected gate when the unknown can materially change the decision.

## 5.7 Lower layers may strengthen, never silently weaken

A project, domain, artifact contract, specialist review, customer obligation, or standard may increase review and evidence depth. It cannot silently reduce an upper-layer obligation.

---

# 6. Classification Record Identity

Every material classification decision has a stable record identity even when physically embedded inside another artifact.

Minimum identity:

~~~yaml
classification_id:
classification_dimension:
subject_type:
subject_id:
scope:
value:
status:
classified_at:
classified_by:
decision_owner:
decision_authority:
source_refs: []
rationale: []
confidence:
review_due:
supersedes:
superseded_by:
reopen_conditions: []
~~~

Repeated classification values for different scopes require separate records or separately addressable entries.

---

# 7. Operating-Layer Classification

Classify the subject into one operating layer before applying artifact rules.

| Code | Operating layer | Definition | Identity rule |
|---|---|---|---|
| FRAMEWORK_ASSET | Product OS framework asset | Methodology, catalog, contracts, classification, gate, schema, repository, automation, or operating specification used to govern projects | Framework document ID; never consumes a project artifact ID |
| PROJECT_ARTIFACT | Cataloged project artifact | One of the 281 logical artifacts activated and instantiated for a project | Canonical artifact ID plus project and version identity |
| PROJECT_OBJECT | Governed nested object | Requirement, capability, decision, assumption, risk, journey, screen, component, architecture decision, work item, test result, incident, metric, or other typed object owned by a project artifact | Stable object ID and owner artifact |
| EXTERNAL_SOURCE | Input from outside the canonical Product OS owner | Document, chat, contract, Figma file, repository revision, API contract, ticket, dataset, log source, standard, or stakeholder statement | Stable source ID and exact received identity |
| EVIDENCE_ITEM | Claim-bound proof | Test result, inspection, approval, log extract, scan, measurement, or other item used to support a defined claim | Evidence ID, claim link, target, method, time, integrity context |
| TOOL_REPRESENTATION | Physical or synchronized view | File, page, board, node, issue, table, dashboard, generated matrix, or export representing canonical data | Tool identity plus canonical subject reference |

Decision order:

1. If the subject governs Product OS itself, classify FRAMEWORK_ASSET.
2. If it is a cataloged project obligation, classify PROJECT_ARTIFACT.
3. If it is a typed child owned by an artifact, classify PROJECT_OBJECT.
4. If it is received input and not canonical project meaning, classify EXTERNAL_SOURCE.
5. If its primary role is proving a defined claim, classify EVIDENCE_ITEM.
6. If it only presents or synchronizes another canonical object, classify TOOL_REPRESENTATION.

A source can later support a fact or requirement without ceasing to be a source. An evidence item can also originate externally, but its evidence identity remains separate from its source identity.

---

# 8. Primary Data Classes

The Master Artifact Catalog uses exactly seven primary data classes.

| Code | Data class | Primary responsibility |
|---|---|---|
| CTL | Control | Governs identity, status, applicability, ownership, decision, risk, exception, change, or cross-object control |
| SOT | Source of Truth | Owns canonical integrated project meaning or an operating baseline |
| REG | Register / Catalog | Owns a governed collection of typed records |
| MOD | Model / Specification | Defines a structured model, map, design, specification, or plan |
| DRV | Derived View | Computes or synchronizes coverage, traceability, readiness, impact, health, or index views from canonical sources |
| EVD | Evidence / Validation | Owns validation, verification, review, acceptance, evidence, or decision-proof results |
| HND | Handoff | Owns a versioned downstream transfer and acceptance boundary |

Data class describes primary responsibility. It does not determine production status, approval, truthfulness, quality, or applicability.

---

# 9. Primary Data-Class Decision Tree

Evaluate in this order:

## 9.1 HND test

Classify HND when the primary purpose is to transfer a defined, versioned scope from one accountable lifecycle owner to another and to record:

- transferred identities and versions;
- accepted and excluded scope;
- unresolved conditions and risks;
- evidence and readiness;
- receiving owner and acknowledgment;
- change and rejection route.

If the artifact merely lists outputs without an acceptance boundary, it is not HND.

## 9.2 DRV test

Classify DRV when:

- every material value is computed, aggregated, queried, or synchronized from canonical objects;
- manual changes must occur in upstream owners;
- freshness and lineage are required;
- the view does not approve or create canonical meaning.

A baseline index may be EVD rather than DRV when its primary purpose is to prove the exact accepted baseline composition and decision scope.

## 9.3 EVD test

Classify EVD when the primary purpose is to record:

- method;
- exact target and version;
- criteria;
- result;
- evidence;
- reviewer or decision authority;
- defect, exception, waiver, or disposition;
- validation or acceptance outcome.

An artifact does not become EVD merely because it links evidence.

## 9.4 CTL test

Classify CTL when the artifact controls multiple objects or lifecycles by owning:

- identity and registry status;
- applicability;
- decision or authority state;
- risk, assumption, question, exception, or change state;
- cross-phase governance.

A domain model that contains status fields is not automatically CTL.

## 9.5 SOT test

Classify SOT when the artifact owns the canonical integrated meaning consumed across downstream work or establishes a baseline that other artifacts must reference.

SOT classification does not mean the current version is approved. Approval, baseline, artifact status, and registry lifecycle remain separate.

## 9.6 REG test

Classify REG when the primary purpose is maintaining a governed collection of repeated typed records, each with stable identity and lifecycle.

If the collection is generated entirely from other canonical sources, classify DRV.

## 9.7 MOD test

Classify MOD when the primary purpose is defining a structured model, map, specification, plan, taxonomy, flow, state model, interface model, design model, architecture model, or execution model that is not better classified by the preceding tests.

## 9.8 Tie-breaker

When two classes remain plausible:

1. identify the artifact’s unique authoritative statement;
2. identify which change must be made in this artifact rather than elsewhere;
3. identify its approval and lifecycle owner;
4. identify its primary downstream consumer;
5. choose the class matching that primary responsibility.

If two independent authoritative statements remain, raise a catalog split or boundary-review proposal. Do not assign two primary data classes.

---

# 10. Data-Class Anti-Substitution Rules

- A REG is not a DRV merely because it can be displayed as a table.
- A MOD is not SOT merely because downstream work references it.
- A CTL is not EVD merely because approval evidence is attached.
- An EVD is not HND merely because it is sent downstream.
- An HND is not a generic report.
- A DRV cannot become canonical through manual editing.
- A tool dashboard is not automatically a DRV project artifact; it may be only a TOOL_REPRESENTATION.
- A file is not a data class.

---

# 11. Activation Classes

Every cataloged project artifact has one default activation class.

| Code | Activation class | Activation rule |
|---|---|---|
| CORE | Core | Active whenever its owning phase and affected scope are active |
| COND | Conditional | Active only when one or more governed triggers apply |
| DRVD | Derived | Created when governed upstream objects and an authorized consumer exist |
| EVENT | Event-driven | Activated by a defined change, release, incident, migration, exception, experiment, or lifecycle event |
| RECUR | Recurring | Maintained for an active operational scope on a defined cadence or review event |

Activation class is catalog metadata. Applicability is a scoped project decision.

---

# 12. Activation Decision Rules

## 12.1 CORE

CORE means the logical obligation must be satisfied when the owning phase and scope are active.

CORE does not mean:

- one dedicated file is mandatory;
- all fields are known at first creation;
- every project uses P3 depth;
- the artifact is automatically complete;
- pre-entry phases must create empty placeholder files.

## 12.2 COND

COND requires:

- explicit activation triggers;
- trigger sources;
- exact affected scope;
- applicability decision;
- decision authority;
- downstream implications;
- reopen conditions.

Unknown trigger state results in PENDING, not silent N/A.

## 12.3 DRVD

DRVD activates only when:

- canonical upstream objects exist;
- a defined consumer or control purpose exists;
- lineage can be maintained;
- freshness can be measured.

No empty derived artifact is created solely to satisfy a file tree.

## 12.4 EVENT

EVENT requires a named event type, event identity, occurrence time or decision, owner, affected scope, and closure route.

An event artifact does not remain permanently active after closure unless it also has a governed recurring or register role.

## 12.5 RECUR

RECUR requires:

- live scope;
- cadence or event-based review rule;
- owner;
- freshness threshold;
- missed-review behavior;
- escalation and retirement conditions.

Recurring does not mean continuously rewritten. It means continuously governed.

---

# 13. Artifact Applicability

Allowed project-artifact applicability values are:

~~~text
APPLICABLE
NOT_APPLICABLE
PENDING
~~~

## 13.1 APPLICABLE

Use APPLICABLE when verified scope and activation conditions require the logical obligation.

The record identifies:

- exact scope;
- trigger or CORE phase condition;
- owner;
- required contract;
- profile and domain override;
- downstream obligations;
- review or expiry.

## 13.2 NOT_APPLICABLE

Use NOT_APPLICABLE only when an authorized decision establishes that the obligation does not apply to an exact scope.

Minimum record:

~~~yaml
subject_id:
scope:
applicability: NOT_APPLICABLE
reason:
decision_owner:
decision_authority:
decision_status:
approved_by: []
decision_date:
source_refs: []
evidence_refs: []
downstream_implications: []
reopen_conditions: []
review_due:
~~~

Absence, lack of knowledge, lack of time, lack of skill, a small team, P1, or “not requested by the client” are not valid N/A reasons.

## 13.3 PENDING

Use PENDING when applicability cannot yet be resolved.

Minimum record:

~~~yaml
subject_id:
scope:
applicability: PENDING
missing_evidence: []
blocking_questions: []
owner:
decision_authority:
safe_interim_treatment:
affected_artifacts: []
affected_gate:
due_event:
escalation_condition:
~~~

PENDING blocks a gate when either possible answer could materially change scope, control, design, architecture, implementation, verification, release, or operation.

## 13.4 Partial scope

PARTIALLY_APPLICABLE is not an allowed top-level status.

Partition the scope:

~~~text
Web application → APPLICABLE
Internal command-line utility → NOT_APPLICABLE
Generated PDF output → PENDING
~~~

Each partition has its own rationale, authority, evidence, and reopen condition.

## 13.5 Conditional requirements

A requirement may contain a governed condition or activation trigger. This does not add CONDITIONAL to the top-level artifact applicability vocabulary.

Example:

~~~text
When offline operation is enabled for a field user, the system SHALL identify locally stored records that have not synchronized.
~~~

The requirement remains a requirement. Its condition defines when the behavior applies.

---

# 14. Standards and Compliance Source Classification

GOV-009 owns project-specific standard and profile applicability.

Allowed source classifications:

~~~text
UNIVERSAL_STANDARD
CONDITIONAL_PROFILE
CAPABILITY_MODULE
~~~

## 14.1 UNIVERSAL_STANDARD

A governing standard that Product OS or GOV-001 applies by default at a defined organizational, product, or project level.

## 14.2 CONDITIONAL_PROFILE

A legal, regulatory, contractual, industry, market, platform, customer, or risk profile activated by verified triggers.

## 14.3 CAPABILITY_MODULE

A product or solution capability grouping such as payments, offline synchronization, multi-tenancy, generated documents, AI-assisted functionality, or messaging.

A capability module is not automatically a compliance profile. It may trigger one or more universal or conditional obligations.

Classification Rules identifies the source class. GOV-009 owns applicability, approval, propagation, and reopen truth.

---

# 15. Contract Modes

Allowed target contract modes are:

~~~text
INDEPENDENT
FAMILY_SECTION
SHARED_ONLY
~~~

Contract mode determines where specialized contract obligations are governed. It does not merge logical artifact identities.

---

# 16. INDEPENDENT Contract Rule

Use INDEPENDENT when one or more of these are true:

- the artifact owns unique source-of-truth meaning;
- it owns cross-object control or decision authority;
- it is a versioned phase or gate handoff;
- it owns a gate-critical validation, acceptance, baseline, release, incident, or operational decision;
- it requires a separate lifecycle, owner, approval, change cadence, or retention rule;
- it has high-assurance, segregation-of-duty, regulatory, contractual, or audit needs;
- failure to distinguish its contract could conceal material incompleteness or unsafe change;
- its validation and reopen rules cannot be expressed safely by the family contract.

Default class guidance:

- CTL, SOT, and HND default to INDEPENDENT;
- EVD that owns material validation, acceptance, release, incident, post-release, or baseline meaning defaults to INDEPENDENT.

A default can be overridden only through the governed override rule in Section 19.

---

# 17. FAMILY_SECTION Contract Rule

Use FAMILY_SECTION when:

- the logical artifact has unique purpose, inputs, outputs, validation, and reopen behavior;
- its contract can share physical packaging with related artifacts;
- phase-family inheritance provides the common semantics;
- logical identity, applicability, ownership, validation, status, and traceability remain independently addressable.

REG, MOD, and domain-specific implementation or evidence records normally use FAMILY_SECTION unless independent authority or assurance requires escalation.

---

# 18. SHARED_ONLY Contract Rule

Use SHARED_ONLY only when a documented sufficiency review confirms:

- the Shared Core Artifact Contract covers all material semantics;
- no unique authority, approval, source-of-truth, handoff, validation, or lifecycle obligation is hidden;
- the artifact is normally derived, routine, index-like, matrix-like, summary-like, or checklist-like;
- its canonical upstream sources are explicit;
- freshness, lineage, profile behavior, change impact, and reopen conditions are covered;
- a future escalation trigger is recorded.

SHARED_ONLY is an active contract decision. It is not missing work.

Any discovered unique authority, material risk, pilot failure, tool ambiguity, or repeated implementation inconsistency reopens the mode and normally escalates it to FAMILY_SECTION or INDEPENDENT.

---

# 19. Contract-Mode Override Rule

An override requires:

~~~yaml
artifact_id:
current_mode:
proposed_mode:
rationale:
unique_semantics:
risk_if_wrong:
affected_profiles: []
affected_domains: []
dependencies: []
gate_impact: []
validation_impact: []
change_impact:
migration:
reviewers: []
approving_authority:
decision_status:
effective_version:
~~~

Rules:

1. Uncertainty about unique authority escalates rather than de-escalates.
2. INDEPENDENT to FAMILY_SECTION or SHARED_ONLY requires explicit proof of semantic sufficiency.
3. SHARED_ONLY to stronger mode may occur without changing the artifact ID.
4. A mode change updates the Coverage Map and Contract Index.
5. A mode change does not automatically change data class or activation class.

## 19.1 Contract-authoring priority

Coverage Map authoring priorities are framework-library planning classifications:

| Value | Meaning |
|---|---|
| P0_DRAFTED | Historical W0 governance-foundation and Critical Chain drafts |
| P0_GOVERNANCE | Governance Family contracts required to establish cross-phase control |
| P0_GATE_CRITICAL | Source truth, control, handoff, validation, baseline, release, incident, or decision contracts with gate-critical meaning |
| P1_CORE_SEMANTIC | Core models, registers, results, reports, and implementation records requiring specialized family semantics |
| P2_CONDITIONAL_EVENT | Conditional or event-driven specialized family semantics |
| P3_DERIVED_SHARED | Derived views and routine indexes or summaries governed by Shared-only sufficiency |

The P0–P3 prefix in contract-authoring priority is not the P1/P2/P3 delivery profile and is not business priority.

These values preserve W0–W14 planning history. Future contract-library work should use an explicitly named authoring-priority field so no tool confuses it with delivery profile.

## 19.2 Contract implementation waves

W0 through W14 record contract-library implementation order:

- W0 established the governance foundation and Critical Chain;
- W1 through W13 expanded governance and phase families;
- W14 performed Core Artifact Contracts technical closure.

Wave does not indicate project lifecycle phase, artifact status, gate status, importance to a specific project, or current execution order.

---

# 20. Profile Packaging Codes

Physical packaging uses:

| Code | Meaning |
|---|---|
| C | Composite phase artifact or governed pack |
| M | Modular artifact or independently reviewable section |
| I | Independent lifecycle, owner, review, verification, and change control |
| R | Persistent shared register across phases |
| D | Derived or synchronized view |
| + | Increased formal assurance, independent review, or evidence depth |
| * | Created only when the logical obligation is applicable |

Allowed catalog profile patterns in the current 281-artifact baseline are:

~~~text
C / M / I
C / M / I+
C* / M* / I*
D / D / D+
R / R / R+
~~~

Codes describe packaging. Applicability remains separately recorded.

---

# 21. Delivery Profiles

## 21.1 P1 — Lean

P1 minimizes physical fragmentation while preserving every applicable logical obligation.

P1 requires:

- stable logical IDs;
- canonical ownership;
- sources and information-state typing;
- required questions and decisions;
- critical unhappy paths and recovery behavior;
- applicable standards and controls;
- verification and evidence;
- gate contribution;
- downstream handoff;
- N/A and reopen behavior;
- change-impact visibility.

P1 is not undocumented, informal, unverified, inaccessible, insecure, or untraceable.

## 21.2 P2 — Standard

P2 is the default for serious production products.

P2 separates or independently addresses artifacts when ownership, approval, specialist review, verification, change frequency, external tool ownership, or gate evidence materially differs.

P2 may combine closely related artifacts physically when their IDs and lifecycle semantics remain explicit.

## 21.3 P3 — Comprehensive

P3 strengthens:

- independent artifact lifecycle;
- formal ownership and approval;
- source and evidence control;
- specialist and independent review;
- segregation of duties;
- exception and waiver governance;
- traceability and auditability;
- retention and custody;
- compatibility, migration, and rollback;
- change impact and baseline control.

P3 still uses applicability. Comprehensive does not mean creating irrelevant artifacts.

---

# 22. Profile Selection Rules

## 22.1 Default

Use P2 when a serious production product has no approved reason for P1 and no trigger requiring P3.

## 22.2 P1 eligibility

P1 is eligible only when evidence supports all applicable conditions:

- bounded product and release scope;
- low or controlled domain risk;
- known decision authority;
- small number of independently changing teams or systems;
- reversible changes or bounded failure consequences;
- no hidden regulatory, contractual, safety, critical-service, sensitive-data, privileged-access, or financial-control complexity;
- composite packaging does not obscure ownership, validation, or change;
- gate evidence can remain complete.

P1 is not selected by screen count, file count, sprint length, team size, budget, or client preference alone.

## 22.3 P3 triggers

P3 is required for the affected domain when one or more apply:

- R4 risk in that domain;
- safety-critical or life-affecting behavior;
- critical infrastructure or systemic operational impact;
- material financial control or irreversible high-value transactions;
- large-scale identity, privileged administration, or high-impact authorization;
- regulated or highly sensitive data;
- cross-border or multi-jurisdiction obligations with material conflict;
- formal audit, evidence custody, independent assurance, or segregation-of-duty requirements;
- high-consequence reliability, continuity, recovery, or data-integrity obligations;
- multiple independently governed organizations, vendors, or release trains;
- material compatibility, migration, or irreversible transformation risk;
- Product Constitution or GOV-009 mandate.

## 22.4 Profile cannot waive obligations

An applicable obligation exists at every profile. Profile changes:

- packaging;
- separation;
- reviewer independence;
- formality;
- evidence depth;
- retention;
- change control.

It does not change whether the obligation applies.

---

# 23. Risk-to-Profile Rules

Risk and profile remain separate, but risk establishes minimum treatment.

| Highest affected-domain risk | Minimum treatment |
|---|---|
| R1 LOW | P1 eligible after evidence-based review; P2 remains valid |
| R2 MODERATE | P2 default; P1 requires explicit bounded-risk rationale |
| R3 HIGH | Affected domain is at least P2; evaluate P3 and specialist review |
| R4 CRITICAL | Affected domain is P3; project default is at least P2; systemic or cross-cutting R4 makes the project P3 |

Unknown critical facts cannot be treated as R1 or used to approve P1.

---

# 24. Domain-Level Profile Overrides

A project has one default profile and may raise specific domains.

Canonical override domains:

~~~text
GOVERNANCE_AND_CONTROL
DISCOVERY_AND_BUSINESS
PRODUCT_AND_REQUIREMENTS
EXPERIENCE_AND_DESIGN
SOLUTION_AND_DATA_ARCHITECTURE
SECURITY_PRIVACY_AND_RESILIENCE
ENGINEERING_AND_IMPLEMENTATION
VERIFICATION_AND_RELEASE
OPERATIONS_AND_EVOLUTION
SOURCE_EVIDENCE_AND_AUDIT
~~~

Minimum override:

~~~yaml
domain:
base_profile:
override_profile:
trigger:
scope:
affected_artifact_families: []
required_specialists: []
review_depth:
evidence_depth:
owner:
approving_authority:
starts_at:
review_due:
expiry_or_reopen:
downstream_implications: []
~~~

Rules:

1. An override normally raises a domain.
2. Lowering a domain below the project default requires explicit authority and proof that all obligations remain satisfied.
3. Cross-cutting domains propagate to every affected phase.
4. The highest applicable domain treatment governs shared artifacts.
5. Overrides are reevaluated after scope, standard, risk, platform, data, vendor, release, or operational change.

---

# 25. Product-State Classification

Allowed primary product states:

| Code | State | Meaning | Default routing intent |
|---|---|---|---|
| S0 | EARLY_IDEA | Early problem or opportunity with limited validated product definition | Phase 01 Discovery |
| S1 | NEW_PRODUCT | New product initiative with an initial concept and no operating product baseline | Phase 01 Discovery |
| S2 | OPERATING_BUSINESS_TRANSFORMATION | Existing business operation, workflow, or service being transformed | Discovery plus business-architecture emphasis |
| S3 | EXISTING_PRODUCT | Existing product requiring analysis, redesign, modernization, or extension | Brownfield baseline and delta route |
| S4 | IMPLEMENTATION_IN_PROGRESS | Delivery has started and current baselines may be incomplete or inconsistent | Current-state audit plus targeted backfill and continuation |
| S5 | TROUBLED_OR_RECOVERY | Product or delivery is failing, compromised, unstable, or requires recovery | Containment and recovery route before normal lifecycle work |
| S6 | OPERATIONAL_EVOLUTION | Operating product is entering planned evolution, optimization, or retirement | Phase 11 evolution and targeted baseline reopen |

## 25.1 Primary and secondary state

One primary state determines the safe entry route.

Secondary context is recorded when one state hides material truth. Examples:

- S4 implementation in progress with S5 recovery context;
- S3 existing product entering S6 evolution;
- S2 transformation with S3 existing product assets.

Secondary context cannot neutralize a stronger safety or recovery route.

## 25.2 State evidence

State classification cites evidence such as:

- product and business baseline;
- operating status;
- repositories and deployment identity;
- design and architecture sources;
- backlog and implementation status;
- release and incident history;
- user and usage evidence;
- requested change and target outcome.

## 25.3 Reclassification

State reopens when:

- an operating product is discovered;
- implementation or production evidence contradicts intake;
- an incident or recovery event occurs;
- a release creates a new operational baseline;
- the requested work changes from creation to evolution, recovery, or retirement.

## 25.4 Product state versus lifecycle mode

Product state describes the current product context. Lifecycle mode describes the kind of lifecycle route being executed.

Allowed lifecycle modes:

~~~text
GREENFIELD
BROWNFIELD
RECOVERY
MIGRATION
INCREMENTAL_EVOLUTION
REGULATORY_OR_STANDARDS_CHANGE
INCIDENT_REMEDIATION
SUNSET_OR_TRANSFER
~~~

Examples:

- S1 NEW_PRODUCT normally uses GREENFIELD;
- S3 EXISTING_PRODUCT may use BROWNFIELD, MIGRATION, REGULATORY_OR_STANDARDS_CHANGE, or SUNSET_OR_TRANSFER;
- S5 TROUBLED_OR_RECOVERY may use RECOVERY or INCIDENT_REMEDIATION;
- S6 OPERATIONAL_EVOLUTION normally uses INCREMENTAL_EVOLUTION but can enter another mode when evidence requires it.

One primary lifecycle mode owns the immediate route. Additional affected modes remain explicit when a combined change cannot be safely represented by one label.

---

# 26. Recovery Safety Override

If current evidence indicates any of the following:

~~~text
ACTIVE_SECURITY_COMPROMISE
ACTIVE_DATA_LOSS_OR_CORRUPTION
PRODUCTION_OUTAGE_WITH_MATERIAL_IMPACT
FINANCIAL_CONTROL_FAILURE
SAFETY_RISK
CRITICAL_IDENTITY_OR_PRIVILEGED_ACCESS_FAILURE
LEGAL_OR_REGULATORY_STOP_CONDITION
~~~

the classification emits:

~~~text
IMMEDIATE_ESCALATION_REQUIRED
~~~

Rules:

1. Normal intake does not delay containment.
2. The responsible incident, security, safety, legal, financial, or operational authority receives the route.
3. Evidence preservation and communication obligations begin immediately.
4. Product OS records the route, owner, affected scope, known facts, assumptions, and next safe review.
5. Full classification resumes only when it does not interfere with containment.

---

# 27. Risk Classification

Allowed risk classes:

~~~text
R1  LOW
R2  MODERATE
R3  HIGH
R4  CRITICAL
~~~

Classify risk by domain, then set overall project risk to the highest active domain risk. Do not average risks.

Canonical risk domains:

~~~text
BUSINESS_OUTCOME
USER_HARM
HEALTH_AND_SAFETY
SECURITY
PRIVACY
FINANCIAL
LEGAL_AND_REGULATORY
DATA_INTEGRITY
RELIABILITY_AND_CONTINUITY
OPERATIONAL
DELIVERY_AND_CHANGE
THIRD_PARTY_AND_SUPPLY_CHAIN
IDENTITY_AND_PRIVILEGED_ACCESS
AUDIT_AND_EVIDENCE
~~~

## 27.1 R1 LOW

Use R1 only when consequences are limited, bounded, reversible, observable, and recoverable; no material sensitive-data, regulatory, safety, financial-control, privileged-access, or critical-service exposure is present; and authority and recovery are known.

## 27.2 R2 MODERATE

Use R2 when failure can cause material but controlled disruption, user harm, data impact, integration impact, contractual exposure, or operational cost, and safeguards and recovery remain practical.

## 27.3 R3 HIGH

Use R3 when failure can cause severe user, business, security, privacy, financial, legal, data-integrity, reliability, or operational consequences; when the change is hard to reverse; or when specialist review and formal controls are required.

## 27.4 R4 CRITICAL

Use R4 when failure can be catastrophic, systemic, safety-critical, legally prohibitive, financially uncontrolled, identity-compromising at scale, destructive to critical data, or capable of causing prolonged critical-service loss.

## 27.5 Risk classification factors

Each domain assessment considers:

- impact severity;
- affected population and scope;
- likelihood or credible exposure;
- detectability;
- reversibility;
- recovery time and data loss;
- privilege and trust boundary;
- legal, regulatory, contractual, and audit obligations;
- dependency concentration;
- uncertainty and evidence quality;
- current controls and verified residual risk.

## 27.6 Risk uncertainty rule

Missing evidence may increase uncertainty or create a conservative temporary floor. It cannot justify a lower class.

Risk acceptance remains in the authorized risk-governance process. Classification does not accept residual risk.

---

# 28. Engagement-Scope Classification

Engagement scope applies only in consulting or client-delivery contexts.

Allowed values:

| Code | Engagement scope |
|---|---|
| E1 | Consultation and Direction |
| E2 | Discovery and Business Analysis |
| E3 | Product and Solution Blueprint |
| E4 | UX Architecture and UI/UX Design |
| E5 | Technical Feasibility and Pre-Implementation |
| E6 | Delivery Advisory and Technical Leadership |

Engagement scope is set-valued. A project may include more than one scope.

Record separately:

~~~yaml
engagement_applicable:
client_selected: []
contracted_scope: []
preliminary_recommended: []
methodology_required: []
gap_or_condition:
commercial_authority:
methodology_authority:
decision_status:
~~~

Rules:

- client-selected scope is not automatically the lifecycle depth the product needs;
- recommended scope is not a commercial commitment;
- a narrow engagement does not permit Product OS to claim unperformed lifecycle work;
- out-of-engagement obligations are handed off explicitly with risk and owner;
- E1–E6 never replaces P1–P3.

---

# 29. Information-State Classification

Every meaningful statement entering Product OS is typed as one of:

~~~text
FACT
ASSUMPTION
REQUESTED_IDEA
DECISION
REQUIREMENT
OPEN_QUESTION
~~~

## 29.1 FACT

A statement represented as true by a source. A FACT can still be unverified, contradicted, outdated, or low-confidence.

## 29.2 ASSUMPTION

A proposition temporarily used without sufficient confirmation.

It requires owner, confidence, impact if wrong, validation method, due point or expiry, affected objects, and final disposition.

## 29.3 REQUESTED_IDEA

A suggestion, preference, feature request, concept, or proposed behavior not yet authorized as scope or requirement.

## 29.4 DECISION

A choice made by valid authority for a defined scope, with rationale, status, date, consequences, and reopen conditions.

## 29.5 REQUIREMENT

A governed obligation with valid origin, authority, scope, normative statement, acceptance criteria, verification method, priority, and traceability.

Captured intake statements remain unvalidated requirement candidates until Requirements Engineering establishes them.

## 29.6 OPEN_QUESTION

An unresolved information or decision need with owner, impact, blocking status, due event, and affected objects.

## 29.7 Promotion rules

~~~text
REQUESTED_IDEA → REQUIREMENT
~~~

requires validation, authority, scope, and canonical requirement ownership.

~~~text
ASSUMPTION → FACT
~~~

requires validating evidence and source update.

~~~text
OPEN_QUESTION → DECISION
~~~

requires an answer plus valid decision authority when a choice is involved.

AI or tooling cannot perform these promotions silently.

---

# 30. Requirement Language and Blueprint Migration

The Project Blueprint terminology maps to Product OS as follows:

| Blueprint term | Product OS treatment |
|---|---|
| L1 Rapid | P1 Lean |
| L2 Standard | P2 Standard |
| L3 Comprehensive | P3 Comprehensive |
| MUST as priority | Business priority MUST |
| SHOULD as priority | Business priority SHOULD |
| COULD as priority | Business priority COULD |
| WONT_NOW | Business priority WONT_NOW |
| MUST_NOT as a proposed prohibition | Requirement candidate that becomes SHALL NOT only after validation and authority |
| SHOULD or MAY inside informal source text | Preference, option, idea, or candidate until formalized |

Canonical approved requirement statements use:

~~~text
SHALL
SHALL NOT
~~~

Canonical business priority uses:

~~~text
MUST
SHOULD
COULD
WONT_NOW
~~~

Priority does not determine normative force. A baselined requirement is an obligation regardless of priority; priority controls product and release decisions.

---

# 31. Confidence Classification

Allowed classification confidence:

~~~text
HIGH
MEDIUM
LOW
UNKNOWN
~~~

Assess confidence using:

- source clarity;
- source authority;
- internal consistency;
- corroboration;
- recency;
- scope fit;
- version fit;
- contradiction status.

## 31.1 HIGH

Authoritative, current, scoped, internally consistent, and corroborated where material.

## 31.2 MEDIUM

Credible and usable, with limited gaps, incomplete corroboration, or non-critical ambiguity.

## 31.3 LOW

Material ambiguity, weak authority, stale input, unresolved contradiction, incomplete scope, or insufficient corroboration.

## 31.4 UNKNOWN

Evidence is absent or insufficient to make a responsible confidence judgment.

Confidence is recorded per dimension. One overall value cannot hide low confidence in risk, authority, applicability, or product state.

Confidence is not:

- truth status;
- approval;
- probability;
- verification;
- residual-risk acceptance;
- AI certainty.

## 31.5 Classification namespaces and scale boundaries

Every value is stored with its namespace. Identical symbols or words in different namespaces do not have identical semantics.

| Namespace | Values or owner | Meaning |
|---|---|---|
| delivery_profile | P1, P2, P3 | Packaging and assurance depth |
| contract_authoring_priority | P0_DRAFTED through P3_DERIVED_SHARED | Historical contract-library authoring order |
| question_priority | Q0, Q1, Q2, Q3 | Intake question blocking and impact order |
| business_priority | MUST, SHOULD, COULD, WONT_NOW | Product and release prioritization |
| requirement_criticality | CRITICAL, HIGH, MEDIUM, LOW when adopted by the requirement contract | Consequence and control importance if the obligation fails |
| risk_class | R1, R2, R3, R4 | Assessed exposure requiring treatment and authority |
| severity | Owning defect, incident, security, or operational contract | Observed impact of an actual issue or event |
| resolution_priority | Owning work, defect, incident, or release contract | Order of response after considering severity, exposure, workaround, dependency, and context |
| confidence | HIGH, MEDIUM, LOW, UNKNOWN | Evidence quality for a classification |

Question-priority meanings are:

~~~text
Q0  CRITICAL_BLOCKER — prevents safe route or G0 evaluation
Q1  HIGH_IMPACT — can materially change state, scope, risk, authority, or route
Q2  IMPORTANT — required downstream but not a current route blocker
Q3  DEFERRED — belongs to a later specialist phase or event
~~~

Rules:

- criticality is not risk;
- severity is not priority;
- risk is not confidence;
- question priority is not business priority;
- contract authoring priority is not delivery profile;
- a local scale must name its owning contract, value definitions, ordering, authority, and mapping before cross-tool comparison.

---

# 32. Trace-Edge Confidence Boundary

Traceability uses a separate relationship-confidence vocabulary:

~~~text
CONFIRMED
SUPPORTED
INFERRED
ASSUMED
UNKNOWN
~~~

Classification confidence measures confidence in a classification decision. Trace-edge confidence measures confidence in a relationship between two objects.

The values are not interchangeable.

---

# 33. Status-Dimension Separation

## 33.1 Artifact production status

~~~text
NOT_STARTED
IN_PROGRESS
IN_REVIEW
BLOCKED
COMPLETE
REOPENED
DEPRECATED
~~~

## 33.2 Applicability

~~~text
APPLICABLE
NOT_APPLICABLE
PENDING
~~~

## 33.3 Decision workflow status

~~~text
OPEN
PROPOSED
IN_REVIEW
APPROVED
DEFERRED
REJECTED
~~~

## 33.4 Decision lifecycle disposition

~~~text
CURRENT
SUPERSEDED
EXPIRED
REOPENED
~~~

Existing specialized contracts that use SUPERSEDED, EXPIRED, or REOPENED in a single decision-status field are interpreted as a lifecycle disposition plus the preserved workflow status. Later schemas must normalize the two fields without losing history.

Examples:

- an approved decision replaced by a later decision has workflow status APPROVED and lifecycle disposition SUPERSEDED;
- an expired decision preserves its last workflow status and uses lifecycle disposition EXPIRED;
- a reopened decision uses lifecycle disposition REOPENED and workflow status OPEN or IN_REVIEW according to current handling.

## 33.5 Verification status

~~~text
NOT_STARTED
PARTIAL
VERIFIED
FAILED
BLOCKED
~~~

## 33.6 Change-impact status

~~~text
NOT_ASSESSED
NO_IMPACT
REVIEW_REQUIRED
IMPACT_CONFIRMED
REMEDIATION_REQUIRED
DISPOSITIONED
~~~

## 33.7 Contract coverage status

The framework Coverage Map uses:

~~~text
DRAFTED_V0_1
PLANNED
SHARED_ACTIVE
REVIEWED
BASELINED
BLOCKED
SUPERSEDED
~~~

This status describes contract-library coverage, not a project artifact instance.

## 33.8 Registry lifecycle status

GOV-002 owns:

~~~text
DRAFT
ACTIVE
SUPERSEDED
STALE
RETIRED
~~~

This is the project artifact registry lifecycle and remains separate from artifact production, applicability, decision, verification, and approval.

## 33.9 Trace status and trace confidence

Trace status uses:

~~~text
PROPOSED
ACTIVE
CONFIRMED
CONFLICTED
INVALIDATED
SUPERSEDED
NOT_APPLICABLE
RETIRED
~~~

Trace confidence uses CONFIRMED, SUPPORTED, INFERRED, ASSUMED, or UNKNOWN as defined in Section 32.

Neither trace status nor trace confidence replaces the status of either connected object.

## 33.10 Approval status

Approval status belongs to the artifact or gate contract defining the approval. It remains distinct from decision workflow, artifact production, verification, and registry lifecycle.

Until the Schemas & Repository Standard establishes any cross-artifact approval vocabulary, tools must preserve the source contract’s exact value and authority rather than normalizing it by guess.

## 33.11 Gate outcome

Gate outcome belongs to Gate Specifications. A classification record may be evidence for a gate but cannot issue its own gate outcome.

---

# 34. End-to-End Classification Algorithm

Execute the following order:

1. Register the received source and exact scope.
2. Determine the operating layer.
3. If the subject is a project statement, classify its information state.
4. If it is a cataloged artifact, confirm its stable artifact ID.
5. Apply the catalog’s primary data class.
6. Reevaluate the data class only when a boundary conflict or catalog-change proposal exists.
7. Apply the catalog’s activation class.
8. Evaluate exact project applicability.
9. Determine project default profile from product state, risk, complexity, authority, and assurance needs.
10. Apply domain-level profile overrides.
11. Apply the artifact’s profile packaging pattern.
12. Apply its target contract mode.
13. Evaluate any contract-mode escalation.
14. Record confidence per classification dimension.
15. Record decision owner, authority, status, sources, rationale, due review, and reopen conditions.
16. Allocate downstream obligations.
17. Evaluate gate impact.
18. Register the classification and affected trace links.
19. Reclassify through governed change when later evidence changes the result.

No step may infer approval from document presence, file location, tool status, or AI output.

---

# 35. Multi-Scope and Conflict Handling

## 35.1 Scope partition

Partition classifications when different markets, platforms, data classes, releases, environments, services, journeys, or user groups have different outcomes.

## 35.2 Conflicting sources

When sources conflict:

1. preserve both source identities;
2. record authority and recency;
3. identify the affected classification;
4. create an OPEN_QUESTION or decision need;
5. use PENDING or the safer temporary treatment;
6. route to the authorized owner;
7. retain the contradiction after resolution.

## 35.3 Classification conflict

When reviewers disagree:

- record proposed values and rationale;
- identify whether disagreement is factual, interpretive, authority-related, or scope-related;
- do not average values;
- escalate to the owning authority;
- preserve the rejected or superseded proposal.

## 35.4 Highest-treatment rule

When one shared object serves scopes with different profiles or risk classes, use the highest applicable treatment unless the object can be safely and canonically partitioned.

---

# 36. Natural-Input Handling

Product OS accepts:

- chat and voice transcription;
- documents and spreadsheets;
- contracts, policies, and standards;
- Figma and design sources;
- repositories, revisions, and build outputs;
- API and interface contracts;
- ERDs and architecture sources;
- tickets and backlogs;
- tests, scans, and reports;
- logs, metrics, traces, and dashboards;
- approvals and release decisions;
- operational events and user feedback.

Processing path:

~~~text
Raw Source
→ Registered Source Identity
→ Atomic Item
→ Information-State Classification
→ Question, Decision, or Requirement Candidate
→ Canonical Project Object
→ Verification
→ Claim-Bound Evidence
→ Downstream Handoff
~~~

Natural input is not forced into a file template before it can be understood. Classification preserves origin and authority while routing it to the correct canonical owner.

---

# 37. Brownfield, In-Progress, Recovery, and Evolution Routing

## 37.1 Brownfield

For S3:

- identify current product and production baseline;
- register actual repositories, deployments, design sources, data, interfaces, and operating evidence;
- classify existing claims as verified, unverified, contradicted, stale, or unknown through their proper status dimensions;
- find the earliest materially invalid or missing baseline;
- perform delta work rather than blindly restarting.

## 37.2 Implementation in progress

For S4:

- identify exact delivery state and candidate revisions;
- classify completed, in-progress, unverified, and blocked work separately;
- compare implementation against existing business, product, requirement, design, and architecture baselines;
- backfill only what is necessary for safe continuation and future change.

## 37.3 Recovery

For S5:

- containment and evidence preservation take precedence;
- current failure, exposure, recent changes, owners, and operational impact are classified first;
- recovery decisions do not imply long-term product approval;
- after stabilization, affected baselines and classifications reopen.

## 37.4 Evolution

For S6:

- start from the operational baseline;
- classify the evolution trigger, affected outcome, scope, risk, and evidence;
- traverse impacted artifacts and gates;
- reopen only affected lifecycle points;
- preserve the prior operational baseline and decision history.

---

# 38. Authority and Approval

Classification ownership is dimension-specific.

| Dimension | Accountable owner or authority |
|---|---|
| Operating layer and framework boundary | Product OS framework authority |
| Catalog data class and activation class | Master Artifact Catalog authority |
| Project artifact applicability | Artifact owner plus authorized applicability authority |
| Standard or profile applicability | GOV-009 decision authority |
| Contract mode | Core Artifact Contract library authority |
| Project profile and domain override | Product OS methodology authority with required risk and specialist reviewers |
| Product state and route | Intake owner and G0 authority |
| Risk class | Risk owner and appropriate specialist or business authority |
| Engagement scope | Commercial authority for contracted scope; methodology authority for needed lifecycle depth |
| Information state | Canonical artifact owner; decision and requirement promotion require valid authority |
| Verification status | Authorized verifier or reviewer |
| Gate outcome | Gate authority defined by Gate Specifications |

AI may draft, compare, detect triggers, find contradictions, and recommend. AI cannot:

- approve product state, scope, profile, risk acceptance, N/A, standards applicability, requirement, release, or gate outcome;
- fabricate source authority;
- convert an idea to a requirement silently;
- lower treatment because information is missing;
- declare compliance or verification from file presence.

---

# 39. Reclassification and Change Impact

Reclassification is required when:

- new or corrected source evidence appears;
- product state changes;
- scope, market, platform, user group, language, data, capability, integration, vendor, contract, or standard changes;
- a risk signal emerges or a control fails;
- an architecture or implementation decision changes downstream meaning;
- a new candidate, release, incident, or operational signal appears;
- an applicability trigger changes;
- profile packaging hides ownership or evidence in practice;
- a Shared-only contract proves insufficient;
- an artifact is split, merged, renamed, or retired.

Minimum reclassification change record:

~~~yaml
change_id:
subject_id:
dimension:
previous_value:
proposed_value:
reason:
source_refs: []
effective_scope:
affected_artifacts: []
affected_gates: []
verification_invalidated: []
evidence_invalidated: []
profile_impact:
contract_impact:
repository_or_tool_impact:
owner:
reviewers: []
approving_authority:
decision_status:
effective_at:
supersession_links: []
~~~

Material approved reclassification updates the canonical owner, GOV-002 where applicable, GOV-007, GOV-008 relationships, GOV-009 entries where applicable, affected verification and evidence, and any reopened baseline or gate.

---

# 40. Gate Integration

Classification Rules provide inputs to gates. Gate Specifications own final checks, authority, outcomes, conditions, and evidence contracts.

| Gate | Required classification contribution |
|---|---|
| G0 — Intake Ready | Product state, preliminary profile, domain overrides, risk candidate, engagement distinction, route, confidence, immediate-escalation check, preliminary standards triggers |
| G1 — Problem Understood | Source and information-state integrity, stakeholder and problem scope, critical assumptions and open questions, discovery confidence |
| G2 — Business Baseline | Business object types, rules, controls, risks, priorities, authority, and standards-derived business obligations |
| G3A — Product Baseline | Product capability, boundary, platform, market, journey, policy, conditional-module, and release-scope classifications |
| G3B — Requirements Baseline | Requirement type, normative status, business priority, criticality, condition, applicability, verification method, and traceability |
| G4A — Experience Baseline | Journey, state, actor, channel, language, accessibility, critical-path, and recovery classifications |
| G4B — Design Baseline | Design subject, component, token, state, platform, output, accessibility, localization, and handoff classifications |
| G5A — Architecture Baseline | Driver, constraint, decision, data, trust boundary, integration, criticality, deployment, and recovery classifications |
| G5B — Engineering Readiness Baseline | Work allocation, readiness, dependency, environment, migration, control, verification, and evidence classifications |
| G6A — Implementation Baseline | Implementation candidate, revision, configuration, feature flag, migration, environment, evidence, and deviation classifications |
| G6B — Verification Baseline | Verification target, method, result, severity, evidence, defect, exception, coverage, and residual-gap classifications |
| G7 — Release Authorization | Exact candidate, production target, release scope, risk, condition, approval, rollback, communication, and monitoring classifications |
| G8 — Operational Sustainability & Evolution Review | Operational baseline, service health, incident, risk, evidence freshness, outcome, evolution, re-entry, and retirement classifications |

No blocking PENDING classification may pass silently.

---

# 41. Canonical Machine-Readable Classification Record

Later schemas must represent at least:

~~~yaml
classification_id:
record_version:
project_id:
subject:
  operating_layer:
  subject_type:
  subject_id:
  owner_artifact_id:
  subject_version:
scope:
  phase:
  lifecycle_event:
  product:
  domains: []
  capabilities: []
  platforms: []
  channels: []
  markets: []
  languages_and_directions: []
  data_classes: []
  user_groups: []
  journeys: []
  releases: []
  environments: []
classification:
  primary_data_class:
  activation_class:
  applicability:
  contract_mode:
  default_profile:
  domain_profiles: []
  product_state:
    primary:
    secondary_context: []
  lifecycle_mode:
    primary:
    affected_modes: []
  risk:
    overall:
    domains: []
    immediate_escalation:
  engagement:
    applicable:
    client_selected: []
    contracted_scope: []
    recommended: []
  information_state:
  standards_source_class:
confidence:
  value:
  factors:
    source_clarity:
    source_authority:
    consistency:
    corroboration:
    recency:
    scope_fit:
authority:
  classified_by:
  owner:
  reviewers: []
  decision_authority:
decision:
  workflow_status:
  lifecycle_disposition:
  rationale: []
  conditions: []
status_dimensions:
  artifact_status:
  registry_lifecycle_status:
  contract_coverage_status:
  verification_status:
  change_impact_status:
  trace_status:
  approval_status:
  gate_outcome_ref:
evidence:
  source_refs: []
  evidence_refs: []
impact:
  affected_artifacts: []
  affected_objects: []
  affected_gates: []
  downstream_obligations: []
  safe_interim_treatment:
review:
  classified_at:
  effective_at:
  review_due:
  expiry:
  reopen_conditions: []
change:
  supersedes:
  superseded_by:
  change_id:
~~~

Optional fields may be omitted only when the schema declares them inapplicable and the governing contract preserves the reason. Unknown required meaning remains explicit.

---

# 42. Deterministic Decision Tables

## 42.1 Data-class quick decision

| Primary question | Yes | No |
|---|---|---|
| Is the primary authority a versioned transfer and acceptance boundary? | HND | Continue |
| Is all material content computed or synchronized from canonical sources? | DRV | Continue |
| Is the primary purpose validation, verification, acceptance, or decision proof? | EVD | Continue |
| Does it control identity, status, applicability, risk, decision, exception, or change across objects? | CTL | Continue |
| Does it own integrated canonical project or operating meaning? | SOT | Continue |
| Does it own repeated typed records? | REG | MOD |

## 42.2 Contract-mode quick decision

| Condition | Result |
|---|---|
| Unique truth, authority, handoff, material validation, independent lifecycle, or high assurance | INDEPENDENT |
| Unique artifact semantics safely governed inside a family contract | FAMILY_SECTION |
| Shared Core proven sufficient and no unique authority or lifecycle exists | SHARED_ONLY |
| Insufficient evidence to prove weaker mode | Escalate one level and review |

## 42.3 Applicability quick decision

| Condition | Result |
|---|---|
| Verified trigger or active CORE scope requires obligation | APPLICABLE |
| Authorized evidence proves exact scope excluded and reopen rule exists | NOT_APPLICABLE |
| Trigger, scope, authority, or evidence unresolved | PENDING |
| Different results across scope | Partition scope; do not use PARTIALLY_APPLICABLE |

## 42.4 Profile quick decision

| Condition | Result |
|---|---|
| R4 or mandatory high-assurance trigger in a domain | Domain P3 |
| Serious production work without approved P1 eligibility or P3 trigger | P2 |
| Bounded, reversible, low-risk work with complete control and evidence | P1 eligible |
| Shared artifact serves multiple profile levels | Highest applicable treatment |

---

# 43. Worked Classification Examples

## 43.1 Framework document

Classification Rules itself:

~~~yaml
operating_layer: FRAMEWORK_ASSET
project_artifact_id: null
project_artifact_classification:
  required: false
  reason: PRIMARY_DATA_CLASS_APPLIES_ONLY_TO_PROJECT_ARTIFACTS
project_artifact_count_impact: NONE
~~~

## 43.2 GOV-009

~~~yaml
artifact_id: GOV-009
operating_layer: PROJECT_ARTIFACT
primary_data_class: CTL
activation_class: CORE
contract_mode: INDEPENDENT
profile_pattern: R/R/R+
~~~

It controls applicability. It does not become the downstream business requirement, design, implementation, or verification artifact.

## 43.3 Conditional generated-document obligation

~~~yaml
subject: Generated PDF accessibility obligations
activation_class: COND
scope:
  generated_pdf: APPLICABLE
  internal_plain_text_export: NOT_APPLICABLE
  future_spreadsheet_export: PENDING
gov_009_owner: GOV-009
~~~

Three scopes receive three entries. No partial status is used.

## 43.4 Shared-only derived view

A coverage matrix generated from canonical requirements, tests, evidence, and trace edges:

~~~yaml
primary_data_class: DRV
activation_class: DRVD
contract_mode: SHARED_ONLY
authoritative_manual_edit: PROHIBITED
~~~

If reviewers begin approving waivers inside the matrix, it has acquired unique control authority and must be reclassified or split.

## 43.5 Baseline validation record

~~~yaml
primary_data_class: EVD
contract_mode: INDEPENDENT
reason:
  - owns exact baseline target
  - owns validation result
  - supplies gate-critical evidence
~~~

## 43.6 Small product with regulated data

The product can have a P1 default for bounded product work and a P3 override for SECURITY_PRIVACY_AND_RESILIENCE if the regulated-data obligation requires high assurance.

Small team size does not lower the domain profile.

## 43.7 Feature request from chat

~~~yaml
source_layer: EXTERNAL_SOURCE
information_state: REQUESTED_IDEA
requirement_status: NOT_YET_A_REQUIREMENT
promotion_required:
  - product scope decision
  - valid authority
  - requirement derivation
  - acceptance criteria
  - verification method
~~~

## 43.8 Existing production system with no current documentation

~~~yaml
product_state: S3_EXISTING_PRODUCT
default_profile: P2_CANDIDATE
risk_confidence: LOW
route:
  - register actual repositories and deployments
  - inspect current operating evidence
  - identify earliest invalid baseline
  - perform targeted backfill
~~~

Lack of documentation does not convert the system into S1.

## 43.9 Active outage

~~~yaml
product_state: S5_TROUBLED_OR_RECOVERY
risk_class: R4_CANDIDATE
route: IMMEDIATE_ESCALATION_REQUIRED
normal_intake: DEFERRED_UNTIL_SAFE
~~~

## 43.10 Blueprint MUST statement

Source statement:

~~~text
The product MUST support export.
~~~

Initial classification:

~~~yaml
information_state: REQUESTED_IDEA_OR_REQUIREMENT_CANDIDATE
business_priority_candidate: MUST
normative_requirement: NOT_ESTABLISHED
~~~

After validation, authority, scope, and acceptance design, the canonical requirement uses SHALL or SHALL NOT.

---

# 44. Current 281-Artifact Reconciliation

This specification was checked against the current Master Artifact Catalog and W14 Coverage Map.

## 44.1 Data-class totals

| Data class | Count |
|---|---:|
| MOD | 93 |
| REG | 70 |
| EVD | 48 |
| SOT | 24 |
| DRV | 21 |
| CTL | 16 |
| HND | 9 |
| **Total** | **281** |

## 44.2 Activation totals

| Activation class | Count |
|---|---:|
| CORE | 181 |
| COND | 63 |
| EVENT | 15 |
| DRVD | 13 |
| RECUR | 9 |
| **Total** | **281** |

## 44.3 Contract-mode totals

| Contract mode | Count |
|---|---:|
| FAMILY_SECTION | 183 |
| INDEPENDENT | 71 |
| SHARED_ONLY | 27 |
| **Total** | **281** |

## 44.4 Contract-coverage-status totals

| Contract coverage status | Count |
|---|---:|
| DRAFTED_V0_1 | 254 |
| SHARED_ACTIVE | 27 |
| **Total** | **281** |

## 44.5 Contract-authoring-priority totals

| Contract authoring priority | Count |
|---|---:|
| P0_DRAFTED | 17 |
| P0_GOVERNANCE | 7 |
| P0_GATE_CRITICAL | 47 |
| P1_CORE_SEMANTIC | 121 |
| P2_CONDITIONAL_EVENT | 62 |
| P3_DERIVED_SHARED | 27 |
| **Total** | **281** |

## 44.6 Profile-pattern totals

| P1 / P2 / P3 pattern | Count |
|---|---:|
| C / M / I | 118 |
| C / M / I+ | 74 |
| C* / M* / I* | 63 |
| D / D / D+ | 18 |
| R / R / R+ | 8 |
| **Total** | **281** |

## 44.7 Data-class to contract-mode reconciliation

| Data class | INDEPENDENT | FAMILY_SECTION | SHARED_ONLY | Total |
|---|---:|---:|---:|---:|
| CTL | 16 | 0 | 0 | 16 |
| SOT | 24 | 0 | 0 | 24 |
| HND | 9 | 0 | 0 | 9 |
| REG | 4 | 66 | 0 | 70 |
| MOD | 0 | 93 | 0 | 93 |
| EVD | 17 | 24 | 7 | 48 |
| DRV | 1 | 0 | 20 | 21 |
| **Total** | **71** | **183** | **27** | **281** |

## 44.8 Reconciliation result

- No catalog artifact ID was added, removed, renamed, merged, or split.
- No current data-class, activation-class, profile-pattern, or contract-mode row requires reclassification.
- W14’s 254 specialized logical contracts and 27 Shared-only dispositions remain valid.
- Classification Rules replace the Coverage Map’s first-pass planning semantics with the canonical cross-cutting Working Draft rules in this file.
- Product OS authority approval and baseline remain pending.

---

# 45. Classification Anti-Patterns

The following are invalid:

1. selecting P1 because the project is small;
2. treating P3 as “create every possible file”;
3. using COND as an applicability value;
4. using PARTIALLY_APPLICABLE instead of partitioning scope;
5. recording N/A without evidence, authority, and reopen condition;
6. treating absence as N/A;
7. lowering risk because evidence is missing;
8. averaging risk domains;
9. using engagement scope to conceal lifecycle need;
10. converting requested ideas into requirements silently;
11. using MUST as both priority and normative requirement language;
12. treating SOT as automatically approved;
13. treating COMPLETE as VERIFIED;
14. treating APPROVED as implemented;
15. treating a derived view as canonical truth;
16. editing a DRV to correct upstream data;
17. assigning multiple primary data classes;
18. using file shape to determine logical identity;
19. merging artifacts with different authorities or lifecycles without explicit identity;
20. using SHARED_ONLY as “no contract needed”;
21. using AI confidence as evidence;
22. allowing AI to approve profile, risk, applicability, requirement, release, or gate decisions;
23. creating empty derived artifacts to satisfy a tree;
24. restarting a brownfield product from Phase 00 without current-state and delta analysis;
25. continuing routine intake during an active compromise, data-loss event, outage, financial-control failure, or safety risk.

---

# 46. Validation Rules

## 46.1 Layer and identity

~~~text
CLS-VAL-001  Every classified subject has an exact operating layer.
CLS-VAL-002  Framework assets do not consume project artifact IDs or change the 281 count.
CLS-VAL-003  Every PROJECT_ARTIFACT uses a canonical catalog ID.
CLS-VAL-004  Every PROJECT_OBJECT identifies its canonical owner artifact.
CLS-VAL-005  TOOL_REPRESENTATION records the canonical subject and cannot become truth by location alone.
~~~

## 46.2 Data class

~~~text
CLS-VAL-006  Every catalog artifact has exactly one primary data class.
CLS-VAL-007  Data class follows primary authority and lifecycle, not file format.
CLS-VAL-008  DRV content identifies canonical upstream objects and freshness.
CLS-VAL-009  EVD identifies claim, target, method, result, and evidence.
CLS-VAL-010  HND identifies transfer scope, versions, receiving owner, and acceptance boundary.
CLS-VAL-011  Any unresolved dual-primary responsibility creates a boundary or catalog-change review.
~~~

## 46.3 Activation and applicability

~~~text
CLS-VAL-012  Every catalog artifact has one activation class.
CLS-VAL-013  Activation class and project applicability are stored separately.
CLS-VAL-014  COND identifies explicit triggers and decision authority.
CLS-VAL-015  DRVD requires upstream objects, consumer, lineage, and freshness.
CLS-VAL-016  EVENT identifies the activating event and closure route.
CLS-VAL-017  RECUR identifies live scope, cadence, owner, freshness, and missed-review behavior.
CLS-VAL-018  Applicability uses only APPLICABLE, NOT_APPLICABLE, or PENDING.
CLS-VAL-019  Mixed scope is partitioned rather than marked PARTIALLY_APPLICABLE.
CLS-VAL-020  NOT_APPLICABLE includes exact scope, reason, authority, evidence, downstream impact, and reopen conditions.
CLS-VAL-021  PENDING includes missing evidence, owner, due event, safe interim treatment, and gate impact.
~~~

## 46.4 Contract mode and profile

~~~text
CLS-VAL-022  Every catalog artifact has one target contract mode.
CLS-VAL-023  SHARED_ONLY has a documented sufficiency decision and escalation trigger.
CLS-VAL-024  Unique truth, authority, handoff, material validation, or separate lifecycle is not hidden in SHARED_ONLY.
CLS-VAL-025  Contract-mode override records rationale, risk, profiles, dependencies, validation, change impact, migration, and authority.
CLS-VAL-026  Profile packaging preserves every applicable logical ID and obligation.
CLS-VAL-027  P1 selection has evidence beyond team size, budget, schedule, or file count.
CLS-VAL-028  P3 applies to every domain with an active mandatory high-assurance trigger.
CLS-VAL-029  Shared objects use the highest applicable domain treatment unless safely partitioned.
CLS-VAL-030  Profile never weakens constitutional, standard, safety, security, privacy, accessibility, legal, reliability, audit, or evidence obligations.
~~~

## 46.5 State, risk, engagement, and information

~~~text
CLS-VAL-031  Product state has one primary route-driving value and preserves material secondary context.
CLS-VAL-032  S3, S4, S5, and S6 use brownfield, continuation, recovery, or evolution routing rather than an automatic full restart.
CLS-VAL-033  Recovery safety signals emit IMMEDIATE_ESCALATION_REQUIRED.
CLS-VAL-034  Risk is assessed by domain and overall risk equals the highest active domain.
CLS-VAL-035  Missing evidence cannot lower risk or approve P1.
CLS-VAL-036  Engagement scope is separated from methodology-required lifecycle depth.
CLS-VAL-037  Every meaningful statement uses a valid information-state classification.
CLS-VAL-038  REQUESTED_IDEA cannot become REQUIREMENT without validation and authority.
CLS-VAL-039  ASSUMPTION has owner, confidence, impact, validation, due point, and disposition.
CLS-VAL-040  Requirements use SHALL or SHALL NOT; business priority uses MUST, SHOULD, COULD, or WONT_NOW.
~~~

## 46.6 Confidence, status, authority, and change

~~~text
CLS-VAL-041  Confidence is recorded per material classification dimension.
CLS-VAL-042  Confidence is based on source quality and is not used as approval or verification.
CLS-VAL-043  Artifact, applicability, decision workflow, decision lifecycle, verification, change-impact, registry, and gate statuses remain separate.
CLS-VAL-044  Classification identifies owner, decision authority, sources, rationale, scope, and review timing.
CLS-VAL-045  AI recommendations remain visibly unapproved until human or organizational authority acts.
CLS-VAL-046  Conflicting sources and rejected classifications remain traceable.
CLS-VAL-047  Material reclassification creates change impact and updates affected governance and downstream objects.
CLS-VAL-048  Invalidated verification and evidence are identified after material reclassification.
CLS-VAL-049  No blocking PENDING classification passes a gate silently.
CLS-VAL-050  Catalog counts reconcile to 281 and profile, activation, data-class, and contract-mode totals reconcile exactly.
CLS-VAL-051  Contract-authoring priority is not interpreted as delivery profile or business priority.
CLS-VAL-052  W0–W14 implementation wave is not interpreted as project lifecycle or artifact status.
CLS-VAL-053  Contract coverage status is not used as project artifact status.
CLS-VAL-054  GOV-002 registry lifecycle uses DRAFT, ACTIVE, SUPERSEDED, STALE, or RETIRED and remains a separate dimension.
CLS-VAL-055  Trace status and trace confidence remain separate from connected-object statuses.
CLS-VAL-056  Approval status preserves the vocabulary and authority of its governing artifact or gate contract.
CLS-VAL-057  Product state and lifecycle mode remain separate and jointly determine safe entry routing.
CLS-VAL-058  Every priority, risk, criticality, severity, and confidence value retains its explicit namespace.
CLS-VAL-059  Severity, resolution priority, requirement criticality, risk class, question priority, and business priority do not substitute for one another.
CLS-VAL-060  Any domain-local scale identifies its owning contract, definitions, ordering, authority, and cross-tool mapping.
~~~

---

# 47. Classification Review Procedure

For a formal review:

1. confirm source identities and authority;
2. confirm subject operating layer;
3. confirm exact scope partitions;
4. confirm primary data class and activation class;
5. confirm applicability and N/A or PENDING evidence;
6. confirm contract mode;
7. confirm default and domain profiles;
8. confirm product state, risk domains, engagement boundary, and information states;
9. confirm confidence factors;
10. confirm distinct statuses;
11. confirm authority and approval boundaries;
12. confirm downstream and gate impact;
13. run CLS-VAL-001 through CLS-VAL-060;
14. record conflicts, conditions, and reopen triggers;
15. issue a review result without inventing Product OS baseline approval.

Review outcomes for this framework workstream are:

~~~text
TECHNICAL_PASS
TECHNICAL_PASS_WITH_CONDITIONS
TECHNICAL_HOLD
TECHNICAL_FAIL
~~~

These are workstream review outcomes, not lifecycle gate outcomes.

---

# 48. Closure Criteria

Classification Rules are technically complete when:

- every classification dimension has a canonical vocabulary and boundary;
- deterministic decision order exists for operating layer, data class, activation, applicability, contract mode, and profile;
- P1/P2/P3 and domain overrides are explicit;
- S0–S6, R1–R4, and E1–E6 are operational;
- information-state, confidence, and status semantics are separated;
- Blueprint L1/L2/L3 and requirement-language migration are resolved;
- natural input, brownfield, recovery, and reclassification routes exist;
- AI authority boundaries are explicit;
- all 281 artifacts reconcile with no unexplained mismatch;
- validation rules are complete;
- downstream Gate Specifications inputs are identified.

Technical completion does not equal Product OS approval or baseline.

---

# 49. Gate Specifications Reconciliation and Downstream Contract

The [Gate Specifications library](Gate_Specifications/Gate_Specifications_Index.md) has consumed the following Classification Rules inputs and completed technical closure at Working Draft level. Product OS authority approval and baseline remain pending.

Gate Specifications consume:

- the classification dimensions and vocabularies in this file;
- exact-scope and partition rules;
- PENDING blocker semantics;
- N/A evidence and authority requirements;
- profile and domain-override treatment;
- risk and immediate-escalation routing;
- status-dimension separation;
- classification confidence boundaries;
- gate contribution table;
- CLS-VAL validation requirements relevant to gate readiness.

Gate Specifications provide:

- gate-specific authorities;
- mandatory inputs and evidence;
- decision quorum and segregation;
- PASS, PASS_WITH_CONDITIONS, HOLD, REJECT, release, and operational outcome contracts;
- condition ownership and expiry;
- gate evidence indexes;
- emergency handling;
- reopen and appeal routes;
- machine-validation expectations.

The [Gate Specifications Coverage and Closure Review](Gate_Specifications/Gate_Specifications_Coverage_and_Closure_Review.md) records 13 / 13 gate specifications, 308 / 308 detailed checks, 50 / 50 shared validation rules, and technical `PASS`.

## 49.1 Traceability Graph Reconciliation

The [Traceability Graph library](Traceability_Graph/Traceability_Graph_Index.md) now owns the complete Working Draft graph language: 23 semantic node classes, 40 canonical edge types, 40 domain/range/cardinality constraints, exact scope and bitemporal history, required paths, coverage, orphans, gaps, conflicts, traversal, standards/evidence/gate lineage, views, and 60 validation rules. Its [Coverage and Closure Review](Traceability_Graph/Traceability_Graph_Coverage_and_Closure_Review.md) records technical `PASS` without changing the 281-artifact catalog.

The graph produces reproducible candidate impact sets. The [Change Impact Rules library](Change_Impact_Rules/Change_Impact_Rules_Index.md) now owns materiality, no-impact authority, remediation, proportional re-review, acknowledgement, reopen decisions, and closure.

## 49.2 Change Impact Rules Reconciliation

The [Change Impact Rules library](Change_Impact_Rules/Change_Impact_Rules_Index.md) operationalizes `GOV-007` through 22 change classes, eight change intents, compatibility/reversibility vocabularies, six materiality levels, ten affected-object dispositions, all 13 artifact families and gates, 12 canonical views, 60 validation rules, and 30 anti-patterns. Its [Coverage and Closure Review](Change_Impact_Rules/Change_Impact_Rules_Coverage_and_Closure_Review.md) records technical `PASS` without changing the 281-artifact catalog.

Classification remains responsible for identifying what kind of object, state, profile, information, risk, and reclassification event exists. Change Impact Rules consumes those classifications and decides the authorized response for exact changed scope. Source / Evidence Model now owns the evidence-quality dimensions that classification previously deferred.

## 49.3 Source / Evidence Model Reconciliation

The [Source / Evidence Model library](Source_Evidence_Model/Source_Evidence_Model_Index.md) operationalizes source/evidence semantics through 22 source types, A0–A5 authority, 12 claim types, all six inherited information states, 22 evidence types, 14 fitness dimensions, all 13 artifact families and gates, 14 views, 70 validation rules, and 35 anti-patterns. Its [Coverage and Closure Review](Source_Evidence_Model/Source_Evidence_Model_Coverage_and_Closure_Review.md) records technical `PASS` without changing the 281-artifact catalog.

Classification continues to identify operating layer, EVD class, information state, confidence, profile, and activation. Source / Evidence Model owns authority/reliability, claim binding, fitness, sufficiency, admissibility, provenance, custody, integrity, access, retention, and disclosure.

## 49.4 AI Operating Specification Reconciliation

The [AI Operating Specification library](AI_Operating_Specification/AI_Operating_Specification_Index.md) operationalizes AI participation through 12 roles, eight operating modes, six consequence-based action classes, seven human/policy operating-control patterns, all 13 artifact families and gates, 14 views, 70 validation rules, and 35 anti-patterns. Its [Coverage and Closure Review](AI_Operating_Specification/AI_Operating_Specification_Coverage_and_Closure_Review.md) records technical `PASS` without changing the 281-artifact catalog.

Classification continues to own operating layer, project profile, risk, information state, applicability, and status separation. AI Operating Specification owns AI behavior and authority, Spec Kit/Figma/GitHub Mapping owns named-tool representations, and Automation / Commands executes bounded checks. The [Pilot](Pilot/Pilot_Index.md) verified those boundaries across P1/P2/P3. The Product OS v1.0 release candidate is technically finalized; the next action is the Product OS authority decision.

---

# 50. Change Control

Changing this specification requires:

- change reason and affected rule IDs;
- impact on the Master Artifact Catalog;
- impact on Core Artifact Contracts and W14 closure;
- impact on P1/P2/P3 packaging;
- impact on phase methodologies and gates;
- impact on GOV-002, GOV-007, GOV-008, and GOV-009;
- schema and repository impact;
- migration and backward-compatibility treatment;
- pilot impact;
- approving Product OS authority;
- version update and change history.

A change that alters artifact IDs, counts, data classes, activation classes, profile patterns, or contract modes reopens the affected catalog and contract-library reviews.

---

# 51. Change History

| Version | Date | Status | Change |
|---|---|---|---|
| 0.1.0 | 2026-08-11 | Working Draft | First complete cross-cutting classification specification; reconciles all 281 artifacts, freezes current classification semantics, resolves Blueprint L1/L2/L3 migration, and hands off to Gate Specifications |

---

# 52. Final Classification Principle

> **Product OS classifies meaning before packaging, scope before status, evidence before confidence, risk before convenience, and authority before approval. A classification is valid only when it routes the exact obligation to the correct owner, profile, gate, verification, evidence, and reopen path without hiding uncertainty or creating competing truth.**
