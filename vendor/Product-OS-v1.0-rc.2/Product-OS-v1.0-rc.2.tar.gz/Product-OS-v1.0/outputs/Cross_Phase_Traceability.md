# Product OS v1.0 — Cross-Phase Traceability

**Document ID:** `MASTER-CROSS-PHASE-TRACEABILITY`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — TRACEABILITY CONTRACT COMPLETE`  
**Coverage:** `Source intake through operations, evolution, and retirement`  
**Constitution Link:** `GOV-001 — Product Constitution`  
**Artifact Registry Link:** `GOV-002 — Artifact Register`  
**Primary Governance Link:** `GOV-008 — Traceability Graph`  
**Standards Link:** `GOV-009 — Standards & Compliance Applicability Matrix`  
**Implementation Library:** [Traceability Graph v0.1.0](Traceability_Graph/Traceability_Graph_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Change Response Library:** [Change Impact Rules v0.1.0](Change_Impact_Rules/Change_Impact_Rules_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Source / Evidence Library:** [Source / Evidence Model v0.1.0](Source_Evidence_Model/Source_Evidence_Model_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**AI Operating Library:** [AI Operating Specification v0.1.0](AI_Operating_Specification/AI_Operating_Specification_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Companion Documents:** `Master_Lifecycle_Index.md`, `Gate_Map.md`, `Gate_Specifications/Gate_Specifications_Index.md`, and `Classification_Rules.md`  
**Purpose:** تعريف الـcanonical traceability graph الذي يربط sources, facts, assumptions, questions, decisions, business and product objects, requirements, experience, design, architecture, readiness, implementation, verification, release, operations, evidence, evolution, and sunset بدون نسخ كل المحتوى داخل matrix واحدة أو اختراع approval من مجرد وجود link.

---

# 1. Core Traceability Chain

```text
Raw Source
  -> Fact / Evidence / Assumption / Request
  -> Question
  -> Decision / Problem / Outcome / Obligation
  -> Business Object
  -> Product Object
  -> Requirement
  -> Experience Object
  -> Design Object
  -> Architecture Mechanism / Decision
  -> Engineering Allocation
  -> Implementation Object / Candidate
  -> Verification Method / Result / Evidence
  -> Release Scope / Decision / Execution
  -> Live Product / Operational Signal / Outcome
  -> Insight / Evolution Decision
  -> Earliest Affected Baseline
  ↺
```

---

# 2. Traceability Is a Graph

Traceability is many-to-many.

One source may support many decisions; one requirement may derive from several sources; one component may implement many requirements; one verification result may support multiple obligations; one incident may reopen multiple baselines.

A flat one-row-per-requirement spreadsheet is only one view of the graph.

---

# 3. Traceability Purposes

The graph must answer:

```text
Why does this object exist?
Who approved it?
Which source and evidence support it?
What does it affect?
Where is it realized?
How is it verified?
What was actually released?
How does it behave in production?
What changed after release?
Which baseline must reopen?
What is no longer applicable, and why?
```

---

# 4. Source-of-Truth Rule

The graph stores identities and relationships.

The authoritative content remains in its owning artifact, system, design source, repository, evidence store, incident system, or operational platform.

Do not duplicate full source truth into traceability fields.

---

# 5. Governance Boundary

`GOV-001` owns the governing rules and non-negotiables that constrain nodes, edges, evidence, authority, and AI behavior.

`GOV-002` owns canonical artifact identity and lifecycle metadata. Traceability nodes reference GOV-002 entries rather than creating competing artifact identities.

`GOV-008` owns the cross-phase traceability graph.

Each phase owns its local objects and contributes governed edges.

`GOV-009` owns standards applicability and clause / criterion lineage; phase objects reference it rather than creating competing applicability truth.

The relationship is:

```text
GOV-001 governing rule
  -> GOV-009 applicability and propagation
  -> Phase artifact registered in GOV-002
  -> Cross-phase relationships in GOV-008
```

---

# 6. Node Classes

```text
ARTIFACT        GOV-002 registered artifact container and version
SOURCE          Raw or authoritative source
FACT            Evidence-backed observation
ASSUMPTION      Unverified belief used provisionally
QUESTION        Open information or decision need
DECISION        Accountable choice and rationale
RISK            Potential adverse event or condition
EXCEPTION       Authorized deviation or waiver
EVIDENCE        Reviewable proof
STANDARD        Standard, criterion, profile, or applicability object
BUSINESS        Business objective, capability, process, rule, control, information
PRODUCT         Product objective, capability, module, feature candidate, policy, state
REQUIREMENT     Functional or quality obligation and acceptance contract
EXPERIENCE      Actor, journey, flow, IA, view, state, interaction, content responsibility
DESIGN          Token, component, pattern, screen, state, content, prototype
ARCHITECTURE    Driver, QAS, ADR, domain, data, interface, control, deployment mechanism
READINESS       Slice, work item, owner, repository, environment, migration, evidence allocation
IMPLEMENTATION  Source, schema, configuration, infrastructure, artifact, candidate
VERIFICATION    Case, run, result, defect, coverage, waiver, VBL
RELEASE         Scope, target, authorization, execution, rollout, rollback, handoff
OPERATION       Live identity, SLI, SLO, incident, support, control health, recovery, cost
EVOLUTION       Signal, insight, experiment, candidate, decision, portfolio, route
LIFECYCLE       Deprecation, migration, sunset, transfer, retirement
```

The dedicated [Node Taxonomy and Identity](Traceability_Graph/01_Node_Taxonomy_and_Identity.md) retains all 22 legacy semantic classes and adds `ARTIFACT` so a catalog container is not confused with the semantic objects it owns.

---

# 7. Canonical Edge Types

```text
CAPTURED_FROM
SUPPORTED_BY
CONTRADICTS
ASSUMES
ANSWERS
DECIDES
DERIVED_FROM
REFINES
DECOMPOSES_TO
BOUNDS
SATISFIES
REALIZES
ALLOCATED_TO
IMPLEMENTED_BY
CONFIGURED_BY
MIGRATED_BY
VERIFIED_BY
EVIDENCED_BY
FAILED_BY
WAIVED_BY
DEPENDS_ON
CONSTRAINED_BY
GOVERNED_BY
APPLIES_TO
NOT_APPLICABLE_TO
INCLUDED_IN
EXCLUDED_FROM
BASELINED_IN
AUTHORIZED_BY
RELEASED_AS
DEPLOYED_TO
OPERATES_AS
MEASURED_BY
OBSERVED_BY
TRIGGERED_BY
REOPENS
INVALIDATES
SUPERSEDES
RETIRES
TRANSFERRED_TO
```

The complete meaning, canonical direction, allowed inverse display, domain, range, aggregate cardinality, cycle behavior, and mandatory activation for all 40 edges are governed by [Edge Vocabulary and Direction](Traceability_Graph/02_Edge_Vocabulary_and_Direction.md) and [Edge Domain, Range, and Cardinality](Traceability_Graph/03_Edge_Domain_Range_and_Cardinality.md).

---

# 8. Edge Semantics

Every edge has one defined meaning.

Examples:

```text
REQ-001 DERIVED_FROM PCAP-007
COMP-012 REALIZES UXS-044
REQ-FR-021 IMPLEMENTED_BY SRC-COMMIT-abc
VCASE-090 VERIFIED_BY REQ-FR-021 is invalid direction
REQ-FR-021 VERIFIED_BY VCASE-090 is valid
VRES-120 EVIDENCED_BY VEVID-411
RSCP-009 AUTHORIZED_BY RDEC-009
REXEC-009 DEPLOYED_TO PROD-TARGET-01
OINC-2026-004 REOPENS ABL-2026-001
```

Direction is canonical and tooling must not infer ambiguous inverse meaning.

---

# 9. Trace Record Contract

```yaml
trace_id: TRACE-000001
from:
  type: REQUIREMENT
  id: REQ-FR-021
  version: RBL-2026-001
edge: IMPLEMENTED_BY
to:
  type: IMPLEMENTATION
  id: SRC-COMMIT-abc123
  version: abc123
scope: RELEASE-2026-04
status: ACTIVE
source: IMP-003
evidence: []
owner: engineering_owner
created_at: null
reviewed_at: null
valid_from: null
valid_until: null
confidence: CONFIRMED
notes: null
```

---

# 10. Trace Status

```text
PROPOSED
ACTIVE
CONFIRMED
CONFLICTED
INVALIDATED
SUPERSEDED
NOT_APPLICABLE
RETIRED
```

---

# 11. Confidence

```text
CONFIRMED        Approved source and evidence support the edge
SUPPORTED        Evidence supports but authority or completeness is pending
INFERRED         Reasoned relationship awaiting confirmation
ASSUMED          Provisional relationship from an explicit assumption
UNKNOWN          Relationship cannot yet be established
```

Inferred and assumed edges cannot be presented as approved coverage.

---

# 12. Version Binding

Every material trace binds object and baseline versions.

An edge between unversioned labels cannot prove release or verification coverage after change.

---

# 13. Scope Binding

Trace scope may include:

```text
Project or product
Release
Capability or module
Platform or client
Market, country, locale, or direction
Role, tenant, or cohort
Environment or target
Standards profile
Lifecycle state
```

---

# 14. Phase Contribution Map

| Phase | Creates or validates | Required upstream link | Required downstream link |
|---|---|---|---|
| 00 | Sources, facts, assumptions, requests, initial questions, triggers | Input origin | Discovery route / GOV-009 |
| 01 | Problems, causes, stakeholders, outcomes, discovery evidence | ICB and sources | Business objects and decisions |
| 02 | Objectives, capabilities, processes, roles, rules, controls, information | DSBL | Product responsibility and requirements source |
| 03 | Product scope, capabilities, modules, policies, states, candidates | BBL | Requirement derivation |
| 04 | Requirements, acceptance, priority, verification intent | BBL / PBL / GOV-009 | Experience, design, architecture, readiness, verification |
| 05 | Journeys, flows, IA, views, states, interaction and content responsibility | PBL / RBL | Design realization |
| 06 | Tokens, components, patterns, screens, states, prototypes | EBL / RBL | Architecture and implementation targets |
| 07 | ADRs, data, APIs, controls, deployment, reliability mechanisms | PBL / RBL / EBL / DBL | Engineering allocation |
| 08 | Slices, work items, repositories, owners, migrations, evidence allocation | All approved baselines | Implementation objects |
| 09 | Source, schema, configuration, infrastructure, artifacts, candidate | ERBL and allocated objects | Verification candidate and evidence |
| 10 | Cases, results, defects, VBL, release scope, target, decision, execution | IBL / all obligations | Live identity and handoff |
| 11 | SLOs, incidents, support, control health, outcomes, insights, routes, lifecycle | Released scope / OBL | Reopened baseline or retirement evidence |

---

# 15. Required Inter-Phase Edges

```text
DSBL           DERIVED_FROM     ICB
BBL            DERIVED_FROM     DSBL
PBL object     DERIVED_FROM     BBL object
RBL object     DERIVED_FROM     PBL / BBL object
EBL object     REALIZES         RBL object
DBL object     REALIZES         EBL object
ABL mechanism  SATISFIES        RBL / QAS / control object
Obligation     ALLOCATED_TO     ERBL item
Obligation     IMPLEMENTED_BY   IBL object
Obligation     VERIFIED_BY      VCASE / method
VRES           EVIDENCED_BY     VEVID
RSCP / RCAND   AUTHORIZED_BY    RDEC
REXEC          DEPLOYED_TO      production target
REXEC          OPERATES_AS      LIDN / OBL live scope
INS            SUPPORTED_BY     operational evidence
EVCAND         DERIVED_FROM     INS
EVDEC          DECIDES          ROUTE
ROUTE          REOPENS          affected baseline
SUN            RETIRES          live scope
```

---

# 16. Upstream Traceability

Upstream trace answers:

```text
Why does this requirement, component, ADR, work item, or test exist?
```

Every approved downstream object reaches at least one legitimate source such as outcome, product responsibility, requirement, risk, standard obligation, defect, incident, or evolution decision.

---

# 17. Downstream Traceability

Downstream trace answers:

```text
Where is this approved obligation realized, verified, released, operated, and measured?
```

Not every early object must reach production, but its disposition must be explicit.

---

# 18. Disposition

```text
PLANNED
IN_SCOPE
IMPLEMENTED
VERIFIED
RELEASED
OPERATING
DEFERRED
NOT_APPLICABLE
REJECTED
SUPERSEDED
RETIRED
```

Disposition is distinct from lifecycle status and verification status.

---

# 19. Orphan Definition

An orphan is an object that should have a required relationship but does not.

Examples:

```text
Feature candidate without product capability
Requirement without approved source
Screen without journey, state, or requirement
Component without adoption or intended consumer
ADR without driver or affected mechanism
Work item without baseline allocation
Source change without work item or decision
Test without obligation or risk
Applicable standard without product / requirement / control chain
Release item without VBL coverage
Operational alert without SLO, risk, control, or response purpose
Evolution candidate without evidence or route
```

---

# 20. Orphan Status

```text
ORPHAN_CONFIRMED
LINK_MISSING
SOURCE_MISSING
DOWNSTREAM_MISSING
INTENTIONALLY_STANDALONE
NOT_APPLICABLE
RESOLVED
```

Intentional standalone status requires reason and review.

---

# 21. Coverage Model

Coverage is evaluated by required relationship, not raw link count.

```text
COVERED
PARTIALLY_COVERED
UNCOVERED
CONFLICTED
NOT_APPLICABLE
NOT_YET_REQUIRED
INVALIDATED
```

---

# 22. Coverage Dimensions

```text
Source coverage
Decision coverage
Business-to-product coverage
Product-to-requirement coverage
Requirement family coverage
Experience and state coverage
Design and component coverage
Architecture allocation coverage
Engineering allocation coverage
Implementation coverage
Verification and evidence coverage
Release-scope coverage
Operational-signal coverage
Evolution and lifecycle coverage
Standards and control coverage
```

---

# 23. Coverage Quality

A link is not sufficient when:

```text
The source is stale or unapproved
The relationship type is wrong
The version is missing
The scope differs
The target only partially realizes the obligation
Evidence does not support the claim
The edge was invalidated by change
The link exists only as free text
```

---

# 24. Decision Traceability

Every material decision links:

```text
Question
Context and evidence
Options
Chosen decision
Authority
Affected objects and baselines
Conditions and exceptions
Date and validity
Reopen trigger
Downstream effect
```

---

# 25. Assumption Traceability

Every material assumption links to:

```text
Source or reason
Objects depending on it
Risk if false
Validation method
Owner
Due date or trigger
Result
Affected gate
```

---

# 26. Risk Traceability

Risk links cause, event, impact, affected scope, controls, requirements, architecture mechanisms, operational detection, response, recovery, owner, evidence, and accepted authority.

---

# 27. Exception Traceability

Exception or waiver links:

```text
Original obligation
Affected scope
Reason and risk
Compensating controls
Monitoring
Authority
Expiry
Gate or live decision
Closure evidence
Reopen trigger
```

An exception never rewrites the obligation as satisfied.

---

# 28. Defect Traceability

```text
Failed obligation / test / live signal
  -> Defect
  -> Root cause classification
  -> Owning baseline or implementation object
  -> Fix / change set
  -> Retest
  -> Regression
  -> Evidence
  -> Release / operational result
```

---

# 29. Incident Traceability

```text
Operational signal
  -> Incident and impact
  -> Containment / recovery
  -> Problem / contributing conditions
  -> Corrective action
  -> Earliest affected baseline
  -> Implementation / verification / release
  -> Updated control evidence
  -> Recurrence monitoring
```

---

# 30. Evolution Traceability

```text
Signal / Feedback / Outcome / Incident
  -> Fact and evidence
  -> Validated insight
  -> Evolution candidate
  -> Decision
  -> Product OS route
  -> Changed baseline
  -> Delivery and release
  -> Realized outcome
  -> G8 review
```

---

# 31. Sunset Traceability

```text
Lifecycle trigger
  -> Sunset decision
  -> Affected users and obligations
  -> Replacement / migration
  -> Data disposition
  -> Integration and access shutdown
  -> Communication and support
  -> Verification
  -> Retirement evidence
  -> Final ownership and archive
```

---

# 32. Standards Traceability Chain

```text
Standard / Profile / Criterion
  -> GOV-009 Applicability Decision
  -> Business Obligation
  -> Product Responsibility
  -> Requirement
  -> Experience / Design Obligation
  -> Architecture Control / Mechanism
  -> Engineering Allocation
  -> Implementation Evidence
  -> Verification Result / Evidence
  -> Release Decision
  -> Live Control / Operational Evidence
  -> Change Trigger / Exception / Incident
```

---

# 33. Standards Coverage Status

```text
TRIGGER_CAPTURED
EVIDENCE_PENDING
APPLICABLE
NOT_APPLICABLE
BUSINESS_LINKED
PRODUCT_LINKED
REQUIREMENT_DERIVED
DESIGN_AND_ARCHITECTURE_ALLOCATED
IMPLEMENTED
VERIFIED
OPERATING_EFFECTIVELY
EXCEPTION_ACTIVE
REVIEW_REQUIRED
RETIRED
```

These are separate dimensions in implementation; do not collapse them into one optimistic status.

---

# 34. Accessibility Thread

| Phase span | Required trace contribution |
|---|---|
| 00–01 | User needs, platform / document / language triggers, barriers, evidence |
| 02–03 | Business obligation, product responsibility, affected capabilities and channels |
| 04 | Verifiable accessibility requirements and acceptance |
| 05 | Journey, input, focus, state, error, recovery, content, and assistive behavior |
| 06 | Tokens, components, screens, contrast, reflow, touch, motion, content, outputs |
| 07 | Platform, document, identity, notification, third-party, and technical mechanisms |
| 08–09 | Work allocation, implementation, source and adoption evidence |
| 10 | Automated, manual, assistive-technology, document, and critical-journey evidence |
| 11 | Complaints, regressions, support, monitoring, communication, evolution, and live evidence |

---

# 35. Security and Identity Thread

| Phase span | Required trace contribution |
|---|---|
| 00–01 | Assets, actors, threats, data, environments, external exposure |
| 02–03 | Business controls, roles, product policies, administrative responsibility |
| 04 | Security, authentication, session, authorization, tenancy, abuse requirements |
| 05–06 | Secure journeys, recovery, sensitive states, messages, permissions, destructive actions |
| 07 | Threat model, trust boundaries, controls, identity, sessions, authorization mechanisms |
| 08–09 | Security work, reviews, configuration, secrets, supply chain, implementation evidence |
| 10 | Security verification, abuse cases, authn/authz/tenancy evidence, release handling |
| 11 | Vulnerability, access, detection, incident, patch, rotation, control-health evidence |

---

# 36. Privacy Thread

| Phase span | Required trace contribution |
|---|---|
| 00–01 | Data categories, user context, markets, vendors, privacy triggers |
| 02–03 | Purpose, policy, business control, product collection and rights responsibility |
| 04 | Collection, minimization, consent, rights, retention, deletion, export requirements |
| 05–06 | Notice, consent, preference, rights, error, sensitive-content experience |
| 07 | Data flows, stores, processors, residency, retention, deletion, access mechanisms |
| 08–09 | Allocated controls, schemas, jobs, vendors, configuration, evidence |
| 10 | Rights, retention, deletion, export, disclosure, and data-handling verification |
| 11 | Rights operations, retention jobs, deletion evidence, complaints, incidents, vendor change |

---

# 37. Data Thread

| Phase span | Required trace contribution |
|---|---|
| 00–01 | Known sources, current data, quality and ownership questions |
| 02–03 | Business concepts, product information responsibility, lifecycle and states |
| 04 | Semantics, integrity, quality, lifecycle, migration, ownership requirements |
| 05–06 | Data presentation, input, empty/error states, tables, visualization, outputs |
| 07 | Ownership, models, stores, lineage, transactions, concurrency, retention, migration |
| 08–09 | Schema, migration, backfill, repository, validation, implementation evidence |
| 10 | Integrity, migration, reconciliation, performance, rollback and recovery evidence |
| 11 | Quality, reconciliation, repair, drift, retention, deletion, backup and realized use |

---

# 38. Reliability and Recovery Thread

| Phase span | Required trace contribution |
|---|---|
| 00–03 | Criticality, business impact, minimum safe product, continuity expectations |
| 04 | Availability, resilience, failure, recovery, RTO / RPO, integrity requirements |
| 05–06 | Degraded, retry, timeout, offline, interruption, recovery, feedback states |
| 07 | Failure modes, redundancy, backpressure, reconciliation, backup, restore, DR |
| 08–09 | Work allocation, infrastructure, observability, runbooks, implemented controls |
| 10 | Failure, performance, backup, restore, DR, rollout, rollback, recovery verification |
| 11 | SLOs, incidents, problem management, exercises, continuity, capacity and error budgets |

---

# 39. Localization, RTL, Time, and Money Thread

| Phase span | Required trace contribution |
|---|---|
| 00–03 | Markets, languages, scripts, currencies, calendars, channels, product scope |
| 04 | Formatting, calculation, precision, localization, RTL, fallback requirements |
| 05–06 | Bidirectional flow, content, layout, typography, truncation, inputs, documents |
| 07 | Locale services, timezone storage, money types, generated-output mechanisms |
| 08–09 | Resource pipelines, implementation, content versions, evidence |
| 10 | Locale / RTL / time / currency / output verification across supported variants |
| 11 | Translation freshness, RTL regression, time and money incidents, support and evolution |

---

# 40. Audit and Evidence Thread

| Phase span | Required trace contribution |
|---|---|
| 00–03 | Evidence needs, authority, business events, control and product obligations |
| 04 | Auditable event, actor, subject, time, context, outcome, integrity requirements |
| 05–06 | User-visible history, confirmation, sensitive actions, content and state evidence |
| 07 | Event model, protection, retention, access, retrieval, integrity mechanisms |
| 08–09 | Work and implementation evidence, source, configuration, logging, storage |
| 10 | Audit completeness, integrity, retrieval, evidence chain, decision records |
| 11 | Operating effectiveness, evidence freshness, access, requests, incidents, retention |

---

# 41. Vendor and Integration Thread

| Phase span | Required trace contribution |
|---|---|
| 00–03 | Existing vendors, business dependency, product boundary, contractual triggers |
| 04 | Integration behavior, failure, security, data, compatibility, service requirements |
| 05–06 | Third-party journeys, redirects, states, errors, notices, branded / embedded UI |
| 07 | Contracts, callbacks, events, trust, quotas, fallback, reconciliation, exit architecture |
| 08–09 | Credentials, sandbox, contracts, implementation, feature flags, evidence |
| 10 | Contract, failure, quota, fallback, rollout, target, and vendor-readiness verification |
| 11 | Health, incidents, advisories, cost, contract, renewal, concentration, migration, exit |

---

# 42. Traceability Views

The graph supports derived views:

```text
Source-to-decision view
Goal-to-capability view
Capability-to-requirement view
Requirement-to-release view
Journey-to-screen-to-component view
Architecture-to-code view
Standard-to-control-to-evidence view
Data-lifecycle view
Risk-to-control-to-monitoring view
Defect-to-fix-to-regression view
Release-to-live-signal view
Incident-to-corrective-action view
Signal-to-evolution-to-outcome view
Sunset-to-data-disposition view
```

---

# 43. Requirement-to-Release View

Minimum columns:

```text
Requirement ID / version
Source and product responsibility
Acceptance criteria
Experience objects
Design objects
Architecture mechanisms
Engineering slices and work items
Implementation references
Verification cases / results / evidence
VBL status
Release scope and G7 decision
Live version and operational signal
Outcome / incident / evolution links
```

---

# 44. Standard-to-Evidence View

Minimum columns:

```text
Standard / profile / criterion
GOV-009 applicability status
Business interpretation and owner
Product responsibility
Requirements
Experience and design obligations
Architecture controls
Implementation mechanisms
Verification methods and evidence
Release scope
Live control status and period evidence
Exception / incident / change trigger
```

---

# 45. Release Coverage View

For each release item show:

```text
RSCP item
Candidate artifact and digest
Included requirement / defect / change
Source baselines
Verification coverage
Waivers and residual risk
Target and rollout
Production validation
Actual live scope
Phase 11 owner and signals
```

---

# 46. Operational Outcome View

For each intended outcome show:

```text
Problem and product objective
Capability and requirements
Released change
Live population
Product and service measures
Support and incident effects
Cost and control guardrails
Realized value and uncertainty
Evolution decision
```

---

# 47. Change Propagation Algorithm

The graph-discovery part of this algorithm is governed by [Traceability Graph](Traceability_Graph/Traceability_Graph_Index.md). Materiality, final disposition, `NO_IMPACT`, remediation, proportional re-review, gate/baseline reopen, acknowledgement, and closure are governed by [Change Impact Rules](Change_Impact_Rules/Change_Impact_Rules_Index.md).

```text
1. Bind exact changed object, old/new versions, scope, source event, and graph revision.
2. Traverse direct, transitive, dependency, governance, evidence, gate, release, live, and lifecycle paths as applicable.
3. Preserve confirmed candidates plus missing, conflicted, inaccessible, and truncated branches.
4. Assess every candidate or retain an explicit unresolved state.
5. Normalize legacy PARTIAL to PARTIALLY_AFFECTED and INVALID to INVALIDATED; assign exact object dispositions.
6. Decide materiality and the actual earliest owning phase with valid authority.
7. Reopen the exact affected baseline/gate scope and assess downstream decisions proportionally.
8. Update or supersede GOV-002 identities and GOV-008 edges; reevaluate GOV-009 triggers.
9. Invalidate and replace affected verification/evidence; create owned actions and due events.
10. Preserve historical versions, obtain downstream acknowledgements, and close or reopen through GOV-007.
```

---

# 48. Upstream Change Examples

```text
Business policy change
  -> BBL
  -> PBL / RBL / EBL / DBL / ABL
  -> ERBL / IBL / VBL / Release / OBL impact review

Design token correction with no semantic change
  -> DBL
  -> affected components / screens / implementation / verification
  -> no automatic PBL or RBL reopen

Vendor API retirement
  -> Phase 11 signal
  -> ABL or earlier depending product impact
  -> readiness / implementation / verification / release
```

---

# 49. Downstream Failure Examples

```text
Verification failure caused by ambiguous requirement
  -> defect
  -> RBL review
  -> downstream baseline impact

Production incident caused by missing retry architecture
  -> incident / problem
  -> ABL reopen
  -> ERBL / IBL / VBL / G7

Low adoption caused by wrong problem assumption
  -> Phase 11 insight
  -> DSBL / Phase 01 reopen
```

---

# 50. Evidence Link Contract

Evidence links include:

```text
Evidence ID
Claim supported
Object / baseline / candidate / live scope
Producer and source system
Method
Timestamp and period
Environment or target
Integrity reference
Classification and access
Retention
Review status
Invalidation trigger
```

---

# 51. Evidence Freshness

Evidence freshness depends on claim type:

```text
Discovery evidence      -> context and market change
Design validation       -> design or audience change
Architecture analysis   -> mechanism or dependency change
Implementation evidence -> source / artifact / configuration change
Verification evidence   -> candidate / environment / obligation change
Release evidence        -> candidate / target / window change
Operational evidence    -> period / live change / incident / drift
```

---

# 52. Evidence Invalidation

Invalidation does not delete evidence.

It marks that the evidence no longer supports the current claim and records trigger, affected scope, replacement, and decision impact.

---

# 53. Physical Storage

Trace nodes and evidence may live in:

```text
Markdown or document artifacts
Requirements systems
Figma and design libraries
Architecture repositories
Source control and artifact registries
CI/CD and test systems
Evidence stores
Release and change systems
Observability and incident systems
Support and research tools
Portfolio systems
```

The graph uses stable references, not tool-specific assumptions.

---

# 54. Canonical Object Reference

```yaml
object_ref:
  object_type: DESIGN_COMPONENT
  object_id: DES-COMP-012
  baseline: DBL-2026-001
  source_system: figma
  source_locator: canonical_node_reference
  owner: design_system_owner
  status: BASELINED
  last_verified_at: null
```

---

# 55. Repository Reference

Source and implementation links use exact repository identity, path, revision, artifact, build, and deployment relationships.

Generic labels such as `backend`, `frontend`, `mobile`, or `database` cannot replace canonical project identities.

---

# 56. Design Reference

Design traces identify canonical file, page, node or component, version or branch where available, library source, instance / adoption target, and validation evidence.

A visual screenshot alone is not canonical design identity.

---

# 57. Runtime Reference

Runtime traces identify organization, project, environment, service, region, domain, artifact, configuration, data stores, version, flags, cohorts, and evidence period.

---

# 58. P1 Traceability

P1 may use one composite coverage view but retains required identities, source links, decisions, verification, evidence, release, and operational outcomes.

Composite does not mean implicit.

---

# 59. P2 Traceability

P2 maintains separate phase matrices or graph views with a consolidated cross-phase index and automated consistency where practical.

---

# 60. P3 Traceability

P3 uses detailed typed edges, specialist control views, stronger evidence integrity, formal change impact, segregation, retention, and periodic traceability audits.

---

# 61. Domain Override

A P1 project may require P3 traceability for security, privacy, accessibility, data, finance, safety, regulated outputs, or another critical domain.

---

# 62. Traceability Ownership

```text
Phase owner          Owns local object correctness
Artifact owner       Owns source content and version
Governance owner     Owns edge vocabulary and graph rules
Gate authority       Accepts coverage for the gate scope
Evidence owner       Owns evidence integrity and access
Operations owner     Owns live identity and period evidence
Evolution owner      Owns signal-to-decision and realized outcome
```

---

# 63. AI Role

The complete governing contract is the [AI Operating Specification](./AI_Operating_Specification/AI_Operating_Specification_Index.md). This section retains the traceability-specific contribution boundary.

AI may assist with:

```text
Candidate edge discovery
Source and object classification
Orphan detection
Coverage gap analysis
Change-impact traversal
Duplicate and conflict discovery
Evidence indexing
Traceability view generation
Stale link and version detection
Incident and evolution correlation
```

---

# 64. AI Boundaries

AI does not:

```text
Invent missing sources or approvals
Convert inference into confirmed trace
Declare requirement satisfaction from a code keyword
Declare component adoption from source existence
Declare compliance from document presence
Accept NOT_APPLICABLE, exception, or risk
Approve gate coverage
Hide ambiguity through guessed links
```

---

# 65. Traceability Validation Rules

```text
TR-VAL-01  Every baselined object has canonical ID, type, version, owner, and scope.
TR-VAL-02  Every approved requirement reaches an approved source or obligation.
TR-VAL-03  Every included product capability has requirement disposition.
TR-VAL-04  Every included critical requirement has experience, architecture, or direct-allocation treatment as applicable.
TR-VAL-05  Every critical journey maps to requirements, states, and validation.
TR-VAL-06  Every baselined screen maps to an experience object and requirement or approved design rationale.
TR-VAL-07  Every implementation object maps to a work item, defect, control, or approved operational change.
TR-VAL-08  Every material source change maps to exact revision and review evidence.
TR-VAL-09  Every verification case maps to an obligation, risk, defect, or charter purpose.
TR-VAL-10  Every verification result binds candidate, environment, method, and evidence.
TR-VAL-11  Every release item is covered by the accepted VBL or governed waiver.
TR-VAL-12  Every release authorization binds exact candidate, target, scope, window, and strategy.
TR-VAL-13  Every live product identity maps to actual release execution or governed brownfield intake.
TR-VAL-14  Every critical SLO maps to a user or service outcome and response policy.
TR-VAL-15  Every material incident maps to impact, evidence, actions, and affected baseline analysis.
TR-VAL-16  Every corrective action maps to verification and closure evidence.
TR-VAL-17  Every evolution candidate maps to signals, insight, decision, and route.
TR-VAL-18  Every realized-outcome claim maps to live population, period, measures, and uncertainty.
TR-VAL-19  Every applicable GOV-009 item has an unbroken obligation-to-live-evidence chain or visible gap.
TR-VAL-20  Every NOT_APPLICABLE edge has reason, scope, evidence, authority where required, and reopen trigger.
TR-VAL-21  Every exception preserves the original obligation and expiry.
TR-VAL-22  Every superseded object retains historical relationships.
TR-VAL-23  Every baseline change triggers downstream impact classification.
TR-VAL-24  Inferred and assumed edges are not counted as confirmed gate coverage.
TR-VAL-25  Trace direction follows controlled edge semantics.
TR-VAL-26  Link count is not used as a substitute for semantic coverage.
TR-VAL-27  Canonical source identity is not replaced by screenshots or generic labels.
TR-VAL-28  Evidence period and freshness match the claim.
TR-VAL-29  Retirement traces include users, data, integrations, access, resources, and evidence.
TR-VAL-30  GOV-008 remains the graph source; phase matrices are derived views.
TR-VAL-31  Every artifact node resolves to one canonical GOV-002 entry and lifecycle identity.
TR-VAL-32  Every constitutional or standards obligation traces through GOV-001 and GOV-009 without merging their responsibilities.
```

---

# 66. Automated Checks

Tooling should detect:

```text
Duplicate IDs
Unknown object types or edges
Missing versions
Broken references
Orphan requirements, screens, components, ADRs, work items, tests, release items, and signals
Invalid edge direction
Stale evidence
Superseded-source links
Unresolved conflicts
Applicable standards without downstream coverage
Implemented objects without approved source
Release items outside VBL
Live services outside operational ownership
Evolution candidates without route
Retired scope with active traffic, access, data, or cost
```

---

# 67. Traceability Anti-Patterns

```text
TR-AP-01  Treating a spreadsheet cell as proof without source identity.
TR-AP-02  Linking everything to a broad epic instead of the actual obligation.
TR-AP-03  Creating requirements directly from raw suggestions without decision lineage.
TR-AP-04  Mapping a feature to itself across phases under different names.
TR-AP-05  Using file presence as implementation evidence.
TR-AP-06  Using source existence as active product adoption evidence.
TR-AP-07  Mapping screenshots instead of canonical design objects.
TR-AP-08  Mapping repositories with generic backend / frontend labels.
TR-AP-09  Counting inferred edges as approved coverage.
TR-AP-10  Omitting versions from baseline links.
TR-AP-11  Keeping links active after source supersession.
TR-AP-12  Hiding contradictions by choosing one source silently.
TR-AP-13  Mapping every requirement directly to one end-to-end test.
TR-AP-14  Treating a test pass as complete requirement satisfaction across all variants.
TR-AP-15  Treating implementation checks as independent verification.
TR-AP-16  Treating VBL coverage as release authorization.
TR-AP-17  Treating deployment as operational health.
TR-AP-18  Treating usage as realized user value.
TR-AP-19  Losing defect history after retest.
TR-AP-20  Losing the original obligation after a waiver.
TR-AP-21  Copying GOV-009 into phase-local competing matrices.
TR-AP-22  Marking a gap NOT_APPLICABLE to improve coverage.
TR-AP-23  Restarting every phase after any small change.
TR-AP-24  Failing to reopen upstream decisions after production evidence contradicts them.
TR-AP-25  Linking incidents only to fixes and not to affected baselines.
TR-AP-26  Routing every evolution signal straight to implementation.
TR-AP-27  Closing outcome traceability when a feature ships.
TR-AP-28  Removing historical edges during re-baselining.
TR-AP-29  Building one mandatory traceability file that becomes stale and unowned.
TR-AP-30  Claiming complete traceability because every row has some link.
```

---

# 68. Traceability Health Measures

Useful measures:

```text
Required-edge coverage by phase and concern
Confirmed vs inferred edge ratio
Orphan count and age
Broken-reference count
Stale-evidence count
Superseded-link cleanup time
Applicable-standard chain gaps
Requirement-to-verification gaps
Release-outside-VBL count
Incident-to-baseline-analysis coverage
Evolution-to-route coverage
Outcome-validation completion
Traceability-driven gate reopen rate
```

---

# 69. Metric Guardrail

Do not optimize link quantity.

A smaller graph with correct identities and meaningful relationships is stronger than a dense graph of generic, stale, or circular links.

---

# 70. Traceability Review Cadence

Review:

```text
Before every gate
After baseline change
After candidate change
Before G7
After release execution
After material incident
During G8
Before deprecation or sunset
On source-system migration
On standards applicability change
```

---

# 71. Gate Traceability Pack

Each gate receives a derived view showing:

```text
Required source baselines
Scope objects
Required cross-cutting obligations
Coverage state
Orphans and conflicts
Conditions and exceptions
Evidence status
Changed / invalidated links
Downstream handoff completeness
```

---

# 72. Example — Accessibility Obligation

```text
Source criterion
  -> GOV-009 item ACC-001 = APPLICABLE
  -> BUS control CTRL-ACC-01
  -> Product capability PCAP-ACCESS-01
  -> RBL requirements ACC-REQ-001..006
  -> EBL journey / state / focus obligations
  -> DBL component and screen variants
  -> ABL platform / document / notification mechanisms
  -> ERBL work and evidence allocation
  -> IBL source / design-system adoption
  -> VCASE / VRES / VEVID assistive-technology evidence
  -> VBL and G7 release scope
  -> OBL accessibility control health and support signals
  -> OSIG regression
  -> ROUTE to earliest affected baseline
```

---

# 73. Example — Production Incident

```text
SLI-CHECKOUT-SUCCESS breach
  -> OINC-2026-004
  -> impact: duplicate financial operation
  -> containment: disable retrying path
  -> problem: idempotency architecture gap
  -> ABL reopen
  -> RBL acceptance update if necessary
  -> ERBL remediation slice
  -> IBL source and migration changes
  -> VBL concurrency / idempotency evidence
  -> G7 constrained rollout
  -> OBL updated control and recurrence signal
  -> corrective action closure evidence
```

---

# 74. Example — Evolution Opportunity

```text
Support pattern + abandonment metric + user research
  -> OSIG / FEED
  -> INS: users cannot understand approval status
  -> EVCAND: improve status comprehension
  -> EVDEC: approve for Phase 05 route
  -> EBL state and content responsibility update
  -> DBL screen and message changes
  -> ABL / RBL review for unaffected carry-forward
  -> ERBL / IBL / VBL / G7
  -> OBL adoption and support outcome validation
```

---

# 75. Minimum Cross-Phase Matrix

When a graph platform is unavailable, use a controlled matrix with at least:

```text
Object ID and type
Object version and baseline
Title / purpose
Source IDs
Decision ID
Upstream links and edge types
Downstream links and edge types
Scope / release / profile
Owner
Status and disposition
Verification and evidence
Gate decision
Live / evolution link
Change and reopen state
```

---

# 76. Matrix Limitation

The matrix is a projection.

Many-to-many relationships, historical versions, evidence periods, and lifecycle branches may require separate normalized tables or a graph store.

---

# 77. Master Traceability Outputs

```text
Canonical node and edge vocabulary
Cross-phase baseline chain
Required inter-phase edges
Concern-specific trace paths
Coverage and orphan rules
Change-propagation logic
Gate traceability pack contract
Operational and evolution feedback loop
Lifecycle and retirement traceability
Validation and anti-pattern rules
```

---

# 78. Maintenance

Update this contract when object types, edge semantics, baseline IDs, gate requirements, evidence systems, standards lineage, operational signals, or lifecycle routing change.

Existing graph data requires migration or explicit compatibility handling when semantics change.

---

# 79. Final Principle

> **Cross-phase traceability is complete when every material Product OS claim can be followed backward to legitimate evidence and authority, forward to realization and operation, and back again from production learning to the earliest decision that must change—without replacing source truth with links or link counts.**
