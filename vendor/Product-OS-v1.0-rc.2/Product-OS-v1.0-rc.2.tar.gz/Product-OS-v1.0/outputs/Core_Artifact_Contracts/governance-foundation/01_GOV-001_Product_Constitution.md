# Core Artifact Contract — GOV-001 Product Constitution

~~~yaml
contract_id: CONTRACT-GOV-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-001
artifact_name: Product Constitution
owning_phase: Cross-phase Governance
gate_or_baseline: Governs all baselines and gates
default_activation: ALWAYS_REQUIRED_FOR_PRODUCT_OS_SCOPE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_downstream: GOV-002, GOV-009, and every activated artifact
~~~

---

# 1. Purpose

GOV-001 is the highest project / product governance artifact beneath the Product OS framework authority. It fixes the principles, non-negotiables, mandatory standards, authority model, minimum quality and assurance baselines, AI boundaries, and universal control rules that every phase, artifact, gate, role, tool, automation, and agent must respect.

It answers: **What rules govern this project or product regardless of the current phase?**

GOV-001 is not a project plan, standards applicability matrix, requirements catalog, decision log, or exception register.

---

# 2. Scope and Applicability

GOV-001 is always required for scope operating under Product OS. It may adopt approved Product OS framework rules by reference and add project- or product-specific rules, but it cannot silently weaken mandatory framework obligations.

NOT_APPLICABLE is not a valid state for an in-scope Product OS project. If the work is outside Product OS, that boundary is recorded by accountable authority before the methodology is claimed to apply.

---

# 3. Accountabilities

- **Owner:** accountable product / project governance authority.
- **Approvers:** authorities empowered to establish or change constitutional rules.
- **Rule owners:** named authorities for quality, security, privacy, accessibility, data, audit, reliability, AI, legal / compliance, and other activated domains.
- **Reviewers:** independent or specialist reviewers required by profile, risk, contract, regulation, or rule.
- **Consumers:** every Product OS phase, artifact, gate, human role, tool, automation, and AI agent.
- **AI:** may draft, compare, trace, and detect conflicts; it cannot establish, weaken, waive, or approve constitutional rules.

The [AI Operating Specification](../../AI_Operating_Specification/AI_Operating_Specification_Index.md) defines the framework-level identity, instruction, action, authority, human-control, execution, evidence, safety, multi-agent, monitoring, evaluation, and incident semantics that each active constitution may strengthen or scope but cannot silently weaken.

---

# 4. Required Inputs

1. Product OS Architecture and mandatory framework standards.
2. Project / product identity, authority, ownership, and operating context.
3. Applicable organizational policies and approved governance models.
4. Known contractual, regulatory, market, platform, data, user, risk, and assurance context.
5. Existing constitutional decisions and governed exceptions for brownfield work.
6. Evidence of any claimed non-negotiable constraint or mandatory baseline.

---

# 5. Required Questions

1. Which Product OS framework rules and universal standards are mandatory for this scope?
2. Which project / product principles and non-negotiables apply across every phase?
3. Who has information, decision, approval, exception, gate, release, risk-acceptance, and operational authority?
4. Which minimum quality, verification, evidence, and traceability rules cannot be reduced by profile packaging?
5. Which security, privacy, accessibility, data, audit, reliability, continuity, safety, localization, and AI baselines apply universally?
6. Which decisions require independent review or segregation of duties?
7. Which rule conflicts or exceptions are possible, who may authorize them, and how do they expire?
8. How are constitutional changes versioned, propagated, verified, and reopened?
9. Which topics belong in GOV-009 applicability rather than GOV-001?
10. Can every downstream artifact identify the exact constitution version governing it?

---

# 6. Required Decisions

- constitution scope and effective boundary;
- adopted Product OS framework rules and mandatory standards;
- principles and non-negotiables;
- authority and approval model;
- minimum quality, assurance, verification, evidence, and gate rules;
- universal domain baselines and prohibited practices;
- AI responsibilities, permissions, and prohibitions;
- exception, waiver, conflict, and escalation authority;
- version, effective date, supersession, review cadence, and change route.

---

# 7. Minimum Constitution Content

GOV-001 contains or references:

1. Constitution ID, version, owner, approvers, effective date, and scope.
2. Product OS framework authority and adopted mandatory rules.
3. Governing principles and non-negotiables.
4. Authority, delegation, approval, segregation, and escalation model.
5. Minimum artifact, source, decision, traceability, verification, evidence, gate, handoff, and change-control rules.
6. P1 / P2 / P3 limitations and domain-level escalation rules.
7. Mandatory quality and assurance baseline.
8. Security, privacy, identity, accessibility, audit, data, reliability, continuity, safety, localization, and other universal baselines as approved.
9. AI operating rules and human authority boundaries.
10. Confidentiality, retention, evidence-integrity, and secret-handling rules.
11. Exception / waiver policy, authority, expiry, evidence, and enforcement.
12. GOV-009 activation boundary and propagation expectation.
13. Constitutional change, impact, supersession, and review rules.
14. Open constitutional decisions and blocking conflicts.

---

# 8. GOV-001 / GOV-009 Separation

GOV-001 defines the governing rule or baseline. GOV-009 determines whether a standard or conditional profile applies to the exact project context, why it applies, and which downstream obligations it activates.

Example relationship:

~~~text
GOV-001 Rule
Accessibility is a core Product OS standard.
Target baseline is WCAG 2.2 AA.

GOV-009 Project Disposition
Accessibility profile = APPLICABLE
Triggers = Web + Mobile + Generated PDFs + Arabic RTL + English LTR
Propagation = BUS → PROD → REQ → EXP → DES → ARC → ENG → IMP → VRL → OPS
~~~

GOV-009 may refine applicability and propagation but cannot weaken the constitutional baseline without an authorized GOV-001 change or exception.

---

# 9. Traceability and Handoff

Minimum path:

~~~text
Product OS Framework Rule / Authorized Governance Source
→ GOV-001 Rule
→ GOV-009 Applicability or Universal Activation
→ Phase Obligation / Artifact Contract / Gate Check
→ Verification and Evidence
→ Operational Control and Review
~~~

Every activated artifact records the governing GOV-001 version in GOV-002. Every gate confirms constitution conformance or an authorized, unexpired exception.

---

# 10. Profile Behavior

- **P1:** constitutional rules may be presented compactly or adopted by reference, but no mandatory rule, authority boundary, control, or evidence obligation disappears.
- **P2:** major governance domains have explicit owners, reviews, exceptions, and traceability.
- **P3:** independent assurance, segregation, formal approval, evidence retention, regulatory mapping, and constitutional change control strengthen.

Profile selection changes implementation depth and packaging, not constitutional authority.

---

# 11. Verification and Evidence

Verification confirms:

- the constitution derives from authorized framework and governance sources;
- scope, version, owner, approvers, and effective date are valid;
- no lower-level contract or baseline silently weakens a rule;
- authority, exception, and expiry rules are enforceable;
- all activated artifacts identify the governing constitution version;
- GOV-009 activates and propagates standards without becoming a duplicate constitution;
- constitutional changes have GOV-007 impact analysis and GOV-008 traversal.

---

# 12. Exit Criteria

GOV-001 is ACTIVE only when its scope, principles, non-negotiables, authority, baselines, AI rules, domain rules, exception model, version, effective date, evidence, and downstream propagation are approved and all blocking conflicts are resolved.

An in-progress constitution cannot be treated as silent permission. Interim authority and conditions must be explicit.

---

# 13. Reopen Conditions

Reopen on a material Product OS framework, organizational policy, authority, standard, regulation, contract, market, platform, data, user, risk, quality, AI, security, privacy, accessibility, audit, reliability, continuity, evidence, or governance-model change.

Every constitutional change updates GOV-007, GOV-002, GOV-008, affected GOV-009 entries, dependent baselines, verification, evidence, and gates.

---

# 14. Artifact-Specific Validation Rules

~~~text
GOV1-CVAL-001  Every in-scope project has exactly one active governing constitution version.
GOV1-CVAL-002  Every constitutional rule has authority, scope, rationale, and effective version.
GOV1-CVAL-003  Lower-level artifacts cannot silently weaken constitutional obligations.
GOV1-CVAL-004  Profiles cannot remove mandatory constitutional rules.
GOV1-CVAL-005  Every exception has authority, scope, evidence, expiry, and reopen conditions.
GOV1-CVAL-006  GOV-001 governs standards; GOV-009 owns project applicability and propagation.
GOV1-CVAL-007  AI cannot approve or waive a constitutional rule.
GOV1-CVAL-008  Material constitutional change triggers cross-phase impact and revalidation.
~~~
