# Core Artifact Contract — GOV-002 Artifact Register

~~~yaml
contract_id: CONTRACT-GOV-002
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-002
artifact_name: Artifact Register
owning_phase: Cross-phase Governance
gate_or_baseline: Governs artifact identity at every gate and baseline
default_activation: ALWAYS_REQUIRED_FOR_PRODUCT_OS_SCOPE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-001 and Master Artifact Catalog
primary_downstream: Every activated artifact, GOV-008, and every gate
~~~

---

# 1. Purpose

GOV-002 is the central project Artifact Register. It provides one canonical identity and lifecycle record for every activated logical artifact regardless of whether its content lives in Markdown, Figma, Git, a requirements tool, a database, a ticketing system, CI, a test platform, an evidence store, or an operational system.

It answers: **Which artifacts exist for this project, who owns them, which version and status are current, where is the canonical content, what do they depend on, and what approval or supersession state applies?**

GOV-002 registers artifacts; it does not duplicate their full content.

---

# 2. Scope and Applicability

GOV-002 is always required for Product OS scope. Every activated artifact, governed NOT_APPLICABLE record, baseline, handoff, gate-evidence package, and material external canonical artifact has a discoverable register entry.

NOT_APPLICABLE is not valid for GOV-002 itself. Individual catalog artifacts may be NOT_APPLICABLE only through their own contract and recorded evidence.

---

# 3. Accountabilities

- **Owner:** project governance or artifact-management authority.
- **Entry owners:** canonical artifact owners accountable for content identity and current metadata.
- **Approvers:** authorities responsible for approval or activation of each artifact where required.
- **Tool owners:** maintain connector, location, access, and revision integrity without becoming content authority.
- **Gate authorities:** consume scoped GOV-002 views to confirm artifact identity and readiness.
- **AI:** may classify, register, reconcile, and detect drift; it cannot invent an artifact, owner, status, version, approval, location, or supersession.

---

# 4. Required Inputs

1. Master Artifact Catalog and applicable Core Artifact Contracts.
2. Active GOV-001 constitution version and profile / domain overrides.
3. Project identity and activated lifecycle route.
4. Canonical artifact sources and exact tool / repository / file / node / record identities.
5. Owners, contributors, reviewers, approvers, and decision authorities.
6. Artifact versions, status dimensions, dependencies, approvals, evidence, and supersession history.
7. Applicability decisions and NOT_APPLICABLE records.

---

# 5. Required Questions

1. Which logical artifact IDs are activated, pending, NOT_APPLICABLE, superseded, stale, retired, or missing?
2. What is the exact name, family, type, owning phase, contract, profile treatment, and canonical owner of each artifact?
3. Where does canonical content live and which exact version or revision is current?
4. Which artifact-production, applicability, decision, verification, approval, and registry lifecycle statuses apply?
5. Which dependencies, downstream consumers, baseline, gate, GOV-008, and GOV-009 links apply?
6. Which approval, acknowledgement, exception, or condition governs current use?
7. Has a material upstream change made the GOV-002 entry STALE or the change-impact assessment REVIEW_REQUIRED?
8. Which artifact supersedes another, and can the full history be reconstructed?
9. Are multiple tool records competing for canonical ownership?
10. Can every gate resolve the exact artifact set and versions under decision?

---

# 6. Required Decisions

- artifact activation and applicability record;
- stable artifact ID, name, family, type, and owning phase;
- canonical owner and canonical location / system;
- governing contract and constitution version;
- registry lifecycle status and all independent status dimensions;
- version, baseline, approval, dependency, and traceability identity;
- supersession, staleness, retirement, archival, and retention disposition;
- missing, duplicate, conflicting, or orphaned artifact resolution.

---

# 7. Minimum Artifact Entry

Every GOV-002 entry supports:

~~~yaml
artifact_id:
artifact_name:
artifact_family:
artifact_type:
owning_phase:
contract_id:
contract_version:
constitution_version:
project_id:
profile:
domain_profile:
activation_class:
applicability:
registry_lifecycle_status:
artifact_status:
decision_status:
verification_status:
approval_status:
artifact_version:
baseline_id:
canonical_owner:
contributors: []
reviewers: []
approvers: []
decision_authority:
canonical_location:
external_system_refs: []
depends_on: []
feeds_into: []
gov_008_node:
gov_009_entries: []
source_refs: []
evidence_refs: []
conditions: []
exceptions: []
created_at:
last_updated:
effective_at:
next_review:
supersedes:
superseded_by:
retention:
access_class:
reopen_conditions: []
~~~

The final machine-readable schema may refine representation but cannot remove these logical obligations without contract change control.

---

# 8. Status Separation

Registry lifecycle status uses:

~~~text
DRAFT
ACTIVE
SUPERSEDED
STALE
RETIRED
~~~

This status is separate from:

- artifact production status such as IN_PROGRESS or COMPLETE;
- applicability such as APPLICABLE or NOT_APPLICABLE;
- decision status such as APPROVED or REJECTED;
- verification status such as VERIFIED or FAILED;
- approval status defined by the relevant artifact or gate contract.

For example, an ACTIVE artifact may be COMPLETE but have PARTIAL verification; a NOT_APPLICABLE artifact record may remain ACTIVE as the current governed disposition; a previously approved version may become STALE after an upstream change.

---

# 9. Canonical Identity and Tool Boundary

One logical artifact has one GOV-002 identity even when its content is distributed across governed systems. The entry records each exact external identity and declares which source owns which meaning.

Multiple files, Figma nodes, repository revisions, test records, or evidence items do not create multiple logical artifacts unless the Master Artifact Catalog and contract define them separately.

A phase-local artifact index, repository manifest, Figma page, or spreadsheet is a scoped GOV-002 view unless explicitly designated as the canonical register implementation.

---

# 10. Traceability and Gate Use

Minimum path:

~~~text
Master Artifact Catalog + Contract
→ Project Activation / Applicability
→ GOV-002 Entry
→ Canonical Artifact Version / Location / Owner
→ GOV-008 Relationships + GOV-009 Entries
→ Baseline / Handoff / Gate Evidence
→ Status, Supersession, or Reopen
~~~

Every gate consumes a frozen or reproducible GOV-002 scope view identifying required, provided, missing, NOT_APPLICABLE, stale, superseded, and conditional artifacts.

---

# 11. Profile Behavior

- **P1:** the register may be a compact governed index, but stable IDs, status separation, ownership, version, location, dependencies, approval, and history remain.
- **P2:** artifact families and status workflows are modular, with validation, access, and change controls.
- **P3:** independent registry assurance, stronger provenance, segregation, immutable history, retention, access control, signatures / attestations where applicable, and automated drift detection strengthen.

Profile packaging changes representation, not logical registration.

---

# 12. Verification and Evidence

Verification confirms:

- every activated or governed N/A artifact has exactly one canonical entry;
- each entry resolves to a real canonical identity or explicit missing state;
- owner, version, location, status, dependencies, approval, and supersession are current;
- status dimensions are not conflated;
- phase indexes and tools do not create competing canonical registries;
- every gate artifact set is reproducible;
- material changes update GOV-002 and trigger GOV-007 / GOV-008 / GOV-009 impact handling.

---

# 13. Exit Criteria

GOV-002 is operational when all currently activated artifact obligations have current entries, missing and duplicate identities are governed, canonical locations and owners are resolvable, status dimensions and versions are current, supersession history is reconstructable, and gate views can be reproduced.

Because GOV-002 is persistent, operational completeness is evaluated for an exact scope and time rather than treated as permanent closure.

---

# 14. Reopen and Update Conditions

Update GOV-002 on artifact activation, applicability, creation, rename, type or phase correction, owner change, version change, approval, verification, baseline inclusion, canonical-location change, dependency change, staleness, supersession, retirement, retention, access, contract change, GOV-001 change, GOV-009 change, gate outcome, or deletion / archival event.

---

# 15. Artifact-Specific Validation Rules

~~~text
GOV2-CVAL-001  Every activated or governed N/A artifact has exactly one canonical GOV-002 entry.
GOV2-CVAL-002  Artifact ID is stable and cannot be reused for different meaning.
GOV2-CVAL-003  Registry lifecycle, artifact, applicability, decision, verification, and approval statuses remain separate.
GOV2-CVAL-004  Canonical location and version resolve to real evidence or explicit MISSING state.
GOV2-CVAL-005  Every entry names owner, governing contract, constitution version, and dependencies.
GOV2-CVAL-006  Supersession and staleness preserve reconstructable history.
GOV2-CVAL-007  Phase-local and tool-specific indexes cannot become silent competing registries.
GOV2-CVAL-008  Every gate consumes a reproducible exact-scope artifact-register view.
~~~
