# Product OS v1.0 — Shared Core Artifact Contract Standard

**Contract ID:** CORE-ARTIFACT-STANDARD  
**Version:** 0.2.0  
**Status:** Working Draft  
**Applies to:** Every Core Artifact Contract and every activated project artifact

---

# 1. Purpose

This standard defines the obligations inherited by every Product OS artifact contract.

Specialized contracts define artifact-specific purpose, content, questions, decisions, object types, validation, handoff, and reopen triggers. They do not repeat or weaken this shared standard.

---

# 2. Contract Precedence

Use this order:

1. Product OS Architecture and approved framework standards.
2. `GOV-001 — Product Constitution` and governed exceptions.
3. Current Phase Methodology Specification.
4. This Shared Core Artifact Contract Standard.
5. Specialized Core Artifact Contract.
6. Selected profile packaging and domain-level override.
7. Tool-specific representation.

A lower layer may strengthen an obligation but may not silently weaken an upper-layer obligation.

`GOV-001` governs the project / product rules. `GOV-009` activates applicable standards and profiles for the exact project context and propagates their obligations. `GOV-002` registers the artifact identities and lifecycle states that realize those rules. These responsibilities remain separate.

---

# 3. Required Metadata

Every artifact instance supports:

~~~yaml
artifact_id:
artifact_name:
contract_id:
contract_version:
artifact_version:
project_id:
owning_phase:
baseline_id:
constitution_version:
artifact_register_entry:
registry_lifecycle_status:
profile:
domain_profile:
artifact_status:
applicability:
decision_status:
verification_status:
change_impact_status:
owner:
contributors: []
reviewers: []
approvers: []
decision_authority:
depends_on: []
feeds_into: []
sources: []
evidence: []
gov_008_node:
gov_009_entries: []
confidentiality:
retention:
created_at:
last_updated:
next_review:
supersedes:
superseded_by:
~~~

Unknown values are explicit. They are not replaced with invented values.

---

# 4. Separate Status Dimensions

## Artifact status

~~~text
NOT_STARTED
IN_PROGRESS
IN_REVIEW
BLOCKED
COMPLETE
REOPENED
DEPRECATED
~~~

## Applicability

~~~text
APPLICABLE
NOT_APPLICABLE
PENDING
~~~

## Decision status

~~~text
PROPOSED
IN_REVIEW
APPROVED
DEFERRED
REJECTED
OPEN
~~~

## Verification status

~~~text
NOT_STARTED
PARTIAL
VERIFIED
FAILED
BLOCKED
~~~

## Change-impact status

~~~text
NOT_ASSESSED
NO_IMPACT
REVIEW_REQUIRED
IMPACT_CONFIRMED
REMEDIATION_REQUIRED
DISPOSITIONED
~~~

One status cannot stand in for another.

---

# 5. Applicability Contract

Every contract defines:

- default activation class;
- trigger questions;
- mandatory triggers;
- safe NOT_APPLICABLE conditions;
- authority permitted to decide applicability;
- evidence required;
- downstream implications;
- reopen triggers.

A NOT_APPLICABLE record contains:

~~~yaml
artifact_id:
applicability: NOT_APPLICABLE
reason:
decision_owner:
approved_by:
decision_date:
source_refs: []
evidence_refs: []
downstream_implications: []
reopen_conditions: []
~~~

Absence is MISSING, not NOT_APPLICABLE.

---

# 6. Source Contract

The complete cross-cutting source taxonomy, authority, reliability, claim, provenance, custody, access, and retention semantics are defined by [Source / Evidence Model](../Source_Evidence_Model/Source_Evidence_Model_Index.md). This section retains the universal minimum inherited by every artifact.

Every material claim preserves:

- stable source ID;
- source type;
- exact received identity or revision;
- authority;
- reliability / confidence;
- access classification;
- date or evidence period;
- extraction or interpretation notes;
- contradictions;
- affected object IDs.

Natural inputs are accepted. Product OS classifies them without inventing approval:

~~~text
Raw Source
→ Fact / Assumption
→ Question
→ Decision / Requirement
→ Canonical Artifact
→ Verification
→ Evidence
→ Downstream Handoff
~~~

---

# 7. Information-State Contract

Every meaningful statement is typed as one of:

~~~text
FACT
ASSUMPTION
REQUESTED_IDEA
DECISION
REQUIREMENT
OPEN_QUESTION
~~~

A REQUESTED_IDEA is not an approved requirement.

An ASSUMPTION has:

- owner;
- confidence;
- impact;
- validation method;
- due point or expiry;
- affected artifacts;
- outcome when validated or rejected.

---

# 8. Required Internal Sections

Every artifact instance contains or references:

~~~text
Purpose
Scope
Applicability
Required Inputs
Required Questions
Required Decisions
Required Outputs
Confirmed Facts
Assumptions
Decisions
Requirements / governed obligations where applicable
Open Questions
Risks and Dependencies
Verification
Evidence
Exceptions
Downstream Handoff
Exit Criteria
Reopen Conditions
Change History
~~~

Typed systems may store these as fields, linked records, diagrams, code, Figma nodes, test systems, or operational systems. One canonical index preserves identity and discovery.

---

# 9. Question Contract

Every question records:

~~~yaml
question_id:
question:
why_it_matters:
affected_artifacts: []
impact:
blocking:
owner:
due_event:
status:
answer_source:
decision_required:
~~~

Already answered questions are not repeated unless the source, context, or baseline changed.

---

# 10. Decision Contract

Every material decision records:

~~~yaml
decision_id:
question:
context:
options_considered: []
decision:
rationale:
scope:
owner:
authority:
status:
conditions: []
risks: []
source_refs: []
evidence_refs: []
effective_at:
expires_at:
affected_artifacts: []
reopen_triggers: []
~~~

AI cannot become the approval authority.

---

# 11. Requirement and Obligation Contract

Where a contract produces or references requirements, each requirement preserves:

- stable ID and type;
- source and rationale;
- atomic statement;
- scope and actor / system responsibility;
- priority / criticality / release allocation;
- applicability;
- acceptance criteria;
- verification method and evidence expectation;
- dependencies and conflicts;
- owner and status;
- GOV-009 lineage where relevant;
- downstream dispositions.

---

# 12. Verification Contract

Verification records:

~~~yaml
check_id:
claim_or_obligation:
method:
scope:
target_identity:
source_revision:
environment:
expected_result:
actual_result:
status:
performed_by:
performed_at:
evidence_refs: []
defects_or_findings: []
limitations: []
reviewer:
~~~

Document presence is not verification.

---

# 13. Evidence Contract

The complete evidence taxonomy, claim binding, fitness, sufficiency, admissibility, integrity, reuse, invalidation, access, retention, and pack semantics are defined by [Source / Evidence Model](../Source_Evidence_Model/Source_Evidence_Model_Index.md). This section retains the universal minimum inherited by every artifact.

Evidence records:

~~~yaml
evidence_id:
evidence_type:
claim_ids: []
artifact_ids: []
scope:
target_identity:
revision:
environment:
producer:
produced_at:
evidence_period:
result:
location:
integrity_ref:
access_class:
retention:
reviewer:
status:
supersedes:
~~~

Evidence must be relevant, reviewable, durable enough for its gate or operational use, and protected from secrets or unnecessary personal data.

---

# 14. Traceability Contract

Every artifact:

- conforms to the active `GOV-001` version or references an authorized exception;
- has one canonical lifecycle entry in `GOV-002`;
- is a node in GOV-008;
- identifies upstream source and baseline IDs;
- identifies objects it owns;
- identifies downstream consumers;
- links applicable GOV-009 entries;
- exposes missing relationships;
- does not duplicate canonical meaning.

Phase-local matrices are derived GOV-008 views.

---

# 15. Handoff Contract

Every handoff or handoff-producing artifact states:

~~~text
Sender and receiver
Baseline and version
Exact included and excluded scope
Canonical source identities
Objects transferred
Decisions and conditions
Open non-blocking questions
Risks, assumptions, dependencies, and exceptions
Verification and evidence expectations
Prohibited downstream actions
Acknowledgement
Change route
Reopen triggers
~~~

Handoff acknowledgement means receipt and understood constraints, not automatic approval of upstream quality.

---

# 16. Profile Contract

## P1 — Lean

- logical obligations remain;
- closely related objects may share a composite artifact;
- critical traceability, controls, verification, evidence, and gate checks remain;
- one owner may hold multiple roles if conflicts are visible and compensated.

## P2 — Standard

- independently owned or reviewed concerns are modular;
- material decisions, risks, validations, and handoffs are explicit;
- this is the default serious-production profile.

## P3 — Comprehensive

- major applicable artifacts have independent lifecycle and assurance;
- specialist and independent review increase;
- evidence integrity, retention, segregation, and change control strengthen.

Domain-level escalation can raise one contract to P2 or P3 without raising the entire project.

---

# 16A. Family Bundle and Section Inheritance Contract

A family bundle is a physical specification that carries multiple independently governed logical contracts. The bundle is a framework asset; it is not a project artifact and does not merge the identities or canonical meanings of its sections.

Every family bundle declares:

~~~yaml
bundle_id:
bundle_version:
bundle_status:
asset_class:
artifact_family:
owning_phase:
gate_or_baseline:
specialized_contract_artifacts: []
shared_only_disposition_reviews: []
specialized_section_defaults:
  contract_version:
  contract_status:
  inherits:
shared_inheritance:
primary_upstream:
primary_downstream:
semantic_source:
gate_source:
~~~

Each `FAMILY_SECTION` resolves its complete contract from four layers:

~~~text
Shared Core Artifact Contract Standard
→ family-bundle metadata and shared family rules
→ specialized_section_defaults
→ artifact-specific section metadata, semantics, and validation rules
~~~

The resolved logical contract must expose the artifact ID and name, contract ID and version, status, inheritance, owning phase, activation / applicability behavior, profile treatment, canonical responsibility, upstream and downstream anchors, artifact-specific questions or decision needs, validation rules, exit behavior, and reopen / change behavior. These obligations may be inherited or referenced; they do not require redundant headings in every compact section.

Inheritance is invalid when a child weakens an upper-layer obligation silently, omits a required identity with no deterministic default, conflicts with family or shared rules, or depends on physical file presence as proof of completion. `SHARED_ONLY` dispositions are not specialized sections and require an explicit sufficiency review instead.

---

# 17. AI Operating Boundary

The complete governing contract is the [AI Operating Specification](../AI_Operating_Specification/AI_Operating_Specification_Index.md). This section preserves the inherited artifact-specific permissions and prohibitions.

AI may:

- classify and structure inputs;
- extract candidates with source references;
- draft questions and artifact content;
- detect contradictions, duplicates, gaps, and stale links;
- propose traceability and change impact;
- prepare validation and evidence indexes;
- summarize without changing authority;
- execute explicitly authorized technical work within the later implementation contracts.

AI must not:

- invent a fact, approval, execution, verification result, or evidence;
- promote an idea to an approved requirement;
- resolve a material ambiguity silently;
- approve a gate, exception, residual risk, release, or lifecycle decision;
- expose secrets or unnecessary personal data;
- claim compliance from document presence;
- alter canonical meaning outside change control.

---

# 18. Exit Contract

An artifact can be COMPLETE only when:

1. The artifact is registered in `GOV-002` and bound to the active `GOV-001` version.
2. Scope and applicability are resolved.
3. Required inputs and source identities are present.
4. Required questions are answered or formally dispositioned.
5. Required decisions have valid authority and status.
6. Required outputs and owned object IDs exist.
7. Upstream and downstream traceability is sufficient.
8. Required verification is complete.
9. Required evidence is linked and reviewable.
10. Blocking issues are zero.
11. Conditions, risks, exceptions, and debt are explicit.
12. Handoff obligations are satisfied.
13. Reopen conditions and change history exist.
14. Gate-specific checks are satisfied where applicable.

---

# 19. Reopen Contract

Reopen when a material change affects:

- the active `GOV-001` constitution or authorized exception;
- source authority or evidence;
- project or product state;
- scope, boundary, users, roles, policies, or rules;
- requirements or standards applicability;
- design or architecture baseline;
- implementation candidate;
- release target or strategy;
- live identity, controls, risks, or operating evidence;
- contract version.

Reopening:

1. creates or updates GOV-007;
2. updates affected lifecycle state and version metadata in GOV-002;
3. traverses GOV-008;
4. reevaluates GOV-009;
5. records `REVIEW_REQUIRED` or stronger change-impact status and marks the affected GOV-002 lifecycle entry `STALE` when its approved meaning may no longer be relied upon;
6. invalidates affected verification or evidence;
7. determines gate or baseline impact.

Every material assessment produces or references a change-impact record:

~~~yaml
change_id:
changed_object_id:
from_version:
to_version:
change_class:
assessment_status:
affected_artifacts: []
affected_profiles: []
affected_gates: []
earliest_affected_phase:
affected_registry_entries: []
registry_lifecycle_actions: []
verification_invalidated: []
evidence_invalidated: []
required_actions: []
owners: []
due_event:
decision_authority:
downstream_acknowledgements: []
final_disposition:
~~~

`NO_IMPACT` requires traversed scope, rationale, assessor, time, and evidence. Absence of a discovered edge is not proof of no impact. A material change remains unresolved while any required affected artifact, profile, gate, invalidated evidence item, owner, due event, or downstream acknowledgement is missing.

---

# 20. Contract Change Control

Changing a Core Artifact Contract requires:

- proposed contract version;
- problem and downstream use;
- compatibility classification;
- affected artifacts and profiles;
- methodology, gate, traceability, schema, repository, automation, and tool impact;
- migration instructions;
- approving Product OS authority;
- changelog.

---

# 21. Universal Validation Rules

~~~text
CORE-VAL-001  Artifact ID is stable and unique.
CORE-VAL-002  Contract and artifact versions are explicit.
CORE-VAL-003  Applicability is explicit.
CORE-VAL-004  NOT_APPLICABLE includes evidence and reopen conditions.
CORE-VAL-005  Every material statement has information state and source.
CORE-VAL-006  Every material decision has authority and rationale.
CORE-VAL-007  Every blocking question has an owner and due event.
CORE-VAL-008  Every owned object has downstream use or explicit disposition.
CORE-VAL-009  Derived views do not become competing truth.
CORE-VAL-010  Verification is claim- and target-bound.
CORE-VAL-011  Evidence is reviewable and integrity-aware.
CORE-VAL-012  GOV-008 and GOV-009 links are preserved.
CORE-VAL-013  P1 packaging does not remove applicable obligations.
CORE-VAL-014  AI-generated content remains proposed until reviewed.
CORE-VAL-015  Completion requires exit criteria, not file presence.
CORE-VAL-016  Material change follows reopen and impact rules.
CORE-VAL-017  Every artifact conforms to the active GOV-001 version or an authorized exception.
CORE-VAL-018  Every artifact has a current canonical lifecycle entry in GOV-002.
CORE-VAL-019  Every family-section contract resolves version, status, inheritance, identity, semantics, validation, exit, and reopen behavior through declared bundle defaults plus its artifact-specific section.
CORE-VAL-020  Every material change has a complete impact traversal, affected-profile and gate disposition, evidence invalidation result, owner, due event, and downstream acknowledgement.
~~~
