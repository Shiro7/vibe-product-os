# Core Artifact Contract — IMP-029 Verification Candidate Register

~~~yaml
contract_id: CONTRACT-IMP-029
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-029
artifact_name: Verification Candidate Register
owning_phase: Phase 09 - Implementation
gate_or_baseline: Implementation Candidate Handoff to Phase 10
default_activation: REQUIRED_FOR_EVERY_VERIFICATION_CANDIDATE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: ENG-031
primary_downstream: VRL-028
~~~

---

# 1. Purpose

IMP-029 establishes the exact immutable identity and bounded scope of an implementation candidate submitted to independent verification. It tells Verification precisely what code, schemas, migrations, configurations, artifacts, environments, flags, data, known defects, deviations, and evidence are under evaluation.

It prevents evidence produced against one build or configuration from being used to approve another.

---

# 2. Scope and Applicability

Every candidate entering Phase 10 requires a unique IMP-029 record and revision. This applies to full releases, partial slices, hotfixes, migrations, configuration-only changes, data changes, generated artifacts, infrastructure changes, and rollback candidates.

IMP-029 is not NOT_APPLICABLE when verification or release is expected. Work that never becomes a candidate remains explicitly excluded with status and rationale in Phase 09.

---

# 3. Accountabilities

- **Owner / submitter:** authorized implementation or release-engineering owner.
- **Contributors:** repository, build, data, migration, environment, platform, security, design, and evidence owners as applicable.
- **Receiver:** independent verification owner or designated Phase 10 authority.
- **Decision authority:** receiver authorized to accept or reject candidate intake; this is not G6B approval.
- **AI:** may assemble identities and compare manifests; it cannot claim an artifact was built, deployed, tested, or signed without evidence.

---

# 4. Required Inputs

1. Accepted ENG-031 version and implementation-status records.
2. Completed work-item identities and exact source revisions.
3. Reproducible build, package, image, schema, migration, infrastructure, configuration, feature-flag, and generated-artifact identities.
4. Target verification environment and deployment evidence.
5. Test data, account, identity, tenant, role, permission, and privacy-safe fixture profiles.
6. Known defects, deviations, exceptions, restrictions, incomplete work, and debt.
7. Implementation evidence index and outstanding verification obligations.

---

# 5. Required Questions

1. What exact candidate is submitted and how can its identity be reproduced or independently confirmed?
2. Which slices and work items are included and excluded?
3. Which source, package, image, schema, migration, configuration, infrastructure, asset, and generated-output revisions constitute the candidate?
4. Which environment, deployment, flags, secrets references, dependencies, and external service versions shape candidate behavior?
5. Which test data and identity profiles are safe and sufficient for verification?
6. Which known defects, deviations, conditions, restrictions, exceptions, and debt remain?
7. Which implementation checks and evidence already exist, and what do they actually prove?
8. Is the candidate stable enough that Phase 10 evidence will remain bound to it?
9. What change creates a new candidate or invalidates existing verification?
10. Has Verification accepted the candidate manifest without treating that acceptance as a pass?

---

# 6. Required Decisions

- Candidate ID and revision;
- included and excluded implementation scope;
- authoritative source and artifact identities;
- environment, deployment, configuration, flag, and dependency identity;
- test data and identity profile;
- known defect / deviation / restriction disposition;
- evidence index and evidence limitations;
- candidate status and verification intake status;
- invalidation and replacement route.

---

# 7. Minimum Candidate Record

IMP-029 records:

1. Candidate ID and revision.
2. Implementation Baseline and ENG-031 identity.
3. Included and excluded slice / work-item scope.
4. Canonical source revisions.
5. Build artifacts, packages, images, binaries, assets, generated outputs, and integrity references.
6. Schemas, migrations, data revisions, and compatibility identity.
7. Infrastructure, configuration, environment, deployment, and feature-flag identity.
8. External service and dependency versions where behaviorally material.
9. Test data and identity / role / tenant / permission profiles.
10. Known defects, deviations, exceptions, conditions, restrictions, and debt.
11. Implementation evidence index with claim and target links.
12. Candidate status, submitter, receiver, timestamps, and replacement / invalidation history.

Secrets are referenced by governed identity and version metadata; secret values never enter the register.

---

# 8. Candidate Identity Contract

Candidate identity must be exact enough to distinguish behavioral changes. Depending on the system, identity can include:

- source commit or immutable revision;
- build, package, binary, container, or artifact digest;
- schema and migration set;
- infrastructure and configuration revision;
- environment and deployment ID;
- feature-flag state and cohort;
- mobile / desktop package version and signing identity;
- generated-document or asset revision;
- external dependency versions.

A mutable branch name, “latest,” verbal release name, screenshot, or date alone is insufficient.

---

# 9. Change and Evidence Invalidation

Any candidate change is assessed for behavioral, security, privacy, data, accessibility, reliability, deployment, compatibility, or evidence impact.

A material change creates a new candidate revision or ID. Existing evidence is marked VALID, PARTIALLY_REUSABLE, STALE, or INVALID with rationale. Reuse requires explicit equivalence and scope evidence; it is never assumed.

---

# 10. Traceability and Handoff

Minimum path:

~~~text
ENG-031 Work Item
→ Source / Artifact / Schema / Config Identity
→ Candidate ID and Scope
→ Verification Obligation
→ VRL-028 Result and Evidence
~~~

The Phase 10 handoff includes the complete candidate record, limitations, known issues, expected verification scope, evidence index, access / data restrictions, invalidation rule, and receiver acknowledgement.

---

# 11. Profile Behavior

- **P1:** a concise candidate manifest is allowed, but exact identity, scope, defects, environment, and evidence binding remain mandatory.
- **P2:** build, deployment, migration, configuration, test-data, and evidence manifests are modular and independently reviewable.
- **P3:** provenance, signing / attestation, chain of custody, segregation, controlled data, reproducibility, artifact retention, and independent candidate acceptance strengthen.

---

# 12. Verification and Evidence

Candidate-intake verification confirms:

- every included work item is completed or explicitly conditioned;
- source and artifact identities are internally consistent;
- the candidate is deployed or made available in the stated verification environment;
- migration, configuration, flags, dependencies, data, and identities match the manifest;
- known issues and limitations are complete to the submitter's knowledge and evidence;
- existing implementation evidence is correctly scoped;
- Phase 10 can bind every result to the exact candidate.

---

# 13. Exit Criteria

IMP-029 is complete for submission only when candidate identity is immutable / reproducible, exact scope and environment are known, included artifacts and controls are internally consistent, known issues are declared, evidence is indexed, invalidation rules are explicit, and Verification accepts intake.

Candidate intake acceptance does not mean verification passed.

---

# 14. Reopen Conditions

Reopen or supersede on any material change to code, artifact, schema, migration, data, infrastructure, configuration, flag, dependency, environment, deployment, identity profile, known defect, deviation, restriction, or evidence claim.

---

# 15. Artifact-Specific Validation Rules

~~~text
IMP29-CVAL-001  Candidate ID and revision uniquely identify the submitted behavior.
IMP29-CVAL-002  Mutable labels alone cannot identify a candidate.
IMP29-CVAL-003  Included and excluded work scope is exact and traceable to ENG-031.
IMP29-CVAL-004  Schema, migration, configuration, environment, and flag identity are explicit.
IMP29-CVAL-005  Secrets are referenced but never copied into the register.
IMP29-CVAL-006  Known defects and deviations remain visible through release disposition.
IMP29-CVAL-007  Material candidate change triggers evidence impact assessment.
IMP29-CVAL-008  Evidence against a different candidate cannot be silently reused.
~~~
