# Core Artifact Contract — VRL-028 Verification Baseline and G6B Decision Record

~~~yaml
contract_id: CONTRACT-VRL-028
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: VRL-028
artifact_name: Verification Baseline and G6B Decision Record
owning_phase: Phase 10 - Verification and Release
gate_or_baseline: G6B - Verification Baseline
default_activation: REQUIRED_FOR_G6B
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: IMP-029
primary_downstream: VRL-035
~~~

---

# 1. Purpose

VRL-028 is the immutable Verification Baseline snapshot accepted at G6B. It binds an exact implementation candidate to exact verification scope, strategy, environments, results, evidence, coverage, defects, waivers, conditions, and decision.

G6B answers whether the identified candidate has sufficient independent verification for release consideration. It does not authorize release.

---

# 2. Scope and Applicability

VRL-028 is mandatory for every candidate seeking release authorization through G7. It may cover one bounded candidate / target compatibility set or explicitly linked variants whose equivalence is proven.

It cannot be NOT_APPLICABLE for a releasable candidate. A cancellation or rejection is recorded as an outcome, not absence.

---

# 3. Accountabilities

- **Owner:** Verification Baseline owner or test / quality authority.
- **Candidate provider:** implementation owner accountable for IMP-029 accuracy.
- **Verification performers:** named people, teams, systems, or independent parties with evidence of execution.
- **Decision authority:** valid G6B authority independent enough for the selected profile and risk.
- **Specialist authorities:** activated for security, privacy, accessibility, data, audit, reliability, safety, regulatory, or other GOV-009 obligations.
- **AI:** may analyze results and trace coverage; it cannot claim execution, approve waivers, accept residual risk, or decide G6B.

---

# 4. Required Inputs

1. Accepted IMP-029 candidate record and exact identity.
2. Approved requirements, design, architecture, engineering, and implementation baseline revisions.
3. Verification strategy, scope, risk model, environment, data, identity, tooling, and evidence plan.
4. Executed results, coverage, evidence, defects, limitations, and retest history.
5. Waiver / exception requests with authority and expiry.
6. GOV-009 verification and evidence obligations.
7. User / business acceptance evidence where applicable.

---

# 5. Required Questions

1. Is every result bound to the exact candidate, environment, data, identity, configuration, and source revision?
2. Which required scope was executed, not executed, excluded, blocked, or covered by justified prior evidence?
3. Does risk-based coverage sufficiently address critical journeys, controls, integrations, migrations, recovery, accessibility, security, privacy, reliability, and data behavior?
4. Which defects remain and what is their severity, scope, evidence, workaround, owner, and release implication?
5. Which evidence is reviewable, durable, integrity-aware, and sufficient for its claim?
6. Which waivers or conditions exist, who may approve them, and when do they expire or reopen?
7. Did candidate changes invalidate any result or require retest?
8. Is user / business acceptance required and valid for the exact scope?
9. Which residual uncertainty prevents G6B PASS?
10. What exact baseline and conditions are handed to the G7 decision?

---

# 6. Required Decisions

- Verification Baseline ID and revision;
- exact candidate identity and digests;
- included, excluded, unexecuted, and conditional verification scope;
- strategy and risk-coverage acceptance;
- result and evidence acceptance;
- defect, waiver, limitation, and residual-risk disposition;
- GOV-009 and UAT disposition;
- G6B outcome: PASS, PASS_WITH_CONDITIONS, HOLD, or REJECT;
- release-decision handoff and reopen / invalidation conditions.

---

# 7. Minimum Verification Baseline Content

VRL-028 contains:

1. Verification Baseline ID and revision.
2. Candidate identities and integrity references.
3. Included, excluded, blocked, and unexecuted scope.
4. Environment, data, identity, configuration, flag, and dependency profiles.
5. Verification strategy and risk model.
6. Execution records.
7. Results and evidence index.
8. Requirement, design, architecture, control, risk, and test traceability.
9. Coverage analysis and limitations.
10. Defects and their disposition.
11. Waivers, exceptions, conditions, expiry, and authority.
12. GOV-009 coverage and evidence.
13. User / business acceptance disposition.
14. G6B decision, authority, rationale, conditions, and triggers.
15. Release-decision handoff.

---

# 8. Decision Record Contract

The G6B decision records:

- gate and decision ID;
- VBL ID and exact candidate identity;
- decision scope and exclusions;
- outcome and rationale;
- critical results, coverage, limitations, and residual uncertainty;
- accepted / rejected defects, waivers, exceptions, and risks;
- conditions with owner, due event, expiry, evidence, and enforcement point;
- decision makers, reviewers, segregation, and authority;
- effective time and reopen / invalidation triggers;
- exact evidence index and downstream G7 handoff.

PASS_WITH_CONDITIONS is not a way to hide a blocker. Each condition must be enforceable before or during the explicitly stated downstream point.

---

# 9. Candidate Change and Rebaseline

Any material candidate change after verification triggers impact analysis. Affected results become review-required, stale, or invalid; required tests are repeated; and a new VBL revision or baseline is issued.

An unchanged name or version label does not prove an unchanged candidate.

---

# 10. Traceability and Handoff

Minimum path:

~~~text
Candidate Identity
→ Requirement / Risk / Control / Journey / Architecture Obligation
→ Verification Check and Execution
→ Result and Evidence
→ Defect / Waiver / Condition
→ G6B Decision
→ VRL-035 G7 Input
~~~

The G7 handoff preserves exact candidate and VBL identities, scope, results, evidence, defects, waivers, conditions, restrictions, expiry, and change triggers.

---

# 11. Profile Behavior

- **P1:** one VBL may consolidate strategy, execution, results, and decision, but exact candidate binding and critical coverage remain mandatory.
- **P2:** test families, environments, evidence, defects, waivers, UAT, and decision assurance are modular and reviewable.
- **P3:** independent execution / review, controlled environments and data, evidence integrity, segregation, chain of custody, regulatory traceability, and retention strengthen.

---

# 12. Verification of the Baseline

Baseline verification confirms:

- candidate identity matches IMP-029 throughout execution;
- results and evidence are target-, environment-, and revision-bound;
- required coverage is complete or explicitly dispositioned;
- failures, defects, limitations, and unexecuted scope remain visible;
- waivers and conditions have valid authority, scope, enforcement, and expiry;
- GOV-009 and UAT obligations are satisfied or block / condition the decision;
- G6B outcome follows evidence rather than schedule pressure.

---

# 13. Exit Criteria

VRL-028 is complete only when the exact VBL and candidate, scope, strategy, execution, results, evidence, coverage, defects, waivers, GOV-009, UAT, limitations, conditions, and authority are frozen; G6B has a valid outcome; and VRL-035 receives an exact handoff.

---

# 14. Reopen Conditions

Reopen on candidate, environment, configuration, data, identity, dependency, requirement, risk, control, defect, waiver, evidence-integrity, UAT, scope, or verification-strategy change that may affect the decision.

---

# 15. Artifact-Specific Validation Rules

~~~text
VRL28-CVAL-001  Every result and evidence item binds to the exact candidate and environment.
VRL28-CVAL-002  Unexecuted, excluded, blocked, and failed scope remains explicit.
VRL28-CVAL-003  Document or test presence alone does not prove requirement satisfaction.
VRL28-CVAL-004  Waivers and conditions have authority, expiry, owner, and enforcement.
VRL28-CVAL-005  Candidate change triggers evidence impact and retest disposition.
VRL28-CVAL-006  G6B cannot authorize release.
VRL28-CVAL-007  PASS is invalid with an unresolved critical verification blocker.
VRL28-CVAL-008  The G7 handoff preserves exact candidate and VBL identity.
~~~
