# Core Artifact Contract — DES-023 Design-to-Code and Engineering Handoff

~~~yaml
contract_id: CONTRACT-DES-023
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DES-023
artifact_name: Design-to-Code and Engineering Handoff
owning_phase: Phase 06 - Product Design
gate_or_baseline: G4B - Design Baseline
default_activation: REQUIRED_FOR_G4B
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: EXP-001
primary_downstream: ARC-001
~~~

---

# 1. Purpose

DES-023 binds the approved Experience and Design Baselines to an exact, implementable design source. It transfers design meaning, behavior, component mapping, assets, constraints, and verification expectations to Solution Architecture and Engineering without requiring material interpretation.

Design-to-code is a governed mapping of meaning and behavior. It is not pixel copying, screenshot transcription, or an instruction to ignore tokens, components, accessibility, responsive behavior, or platform conventions.

---

# 2. Scope and Applicability

DES-023 is mandatory for G4B whenever implementation consumes product design. It may be NOT_APPLICABLE only for scope with no designed interface or generated visual output, where experience and technical responsibility are explicitly allocated elsewhere with evidence and reopen conditions.

A static design link, presentation, or collection of screenshots does not satisfy this contract.

---

# 3. Accountabilities

- **Owner:** product design lead or designated handoff owner.
- **Senders:** experience and design owners of the approved sources.
- **Receivers:** solution architecture, engineering readiness, implementation, verification, and any code / design-system owners.
- **Decision authority:** authority assigned to accept G4B.
- **Specialist reviewers:** accessibility, content, localization / RTL, brand, security / privacy, platform, or other activated concerns.
- **AI:** may inspect, map, compare, and draft; it cannot invent missing interaction, claim components are adopted without evidence, or approve G4B.

---

# 4. Required Inputs

1. Approved EXP-001 baseline identity and G4A decision.
2. Approved design source identities, file / page / node or equivalent revisions, and design-system source identities.
3. Requirement baseline and acceptance / verification links.
4. Product scope, routes, platforms, channels, themes, locales, and release allocation.
5. Component, pattern, token, asset, content, motion, accessibility, and generated-output sources.
6. Existing code, component, and design-system mappings for brownfield work.

---

# 5. Required Questions

1. Which exact design revisions are approved for implementation?
2. Which scope is included, excluded, conditional, or dependent?
3. Which tokens, themes, components, patterns, screens, routes, and states map to which implementation targets?
4. Which items reuse canonical design-system components and which require a governed new component or exception?
5. Which assets are authoritative, how are they exported, and what transformations are prohibited?
6. How do responsive, platform, accessibility, localization, RTL, content, and motion behaviors change by context?
7. Which design elements are illustrative only and which carry normative behavior?
8. Which tests and evidence must prove implementation equivalence and behavior?
9. Which constraints, assumptions, unresolved decisions, or dependencies may affect implementation?
10. How are design changes acknowledged and propagated after handoff?

---

# 6. Required Decisions

- Design Baseline ID and canonical source revisions;
- implementation scope and release allocation;
- token / theme contract;
- canonical component and pattern mapping;
- screen / route / state mapping;
- asset and generated-output rules;
- responsive, platform, accessibility, localization, RTL, content, and motion behavior;
- allowed deviations and exception route;
- expected tests and evidence;
- G4B outcome, conditions, and receiver acknowledgement.

---

# 7. Minimum Handoff Content

DES-023 contains:

1. Design Baseline ID and source revisions.
2. Implementation scope, inclusions, exclusions, and allocation.
3. Token and theme contract.
4. Component and pattern mappings.
5. Screen, route, journey, and state mappings.
6. Assets and export rules.
7. Responsive and platform behavior.
8. Accessibility semantics and checks.
9. Localization and RTL behavior.
10. Content and message sources.
11. Motion behavior and reduced-motion disposition.
12. Generated outputs and document / media rules.
13. Open constraints, assumptions, dependencies, risks, and conditions.
14. Expected tests and evidence.
15. Change-control and deviation route.
16. Owners and receiver acknowledgement.

---

# 8. Traceability and Mapping Contract

Every implementation-relevant design object maps:

~~~text
Requirement / Acceptance Criterion
→ Experience Journey / View / State
→ Design Source Node / Component / Pattern / Token
→ Intended Code Component / Route / Asset / Content Source
→ Verification Check and Evidence
~~~

The mapping states whether the design object is canonical, instance-specific, illustrative, deprecated, experimental, or pending. A name match alone does not prove semantic equivalence or active adoption.

---

# 9. Source Identity and Change Control

The handoff records immutable or reproducible source identity appropriate to each tool: file, branch, revision, version, node, asset digest, design-system release, or exported package identity.

After G4B:

- material design changes require GOV-007 impact analysis;
- GOV-008 identifies requirements, experience, architecture, code, tests, and evidence affected;
- receiver acknowledgement is renewed when behavior or scope changes;
- implementation never treats an unreviewed latest design as automatically approved.

---

# 10. Profile Behavior

- **P1:** one handoff may contain consolidated mappings, but every critical route, state, token, component, asset, and behavior remains discoverable.
- **P2:** token, component, asset, screen, accessibility, content, and test mappings are modular and owned.
- **P3:** independent design-system, accessibility, localization, security / privacy, platform, asset provenance, and handoff assurance strengthen; source integrity and retention are controlled.

---

# 11. Verification and Evidence

Verification confirms:

- every committed designed route and state maps to approved experience and requirements;
- every implementation target uses an exact design source revision;
- tokens, components, patterns, and assets resolve to canonical sources or governed exceptions;
- responsive, accessibility, RTL, localization, content, motion, and generated-output rules are testable;
- unresolved questions are non-blocking or explicitly conditional;
- receivers can implement without material guessing.

Evidence includes mapping reviews, canonical-source inspection, component adoption evidence, export checks, accessibility annotations, responsive and state coverage, and the exact G4B decision.

---

# 12. Exit Criteria

DES-023 is complete only when the exact baseline and sources, implementation scope, mappings, cross-cutting behavior, constraints, tests, evidence expectations, change route, owners, and acknowledgement exist; all blocking ambiguity is resolved; and G4B has a valid outcome.

G4B cannot pass without an accepted DES-023.

---

# 13. Reopen Conditions

Reopen on a material requirement, experience, source revision, design-system, token, component, route, state, asset, content, accessibility, responsive, platform, localization, RTL, motion, generated-output, implementation-target, or acceptance change.

---

# 14. Artifact-Specific Validation Rules

~~~text
DES23-CVAL-001  Every normative design source has exact identity and revision.
DES23-CVAL-002  Every committed route and state maps to requirements and experience.
DES23-CVAL-003  Component name similarity does not prove canonical equivalence or adoption.
DES23-CVAL-004  Assets include authority, export rule, integrity, and usage constraints.
DES23-CVAL-005  Accessibility, responsive, RTL, localization, content, and motion behavior are explicit.
DES23-CVAL-006  Material design changes after G4B follow impact analysis and acknowledgement.
DES23-CVAL-007  Handoff receipt does not waive unresolved quality or baseline defects.
DES23-CVAL-008  G4B PASS is invalid when engineering must materially guess design behavior.
~~~
