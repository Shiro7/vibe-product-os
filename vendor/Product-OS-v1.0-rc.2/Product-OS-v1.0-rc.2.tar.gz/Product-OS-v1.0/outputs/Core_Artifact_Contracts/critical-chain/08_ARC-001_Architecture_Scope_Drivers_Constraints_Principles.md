# Core Artifact Contract — ARC-001 Architecture Scope, Drivers, Constraints, and Principles

~~~yaml
contract_id: CONTRACT-ARC-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: ARC-001
artifact_name: Architecture Scope, Drivers, Constraints, and Principles
owning_phase: Phase 07 - Solution Architecture
gate_or_baseline: Architecture Foundation for G5A
default_activation: REQUIRED_WHEN_PHASE_07_IS_ACTIVE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DES-023
primary_downstream: ARC-033
~~~

---

# 1. Purpose

ARC-001 establishes the system of interest, architecture states, decision boundary, drivers, priorities, constraints, principles, assumptions, dependencies, risks, and authority that govern Solution Architecture.

It prevents architectural choices from being made against an undefined scope or from being justified by preference rather than traceable product, requirement, standard, design, risk, or current-state need.

---

# 2. Scope and Applicability

The contract activates whenever Phase 07 makes, changes, recovers, or validates architectural responsibility or a technical baseline.

For brownfield, recovery, migration, or evolution work it must explicitly distinguish CURRENT, TARGET, and TRANSITION. NOT_APPLICABLE requires evidence that no architectural decision, allocation, integration, data, deployment, control, or quality concern changes for the exact scope.

---

# 3. Accountabilities

- **Owner:** solution architect or designated architecture lead.
- **Decision authorities:** named architecture and business / product authorities according to decision scope.
- **Contributors:** design, engineering, data, security, privacy, reliability, platform, verification, operations, and activated domain specialists.
- **Reviewers:** independent or specialist reviewers required by profile, risk, and GOV-009.
- **AI:** may derive candidate drivers, compare options, and detect conflicts; it cannot select risk acceptance, approve architecture, or invent current-state evidence.

---

# 4. Required Inputs

1. Approved requirements and Design Baseline identities with conditions.
2. Product scope, boundary, information, integration, lifecycle, platform, and release context.
3. Current system, repositories, environments, data, infrastructure, interfaces, controls, incidents, and operational evidence where applicable.
4. Active standards, policies, contracts, GOV-009 entries, and domain overrides.
5. Known quality attributes, risks, assumptions, constraints, dependencies, and decision deadlines.

---

# 5. Required Questions

1. What exact system, ecosystem, deployment, and organizational responsibility is in architectural scope?
2. Which architecture states are relevant: CURRENT, TARGET, and TRANSITION?
3. Which business, product, experience, quality, security, privacy, data, accessibility, audit, operational, cost, regulatory, and delivery forces drive decisions?
4. Which drivers are highest priority and how are conflicts resolved?
5. Which constraints are fixed, which are negotiable, and which are only assumed?
6. Which principles guide repeated decisions and what practical implications follow?
7. Which dependencies and external systems can fail, change, or constrain the design?
8. Which risks require elimination, mitigation, transfer, acceptance, monitoring, or escalation?
9. Who owns each decision category and domain override?
10. Which evidence would invalidate a driver, constraint, assumption, or principle?

---

# 6. Required Decisions

- system of interest and architectural boundary;
- included and excluded architecture scope;
- applicable architecture states;
- driver set, priority, and conflict disposition;
- hard / soft / assumed constraint classification;
- principle set and implications;
- decision authority and domain override route;
- accepted assumptions, dependencies, and risk treatment route;
- architecture profile and required assurance depth.

---

# 7. Minimum Content

ARC-001 contains:

1. System of interest.
2. Architecture states: CURRENT, TARGET, and TRANSITION as applicable.
3. Scope, boundaries, inclusions, and exclusions.
4. Architecture drivers and priorities.
5. Constraints with classification and authority.
6. Principles and their decision implications.
7. Assumptions with validation and expiry.
8. Dependencies and external ownership.
9. Risks and treatment / escalation route.
10. Decision authority and decision categories.
11. Selected profile and domain-level overrides.
12. Requirement, Design, GOV-008, and GOV-009 traceability.
13. Open questions and evidence gaps.

---

# 8. Driver Contract

Every architecture driver traces to at least one of:

- approved requirement or acceptance criterion;
- applicable standard, policy, contract, regulation, or GOV-009 entry;
- approved Design constraint;
- evidenced current-state or operational need;
- governed assumption with owner, validation, and expiry;
- material risk or dependency.

Each driver records priority, affected domains, conflicts, decision implications, verification expectations, and change triggers. Preference alone is not a driver.

---

# 9. State and Boundary Contract

CURRENT describes evidence-supported reality. TARGET describes the approved intended state. TRANSITION describes safe movement, coexistence, migration, compatibility, rollback, and retirement.

Unknown current-state areas remain unknown. Target diagrams do not overwrite current reality. Each view and decision is labelled by state and effective scope.

---

# 10. Traceability and Handoff

Minimum path:

~~~text
Requirement / Design Rule / GOV-009 / Current Evidence / Risk
→ Architecture Driver or Constraint
→ Principle / Decision Question
→ Architecture Decision
→ Technical Contract / Fitness Function
→ ARC-033 Handoff
~~~

ARC-001 supplies the controlling context for all later architecture artifacts and ARC-033. Domain overrides reference this baseline and cannot silently weaken universal obligations.

---

# 11. Profile Behavior

- **P1:** scope, driver, constraint, principle, assumption, dependency, and risk views may be consolidated, but all material decisions remain traceable.
- **P2:** architecture concerns and decisions are modular with explicit reviews, fitness functions, and handoffs.
- **P3:** independent assurance, threat / risk analysis, data and reliability architecture, regulatory evidence, transition safety, and decision segregation strengthen.

---

# 12. Verification and Evidence

Verification confirms:

- system and state boundaries are unambiguous;
- every driver and constraint has source, authority, scope, and implications;
- conflicts between drivers have explicit disposition;
- principles are actionable rather than slogans;
- assumptions have owners, validation, and expiry;
- current-state claims are evidence-based;
- GOV-009 and domain overrides are correctly linked;
- downstream architecture decisions can be evaluated against stable criteria.

---

# 13. Exit Criteria

ARC-001 is complete only when the system of interest, states, scope, drivers, priorities, constraints, principles, assumptions, dependencies, risks, authority, profile, overrides, traceability, and open issues are governed sufficiently for architecture decisions and ARC-033 preparation.

---

# 14. Reopen Conditions

Reopen on a material requirement, design, standard, boundary, current-state evidence, quality target, risk, dependency, platform, vendor, data, integration, deployment, cost, timeline, or authority change.

---

# 15. Artifact-Specific Validation Rules

~~~text
ARC1-CVAL-001  Every driver has a valid source and decision implication.
ARC1-CVAL-002  CURRENT, TARGET, and TRANSITION are explicitly distinguished.
ARC1-CVAL-003  Hard constraints identify the authority that makes them hard.
ARC1-CVAL-004  Principles state observable architectural implications.
ARC1-CVAL-005  Assumptions include owner, validation, expiry, and failure impact.
ARC1-CVAL-006  Driver conflicts have explicit priority or escalation disposition.
ARC1-CVAL-007  Domain overrides reference controlling GOV-009 and architecture scope.
ARC1-CVAL-008  Architecture decisions cannot be justified by preference alone.
~~~
