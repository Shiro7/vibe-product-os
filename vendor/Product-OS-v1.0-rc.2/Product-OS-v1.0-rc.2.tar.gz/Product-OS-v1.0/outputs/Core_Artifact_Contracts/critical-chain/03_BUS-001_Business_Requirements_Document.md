# Core Artifact Contract — BUS-001 Business Requirements Document

~~~yaml
contract_id: CONTRACT-BUS-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-001
artifact_name: Business Requirements Document
owning_phase: Phase 02 - Business Architecture
gate_or_baseline: G2 - Business Baseline
default_activation: REQUIRED_WHEN_PHASE_02_IS_ACTIVE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-002
primary_downstream: PROD-002
~~~

---

# 1. Purpose

BUS-001 is the consolidated human-readable Business Baseline. It defines what the business must achieve, govern, perform, decide, measure, and control before responsibility is allocated to the product.

It describes business intent and operating logic. It does not prescribe screens, features, APIs, database entities, or solution architecture.

---

# 2. Scope and Applicability

The contract activates whenever Phase 02 establishes or changes business outcomes, capabilities, value streams, processes, actors, decisions, rules, controls, information responsibilities, or KPIs.

A small change may package BUS-001 with linked business records, but the Business Baseline remains explicit. NOT_APPLICABLE requires evidence that no business responsibility, rule, control, outcome, or operating change needs definition and identifies the authoritative alternative baseline and reopen triggers.

---

# 3. Accountabilities

- **Owner:** designated business architect, business analyst, or equivalent.
- **Business authorities:** accountable owners for domains, processes, policies, controls, and outcomes.
- **Contributors:** product, operations, finance, legal, risk, security, privacy, accessibility, audit, data, and other applicable specialists.
- **Decision authority:** authority assigned to approve G2 and the Business Baseline.
- **AI:** may structure and trace candidate business requirements and rules; it cannot decide business policy or accept residual control risk.

---

# 4. Required Inputs

1. Accepted DISC-002 version, G1 decision, and conditions.
2. Validated problems, impacts, outcomes, signals, opportunities, constraints, and assumptions.
3. Current business operating model and evidence.
4. Applicable policies, contracts, regulations, standards, and GOV-009 entries.
5. Known domains, actors, roles, processes, decisions, information, controls, and measures.
6. Existing business requirements and rules with authority and freshness.

---

# 5. Required Questions

1. Which business outcomes and objectives must be achieved, and how will they be measured?
2. Which business domains and capabilities are affected?
3. Which value streams and processes create, protect, or recover value?
4. Which actors, roles, responsibilities, and decision rights are required?
5. Which business decisions, rules, policies, controls, and exceptions govern behavior?
6. Which information objects does the business create, use, share, retain, or dispose of?
7. Which events, handoffs, dependencies, and external parties shape the operating model?
8. Which accessibility, security, privacy, audit, regulatory, contractual, data, or resilience obligations must become business requirements or controls?
9. Which KPIs, risks, assumptions, and constraints govern acceptance of the baseline?
10. What must later product and requirements phases derive without inventing business logic?

---

# 6. Required Decisions

- business scope and exclusions;
- target outcomes, objectives, measures, and tolerances;
- affected domains, capabilities, value streams, and processes;
- accountable actors, roles, and decision authority;
- approved business requirements, rules, policies, controls, and exceptions;
- business information responsibilities and lifecycle expectations;
- standards profile applicability and business-level obligation disposition;
- G2 outcome, conditions, and downstream product-definition route.

---

# 7. Required Content

BUS-001 contains or references:

1. Executive business context and change rationale.
2. Business scope, exclusions, and boundary conditions.
3. Problems, outcomes, objectives, and success measures.
4. Business domains and capability model.
5. Value streams and value exchanges.
6. Actors, roles, responsibilities, and decision rights.
7. Current, target, and transition processes where applicable.
8. Business events, decisions, rules, policies, and exceptions.
9. Controls and evidence expectations.
10. Business information objects, ownership, classification, and lifecycle implications.
11. Business requirements catalog view.
12. KPI and outcome measurement model.
13. Dependencies, constraints, assumptions, risks, and open questions.
14. Standards / compliance profile and GOV-009 disposition.
15. Traceability and derivation guidance for Phase 03 and Phase 04.
16. G2 decision, conditions, and handoff.

BUS-001 consolidates and references BUS-family artifacts. It does not create duplicate canonical records.

---

# 8. Business Requirement and Rule Contract

Business Requirement IDs use an approved stable namespace. The base and specialized namespace prefixes include:

~~~text
BREQ
BREQ-A11Y
BREQ-SEC
BREQ-PRIV
BREQ-AUD
~~~

The future schema standard defines the governed separator and sequence component; this contract fixes the semantic namespaces without pretending that the schema has already been approved.

A Business Requirement states a required business capability, outcome, responsibility, or control. A Business Rule states governing logic, condition, constraint, calculation, eligibility, obligation, or prohibition. The two remain linked but are not merged.

Each requirement follows the shared requirement contract and also records business owner, business rationale, outcome / objective link, capability / process allocation, rule / control implications, and downstream derivation status.

---

# 9. Traceability and Handoff

Required trace paths include:

~~~text
PRB → OUT → OBJ → CAP → PROC → BREQ
BREQ → Business Rule / Policy / Control / KPI
BREQ → Product Objective / Capability → later FR or NFR
GOV-009 Entry → Business Obligation / Control → downstream derivation
~~~

The handoff to PROD-002 includes approved business scope, objectives, domains, capabilities, value streams, actors, roles, responsibilities, processes, decisions, rules, controls, exceptions, information, KPIs, dependencies, risks, assumptions, open questions, standards profile, derivation obligations, G2 decision, and conditions.

---

# 10. Profile Behavior

- **P1:** the BRD may contain embedded capability, process, rule, control, and KPI views while preserving stable object identities.
- **P2:** independently governed domains, processes, rules, controls, and requirements are modular and separately reviewable.
- **P3:** independent control, legal / compliance, audit, data, operating-model, and evidence assurance strengthen; segregation and retention rules are explicit.

---

# 11. Verification and Evidence

Verification confirms:

- each business requirement traces to an evidence-supported problem, outcome, objective, obligation, or decision;
- business rules have valid authority and scope;
- capabilities and processes have ownership and clear boundaries;
- controls state evidence expectations and exceptions;
- KPIs measure approved outcomes rather than convenient activity alone;
- standards obligations have explicit applicability and disposition;
- downstream derivation can occur without inventing business intent.

Evidence includes the exact BUS-001 version, canonical object snapshots, policy and standard identities, review records, unresolved issue disposition, and G2 decision.

---

# 12. Exit Criteria

BUS-001 is complete only when:

1. business scope, outcomes, objectives, and measures are approved;
2. domains, capabilities, value streams, and material processes are coherent;
3. actors, responsibilities, decision rights, rules, controls, and exceptions are explicit;
4. business information responsibilities are defined at the required level;
5. all baseline business requirements are traceable and appropriately governed;
6. applicable standards and GOV-009 entries have business disposition;
7. material risks, assumptions, dependencies, and open questions are governed;
8. no G2 blocker would force product definition to invent business logic;
9. G2 has a valid outcome and conditions;
10. PROD-002 accepts the baseline handoff.

---

# 13. Reopen Conditions

Reopen on a material change to business outcome, scope, operating model, capability, process, role, rule, policy, control, information responsibility, KPI, standard applicability, authority, or evidence that invalidates an approved business assumption.

---

# 14. Artifact-Specific Validation Rules

~~~text
BUS1-CVAL-001  Every BREQ traces to a problem, outcome, objective, obligation, or governed decision.
BUS1-CVAL-002  Business requirements and business rules remain distinct object types.
BUS1-CVAL-003  A capability is not represented merely as an organization unit or application feature.
BUS1-CVAL-004  Every material rule and control has authority, scope, and exception handling.
BUS1-CVAL-005  Each KPI traces to an approved outcome or objective.
BUS1-CVAL-006  BUS-001 does not prescribe screens, APIs, or database implementation.
BUS1-CVAL-007  Standards obligations include explicit business disposition.
BUS1-CVAL-008  G2 PASS is invalid if downstream work must invent material business logic.
~~~
