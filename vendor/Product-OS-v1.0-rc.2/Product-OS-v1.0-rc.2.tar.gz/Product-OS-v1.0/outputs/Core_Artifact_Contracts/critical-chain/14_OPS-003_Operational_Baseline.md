# Core Artifact Contract — OPS-003 Operational Baseline

~~~yaml
contract_id: CONTRACT-OPS-003
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: OPS-003
artifact_name: Operational Baseline
owning_phase: Phase 11 - Operations and Evolution
gate_or_baseline: Operational Baseline for G8
default_activation: REQUIRED_FOR_LIVE_OPERATION
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: VRL-035
primary_downstream: OPS-037
~~~

---

# 1. Purpose

OPS-003 is the accepted versioned snapshot of current live operational truth. It binds live identity, scope, ownership, service objectives, telemetry, controls, runbooks, risks, recovery, dependencies, support, maintenance, cost, debt, and evolution signals.

It is not an aspirational operations plan. Differences between intended and observed operation remain explicit.

---

# 2. Scope and Applicability

OPS-003 is required for every live product, service, system, deployment, tenant / cohort, operational process, or controlled production scope managed through Product OS.

Greenfield work activates the contract when live operation begins. Brownfield and recovery work create a bounded initial baseline even when truth is incomplete; unknowns are recorded and prioritized rather than invented. NOT_APPLICABLE is only valid when no live operational responsibility exists in the exact project scope.

---

# 3. Accountabilities

- **Owner:** service / operations owner accountable for baseline integrity.
- **Technical owners:** named owners for applications, platforms, data, security, reliability, support, vendors, and recovery as applicable.
- **On-call and escalation authorities:** explicit for incidents and critical decisions.
- **Baseline approver:** authority assigned to accept current operational truth and G8 inputs.
- **AI:** may correlate signals and draft baseline updates; it cannot claim service health, incident resolution, restore success, control operation, or sustainability without evidence.

---

# 4. Required Inputs

1. Valid VRL-035 and actual release / deployment execution evidence.
2. Live System / Service Configuration Profile and Live Identity records.
3. Current versions, environments, topologies, configuration, flags, cohorts, dependencies, and vendor identities.
4. Ownership, access, on-call, escalation, support, and communication records.
5. SLIs, SLOs, error budgets, product outcomes, telemetry, dashboards, alerts, synthetics, logs, traces, and data-quality evidence.
6. Incident, problem, security, privacy, accessibility, audit, data, backup, restore, DR, capacity, cost, vendor, maintenance, exception, risk, debt, and evolution evidence.

---

# 5. Required Questions

1. What exact live scope exists now, where, at which version, configuration, flag, cohort, and topology?
2. Who owns service, code, platform, data, security, support, incident, access, and escalation responsibilities?
3. Which SLIs, SLOs, error budgets, and product outcomes define acceptable health?
4. Can telemetry accurately and promptly detect degradation, control failure, user harm, and business impact?
5. Which incidents, problems, defects, exceptions, risks, dependencies, vendor limits, and debt affect sustainability?
6. Are security, privacy, accessibility, audit, data, and operational controls functioning with evidence?
7. Are backup, restore, DR, capacity, rollback, recovery, and continuity capabilities verified?
8. Which support, communication, runbook, maintenance, cost, and access arrangements are current?
9. Which user, market, operational, cost, compliance, technology, and product signals justify sustainment, remediation, evolution, constraint, transfer, or sunset review?
10. What material change requires a new OBL version or an earlier-phase reopen?

---

# 6. Required Decisions

- Operational Baseline ID, version, scope, and effective period;
- accepted live identities and current-state confidence;
- ownership, access, on-call, escalation, and support model;
- SLI, SLO, error-budget, product-outcome, and alert thresholds;
- control, telemetry, incident, recovery, maintenance, vendor, cost, risk, exception, and debt disposition;
- GOV-009 operational evidence and gaps;
- evolution signals, candidates, routes, and review cadence;
- G8 readiness and any immediate escalation.

---

# 7. Minimum Operational Baseline Content

OPS-003 contains:

1. OBL ID and version.
2. Live System / Service Configuration Profile and Live Identity references.
3. Versions, flags, cohorts, regions, platforms, environments, dependencies, and topology.
4. Service, technical, data, security, platform, support, vendor, on-call, access, and escalation ownership.
5. SLIs, SLOs, error budgets, service health, and product outcomes.
6. Dashboards, alerts, synthetics, telemetry coverage, and telemetry-quality limits.
7. Incident, problem, support, communication, and known-defect status.
8. Security, privacy, identity, access, accessibility, audit, and data controls.
9. Backup, restore, DR, rollback, continuity, capacity, performance, cost, and vendor status.
10. Runbooks, maintenance, lifecycle / end-of-life, exceptions, risks, restrictions, and debt.
11. GOV-009 operational obligations and evidence.
12. User, product, market, support, incident, cost, control, and technology evolution signals.
13. Experiments, improvement candidates, portfolio links, and routed changes.
14. G8 action status, decision history, and next review cadence.

---

# 8. Operational Truth and Versioning

OPS-003 distinguishes:

- **OBSERVED:** confirmed through current operational evidence;
- **DECLARED:** asserted by an authority but not yet independently observed;
- **UNKNOWN:** not currently known;
- **DEGRADED:** known to be below the accepted operational objective or control;
- **TEMPORARY:** valid only for a bounded window or exception.

A new OBL version is required when live identity, ownership, SLOs, topology, controls, recovery, support, or evolution routing materially changes. History is preserved.

---

# 9. Brownfield and Recovery Contract

When entering Product OS with incomplete operational truth:

1. bind a safe, bounded live scope;
2. discover identities, dependencies, environments, and owners;
3. record unknowns and confidence without invention;
4. protect access, secrets, personal data, and production safety;
5. establish minimum telemetry, incident response, and escalation;
6. verify critical backup, restore, rollback, or recovery claims;
7. stabilize critical risks before broad evolution;
8. issue a truthful OBL with conditions and recovery actions.

The absence of perfect documentation does not justify an aspirational baseline.

---

# 10. Traceability and Handoff

Minimum paths include:

~~~text
G7 Authorization + Release Execution
→ Live Identity / Configuration / Topology
→ SLI / SLO / Control / Runbook / Owner
→ Operational Evidence / Incident / Risk / Signal
→ OPS-037 Decision
→ Sustainment Action or Governed Lifecycle Route
~~~

OPS-003 receives exact release identity and preserves links back to candidate, VBL, G7, requirements, controls, and evidence. It feeds OPS-037 with current, period-bound operational truth.

---

# 11. Profile Behavior

- **P1:** one OBL may consolidate service, telemetry, control, recovery, and evolution views while live identity and critical ownership remain exact.
- **P2:** service, SLO, telemetry, incident, security, data, recovery, cost, vendor, and evolution records are modular and reviewable.
- **P3:** independent control evidence, multi-region / tenant coverage, advanced resilience, segregation, evidence retention, regulatory reporting, vendor assurance, and continuity exercises strengthen.

---

# 12. Verification and Evidence

Verification confirms:

- live identity matches actual deployed / active state;
- ownership and escalation contacts are current and reachable under the governed process;
- SLI / SLO calculations and telemetry quality are reproducible;
- alerts and runbooks correspond to material failure modes;
- controls, backups, restore, DR, and recovery claims have execution evidence appropriate to risk;
- incidents, exceptions, risks, and debt are not hidden;
- evolution signals have source, period, scope, and decision use.

---

# 13. Exit Criteria

OPS-003 is current and acceptable when its exact live scope and identity, ownership, objectives, telemetry, controls, response, recovery, dependencies, support, risks, exceptions, cost, debt, GOV-009, and evolution signals reflect evidenced operational truth sufficiently for G8 decision-making.

An OBL can be accepted with explicit unknowns and actions; it cannot be accepted with concealed critical uncertainty.

---

# 14. Reopen and Version Triggers

Create a new version or reopen on material release, rollback, migration, configuration, flag, cohort, topology, environment, owner, access, SLO, telemetry, control, incident, recovery, vendor, cost, support, risk, exception, debt, standard, or evolution change.

---

# 15. Artifact-Specific Validation Rules

~~~text
OPS3-CVAL-001  OBL live identity matches current operational evidence.
OPS3-CVAL-002  Intended and observed operation are not silently conflated.
OPS3-CVAL-003  Unknown operational truth remains explicit with owner and action.
OPS3-CVAL-004  Critical SLO, control, backup, restore, and recovery claims have evidence.
OPS3-CVAL-005  Incidents, exceptions, risks, restrictions, and debt remain visible.
OPS3-CVAL-006  Material live changes create a new OBL version or impact review.
OPS3-CVAL-007  Evolution signals identify source, scope, period, and decision use.
OPS3-CVAL-008  OPS-037 cannot rely on an unbound or materially stale OBL.
~~~
