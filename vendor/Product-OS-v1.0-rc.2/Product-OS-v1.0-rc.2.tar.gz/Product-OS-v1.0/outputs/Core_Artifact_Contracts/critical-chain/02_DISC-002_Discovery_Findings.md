# Core Artifact Contract — DISC-002 Discovery Findings

~~~yaml
contract_id: CONTRACT-DISC-002
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-002
artifact_name: Discovery Findings
owning_phase: Phase 01 - Discovery and Problem Definition
gate_or_baseline: G1 - Discovery Baseline
default_activation: REQUIRED_WHEN_PHASE_01_IS_ACTIVE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: INIT-001
primary_downstream: BUS-001
~~~

---

# 1. Purpose

DISC-002 consolidates the evidence-supported understanding of the current state, stakeholders, problems, impacts, causes, desired outcomes, opportunities, and validation limits at the end of Discovery.

It establishes what the organization has learned. It does not approve a product feature set, business architecture, requirements baseline, or solution.

---

# 2. Scope and Applicability

The contract activates whenever Phase 01 is used to validate or refine a problem, need, current state, outcome, or recovery condition.

A compressed discovery route may reuse sufficiently current and authoritative evidence, but it must still produce an explicit DISC-002 baseline view. NOT_APPLICABLE requires a governed route that demonstrates Discovery has no decision use, identifies the alternative evidence baseline, records downstream risk, and defines a reopen trigger.

---

# 3. Accountabilities

- **Owner:** product / business analyst or designated discovery lead.
- **Contributors:** affected stakeholders, users, operators, domain specialists, and evidence owners.
- **Decision authority:** authority assigned to accept G1 and its residual uncertainty.
- **Independent reviewers:** activated for high-risk, regulated, safety, security, privacy, accessibility, audit, or recovery concerns.
- **AI:** may synthesize and challenge evidence; it cannot claim an interview occurred, infer consensus, or promote a cause hypothesis to fact.

---

# 4. Required Inputs

1. Accepted INIT-001 version, G0 outcome, and conditions.
2. Registered sources, authority, and current-state assets.
3. Stakeholder and user evidence, including dissent where material.
4. Observations, interviews, research, analytics, support, operational, incident, process, and market evidence as applicable.
5. Preliminary problems, desired outcomes, constraints, risks, and GOV-009 triggers.
6. Previous attempts, workarounds, and known effects.

Reused evidence records collection period, freshness, method, population / scope, limitations, and authority.

---

# 5. Required Questions

1. What is happening today, for whom, where, when, and how often?
2. Which observations are facts, interpretations, assumptions, or unresolved contradictions?
3. Which symptoms indicate a deeper problem, and which problems remain separate?
4. What business, user, operational, control, financial, or strategic impact is supported?
5. Which causes are evidenced, which are hypotheses, and what could falsify them?
6. Who is affected, who influences the situation, and whose perspective is missing?
7. What has already been attempted, and what was learned?
8. Which workarounds exist, and what risks or hidden costs do they introduce?
9. What outcomes matter, and which observable signals would indicate improvement?
10. Which opportunities are supported without being treated as approved solutions?
11. What is the current scope hypothesis and what remains outside it?
12. Which standards, access needs, contexts, and barriers alter the problem definition?
13. Which uncertainty is tolerable at G1 and which blocks downstream work?

---

# 6. Required Decisions

- validated problem set and problem priority;
- current-state interpretation and material evidence limitations;
- supported impacts and cause status;
- desired outcomes and success signals carried forward;
- opportunity and scope hypotheses eligible for later evaluation;
- assumptions accepted conditionally and validations still required;
- G1 outcome and residual conditions;
- downstream route to business architecture, product recovery, or another governed path.

No opportunity, workaround, or stakeholder idea becomes a product commitment through DISC-002.

---

# 7. Required Content

DISC-002 contains or references:

1. Executive Discovery Summary.
2. Current State.
3. Stakeholders, users, contexts, and evidence coverage.
4. Symptoms.
5. Problems and priorities.
6. Supported impacts.
7. Supported causes and cause hypotheses, kept distinct.
8. Assumptions and validation status.
9. Constraints and dependencies.
10. Previous attempts and observed outcomes.
11. Workarounds and their risks.
12. Desired outcomes.
13. Success signals.
14. Opportunities and opportunity evidence.
15. Scope hypothesis with inclusions, exclusions, and uncertainty.
16. Risks and contradictions.
17. GOV-009 discovery findings, barriers, and evidence gaps.
18. Open questions and decision gaps.
19. Validation summary and limitations.
20. G1 decision and downstream handoff.

---

# 8. Objects Owned and Referenced

DISC-002 owns the consolidated discovery narrative and approved finding set. It references canonical stakeholder, research, observation, problem, impact, cause, outcome, signal, opportunity, assumption, risk, question, evidence, GOV-008, and GOV-009 records.

Every finding has a stable ID or references one. Facts, symptoms, problems, causes, impacts, outcomes, opportunities, and solutions are not interchangeable types.

---

# 9. Traceability and Handoff

Minimum semantic paths include:

~~~text
Source / Observation → Finding → Symptom → Problem → Impact
Problem → Cause Evidence or Cause Hypothesis
Problem → Desired Outcome → Success Signal
Problem / Outcome → Opportunity → later Business or Product evaluation
GOV-009 Trigger → Discovery Need / Barrier / Evidence → later obligation
~~~

The handoff to BUS-001 supplies the validated current state, stakeholder map, problems and priorities, impacts, cause status, constraints, dependencies, desired outcomes, signals, opportunities, scope hypothesis, risks, assumptions, open questions, standards evidence, pending GOV-009 decisions, G1 outcome, and conditions.

---

# 10. Profile Behavior

- **P1:** one Discovery Findings artifact may present linked research and validation views; evidence IDs and uncertainty remain explicit.
- **P2:** major research, problem, outcome, and validation records remain modular and independently reviewable.
- **P3:** research design, representativeness, specialist review, evidence retention, independent validation, and high-risk cause analysis strengthen.

---

# 11. Verification and Evidence

Verification checks that:

- every confirmed finding has a source, method, scope, and evidence period;
- contradictory evidence is retained and dispositioned;
- cause claims match their validation status;
- stakeholder coverage and missing perspectives are visible;
- success signals are observable and connected to outcomes;
- opportunities do not silently become scope commitments;
- G1 blockers and conditions are resolved or explicitly governed.

Evidence may include research records, observation notes, analytics extracts, process evidence, operational records, source snapshots, validation results, and the exact G1 decision record.

---

# 12. Exit Criteria

DISC-002 is complete only when:

1. current state and evidence limitations are understandable;
2. affected stakeholders, users, and material coverage gaps are explicit;
3. symptoms, problems, impacts, and cause status are separated;
4. priority problems have sufficient evidence for the selected profile and risk;
5. desired outcomes and observable success signals exist;
6. opportunities and scope hypothesis are traceable but not over-approved;
7. assumptions, constraints, dependencies, risks, standards implications, and open questions are governed;
8. critical validation blockers equal zero;
9. G1 has a valid outcome and conditions;
10. BUS-001 or the approved alternative route accepts the handoff.

---

# 13. Reopen Conditions

Reopen when material new evidence contradicts a finding, a key stakeholder or user context was omitted, an assumed cause fails, the current state materially changes, an outcome or signal loses relevance, a GOV-009 trigger changes, or downstream work exposes an unsupported problem or opportunity.

---

# 14. Artifact-Specific Validation Rules

~~~text
DISC2-CVAL-001  A finding cannot be CONFIRMED without a source and validation status.
DISC2-CVAL-002  A symptom cannot silently stand in for a problem.
DISC2-CVAL-003  A cause hypothesis is never labelled as a supported cause without evidence.
DISC2-CVAL-004  An opportunity is not an approved feature or product requirement.
DISC2-CVAL-005  Success signals are observable and trace to desired outcomes.
DISC2-CVAL-006  Reused evidence states freshness and limitations.
DISC2-CVAL-007  Contradictory evidence remains visible through disposition.
DISC2-CVAL-008  G1 PASS is invalid with a critical discovery validation blocker.
~~~
