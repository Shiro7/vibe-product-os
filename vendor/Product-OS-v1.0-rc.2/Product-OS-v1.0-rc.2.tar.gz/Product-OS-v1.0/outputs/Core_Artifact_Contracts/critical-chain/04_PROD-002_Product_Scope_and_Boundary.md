# Core Artifact Contract — PROD-002 Product Scope and Boundary

~~~yaml
contract_id: CONTRACT-PROD-002
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: PROD-002
artifact_name: Product Scope and Boundary
owning_phase: Phase 03 - Product Definition
gate_or_baseline: G3A - Product Baseline
default_activation: REQUIRED_WHEN_PHASE_03_IS_ACTIVE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: BUS-001
primary_downstream: REQ-001
~~~

---

# 1. Purpose

PROD-002 defines what responsibility belongs to the product, what the product supports or integrates with, and what remains human, organizational, policy, external-system, manual, future, conditional, dependent, or out of scope.

It prevents Product Definition from collapsing into a feature list and prevents Requirements Engineering from inventing the product boundary.

---

# 2. Scope and Applicability

The contract activates whenever Phase 03 defines or changes product responsibility, product scope, boundary, lifecycle coverage, channel, platform, integration context, or release allocation.

For an existing product it must distinguish CURRENT, CHANGE, and TARGET. NOT_APPLICABLE is only valid when no product responsibility is being created, changed, recovered, or evaluated and an authoritative alternative boundary exists.

---

# 3. Accountabilities

- **Owner:** product manager / product owner or designated product-definition lead.
- **Business authority:** confirms alignment with BUS-001.
- **Contributors:** experience, design, architecture, engineering, operations, and activated specialists.
- **Decision authority:** authority assigned to approve G3A.
- **AI:** may classify and trace scope candidates; it cannot approve scope, capability priority, or responsibility transfer.

---

# 4. Required Inputs

1. Approved BUS-001 version, G2 decision, and conditions.
2. Business problems, outcomes, objectives, capabilities, processes, roles, rules, controls, information responsibilities, and KPIs.
3. Existing product evidence and current-state assets where applicable.
4. Product vision, mission, objectives, users, roles, capability candidates, policies, constraints, dependencies, and integration context.
5. Active GOV-009 entries and product-level disposition needs.
6. Known release, market, platform, channel, language, document, and third-party constraints.

---

# 5. Required Questions

1. Which business capabilities and outcomes require product responsibility?
2. What does the product own, support, integrate, observe, or leave manual / external?
3. Which responsibilities remain with humans, operations, policy, another product, or an external system?
4. What is in scope now, explicitly out of scope, future, conditional, or dependency-bound?
5. Which product users and roles interact with each boundary area?
6. Which product capabilities cover the approved business need without becoming premature features?
7. Which states, information responsibilities, integration contexts, dependencies, policies, and constraints cross the boundary?
8. For an existing product, what is CURRENT, what changes, and what is the TARGET state?
9. Which GOV-009 obligations create product capability, constraint, policy, platform, journey, generated-document, third-party, or release implications?
10. What must Phase 04 derive as requirements rather than decide itself?

---

# 6. Required Decisions

- product vision, mission, and objectives relevant to the boundary;
- product responsibility allocation;
- boundary type for every material boundary item;
- scope status and justification for every material scope item;
- product capability, domain, module, policy, constraint, information, integration, and dependency implications;
- current / change / target disposition for brownfield work;
- GOV-009 product applicability and derivation route;
- G3A outcome, conditions, and Phase 04 handoff.

---

# 7. Boundary and Scope Taxonomy

Every material boundary item uses one type:

~~~text
OWNED
SUPPORTED
INTEGRATED
OBSERVED
MANUAL
EXTERNAL
OUT_OF_SCOPE
~~~

Every material scope item uses one status:

~~~text
IN_SCOPE
OUT_OF_SCOPE
FUTURE_SCOPE
CONDITIONAL_SCOPE
DEPENDENT_SCOPE
~~~

Boundary type describes responsibility. Scope status describes commitment and timing. They are separate dimensions.

---

# 8. Required Content

PROD-002 contains or references:

1. Product identity, vision, mission, and objectives.
2. Boundary statement and system-of-interest context at product level.
3. Boundary register using the controlled taxonomy.
4. Scope register using the controlled taxonomy and justification.
5. Product vs human / business / policy / external-system responsibility map.
6. Product users, roles, and affected contexts.
7. Product capabilities and business-capability coverage.
8. Product domains and logical modules affected by the boundary.
9. Product lifecycle and state implications.
10. Product information responsibility.
11. Integration context and ownership.
12. Policies, constraints, assumptions, dependencies, risks, and open questions.
13. CURRENT / CHANGE / TARGET delta where applicable.
14. GOV-009 product linkage and Phase 04 derivation types.
15. G3A decision, conditions, and requirements handoff.

---

# 9. Scope Justification and Traceability

Each major scope and boundary item traces to one or more of:

- approved Business Capability;
- Product Objective;
- validated Problem;
- desired Outcome;
- policy, contract, regulation, or active standard;
- governed Product Decision.

Minimum path:

~~~text
Problem / Outcome / BREQ / Business Capability
→ Product Objective
→ Product Capability
→ Boundary and Scope Disposition
→ Phase 04 Requirement Derivation
~~~

The handoff declares which items require FR, NFR, data, integration, security / privacy, accessibility, audit / evidence, acceptance, or other requirements.

---

# 10. GOV-009 Product Linkage

Each applicable GOV-009 entry identifies:

- affected product capabilities;
- product constraints and policies;
- platform, channel, journey, generated-document, and third-party implications;
- product lifecycle and release implications;
- required Phase 04 derivation families;
- evidence or decision gaps;
- reopen triggers.

Generic statements such as “must be accessible” or “must be secure” do not satisfy this linkage.

---

# 11. Profile Behavior

- **P1:** boundary, scope, capability coverage, and delta views may share PROD-002 while retaining stable item IDs.
- **P2:** capability, domain, module, integration, policy, dependency, and scope records remain modular and independently reviewable.
- **P3:** multi-market, multi-platform, regulated, safety, data, third-party, and lifecycle boundaries receive specialist and independent assurance.

---

# 12. Verification and Evidence

Verification confirms:

- each material product responsibility has business justification;
- boundary and scope dimensions are not conflated;
- unsupported feature ideas are not hidden inside scope wording;
- external and manual responsibilities have owners and dependency implications;
- CURRENT / CHANGE / TARGET is evidence-based where applicable;
- GOV-009 entries have product and requirements derivation disposition;
- Phase 04 can derive requirements without inventing product behavior or scope.

---

# 13. Exit Criteria

PROD-002 is complete only when:

1. product responsibility and exclusions are unambiguous;
2. every material item has boundary type, scope status, justification, owner, and trace links;
3. product capabilities sufficiently cover the approved business need;
4. product vs human / external / policy responsibilities are separated;
5. current-state delta is explicit for existing products;
6. information, integration, policy, constraint, dependency, and lifecycle implications are governed;
7. GOV-009 applicability has been reviewed before G3A;
8. no G3A blocker would force Phase 04 to invent scope or product behavior;
9. G3A has a valid outcome and conditions;
10. REQ-001 accepts the handoff.

---

# 14. Reopen Conditions

Reopen on a material change to business baseline, product objective, responsibility owner, capability, market, platform, channel, user, lifecycle, integration, third party, standard applicability, release strategy, or evidence showing the current boundary is inaccurate.

---

# 15. Artifact-Specific Validation Rules

~~~text
PROD2-CVAL-001  Boundary type and scope status are separately recorded.
PROD2-CVAL-002  Every major scope item has business and product justification.
PROD2-CVAL-003  Feature candidates are not treated as approved requirements.
PROD2-CVAL-004  OWNED responsibility has an accountable product owner.
PROD2-CVAL-005  EXTERNAL and MANUAL items expose dependency and failure implications.
PROD2-CVAL-006  Brownfield scope distinguishes CURRENT, CHANGE, and TARGET.
PROD2-CVAL-007  GOV-009 entries name affected capabilities and derivation families.
PROD2-CVAL-008  G3A PASS is invalid if Phase 04 must invent material scope or behavior.
~~~
