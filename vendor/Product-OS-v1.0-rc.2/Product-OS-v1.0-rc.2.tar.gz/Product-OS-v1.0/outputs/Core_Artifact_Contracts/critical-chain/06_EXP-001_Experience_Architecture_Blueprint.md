# Core Artifact Contract — EXP-001 Experience Architecture Blueprint

~~~yaml
contract_id: CONTRACT-EXP-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: EXP-001
artifact_name: Experience Architecture Blueprint
owning_phase: Phase 05 - Experience Architecture
gate_or_baseline: G4A - Experience Baseline
default_activation: REQUIRED_WHEN_PHASE_05_IS_ACTIVE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: REQ-001
primary_downstream: DES-023
~~~

---

# 1. Purpose

EXP-001 is the human-readable Experience Baseline connecting actors and goals to scenarios, journeys, flows, information architecture, navigation, views, states, cross-cutting behavior, and recovery.

Experience Architecture owns the logical journey, navigation, context, state, and interaction contract. Product Design realizes and references that contract; it does not silently redefine it.

---

# 2. Scope and Applicability

The contract activates whenever Phase 05 defines or changes a user, operator, administrator, support, partner, machine-mediated, or assisted experience.

Non-visual services still require experience disposition for actors, states, errors, support, and recovery where humans are affected. NOT_APPLICABLE requires evidence that no actor-facing or human-operational experience exists in the exact scope and records the alternative responsibility and reopen conditions.

---

# 3. Accountabilities

- **Owner:** experience architect, UX lead, or designated equivalent.
- **Contributors:** product, requirements, content, design, architecture, engineering, support, operations, research, and activated specialists.
- **Decision authority:** authority assigned to accept G4A.
- **Accessibility and localization authority:** named when the associated GOV-009 profile is active.
- **AI:** may synthesize journeys, states, and gap views; it cannot claim user validation, approve safety behavior, or replace an authoritative requirement.

---

# 4. Required Inputs

1. Approved REQ-001 baseline identity, G3B outcome, and conditions.
2. Product scope, users, roles, capabilities, states, policies, constraints, dependencies, and integration context.
3. Discovery evidence about user contexts, barriers, workarounds, and outcomes.
4. Content, accessibility, localization, RTL, platform, channel, responsive, safety, security, privacy, and support obligations.
5. Existing journeys, navigation, interfaces, analytics, incidents, and support evidence for brownfield work.

---

# 5. Required Questions

1. Which actors pursue which goals, in which contexts, channels, devices, and constraints?
2. Which scenarios and end-to-end journeys are critical, high-risk, high-frequency, irreversible, or recovery-sensitive?
3. What information and orientation must each actor have before, during, and after an action?
4. How does navigation preserve identity, authorization, tenant / entity / workspace, task, and process context?
5. Which views or routes are required by the journey rather than merely desired as screens?
6. Which loading, empty, partial, success, error, offline, interrupted, unauthorized, forbidden, expired, conflicting, and recovery states apply?
7. How do errors prevent harm, preserve work, explain consequences, and support recovery?
8. What keyboard, focus, semantic, contrast, reflow, touch, alternative-input, announcement, and assistive-technology behavior is required?
9. How do responsive structure, platform convention, localization, RTL, content expansion, and generated outputs alter the experience?
10. Which assumptions require validation before G4A or Product Design?

---

# 6. Required Decisions

- actor / goal / context coverage;
- critical scenario and journey set;
- journey, flow, and cross-channel continuity;
- information architecture and navigation model;
- context-preservation and state-transition rules;
- required view / route inventory and responsibilities;
- error, interruption, safety, and recovery behavior;
- accessibility, localization, RTL, responsive, and platform rules;
- validation disposition and residual conditions;
- G4A outcome and Product Design handoff.

---

# 7. Required Content

EXP-001 contains or references:

1. Experience baseline identity, scope, and source revisions.
2. Actors, goals, contexts, channels, platforms, and constraints.
3. Scenario inventory and criticality.
4. End-to-end journey map.
5. Task, service, and system flows.
6. Information architecture.
7. Navigation, wayfinding, orientation, and context model.
8. View / route inventory and responsibility.
9. State model and transition rules.
10. Loading, empty, partial, success, error, authorization, interruption, offline, conflict, and recovery states.
11. Interaction principles and high-risk action rules.
12. Content, terminology, messages, confirmations, and consequence communication.
13. Responsive and cross-platform behavior.
14. Accessibility behavior.
15. Localization, internationalization, and RTL behavior.
16. Validation scope, methods, evidence, findings, limitations, and disposition.
17. Traceability to requirements and GOV-009.
18. Risks, assumptions, dependencies, exceptions, and open questions.
19. G4A decision, conditions, and Design handoff.

---

# 8. Ownership Boundary

EXP-001 owns logical experience behavior:

- journey purpose and sequence;
- information and navigation structure;
- view responsibility;
- state and transition meaning;
- context preservation;
- error, safety, interruption, and recovery logic;
- cross-cutting responsive, accessibility, localization, and RTL behavior.

It does not own visual styling, token values, production components, code architecture, or test execution. DES-023 must reference this meaning rather than replace it with disconnected screens.

---

# 9. Traceability and Handoff

Minimum paths include:

~~~text
Actor / Goal / Context
→ Scenario
→ Journey
→ Flow
→ View / Route
→ State / Transition
→ Requirement / Acceptance Criterion
→ Design Realization

GOV-009 Entry
→ Experience Rule
→ View / State / Journey Coverage
→ Design and Verification Handoff
~~~

The handoff states exact G4A baseline identity, included journeys, IA and navigation, view / route responsibilities, state and recovery rules, cross-cutting behavior, validation findings, open non-blocking conditions, prohibited design changes, and change-control route.

---

# 10. Profile Behavior

- **P1:** scenario, journey, flow, IA, view, and state views may be consolidated while critical end-to-end behavior remains explicit.
- **P2:** major journeys, navigation, state models, accessibility, content, and validation records are modular and reviewable.
- **P3:** critical journeys receive independent research / validation, specialist accessibility and localization assurance, safety analysis, cross-platform coverage, and stronger evidence retention.

---

# 11. Verification and Evidence

Verification confirms:

- every critical requirement has an experience disposition or valid non-experience allocation;
- every critical journey is end-to-end and includes exception and recovery paths;
- navigation preserves material context and authorization boundaries;
- view inventory and state coverage are complete for the approved scope;
- accessibility and RTL behavior are structural, not generic labels;
- validation claims identify method, participants / evidence scope, findings, limitations, and revisions;
- Product Design can realize the baseline without inventing experience logic.

---

# 12. G4A Blocking Conditions

G4A cannot pass when committed scope has any of the following:

- no defined critical journey;
- identity, authorization, or context contradiction;
- undefined recovery for payment, irreversible, destructive, or critical actions;
- navigation that cannot preserve required context;
- critical forms without error, focus, and recovery behavior;
- accessibility represented only by a generic claim;
- structural mobile, responsive, localization, or RTL behavior left undefined;
- unresolved GOV-009 experience gap;
- critical validation blocker.

---

# 13. Exit Criteria

EXP-001 is complete only when actors, contexts, critical journeys, IA, navigation, views, states, error / recovery, responsive, accessibility, localization, RTL, validation, traceability, and conditions are sufficient for Design; G4A has valid authority and outcome; and DES-023 can be prepared without inventing experience logic.

---

# 14. Reopen Conditions

Reopen on a material requirement, role, context, journey, navigation, state, policy, platform, channel, accessibility, localization, RTL, safety, content, or validation change, or when design / implementation evidence exposes a missing or harmful experience rule.

---

# 15. Artifact-Specific Validation Rules

~~~text
EXP1-CVAL-001  Every critical journey traces to actor, goal, requirements, and success / failure states.
EXP1-CVAL-002  Every committed view has responsibility, route / entry context, and state coverage.
EXP1-CVAL-003  Error handling includes consequence, preservation, recovery, and escalation where applicable.
EXP1-CVAL-004  Authorization and navigation context remain consistent.
EXP1-CVAL-005  Accessibility and RTL are expressed as behavior, not generic claims.
EXP1-CVAL-006  Validation evidence cannot be invented or generalized beyond its scope.
EXP1-CVAL-007  Design screens cannot silently redefine approved experience logic.
EXP1-CVAL-008  G4A PASS is invalid with a critical journey or recovery gap.
~~~
