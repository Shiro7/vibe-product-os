# Core Artifact Contract — INIT-001 Product / Project Brief

~~~yaml
contract_id: CONTRACT-INIT-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: INIT-001
artifact_name: Product / Project Brief
owning_phase: Phase 00 - Initialization and Intake
gate_or_baseline: G0 - Intake Ready
default_activation: REQUIRED_WHEN_PHASE_00_IS_ACTIVE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_downstream: DISC-002
~~~

---

# 1. Purpose

INIT-001 is the human-readable entry summary for work entering Product OS. It establishes what entered, why it entered, who supplied and may authorize information, what is known about the current state, which material unknowns remain, and where the work routes next.

It is an intake baseline, not a discovery conclusion, product scope, requirements specification, or solution proposal.

---

# 2. Scope and Applicability

The contract activates for every Product OS entry path: early idea, new product, business transformation, existing product, implementation in progress, recovery, or continuous evolution.

At least one legitimate entry input must exist:

- project or product description;
- business need or trigger;
- existing product or implementation context;
- change or evolution request;
- recovery or stabilization request.

INIT-001 cannot be omitted merely because the source is informal, incomplete, or already technical. NOT_APPLICABLE is permitted only when the work is demonstrably outside Product OS and the routing authority records the reason, evidence, downstream implications, and reopen condition.

---

# 3. Accountabilities

- **Owner:** designated intake analyst, product analyst, or equivalent role.
- **Information providers:** initiator and registered source owners.
- **Decision authority:** identified business / product authority for G0 and routing.
- **Specialist reviewers:** activated when a material standard, security, privacy, accessibility, regulatory, contractual, data, or recovery trigger exists.
- **AI:** may classify, extract, draft, and identify gaps; it cannot declare a source authoritative or approve G0.

Named people or systems of record are project-instance data and must not be invented by this contract.

---

# 4. Required Inputs

1. Registered raw source identities and received revisions.
2. Initiator and available authority context.
3. Entry reason and why-now trigger.
4. Available current-state description and existing asset references.
5. Stated problem, need, requested change, or recovery condition.
6. Desired outcomes or success signals supplied by stakeholders.
7. Known constraints, dependencies, deadlines, budgets, commitments, and risk signals.
8. Potential standards and compliance triggers for GOV-009.

Unavailable information is recorded as an explicit unknown or question, never silently completed.

---

# 5. Required Questions

INIT-001 must answer or disposition:

1. What product, project, service, system, or change has entered Product OS?
2. Why has it entered now, and what happens if no action is taken?
3. Who supplied each material source, and what authority does that source carry?
4. What exists today, and how fresh is the available evidence?
5. What problem, need, trigger, or recovery condition is being presented?
6. What outcome is desired, and which signals would indicate progress?
7. Which material constraints, dependencies, commitments, or deadlines already exist?
8. Which markets, users, platforms, languages, data, payments, generated documents, third parties, contracts, or regulations may activate GOV-009?
9. Which contradictions and unknowns block safe routing?
10. Which methodology phase and profile should receive the work next?

---

# 6. Required Decisions

- primary Product State and any secondary state indicators;
- preliminary P1 / P2 / P3 delivery profile;
- preliminary risk class and any domain-level escalation;
- engagement scope where commercially relevant, kept distinct from methodology scope;
- preliminary GOV-009 trigger routing;
- next-phase or recovery route;
- G0 outcome: PASS, PASS_WITH_CONDITIONS, HOLD, or REJECT.

Each decision records authority, evidence, rationale, conditions, and reopen triggers. Preliminary decisions are labelled as preliminary.

---

# 7. Required Content

INIT-001 contains or references:

1. **Project identity** — stable project ID, working name, entry date, and context.
2. **Entry context** — entry path, trigger, why now, and initiating request.
3. **Source baseline** — registered sources, revisions, owners, authority, reliability, and restrictions.
4. **Atomic information summary** — facts, assumptions, requested ideas, decisions, requirements, and open questions without changing their state.
5. **Authority snapshot** — known decision and information authority plus gaps.
6. **Product State** — selected state, supporting evidence, ambiguity, and implications.
7. **Current state** — what exists, what is only claimed, freshness, and material assets.
8. **Problem and desired outcome** — preliminary wording with source links.
9. **Constraints and dependencies** — hard, soft, claimed, and unverified items kept distinct.
10. **Risk and contradiction signals** — severity, ownership, impact, and disposition.
11. **Standards applicability triggers** — preliminary GOV-009 entries and required specialist routes.
12. **Open questions** — priority, blocker status, owner, and due event.
13. **Preliminary classification** — profile, risk, engagement, and rationale.
14. **G0 decision and conditions.**
15. **Next-phase recommendation and handoff.**

---

# 8. Objects Owned and Referenced

INIT-001 owns the approved human-readable intake summary. Detailed source, atomic-item, authority, classification, asset, question, risk, decision, GOV-008, and GOV-009 records remain canonical in their designated registers.

The brief must reference those IDs rather than duplicate or renumber them. It does not own DISC findings, validated causes, business requirements, product capabilities, or solution decisions.

---

# 9. Traceability and Handoff

Minimum trace path:

~~~text
Raw Source
→ Atomic Item
→ INIT-001 statement / question / decision
→ G0 condition or route
→ DISC-002 or approved alternative route
~~~

The handoff states:

- sender, receiver, INIT-001 version, and G0 decision identity;
- included and excluded scope;
- source and asset identities;
- Product State and preliminary classification;
- problem, desired outcomes, constraints, dependencies, and risk signals;
- GOV-009 triggers and pending applicability decisions;
- open non-blocking questions and all G0 conditions;
- prohibited downstream assumptions and change route.

---

# 10. Profile Behavior

- **P1:** INIT-001 may contain linked source, atomic-item, authority, and classification views, but the logical records and trace links remain explicit.
- **P2:** supporting registers are independently maintained and reviewable; material triggers and routing decisions receive named review.
- **P3:** source authority, evidence handling, specialist applicability, segregation, and intake approval receive stronger independent assurance.

---

# 11. Verification and Evidence

Required checks confirm:

- each material statement maps to a registered source or explicit assumption;
- the selected Product State is evidence-supported;
- critical contradictions and Q0 blockers have zero unresolved items at PASS;
- standard applicability triggers were actively evaluated;
- G0 authority and decision are valid;
- the next route can consume the handoff without inventing context.

Evidence includes the exact brief version, source register snapshot, question and contradiction status, GOV-009 trigger view, and G0 decision record.

---

# 12. Exit Criteria

INIT-001 is complete only when:

1. project context and entry reason are identifiable;
2. sources and meaningful atomic inputs are registered;
3. authority context and gaps are explicit;
4. Product State and current-state freshness are stated;
5. problem / need and desired outcome are captured without false validation;
6. material constraints, dependencies, risks, contradictions, and unknowns are visible;
7. intake-blocking questions equal zero for PASS or PASS_WITH_CONDITIONS;
8. preliminary classification and GOV-009 triggers are recorded;
9. G0 has a valid outcome, authority, rationale, and conditions;
10. the downstream route and handoff are accepted.

---

# 13. Reopen Conditions

Reopen on a material new source, authority correction, Product State change, current-state contradiction, new critical risk, new standards trigger, invalid G0 condition, or downstream evidence showing the intake route was unsafe or incomplete.

---

# 14. Artifact-Specific Validation Rules

~~~text
INIT1-CVAL-001  INIT-001 is not marked complete without at least one registered entry source.
INIT1-CVAL-002  Requested ideas remain distinct from approved requirements.
INIT1-CVAL-003  Preliminary outcomes are not presented as validated Discovery findings.
INIT1-CVAL-004  Product State includes evidence and ambiguity disposition.
INIT1-CVAL-005  Every G0 condition has an owner and due event.
INIT1-CVAL-006  Standards trigger capture is present even when no trigger is found.
INIT1-CVAL-007  PASS is invalid while a Q0 intake blocker remains open.
INIT1-CVAL-008  Next routing references an exact receiving phase or governed alternative.
~~~
