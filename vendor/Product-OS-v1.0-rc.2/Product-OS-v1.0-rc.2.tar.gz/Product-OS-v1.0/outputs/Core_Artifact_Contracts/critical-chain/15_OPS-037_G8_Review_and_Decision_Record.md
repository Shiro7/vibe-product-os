# Core Artifact Contract — OPS-037 G8 Review and Decision Record

~~~yaml
contract_id: CONTRACT-OPS-037
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: OPS-037
artifact_name: G8 Review and Decision Record
owning_phase: Phase 11 - Operations and Evolution
gate_or_baseline: G8 - Sustainability and Evolution Review
default_activation: REQUIRED_AT_G8_CADENCE_AND_TRIGGER_EVENTS
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: OPS-003
primary_downstream: Lifecycle routing
~~~

---

# 1. Purpose

OPS-037 records the recurring G8 decision about whether a bounded live scope should be sustained, sustained with actions, remediated, evolved, constrained, assessed for sunset or transfer, or critically escalated.

G8 governs operational sustainability and lifecycle routing. It does not authorize implementation, release, production access, or a change outside the recorded scope.

---

# 2. Scope and Applicability

OPS-037 is required at the approved G8 cadence and whenever a trigger event demands review. One review may produce multiple scope-specific outcomes when different services, tenants, regions, capabilities, versions, or risks require different routes.

A live scope cannot be NOT_APPLICABLE to G8 solely because no major change is planned. Sustaining operation is itself a governed decision.

---

# 3. Accountabilities

- **Owner:** service / product operations governance owner or designated G8 coordinator.
- **Decision authorities:** named product / business, service / operations, technology, risk, and specialist authorities required by scope.
- **Contributors:** support, incident, security, privacy, accessibility, data, audit, reliability, finance, vendor, legal, product, engineering, and user / market evidence owners as applicable.
- **Route receivers:** owners of sustainment actions or the methodology phase receiving remediation, evolution, constraint, sunset, transfer, or escalation work.
- **AI:** may correlate period evidence and propose routes; it cannot decide sustainability, accept risk, authorize change, or claim an action occurred.

---

# 4. Required Inputs

1. Current accepted OPS-003 OBL and exact live scope.
2. Review period, cadence, previous G8 decision, conditions, and action status.
3. Service health, SLI / SLO, error budget, product outcome, user, support, incident, problem, control, security, privacy, accessibility, data, audit, reliability, capacity, cost, vendor, maintenance, debt, and lifecycle evidence.
4. Active risks, exceptions, waivers, restrictions, end-of-life conditions, contracts, standards, and GOV-009 entries.
5. Candidate improvements, experiments, strategy, market, portfolio, and technology signals.
6. Trigger event evidence where the review is event-driven.

---

# 5. Required Questions

1. Is the OBL current and sufficiently bound to the review scope and period?
2. Is the live service achieving accepted technical, product, user, control, and business outcomes?
3. Which health, risk, control, incident, cost, dependency, or debt trends are improving, stable, degrading, or unknown?
4. Can the scope be safely sustained under current ownership, capacity, controls, vendors, and recovery capability?
5. Which actions are mandatory even if the primary decision is SUSTAIN?
6. Which evidence justifies remediation, evolution, constraint, sunset review, transfer review, or critical escalation?
7. Does the decision differ by service, capability, tenant, cohort, region, platform, version, or lifecycle state?
8. Which methodology route must receive each approved action or candidate?
9. Which constraints, risks, exceptions, or debt continue, and when do they expire or trigger re-review?
10. When is the next review and which events reopen the decision earlier?

---

# 6. Required Decisions and Outcomes

~~~text
SUSTAIN
SUSTAIN_WITH_ACTIONS
REMEDIATE
EVOLVE
CONSTRAIN
SUNSET_REVIEW
TRANSFER_REVIEW
CRITICAL_ESCALATION
~~~

The record may contain one overall outcome and multiple scope-specific outcomes. Each route has owner, authority, target phase or operational action, due event, evidence expectation, and constraint.

---

# 7. Minimum Decision Record

OPS-037 records:

1. Gate / review ID.
2. OBL ID and version.
3. Exact live scope.
4. Review period and evidence cut-off.
5. Overall outcome.
6. Scope-specific outcomes.
7. Health and sustainability assessment.
8. Required actions and priorities.
9. Lifecycle and methodology routes.
10. Continuing constraints, conditions, risks, exceptions, restrictions, and debt.
11. Decision makers, authority, reviewers, and dissent.
12. Next review date / cadence.
13. Trigger events for earlier review.
14. Evidence index and limitations.
15. Previous-action disposition and handoff acknowledgement.

---

# 8. Outcome Semantics

- **SUSTAIN:** continue the bounded live scope under the accepted OBL and normal cadence.
- **SUSTAIN_WITH_ACTIONS:** continue while named, enforceable operational actions are completed.
- **REMEDIATE:** route bounded defects, controls, resilience, debt, or operational weaknesses into governed correction.
- **EVOLVE:** route an evidence-supported opportunity or change through the appropriate Product OS phases.
- **CONSTRAIN:** reduce scope, cohort, access, capability, traffic, geography, or behavior to manage risk.
- **SUNSET_REVIEW:** initiate governed assessment of retirement, migration, retention, user / contract impact, and exit.
- **TRANSFER_REVIEW:** assess a change of ownership, vendor, platform, service boundary, or operating responsibility.
- **CRITICAL_ESCALATION:** invoke immediate authority for intolerable risk, harm, control failure, or unsustainable operation.

None of these outcomes bypasses the gates required to implement or release a change.

---

# 9. Trigger Events

An event-driven G8 review is required for material:

- incident, problem recurrence, or service deterioration;
- security, privacy, accessibility, audit, data, safety, or control finding;
- standard, regulation, policy, or contract change;
- market, country, language, platform, channel, or user expansion;
- vendor, external dependency, infrastructure, or platform change;
- capacity, performance, reliability, cost, or error-budget breach;
- strategy, portfolio, ownership, funding, or operating-model change;
- backup, restore, DR, recovery, or continuity failure;
- technology, dependency, certificate, license, or service end of life;
- expired exception, waiver, risk acceptance, restriction, or debt commitment.

---

# 10. Traceability and Routing Contract

Each non-routine action routes to the earliest phase that owns the changed truth:

~~~text
New / changed problem or evidence → Phase 01
Business operating or control change → Phase 02
Product scope / capability / responsibility change → Phase 03
Requirement change → Phase 04
Experience behavior change → Phase 05
Design change → Phase 06
Architecture change → Phase 07
Readiness / planning change → Phase 08
Authorized implementation → Phase 09
Verification and release decision → Phase 10
Operational-only action → Phase 11
~~~

Emergency response may act immediately within existing authority, then records evidence and routes lasting changes through the correct phase.

---

# 11. Profile Behavior

- **P1:** one concise review may combine health, risks, actions, and decisions, while exact scope and evidence remain explicit.
- **P2:** domain health, action, risk, cost, control, and evolution assessments are modular and reviewed by owners.
- **P3:** independent sustainability, regulatory, security / privacy, accessibility, resilience, finance, vendor, and portfolio review strengthen; decision evidence and action follow-through receive formal assurance.

---

# 12. Verification and Evidence

Decision verification confirms:

- OPS-003 is current for the exact scope and period;
- assessment uses evidence from the relevant period and does not hide degraded or unknown state;
- prior conditions and actions are dispositioned;
- outcome follows health, risk, control, user, business, cost, and lifecycle evidence;
- every action and route has owner, authority, due event, evidence, and acknowledgement;
- scope-specific differences are visible;
- the decision does not imply implementation or release authorization.

---

# 13. Exit Criteria

OPS-037 is complete only when exact scope, OBL, period, evidence, outcome, scope-specific outcomes, actions, routes, constraints, risks, exceptions, authority, next review, triggers, and handoff acknowledgement are recorded and all critical escalations have active ownership.

---

# 14. Reopen Conditions

Reopen on any scheduled cadence, listed trigger event, material evidence correction, scope or OBL change, action failure, expired condition, new critical incident, or changed authority. A reopened G8 record creates a new review identity or revision while preserving history.

---

# 15. Artifact-Specific Validation Rules

~~~text
OPS37-CVAL-001  G8 binds an exact OBL, live scope, review period, and evidence cut-off.
OPS37-CVAL-002  Multiple scope outcomes remain distinct when health or risk differs.
OPS37-CVAL-003  Every action and route has owner, due event, evidence, and acknowledgement.
OPS37-CVAL-004  Prior G8 conditions and actions receive explicit disposition.
OPS37-CVAL-005  Degraded and unknown state cannot be hidden inside SUSTAIN.
OPS37-CVAL-006  G8 does not authorize implementation or release.
OPS37-CVAL-007  Trigger events can reopen review before the scheduled cadence.
OPS37-CVAL-008  CRITICAL_ESCALATION has immediate authority and ownership.
~~~
