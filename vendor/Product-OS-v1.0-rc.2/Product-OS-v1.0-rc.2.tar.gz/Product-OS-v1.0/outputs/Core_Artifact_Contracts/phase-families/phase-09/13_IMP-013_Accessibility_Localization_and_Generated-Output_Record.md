# Core Artifact Contract — IMP-013 Accessibility, Localization, and Generated-Output Record

~~~yaml
contract_id: CONTRACT-IMP-013
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-013
artifact_name: Accessibility, Localization, and Generated-Output Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Checks 07, 17, 27, and 28 / IBL
default_activation: CONDITIONAL_BY_PLATFORM_LANGUAGE_OUTPUT_AND_GOV009
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: accessibility / localization requirements, EXP / DES baselines, ARC-027, ENG-021, ENG-028, ENG-031, and GOV-009
primary_downstream: IMP-005, IMP-006, IMP-016, IMP-022, IMP-026 through IMP-032, Phase 10 accessibility / localization verification, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

IMP-013 is the canonical cross-cutting implementation record for accessibility, localization, internationalization, RTL / LTR, timezone / calendar / money / number behavior, fonts / shaping, content, and accessible generated documents / emails / reports. It maps each obligation to exact production targets, checks, evidence, known limits, and remaining independent verification.

Activate based on applicable platforms, user needs, locales, directions, outputs, markets, contracts, and GOV-009. A platform, language, output, or criterion may be NOT_APPLICABLE only through the governed applicability contract.

---

# 2. Inputs, Owners, and Decisions

Inputs include WCAG / applicable standards profile; experience and design accessibility contracts; platform semantics; focus / keyboard / forms / errors; responsive / reflow / zoom / reduced motion; locales / RTL; time / money / formats; content / fonts; generated-output structure; assistive contexts; exact code targets; checks; evidence and verification allocation.

Accessibility, localization / content, design, Engineering, platform, document-output, and verification owners are named. Decisions cover implementation targets, supported contexts, fallback, automated / manual checks, evidence, known limits, divergence, and remaining verification.

---

# 3. Minimum Record

~~~yaml
cross_cutting_implementation_record_id:
run_work_requirement_design_architecture_gov009_refs: []
platforms_surfaces_components_states_and_generated_outputs: []
repository_revision_and_implementation_targets: []
semantics_names_roles_values_relationships_and_announcements: []
focus_keyboard_forms_errors_timeout_and_recovery: []
contrast_target_size_zoom_reflow_orientation_and_reduced_motion: []
locales_languages_rtl_ltr_fonts_shaping_and_content: []
timezone_calendar_date_number_money_address_and_sorting: []
generated_output_structure_order_metadata_fonts_and_alternatives: []
automated_manual_assistive_platform_checks_and_evidence: []
known_limits_divergences_and_remaining_verification: []
status_and_owners:
~~~

---

# 4. Cross-Cutting Truth and Traceability

Accessibility and localization are product implementation requirements, not post-build decoration. Automated scans, translated strings, RTL screenshots, or a valid PDF alone cannot prove complete behavior. Exact obligations remain connected from GOV-009 / requirements / design through production source, states, outputs, tests, evidence, candidate, and Phase 10 verification.

---

# 5. Profiles, Exit, and Reopen

Level 1 retains all critical journey and required standard obligations; Level 2 covers all applicable components / screens / states / locales / outputs; Level 3 adds independent assistive-technology, multi-platform / locale, generated-output, language-quality, and evidence-custody assurance.

Exit requires applicable obligations implemented in exact targets with critical states, platform semantics, locale / direction behavior, generated outputs, checks, evidence, governed limits, and remaining verification. Reopen on standard, user need, platform, component, state, content, locale, direction, font, output generator, assistive context, environment, or candidate change.

---

# 6. Validation Rules

~~~text
IMP13-CVAL-001  Every applicable accessibility, localization, RTL, formatting, font, content, and generated-output obligation binds exact production targets, owners, status, and evidence.
IMP13-CVAL-002  Semantics, focus, keyboard, forms, errors, timeouts, reflow, zoom, contrast, target size, reduced motion, and recovery are implemented across applicable states.
IMP13-CVAL-003  Locale, language, direction, shaping, date / time, calendar, number, currency, address, sorting, pluralization, and fallback behavior are explicit.
IMP13-CVAL-004  Generated outputs preserve structure, reading order, metadata, language / direction, fonts, alternatives, pagination, contrast, and accessible delivery as applicable.
IMP13-CVAL-005  Automated, manual, assistive-technology, visual, content, and generated-output checks identify exact revision, platform, locale, state, method, result, and evidence.
IMP13-CVAL-006  Scanner pass, translated strings, RTL screenshot, semantic component, or visually correct PDF cannot alone prove end-to-end conformance or usability.
IMP13-CVAL-007  Known limits and divergences state affected users / contexts, severity, authority, mitigation, verification / release restriction, owner, and resolution.
IMP13-CVAL-008  Standard, platform, state, component, locale, content, font, output, assistive context, environment, or candidate change triggers impact and revalidation.
~~~

