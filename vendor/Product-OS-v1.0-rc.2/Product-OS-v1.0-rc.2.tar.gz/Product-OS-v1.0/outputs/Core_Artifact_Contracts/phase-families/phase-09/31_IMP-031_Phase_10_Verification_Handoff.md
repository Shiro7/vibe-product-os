# Core Artifact Contract — IMP-031 Phase 10 Verification Handoff

~~~yaml
contract_id: CONTRACT-IMP-031
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-031
artifact_name: Phase 10 Verification Handoff
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Check 30 / IBL Handoff to Phase 10
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: IMP-001 through IMP-030, IMP-032 candidate index, ENG-031 / ERBL / G5B, RBL / EBL / DBL / ABL, GOV-009, and governance registers
primary_downstream: Phase 10 Verification and Release, VRL artifacts, G6B, G7, release execution, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

IMP-031 transfers one exact Implementation Baseline and IMP-029 candidate to Phase 10 with scope, exclusions, source / artifact / schema / migration / configuration / infrastructure / environment / deployment / flag identity, mappings, verification allocations, acceptance criteria, test contexts, evidence, known items, candidate-change rules, owners, support, conditions, and receiver acknowledgement.

It prevents Verification from testing an ambiguous “latest” candidate or inventing missing behavior, identities, data, environments, controls, or acceptance scope.

---

# 2. Scope and Applicability

IMP-031 is CORE for every candidate entering Phase 10. Separate handoffs may be used for independent candidates, platforms, environments, migrations, cohorts, risk domains, or verification tracks, but shared dependencies and compatible snapshot boundaries must be explicit.

Handoff acknowledgement means intake is usable; it is not G6A, G6B, UAT, release, or compliance approval.

---

# 3. Accountabilities

- **Sender:** implementation lead accountable for truthful candidate, scope, evidence, open items, and support information.
- **Contributors:** repository / build / data / migration / platform / design / architecture / security / privacy / accessibility / operations owners.
- **Receiver:** QA / Verification lead accountable for intake acknowledgement, verification planning, and candidate-change handling.
- **G6A authority:** approves the exact handoff scope through the gate record.
- **AI:** may assemble and cross-check the manifest but cannot claim acknowledgement, waive gaps, approve G6A / G6B, or release.

---

# 4. Required Inputs and Decisions

Inputs include stable IMP-029, IMP-030 results, proposed IMP-032, all applicable IMP artifacts and evidence, upstream baselines, acceptance / verification allocations, environments / data / identities / tools, open defects / deviations / debt / conditions, support / runbooks, and candidate invalidation rules.

Required decisions are handoff ID / revision; candidate and IBL identity; included / excluded verification scope; canonical source and runtime snapshot; verification methods / owners / contexts; evidence accepted for intake; known limitations; permitted / prohibited work; freeze / invalidation / replacement; support and escalation; acknowledgement outcome and unresolved intake items.

---

# 5. Minimum Handoff Record

~~~yaml
phase10_handoff_id_and_revision:
implementation_baseline_g6a_and_imp029_candidate_refs: []
included_excluded_conditional_and_shared_scope: []
source_artifact_schema_migration_configuration_infrastructure_environment_deployment_domain_and_flag_snapshot: []
requirement_experience_design_architecture_and_gov009_mappings: []
acceptance_criteria_and_verification_allocations: []
test_data_identities_roles_tenants_locales_platforms_tools_and_access: []
implementation_checks_and_evidence_index: []
known_defects_blockers_deviations_exceptions_debt_conditions_and_restrictions: []
remaining_verification_release_and_operational_obligations: []
candidate_freeze_invalidation_replacement_and_evidence_reuse_rules: []
support_contacts_runbooks_dependencies_and_escalation: []
sender_and_receiver_owners: []
acknowledgement_status_findings_and_date:
reopen_triggers: []
~~~

---

# 6. Intake, Authority, and Change Rules

The receiver confirms the manifest is sufficiently exact to plan and bind tests. Missing critical environment, data, identity, acceptance, evidence, control, known-item, or invalidation information results in CONDITIONAL_INTAKE, HOLD, or rejection of affected scope.

Any material candidate change updates IMP-029 and IMP-031, assesses every reused result / evidence item as VALID, PARTIALLY_REUSABLE, STALE, or INVALID, and reopens G6A when required. Verification never silently follows a moving branch, deployment, flag, schema, or environment.

Required path:

~~~text
ENG-031 / ERBL / G5B
  -> IMP Implementation / Evidence
  -> IMP-029 Candidate
  -> IMP-030 G6A Validation
  -> IMP-031 Acknowledged Handoff
  -> Phase 10 Verification Results / G6B / G7
~~~

---

# 7. Profiles, Evidence, Exit, and Reopen

Level 1 uses a compact exact candidate manifest; Level 2 requires modular domain mappings, contexts, evidence, and formal acknowledgement; Level 3 adds signed manifests, chain of custody, separation, controlled data / access, multi-environment tracks, formal evidence reuse, and independent intake review.

IMP-031 exits when receiver can identify, access, reproduce or confirm, test, and invalidate the exact candidate without invention; all limitations and open items are visible; support exists; and acknowledgement is recorded. Reopen on candidate, scope, source / artifact, schema / migration, config / flag, infrastructure / environment / deployment, data / identity / tool, evidence, defect / deviation / condition, owner, or verification-allocation change.

---

# 8. Validation Rules

~~~text
IMP31-CVAL-001  IMP-031 binds one exact IBL / G6A scope and IMP-029 candidate with immutable source, artifact, data, configuration, infrastructure, environment, deployment, domain, and flag identities.
IMP31-CVAL-002  Included, excluded, conditional, shared, deferred, implementation-checked, verification-pending, verified, release-authorized, and operational states remain distinct.
IMP31-CVAL-003  Every critical criterion and obligation maps verification method, environment, data / identity / tool, owner, evidence expectation, timing, and status.
IMP31-CVAL-004  Known defects, blockers, deviations, exceptions, debt, conditions, restrictions, residual risks, and prohibited actions are complete and linked to affected scope.
IMP31-CVAL-005  Receiver acknowledgement records exact handoff revision, candidate, access / context checks, findings, conditions, owner, date, and unresolved intake items.
IMP31-CVAL-006  Branch labels, latest deployment, green build, evidence index, meeting note, or sender claim cannot substitute for exact candidate and receiver acknowledgement.
IMP31-CVAL-007  Handoff acknowledgement cannot issue G6A / G6B, accept product or compliance risk, approve UAT, authorize release, or claim operational success.
IMP31-CVAL-008  Material candidate, scope, source / runtime identity, verification context, evidence, open-item, condition, support, or owner change triggers impact, update, and re-acknowledgement.
~~~
