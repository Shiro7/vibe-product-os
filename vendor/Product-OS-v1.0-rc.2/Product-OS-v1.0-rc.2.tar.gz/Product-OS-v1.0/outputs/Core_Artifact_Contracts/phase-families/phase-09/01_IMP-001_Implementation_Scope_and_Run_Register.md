# Core Artifact Contract — IMP-001 Implementation Scope and Run Register

~~~yaml
contract_id: CONTRACT-IMP-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-001
artifact_name: Implementation Scope and Run Register
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A - Implementation Baseline / IBL - Implementation Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: ENG-031, ERBL / G5B, approved release / slice scope, canonical source identities, GOV-009, and governance registers
primary_downstream: IMP-002 through IMP-032, IBL / G6A, Phase 10, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

IMP-001 defines every authorized Implementation Run and binds it to the exact ERBL / release / slice / work scope, repositories / modules, target environments, owners, dependencies, conditions, dates where governed, status, and evidence index. It prevents implementation from expanding through backlog proximity, memory, convenience, or an unverified repository assumption.

---

# 2. Scope and Applicability

IMP-001 is CORE whenever Phase 09 is active. Separate runs may govern independently releasable slices, repositories, platforms, migrations, environments, teams, regions, risk classes, hotfixes, or emergency changes.

Partial runs are valid only when included, excluded, deferred, shared, and conditional work; cross-run dependencies; compatibility; controls; migration / deployment boundaries; verification; evidence; and operational effects are explicit. NOT_APPLICABLE requires an equivalent authorized run-control mechanism.

---

# 3. Accountabilities

- **Owner:** implementation lead accountable for run truth and scope control.
- **Repository / module / platform / data owners:** confirm canonical targets, revisions, access, dependencies, and execution status.
- **Product / design / architecture / standards authorities:** own upstream intent and material divergence decisions.
- **Verification receiver:** confirms the run can produce a bounded candidate; it does not approve G6A.
- **AI:** may assemble and compare identities but cannot infer ownership, broaden scope, accept risk, or claim work executed without evidence.

---

# 4. Required Inputs and Decisions

Required inputs are accepted ENG-031 and G5B conditions; exact upstream baseline revisions; approved release / slices / work; canonical tracker / repository / branch / module / schema / infrastructure / environment identities; owners and access; dependencies; controls; verification / evidence allocations; risks, exceptions, deviations, blockers, and debt.

Required decisions include run ID; included / excluded scope; current and target identities; implementation profile / overrides; owners / reviewers / authorities; dependencies and sequence; environments; conditions and restrictions; start / target events; change authority; evidence boundary; completion, suspension, cancellation, and reopen rules.

---

# 5. Minimum Run Record

~~~yaml
implementation_run_id:
erbl_and_g5b_refs: []
release_milestone_and_slice_refs: []
included_work_items: []
excluded_deferred_shared_or_conditional_work: []
repositories_branches_modules_schemas_and_infrastructure_refs: []
current_source_revisions: []
target_environments_and_deployment_paths: []
platforms_regions_tenants_locales_and_outputs: []
owners_reviewers_and_authorities: []
dependencies_sequence_and_conditions: []
controls_migrations_rollout_rollback_and_operational_scope: []
verification_and_evidence_allocations: []
known_blockers_defects_deviations_exceptions_and_debt: []
dates_or_target_events: []
status:
evidence_index:
completion_and_reopen_rules: []
~~~

---

# 6. Authority, Traceability, and Change

Phase 09 may implement and sequence only within accepted Engineering boundaries. Product scope, requirement semantics, experience / design behavior, architecture, standards applicability, risk acceptance, verification results, and release authorization remain outside run authority.

Required path:

~~~text
ENG-031 / ERBL / G5B
  -> IMP-001 Run / Scope / Identities / Conditions
  -> Work / Change / Check / Migration / Deployment / Evidence
  -> IMP-029 Candidate
  -> IMP-030 Validation / IMP-031 Handoff
  -> IBL / G6A / Phase 10
~~~

Material scope, source, target, environment, owner, dependency, control, condition, migration, rollout, evidence, or candidate change triggers impact analysis and status review.

---

# 7. Profile, Evidence, Exit, and Reopen

- **Level 1:** one compact run is allowed for narrow low-risk scope, with exact identities and evidence retained.
- **Level 2:** modular runs, multi-dimensional status, explicit mappings, and formal candidate handoff are required.
- **Level 3:** controlled scopes, separation, signed snapshots, multi-environment evidence, migration custody, and independent challenge are added.

IMP-001 exits only when scope, sources, targets, owners, dependencies, conditions, controls, evidence obligations, status, and run-to-candidate route are accepted. Reopen on any material change to those facts or to G5B / ENG-031.

---

# 8. Validation Rules

~~~text
IMP1-CVAL-001  Every run binds exact ENG-031, ERBL / G5B, release, slice / work scope, source revisions, targets, profile, conditions, and evidence boundary.
IMP1-CVAL-002  Included, excluded, deferred, shared, conditional, cancelled, current, target, implemented, verified, and released states remain distinct.
IMP1-CVAL-003  Canonical repository, branch, module, schema, infrastructure, environment, project, domain, owner, and authority identities are verified.
IMP1-CVAL-004  Partial runs record cross-run dependencies, compatibility, controls, migration / deployment, verification, evidence, operations, and prohibited assumptions.
IMP1-CVAL-005  Run authority cannot silently override upstream product, requirement, design, architecture, standards, risk, verification, or release decisions.
IMP1-CVAL-006  Unrelated user-owned changes are preserved and excluded unless explicitly accepted into the run with impact and authority.
IMP1-CVAL-007  A sprint, backlog filter, team, branch, repository list, target date, or deployment cannot alone define or approve implementation scope.
IMP1-CVAL-008  Material scope, source, target, owner, dependency, environment, condition, control, evidence, or candidate change propagates review and revalidation.
~~~

