# Core Artifact Contract — IMP-005 UI and Design-System Implementation Record

~~~yaml
contract_id: CONTRACT-IMP-005
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-005
artifact_name: UI and Design-System Implementation Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Checks 07, 08, 17, and 28 / IBL
default_activation: CONDITIONAL_WHEN_UI_OR_GENERATED_OUTPUT_EXISTS
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: ENG-009, ENG-010, ENG-015, ENG-021, DES-001 through DES-023, EXP baseline, REQ baseline, GOV-009, and ENG-031
primary_downstream: IMP-006, IMP-013, IMP-022, IMP-027 through IMP-032, Phase 10 design / accessibility verification, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

IMP-005 is the canonical implementation record for design tokens, themes, modes, components, screens, states, routes, content, assets, motion, responsive behavior, platform behavior, RTL / localization behavior, accessibility semantics, and generated outputs. It binds approved design sources and revisions to exact code targets and evidence.

Activate for any user-visible, operator-visible, document, email, notification, report, or design-system change. NOT_APPLICABLE requires proof that the G6A scope contains no such surface or shared primitive.

---

# 2. Accountabilities and Inputs

- **Engineering owner:** owns source implementation and truthful status.
- **Design / experience owner:** confirms source identity and owns design divergence decisions.
- **Accessibility / localization owners:** confirm applicable obligations and implementation review.
- **Product / content owner:** owns approved behavior and content meaning.
- **Verification:** receives exact parity and test scope without Phase 09 self-approval.

Inputs include exact design file / library / node / component / token / content / asset revisions; DES-023 handoff; screen / state / route maps; supported platforms / viewports / modes / locales / directions / assistive contexts; requirements / acceptance; standards; code targets; test strategy; known divergences.

---

# 3. Required Decisions and Minimum Record

Decide canonical source-to-code mapping, implementation boundary, supported states / modes / platforms / locales, component adoption, token strategy, accessibility semantics, content / asset / motion handling, generated-output behavior, tests, evidence, divergence route, and completion status.

Minimum record:

~~~yaml
ui_implementation_record_id:
implementation_run_and_work_refs: []
design_file_library_node_and_revision_refs: []
code_repository_revision_components_screens_and_routes: []
tokens_themes_modes_and_fallbacks: []
components_properties_variants_and_states: []
screen_states_errors_recovery_and_unknown_outcomes: []
responsive_platform_rtl_locale_timezone_money_and_content: []
semantics_focus_keyboard_forms_zoom_reflow_and_reduced_motion: []
assets_fonts_shaping_motion_and_generated_outputs: []
actual_product_consumers: []
checks_parity_methods_and_evidence: []
approved_divergences_and_limits: []
owners_and_status:
~~~

---

# 4. Truth, Boundary, and Traceability

Design and code remain separate canonical sources connected by exact mappings. Implementation may resolve code-level detail but cannot silently redesign behavior, semantics, visual hierarchy, content, interaction, accessibility, or platform intent.

Required path:

~~~text
Requirement / Experience / Design / GOV-009
  -> DES-023 / ENG-009 / ENG-010 / ENG-021
  -> IMP-005 Code Target / State / Consumer
  -> IMP-006 Parity / IMP-013 Cross-cutting Record
  -> Check / Evidence / Candidate
  -> Phase 10 Verification
~~~

---

# 5. Profiles, Evidence, Exit, and Reopen

Level 1 may consolidate narrow-surface records; Level 2 requires component / screen / state mappings and reproducible parity evidence; Level 3 adds independent multi-platform, assistive-technology, localization, generated-output, and design-system adoption assurance.

Exit requires every applicable design obligation mapped to exact code and consumers, critical states implemented, checks / evidence present, divergences governed, and remaining independent verification allocated. Reopen on design, token, component, content, asset, code, platform, browser, locale, direction, assistive, consumer, or divergence change.

---

# 6. Validation Rules

~~~text
IMP5-CVAL-001  Every UI object binds approved design file / library / node / revision to exact code target, source revision, owner, consumer, and status.
IMP5-CVAL-002  Tokens, themes, modes, components, variants, states, content, assets, responsive / platform, RTL, accessibility, motion, and outputs are covered as applicable.
IMP5-CVAL-003  Loading, success, empty, error, denied, conflict, offline, processing, unknown-outcome, expiry, interruption, and recovery states are explicitly dispositioned.
IMP5-CVAL-004  Semantic structure, focus, keyboard, forms, errors, zoom / reflow, reduced motion, localization, fonts / shaping, and generated-output structure reach production code.
IMP5-CVAL-005  Component implementation, publication, documentation, and actual product adoption remain separate and evidenced.
IMP5-CVAL-006  Screenshot similarity, design export, token name, component story, or green UI test cannot alone prove interaction, semantic, accessibility, localization, or adoption parity.
IMP5-CVAL-007  Material design divergence requires owning authority, impact, disposition, implementation / source update, recheck, and candidate treatment.
IMP5-CVAL-008  Design, code, consumer, content, asset, platform, mode, state, locale, direction, accessibility, or divergence change reopens affected evidence.
~~~

