# Core Artifact Contract — IMP-008 Data, Schema, Lifecycle, and Migration Record

~~~yaml
contract_id: CONTRACT-IMP-008
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-008
artifact_name: Data, Schema, Lifecycle, and Migration Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Checks 11, 12, 15, 22, and 28 / IBL
default_activation: CONDITIONAL_WHEN_DATA_SCHEMA_OR_MIGRATION_IS_AFFECTED
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: REQ data requirements, ARC-008 through ARC-011 and ARC-028, ENG-013, ENG-031, GOV-009, and approved data / migration decisions
primary_downstream: IMP-004, IMP-007, IMP-010 through IMP-012, IMP-014 through IMP-020, IMP-022 through IMP-032, Phase 10 data / migration verification, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

IMP-008 is the canonical implementation and execution record for data models, schemas, constraints, indexes, ownership, classification, access, lineage, lifecycle, retention, deletion, residency, seed / reference data, search indexes, analytics, migrations, backfills, validation, reconciliation, and recovery.

Activate whenever application, analytical, audit, configuration, identity, cache, search, vendor, backup, or generated-output data behavior changes. NOT_APPLICABLE requires evidence of no affected data object, store, schema, migration, lifecycle, or copy.

---

# 2. Owners, Inputs, and Decisions

Data / schema owner, application owner, security / privacy owner, platform / database owner, migration executor, reviewer, and verification receiver are named. Inputs include approved models / requirements, classifications, schemas, contracts, lifecycle policy, current-state evidence, target stores, migrations / backfills, environment identity, data volume / quality, compatibility, backup / recovery, and verification allocation.

Decisions cover source / target revisions; constraints / indexes; lifecycle; execution plan; checkpoints; maintenance or online behavior; validation / reconciliation; rollback / forward-fix; custody; access; evidence; residual risk; and candidate inclusion.

---

# 3. Minimum Record

~~~yaml
data_implementation_record_id:
run_work_requirement_architecture_and_control_refs: []
data_objects_stores_owners_and_classifications: []
source_target_schema_and_code_revisions: []
constraints_indexes_access_and_compatibility: []
retention_deletion_residency_lineage_and_copy_scope: []
migration_backfill_seed_search_and_analytics_changes: []
environment_database_tenant_region_and_dataset_identity: []
prechecks_backup_checkpoints_and_approvals: []
execution_steps_results_timestamps_and_actors: []
validation_reconciliation_counts_and_invariants: []
rollback_forward_fix_restore_and_irreversibility: []
privacy_security_audit_and_operational_effects: []
evidence_known_limits_and_remaining_verification: []
status_and_owners:
~~~

---

# 4. Execution Truth and Change Impact

Migration source, planned execution, actual execution, schema state, data state, validation, reconciliation, and recovery readiness are separate claims. A migration file or deployment record does not prove the intended database or dataset changed safely.

Traceability runs from data requirement / architecture / ENG-013 through exact schema / migration / environment / execution evidence to candidate and Phase 10 validation. Material schema, data, environment, volume, compatibility, lifecycle, privacy, or execution change invalidates affected evidence.

---

# 5. Profiles, Exit, and Reopen

Level 1 allows compact low-risk migration records but retains exact target, precheck, recovery, execution, validation, and evidence. Level 2 requires independently reviewable schema / migration / lifecycle records. Level 3 adds rehearsal, separation of duties, custody, signed evidence, multi-region / tenant sampling, formal reconciliation, restore proof, and independent review.

Exit requires exact source and target truth, safe execution or explicit non-execution, validated invariants, reconciled effects, protected evidence, governed open items, and candidate binding. Reopen on model, schema, data, store, environment, tenant, region, volume, lifecycle, classification, migration, validation, recovery, candidate, or evidence change.

---

# 6. Validation Rules

~~~text
IMP8-CVAL-001  Every data change binds exact objects, owners, classification, source / target schemas, code / migration revisions, stores, environment, and status.
IMP8-CVAL-002  Migration plan, source existence, approval, execution, validation, reconciliation, rollback / forward-fix, and verification remain separate evidence states.
IMP8-CVAL-003  Constraints, indexes, compatibility, access, retention, deletion, residency, lineage, backups, replicas, vendor copies, and analytical copies are dispositioned as applicable.
IMP8-CVAL-004  Execution records include prechecks, backup / recovery readiness, target identity, actor, timestamps, checkpoints, result, validation, reconciliation, and evidence.
IMP8-CVAL-005  Backfills, seed / reference data, search / index rebuilds, analytics changes, and generated data follow bounded, repeatable, observable, and recoverable procedures.
IMP8-CVAL-006  Migration file presence, local success, deployment success, row-count equality, or green build cannot alone prove production execution, integrity, compatibility, or recovery.
IMP8-CVAL-007  Actual secret values or uncontrolled sensitive records never enter evidence; samples, exports, logs, and screenshots follow minimization and access controls.
IMP8-CVAL-008  Schema, data, target, environment, volume, classification, lifecycle, compatibility, execution, validation, recovery, or candidate change triggers impact and revalidation.
~~~
