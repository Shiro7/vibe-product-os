# Core Artifact Contract — IMP-011 Security and Privacy Control Implementation Record

~~~yaml
contract_id: CONTRACT-IMP-011
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-011
artifact_name: Security and Privacy Control Implementation Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Checks 15, 21, 27, and 28 / IBL
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: REQ security / privacy requirements, ARC-018, ARC-019, ENG-020, ENG-028, ENG-031, threat / privacy models, GOV-009, and risk / exception decisions
primary_downstream: IMP-012, IMP-016 through IMP-019, IMP-022 through IMP-032, Phase 10 security / privacy verification, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

IMP-011 is the canonical implementation record for security and privacy controls. It binds each risk / obligation / GOV-009 control to exact code, configuration, infrastructure, migration, enforcement, safe defaults, failure behavior, telemetry, privacy / data effect, owner, developer checks, evidence, remaining verification, and exception.

IMP-011 is CORE because every production implementation has trust and privacy boundaries, even when individual control families are NOT_APPLICABLE.

---

# 2. Inputs, Accountabilities, and Decisions

Inputs include requirements, threat / abuse model, privacy purposes and data map, architecture controls, GOV-009 obligations, identity / authorization / data changes, secrets / keys, infrastructure, dependencies, logging / audit, verification allocation, exceptions, and residual risks.

Security / privacy owner, implementation owner, data / identity / platform owners, control reviewer, evidence owner, exception / risk authority, and Phase 10 receiver are named. Decisions cover mechanism, target, enforcement, safe failure, telemetry, data effect, check, evidence, exception, residual risk, and remaining verification.

---

# 3. Minimum Record

~~~yaml
control_implementation_record_id:
run_work_requirement_risk_and_gov009_refs: []
control_objective_and_scope:
repository_revision_configuration_infrastructure_and_migration_targets: []
enforcement_points_and_dependencies: []
safe_defaults_failure_and_degradation_behavior: []
data_purpose_minimization_consent_rights_and_disclosure_effects: []
secret_key_encryption_input_output_edge_and_abuse_controls: []
telemetry_audit_alerts_and_operational_owner: []
developer_checks_results_and_evidence: []
remaining_phase10_verification: []
exceptions_conditions_residual_risk_and_expiry: []
implementation_status:
owners_and_reviewers: []
~~~

---

# 4. Control Truth and Traceability

Planned, coded, configured, deployed, developer-checked, independently verified, compliant, release-authorized, and operationally effective are different claims. IMP-011 may claim only the status its exact evidence supports.

Traceability: risk / requirement / architecture / GOV-009 → control objective → mechanism and exact target → telemetry / checks / evidence → IMP-026 derived view → candidate → Phase 10 verification / exception / release / operations.

---

# 5. Profiles, Exit, and Reopen

Level 1 retains all critical control and safe-failure evidence; Level 2 separates control records by owner / target; Level 3 adds independent review, separation, formal evidence custody, attack / privacy scenario rehearsal, multi-environment proof, and exception monitoring.

Exit requires every active control implemented or governed, exact target and status, safe failure, telemetry, evidence, remaining verification, and valid exception / residual-risk treatment. Reopen on risk, obligation, data, threat, mechanism, target, configuration, secret / key, dependency, environment, evidence, exception, or candidate change.

---

# 6. Validation Rules

~~~text
IMP11-CVAL-001  Every active control binds exact risk / requirement / GOV-009 source, objective, scope, mechanism, enforcement target, owner, status, and evidence.
IMP11-CVAL-002  Planned, implemented, configured, deployed, developer-checked, independently verified, compliant, released, and operational statuses remain distinct.
IMP11-CVAL-003  Safe defaults, fail-closed behavior, privacy / data effect, telemetry, audit, alerts, owner, verification, and exception treatment are explicit.
IMP11-CVAL-004  Inputs, outputs, edge / abuse, encryption, secrets / keys, minimization, consent, rights, disclosure, retention, and vendor propagation are covered as applicable.
IMP11-CVAL-005  Evidence binds exact source / artifact / environment / configuration revision and states what remains for Phase 10.
IMP11-CVAL-006  Control documentation, code presence, configuration key, scan pass, checklist, or matrix completion cannot alone prove enforcement, effectiveness, verification, or compliance.
IMP11-CVAL-007  Exceptions require authority, rationale, alternative, temporary controls, residual risk, restrictions, expiry, evidence, and return-to-standard route.
IMP11-CVAL-008  Risk, obligation, data, threat, mechanism, target, environment, evidence, exception, or candidate change triggers impact and revalidation.
~~~

