# Core Artifact Contract — IMP-017 Configuration, Secret, Key, and Feature-Flag Record

~~~yaml
contract_id: CONTRACT-IMP-017
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-017
artifact_name: Configuration, Secret, Key, and Feature-Flag Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Checks 15, 21, 24, and 28 / IBL
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: configuration / secret / key / rollout requirements, ARC-024, ENG-014, ENG-031, deployment / environment architecture, threat model, and GOV-009
primary_downstream: IMP-004, IMP-007 through IMP-020, IMP-022 through IMP-032, Phase 10 configuration / rollout verification, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

IMP-017 is the canonical control record for runtime configuration, secret identities, cryptographic key classes, certificates, feature flags, experiments, cohorts, environment scopes, injection / access, rotation / revocation, safe defaults, failure behavior, rollout / removal, audit, drift, and evidence.

IMP-017 is CORE. It records identities and lifecycle metadata only; actual secret, private-key, token, password, or sensitive configuration values are prohibited.

---

# 2. Inputs, Owners, and Decisions

Inputs include approved configuration schemas, environment topology, secret / key architecture, identity and access controls, flag / rollout strategy, migration / deployment dependencies, safe-default and fail-closed requirements, rotation / leak response, audit / telemetry, evidence and verification allocation.

Application, platform / environment, security / key-custody, release / rollout, operations, reviewer, and Phase 10 owners are named. Decisions cover identity / class, source / scope, injection, access, lifecycle, default / failure, flag semantics, rollout / removal, drift, checks, evidence, and exceptions.

---

# 3. Minimum Record

~~~yaml
runtime_control_record_id:
run_work_requirement_architecture_and_control_refs: []
configuration_secret_key_certificate_or_flag_identities: []
class_schema_type_requiredness_and_validation: []
source_environment_region_tenant_service_and_owner_scope: []
injection_resolution_access_and_separation_of_duties: []
generation_rotation_revocation_expiry_and_leak_response: []
safe_default_missing_invalid_and_dependency_failure_behavior: []
flag_evaluation_targeting_cohort_telemetry_and_security_boundary: []
rollout_kill_switch_removal_cleanup_and_retirement: []
drift_detection_audit_checks_and_evidence: []
known_limits_exceptions_and_remaining_verification: []
status_and_owners:
~~~

---

# 4. Runtime Truth and Traceability

Required, configured in a control plane, provisioned to a target, injected into a workload, resolved at startup, runtime-effective, rotated, revoked, and independently verified are distinct states. Configuration identity is evidenced without exposing its value.

Traceability: architecture / ENG-014 / GOV-009 → configuration / secret / key / flag identity → exact code / platform / environment target → deployment / runtime evidence → candidate → Phase 10 verification → rotation / removal operations.

---

# 5. Profiles, Exit, and Reopen

Level 1 retains exact critical identities, sources, safe failure, access, lifecycle, and evidence; Level 2 separates records by environment / service / owner; Level 3 adds custody, segregation, HSM / KMS or equivalent evidence, formal rotation, controlled rollout, drift monitoring, and independent review.

Exit requires all candidate-effective runtime controls identified, validated, safely resolved, access-controlled, evidence-bound, with flags / keys governed and remaining verification explicit. Reopen on schema, identity, source, environment, access, value version, rotation, revocation, flag state / cohort, code resolution, dependency, drift, or candidate change.

---

# 6. Validation Rules

~~~text
IMP17-CVAL-001  Every configuration, secret, key, certificate, and flag binds governed identity, class / schema, source, environment scope, consumer, owner, lifecycle, status, and evidence.
IMP17-CVAL-002  Required, configured, provisioned, injected, resolved, runtime-effective, rotated, revoked, and verified states remain distinct.
IMP17-CVAL-003  Missing, invalid, expired, inaccessible, stale, conflicting, or dependency-failed configuration follows explicit safe-default or fail-closed behavior.
IMP17-CVAL-004  Secret / key access, generation, injection, rotation, revocation, expiry, audit, recovery, and leak response preserve least privilege and separation as required.
IMP17-CVAL-005  Feature flags define evaluation point, default, targeting / cohort, telemetry, security boundary, rollout stages, kill switch, owner, expiry, and removal.
IMP17-CVAL-006  Variable name, control-plane presence, successful build, deployment, or masked screenshot cannot alone prove runtime-effective configuration or safe behavior.
IMP17-CVAL-007  Actual secret, credential, token, password, private key, recovery code, or sensitive production value never enters the record, logs, screenshots, or evidence.
IMP17-CVAL-008  Schema, identity, source, environment, access, value version, lifecycle, flag state, code resolver, dependency, drift, or candidate change triggers revalidation.
~~~

