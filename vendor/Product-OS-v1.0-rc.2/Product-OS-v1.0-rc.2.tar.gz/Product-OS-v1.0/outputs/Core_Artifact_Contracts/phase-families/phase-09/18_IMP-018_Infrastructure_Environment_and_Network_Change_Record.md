# Core Artifact Contract — IMP-018 Infrastructure, Environment, and Network Change Record

~~~yaml
contract_id: CONTRACT-IMP-018
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-018
artifact_name: Infrastructure, Environment, and Network Change Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A Checks 22, 24, and 28 / IBL
default_activation: CONDITIONAL_WHEN_PLATFORM_ENVIRONMENT_OR_NETWORK_CHANGES
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: ARC-023 through ARC-026, ENG-007, ENG-014, ENG-022, ENG-024, ENG-031, approved infrastructure decisions, and GOV-009
primary_downstream: IMP-004, IMP-008, IMP-014 through IMP-020, IMP-022 through IMP-032, Phase 10 platform / resilience verification, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

IMP-018 is the canonical source and execution record for infrastructure, environment, network, region, runtime, storage, compute, identity, access, DNS / domain, certificate, dependency, and platform changes. It binds architecture, source revision, exact target, reviewed plan, approvals, apply result, post-change checks, rollback / forward-fix, drift, cost / data / security effect, evidence, and status.

Activate for infrastructure-as-code and controlled manual / vendor changes. NOT_APPLICABLE requires proof that no candidate-effective platform, environment, network, provisioning, domain, or managed-service state changes.

---

# 2. Inputs, Owners, and Decisions

Inputs include architecture source, current inventory / drift evidence, infrastructure definitions, exact account / project / subscription / region / environment targets, network / access rules, data / secret / cost impacts, dependencies, change window, plan, approvals, apply method, post-checks, rollback / recovery, monitoring, and verification allocation.

Platform / infrastructure owner, environment / service owner, network / security / data owners, cost owner, approver, executor, reviewer, operations receiver, and Phase 10 owner are named. Decisions cover target, source, plan, access, sequence, apply / abort, rollback / forward-fix, evidence, residual risk, and candidate inclusion.

---

# 3. Minimum Record

~~~yaml
infrastructure_change_record_id:
run_work_architecture_gov009_and_change_refs: []
infrastructure_source_repository_revision_and_module: []
provider_account_project_subscription_region_environment_and_domain_identity: []
current_state_inventory_plan_and_drift_refs: []
resources_network_routes_firewalls_dns_certificates_and_access: []
compute_storage_database_runtime_and_managed_service_changes: []
data_secret_key_security_privacy_availability_and_cost_impacts: []
dependencies_sequence_window_approvals_and_separation: []
plan_result_apply_result_actor_and_timestamps: []
post_change_startup_health_smoke_security_and_connectivity_checks: []
rollback_forward_fix_restore_and_irreversible_limits: []
evidence_residual_risk_and_remaining_verification: []
status_and_owners:
~~~

---

# 4. Plan, Apply, and Runtime Truth

Infrastructure source, desired state, generated plan, approval, applied state, provider state, application compatibility, network reachability, runtime health, and drift status are distinct claims. Click-ops may be emergency evidence but must be reconciled to canonical source or explicitly governed.

Traceability: architecture / ENG / GOV-009 → source and exact target → plan / approval / apply / post-check evidence → deployment / candidate → Phase 10 platform verification → operational inventory and drift control.

---

# 5. Profiles, Exit, and Reopen

Level 1 retains exact target, plan, apply, health, rollback, and evidence; Level 2 requires independently reviewable environment / resource changes; Level 3 adds separation, signed plans, controlled windows, multi-region / DR rehearsal, policy-as-code, drift proof, cost assurance, and independent review.

Exit requires source and target identity verified, material plan reviewed, apply outcome and post-checks known, rollback / recovery governed, drift reconciled, evidence protected, and remaining verification explicit. Reopen on architecture, source, target, provider, plan, access, resource, network, data / secret, dependency, apply, health, drift, cost, or candidate change.

---

# 6. Validation Rules

~~~text
IMP18-CVAL-001  Every platform change binds architecture source, canonical infrastructure revision, exact provider / account / project / region / environment / domain target, owner, and status.
IMP18-CVAL-002  Desired source, plan, approval, apply, provider state, application compatibility, runtime health, drift, rollback, and verification remain distinct.
IMP18-CVAL-003  Resources, network exposure, access, identity, data, secrets / keys, availability, dependencies, cost, and operational effects are reviewed as applicable.
IMP18-CVAL-004  Material changes have reviewed plan, exact target, authorized executor, window / sequence, apply result, post-checks, evidence, and rollback / forward-fix treatment.
IMP18-CVAL-005  Startup, readiness, connectivity, security, smoke, observability, data / migration compatibility, and failure checks bind the actual applied target.
IMP18-CVAL-006  Infrastructure source, plan success, provider completion, deployment success, or console screenshot cannot alone prove correct target, runtime health, compatibility, or drift-free state.
IMP18-CVAL-007  Emergency or manual changes record authority, exact action, evidence, risk, monitoring, expiry, and reconciliation to canonical source.
IMP18-CVAL-008  Architecture, source, target, provider, access, resource, network, data / secret, dependency, apply, health, drift, cost, or candidate change triggers revalidation.
~~~

