# Core Artifact Contract — IMP-030 Implementation Validation Record

~~~yaml
contract_id: CONTRACT-IMP-030
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: IMP-030
artifact_name: Implementation Validation Record
owning_phase: Phase 09 - Implementation
gate_or_baseline: G6A - Implementation Baseline / IBL - Implementation Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: IMP-001 through IMP-029, candidate IMP-031 and IMP-032 views, ENG-031 / ERBL / G5B, approved upstream baselines, GOV-009, governance registers, canonical source / runtime identities, and implementation evidence
primary_downstream: G6A decision, IBL status, IMP-031, Phase 10, G6B, release, and operations
semantic_source: ../../../Phase_09_Implementation.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

IMP-030 is the independent evidence and control record showing how the exact Implementation Baseline candidate, scope, source / artifact / schema / configuration / infrastructure / environment identities, work disposition, reviews, builds, checks, UI / application / data / trust / operability / platform implementation, defects, deviations, debt, GOV-009 status, coverage, evidence, and Phase 10 handoff were reviewed, challenged, supported, contradicted, corrected, conditioned, or left unresolved.

It may recommend a G6A outcome but cannot issue the human gate decision or claim independent Phase 10 verification.

---

# 2. Scope and Applicability

IMP-030 is CORE for every G6A candidate. Validation binds one exact IMP-029 candidate and one coherent implementation snapshot. Partial scope requires precise exclusions, shared dependencies, candidate boundaries, prohibited verification / release actions, and change-invalidation behavior.

No artifact, domain, check, platform, migration, environment, control, or evidence family may disappear through silence. NOT_APPLICABLE requires reason, owner, evidence, date / revision, downstream impact, and reopen condition.

---

# 3. Accountabilities

- **Validation owner:** coordinates review and preserves independence from authorship appropriate to profile and risk.
- **Engineering / repository owners:** provide exact source, artifact, review, build, and check evidence.
- **Design / architecture / security / privacy / data / platform owners:** review their affected contract domains.
- **QA / Verification lead:** acknowledges candidate and handoff readiness without issuing G6B.
- **G6A authority:** designated humans decide PASS, PASS_WITH_CONDITIONS, HOLD, or REJECT.
- **AI:** may compare coverage and evidence; it cannot infer execution, waive failures, accept risk, or approve G6A.

---

# 4. Required Inputs and Review Record

Required inputs include IMP-001 through IMP-029; exact source / artifact / schema / migration / configuration / infrastructure / environment / deployment / flag snapshots; ENG-031 and G5B conditions; DoD / acceptance / verification allocations; canonical checks and evidence; defects / blockers / deviations / debt; GOV-009; coverage; proposed IMP-031; and accountable acknowledgements.

Minimum record:

~~~yaml
implementation_validation_id:
ibl_candidate_and_imp029_refs: []
eng031_erbl_g5b_and_upstream_baseline_refs: []
scope_inclusions_exclusions_and_profile: []
source_artifact_schema_migration_configuration_infrastructure_environment_deployment_and_flag_snapshot: []
artifact_dispositions_imp001_through_imp032: []
validation_methods_participants_contexts_and_dates: []
g6a_check_results: []
findings_severity_affected_ids_owner_resolution_and_recheck: []
defects_blockers_deviations_exceptions_debt_and_conditions: []
coverage_metrics_definitions_and_gaps: []
evidence_index_integrity_access_and_limitations: []
phase10_handoff_and_acknowledgements: []
residual_risks_and_authority_refs: []
recommended_g6a_outcome:
g6a_decision_ref:
reopen_triggers: []
~~~

---

# 5. G6A Check Contract — All 30 Domains

1. **Scope and baseline integrity:** exact ENG-031 / ERBL / G5B, release, slices, work, inclusions / exclusions, profile / overrides, conditions, and authority are valid.
2. **Repository, branch, and revision identity:** canonical repository / module / branch / base / head, ownership, dirty-worktree treatment, and source snapshot are confirmed.
3. **Work-item implementation status:** every scoped item has truthful multi-dimensional disposition, owner, evidence, and open-item treatment.
4. **Change-set and review integrity:** coherent changes bind exact revisions, risk, reviewers, findings, resolutions, approvals, and merge evidence.
5. **Build and artifact integrity:** toolchain / lock / configuration, artifact identity / digest / provenance, warnings, result, and storage are attributable.
6. **Developer and integration checks:** required format, lint, type, static, unit, component, contract, integration, migration, build, startup, smoke, and other checks have valid results.
7. **UI and design-system implementation:** applicable tokens, components, screens, states, content, assets, responsive / platform / RTL, accessibility, motion, and outputs exist in production targets.
8. **Design parity and adoption:** approved design revisions map exact code and real consumers; contexts, findings, divergences, and evidence are complete.
9. **Domain and application behavior:** rules, transitions, validation, concurrency, errors, partial / unknown outcomes, reconciliation, and recovery are implemented.
10. **API, event, job, and integration contracts:** schemas, versions, producer / consumer, security, errors, retry / idempotency / ordering, compatibility, observability, and checks are valid.
11. **Data and schema integrity:** ownership, classification, constraints, indexes, lifecycle, access, residency, copies, and schema compatibility are correct.
12. **Migration and backfill execution:** exact target, prechecks, backup / recovery, execution, validation, reconciliation, status, and evidence are known.
13. **Identity, authentication, session, and recovery:** trust authorities, factors, credentials, sessions, revocation, recovery, failure / abuse controls, audit, and evidence are implemented.
14. **Authorization, tenancy, and administrative access:** policy, enforcement, default deny, tenant propagation / isolation, delegation, privileged access, audit, and negative checks are implemented.
15. **Security and privacy controls:** active controls have exact mechanisms / targets, safe failures, telemetry, data effects, evidence, remaining verification, and valid exceptions.
16. **Audit and evidence mechanisms:** events preserve context / outcome / integrity / retention / access / monitoring, with implementation samples and checks.
17. **Accessibility and localization:** semantics, keyboard, focus, forms, errors, reflow, reduced motion, locale, RTL, time / money, fonts, content, and outputs are implemented.
18. **Reliability and failure handling:** timeouts, retries, idempotency, isolation, degradation, unknown outcomes, reconciliation, backup, restore, and recovery are implemented.
19. **Performance, capacity, and resource controls:** budgets, queries, caches, payloads, queues, backpressure, quotas, scaling, instrumentation, cost, and sanity evidence are sufficient.
20. **Observability, logging, health, and alerts:** safe signals, correlation, health, dashboards, alerts, runbooks, redaction, retention, access, and owners are ready.
21. **Configuration, secrets, keys, and flags:** sources, schemas, scopes, access, lifecycle, defaults, failure, rollout / removal, drift, and evidence are valid without secret exposure.
22. **Infrastructure, environment, and network changes:** exact targets, plans, approvals, apply results, access / exposure / cost, post-checks, drift, and rollback are valid.
23. **CI/CD and supply chain:** protections, checks / scans, build identity, dependencies / generators, artifacts / provenance, registries, promotion, deployment controls, and retention are valid.
24. **Deployment, rollout, and runtime health:** exact project / environment / domain / artifact / configuration / migration / flag identity, startup, smoke, health, and rollback path are known.
25. **Dependencies, licenses, and generated code:** source, version / lock, purpose, license, security, provenance, review, tests, update, and removal are governed.
26. **Defects, blockers, deviations, and debt:** no hidden critical item exists; remaining items have authority, restrictions, reconciliation, Phase 10 / release treatment, and evidence.
27. **GOV-009 implementation status:** every active obligation has mechanism, evidence, remaining verification, exception, and operational owner without compliance overclaim.
28. **Coverage and traceability:** requirements, states, designs, architecture, controls, work, changes, runtime targets, checks, evidence, and candidate form complete bidirectional paths.
29. **Verification candidate integrity:** IMP-029 identifies one compatible immutable source / artifact / schema / migration / config / environment / deployment / flag / data / issue / evidence snapshot.
30. **Phase 10 handoff:** owners acknowledge candidate, scope, contexts, data / identities / tools, allocations, evidence, restrictions, change rules, support, and open items.

Each check records scope, objects, sources, contexts, method, expected / actual result, evidence, limitations, findings, risk, conditions, owner, reviewer, and status.

---

# 6. Outcome and Authority Contract

- **PASS:** all critical implementation obligations and candidate / handoff controls are complete; blocking gaps and unacceptable risk equal zero.
- **PASS_WITH_CONDITIONS:** only explicit non-blocking limitations remain, with owner, due event, closure evidence, restrictions, monitoring, candidate invalidation, and Phase 10 acknowledgement.
- **HOLD:** named implementation, source, environment, migration, evidence, decision, or handoff facts remain unresolved.
- **REJECT:** the candidate materially conflicts with approved baselines, hides critical failures, or is unsafe / unverifiable.

IMP-030 records a recommendation. The gate record holds accountable human decision, exact scope, rationale, conditions, restrictions, approvals, evidence, and reopen triggers.

---

# 7. Profiles, Exit, and Reopen

Level 1 permits compact review but every applicable G6A check remains; Level 2 requires structured multi-domain review and reproducible evidence; Level 3 adds independent / segregated review, signed provenance, controlled migration / infrastructure evidence, multi-environment assurance, evidence custody, and formal condition monitoring.

IMP-030 exits when all 30 checks have evidence-backed dispositions, findings are resolved or gate-treated, IMP-029 is stable, IMP-031 is acknowledged, evidence limitations are visible, and human authority records G6A. Reopen on any material candidate, source, artifact, data, config, infrastructure, environment, evidence, defect, deviation, condition, or handoff change.

---

# 8. Validation Rules

~~~text
IMP30-CVAL-001  IMP-030 binds one exact IMP-029 candidate, coherent implementation snapshot, ENG-031 / ERBL / G5B scope, upstream revisions, GOV-009, profile, and evidence period.
IMP30-CVAL-002  All thirty G6A checks receive explicit method, context, result, evidence, limitation, finding, owner, reviewer, and status or governed NOT_APPLICABLE treatment.
IMP30-CVAL-003  Build, source, runtime, migration, deployment, developer-check, independent-verification, release, and operational evidence remain distinct.
IMP30-CVAL-004  Findings preserve severity, affected IDs, candidate impact, owner, resolution, exact recheck revision / context, evidence, residual risk, and gate treatment.
IMP30-CVAL-005  PASS_WITH_CONDITIONS names permitted and prohibited Phase 10 / release actions, owner, due event, closure evidence, monitoring, invalidation, and reopen trigger.
IMP30-CVAL-006  Empty artifacts, status claims, coverage percentages, green builds, staging deployments, screenshots, indexes, or AI summaries cannot prove G6A readiness.
IMP30-CVAL-007  IMP-030 may recommend but cannot issue G6A, accept risk, approve exception, claim independent verification, or authorize release.
IMP30-CVAL-008  Material scope, source, artifact, schema, migration, config, infrastructure, environment, evidence, open-item, candidate, or handoff change triggers impact and revalidation.
~~~

