# Core Artifact Contract — OPS-012 Incident, Timeline, Communication, and Evidence Record

~~~yaml
contract_id: CONTRACT-OPS-012
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: OPS-012
artifact_name: Incident, Timeline, Communication, and Evidence Record
owning_phase: Phase 11 - Operations and Evolution
gate_or_baseline: Event-driven operational control / G8 evidence
default_activation: EVENT_DRIVEN
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: OPS-001 through OPS-011, live signals, user or support reports, control findings, and declared incident evidence
primary_downstream: OPS-003, OPS-013 through OPS-038, corrective action, G8, and regulated or contractual reporting
semantic_source: ../../../Phase_11_Operations_and_Evolution.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

OPS-012 is the authoritative event record for an operational incident. It preserves declaration, classification, exact live scope, impact, roles, decisions, timeline, containment, recovery, communication, evidence, control obligations, and closure without rewriting uncertain or evolving facts.

It is distinct from an alert, support case, problem record, corrective-action register, post-incident insight, or G8 decision, although it links them.

---

# 2. Activation and Safety

OPS-012 activates for any event meeting the governed incident definition or requiring coordinated response, communication, evidence preservation, or specialist assessment. Security, privacy, accessibility, safety, audit, data, vendor, continuity, or regulated events activate their specialist procedures without fragmenting the canonical incident identity.

Response safety and harm reduction take precedence over documentary completeness. Missing detail is marked `UNKNOWN` with time and owner; responders never delay containment to beautify the record.

---

# 3. Accountabilities and Inputs

- **Incident Commander:** owns coordination and decision flow within declared authority.
- **Technical / operations leads:** diagnose, contain, recover, and produce evidence.
- **Communication owner:** governs internal, status, customer, partner, regulatory, and contractual messages.
- **Specialist authorities:** security, privacy, data, accessibility, legal, compliance, safety, vendor, and business continuity as triggered.
- **Evidence custodian:** preserves provenance, access, integrity, retention, and disclosure restrictions.
- **AI:** may correlate signals and draft timelines; it cannot declare resolution, assign blame, authorize access, send communication, or claim evidence it did not observe.

Inputs include alerts, telemetry, synthetics, user / support reports, audit or control findings, live identities, runbooks, access records, change events, vendor notifications, and prior related incidents.

---

# 4. Minimum Incident Record

OPS-012 records:

1. incident ID, status, severity, type, declaration time, declarer, commander, and applicable profiles;
2. exact affected OPS-002 identities, users / tenants / regions / data / capabilities, start time or range, and confidence;
3. detected symptoms, known facts, hypotheses, unknowns, user / business / control / legal impact, and risk;
4. timestamped timeline of signals, decisions, actions, actors, commands / changes by safe reference, results, and evidence;
5. roles, handoffs, escalation, on-call participation, break-glass use, vendor involvement, and authority;
6. containment, service reduction, workaround, recovery, validation, rollback, and continuity actions;
7. communication audiences, approvals, content version, channel, time, delivery evidence, and corrections;
8. evidence items with source, collection method, candidate / runtime context, integrity, sensitivity, access, custody, and retention;
9. security / privacy / accessibility / audit / data / contractual notification assessments and decisions;
10. resolution basis, restoration proof, remaining impact, restrictions, monitoring window, and recurrence risk;
11. linked problem, defect, risk, exception, corrective action, debt, insight, G8 trigger, and earlier-phase route;
12. review, closure authority, dissent, limitations, and reopen triggers.

---

# 5. Status and Authority Contract

~~~text
DETECTED → DECLARED → ACTIVE → CONTAINED → RECOVERING → MONITORING → RESOLVED → REVIEWED → CLOSED
~~~

Statuses may move backward when evidence changes. `RESOLVED` requires service / control validation for the affected scope; `CLOSED` additionally requires required review, evidence preservation, communication disposition, and follow-up ownership. Closure does not prove root cause or corrective-action completion.

---

# 6. Profiles, Exit, and Reopen

- **P1:** one event record may combine coordination, timeline, communication, and evidence for a bounded incident.
- **P2:** command, technical, communication, evidence, specialist, and review views may be modular but share one incident identity.
- **P3:** segregated command, independent evidence custody, regulatory timelines, forensic handling, multi-region coordination, exercises, and formal assurance strengthen.

OPS-012 exits when the affected scope is stable or deliberately constrained, evidence supports the recorded state, required notifications are dispositioned, remaining risks and actions have owners, and closure authority is valid. Reopen on recurrence, evidence correction, hidden impact, failed recovery, required notification change, control finding, scope expansion, or invalid closure basis.

---

# 7. Validation Rules

~~~text
OPS12-CVAL-001  Every incident binds exact live identities, time range, severity, commander, impact, status, and evidence cut-off.
OPS12-CVAL-002  Facts, hypotheses, unknowns, interpretations, and corrected information remain distinguishable through the timeline.
OPS12-CVAL-003  Every material decision, action, communication, and handoff records actor, authority, time, result, and evidence.
OPS12-CVAL-004  Containment, recovery, resolution, review, and closure remain separate statuses with separate evidence.
OPS12-CVAL-005  Security, privacy, accessibility, audit, data, safety, vendor, legal, and contractual triggers receive explicit disposition.
OPS12-CVAL-006  Evidence integrity, sensitivity, custody, access, retention, and disclosure limits are preserved.
OPS12-CVAL-007  Closure cannot hide remaining impact, recurrence risk, corrective action, restriction, exception, debt, or G8 trigger.
OPS12-CVAL-008  Incident response may use emergency authority, but lasting change routes through governed change and Product OS re-entry.
~~~
