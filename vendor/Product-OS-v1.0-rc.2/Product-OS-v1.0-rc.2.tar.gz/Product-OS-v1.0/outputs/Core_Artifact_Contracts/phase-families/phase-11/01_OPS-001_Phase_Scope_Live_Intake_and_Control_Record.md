# Core Artifact Contract — OPS-001 Phase Scope, Live Intake, and Control Record

~~~yaml
contract_id: CONTRACT-OPS-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: OPS-001
artifact_name: Phase Scope, Live Intake, and Control Record
owning_phase: Phase 11 - Operations and Evolution
gate_or_baseline: Operational cycle control / G8 preparation
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: VRL-035, VRL-036 through VRL-038, OPS-003, brownfield intake, live evidence, and governance registers
primary_downstream: OPS-002 through OPS-038, operational cycles, G8, and Product OS re-entry
semantic_source: ../../../Phase_11_Operations_and_Evolution.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

OPS-001 establishes the exact control boundary for Phase 11. It records whether the phase entered through an authorized Phase 10 handoff, brownfield adoption, recovery, transfer, or another approved live-intake route; identifies the operated scope and evidence period; activates the required operational and evolution profiles; and assigns authority for recurring operation, event-driven response, lifecycle review, and G8.

It is a control record, not proof of service health, release execution, incident resolution, control effectiveness, or G8 approval.

---

# 2. Scope and Applicability

OPS-001 is CORE whenever Product OS has responsibility for a live product, service, system, deployment, integration, data scope, tenant / cohort, or operational process. Separate records may govern materially independent services, regions, operating models, regulated scopes, transferred responsibilities, or recovery efforts.

NOT_APPLICABLE is valid only when the bounded project has no live operational responsibility. It records reason, authority, evidence, effective date, and reopen trigger.

---

# 3. Accountabilities and Inputs

- **Owner:** Product Operations Owner or delegated Phase 11 control owner.
- **Live authorities:** named service, product, technical, incident, security, privacy, data, support, continuity, finance, vendor, and lifecycle authorities as applicable.
- **G8 authority:** named independently of ordinary record preparation.
- **Route receivers:** owners that acknowledge operational actions or earlier-phase re-entry.
- **AI:** may classify intake, detect gaps, and draft control updates; it cannot claim live state, accept risk, authorize production action, or decide G8.

Required inputs include the exact Phase 10 handoff and release evidence when available; current OPS-003; brownfield or transfer evidence; GOV-001 through GOV-009; known live identities, owners, controls, incidents, risks, obligations, and prior operational decisions.

---

# 4. Required Decisions and Minimum Record

OPS-001 records at minimum:

1. control-record ID, version, status, owner, and effective period;
2. intake route and exact source identities;
3. included and excluded live scopes, services, environments, tenants, regions, data, integrations, and lifecycle states;
4. known identity gaps, confidence, restrictions, and immediate safety actions;
5. selected P1 / P2 / P3 profile by operational domain and every override rationale;
6. activated OPS artifacts, conditional modules, recurring cadences, trigger events, and evidence windows;
7. ownership, on-call, escalation, incident, emergency-change, access, G8, and re-entry authority;
8. entry conditions, initial OBL state, critical blockers, recovery actions, and target dates;
9. truth freeze, evidence cut-off, change control, review cadence, exit, and reopen rules;
10. expected downstream handoffs and receiver acknowledgement.

---

# 5. Control and Authority Boundary

The record separates operational evidence from assertion, emergency action from lasting change, G8 routing from implementation authorization, and recurring registers from event records. Brownfield uncertainty remains `UNKNOWN` or `DECLARED`; it is not rewritten as observed truth.

Required path:

~~~text
Phase 10 Handoff or Brownfield / Recovery Intake
→ OPS-001 Control Boundary
→ OPS-002 Live Identity + OPS-003 Operational Baseline
→ Operational Evidence and Evolution Records
→ OPS-033 Health Review
→ OPS-037 G8 Decision
→ Operational Action or Earliest Affected Product OS Phase
~~~

---

# 6. Profiles, Exit, and Reopen

- **P1:** one bounded control record may govern a small live scope while exact identity, ownership, safety, evidence, and G8 authority remain mandatory.
- **P2:** domain controls, cycles, registers, and reviews are modular and independently owned.
- **P3:** multi-service / region / tenant boundaries, segregation, independent assurance, regulated evidence, continuity, and lifecycle governance strengthen.

OPS-001 exits intake when the live boundary, source identities, owners, authorities, profiles, cadences, activated obligations, critical gaps, OBL route, and handoffs are usable. Reopen on material scope, intake route, ownership, operating model, profile, authority, standard, service, region, tenant, lifecycle, risk, or evidence-period change.

---

# 7. Validation Rules

~~~text
OPS1-CVAL-001  OPS-001 binds an exact live scope, intake route, evidence period, source identities, and accountable owner.
OPS1-CVAL-002  Brownfield, recovery, transfer, and Phase 10 handoff states remain distinguishable.
OPS1-CVAL-003  Unknown live truth is recorded with risk, owner, action, confidence, and review date rather than invented.
OPS1-CVAL-004  Profiles and conditional artifacts follow applicability and risk; packaging cannot remove an obligation.
OPS1-CVAL-005  Operational, incident, emergency-change, access, G8, and re-entry authorities are explicit.
OPS1-CVAL-006  G8 routing does not authorize implementation, release, or uncontrolled production action.
OPS1-CVAL-007  Material control-boundary change triggers GOV-007, GOV-008 impact traversal, and affected baseline review.
OPS1-CVAL-008  Exit requires acknowledged routes into live identity, OBL, operational evidence, G8, and downstream action.
~~~
