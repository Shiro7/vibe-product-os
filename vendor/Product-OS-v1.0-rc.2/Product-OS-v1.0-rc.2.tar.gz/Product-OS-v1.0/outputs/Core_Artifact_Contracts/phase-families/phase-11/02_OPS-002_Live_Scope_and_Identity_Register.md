# Core Artifact Contract — OPS-002 Live Scope and Identity Register

~~~yaml
contract_id: CONTRACT-OPS-002
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: OPS-002
artifact_name: Live Scope and Identity Register
owning_phase: Phase 11 - Operations and Evolution
gate_or_baseline: Operational identity control / G8 input
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: OPS-001, VRL-030, VRL-035 through VRL-038, deployment evidence, brownfield discovery, and authoritative runtime sources
primary_downstream: OPS-003, OPS-004 through OPS-038, incident response, operational change, and G8
semantic_source: ../../../Phase_11_Operations_and_Evolution.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

OPS-002 is the canonical register of what Product OS actually operates and where it exists. It binds product, service, runtime, environment, account, region, topology, version, configuration, feature state, tenant / cohort, domain, data, integration, dependency, owner, and lifecycle identities to current evidence.

It prevents intended architecture, release plans, repository names, dashboards, or inventory labels from being mistaken for live identity.

---

# 2. Scope and Applicability

OPS-002 is CORE for every live scope. It may be partitioned by service, platform, environment, region, tenant class, regulated boundary, or operating owner, provided a governed aggregate preserves uniqueness and dependencies.

Sensitive values, credentials, private keys, tokens, and unrestricted personal data are never stored. The register records secure references, classifications, custodians, rotation / expiry metadata, and approved access paths.

---

# 3. Accountabilities and Sources

- **Register owner:** accountable for identity currency and reconciliation.
- **Identity owners:** service, platform, data, domain, network, integration, vendor, and configuration owners attest their bounded entries.
- **Change owners:** update affected identities after releases, rollbacks, migrations, failovers, transfers, emergency changes, or drift remediation.
- **AI:** may compare sources and flag drift; it cannot assert that a runtime, deployment, tenant, control, or dependency exists without evidence.

Preferred sources are authoritative runtime, deployment, cloud / platform, configuration, domain, certificate, service-discovery, data-catalog, identity, and vendor systems plus signed execution evidence.

---

# 4. Minimum Identity Record

Each entry records as applicable:

1. canonical live-scope and identity IDs, type, name, owner, criticality, status, and lifecycle state;
2. product / capability / service / component / integration relationship;
3. environment class, provider, account / subscription / project, region, cluster, namespace, host, domain, endpoint, and network boundary;
4. deployment, build, image, schema, migration, configuration, feature-flag, cohort, locale, and version identities;
5. tenant, data store, dataset, residency, classification, retention, and processing boundary without exposing restricted values;
6. upstream / downstream dependencies, consumers, vendors, trust boundaries, and fallback / exit paths;
7. operational owner, technical owner, on-call, support, access authority, and secure source references;
8. discovery / observation source, collection time, confidence, attestor, evidence, freshness, and reconciliation status;
9. expected identity, observed identity, drift, risk, restriction, action, and due date;
10. effective-from / to, supersession, history, and reopen trigger.

---

# 5. Identity, Drift, and Evidence Rules

Every identity is attributable to a current source and evidence time. `OBSERVED`, `DECLARED`, `UNKNOWN`, `DRIFTED`, `DECOMMISSIONING`, and `RETIRED` remain distinct. An unresolved material mismatch blocks claims that OPS-003, an incident scope, a change, or G8 is correctly bound.

OPS-002 references but does not replace service catalogs, CMDBs, cloud inventories, data catalogs, source control, deployment records, or vendor systems. Conflicts are recorded and reconciled with authority.

---

# 6. Profiles, Exit, and Reopen

- **P1:** a concise register may cover one product and deployment, but exact live target, version, owner, dependencies, and evidence remain required.
- **P2:** identity sets are modular by domain and reconciled on a controlled cadence.
- **P3:** automated discovery, multi-region / tenant reconciliation, attestation, drift control, evidence retention, and independent review strengthen.

The register is usable when every in-scope live object has a unique identity, owner, authoritative source, status, dependency context, and freshness; material unknowns and drift have bounded treatment. Reopen on any live identity, topology, configuration, cohort, data, dependency, owner, environment, vendor, lifecycle, or source-of-truth change.

---

# 7. Validation Rules

~~~text
OPS2-CVAL-001  Every live entry has a unique canonical identity, bounded scope, type, owner, status, and authoritative evidence source.
OPS2-CVAL-002  Planned, declared, observed, drifted, unknown, decommissioning, and retired identities remain distinct.
OPS2-CVAL-003  Candidate, build, deployment, runtime, configuration, data, tenant, region, and dependency identities remain traceable.
OPS2-CVAL-004  Secrets and restricted values are never copied into the register; only governed references and lifecycle metadata are stored.
OPS2-CVAL-005  Source conflict and material drift create an owned reconciliation and affected-baseline impact review.
OPS2-CVAL-006  Inventory presence, naming similarity, dashboard visibility, or prior deployment does not prove current live identity.
OPS2-CVAL-007  Incident, change, evidence, OBL, and G8 records bind the exact applicable OPS-002 identity revision.
OPS2-CVAL-008  Material identity change preserves history and triggers OPS-003 currency review.
~~~
