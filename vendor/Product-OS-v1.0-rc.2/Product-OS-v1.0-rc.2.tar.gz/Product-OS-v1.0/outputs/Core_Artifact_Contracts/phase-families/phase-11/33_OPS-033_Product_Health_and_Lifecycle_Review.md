# Core Artifact Contract — OPS-033 Product Health and Lifecycle Review

~~~yaml
contract_id: CONTRACT-OPS-033
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: OPS-033
artifact_name: Product Health and Lifecycle Review
owning_phase: Phase 11 - Operations and Evolution
gate_or_baseline: G8 evidence and recommendation
default_activation: RECURRING_AND_TRIGGERED
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: OPS-003 through OPS-032, lifecycle evidence, strategy, portfolio, standards, contracts, and prior G8 decisions
primary_downstream: OPS-034 through OPS-038, G8, lifecycle action, and Product OS re-entry
semantic_source: ../../../Phase_11_Operations_and_Evolution.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

OPS-033 is the independent, period-bound assessment of whether an exact live product scope is healthy, sustainable, strategically coherent, supportable, compliant, economically viable, and appropriate for its current lifecycle state. It turns current operational and evolution evidence into a reviewable assessment and recommendation for G8.

It does not issue the G8 decision, authorize change, approve release, or silently convert a recommendation into a roadmap commitment.

---

# 2. Scope and Cadence

OPS-033 is required at the approved product-health and G8 cadence and on material trigger events. Reviews may be segmented by product, capability, service, region, tenant / cohort, platform, version, lifecycle state, or regulated boundary when evidence or decisions differ.

The review binds an exact OPS-003 version, evidence period, cut-off, prior-decision state, and current live identity. Stale, biased, inaccessible, or incomparable evidence remains visible.

---

# 3. Accountabilities and Inputs

- **Review owner:** accountable for scope, evidence integrity, synthesis, and timely completion.
- **Domain assessors:** product, business, users, support, operations, reliability, security, privacy, data, accessibility, audit, architecture, engineering, finance, vendor, legal, and lifecycle owners as applicable.
- **Challenge / assurance:** independent enough for the risk and profile.
- **G8 authority:** receives the review but remains the decision owner.
- **AI:** may correlate trends and draft findings; it cannot manufacture evidence, accept risk, select lifecycle outcome, or decide G8.

Inputs include current OBL; objectives and outcomes; SLI / SLO and error budgets; incidents and problems; support and feedback; control evidence; capacity and cost; vendors and assets; maintenance and debt; experiments and realized outcomes; deprecation / transfer signals; obligations; prior G8 conditions and actions.

---

# 4. Minimum Health Review

OPS-033 records:

1. review ID, exact scope, OPS-002 / OPS-003 revisions, period, cut-off, cadence / trigger, owner, participants, and limitations;
2. health dimensions, definitions, thresholds, sources, weights where used, confidence, status, trend, and evidence;
3. service reliability, user experience, accessibility, product value, business outcome, support burden, security, privacy, audit, data, recovery, performance, capacity, cost, sustainability, vendor, maintainability, debt, and lifecycle assessment;
4. current lifecycle state and evidence for incubation, growth, mature, maintain, constrain, deprecate, sunset, transfer, or retired states as applicable;
5. prior review / G8 action completion, condition effectiveness, benefit realization, regression, and unresolved ownership;
6. cross-domain tensions, scope-specific differences, uncertainties, minority or high-impact needs, and sensitivity to assumptions;
7. findings classified as sustainment, mandatory action, remediation, evolution, constraint, sunset assessment, transfer assessment, or critical escalation candidates;
8. recommendation, alternatives considered, no-change consequence, risk, dependencies, capacity, earliest affected phase, evidence needs, and dissent;
9. next review cadence and early trigger events.

---

# 5. Health and Lifecycle Semantics

Each dimension records both status and trend. `HEALTHY`, `WATCH`, `DEGRADED`, `CRITICAL`, `UNKNOWN`, and `NOT_APPLICABLE` cannot be averaged into a misleading green score. Improving, stable, degrading, volatile, and unknown trends remain distinguishable. Composite ratings disclose method, weights, missing data, sensitivity, and prohibited interpretations.

A lifecycle label follows evidence and governed authority. Low usage alone, high cost alone, one executive request, or an aging technology does not automatically justify deprecation or sunset.

---

# 6. Profiles, Exit, and Reopen

- **P1:** a concise review may combine health dimensions while exact scope, sources, critical findings, prior actions, and recommendation remain explicit.
- **P2:** domain assessments are independently owned and synthesized through a governed review.
- **P3:** independent assurance, longitudinal cohorts, regulatory / contractual review, cost and vendor analysis, resilience exercises, scenario modeling, and lifecycle impact assessment strengthen.

The review is complete when all applicable dimensions, critical unknowns, prior actions, current lifecycle state, scope differences, recommendations, alternatives, route implications, and evidence limitations are explicit and acknowledged. Reopen on material evidence correction, incident, control failure, SLO / cost / vendor / lifecycle change, action failure, scope change, standard change, or G8 request.

---

# 7. Validation Rules

~~~text
OPS33-CVAL-001  OPS-033 binds an exact live scope, OBL revision, review period, evidence cut-off, cadence or trigger, and accountable owner.
OPS33-CVAL-002  Every health dimension defines source, metric or method, threshold, status, trend, confidence, limitation, and evidence.
OPS33-CVAL-003  Critical, degraded, unknown, volatile, and NOT_APPLICABLE dimensions cannot be hidden by a composite score.
OPS33-CVAL-004  Prior G8 actions, conditions, restrictions, benefits, and failures receive explicit disposition.
OPS33-CVAL-005  Lifecycle state and recommendation distinguish evidence, interpretation, alternatives, risk, authority, and no-change consequence.
OPS33-CVAL-006  Scope-specific health and lifecycle differences remain visible rather than averaged away.
OPS33-CVAL-007  The review recommends and routes; it does not authorize implementation, release, sunset, transfer, or G8 outcome.
OPS33-CVAL-008  Material new evidence or trigger event invalidates stale conclusions and reopens review.
~~~
