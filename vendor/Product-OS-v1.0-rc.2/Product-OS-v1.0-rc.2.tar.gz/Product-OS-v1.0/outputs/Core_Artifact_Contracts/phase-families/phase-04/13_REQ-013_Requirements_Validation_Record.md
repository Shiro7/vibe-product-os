# Core Artifact Contract — REQ-013 Requirements Validation Record

~~~yaml
contract_id: CONTRACT-REQ-013
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: REQ-013
artifact_name: Requirements Validation Record
owning_phase: Phase 04 - Requirements Engineering
gate_or_baseline: G3B - Requirements Baseline / RBL - Requirements Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: REQ-001 through REQ-012, Product Baseline and G3A decision, governance registers, GOV-009, and requirements-validation evidence
primary_downstream: G3B decision, RBL status, REQ-014, Experience Architecture, Product Design, Solution Architecture, Engineering Readiness, and Verification
semantic_source: ../../../Phase_04_Requirements_Engineering.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

REQ-013 is the independent evidence and control record showing how the exact Requirements Baseline was reviewed, challenged, corroborated, contradicted, corrected, confirmed, conditioned, or left unresolved before G3B.

It binds exact REQ-001 through REQ-012 versions, requirement objects, acceptance criteria, verification allocations, traceability paths, release scope, applicability, standards derivation, validation activities, reviewers / authoritative sources, evidence, limitations, conflicts, feasibility findings, conditions, and all nineteen G3B check domains.

It answers: **Which requirements and versions were validated, by what method and authority, for which release and context, what remains disputed or incomplete, and can downstream phases proceed without inventing behavior, constraints, acceptance, or obligation meaning?**

Validation is not grammar review, stakeholder attendance, consensus, document presence, row count, traceability appearance, prototype existence, implemented behavior, passed tests, or AI confidence. REQ-013 supplies reproducible evidence to the G3B authority; it does not self-approve the gate.

---

# 2. Scope and Applicability

REQ-013 is CORE whenever Phase 04 is active. It validates the exact RBL identity, version, release scope, product boundary, markets, platforms, channels, languages, users, data contexts, integrations, standards profiles, and operating conditions.

Different releases, markets, legal entities, platforms, product variants, regulatory profiles, or risk classes may require separate validation activities and dispositions within one controlled record or separate scoped records.

Prior validation may be reused only when requirement identity and version, source, release, scope, acceptance, verification method, product context, standards applicability, authority, evidence period, freshness, risk, and limitations remain fit for the current G3B decision.

NOT_APPLICABLE is valid only when an authorized alternate requirements baseline and gate-evidence mechanism replaces Phase 04 for the exact route, records authority, risk, evidence, standards coverage, downstream use, and reopen conditions, and does not force downstream phases to invent system obligations.

---

# 3. Accountabilities

- **Owner:** requirements-validation owner independent enough to report gaps, contradictions, infeasibility, and dissent truthfully.
- **Requirement owners:** maintain exact canonical requirements, sources, acceptance, status, release allocation, version history, and responses to findings.
- **Business and product authorities:** confirm derivation from the accepted Business and Product Baselines without silently changing their meaning.
- **Domain and user authorities:** confirm behavior, rule, information, role, context, and outcome semantics within their authority.
- **Specialist reviewers:** validate activated performance, reliability, data, integration, security, privacy, accessibility, audit, legal, regulatory, localization, continuity, operational, and evidence obligations.
- **Experience, Design, Architecture, Engineering, Verification, and Operations reviewers:** challenge clarity, completeness, feasibility, verifiability, allocation readiness, and downstream usability without replacing requirements with design.
- **G3B decision authority:** decides `PASS`, `PASS_WITH_CONDITIONS`, `HOLD`, or `REJECT` for the exact RBL.
- **Downstream receivers:** acknowledge exact baseline versions, conditions, allocations, open non-blocking items, and prohibited assumptions.
- **AI:** may assemble evidence, compare versions, detect duplicates / conflicts / orphans, traverse derivation and coverage, and propose check status; it cannot claim validation occurred, invent sources or authority, resolve normative conflicts, waive obligations, accept risk, or approve G3B.

---

# 4. Required Inputs

1. Exact Product Baseline, G3A decision, conditions, release scope, and accepted downstream route.
2. REQ-001 consolidated System Requirements Specification version under validation.
3. REQ-002 Requirement Catalog and Index with canonical locations, ownership, lifecycle, release, and baseline status.
4. REQ-003 Functional, REQ-004 Non-Functional, REQ-005 Data, REQ-006 Integration, REQ-007 Security and Privacy, REQ-008 Accessibility, and REQ-009 Audit and Evidence catalogs, including applicable conditional dispositions.
5. REQ-010 Acceptance and Verification Matrix as a derived view over canonical requirement acceptance and verification fields.
6. REQ-011 Requirements Traceability Matrix as a derived view over GOV-008, with source-graph revision and view freshness.
7. REQ-012 issue and conflict records, resolutions, upstream routes, blockers, owned conditions, and residual concerns.
8. GOV-003 decisions, GOV-004 risks, GOV-005 assumptions, GOV-006 questions, GOV-007 changes, GOV-008 paths, and GOV-009 applicability / derivation entries.
9. Validation activities, participants / authoritative sources, methods, contexts, evidence periods, feasibility findings, limitations, contradictions, corrections, dissent, and receiver acknowledgements.

---

# 5. Required Questions

1. Which exact RBL, REQ-001 through REQ-012 versions, release scope, and product contexts are being validated?
2. Which validation method applies: business, product, domain, user, scenario, rule, data, integration, quality, security, privacy, accessibility, audit, standards, traceability, feasibility, verification, or another governed method?
3. Does each participant or source have relevant knowledge and authority for the exact requirement and context reviewed?
4. Would implementation exactly as written satisfy the approved responsibility safely, completely, and observably?
5. Is every requirement necessary, correct, atomic, unambiguous, complete enough, consistent, feasible, verifiable, implementation-independent, traceable, prioritized, and owned?
6. Are normative requirement, rationale, source, applicability, acceptance criterion, verification method, priority, release, lifecycle, and implementation note semantically separate?
7. Do all approved business, product, risk, control, policy, information, standard, and release obligations have requirement coverage or authorized no-requirement rationale?
8. Are normal, alternate, invalid, unauthorized, dependency-failure, timeout, partial, recovery, state, data, integration, quality, security, privacy, accessibility, audit, and evidence paths covered proportionately?
9. Are acceptance criteria observable and verification methods feasible without turning implementation or test results into requirement truth?
10. Which duplicate, conflict, orphan, derivation gap, architecture leakage, infeasibility, scope-change candidate, or mandatory-obligation gap remains?
11. Which open item blocks G3B, and which can proceed only as an authorized, owned, time-bound condition?
12. Can every downstream receiver consume the baseline without inventing behavior, constraints, thresholds, acceptance, evidence, or standards meaning?

---

# 6. Validation Status, Requirement Disposition, and G3B Outcome Separation

Validation activity status:

~~~text
PLANNED
IN_PROGRESS
PARTIAL
COMPLETE
INVALIDATED
SUPERSEDED
~~~

Requirement / claim disposition:

~~~text
CONFIRMED
SUPPORTED
PARTIALLY_SUPPORTED
CONTRADICTED
CORRECTED
UNRESOLVED
NOT_EVALUATED
NOT_APPLICABLE
~~~

G3B check status:

~~~text
PASS
PASS_WITH_CONDITION
FAIL
BLOCKED
NOT_APPLICABLE
~~~

G3B outcome:

~~~text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
~~~

These dimensions remain separate. A completed activity may contradict a requirement. A requirement may be well written but lack authority, feasibility, acceptance, or downstream coverage. Implemented behavior or a passing test does not retroactively validate an invalid requirement. G3B PASS approves Requirements Baseline sufficiency only.

---

# 7. Minimum Validation Activity Record

~~~yaml
requirements_validation_id:
rbl_id:
rbl_version:
release_scope_ref:
market_platform_channel_language_context: []
requirement_and_artifact_refs: []
requirement_versions: []
claim_or_contract_under_review:
validation_type:
method:
participant_or_source_refs: []
knowledge_and_authority_scope:
scenario_population_or_operating_context:
evidence_period:
performed_by:
performed_at:
evidence_refs: []
expected_confirmation_or_acceptance:
actual_result:
requirement_disposition:
confidence:
limitations: []
contradictions_or_conflicts: []
corrections: []
derivation_traceability_or_coverage_gaps: []
feasibility_or_verification_gaps: []
standards_and_gov_009_refs: []
upstream_change_candidates: []
follow_up_actions: []
owner:
due_event:
status:
reviewed_by: []
supersedes:
superseded_by:
reopen_triggers: []
~~~

---

# 8. Minimum Requirements Validation Summary

~~~yaml
requirements_validation_record_id:
project_id:
rbl_id:
rbl_version:
pbl_and_g3a_refs: []
validated_release_scope:
validated_contexts:
  markets: []
  platforms: []
  channels: []
  languages: []
  user_and_operating_contexts: []
artifact_versions:
  req_001:
  req_002:
  req_003:
  req_004:
  req_005:
  req_006:
  req_007:
  req_008:
  req_009:
  req_010:
  req_011:
  req_012:
conditional_family_dispositions: []
validation_activities: []
coverage:
  baseline_scope_and_upstream_derivation:
  requirement_quality:
  functional_and_state_behavior:
  non_functional_quality:
  data_and_information:
  integration_and_dependency_behavior:
  security_and_privacy:
  accessibility:
  audit_and_evidence:
  acceptance_and_testability:
  traceability_and_release_integrity:
  dependencies_and_feasibility:
  conflicts_duplicates_and_open_items:
  standards_derivation:
  downstream_readiness_and_change_governance:
confirmed_requirements: []
partial_or_unresolved_requirements: []
contradicted_or_corrected_requirements: []
orphan_requirements_and_obligations: []
duplicate_and_conflict_findings: []
scope_change_candidates: []
architecture_leakage_findings: []
feasibility_and_verification_gaps: []
method_and_evidence_limitations: []
blocking_decisions_questions_and_issues: []
conditions: []
risk_reassessment_ref:
gov_009_entries: []
downstream_allocation_readiness: []
g3b_checks: []
recommended_g3b_outcome:
g3b_decision_ref:
approved_by: []
downstream_routes: []
prohibited_downstream_assumptions: []
receiver_acknowledgements: []
evidence_index: []
reopen_triggers: []
~~~

Every `PASS_WITH_CONDITIONS` condition records exact affected requirements and scope, rationale, owner, due event / gate, evidence expectation, escalation, downstream consequence, receiver acknowledgement, and failure disposition.

---

# 9. G3B Check Contract

REQ-013 provides evidence for all nineteen G3B domains:

1. **Baseline scope:** exact product, release, market, platform, channel, language, user, and operating scope is explicit.
2. **Upstream derivation:** requirements trace to approved business, product, risk, control, policy, information, standard, decision, or other authorized sources.
3. **Requirement quality:** baselined requirements are necessary, correct, atomic, unambiguous, complete enough, consistent, feasible, verifiable, implementation-independent, traceable, prioritized, and owned.
4. **Functional coverage:** committed capabilities, states, rules, roles, journeys, exceptions, errors, recovery, administration, and generated behavior have adequate FR coverage.
5. **NFR coverage:** applicable quality domains have measurable subjects, conditions, metrics, thresholds, tolerances, and verification intent.
6. **Data coverage:** meaning, ownership, source, validation, quality, classification, privacy, lifecycle, retention, deletion, residency, derivation, and migration obligations are covered where material.
7. **Integration coverage:** applicable external interactions include observable exchange, timing, failure, retry, duplicate, ordering, security, evidence, reconciliation, and fallback behavior.
8. **Security and privacy:** identity, access, isolation, sessions, sensitive data, privacy rights, abuse, recovery, control, and residual-risk routes are sufficiently specified.
9. **Accessibility:** adopted criteria and exact journeys, forms, states, documents, platforms, localization contexts, and third-party responsibilities have verifiable coverage.
10. **Audit and evidence:** material accountability, control, decision, administrative, security, privacy, and evidence obligations have precise event / record and lifecycle semantics.
11. **Acceptance and testability:** every baselined requirement has observable acceptance and a feasible verification method, level, and expected evidence route.
12. **Traceability:** bidirectional source-to-requirement-to-downstream-to-test-to-evidence paths are resolvable through GOV-008 without competing truth.
13. **Priority and release integrity:** priority, release allocation, dependencies, exclusions, deferrals, and changes are authorized and do not leave an incoherent delivery slice.
14. **Dependencies and feasibility:** material external, data, platform, standards, operational, technical, sequencing, and evidence dependencies are explicit and reviewed.
15. **Conflicts and duplicates:** unresolved blocking semantic duplicates, contradictions, authority conflicts, or inconsistent obligations equal zero.
16. **Open questions and decisions:** blocking TBDs, TBCs, decisions, questions, issues, assumptions, and scope-change candidates equal zero.
17. **Standards derivation:** applicable GOV-009 obligations have requirement IDs, acceptance / verification links, downstream owners, coverage status, evidence expectations, and reopen conditions.
18. **Downstream readiness:** Experience, Design, Architecture, Engineering, and Verification can proceed without inventing behavior, constraints, thresholds, acceptance, or obligation meaning.
19. **Change governance:** requirement changes preserve authority, versioning, baseline status, impact traversal, receiver notification, stale-state propagation, revalidation, and re-approval.

Each check binds exact artifact and requirement versions, evidence, scope, context, status, limitations, conditions, and accountable reviewer. A family marked `CONDITIONAL` or `NOT_APPLICABLE` requires authorized rationale, evidence, downstream impact, and reopen triggers; omission or empty catalogs do not prove non-applicability.

---

# 10. G3B Outcome Contract

## PASS

The exact Requirements Baseline is coherent, sufficiently complete, derived, measurable, traceable, feasible, verifiable, and ready for the approved downstream routes. No blocking requirement, source, acceptance, standards, conflict, dependency, or change-governance gap remains.

## PASS_WITH_CONDITIONS

Residual work is explicit, owned, time-bound, evidence-bound, accepted by affected downstream receivers, and does not force them to invent or reinterpret material behavior or obligations.

## HOLD

Used when scope, derivation, mandatory coverage, requirement quality, acceptance, traceability, feasibility, standards applicability, conflict, decision, or another material baseline property remains unresolved and makes downstream work unsafe.

## REJECT

Used when the proposed baseline conflicts materially with approved authority, omits critical obligations, is structurally untestable or infeasible, or requires substantial rework before renewed validation.

G3B outcome, authority, timestamp, rationale, conditions, affected scope, evidence, receiver acknowledgements, and reopen triggers are recorded through the governed gate-decision mechanism. REQ-013 may recommend but cannot issue the outcome.

---

# 11. Traceability and Change Impact

Required paths include:

~~~text
BUS / PROD / GOV-009 / risk / control / policy / decision / evidence source
  -> exact requirement version
  -> acceptance criterion and verification allocation
  -> REQ-013 validation activity and G3B check
  -> G3B decision and RBL version
  -> REQ-014 downstream allocation
  -> Experience / Design / Architecture / Engineering / Test / Evidence object
~~~

Any change to source authority, product or release scope, requirement statement, applicability, priority, acceptance, verification, standards derivation, dependency, or evidence expectation triggers impact analysis. Affected validation results become `STALE` or `REVIEW_REQUIRED` until re-evaluated; copied downstream content cannot conceal staleness.

Changes to product boundary route to Phase 03, business rule / control / information authority to Phase 02, and standards applicability to GOV-009. Phase 04 cannot hide upstream scope expansion as requirement clarification.

---

# 12. Profile Behavior

| Profile | Required behavior |
|---|---|
| Level 1 — Rapid | One compact record may validate the exact small RBL, but all applicable G3B checks, blockers, authority, conditions, evidence, downstream route, and reopen triggers remain explicit. |
| Level 2 — Standard | Structured activities, family coverage, traceability sampling plus critical-path completeness, specialist review, findings, conditions, and receiver acknowledgement are required. |
| Level 3 — Comprehensive | Independent or segregated review, full critical and regulated traceability, multi-context / multi-profile validation, quantitative quality checks, specialist evidence, reproducibility, and formal condition monitoring are required. |

Profile changes packaging and validation depth, not the meaning of G3B or permission to omit applicable mandatory obligations.

---

# 13. Evidence and Exit Conditions

Evidence may include reviewed requirement snapshots, source comparisons, derivation reports, scenario results, domain confirmations, quality analyses, conflict reports, duplicate detection, traceability traversals, feasibility reviews, specialist assessments, acceptance reviews, standards coverage, issue resolutions, signed decisions, and receiver acknowledgements.

REQ-013 is complete only when:

1. exact RBL and REQ-001 through REQ-012 versions are bound;
2. every applicable G3B domain has status, authority, evidence, limitations, and conditions;
3. critical and mandatory obligations have complete derivation, acceptance, verification, and downstream routes;
4. duplicate, conflict, orphan, scope-change, architecture-leakage, and feasibility findings are resolved or governed;
5. blocking decisions, questions, issues, and applicability gaps equal zero for PASS;
6. conditions are owned, time-bound, evidence-bound, acknowledged, and cannot invalidate the downstream route;
7. recommended outcome and designated decision authority are explicit;
8. REQ-014 can reproduce the accepted baseline and conditions without interpretation.

Reopen on baseline change, source / authority change, release-scope change, standards applicability change, invalidated evidence, newly discovered conflict or omission, failed condition, significant feasibility finding, downstream contradiction, or incorrect gate basis.

---

# 14. Validation Rules

~~~text
REQ13-CVAL-001  REQ-013 binds exact RBL, REQ-001 through REQ-012, release, source, acceptance, verification, and GOV-009 versions.
REQ13-CVAL-002  Validation activity status, requirement disposition, G3B check status, and G3B outcome remain separate.
REQ13-CVAL-003  Every one of the nineteen G3B domains has scoped evidence, authority, limitations, status, and conditions where applicable.
REQ13-CVAL-004  Grammar review, consensus, document presence, row count, implementation, passed tests, or AI confidence cannot substitute for requirements validation.
REQ13-CVAL-005  Blocking derivation, coverage, conflict, acceptance, feasibility, standards, decision, or traceability gaps prevent G3B PASS.
REQ13-CVAL-006  Conditions are exact, owned, time-bound, evidence-bound, acknowledged, and incapable of forcing downstream invention.
REQ13-CVAL-007  Source or baseline change propagates impact, stale status, revalidation, receiver notification, and re-approval where required.
REQ13-CVAL-008  REQ-013 supplies evidence and recommendation but cannot self-approve G3B or claim downstream design, implementation, verification, or release readiness.
~~~

