# Phase 01 Family Contract — Discovery Models and Registers

~~~yaml
bundle_id: CONTRACT-BUNDLE-PHASE-01-FAMILY
bundle_version: 0.1.0
bundle_status: WORKING_DRAFT
asset_class: Product OS contract bundle - not a project artifact
artifact_family: DISC
owning_phase: Phase 01 - Discovery and Problem Definition
gate_or_baseline: G1 - Problem Understood / DSBL - Discovery Baseline
specialized_contract_artifacts:
  - DISC-001
  - DISC-003
  - DISC-004
  - DISC-005
  - DISC-006
  - DISC-007
  - DISC-008
shared_only_disposition_reviews: []
specialized_section_defaults:
  contract_version: 0.1.0
  contract_status: WORKING_DRAFT
  inherits: CORE-ARTIFACT-STANDARD@0.2.0
shared_inheritance: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: INIT-001, INIT-007, registered evidence, and active governance registers
primary_downstream: DISC-002, DISC-009, G1, BUS-001, and the approved alternate route
semantic_source: ../../../Phase_01_Discovery_and_Problem_Definition_v1.1.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Bundle Purpose and Boundary

This file provides seven independently governed logical discovery contracts without requiring seven physical files in every project. Each section retains its own artifact ID, contract ID, activation, lifecycle, validation, traceability, exit, and reopen rules.

~~~text
DISC-001  Discovery Plan
DISC-003  Stakeholder Map
DISC-004  Current-State Model
DISC-005  Problem Register
DISC-006  Cause & Hypothesis Register
DISC-007  Outcome & Success Model
DISC-008  Scope Hypothesis
~~~

[DISC-002 Discovery Findings](../../critical-chain/02_DISC-002_Discovery_Findings.md) remains the consolidated discovery source of truth. `DISC-009` independently records validation and G1 evidence. The detailed method remains in [Phase 01 — Discovery and Problem Definition](../../../Phase_01_Discovery_and_Problem_Definition_v1.1.md); this bundle operationalizes artifact contracts and does not create a competing phase methodology.

---

# 2. Shared Discovery Family Rules

1. Discovery defines and validates the problem before approving a solution.
2. Current state, symptom, problem, impact, cause hypothesis, validated cause, constraint, opportunity, desired outcome, success measure, and solution idea remain different object types.
3. Evidence strength, confidence, validation, authority, approval, and artifact status remain separate.
4. Multiple perspectives and contradictory evidence remain visible; no source becomes absolute truth automatically.
5. Cause must be earned through evidence; correlation is not causation and AI plausibility is not validation.
6. Desired outcomes express changed conditions, not features or technology choices.
7. Scope in Phase 01 is a hypothesis for later evaluation, not approved product scope.
8. Discovery stops when the decision risk of continuing is acceptably lower than the cost of more discovery, not when everything is known.
9. Phase 01 enriches GOV-009 evidence and pending ownership but does not invent business applicability decisions or requirements.
10. Non-software intervention and no-product-change outcomes remain valid.

---

# 3. Shared Profile Packaging

- **P1 — Lean:** all seven logical artifacts may be governed sections of one Discovery Pack while stable IDs, evidence, uncertainty, and validation remain explicit.
- **P2 — Standard:** stakeholder, current-state, problem, cause, outcome, scope, and validation records are modular and independently reviewable.
- **P3 — Comprehensive:** multi-stakeholder coverage, deeper source authority, quantitative evidence, process variants, formal conflict management, audit history, independent validation, and domain-by-domain assurance strengthen.

Discovery breadth (`FOCUSED`, `STANDARD`, `CROSS_FUNCTIONAL`, `ENTERPRISE`) is different from P1 / P2 / P3. Profile and breadth cannot be conflated to justify missing applicable evidence.

---

# 4. DISC-001 — Discovery Plan Contract

~~~yaml
contract_id: CONTRACT-DISC-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-001
artifact_name: Discovery Plan
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: INIT-001, INIT-007, G0 conditions, and registered sources
primary_downstream: DISC-002 through DISC-009 and G1
~~~

## 4.1 Purpose

DISC-001 defines why discovery is needed, which decisions it must inform, what will be investigated, who and what must be covered, which methods and evidence are appropriate, how uncertainty and risk will be handled, and when discovery should stop.

It answers: **What must we learn to reduce decision risk enough for G1, through which evidence and stakeholders, within which investigation boundary?**

It is not product scope, a requirements plan, a solution-design plan, or a promise to use one research technique.

## 4.2 Applicability and Accountabilities

DISC-001 is CORE whenever Phase 01 is active. A compressed route may reuse current authoritative evidence but still records objectives, decision use, evidence freshness, gaps, validation, and stop conditions.

- **Owner:** discovery lead or product / business analyst.
- **Decision consumers:** G1 and downstream business, product, recovery, or alternate-route authorities.
- **Method / evidence owners:** responsible for interviews, observation, analytics, documents, process evidence, or specialist review.
- **Participants:** affected users, operators, domain owners, authorities, controls, and external parties as applicable.
- **AI:** may propose scope, questions, methods, sampling, and gaps; it cannot claim participation, consent, access, evidence, or validation occurred.

## 4.3 Required Inputs and Questions

Inputs include ICB / G0 outcome and conditions, product state, initial problems and outcomes, sources and assets, authority context, risks, open questions, GOV-009 triggers, constraints, available time, access, and evidence.

The plan answers:

1. Which decision questions and G1 uncertainties must discovery resolve?
2. What discovery scope, exclusions, breadth, and depth apply—and how do they differ from future product scope?
3. Which stakeholders, users, contexts, operations, systems, processes, data, documents, third parties, and standards triggers require coverage?
4. What sources, methods, sampling / selection, evidence periods, and validation types are proportionate?
5. What access, privacy, confidentiality, safety, ethics, language, accessibility, or participant constraints apply?
6. Which assumptions, risks, conflicts, biases, missing perspectives, and dependencies threaten discovery validity?
7. What outputs, owners, milestones, evidence, review, and G1 checks are required?
8. What stop, escalation, rescope, and reopen conditions apply?

## 4.4 Minimum Plan Record

~~~yaml
plan_id:
project_id:
discovery_scope:
decision_questions: []
objectives: []
expected_decision_use: []
breadth:
depth_by_domain: []
included_domains: []
excluded_domains: []
stakeholder_coverage: []
user_and_context_coverage: []
sources_to_review: []
methods: []
sampling_or_selection: []
evidence_requirements: []
gov_009_entries: []
roles_and_owners: []
access_and_ethics_conditions: []
risks_and_biases: []
assumptions: []
dependencies: []
milestones: []
expected_outputs: []
validation_plan: []
g1_checks: []
stop_conditions: []
rescope_triggers: []
status:
approved_or_accepted_by: []
reopen_triggers: []
~~~

## 4.5 Decisions, Outputs, and Traceability

Required decisions cover scope and exclusions, breadth / depth, coverage, methods, evidence, owners, constraints, validation, stop conditions, and any authorized compression or reuse.

~~~text
ICB / G0 Need and Conditions
→ DISC-001 Questions, Scope, Coverage, Methods, and Evidence Plan
→ DISC-003 through DISC-008 Objects
→ DISC-002 Consolidated Findings
→ DISC-009 Validation / G1
~~~

Outputs include the versioned plan, coverage and evidence obligations, participant / source route, validation plan, risk and bias controls, and rescope history.

## 4.6 Verification, Exit, and Reopen

Verification confirms every planned activity supports a decision or G1 check, coverage gaps are visible, method claims are feasible, access is authorized, reused evidence has freshness and limitations, and the plan does not drift into solution approval.

DISC-001 is complete for use when objectives, scope, questions, coverage, methods, evidence, owners, risks, validation, outputs, stop conditions, and rescope route are explicit. Reopen on material G0 condition, scope, product-state, stakeholder, evidence, access, risk, GOV-009 trigger, method feasibility, or decision-use change.

## 4.7 Artifact-Specific Validation Rules

~~~text
DISC1-CVAL-001  Every discovery activity maps to a decision question, evidence need, or G1 check.
DISC1-CVAL-002  Discovery scope and future product scope remain explicitly distinct.
DISC1-CVAL-003  Stakeholder, user, context, source, method, and standards-trigger coverage gaps remain visible.
DISC1-CVAL-004  Reused evidence states source, period, freshness, scope, and limitations.
DISC1-CVAL-005  Access, privacy, confidentiality, safety, ethics, language, and accessibility constraints are governed.
DISC1-CVAL-006  Method choice is proportionate to state, risk, uncertainty, and decision use.
DISC1-CVAL-007  AI cannot claim research, participation, consent, access, evidence, or validation occurred.
DISC1-CVAL-008  Material scope or method change updates the plan and downstream evidence expectations.
~~~

---

# 5. DISC-003 — Stakeholder Map Contract

~~~yaml
contract_id: CONTRACT-DISC-003
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-003
artifact_name: Stakeholder Map
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: INIT-004, DISC-001, and registered evidence
primary_downstream: DISC-002, DISC-004 through DISC-009, GOV-003 through GOV-006, and G1
~~~

## 5.1 Purpose

DISC-003 identifies the people, roles, organizations, users, customers, operators, authorities, control owners, vendors, and external parties that influence or are affected by the problem, and makes perspective, knowledge, authority, impact, conflict, and coverage gaps explicit.

It answers: **Whose reality, harm, work, knowledge, authority, dependency, approval, or risk must be represented for the problem understanding to be defensible?**

It deepens INIT-004 but does not become a final organization, permission, RACI, or governance model.

## 5.2 Applicability and Accountabilities

DISC-003 is CORE. Coverage is proportionate to problem and risk; it cannot rely only on executive voices for operational problems or only on users when finance, control, legal, security, data, or compliance perspectives are material.

- **Owner:** discovery lead or stakeholder-research owner.
- **Stakeholder / evidence owners:** provide or validate the perspective and context attributed to them.
- **Authority reviewers:** confirm topic-bound decision and approval roles.
- **Privacy owner:** ensures identity and contact data are minimized.
- **AI:** may cluster roles and expose missing perspectives; it cannot invent people, authority, consensus, conflict resolution, or participation.

## 5.3 Required Inputs and Questions

Inputs include INIT-004, discovery scope, current-state claims, source identities, organizational evidence, problem and impact signals, risk / standards context, participation facts, and conflicts.

Each mapped stakeholder answers:

1. How does this party influence, experience, own, decide, approve, operate, control, depend on, or bear risk from the problem?
2. Which knowledge and authority domains are evidenced and which are unknown?
3. What impact, influence, urgency, access need, context, and perspective apply?
4. Which source and method represent the perspective, and when was it collected?
5. Who is missing, overrepresented, underrepresented, inaccessible, or represented by proxy?
6. Which conflicts, power imbalances, incentives, harms, or biases may distort findings?
7. What validation or decision route is required?
8. What may be retained without unnecessary personal data?

## 5.4 Minimum Stakeholder Record

~~~yaml
stakeholder_id:
person_role_or_group:
organization:
stakeholder_types: []
relationship_to_problem:
affected_contexts: []
knowledge_domains: []
authority_domains: []
decision_or_approval_limits: []
impact:
influence:
risk_or_control_ownership: []
dependencies: []
perspectives_and_needs: []
source_refs: []
research_or_contact_refs: []
evidence_period:
confidence:
conflicts_or_incentives: []
representation_status:
coverage_status:
privacy_and_access_class:
open_question_refs: []
affected_artifacts: []
reviewed_by: []
reopen_triggers: []
~~~

## 5.5 Decisions, Outputs, and Traceability

Required decisions identify stakeholder inclusion, representation method, knowledge / authority scope, missing-perspective disposition, conflict route, and sufficient G1 coverage.

~~~text
INIT-004 Authority Snapshot + Sources
→ DISC-003 Stakeholder / Perspective / Coverage Map
→ Current State / Problem / Impact / Outcome Evidence
→ DISC-002 Findings + DISC-009 Validation
→ G1 Stakeholder Coverage Check
~~~

Outputs are stakeholder entries, perspective and impact links, authority refinements, coverage gaps, conflict records, privacy treatment, and Phase 02 role / ownership handoff inputs.

## 5.6 Verification, Exit, and Reopen

Verification confirms mapped identities or groups are real and relevant, perspective claims have evidence and period, authority is topic-bound, proxy representation is visible, material missing voices are governed, and disagreement is not collapsed into fake consensus.

DISC-003 is complete for G1 when necessary affected, influential, knowledgeable, decision, control, and risk perspectives have sufficient representation or explicit gap / condition treatment. Reopen on new stakeholder, omitted context, role or authority change, conflict, impact shift, access change, or downstream discovery of missing representation.

## 5.7 Artifact-Specific Validation Rules

~~~text
DISC3-CVAL-001  Every stakeholder entry states relationship, context, evidence, and coverage purpose.
DISC3-CVAL-002  Knowledge, influence, impact, decision authority, approval, and control ownership remain distinct.
DISC3-CVAL-003  Executive-only or user-only coverage is invalid when other material perspectives exist.
DISC3-CVAL-004  Missing, proxy, underrepresented, inaccessible, and conflicting perspectives remain visible.
DISC3-CVAL-005  Disagreement cannot be rewritten as consensus without authority and evidence.
DISC3-CVAL-006  Personal data is minimized, access-controlled, and retained only as needed.
DISC3-CVAL-007  AI cannot invent identity, participation, authority, perspective, or agreement.
DISC3-CVAL-008  G1 stakeholder coverage is scoped to the problem and risk, not raw interview count.
~~~

---

# 6. DISC-004 — Current-State Model Contract

~~~yaml
contract_id: CONTRACT-DISC-004
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-004
artifact_name: Current-State Model
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-001, DISC-003, INIT-006, and current-state evidence
primary_downstream: DISC-002, DISC-005 through DISC-009, G1, and BUS-001
~~~

## 6.1 Purpose

DISC-004 models how work, product behavior, people, systems, data, decisions, handoffs, controls, exceptions, timing, volume, workarounds, and failures actually operate today at the depth needed to understand the problem.

It answers: **What really happens now, for whom and under which contexts, and where does actual state differ from documented policy, intended behavior, or reported belief?**

It is not target state, full enterprise process architecture, requirements, solution design, or unbounded documentation of every workflow.

## 6.2 Applicability and Accountabilities

DISC-004 is CORE, adapted by product state. Early ideas may model contexts and alternatives; business transformation needs operations and handoffs; existing products need behavior, analytics, support, and system evidence; recovery and evolution need incidents, drift, controls, and live evidence.

- **Owner:** discovery analyst or current-state model owner.
- **Evidence owners:** operators, users, process owners, system / data owners, support, control, and operational sources.
- **Reviewers:** stakeholders required to validate actual and policy differences.
- **AI:** may synthesize and compare evidence; it cannot claim observation, actual adoption, process frequency, system behavior, or production state without evidence.

## 6.3 Required Inputs and Questions

Inputs include discovery scope, stakeholders, existing assets, documented / reported / observed process evidence, system and data sources, analytics, logs, support, incidents, workarounds, previous attempts, policies, controls, and constraints.

The model asks:

1. What activity, trigger, actor, input, action, output, decision, system, data, control, and handoff exist?
2. What happens in normal, exception, failure, rework, override, and escalation paths?
3. Which state is documented, reported, observed, measured, or inferred?
4. Where do policy state and actual state differ?
5. What frequency, volume, timing, delay, error, effort, or population is known?
6. Which workarounds and previous attempts exist and with what consequence?
7. What evidence and period support each material state?
8. What depth from L0 context through L3 exception is needed for the decision?

## 6.4 Minimum Current-State Unit

~~~yaml
current_state_id:
context_or_workflow:
level: L0_OR_L1_OR_L2_OR_L3
state_basis: DOCUMENTED_OR_REPORTED_OR_OBSERVED_OR_MEASURED_OR_INFERRED
activity:
trigger:
actors: []
inputs: []
actions: []
outputs: []
systems_and_tools: []
data_objects: []
decisions_and_approvals: []
controls: []
handoffs: []
exceptions_and_failures: []
workarounds: []
timing_and_volume:
policy_state_ref:
actual_state_delta:
source_refs: []
evidence_period:
confidence:
symptom_refs: []
problem_refs: []
constraint_refs: []
dependency_refs: []
status:
reviewed_by: []
reopen_triggers: []
~~~

## 6.5 Decisions, Outputs, and Traceability

Required decisions cover investigation depth, canonical current-state interpretation, actual / policy distinction, material variants and exceptions, evidence limitations, and whether gaps block G1.

~~~text
Stakeholder / Asset / Process / System / Operational Evidence
→ DISC-004 Current-State Units and Variants
→ Symptom / Problem / Impact / Cause Analysis
→ DISC-002 Findings + DISC-009 Validation
→ G1 Current-State Check → BUS-001
~~~

Outputs include scoped context and workflow models, actual-versus-policy deltas, handoffs, decisions, controls, exceptions, workarounds, evidence limits, and downstream process / business-analysis needs.

## 6.6 Verification, Exit, and Reopen

Verification confirms actual, reported, observed, documented, measured, and inferred states are not conflated; material variants and exceptions are represented; exact sources and periods exist; and depth is sufficient for the problem without becoming premature target design.

DISC-004 is complete for G1 when the current condition and material variants, actors, systems, data, handoffs, controls, exceptions, and limitations are understandable enough to support problems and impacts. Reopen on process, product, system, data, policy, volume, context, evidence, incident, workaround, or operating-state change.

## 6.7 Artifact-Specific Validation Rules

~~~text
DISC4-CVAL-001  Every material current-state unit has context, basis, source, period, and confidence.
DISC4-CVAL-002  Documented, reported, observed, measured, and inferred process states remain distinct.
DISC4-CVAL-003  Actual state and policy state differences remain explicit.
DISC4-CVAL-004  Material exception, failure, override, rework, and workaround paths are not hidden.
DISC4-CVAL-005  Model depth is proportionate to problem, state, risk, and decision use.
DISC4-CVAL-006  Existing asset visibility cannot prove active use, deployment, ownership, or current behavior.
DISC4-CVAL-007  AI cannot claim observation, frequency, adoption, or production truth without evidence.
DISC4-CVAL-008  Current-state content cannot silently become target state, requirement, or solution design.
~~~

---

# 7. DISC-005 — Problem Register Contract

~~~yaml
contract_id: CONTRACT-DISC-005
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-005
artifact_name: Problem Register
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-003, DISC-004, symptoms, impacts, and registered evidence
primary_downstream: DISC-002, DISC-006 through DISC-009, G1, and BUS-001
~~~

## 7.1 Purpose

DISC-005 provides canonical discovery identities for symptoms, problems, impacts, priority, hierarchy, evidence, affected stakeholders and contexts, and unresolved cause state. It prevents solution absence, stakeholder preference, or a loud symptom from becoming the problem definition.

It answers: **What material negative condition or blocked outcome exists, for whom, with what supported impact and priority, and which evidence distinguishes it from its symptoms and possible causes?**

## 7.2 Applicability and Accountabilities

DISC-005 is CORE. Opportunity-led discovery may legitimately conclude no material problem exists, but still records the evidence and opportunity route rather than fabricating one.

- **Owner:** discovery lead or problem-model owner.
- **Impact / evidence owners:** supply operational, user, financial, control, data, security, compliance, safety, quality, or strategic support.
- **Affected stakeholders:** validate context and consequence without becoming automatic priority authority.
- **G1 authority:** accepts the problem set and residual uncertainty.
- **AI:** may detect candidate problems and solution contamination; it cannot invent impact, priority, consensus, or cause.

## 7.3 Required Inputs and Questions

Inputs include stakeholder and current-state models, symptoms, quantitative and qualitative evidence, workarounds, previous attempts, risks, constraints, opportunities, conflicts, and authority context.

Each problem asks:

1. Who or what is affected, what condition exists, and which desired state is prevented?
2. Is the statement a problem, symptom, impact, cause, constraint, opportunity, or missing solution?
3. What direct source and evidence support it, over which scope and period?
4. What financial, operational, customer, employee, compliance, security, quality, time, data, strategic, reputational, or safety impact exists?
5. What magnitude, frequency, population, urgency, cost, risk, and dependency support priority?
6. Which related, parent, or child problems and symptoms exist?
7. What cause status is known without overclaiming?
8. What evidence, conflict, or unknown could change or invalidate the problem?

## 7.4 Minimum Problem Record

~~~yaml
problem_id:
statement:
affected_area:
affected_stakeholders: []
affected_contexts: []
desired_state_blocked:
symptom_refs: []
impacts:
  categories: []
  statements: []
  magnitude:
  quantitative_refs: []
source_refs: []
evidence_strength: E0_TO_E4
evidence_period:
priority:
priority_rationale: []
frequency:
affected_population:
parent_problem:
child_problems: []
related_problems: []
cause_status:
cause_refs: []
constraints: []
dependencies: []
risks: []
conflicts: []
solution_contamination_flags: []
confidence:
status:
owner:
reviewed_by: []
reopen_triggers: []
~~~

Evidence strength from `E0 NONE` through `E4 MEASURED` describes current support, not a universal truth score. Missing metrics do not invalidate qualitative findings, but vague impact cannot justify unsupported criticality.

## 7.5 Decisions, Outputs, and Traceability

Required decisions cover problem identity, separation from symptoms and solutions, supported impacts, hierarchy, evidence strength, priority, cause status, and G1 inclusion / condition.

~~~text
Source / Current State → Symptom → DISC-005 Problem → Impact
Problem → DISC-006 Cause or Explicit Unresolved Cause
Problem → DISC-007 Outcome → Success Signal
Problem / Outcome → DISC-008 Scope Hypothesis
→ DISC-002 Findings + DISC-009 Validation → G1
~~~

Outputs are the governed problem and symptom set, impacts, priorities, hierarchies, evidence gaps, conflict routes, and trace links to outcomes and scope hypotheses.

## 7.6 Verification, Exit, and Reopen

Verification tests source / evidence lineage, solution-free statement quality, symptom distinction, material impact, priority rationale, hierarchy, cause-status honesty, and affected stakeholder coverage.

DISC-005 is complete for G1 when primary problems are explicit, evidence-backed, impact-linked, separated from symptoms / solutions / causes, prioritized proportionately, and connected to outcomes. Reopen on current-state change, new evidence, omitted population, impact correction, problem split / merge, cause invalidation, conflict, or downstream discovery of an unsupported problem.

## 7.7 Artifact-Specific Validation Rules

~~~text
DISC5-CVAL-001  Every problem states affected party or object, current condition, impact, and evidence.
DISC5-CVAL-002  Symptom, problem, impact, cause, constraint, opportunity, and solution remain distinct.
DISC5-CVAL-003  Absence of a preferred system, feature, or technology is not sufficient problem definition.
DISC5-CVAL-004  Critical and high priority require material impact and proportionate rationale.
DISC5-CVAL-005  Stakeholder loudness, seniority, or preference cannot determine priority alone.
DISC5-CVAL-006  Problem hierarchy preserves parent, child, related, split, merge, and supersession lineage.
DISC5-CVAL-007  AI cannot invent impact, priority, affected population, evidence, or cause.
DISC5-CVAL-008  G1 cannot pass when a primary problem lacks source, impact, or honest cause disposition.
~~~

---

# 8. DISC-006 — Cause & Hypothesis Register Contract

~~~yaml
contract_id: CONTRACT-DISC-006
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-006
artifact_name: Cause & Hypothesis Register
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-004, DISC-005, observations, system data, and other cause evidence
primary_downstream: DISC-002, DISC-007 through DISC-009, GOV-004, GOV-005, G1, and downstream analysis
~~~

## 8.1 Purpose

DISC-006 governs possible and supported explanations for problems, including cause identity, category, lifecycle, confidence, evidence, competing explanations, falsification, relationships, and unresolved state.

It answers: **What may be causing the problem, what evidence supports or challenges that explanation, how strong is the causal claim, and what remains unresolved?**

Plausibility, correlation, repetition, stakeholder certainty, or AI reasoning does not create a validated cause.

## 8.2 Applicability and Accountabilities

DISC-006 is CORE, but complete root-cause certainty is not mandatory for every discovery. G1 may proceed with a supported cause or an explicitly unresolved cause when the problem, outcome, route, and residual risk are sufficiently clear.

- **Owner:** discovery or cause-analysis owner.
- **Evidence / method owners:** observations, walkthroughs, data, logs, tests, audits, incidents, or analysis owners.
- **Domain reviewers:** assess causal claims and alternative explanations.
- **Risk / assumption owners:** receive material uncertainty through GOV-004 / GOV-005.
- **AI:** may generate hypotheses and challenge logic; it cannot label a cause supported, validated, primary, or root without evidence and authority.

## 8.3 Required Inputs and Questions

Inputs include problem identities, current-state and process evidence, observations, system / transaction data, logs, incidents, audits, tests, workarounds, previous attempts, constraints, dependencies, risks, and alternative explanations.

Each cause asks:

1. Which exact problem and effect is this explanation intended to address?
2. Is the relationship observed, hypothesized, supported, validated, rejected, or unresolved?
3. Which method and evidence support it, and over what scope and period?
4. What evidence contradicts it or could falsify it?
5. Is the pattern causal, correlational, contributory, conditional, or unknown?
6. Which people, process, policy, system, data, integration, control, governance, training, capacity, communication, vendor, regulatory, or physical category applies?
7. Which competing, interacting, parent, or contributing causes exist?
8. What decision, risk, validation, or downstream route depends on the result?

## 8.4 Cause Lifecycle and Minimum Record

~~~text
IDENTIFIED → HYPOTHESIZED → SUPPORTED → VALIDATED
                             ↘ REJECTED
                             ↘ UNRESOLVED
~~~

~~~yaml
cause_id:
statement:
problem_refs: []
category:
relationship_type: CAUSAL_OR_CORRELATIONAL_OR_CONTRIBUTORY_OR_CONDITIONAL_OR_UNKNOWN
lifecycle_status:
confidence:
method_refs: []
supporting_evidence: []
contradicting_evidence: []
evidence_period:
falsification_condition:
alternative_explanations: []
related_causes: []
contribution_or_weight:
scope_and_context:
assumption_refs: []
risk_refs: []
limitations: []
owner:
reviewed_by: []
decision_impact: []
status:
reopen_triggers: []
~~~

`ROOT_CAUSE` is used only when evidence supports that strength of claim. `PRIMARY_SUPPORTED_CAUSE` is preferred when discovery evidence identifies the most useful supported explanation without false finality.

## 8.5 Decisions, Outputs, and Traceability

Required decisions cover hypothesis status, relationship type, evidence sufficiency, primary / contributing cause treatment, unresolved risk, falsification need, and G1 disposition.

~~~text
DISC-005 Problem + Current-State / Data / Observation Evidence
→ DISC-006 Hypothesis and Alternatives
→ Supported / Validated / Rejected / Unresolved Disposition
→ DISC-002 Finding + DISC-009 Validation
→ Risk / Outcome / Scope / Downstream Decision Impact
~~~

Outputs are cause and hypothesis records, competing explanations, method and evidence links, uncertainty and limitation statements, risks, validation needs, and downstream causal assumptions.

## 8.6 Verification, Exit, and Reopen

Verification confirms evidence addresses the stated relationship, method and period are known, correlation is not presented as causation, alternatives are considered, confidence matches support, and unresolved cause risk remains visible.

DISC-006 is complete for G1 when every primary problem has a supported cause or explicit unresolved-cause disposition with owner, risk, evidence need, and safe downstream route. Reopen on new data, contradiction, falsification, incident, process change, cause rejection, problem redefinition, or downstream evidence that the causal model failed.

## 8.7 Artifact-Specific Validation Rules

~~~text
DISC6-CVAL-001  Every cause or hypothesis links exact problems, scope, method, evidence, and owner.
DISC6-CVAL-002  Identified, hypothesized, supported, validated, rejected, and unresolved states remain distinct.
DISC6-CVAL-003  Correlation, temporal sequence, stakeholder belief, and AI plausibility never prove causation.
DISC6-CVAL-004  ROOT_CAUSE requires evidence proportionate to the strength and scope of the claim.
DISC6-CVAL-005  Competing and multi-causal explanations cannot be forced into one artificial cause.
DISC6-CVAL-006  Contradicting evidence, limitations, and falsification conditions remain visible.
DISC6-CVAL-007  AI cannot promote, validate, prioritize, or close a cause without evidence and authority.
DISC6-CVAL-008  G1 allows unresolved cause only with explicit risk, owner, evidence need, and safe route.
~~~

---

# 9. DISC-007 — Outcome & Success Model Contract

~~~yaml
contract_id: CONTRACT-DISC-007
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-007
artifact_name: Outcome & Success Model
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-005, DISC-006, opportunities, and stakeholder evidence
primary_downstream: DISC-002, DISC-008, DISC-009, G1, BUS-001, and later product outcomes
~~~

## 9.1 Purpose

DISC-007 defines the improved business, operational, user, financial, risk, compliance, quality, strategic, or technical conditions sought and the observable signals that would indicate progress or success.

It answers: **What must become better, for whom and why, and what evidence would show that the problem or opportunity materially improved?**

An outcome is not a feature, screen, system, architecture, technology, backlog item, or delivery commitment.

## 9.2 Applicability and Accountabilities

DISC-007 is CORE. Every major problem or supported opportunity has at least one desired outcome. Major outcomes have an observable success direction; not every measure must reach a baselined target in Discovery.

- **Owner:** discovery outcome owner with accountable business / product authority.
- **Affected stakeholders / evidence owners:** validate relevance and observability.
- **Measurement owners:** supply baseline, method, population, period, data quality, and later reporting route.
- **Downstream authorities:** refine and approve business or product outcomes later.
- **AI:** may propose wording and measures; it cannot invent baseline, target, KPI approval, authority, or outcome consensus.

## 9.3 Required Inputs and Questions

Inputs include problems, impacts, supported causes, opportunities, stakeholders, constraints, prior measures, data availability, current baselines, risks, standards evidence, and strategy where authoritative.

Each outcome asks:

1. What improved condition should exist and which problem or opportunity justifies it?
2. Who benefits or bears the result, in what context and time horizon?
3. Is the statement solution-independent and observable?
4. Which business, operational, user, financial, risk, compliance, quality, strategic, or technical type applies?
5. What current baseline exists and with what source, method, scope, period, and quality?
6. What success signal or proposed measure could indicate improvement?
7. Is metric maturity `M0 UNKNOWN` through `M4 BASELINED` honest?
8. Which tradeoffs, guardrails, unintended harms, constraints, and dependencies apply?

## 9.4 Minimum Outcome and Signal Record

~~~yaml
outcome_id:
statement:
outcome_types: []
problem_refs: []
opportunity_refs: []
beneficiaries_and_affected_parties: []
scope_and_context:
priority:
rationale:
success_signals: []
metric_maturity: M0_TO_M4
current_baseline:
  value:
  source_ref:
  method:
  scope:
  period:
proposed_target:
measurement_owner:
measurement_method:
guardrails: []
tradeoffs: []
constraints: []
dependencies: []
risks: []
source_refs: []
confidence:
approval_status:
status:
reviewed_by: []
reopen_triggers: []
~~~

## 9.5 Decisions, Outputs, and Traceability

Required decisions cover desired outcome identity, problem / opportunity linkage, priority, observable signal, metric maturity, baseline availability, proposed measure status, guardrails, owner, and G1 disposition.

~~~text
Problem / Impact / Opportunity
→ DISC-007 Desired Outcome
→ Success Signal / Proposed Measure / Baseline
→ DISC-002 Findings + DISC-009 Validation
→ G1 → Business Outcome / Product Outcome Refinement
→ Later Live Measurement and Realized Outcome
~~~

Outputs are outcome identities, success signals, measurement maturity, baseline and data gaps, proposed measures, guardrails, tradeoffs, and downstream measurement obligations.

## 9.6 Verification, Exit, and Reopen

Verification confirms every major outcome links to a problem or opportunity, avoids solution wording, can be observed, states metric maturity honestly, does not invent baseline or target, and identifies measurement limitations and owner.

DISC-007 is complete for G1 when desired improvements are explicit, major outcomes have success direction, unknown or proposed measures are labelled, and relevant tradeoffs / guardrails are visible. Reopen on problem or opportunity change, stakeholder impact, measurement evidence, baseline correction, strategy change, adverse effect, or downstream outcome refinement.

## 9.7 Artifact-Specific Validation Rules

~~~text
DISC7-CVAL-001  Every outcome links to a supported problem or opportunity and affected context.
DISC7-CVAL-002  Outcome, solution, feature, output, activity, and delivery commitment remain distinct.
DISC7-CVAL-003  Every major outcome has an observable success direction or explicit measurement gap.
DISC7-CVAL-004  Metric maturity, baseline, target, approval, and verification statuses remain separate.
DISC7-CVAL-005  AI-proposed measures remain proposed until authorized and evidence-backed.
DISC7-CVAL-006  Guardrails, tradeoffs, unintended harms, and affected populations remain visible.
DISC7-CVAL-007  Baseline and target values require exact source, method, scope, period, and owner.
DISC7-CVAL-008  Discovery outcomes cannot silently become approved business or product commitments.
~~~

---

# 10. DISC-008 — Scope Hypothesis Contract

~~~yaml
contract_id: CONTRACT-DISC-008
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DISC-008
artifact_name: Scope Hypothesis
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-003 through DISC-007, constraints, dependencies, opportunities, and evidence
primary_downstream: DISC-002, DISC-009, G1, BUS-001, and later product-scope decisions
~~~

## 10.1 Purpose

DISC-008 records the evidence-supported preliminary boundary of where the intervention and next-phase analysis appear likely to focus, including likely in-scope, likely out-of-scope, uncertain, and scope-expansion candidates.

It answers: **Given the validated problems, outcomes, opportunities, constraints, and dependencies, where should the next phase investigate or define responsibility—and what remains uncertain?**

It is not approved business scope, product boundary, module list, feature list, MVP, screen set, requirements baseline, commercial authorization, or implementation scope.

## 10.2 Applicability and Accountabilities

DISC-008 is CORE for G1. A non-software or no-product-change route still has a scope hypothesis describing the intervention and excluded product work.

- **Owner:** discovery lead or scope-hypothesis owner.
- **Evidence / object owners:** maintain problem, outcome, opportunity, constraint, dependency, risk, and stakeholder links.
- **G1 authority:** accepts the hypothesis only as an input to the downstream route.
- **Downstream scope authorities:** decide business and product scope in later phases.
- **AI:** may propose inclusions, exclusions, uncertainty, and conflicts; it cannot approve scope, commercial expansion, feature inclusion, or product responsibility.

## 10.3 Required Inputs and Questions

Inputs include stakeholder / current-state / problem / cause / outcome objects, opportunities, requested ideas, constraints, dependencies, risks, conflicts, commercial boundary, standards evidence, and solution-contamination flags.

Each scope item asks:

1. Is it likely in scope, likely out, uncertain, an expansion candidate, or a non-product intervention?
2. Which problem, outcome, opportunity, constraint, dependency, risk, or standard context justifies the disposition?
3. Is the item a domain / intervention boundary or a disguised feature, module, screen, technology, or preferred solution?
4. Which people, processes, systems, data, markets, platforms, documents, third parties, or lifecycle contexts are implicated?
5. What evidence and confidence support the hypothesis?
6. What dependency, conflict, authority, or commercial gap remains?
7. Which later phase and authority must decide it?
8. What change would reopen or expand the boundary?

## 10.4 Minimum Scope-Hypothesis Record

~~~yaml
scope_hypothesis_id:
project_id:
scope_context:
likely_in_scope: []
likely_out_of_scope: []
uncertain: []
scope_expansion_candidates: []
non_product_interventions: []
item_rationales:
  problem_refs: []
  outcome_refs: []
  opportunity_refs: []
  constraint_refs: []
  dependency_refs: []
  risk_refs: []
stakeholders_and_contexts: []
commercial_scope_ref:
methodology_need_delta:
gov_009_entries: []
source_refs: []
confidence:
conflicts: []
assumptions: []
decision_gaps: []
downstream_route:
decision_authority:
approval_status: HYPOTHESIS_NOT_PRODUCT_SCOPE_APPROVAL
status:
supersedes:
superseded_by:
reopen_triggers: []
~~~

## 10.5 Decisions, Outputs, and Traceability

Required decisions cover hypothesis categories, rationale sufficiency, uncertainty, expansion treatment, methodology / commercial separation, downstream route, owner, and G1 readiness.

~~~text
Problem / Outcome / Opportunity / Constraint / Dependency
→ DISC-008 Scope Hypothesis Item
→ DISC-002 Findings + DISC-009 Validation
→ G1
→ BUS-001 Business Boundary / PROD-002 Product Scope Decision
~~~

Outputs are explicit likely-in, likely-out, uncertain, expansion, and non-product items; rationale; conflicts; decision gaps; commercial delta; and later scope-decision routes.

## 10.6 Verification, Exit, and Reopen

Verification confirms every item has rationale and trace, solution ideas are not silently included, uncertainty is visible, commercial limits do not hide methodology need, and the artifact cannot be misread as final scope approval.

DISC-008 is complete for G1 when the next analysis boundary is understandable, every material item has evidence-linked rationale and confidence, and uncertain / expansion items have owners and decision routes. Reopen on problem, outcome, opportunity, constraint, dependency, risk, standards, commercial, authority, evidence, or later scope-decision change.

## 10.7 Artifact-Specific Validation Rules

~~~text
DISC8-CVAL-001  Every scope-hypothesis item links to problem, outcome, opportunity, constraint, dependency, or risk rationale.
DISC8-CVAL-002  Likely in, likely out, uncertain, expansion, and non-product dispositions remain distinct.
DISC8-CVAL-003  Solution idea, feature, module, screen, technology, or competitor capability cannot enter scope automatically.
DISC8-CVAL-004  Discovery scope, scope hypothesis, business scope, product scope, MVP, and commercial scope remain distinct.
DISC8-CVAL-005  Uncertain and expansion items have owner, evidence need, and decision route.
DISC8-CVAL-006  Commercial boundary cannot hide methodology need or authorize extra delivery.
DISC8-CVAL-007  AI cannot approve product scope, commercial expansion, feature inclusion, or responsibility.
DISC8-CVAL-008  G1 scope-hypothesis acceptance remains provisional and reopens on material upstream change.
~~~

---

# 11. Family Bundle Completion Contract

This Phase 01 family bundle is complete at Working Draft level when:

1. DISC-001 and DISC-003 through DISC-008 each retain stable artifact and contract IDs.
2. All seven inherit `CORE-ARTIFACT-STANDARD@0.2.0`.
3. Each section contains purpose, inputs, questions, decisions, outputs, applicability, traceability, verification, validation, exit, and reopen rules.
4. The sections preserve distinct current-state, symptom, problem, impact, cause, outcome, opportunity, scope, evidence, and solution meanings.
5. DISC-002 remains the consolidated findings source; DISC-009 remains validation / G1 evidence.
6. P1 / P2 / P3 packaging and discovery breadth remain separate and consistent with the Master Artifact Catalog.
7. GOV-003 through GOV-009 receive only their canonical decisions, risks, assumptions, questions, changes, relationships, and applicability evidence.
8. G1 and downstream routes can reproduce exact-scope views of all applicable discovery objects and gaps.

Changing one family section does not silently change another. A bundle-version change lists the affected logical contracts, evidence, DISC-002, DISC-009, G1, and downstream impact.
