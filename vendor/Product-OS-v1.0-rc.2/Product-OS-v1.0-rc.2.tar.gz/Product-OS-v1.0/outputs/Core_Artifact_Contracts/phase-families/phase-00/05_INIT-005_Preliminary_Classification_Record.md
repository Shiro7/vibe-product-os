# Core Artifact Contract — INIT-005 Preliminary Classification Record

~~~yaml
contract_id: CONTRACT-INIT-005
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: INIT-005
artifact_name: Preliminary Classification Record
owning_phase: Phase 00 - Initialization and Intake
gate_or_baseline: G0 - Intake Ready / ICB - Initial Context Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: INIT-001 through INIT-004, applicable INIT-006, and GOV-009 trigger evidence
primary_downstream: INIT-007, G0, profile packaging, risk review, and downstream methodology routing
semantic_source: ../../../Phase_00_Initialization_and_Intake_v1.1.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

INIT-005 records the provisional Phase 00 classification of product state, Product OS delivery profile, risk class, engagement scope when applicable, and recommended downstream route. It preserves the evidence, rationale, confidence, ambiguity, signals, owner, review requirement, and conditions behind each classification.

It answers: **What kind of product context has entered Product OS, what delivery and assurance depth does it preliminarily need, what risk signals exist, and which route should begin next?**

Classification is provisional. It is not approved scope, a commercial commitment, a final risk assessment, a standards-applicability approval, or a substitute for the governing [Classification Rules](../../../Classification_Rules.md).

---

# 2. Scope and Applicability

INIT-005 is CORE and required for G0. At minimum it records:

~~~text
Primary Product State
P-profile Candidate
Risk-class Candidate
Downstream Route
~~~

Engagement scope activates only for consulting or client-engagement contexts. Secondary product states and domain-level profile escalations are recorded when one label would hide material context.

---

# 3. Classification Dimensions

Product state:

~~~text
S0  EARLY_IDEA
S1  NEW_PRODUCT
S2  OPERATING_BUSINESS_TRANSFORMATION
S3  EXISTING_PRODUCT
S4  IMPLEMENTATION_IN_PROGRESS
S5  TROUBLED_OR_RECOVERY
S6  OPERATIONAL_EVOLUTION
~~~

Delivery profile:

~~~text
P1  LEAN
P2  STANDARD
P3  COMPREHENSIVE
~~~

Preliminary risk class:

~~~text
R1  LOW
R2  MODERATE
R3  HIGH
R4  CRITICAL
~~~

Conditional engagement scope:

~~~text
E1  Consultation and Direction
E2  Discovery and Business Analysis
E3  Product and Solution Blueprint
E4  UX Architecture and UI/UX Design
E5  Technical Feasibility and Pre-Implementation
E6  Delivery Advisory and Technical Leadership
~~~

The engagement purchased and the lifecycle depth the product needs remain separate.

---

# 4. Accountabilities

- **Owner:** product analyst, intake owner, or methodology owner accountable for classification quality.
- **Information owners:** provide source-backed product-state, business, technical, operational, risk, and engagement context.
- **Risk / specialist reviewers:** review R3 / R4 signals and activated security, privacy, accessibility, legal, compliance, data, safety, reliability, or continuity concerns.
- **G0 authority:** accepts, conditions, holds, or rejects the route using the classification as evidence.
- **Commercial authority:** owns engagement commitments; it cannot redefine methodology need silently.
- **AI:** may recommend classification, expose ambiguity, and identify signals; it cannot approve scope, risk acceptance, commercial terms, or GOV-009 applicability.

---

# 5. Required Inputs

1. INIT-001 project / product identity, entry reason, current context, need, outcome, and constraints.
2. INIT-002 sources and authority / reliability context.
3. INIT-003 atomic items, contradictions, risk signals, and standards triggers.
4. INIT-004 authority snapshot.
5. INIT-006 existing assets when applicable.
6. GOV-004 initial risk entries and GOV-009 preliminary applicability entries.
7. Existing implementation, operational, recovery, commercial, or lifecycle evidence.

---

# 6. Required Questions

1. Which primary state best determines the safe entry workflow, and what secondary context must remain visible?
2. What direct source evidence supports each state classification?
3. What artifact depth, ownership, assurance, and change control are currently indicated: P1, P2, or P3?
4. Which domains require a higher profile than the project default?
5. Which risk signals indicate R1 through R4, and what is still unknown?
6. Is immediate containment, incident, legal, security, safety, or recovery routing required before normal discovery?
7. Is engagement scope applicable, and are client-selected and recommended scopes different?
8. What route follows G0 for the product state and risk context?
9. Which classification is low-confidence or pending review?
10. What evidence or event will confirm, change, or supersede the preliminary classification?

---

# 7. Required Decisions

- primary product state and any secondary context;
- preliminary P-profile and domain-level overrides;
- preliminary risk class and immediate escalation / containment route;
- conditional client-selected and recommended engagement scopes;
- confidence, evidence sufficiency, review requirements, and due event;
- downstream methodology route and alternate route;
- G0 blocker or condition caused by unresolved classification;
- planned reclassification point and change route.

---

# 8. Minimum Classification Record

~~~yaml
classification_id:
project_id:
scope:
classified_at:
owner:
product_state:
  primary:
  secondary_context: []
  confidence:
  rationale: []
  source_refs: []
delivery_profile:
  preliminary:
  domain_overrides: []
  confidence:
  rationale: []
  review_required:
risk_class:
  preliminary:
  signals: []
  unknowns: []
  immediate_actions: []
  confidence:
  rationale: []
  reviewer:
engagement_scope:
  applicable:
  client_selected:
  preliminary_recommended:
  gap_or_condition:
  authority:
standards_triggers: []
gov_009_entries: []
downstream_route:
alternate_routes: []
blocking_questions: []
conditions: []
decision_status:
approved_or_accepted_by: []
review_due:
supersedes:
superseded_by:
affected_artifacts: []
reopen_triggers: []
~~~

Each dimension retains its own rationale and confidence. One overall confidence value cannot hide weak evidence in a critical dimension.

---

# 9. Classification Boundaries

~~~text
Product State      → determines entry context and likely route
Delivery Profile   → controls packaging, ownership, review, and assurance depth
Risk Class         → controls scrutiny, escalation, and safeguards
Engagement Scope   → describes contracted or recommended service boundary when relevant
GOV-009            → owns standards / profile applicability, not INIT-005
GOV-004            → owns material risk records and residual-risk decisions
~~~

P1 does not weaken applicable security, privacy, accessibility, legal, regulatory, safety, reliability, audit, or evidence obligations. E1–E6 cannot be used to misrepresent what the product lifecycle requires.

---

# 10. Traceability and G0 Use

~~~text
Sources + Atomic Items + Authority + Existing Assets + Risk / Standard Triggers
→ INIT-005 Preliminary Classification
→ G0 Classification and Route Check
→ INIT-007 Handoff
→ Phase 01 or Explicit Alternate / Containment Route
→ Later Reclassification and GOV-007 Change
~~~

G0 requires state, profile candidate, and risk candidate to be explicit. Final classification-engine scores are not required. A low-confidence classification may pass only when the route remains safe and the review condition is explicit.

---

# 11. Profile Behavior

- **P1:** the record may be one section of INIT-000, but all classification dimensions, rationale, confidence, route, and review condition remain.
- **P2:** state, profile, risk, engagement, evidence, and routes are independently reviewable fields or modules.
- **P3:** formal scoring where adopted, specialist and independent review, domain overrides, signatures / attestations where applicable, and complete classification history strengthen.

The artifact describes the preliminary profile; its own physical packaging may still be composite in P1.

---

# 12. Verification and Evidence

Verification confirms each classification traces to exact sources and signals; primary and secondary states are coherent; profile does not remove obligations; risk class is not lowered by missing evidence; engagement and methodology need remain separate; authority matches the classification dimension; the route is safe; and ambiguity or unknown state remains visible.

---

# 13. Exit Criteria

INIT-005 is complete for G0 when primary state, preliminary delivery profile, risk candidate, route, rationale, confidence, sources, review owner, material domain override, standards triggers, and blocking / conditional unknowns are explicit. Engagement classification is complete only when applicable; otherwise it records governed N/A.

---

# 14. Reopen Conditions

Reopen on new source, corrected fact, product-state change, existing asset discovery, implementation or production evidence, incident or recovery event, risk or standard trigger, market / platform / data / contract change, authority change, commercial-scope change, G0 condition failure, or downstream evidence that the route or profile is unsuitable.

---

# 15. Artifact-Specific Validation Rules

~~~text
INIT5-CVAL-001  State, profile, risk, engagement, and route classifications retain separate rationale and confidence.
INIT5-CVAL-002  Primary product state has evidence; secondary context remains visible where material.
INIT5-CVAL-003  Preliminary classification cannot be represented as final scope, risk acceptance, or standards approval.
INIT5-CVAL-004  Delivery profile changes packaging and assurance depth, not applicable obligations.
INIT5-CVAL-005  Missing evidence cannot silently lower risk class or remove a domain override.
INIT5-CVAL-006  Commercial engagement scope cannot redefine lifecycle need without explicit governed decision.
INIT5-CVAL-007  AI may recommend but cannot approve classification, scope, risk acceptance, or applicability.
INIT5-CVAL-008  G0 route is invalid when classification ambiguity prevents safe downstream selection.
~~~
