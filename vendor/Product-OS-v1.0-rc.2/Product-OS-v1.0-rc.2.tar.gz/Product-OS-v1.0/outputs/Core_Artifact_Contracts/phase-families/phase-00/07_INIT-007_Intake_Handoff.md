# Core Artifact Contract — INIT-007 Intake Handoff

~~~yaml
contract_id: CONTRACT-INIT-007
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: INIT-007
artifact_name: Intake Handoff
owning_phase: Phase 00 - Initialization and Intake
gate_or_baseline: G0 - Intake Ready / ICB - Initial Context Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: INIT-001 through INIT-006, GOV-003 through GOV-009, and G0 evidence
primary_downstream: Phase 01 or an explicitly selected alternate route
semantic_source: ../../../Phase_00_Initialization_and_Intake_v1.1.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

INIT-007 is the machine-oriented, receiver-acknowledged handoff of the Initial Context Baseline from Phase 00 into Phase 01 or an explicitly selected alternate, containment, recovery, or operational route. It binds exact source and artifact identities, known truth, provisional truth, classification, open items, conditions, risks, standards triggers, gate outcome, and prohibited downstream assumptions.

It answers: **What exact intake context is being transferred, what is known or still provisional, which route is authorized to begin, under what conditions, and what must the receiver not assume?**

INIT-007 is not proof that discovery is complete, scope is approved, requirements are baselined, architecture is selected, or implementation may begin.

---

# 2. Scope and Applicability

INIT-007 is CORE for every Product OS entry that proceeds beyond Phase 00. One versioned handoff may cover the complete ICB or a bounded scope when separate routes are necessary.

`PASS` and `PASS_WITH_CONDITIONS` may activate a downstream handoff. `HOLD` and `REJECT` require a governed disposition record but do not masquerade as an authorized normal-phase handoff. Emergency or critical risk routes preserve minimum identity, source, authority, condition, and acknowledgement even when expedited.

---

# 3. Accountabilities

- **Owner / sender:** Phase 00 intake owner accountable for handoff integrity.
- **G0 authority:** records the gate outcome and accepted conditions for the exact ICB scope.
- **Receiver:** Phase 01 owner or alternate-route owner that acknowledges scope, gaps, conditions, and prohibited assumptions.
- **Artifact / register owners:** ensure linked identities, statuses, and versions are current.
- **Risk / standards / specialist owners:** acknowledge critical routes and applicable conditions.
- **AI:** may assemble, validate, compare, and route the handoff; it cannot invent G0 outcome, receiver acknowledgement, authority, approval, or downstream completion.

---

# 4. Required Inputs

1. INIT-001 Product / Project Brief and exact version.
2. INIT-002 source baseline and material source dispositions.
3. INIT-003 atomic-item disposition, contradictions, and canonical routing.
4. INIT-004 authority snapshot and unresolved authority conditions.
5. INIT-005 preliminary classification and downstream route.
6. Applicable INIT-006 existing-asset inventory or governed N/A.
7. Current GOV-003 decisions, GOV-004 risks, GOV-005 assumptions, GOV-006 questions, GOV-007 changes, GOV-008 traceability, and GOV-009 entries relevant to the handoff.
8. G0 check results, outcome, conditions, evidence, authority, and evaluation timestamp.

---

# 5. Required Questions

1. Which exact project / product and ICB version are being transferred?
2. Which source, artifact, register, and external identities are included, excluded, missing, stale, superseded, or N/A?
3. What confirmed facts, stated facts, assumptions, requested ideas, captured requirements, decisions, risks, questions, constraints, dependencies, and contradictions are active?
4. What preliminary state, profile, risk class, standards triggers, and route apply?
5. Which G0 checks passed, are conditional, failed, or remain not applicable?
6. Are blocking intake questions zero for the authorized route?
7. Which conditions, owners, due events, evidence expectations, and escalation routes remain?
8. What must the receiver validate rather than inherit as approved truth?
9. Is the alternate or emergency route within current authority and clearly bounded?
10. Has the named receiver acknowledged the exact handoff and prohibited assumptions?

---

# 6. Required Decisions

- ICB ID, version, exact included / excluded scope, and reproducible artifact set;
- G0 outcome and gate-authority reference;
- primary and alternate downstream route;
- sender, receiver, acknowledgement, and effective time;
- status and disposition of sources, facts, assumptions, decisions, questions, risks, constraints, dependencies, and contradictions;
- preliminary classification and standards-trigger handoff;
- conditions, due events, evidence, escalation, and stop rules;
- prohibited downstream assumptions;
- change, correction, and reopen route.

---

# 7. Minimum Handoff Record

~~~yaml
handoff_id:
project_id:
icb_id:
icb_version:
scope:
included_scope: []
excluded_scope: []
sender:
receiver:
created_at:
effective_at:
gate:
  gate_id: G0
  outcome:
  decision_record:
  evaluated_at:
  authority:
  check_results: []
canonical_artifacts:
  init_001:
  init_002:
  init_003:
  init_004:
  init_005:
  init_006:
source_baseline: []
confirmed_or_stated_facts: []
assumptions: []
requested_ideas: []
captured_unbaselined_requirements: []
decisions: []
risks: []
open_questions: []
constraints: []
dependencies: []
contradictions: []
classification_ref:
standards_triggers: []
gov_009_entries: []
conditions: []
exceptions: []
missing_or_stale_items: []
next_route:
alternate_route:
next_phase_objectives: []
required_follow_up: []
evidence_expectations: []
prohibited_assumptions: []
change_route:
reopen_triggers: []
receiver_acknowledgement:
  status:
  acknowledged_by:
  acknowledged_at:
  comments: []
~~~

---

# 8. G0 and Handoff Boundary

G0 asks whether enough trusted context exists to begin the correct route. It does not approve the solution, product scope, requirements, design, architecture, implementation, or release.

Canonical G0 outcomes are:

~~~text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
~~~

`PASS_WITH_CONDITIONS` lists every condition, owner, due event, impact, evidence expectation, and escalation rule. A Discovery question is not a G0 blocker unless its answer could change the entry path, project identity, product state, immediate risk handling, legal ability to proceed, responsible authority, source interpretation, or G0 decision.

---

# 9. Prohibited Downstream Assumptions

The receiver must not infer that:

- a requested idea is an approved feature or requirement;
- a captured requirement is validated or baselined;
- a stated fact is independently verified;
- preliminary state, profile, risk, or engagement classification is final;
- a source is current or authoritative merely because it exists;
- an existing asset is adopted, secure, deployed, production, or reusable;
- a GOV-009 trigger is an approved applicability or compliance claim;
- absence means NOT_APPLICABLE;
- G0 means the problem, scope, or solution is understood;
- the handoff authorizes implementation, access, release, or risk acceptance.

---

# 10. Traceability and Routing

~~~text
INIT-001 Brief
+ INIT-002 Sources
+ INIT-003 Atomic Items
+ INIT-004 Authority
+ INIT-005 Classification
+ applicable INIT-006 Assets
+ GOV-003 through GOV-009 Context
→ ICB / G0 Decision
→ INIT-007 Exact Handoff
→ Phase 01 or Authorized Alternate Route
→ Receiver Acknowledgement
→ Changed-Truth Route through GOV-007 and GOV-008
~~~

The handoff references canonical identities and statuses. It does not copy full register content or create a competing baseline.

---

# 11. Profile Behavior

- **P1:** INIT-007 may be the final governed section of INIT-000; exact scope, versions, statuses, conditions, route, and acknowledgement remain.
- **P2:** the handoff is an independently reviewable, structured artifact with linked register views.
- **P3:** formal gate evidence, independent review, signed / attested acknowledgement where applicable, access classification, retention, immutable history, and automated consistency checks strengthen.

---

# 12. Verification and Evidence

Verification confirms all canonical IDs and versions resolve; G0 evidence covers the 15 check domains; blocking intake questions are zero for the selected route; conditions are owned and bounded; classification and GOV-009 states are honestly provisional; missing, stale, conflicting, and N/A dispositions are explicit; the receiver exists and acknowledges; and the handoff makes no unauthorized downstream claim.

---

# 13. Exit Criteria

INIT-007 is complete only when the exact ICB and artifact set, G0 outcome, source baseline, information-state dispositions, preliminary classification, standards triggers, risks, conditions, open non-blocking questions, missing / stale items, next route, prohibited assumptions, evidence expectations, change route, sender, receiver, and acknowledgement are recorded.

A handoff with `PASS_WITH_CONDITIONS` remains valid only while its conditions, owners, due events, and escalation rules remain active. `HOLD` requires blocker resolution before a new or revised handoff.

---

# 14. Reopen Conditions

Reopen on source correction, material contradiction, authority change, classification change, G0 condition failure, new critical risk, GOV-009 trigger or decision change, existing-asset discovery, receiver rejection, route change, baseline staleness, evidence invalidation, or discovery of any intake omission that makes the selected path unsafe.

---

# 15. Artifact-Specific Validation Rules

~~~text
INIT7-CVAL-001  Handoff binds exact project, ICB, artifact versions, G0 outcome, sender, receiver, and route.
INIT7-CVAL-002  PASS or PASS_WITH_CONDITIONS never implies discovery, scope, requirements, architecture, or implementation approval.
INIT7-CVAL-003  Every condition has owner, due event, impact, evidence, and escalation route.
INIT7-CVAL-004  Blocking intake questions equal zero for the authorized downstream route.
INIT7-CVAL-005  Missing, stale, conflicting, superseded, provisional, and N/A states remain explicit.
INIT7-CVAL-006  Receiver acknowledgement cannot be invented or inferred from artifact delivery.
INIT7-CVAL-007  The handoff references canonical registers and does not create competing truth.
INIT7-CVAL-008  Material source, authority, classification, risk, applicability, or route change reopens the ICB handoff.
~~~
