# Core Artifact Contract — ENG-016 Engineering Standards and Review Contract

~~~yaml
contract_id: CONTRACT-ENG-016
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: ENG-016
artifact_name: Engineering Standards and Review Contract
owning_phase: Phase 08 - Engineering Readiness
gate_or_baseline: G5B - Engineering Readiness Baseline / ERBL - Engineering Readiness Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-001, GOV-009, ARC-029 / ARC-030 / ARC-033, repository and toolchain evidence, security / privacy / accessibility / reliability obligations, and organizational standards
primary_downstream: ENG-017 through ENG-031, work items, reviews, CI/CD checks, implementation, verification, exceptions, and evidence
semantic_source: ../../../Phase_08_Engineering_Readiness.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

ENG-016 activates the exact Engineering standards, review roles, required checks, enforcement points, evidence, and exception paths that govern the named G5B scope. It converts high-level constitutional, architecture, security, privacy, accessibility, testing, audit, dependency, migration, and operational rules into executable implementation controls.

It is not a generic style guide or a copied checklist. Each rule identifies authority, version, applicability, targets, work / tool enforcement, reviewers, evidence, failure behavior, exception authority, and change impact.

---

# 2. Scope and Applicability

ENG-016 is CORE whenever Phase 08 is active. Rules may vary by repository, module, language, framework, platform, data class, risk domain, environment, artifact type, or change type, but overlaps and precedence must be explicit.

An individual rule may be NOT_APPLICABLE only after trigger assessment with exact scope, reason, owner, authority, date, evidence, downstream effect, and reopen condition. A project cannot mark the artifact itself NOT_APPLICABLE merely because conventions exist in code or CI.

---

# 3. Accountabilities

- **Owner:** Engineering standards owner accountable for scope, versions, conflicts, and enforceability.
- **Repository / module owners:** apply rules to exact targets and maintain enforcement / review routes.
- **Security, privacy, data, accessibility, reliability, platform, QA, and operations specialists:** own their authoritative rule interpretations and high-risk reviews.
- **Reviewers:** perform specified checks within competence and record evidence / limitations.
- **Exception authority:** may approve bounded exceptions with residual risk, expiry, controls, and return plan.
- **G5B authority:** confirms standards and review controls are executable for the scope.
- **AI:** may compare sources, detect gaps, propose checks, and summarize findings; it cannot invent authority, claim compliance, approve exceptions, or replace accountable review.

---

# 4. Required Inputs

1. Active GOV-001 and GOV-009 versions and propagated Engineering obligations.
2. ARC-029 decisions, ARC-030 control mappings, ARC-033 implementation / fitness obligations.
3. Canonical repositories, modules, languages, frameworks, toolchains, environments, data classes, platforms, and delivery paths.
4. Organizational / legal / contractual / industry standards and authoritative versions.
5. Existing code, review, test, logging, audit, dependency, migration, documentation, and operational conventions with current evidence.
6. Known conflicts, legacy constraints, exceptions, deviations, risks, and automation gaps.

---

# 5. Required Questions

1. Which exact standards / rules apply to which Engineering targets and change types?
2. What is each rule's authority, version, effective scope, and precedence?
3. How is it implemented, automatically checked, manually reviewed, verified, and evidenced?
4. Which reviewers / approvers are required and what competence / independence is needed?
5. What happens when a check cannot run, fails, is overridden, or conflicts with another rule?
6. Which code, module, security, privacy, accessibility, test, log / audit, dependency, migration, documentation, and operational rules are mandatory?
7. What exception path, temporary controls, residual risk, expiry, and return plan apply?
8. Which rules enter DoR, DoD, CI/CD, review templates, verification, and ENG-031?
9. Which rules are currently enforced versus planned work?
10. What changes reopen applicability or review design?

---

# 6. Minimum Engineering Rule Record

~~~yaml
engineering_rule_id:
title:
authority_source_and_version:
gov_001_gov_009_arc_and_requirement_refs: []
applicable_repositories_modules_languages_platforms_data_and_change_types: []
rule_statement:
rationale_and_risk:
required_implementation_behavior:
automated_enforcement_or_check:
manual_review_requirement:
reviewer_roles_and_independence: []
failure_and_blocking_behavior:
evidence_required:
dor_dod_ci_cd_verification_and_handoff_links: []
exception_authority_and_process:
active_exceptions: []
owner:
status:
effective_from:
supersedes:
reopen_triggers: []
~~~

---

# 7. Required Rule Domains

Activated domains include:

- repository, module, naming, dependency direction, generated code, and ownership;
- secure coding, secrets, data protection, authorization, tenancy, input / output, and supply chain;
- privacy, minimization, logging / audit, retention, evidence, and sensitive-data handling;
- accessibility, localization / RTL, content, design parity, and generated-output implementation;
- tests, contract checks, migration safety, compatibility, rollback, performance, resilience, and observability;
- documentation, change / review, commit / branch / artifact identity, provenance, deployment, and operational handoff.

Rules may reference authoritative external standards, but the record must state the local implementation consequence rather than copy an entire source.

---

# 8. Status and Exception Separation

Rule applicability:

~~~text
APPLICABLE
CONDITIONALLY_APPLICABLE
NOT_APPLICABLE
UNDER_REVIEW
~~~

Implementation / enforcement status:

~~~text
PLANNED
PARTIALLY_ENFORCED
ENFORCED
VERIFIED
DEGRADED
STALE
~~~

Exception status:

~~~text
PROPOSED
UNDER_REVIEW
APPROVED_ACTIVE
EXPIRED
REVOKED
CLOSED
~~~

These dimensions remain separate. An applicable rule can have unfinished enforcement. A green automated check does not prove all semantic obligations. An approved exception does not make the rule NOT_APPLICABLE.

---

# 9. Review and Evidence Contract

Each required review defines subject / revision, reviewer / role, competence / authority, method, required context, criteria, tools, automated inputs, findings, limitations, disposition, evidence, re-review triggers, and downstream effect.

Review approval cannot be inferred from comment absence, merge completion, status-check success, or AI output. High-risk exceptions, controls, migrations, and security / privacy / accessibility decisions require the designated authority.

---

# 10. Traceability and Change Impact

Required paths include:

~~~text
GOV-001 / GOV-009 / ARC / Standard Source
  -> ENG-016 Rule / Check / Reviewer / Exception Path
  -> Slice / Work / Target / DoR / DoD / CI-CD
  -> Implementation Review / Verification / Evidence
  -> ENG-030 G5B Check / ENG-031 Handoff
~~~

Rule or source change triggers applicability review, affected work / DoR / DoD / checks / evidence impact, stale status, notifications, migration / remediation, and baseline / handoff update.

---

# 11. Profile Behavior

| Profile | Required standards behavior |
|---|---|
| Level 1 — Rapid | Compact rule set and review matrix are allowed, but every critical rule has authority, target, check / reviewer, evidence, failure behavior, and exception route. |
| Level 2 — Standard | Modular rule domains, automated and manual controls, reviewer ownership, exception governance, and formal G5B evidence are required. |
| Level 3 — Comprehensive | Segregated review, formal control mapping, independent assurance, provenance, regulated evidence retention, exception monitoring, and cross-repository enforcement are added. |

---

# 12. Evidence and Exit Conditions

Evidence may include authoritative rule versions, repository protections, linters / analyzers, test / scan configuration, review ownership, sample findings / resolutions, CI/CD enforcement, exception decisions, migrations, training / capability evidence, and downstream acknowledgement.

ENG-016 is complete only when applicable rules, versions, precedence, exact targets, implementation work, enforcement / review, evidence, failure behavior, exception authority, active exceptions, and DoR / DoD / handoff links are explicit, executable, and accepted.

---

# 13. Reopen Conditions

Reopen on standard / GOV-009 / architecture / technology / repository / language / platform / data / threat / vulnerability / regulation / dependency / tool / review-capacity / exception / incident / verification finding change.

---

# 14. Validation Rules

~~~text
ENG16-CVAL-001  Every applicable Engineering rule binds exact authority, version, scope, targets, owner, implementation consequence, check / reviewer, and evidence.
ENG16-CVAL-002  Applicability, implementation, enforcement, review, verification, approval, exception, and compliance statuses remain separate.
ENG16-CVAL-003  Code, security, privacy, accessibility, test, logging / audit, dependency, migration, documentation, and operations domains are dispositioned.
ENG16-CVAL-004  Automated controls define tool / rule version, target, trigger, failure behavior, bypass authority, evidence, and limitations.
ENG16-CVAL-005  Manual reviews define subject / revision, competence, method, criteria, findings, evidence, authority, and re-review triggers.
ENG16-CVAL-006  Exceptions are exact, authorized, risk-bound, controlled, time-bound, evidenced, monitored, and linked to return-to-standard work.
ENG16-CVAL-007  Existing conventions, green pipelines, merged code, reviewer silence, or AI output cannot prove rule coverage or compliance.
ENG16-CVAL-008  Source, scope, target, tool, risk, exception, or evidence change propagates to work, DoR / DoD, checks, handoff, and revalidation.
~~~
