# Core Artifact Contract — ENG-017 Definition of Ready and Definition of Done

~~~yaml
contract_id: CONTRACT-ENG-017
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: ENG-017
artifact_name: Definition of Ready and Definition of Done
owning_phase: Phase 08 - Engineering Readiness
gate_or_baseline: G5B - Engineering Readiness Baseline / ERBL - Engineering Readiness Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: ENG-001 through ENG-016, approved upstream baselines, work types, standards, controls, verification, evidence, release, and operations obligations
primary_downstream: ENG-018 through ENG-031, G5B, Phase 09 start / completion controls, G6A candidate readiness, and verification handoff
semantic_source: ../../../Phase_08_Engineering_Readiness.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

ENG-017 defines the universal, type-specific, and conditional criteria that decide whether a slice / enabler / work item may start implementation and what must be true before Phase 09 can call it done. It binds criteria to source, applicability, method, evidence, authority, exception / condition rules, automation, and change behavior.

Definition of Ready protects implementation from material invention and hidden blockers. Definition of Done protects downstream phases from code-complete claims that omit review, tests, controls, parity, migration, observability, evidence, documentation, traceability, or operational consequences.

---

# 2. Scope and Applicability

ENG-017 is CORE for every implementation item entering ENG-031. Universal criteria apply to all items; type-specific criteria apply to slices, enablers, APIs / events / integrations, data / migrations, UI / design, identity / security / privacy / audit, platform, configuration, infrastructure, CI/CD, observability, operations, and other activated types.

Conditional readiness is allowed only for non-blocking, exact, owned, authorized, time-bound gaps with compensating controls, evidence, restrictions, acknowledgement, and failure / reopen behavior. A critical unknown or material implementation decision cannot be waived into readiness.

---

# 3. Accountabilities

- **Owner:** Engineering Readiness / standards owner maintaining criteria and applicability.
- **Item owner:** supplies evidence and truthful readiness / completion status.
- **Repository / module / platform owners:** confirm exact targets, access, toolchain, environments, and review paths.
- **Specialist owners:** confirm security, privacy, data, accessibility, reliability, migration, verification, evidence, and operational criteria.
- **Condition / exception authority:** approves only within delegated scope and cannot waive upstream authority.
- **G5B authority:** confirms included items satisfy applicable DoR and carry executable DoD.
- **Phase 09 owner:** applies DoD to actual implementation and reports deviations.
- **AI:** may evaluate rule completeness and collect evidence references; it cannot mark ready / done without valid evidence or approve conditions.

---

# 4. Required Inputs

1. ENG-001 scope / profile and ENG-002 through ENG-015 readiness artifacts.
2. ENG-016 applicable standards, checks, reviewers, exceptions, and evidence.
3. Approved requirements, experience, design, architecture, GOV-009, and ARC-033 obligations.
4. Slice / enabler / work types, targets, dependencies, acceptance, verification, evidence, migration, rollout, and operational obligations.
5. Current target / environment / access / toolchain / test-data evidence.
6. Questions, blockers, assumptions, risks, conditions, exceptions, deviations, and debt.

---

# 5. Required Questions

1. Which universal DoR criteria apply to every item?
2. Which type-specific and conditional criteria apply to this exact item / context?
3. What evidence and authority prove each criterion?
4. Which gap is blocking versus eligible for controlled conditional readiness?
5. Does the item have exact upstream reason, outcome, target, owner, dependencies, contracts, acceptance, verification, evidence, and operational obligations?
6. What code, review, tests, checks, parity, controls, migrations, documentation, observability, traceability, and evidence define Done?
7. Which criteria can be automated, and what are automation limitations / bypass rules?
8. What changes invalidate the DoR result or alter the DoD contract?
9. Who decides READY, READY_WITH_CONDITION, NOT_READY, and DONE evidence sufficiency?
10. How will Phase 09 report actual completion and deviations against these stable criteria?

---

# 6. Minimum Criterion Contract

~~~yaml
criterion_id:
criterion_type: DOR | DOD
title:
applies_to_item_types_and_contexts: []
source_authority_and_version:
criterion_statement:
rationale_and_risk:
blocking_classification:
evaluation_method:
required_evidence:
evidence_freshness_and_subject_revision:
responsible_owner:
reviewer_or_decision_authority:
automation_rule_and_limitations:
allowed_condition_or_exception:
failure_behavior:
downstream_effect:
status:
supersedes:
reopen_triggers: []
~~~

---

# 7. Universal Definition of Ready

Every included item has:

1. stable identity, parent slice / enabler, exact upstream reason, and observable outcome;
2. canonical repository / module / schema / environment / configuration targets and accountable owner;
3. valid source / contract revisions and no material unresolved product / design / architecture invention;
4. dependency, sequence, access, toolchain, environment, data / identity, and reviewer readiness;
5. acceptance, applicable DoD, verification method / context / owner, and evidence obligation;
6. applicable security, privacy, audit, accessibility, localization, reliability, performance, observability, migration, release, and operational work;
7. estimate range / confidence / assumptions and capacity / skills / specialist constraints;
8. visible questions, blockers, spikes, risks, conditions, exceptions, deviations, and debt;
9. readiness status supported by evidence and correct authority.

---

# 8. Type-Specific and Conditional DoR

Type-specific criteria extend universal DoR for:

- UI / design / content / accessibility / localization work;
- API / event / job / integration / contract work;
- data / schema / migration / retention / residency work;
- identity / authorization / tenant / security / privacy / audit work;
- configuration / secret / key / flag work;
- platform / client / infrastructure / environment / CI/CD work;
- reliability / performance / observability / backup / recovery work;
- enablers, spikes, vendor dependencies, and legacy transformations.

`READY_WITH_CONDITION` is permitted only when the gap cannot force material invention, invalidate acceptance / verification, create unaccepted risk, or block safe implementation. It records exact restriction, owner, authority, evidence, due event, monitoring, failure route, and receiver acknowledgement.

---

# 9. Universal Definition of Done

Every completed item requires, as applicable:

1. implementation at exact authorized targets with immutable source / change identity;
2. required review, standards checks, tests, scans, and finding disposition;
3. acceptance and verification evidence for normal, failure, denied, unknown, recovery, and cross-cutting contexts;
4. design / content / accessibility / localization parity and approved divergence handling;
5. security / privacy / audit / data / control implementation and evidence;
6. migration / backfill / reconciliation / configuration / flag / deployment / rollback work and evidence;
7. reliability / performance / observability / operational documentation / runbook obligations;
8. updated traceability, implementation status, defects, risks, exceptions, deviations, and debt;
9. documentation, ownership, support / operations, and downstream handoff updates;
10. exact candidate inclusion / exclusion eligibility without claiming independent verification or release authorization.

---

# 10. Status Model

DoR result:

~~~text
NOT_EVALUATED
NOT_READY
READY_WITH_CONDITION
READY
STALE
SUPERSEDED
~~~

DoD result:

~~~text
NOT_STARTED
IN_PROGRESS
PARTIALLY_SATISFIED
SATISFIED
FAILED
STALE
SUPERSEDED
~~~

Implementation, verification, candidate, approval, and release statuses remain separate. DoR `READY` authorizes start within ENG-031; DoD `SATISFIED` supports Phase 09 completion but does not decide G6A / G6B / G7.

---

# 11. Traceability and Change Impact

Required paths include:

~~~text
Upstream Obligation / Standard / Risk
  -> ENG-017 Criterion / Applicability / Evidence
  -> Slice / Enabler / Work DoR Result and DoD Contract
  -> ENG-031 Authorized Start
  -> Phase 09 Implementation / Review / Test / Evidence / Deviation
  -> G6A Candidate / Phase 10 Verification
~~~

Material source, target, dependency, owner, environment, contract, acceptance, verification, evidence, risk, condition, or implementation change invalidates affected DoR / DoD results until reassessed.

---

# 12. Profile Behavior

| Profile | Required DoR / DoD behavior |
|---|---|
| Level 1 — Rapid | Compact criteria are allowed, but every item has exact target, owner, dependency, acceptance, verification, evidence, critical controls, and truthful readiness / completion. |
| Level 2 — Standard | Universal and type-specific criteria, evidence references, review ownership, automation, conditions, and formal G5B checks are required. |
| Level 3 — Comprehensive | Independent / segregated review, formal control evidence, migration / recovery rehearsal, provenance, multi-team conditions, and audit retention are added. |

---

# 13. Evidence and Exit Conditions

Evidence may include target / access verification, source revisions, contract readiness, dependency acceptance, environment / test-data checks, review assignments, estimates / capacity, automated rule results, manual review, migration / rollback plans, verification / evidence allocation, and condition authority.

ENG-017 is complete when universal and activated type-specific DoR / DoD criteria, methods, evidence, authority, automation, conditions / exceptions, status semantics, change impact, and Phase 09 reporting obligations are versioned and accepted; every ENG-031 item has a current DoR result and DoD contract.

---

# 14. Reopen Conditions

Reopen on scope, work type, standard, source, target, dependency, owner, toolchain, environment, data / identity, contract, acceptance, verification, evidence, control, migration, deployment, operational, risk, condition, or implementation-discovery change.

---

# 15. Validation Rules

~~~text
ENG17-CVAL-001  Every ENG-031 item has applicable universal and type-specific DoR criteria, a current evidence-backed result, and an executable DoD contract.
ENG17-CVAL-002  DoR, DoD, implementation, verification, candidate, approval, release, and operational statuses remain separate.
ENG17-CVAL-003  READY requires exact upstream reason, outcome, target, owner, dependencies, contracts, acceptance, verification, evidence, controls, and no hidden blocker.
ENG17-CVAL-004  READY_WITH_CONDITION is exact, non-blocking, authorized, owned, time-bound, evidenced, restricted, acknowledged, and automatically reopens on failure.
ENG17-CVAL-005  DoD covers code, review, tests, parity, controls, migration, observability, documentation, evidence, traceability, deviations, and operations as applicable.
ENG17-CVAL-006  Automated checks declare rule / tool version, subject, trigger, evidence, failure / bypass behavior, and semantic limitations.
ENG17-CVAL-007  Tracker status, checklist ticks, progress percentage, merged code, pipeline green, or developer confidence cannot prove READY or DONE.
ENG17-CVAL-008  Material source, target, dependency, context, risk, condition, or implementation change invalidates affected results and propagates review.
~~~
