# Core Artifact Contract — ENG-001 Engineering Readiness Scope and Profile

~~~yaml
contract_id: CONTRACT-ENG-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: ENG-001
artifact_name: Engineering Readiness Scope and Profile
owning_phase: Phase 08 - Engineering Readiness
gate_or_baseline: G5B - Engineering Readiness Baseline / ERBL - Engineering Readiness Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: RBL / EBL / DBL / ABL, G3B / G4A / G4B / G5A, ARC-033, release scope, current engineering evidence, GOV-009, and governance registers
primary_downstream: ENG-002 through ENG-032, G5B decision, ERBL, ENG-031, and Phase 09
semantic_source: ../../../Phase_08_Engineering_Readiness.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

ENG-001 defines the exact named scope for which Engineering Readiness will be assessed and potentially approved. It binds release / increment, included and excluded upstream baselines / objects, profile / domain overrides, current Engineering state, upstream conditions, teams / ownership, repository / environment boundary, decision / deviation authority, and evidence period.

It prevents G5B from becoming approval of a vague product area, entire backlog, date plan, or presumed implementation boundary. Later ENG artifacts may refine execution detail only inside this authorized scope or through governed change.

---

# 2. Scope and Applicability

ENG-001 is CORE whenever Phase 08 is active. A project may create separate records for independently governed products, releases, platforms, domains, migrations, repositories, teams, or risk classes.

Scope may be partial only when inclusions / exclusions, shared dependencies, upstream conditions, cross-scope controls, verification, evidence, operational effects, and prohibited assumptions are explicit. NOT_APPLICABLE requires an authorized alternate readiness mechanism with equivalent scope, baseline, authority, evidence, handoff, and reopen behavior.

---

# 3. Accountabilities

- **Owner:** Engineering Readiness lead accountable for truthful scope and current-state boundaries.
- **Product / release authority:** confirms release outcome and allocation boundary.
- **Architecture / design / requirements authorities:** confirm exact upstream baseline identities and unresolved conditions.
- **Repository / platform / data / security / verification / operations owners:** confirm affected targets, access, contexts, controls, and dependencies.
- **G5B authority:** approves readiness only for the exact named scope.
- **AI:** may assemble source identities and detect gaps; it cannot infer canonical repository / environment ownership, approve profile overrides, accept risk, or decide G5B.

---

# 4. Required Inputs

1. Exact RBL, EBL, DBL, ABL, G3B, G4A, G4B, and G5A versions / outcomes / conditions.
2. ARC-033 implementation obligations and source revisions.
3. Product / release outcome, candidate implementation boundary, platforms, markets, tenants, regions, languages, and outputs.
4. Current repositories, modules, toolchains, environments, trackers, teams, access, dependencies, and delivery evidence.
5. GOV-003 through GOV-009 relevant records.
6. Known questions, blockers, assumptions, risks, exceptions, deviations, debt, and operational constraints.

---

# 5. Required Questions

1. What exact release / increment / slice set is being assessed for G5B?
2. Which upstream baseline objects are included, excluded, deferred, shared, or conditionally consumed?
3. Which profile and domain overrides apply, and why?
4. What is confirmed current Engineering state versus planned target state?
5. Which canonical repositories, modules, schemas, environments, trackers, platforms, and teams bound the scope?
6. Which upstream conditions, shared dependencies, controls, migrations, verification contexts, and operational interfaces cross the boundary?
7. Who owns readiness, source decisions, deviations, risks, exceptions, reviews, and G5B approval?
8. What may Engineering decide locally, and what must return upstream?
9. Which evidence period and source revisions make current-state claims valid?
10. What changes automatically reopen this scope?

---

# 6. Required Decisions

- G5B / ERBL candidate scope identity;
- included, excluded, deferred, shared, and conditional objects;
- readiness profile and domain-level overrides;
- current versus target Engineering-state boundary;
- canonical target / tracker / repository / environment boundary;
- teams, owners, reviewers, and authorities;
- upstream-condition and shared-dependency treatment;
- risk, exception, deviation, and change authority;
- evidence period, prohibited assumptions, and reopen triggers.

---

# 7. Minimum Scope Record

~~~yaml
engineering_readiness_scope_id:
project_and_product_refs: []
release_increment_and_gate_scope:
erbl_candidate_id:
upstream_baselines_and_gate_outcomes: []
included_upstream_objects: []
excluded_or_deferred_objects: []
shared_and_conditional_objects: []
scope_boundary_rationale:
readiness_profile:
domain_profile_overrides: []
markets_platforms_tenants_regions_languages_outputs: []
current_engineering_state_refs_and_evidence: []
target_engineering_state_refs: []
canonical_tracker_repository_module_schema_environment_refs: []
teams_owners_and_reviewers: []
upstream_conditions_and_shared_dependencies: []
security_privacy_data_accessibility_reliability_and_operations_scope: []
decision_deviation_risk_and_exception_authorities: []
evidence_period:
prohibited_assumptions: []
status:
approved_by: []
reopen_triggers: []
~~~

---

# 8. Boundary and Authority Rules

Phase 08 may decide decomposition, sequencing, work ownership, implementation targets within approved architecture, Engineering standards, DoR / DoD, verification allocation, evidence production, and readiness conditions.

It may not alter business outcome, product responsibility, requirement semantics, experience behavior, design source truth, architecture decision, standards applicability, accepted risk, or release authorization without the owning governance path.

Out-of-scope work, targets, platforms, environments, or obligations are not authorized by proximity to the backlog. Shared dependencies must identify owner, consuming scope, readiness, evidence, and change notification.

---

# 9. Traceability and Change Impact

Required paths include:

~~~text
Upstream Baseline / Gate / GOV-009 / Current Evidence
  -> ENG-001 Scope / Profile / Boundary / Authority
  -> ENG-002 through ENG-030 Allocations and Evidence
  -> G5B Decision / ERBL / ENG-032
  -> ENG-031 Acknowledged Implementation Handoff
~~~

Scope change propagates to slices, work, targets, dependencies, estimates, conditions, DoR / DoD, verification, evidence, coverage, validation, baseline index, and handoff. Affected objects become `STALE` or `REVIEW_REQUIRED` until disposition.

---

# 10. Profile Behavior

| Profile | Required scope behavior |
|---|---|
| Level 1 — Rapid | One compact record may govern a narrow scope, but exact baselines, included objects, targets, owners, risks, conditions, evidence, and authority remain explicit. |
| Level 2 — Standard | Modular release / domain scope, current-state evidence, target boundaries, teams, repositories / environments, and formal G5B authority are required. |
| Level 3 — Comprehensive | Multiple repositories / teams / platforms / regions, regulated controls, segregation, formal source snapshots, independent challenge, and scope-level assurance are added. |

---

# 11. Evidence and Exit Conditions

Evidence may include baseline / gate records, tracker snapshots, repository / module / branch evidence, environment inventories, access / ownership confirmations, delivery and incident history, architecture / design sources, dependency contracts, risk / exception authority, and receiver acknowledgements.

ENG-001 is complete only when exact scope, profile, baselines, source revisions, current / target boundary, canonical targets, teams, authority, conditions, exclusions, evidence period, and reopen triggers are accepted and all material unknown boundary claims are resolved or governed.

---

# 12. Reopen Conditions

Reopen on release / upstream baseline / profile / market / platform / tenant / region / language / output / repository / module / schema / environment / team / authority / dependency / control / migration / risk / condition / source-evidence change.

---

# 13. Validation Rules

~~~text
ENG1-CVAL-001  ENG-001 binds exact RBL, EBL, DBL, ABL, gate outcomes, release, scope, profile, GOV-009, source revisions, and evidence period.
ENG1-CVAL-002  Included, excluded, deferred, shared, conditional, current, target, ready, implemented, verified, and approved statuses remain distinct.
ENG1-CVAL-003  Canonical tracker, repository, module, schema, environment, platform, team, owner, and authority identities are explicit and verified.
ENG1-CVAL-004  Partial scope records shared dependencies, cross-scope controls, verification, evidence, operations, conditions, and prohibited assumptions.
ENG1-CVAL-005  Phase 08 decision authority never silently overrides product, requirement, experience, design, architecture, standards, risk, or release authority.
ENG1-CVAL-006  Profile and domain overrides cite triggers, rationale, affected artifacts, assurance depth, owner, evidence, and reopen conditions.
ENG1-CVAL-007  A backlog, roadmap, team name, repository list, or estimate deck cannot define or approve the G5B scope.
ENG1-CVAL-008  Material scope, source, target, owner, authority, condition, or dependency change propagates stale status and revalidation.
~~~
