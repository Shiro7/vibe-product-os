# Phase 02 Family Contract — Business Architecture Models and Registers

~~~yaml
bundle_id: CONTRACT-BUNDLE-PHASE-02-FAMILY
bundle_version: 0.1.0
bundle_status: WORKING_DRAFT
asset_class: Product OS contract bundle - not a project artifact
artifact_family: BUS
owning_phase: Phase 02 - Business Architecture
gate_or_baseline: G2 - Business Baseline / BBL - Business Baseline
specialized_contract_artifacts:
  - BUS-002
  - BUS-003
  - BUS-004
  - BUS-005
  - BUS-006
  - BUS-007
  - BUS-008
  - BUS-009
  - BUS-010
  - BUS-011
shared_only_disposition_reviews: []
specialized_section_defaults:
  contract_version: 0.1.0
  contract_status: WORKING_DRAFT
  inherits: CORE-ARTIFACT-STANDARD@0.2.0
shared_inheritance: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-002, G1 decision and conditions, governance registers, GOV-009, and registered business evidence
primary_downstream: BUS-001, BUS-012, G2, PROD-002, REQ-001, and affected governance registers
semantic_source: ../../../Phase_02_Business_Architecture_v1.1.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Bundle Purpose and Boundary

This file provides ten independently governed logical artifact contracts without requiring ten physical files in every project. It preserves separate IDs, applicability, owners, lifecycle, validation, traceability, exit criteria, and reopen conditions while P1 / P2 / P3 control packaging depth.

The bundle contains:

~~~text
BUS-002  Business Capability Map
BUS-003  Value Stream Map
BUS-004  Target Operating Model
BUS-005  Business Process Catalog
BUS-006  Business Rules Catalog
BUS-007  Business Decision Catalog
BUS-008  Roles & Responsibilities Model
BUS-009  Business Control Register
BUS-010  Business Information Model
BUS-011  KPI & Outcome Measurement Model
~~~

BUS-001 remains the consolidated human-readable Business Baseline and references the canonical objects governed here; it does not duplicate them. BUS-012 independently records validation evidence and supplies the G2 authority with reproducible check results. This bundle is a framework asset and is not added to the 281-artifact catalog.

The detailed method remains in [Phase 02 — Business Architecture](../../../Phase_02_Business_Architecture_v1.1.md). This bundle operationalizes artifact obligations and does not create a competing methodology.

---

# 2. Shared Phase 02 Family Rules

1. Business architecture defines technology-neutral business truth before allocating behavior to product, experience, system, data, or architecture.
2. Business capability is not a feature or department; value stream is not a process; role is not a system permission; business information is not a database entity.
3. Current, target, and transitional states remain distinct and traceable.
4. Rules, decisions, controls, responsibilities, exceptions, information, and KPIs remain separate canonical object types even when they are presented in one diagram or pack.
5. Every material object has stable identity, accountable ownership or explicit ownership gap, source / rationale, lifecycle status, and downstream links.
6. Happy-path documentation is incomplete when material exceptions affect money, rights, ownership, stock, security, legal status, approval, audit, or operational continuity.
7. Applicable standards and profiles enter Phase 02 through GOV-009 and become canonical `BREQ`, `BR`, `CTRL`, `POL`, `INFO`, or `EVID` obligations without copying the standard as a competing source.
8. A conditional artifact may be NOT_APPLICABLE only with reason, decision owner, date, evidence, approval status, downstream implication, and reopen condition.
9. Unknown, conflict, authority gap, control gap, and measurement gap remain explicit; AI confidence or document volume cannot close them.
10. Phase 02 never prescribes screens, buttons, APIs, tables, frameworks, microservices, or vendor products.

---

# 3. Shared Profile Packaging

- **P1 — Lean:** applicable logical artifacts may be governed sections or linked views inside a Business Architecture Pack and BUS-001. Stable object IDs, status, applicability, decisions, evidence, and reopen semantics remain.
- **P2 — Standard:** core models and registers are modular and independently reviewable; conditional artifacts activate from explicit triggers.
- **P3 — Comprehensive:** independent ownership, version lineage, policy / control assurance, segregation-of-duties analysis, formal decision tables, current / target / transition variants, retained evidence, and independent review strengthen.

Profile changes packaging and assurance depth. It never removes an applicable constitutional, legal, security, privacy, accessibility, audit, financial, safety, resilience, or contractual obligation.

---

# 4. BUS-002 — Business Capability Map Contract

~~~yaml
contract_id: CONTRACT-BUS-002
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-002
artifact_name: Business Capability Map
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-002, G1 baseline, business objectives, scope, and GOV-009 obligations
primary_downstream: BUS-001, BUS-003 through BUS-005, BUS-011, BUS-012, PROD-002, and REQ-001
~~~

## 4.1 Purpose, Boundary, and Applicability

BUS-002 defines what the business must be able to do, independently of organization structure and technology implementation. It organizes relevant domain, capability, and sub-capability identities and shows how each supports an objective, outcome, problem, opportunity, policy, or regulatory need.

BUS-002 is CORE when Phase 02 is active. Capability names use business meaning, preferably `Verb + Business Object`. A feature, screen, service, database, team, department, activity, or process step cannot substitute for a business capability.

## 4.2 Accountabilities, Inputs, and Questions

- **Owner:** business architecture or business analysis authority.
- **Capability owners:** accountable business roles for capability meaning, need, maturity, and change direction.
- **Domain / policy reviewers:** confirm boundaries, cross-domain ownership, and obligation coverage.
- **AI:** may cluster and propose candidate hierarchies; it cannot invent capability need, ownership, current maturity, or target maturity.

Required inputs are the exact DSBL / DISC-002 version, G1 conditions, business scope, problems, outcomes, objectives, current operating evidence, relevant policies and standards, existing capability models, and known ownership.

Each capability answers:

1. What stable business ability is required and within which domain boundary?
2. Which problem, outcome, objective, opportunity, policy, or GOV-009 obligation justifies it?
3. Is it L0 domain capability, L1 capability, or L2 sub-capability?
4. Who owns it, and is ownership singular, shared with rationale, or unresolved?
5. What current gap and target change are decision-relevant?
6. Which processes, value streams, information, rules, controls, and KPIs depend on it?

## 4.3 Minimum Capability Record

~~~yaml
capability_id:
name:
level: L0_OR_L1_OR_L2
parent_capability_ref:
business_domain_refs: []
purpose:
rationale_refs: []
supports_objectives: []
related_problems_outcomes_opportunities: []
standards_obligation_refs: []
owner:
ownership_status:
strategic_importance:
current_maturity:
target_maturity:
gap_or_change_need:
change_type:
related_value_streams: []
related_processes: []
related_rules_controls_information_kpis: []
status:
source_refs: []
assumption_question_risk_refs: []
downstream_derivation_refs: []
reopen_triggers: []
~~~

Maturity may use `M0 ABSENT` through `M5 OPTIMIZED` only when it informs a decision. Gap states may include `MISSING`, `WEAK`, `FRAGMENTED`, `MANUAL`, `DUPLICATED`, `UNCONTROLLED`, `ADEQUATE`, and `STRONG`.

## 4.4 Decisions, Traceability, Verification, Exit, and Reopen

Required decisions cover domain boundary, hierarchy, capability need, owner, importance, current / target disposition, cross-domain treatment, and downstream responsibility. Outputs are the versioned hierarchy, capability records, ownership / gap views, orphan list, and BUS-001 references.

~~~text
PRB / OPP / GOV-009 → OUT / OBJ → CAP
CAP → VS / PROC / BR / CTRL / INFO / KPI
CAP → Product responsibility → System requirement derivation
~~~

Verification checks semantic naming, justified inclusion, non-duplicate cross-domain identity, ownership, hierarchy depth, current / target distinction, and downstream links. BUS-002 is complete when all material objectives and applicable obligations have proportionate capability coverage, orphan and ownership gaps are governed, and later phases can derive responsibility without inventing capability need.

Reopen on objective, scope, operating model, domain, owner, policy, standard applicability, maturity evidence, capability gap, product boundary, or downstream rejection change.

## 4.5 Artifact-Specific Validation Rules

~~~text
BUS2-CVAL-001  Every capability is a technology-neutral business ability, not a feature, screen, service, team, or process step.
BUS2-CVAL-002  Every new or changed capability traces to an objective, problem, outcome, opportunity, policy, or regulatory obligation.
BUS2-CVAL-003  Capability hierarchy preserves L0, L1, and L2 meaning without becoming a hidden activity list.
BUS2-CVAL-004  Cross-domain capability identity is not duplicated merely because multiple departments participate.
BUS2-CVAL-005  Capability owner, ownership gap, and current / target disposition remain explicit.
BUS2-CVAL-006  Maturity and heatmap values are evidence-based and used only when decision-relevant.
BUS2-CVAL-007  Applicable GOV-009 obligations have capability coverage or an explicit alternate business-object route.
BUS2-CVAL-008  Orphan capability count is zero or every orphan has a governed disposition before G2.
~~~

---

# 5. BUS-003 — Value Stream Map Contract

~~~yaml
contract_id: CONTRACT-BUS-003
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-003
artifact_name: Value Stream Map
target_mode: FAMILY_SECTION
default_activation: CONDITIONAL
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: BUS-002, business objectives, stakeholder value, scope, and operating evidence
primary_downstream: BUS-001, BUS-004, BUS-005, BUS-011, BUS-012, PROD-002, and REQ-001
~~~

## 5.1 Purpose, Boundary, and Applicability

BUS-003 describes the relevant end-to-end progression that creates, protects, exchanges, or recovers value for a stakeholder. It establishes trigger, value recipient, value outcome, stages, participating capabilities, handoffs, and material loss or delay points.

It activates when end-to-end value progression is needed to understand scope, cross-domain responsibility, transformation, customer / partner outcomes, or major handoffs. It is not a process map: a value-stream stage expresses meaningful value progression, not necessarily an activity or workflow step.

If NOT_APPLICABLE, record the activation question, reason, owner, evidence, approval, downstream implication, and the event that would reopen value-stream analysis.

## 5.2 Accountabilities, Inputs, and Questions

- **Owner:** business architecture owner for end-to-end value coherence.
- **Value recipient / business owners:** confirm trigger, expected value, stages, and value loss.
- **Capability / process owners:** confirm participation without converting stages into process steps.
- **AI:** may synthesize candidate stages; it cannot invent recipient value, stage acceptance, or applicability.

Inputs include objectives, affected stakeholders, BUS-002 capabilities, current / target evidence, process boundaries, dependencies, and standards-derived continuity obligations.

Each value stream answers:

1. What triggers the value progression and who receives or recognizes value?
2. What end value or protected outcome concludes it?
3. Which stages represent meaningful value progression?
4. Which capabilities, actors, domains, information, and external dependencies participate?
5. Where are delays, loss, failure, control, accessibility, or ownership gaps material?
6. Which processes realize each stage without becoming the value stream itself?

## 5.3 Minimum Value Stream Record

~~~yaml
value_stream_id:
name:
scope:
state: CURRENT_OR_TARGET_OR_TRANSITIONAL
trigger:
value_recipient_refs: []
expected_value_or_outcome:
stages:
  - stage_id:
    name:
    value_progression:
    entry_condition:
    exit_or_value_condition:
    capability_refs: []
    actor_or_role_refs: []
    information_refs: []
    process_refs: []
    dependency_refs: []
    risk_control_or_gap_refs: []
cross_domain_handoffs: []
value_loss_or_delay_points: []
kpi_refs: []
source_refs: []
owner:
status:
reopen_triggers: []
~~~

## 5.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover applicability, value recipient, stream boundary, stage semantics, current / target / transitional state, participating capabilities, value-loss hotspots, and process allocation. Outputs are versioned streams, stage definitions, cross-domain handoff view, and process / KPI derivation links.

~~~text
Stakeholder Need / OBJ → VS Trigger → Value Stages → Value Outcome
VS Stage → CAP / PROC / ROLE / INFO / Dependency
VS Gap → Risk / Control / KPI / Product implication
~~~

Verification confirms end-to-end coverage, explicit value recipient, non-process stage semantics, state separation, and traceable realization. BUS-003 is complete when every activated stream has coherent trigger-to-value boundaries, material stage / handoff gaps are governed, and BUS-005 can model work without inventing the value logic.

Reopen on stakeholder, value proposition, business scope, capability, handoff, operating model, dependency, standards obligation, or material process change.

## 5.5 Artifact-Specific Validation Rules

~~~text
BUS3-CVAL-001  Every value stream identifies trigger, value recipient, expected value, and end-to-end boundary.
BUS3-CVAL-002  A value-stream stage expresses value progression and is not mislabeled as a detailed process step.
BUS3-CVAL-003  Current, target, and transitional stream views remain distinct when more than one exists.
BUS3-CVAL-004  Each stage links the capabilities and processes that realize it without duplicating their canonical content.
BUS3-CVAL-005  Material cross-domain handoffs, dependencies, value loss, delay, and failure points remain visible.
BUS3-CVAL-006  A stream does not expand beyond the approved business scope without a governed scope decision.
BUS3-CVAL-007  Conditional non-activation includes reason, owner, evidence, approval, downstream effect, and reopen condition.
BUS3-CVAL-008  BUS-003 never substitutes customer-journey screens or workflow diagrams for business value progression.
~~~

---

# 6. BUS-004 — Target Operating Model Contract

~~~yaml
contract_id: CONTRACT-BUS-004
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-004
artifact_name: Target Operating Model
target_mode: FAMILY_SECTION
default_activation: CONDITIONAL
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-002 current state, BUS-002, BUS-003, policies, constraints, risks, and GOV-009
primary_downstream: BUS-001, BUS-005 through BUS-011, BUS-012, PROD-002, and REQ-001
~~~

## 6.1 Purpose, Boundary, and Applicability

BUS-004 defines how the business must operate at the required depth across people, roles, processes, decisions, controls, information, locations, partners, governance, performance, and contextual technology touchpoints. It preserves the canonical relationship `CURRENT → GAP → TARGET` and models transitional coexistence when change cannot occur atomically.

It activates for business transformation, meaningful operating-model change, organizational or partner change, centralization / decentralization, outsourcing, migration, control redesign, or another situation in which separate target and transition logic is needed. Technology touchpoints remain contextual; BUS-004 does not choose system components or architecture.

NOT_APPLICABLE requires evidence that the accepted operating model is unchanged or sufficiently governed elsewhere, plus owner, approval, downstream effect, and reopen condition.

## 6.2 Accountabilities, Inputs, and Questions

- **Owner:** accountable business architecture / transformation owner.
- **Business and operating owners:** approve current truth, gaps, target responsibilities, and transition viability.
- **Policy / control / people / partner authorities:** confirm obligations within their scope.
- **AI:** may compare and structure states; it cannot approve organization change, outsourcing, authority, control removal, or target viability.

Inputs include current-state evidence, objectives, capabilities, value streams, roles, processes, decisions, rules, controls, information, locations, partners, dependencies, risks, costs, constraints, policies, and GOV-009 obligations.

Required questions include:

1. Which operating dimensions materially change and why?
2. What is the evidence-supported current state, the exact gap, and the intended target state?
3. Which change type applies: keep, improve, standardize, automate, remove, consolidate, separate, introduce, outsource, centralize, decentralize, or unknown?
4. Who owns and approves the target and transition state?
5. Which control, continuity, accessibility, data, legal, workforce, partner, or location consequences apply?
6. What transition stages, coexistence rules, fallback, acceptance conditions, and dependencies are required?

## 6.3 Minimum Operating-Model Change Record

~~~yaml
operating_model_change_id:
dimension:
business_scope:
current_state:
current_state_evidence_refs: []
gap:
target_state:
rationale_refs: []
change_type:
owner:
approvers: []
affected_capabilities: []
affected_roles_processes_decisions_rules: []
affected_controls_information_kpis: []
partner_location_dependency_refs: []
technology_touchpoints_context_only: []
standards_and_policy_refs: []
transition_states: []
coexistence_or_cutover_rules: []
fallback_or_continuity:
acceptance_conditions: []
risks_assumptions_questions: []
status:
downstream_implications: []
reopen_triggers: []
~~~

## 6.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover activation, current / gap / target truth, change type, responsibility, authority, controls, transition route, dependencies, acceptance, and downstream implications. Outputs are the target model, change records, transition states, operating dependencies, responsibility / control deltas, and BUS-001 consolidation links.

Verification checks that the target is justified rather than copied from current state, gaps are explicit, technology is contextual, transition is viable, and no control disappears silently. BUS-004 is complete when activated operating dimensions have accountable target and transition dispositions that processes, product, and requirements can consume without inventing organizational behavior.

Reopen on strategy, business scope, organization, policy, authority, location, partner, sourcing, control, standard applicability, transition evidence, dependency, or target-acceptance change.

## 6.5 Artifact-Specific Validation Rules

~~~text
BUS4-CVAL-001  Every target-state assertion traces through an explicit current state and gap or records why prior current-state evidence remains valid.
BUS4-CVAL-002  Current, target, and transitional operating states cannot be collapsed into one ambiguous model.
BUS4-CVAL-003  Technology touchpoints are contextual and do not prescribe solution architecture.
BUS4-CVAL-004  Every material operating change has type, rationale, owner, authority, dependencies, and acceptance conditions.
BUS4-CVAL-005  Transition and coexistence states preserve required controls, ownership, evidence, and continuity.
BUS4-CVAL-006  Removal or automation of work does not silently remove a rule, decision, control, exception, or accountable responsibility.
BUS4-CVAL-007  Conditional non-activation includes reason, owner, evidence, approval, downstream effect, and reopen condition.
BUS4-CVAL-008  Target-model viability is not asserted from AI preference, organization-chart appearance, or technology fashion.
~~~

---

# 7. BUS-005 — Business Process Catalog Contract

~~~yaml
contract_id: CONTRACT-BUS-005
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-005
artifact_name: Business Process Catalog
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: BUS-002 through BUS-004, business events, roles, rules, controls, information, and evidence
primary_downstream: BUS-001, BUS-006 through BUS-012, PROD-002, REQ-001, and EXP-001
~~~

## 7.1 Purpose, Boundary, and Applicability

BUS-005 is the canonical register of major business processes and required subprocesses. A process begins with a business trigger, transforms defined inputs through accountable activities, decisions, rules, controls, handoffs, and exceptions, and ends at a business outcome.

BUS-005 is CORE. Modeling depth is proportionate to risk, complexity, exception density, automation need, cross-functional handoffs, and control requirements. A process is not a value stream, user journey, screen flow, system workflow, or organization chart.

## 7.2 Accountabilities, Inputs, and Questions

- **Owner:** business process architecture owner.
- **Process owners:** confirm purpose, boundary, actual / target behavior, roles, outcomes, exceptions, and performance.
- **Rule / control / information owners:** confirm linked logic and evidence obligations.
- **AI:** may structure process records and identify missing paths; it cannot claim current behavior, decide target behavior, or close exceptions without authority.

Inputs include objectives, capabilities, value streams, operating states, business events, roles, decisions, rules, controls, exceptions, information, dependencies, KPIs, current-state evidence, and GOV-009 obligations.

Each process answers:

1. What business event triggers it and what business outcome ends it?
2. What level is it: L0 end-to-end, L1 major process, L2 subprocess, or L3 activity?
3. Is this CURRENT, TARGET, or TRANSITIONAL behavior?
4. Which inputs, outputs, roles, activities, decisions, rules, controls, information, handoffs, and dependencies apply?
5. Which rejection, invalid input, authority exception, dependency failure, cancellation, manual override, and recovery paths are material?
6. Which capability and objective does the process realize, and which KPI measures it?

## 7.3 Minimum Process Record

~~~yaml
process_id:
name:
level:
parent_process_ref:
state: CURRENT_OR_TARGET_OR_TRANSITIONAL
business_domain_refs: []
purpose:
capability_and_objective_refs: []
trigger_event_refs: []
inputs: []
roles: []
activities: []
decisions: []
rules: []
controls: []
information_refs: []
outputs: []
business_outcome_refs: []
exceptions: []
handoffs: []
dependencies: []
kpi_refs: []
standards_obligation_refs: []
owner:
status:
source_and_evidence_refs: []
assumption_question_risk_refs: []
downstream_derivation_refs: []
reopen_triggers: []
~~~

A material handoff records from-role, to-role, transferred information, acceptance condition, failure / rejection path, ownership, and applicable control. Activities record actor, input, action, output, linked rule / decision / control, and exception where required.

## 7.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover process identity, boundary, level, state, owner, trigger, outcome, modeling depth, variants, handoffs, exception coverage, and downstream allocation. Outputs are the process index, versioned process contracts, event / handoff / exception views, orphan list, and product / requirement derivation references.

~~~text
OBJ → CAP → VS Stage → PROC → Activity / Handoff
PROC → DEC / BR / CTRL / EXC / INFO / KPI / Dependency
PROC → Product capability / Requirement / Experience scenario
~~~

Verification confirms trigger-to-outcome boundaries, state separation, capability justification, ownership, linked logic, cross-functional handoffs, and material exception coverage. BUS-005 is complete when major business flows needed downstream are understood without forcing later phases to invent business behavior.

Reopen on event, outcome, capability, operating state, role, authority, decision, rule, control, exception, dependency, information, KPI, policy, standard, or implementation feedback change.

## 7.5 Artifact-Specific Validation Rules

~~~text
BUS5-CVAL-001  Every major process has a business trigger, business outcome, owner, boundary, state, and capability or objective rationale.
BUS5-CVAL-002  L0 through L3 depth is proportionate and does not confuse process, value stream, journey, screen flow, or technical workflow.
BUS5-CVAL-003  Current, target, and transitional processes remain separate and version-identifiable.
BUS5-CVAL-004  Material decisions, rules, controls, information, dependencies, and KPIs are linked rather than embedded as ungoverned prose.
BUS5-CVAL-005  Cross-functional handoffs identify ownership, information, acceptance, failure path, and control where applicable.
BUS5-CVAL-006  Critical exceptions and recovery paths are explicit; happy-path-only coverage cannot pass G2.
BUS5-CVAL-007  Every material process traces to a capability or objective, or has an approved legacy / mandatory rationale.
BUS5-CVAL-008  Process descriptions remain technology-neutral and do not prescribe screens, APIs, tables, services, or vendor workflow products.
~~~

---

# 8. BUS-006 — Business Rules Catalog Contract

~~~yaml
contract_id: CONTRACT-BUS-006
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-006
artifact_name: Business Rules Catalog
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: business policies, contracts, regulations, decisions, processes, exceptions, domain knowledge, GOV-003, and GOV-009
primary_downstream: BUS-001, BUS-005, BUS-007, BUS-009, BUS-010, BUS-012, PROD-002, and REQ-001
~~~

## 8.1 Purpose, Boundary, and Applicability

BUS-006 is the canonical register of declarative logic that constrains, derives, classifies, calculates, validates, times, authorizes, obligates, prohibits, or governs business behavior. Rules are atomic, unambiguous, technology-neutral, traceable, owned, exception-aware, and testable where practical.

BUS-006 is CORE. A business requirement states a required capability, outcome, responsibility, or control; a business rule governs behavior. A rule is not a UI message, code expression, process step, policy document, control, or project decision.

## 8.2 Accountabilities, Inputs, and Questions

- **Owner:** business-rule governance owner.
- **Rule owner / authoritative source owner:** approves meaning, applicability, lifecycle, and override behavior.
- **Process, decision, control, and information owners:** confirm operational links and conflicts.
- **AI:** may extract and normalize candidate rules or detect duplicates; it cannot invent authority, thresholds, status, approval, or exception rights.

Inputs include authoritative policies, contracts, regulation, management decisions, operating evidence, processes, decisions, calculations, state models, exceptions, conflicts, standards obligations, and source lineage.

Each rule answers:

1. What atomic business behavior is governed and what rule type applies?
2. When does it apply, when does it not apply, and which scope / population / state is covered?
3. Who owns it or which policy, contract, regulation, or accountable decision authorizes it?
4. What inputs, thresholds, calculation, outcome, and effective period apply?
5. Can it be overridden, by whom, within which limits, with what evidence and auditability?
6. Which capability, process, decision, control, exception, information concept, standard obligation, and downstream requirement depend on it?

## 8.3 Minimum Rule Record

~~~yaml
business_rule_id:
name:
statement:
rule_type:
business_scope:
applicability_conditions: []
non_applicability_conditions: []
inputs: []
logic_or_calculation:
outcomes: []
owner:
authority_source_refs: []
effective_from:
effective_to:
status:
process_refs: []
decision_refs: []
control_refs: []
exception_refs: []
information_refs: []
standards_obligation_refs: []
override:
  allowed:
  authority_refs: []
  limits: []
  evidence_required: []
conflicts_with: []
supersedes:
superseded_by:
verification_or_example_refs: []
downstream_derivation_refs: []
reopen_triggers: []
~~~

Allowed lifecycle includes `PROPOSED`, `IN_REVIEW`, `APPROVED`, `REJECTED`, `DEPRECATED`, and `SUPERSEDED`. Rule status remains separate from implementation and verification status.

## 8.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover rule statement, type, authority, scope, effective period, exceptions, override, conflicts, lifecycle, and downstream derivation. Outputs include versioned rules, conflict / duplicate views, decision tables where complexity warrants, exception and control links, and requirement derivation flags.

~~~text
Policy / Contract / Regulation / GOV-003 / GOV-009 → BR
CAP / PROC / DEC / EXC / INFO ↔ BR ↔ CTRL
BR → Product policy or constraint → FR / NFR / SEC / ACC / AUD / DR / INT
~~~

Verification tests clarity, atomicity, authority, scope, example outcomes, conflict handling, and override governance. BUS-006 is complete when material business logic is explicit enough for product and requirements work without relying on undocumented human or developer knowledge.

Reopen on policy, regulation, contract, authority, threshold, calculation, scope, effective date, decision, process, exception, control, information, standard applicability, conflict, or implementation evidence change.

## 8.5 Artifact-Specific Validation Rules

~~~text
BUS6-CVAL-001  Every material rule is atomic, unambiguous, technology-neutral, owned or authority-sourced, and traceable.
BUS6-CVAL-002  Requirement, policy, project decision, process step, control, UI wording, and code expression do not replace the business-rule object.
BUS6-CVAL-003  Applicability, non-applicability, effective period, inputs, logic, and outcomes are explicit where material.
BUS6-CVAL-004  Override rights identify authority, conditions, limits, evidence, and auditability.
BUS6-CVAL-005  Rule conflicts, duplicates, corrections, and supersession remain visible until governed disposition.
BUS6-CVAL-006  Calculation, threshold, eligibility, classification, and state-transition rules have reproducible examples or tests where practical.
BUS6-CVAL-007  Standards-derived rules trace to GOV-009 and preserve the authoritative external source identity.
BUS6-CVAL-008  Critical business logic cannot remain only in a diagram, meeting note, developer understanding, or implementation.
~~~

---

# 9. BUS-007 — Business Decision Catalog Contract

~~~yaml
contract_id: CONTRACT-BUS-007
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-007
artifact_name: Business Decision Catalog
target_mode: FAMILY_SECTION
default_activation: CONDITIONAL
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: BUS-002, BUS-005, BUS-006, BUS-008, policies, authority, and material decision evidence
primary_downstream: BUS-001, BUS-005, BUS-006, BUS-008 through BUS-012, PROD-002, and REQ-001
~~~

## 9.1 Purpose, Boundary, and Applicability

BUS-007 owns reusable business choice logic that determines what happens next based on information, rules, authority, and context. It captures decision question, owner, inputs, criteria / rules, possible outcomes, authority limits, escalation, evidence, and affected process.

It activates when decisions are material, repeated, rule-driven, cross-functional, delegated, exception-sensitive, or affect money, rights, ownership, eligibility, status, approval, control, compliance, or risk. Approval is one decision type; classify, route, calculate, select, reject, and escalate are also decisions.

BUS-007 does not duplicate GOV-003. BUS-007 owns reusable business decision logic; GOV-003 owns accountable project or baseline choices. NOT_APPLICABLE requires reason, owner, evidence, approval, downstream effect, and reopen condition.

## 9.2 Accountabilities, Inputs, and Questions

- **Owner:** business decision-model owner.
- **Decision owner / delegated authorities:** approve question, criteria, outcome authority, limits, and escalation.
- **Rule, process, control, and information owners:** confirm dependencies and evidence needs.
- **AI:** may structure a decision table or identify authority gaps; it cannot decide business outcomes, assign authority, or fabricate decision evidence.

Inputs include processes, rules, roles, responsibilities, delegation, information, controls, exception paths, policy / regulatory sources, historical decisions, and GOV-009 obligations.

Each decision answers:

1. What exact business question determines the next outcome?
2. Who owns the decision, who may propose / approve / execute / override, and within what limits?
3. What information and rules are required?
4. What outcomes, rejection, escalation, timeout, and insufficient-information paths exist?
5. What evidence and justification must be retained?
6. Is a decision table required to remove ambiguous or conflicting logic?

## 9.3 Minimum Business Decision Record

~~~yaml
business_decision_id:
name:
question:
decision_type:
business_scope:
owner_role_ref:
authority_refs: []
delegated_limits: []
inputs: []
rule_refs: []
possible_outcomes: []
insufficient_information_path:
rejection_or_escalation_path:
override_authority_refs: []
evidence_required: []
process_and_capability_refs: []
control_and_exception_refs: []
information_refs: []
decision_table_ref:
standards_obligation_refs: []
status:
source_refs: []
conflict_question_risk_refs: []
downstream_derivation_refs: []
reopen_triggers: []
~~~

## 9.4 Decisions, Traceability, Verification, Exit, and Reopen

Required decisions cover activation, question, type, owner, authority, delegated limit, inputs, criteria, outcomes, override, escalation, evidence, and decision-table need. Outputs are the decision catalog, authority-gap list, decision tables, process / rule / control links, and product / requirement derivation route.

Verification exercises representative and boundary scenarios, confirms authority and evidence, and separates reusable logic from historical project decisions. BUS-007 is complete when all activated material choices can be executed or derived downstream without hidden judgment or authority ambiguity.

Reopen on process, rule, information, authority, delegation, threshold, outcome, exception, control, evidence, policy, standard, or downstream behavior change.

## 9.5 Artifact-Specific Validation Rules

~~~text
BUS7-CVAL-001  Every material decision states one clear business question, owner, inputs, rules, outcomes, authority, escalation, and evidence need.
BUS7-CVAL-002  Approval is modeled as one decision type and does not hide classify, route, calculate, reject, or escalate logic.
BUS7-CVAL-003  Decision owner, proposer, approver, executor, override authority, and delegated limits remain distinct where applicable.
BUS7-CVAL-004  Complex or conflicting criteria use a governed decision table or equivalent reproducible representation.
BUS7-CVAL-005  BUS-007 reusable business logic is not duplicated in GOV-003 project decision records.
BUS7-CVAL-006  Decisions affecting money, rights, ownership, eligibility, status, control, or risk include exception and evidence treatment.
BUS7-CVAL-007  Conditional non-activation includes reason, owner, evidence, approval, downstream effect, and reopen condition.
BUS7-CVAL-008  UI actions, workflow labels, AI recommendations, or historical outcomes cannot substitute for authorized business decision logic.
~~~

---

# 10. BUS-008 — Roles & Responsibilities Model Contract

~~~yaml
contract_id: CONTRACT-BUS-008
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-008
artifact_name: Roles & Responsibilities Model
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: stakeholders, business domains, BUS-002 through BUS-007, organization and authority sources, and GOV-001
primary_downstream: BUS-001, BUS-004 through BUS-007, BUS-009, BUS-010, BUS-012, PROD-002, and REQ-001
~~~

## 10.1 Purpose, Boundary, and Applicability

BUS-008 defines business actors, roles, ongoing responsibilities, decision rights, delegated authority, limits, participation, handoffs, and accountability. An actor answers who or what participates; a role expresses responsibility being performed; a responsibility is an ongoing obligation rather than a discrete task.

BUS-008 is CORE. Business roles do not become system permissions. Generic roles such as `Admin`, `Manager`, or `User` require decomposition or evidence that their business meaning and authority are genuinely clear.

## 10.2 Accountabilities, Inputs, and Questions

- **Owner:** business responsibility / operating-model owner.
- **Domain and process owners:** approve responsibilities, ownership, participation, and handoffs.
- **Authority / governance owners:** approve delegation, limits, segregation, and escalation.
- **AI:** may detect ambiguity, collision, and missing accountability; it cannot assign responsibility or authority from title, attendance, or system access.

Inputs include stakeholder and organization evidence, domains, capabilities, operating model, processes, decisions, rules, controls, information ownership, policy, delegation, conflicts, and external-party boundaries.

Each role answers:

1. What business responsibility is performed and within which domain / scope?
2. Which actor types may carry the role, without binding it to one person?
3. What may the role propose, approve, execute, override, validate, own, or receive?
4. What limits, delegation, escalation, absence / backup, and segregation apply?
5. Which capabilities, processes, decisions, rules, controls, information, and handoffs depend on it?
6. Is accountability singular, shared with rationale, unresolved, or external?

## 10.3 Minimum Role and Responsibility Record

~~~yaml
role_id:
name:
business_definition:
business_domain_refs: []
eligible_actor_types: []
responsibility_refs: []
capability_and_process_refs: []
decision_rights:
  propose: []
  approve: []
  execute: []
  override: []
  validate: []
authority_refs: []
authority_limits: []
delegated_from:
delegates_to: []
escalation_route:
backup_or_absence_rule:
segregation_constraints: []
information_ownership_or_use: []
handoff_refs: []
control_refs: []
standards_obligation_refs: []
owner:
status:
source_refs: []
conflict_question_risk_refs: []
reopen_triggers: []
~~~

RACI is optional. If used, multiple Accountable assignments require explicit rationale and cannot hide final decision authority.

## 10.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover actor / role boundary, responsibility, owner, authority, delegation, limits, accountability, segregation, escalation, and handoffs. Outputs are role and responsibility definitions, authority map, RACI where useful, gaps / conflicts, and downstream authorization derivation constraints.

~~~text
Domain / CAP → ROLE → RESP → PROC / Handoff
ROLE → DEC Authority / BR Override / CTRL Segregation / INFO Ownership
ROLE → Product actor / System authorization requirement, never direct permission invention
~~~

Verification confirms responsibilities have accountable owners, authority sources and limits are valid, generic roles are decomposed, segregation conflicts are visible, and system permissions have not been designed. BUS-008 is complete when critical business work and decisions have unambiguous accountable routes or governed gaps before G2.

Reopen on organization, domain, role, responsibility, authority, delegation, process, decision, control, information ownership, partner boundary, policy, or standard change.

## 10.5 Artifact-Specific Validation Rules

~~~text
BUS8-CVAL-001  Actor, business role, responsibility, task, person, and system permission remain distinct object types.
BUS8-CVAL-002  Every critical capability, process, decision, control, and information responsibility has an accountable role or explicit authority gap.
BUS8-CVAL-003  Authority records distinguish propose, approve, execute, override, validate, and inform responsibilities where relevant.
BUS8-CVAL-004  Delegation includes source, scope, limits, validity, escalation, and backup or absence behavior.
BUS8-CVAL-005  Generic role names are decomposed or supported by precise business meaning and authority.
BUS8-CVAL-006  RACI, when used, does not hide multiple Accountable owners or substitute for decision authority.
BUS8-CVAL-007  Segregation-of-duties conflicts are identified before downstream authorization design.
BUS8-CVAL-008  Organization title, meeting participation, or existing application access never proves business authority.
~~~

---

# 11. BUS-009 — Business Control Register Contract

~~~yaml
contract_id: CONTRACT-BUS-009
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-009
artifact_name: Business Control Register
target_mode: FAMILY_SECTION
default_activation: CONDITIONAL
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-004, GOV-009, BUS-004 through BUS-008, policies, risks, contracts, regulations, and audit evidence
primary_downstream: BUS-001, BUS-005, BUS-006, BUS-008, BUS-010, BUS-012, PROD-002, REQ-001, and later assurance
~~~

## 11.1 Purpose, Boundary, and Applicability

BUS-009 is the canonical register of mechanisms designed to prevent, detect, correct, limit, monitor, reconcile, approve, separate, audit, or evidence unacceptable business behavior or risk. A rule states what must or must not happen; a control reduces the risk that the rule or obligation is violated.

It activates when material business risk, policy, contract, regulation, financial effect, authority, security, privacy, accessibility, audit, safety, resilience, data, evidence, or GOV-009 obligation requires control treatment. Control types may include `PREVENTIVE`, `DETECTIVE`, `CORRECTIVE`, `APPROVAL`, `SEGREGATION_OF_DUTIES`, `RECONCILIATION`, `LIMIT`, `MONITORING`, `AUDIT`, and `EVIDENCE`.

NOT_APPLICABLE requires a governed risk / obligation decision, owner, rationale, evidence, approval, compensating implications, and reopen condition. A control cannot disappear merely for UX or implementation convenience.

## 11.2 Accountabilities, Inputs, and Questions

- **Owner:** business control owner accountable for design, operation, evidence, and review.
- **Risk / policy / compliance authorities:** confirm objective, required strength, residual exposure, and exceptions.
- **Process / role / rule / information owners:** confirm where and how the control operates.
- **AI:** may map obligations and identify gaps; it cannot accept residual risk, waive control, approve compensating control, or claim operating effectiveness.

Inputs include risks, rules, processes, decisions, roles, segregation, exceptions, information, policies, contracts, regulations, standards applicability, incidents, audit findings, and evidence expectations.

Each control answers:

1. Which risk, rule, policy, process, decision, information, or standard obligation does it address?
2. Is it preventive, detective, corrective, approval, segregation, reconciliation, limit, monitoring, audit, or evidence control?
3. Who owns, performs, reviews, approves, and may override it?
4. What scope, trigger / frequency, mechanism, tolerance, and evidence apply?
5. What exception, failure, escalation, compensating control, and residual-risk route exists?
6. How will design adequacy and later operating effectiveness be evaluated without claiming Phase 02 has executed the control?

## 11.3 Minimum Control Record

~~~yaml
business_control_id:
name:
control_objective:
control_type:
risk_refs: []
rule_policy_obligation_refs: []
process_decision_information_refs: []
business_scope:
mechanism:
owner:
performer_role_refs: []
reviewer_or_approver_refs: []
segregation_constraints: []
trigger_or_frequency:
tolerance_or_threshold:
required_evidence: []
evidence_owner:
exception_and_override_route:
compensating_control_refs: []
failure_and_escalation:
design_status:
operating_status: NOT_EVALUATED_IN_PHASE_02
review_or_test_expectation:
residual_risk_ref:
standards_and_gov_009_refs: []
source_refs: []
status:
downstream_realization_refs: []
reopen_triggers: []
~~~

## 11.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover activation, objective, risk / obligation coverage, type, owner, performer / reviewer separation, evidence, frequency, exceptions, compensating treatment, residual-risk route, and downstream realization. Outputs are the control register, segregation matrix, evidence expectations, control gaps, and requirement / assurance derivation links.

~~~text
Risk / BR / Policy / GOV-009 → CTRL → Process / Decision / Role / INFO
CTRL → BREQ / Product constraint → SEC / PRIV / ACC / AUD / NFR / DR requirement
CTRL Design → Later implementation evidence → Verification → Operational evidence
~~~

Verification in Phase 02 confirms design coherence and traceability, not operating effectiveness. BUS-009 is complete when all activated material risks and obligations have a control, approved gap, authorized alternate treatment, or explicit residual-risk decision route.

Reopen on risk, rule, policy, regulation, contract, process, role, authority, information, standard applicability, exception, control failure, audit finding, evidence, residual risk, or implementation feedback change.

## 11.5 Artifact-Specific Validation Rules

~~~text
BUS9-CVAL-001  Every control traces to a material risk, rule, policy, process, decision, information obligation, or GOV-009 entry.
BUS9-CVAL-002  Rule and control remain separate: the rule governs behavior and the control reduces violation risk.
BUS9-CVAL-003  Control owner, performer, reviewer, approver, trigger or frequency, mechanism, and evidence are explicit where applicable.
BUS9-CVAL-004  Critical financial, governance, security, or evidence flows evaluate create, approve, execute, reconcile, and audit segregation.
BUS9-CVAL-005  Exception, override, failure, escalation, compensating control, and residual-risk routes remain governed.
BUS9-CVAL-006  Phase 02 design review cannot be mislabeled as implemented or operating-effective control evidence.
BUS9-CVAL-007  Conditional non-activation includes risk / obligation rationale, owner, evidence, approval, downstream effect, and reopen condition.
BUS9-CVAL-008  UX, schedule, cost, or technical preference cannot silently remove a required control or evidence obligation.
~~~

---

# 12. BUS-010 — Business Information Model Contract

~~~yaml
contract_id: CONTRACT-BUS-010
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-010
artifact_name: Business Information Model
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: BUS-002, BUS-004 through BUS-009, business definitions, policies, standards, and authoritative information sources
primary_downstream: BUS-001, BUS-005 through BUS-012, PROD-002, REQ-001, EXP-001, and later data architecture
~~~

## 12.1 Purpose, Boundary, and Applicability

BUS-010 defines business-level information concepts, meaning, ownership, authoritative source, key attributes, sensitivity, state, lifecycle, creation / change / validation / consumption responsibilities, and links to business behavior.

BUS-010 is CORE. A business information concept is not a database table, entity class, API payload, field list, schema, or storage decision. One business concept may later map to multiple technical objects. Phase 02 records only attributes and lifecycle details needed to govern business meaning and decisions.

## 12.2 Accountabilities, Inputs, and Questions

- **Owner:** business information / domain model owner.
- **Information owners and stewards:** approve meaning, authoritative source, lifecycle, quality, sensitivity, and change responsibility.
- **Process, decision, rule, and control owners:** confirm required use and state semantics.
- **AI:** may identify candidate concepts and term conflicts; it cannot invent authoritative source, ownership, legal classification, retention, or lifecycle truth.

Inputs include domain terminology, processes, decisions, rules, controls, exceptions, policies, current data / document sources, state models, derived calculations, information risks, and GOV-009 obligations.

Each concept answers:

1. What does the concept mean to the business and which terms are synonyms or conflicts?
2. Who creates, owns, changes, validates, consumes, shares, retains, and disposes it?
3. What is the authoritative business source, or what source gap exists?
4. Which key business attributes and derived values are decision-relevant?
5. Which states, transitions, lifecycle events, sensitivity, consent, evidence, retention, or locality obligations apply?
6. Which processes, decisions, rules, controls, KPIs, product implications, and requirements use it?

## 12.3 Minimum Information Concept Record

~~~yaml
business_information_id:
name:
business_definition:
synonyms: []
disallowed_or_conflicting_terms: []
business_domain_refs: []
owner:
steward_roles: []
create_change_validate_consume_roles: []
authoritative_source:
source_status:
key_business_attributes: []
derived_information_rule_refs: []
states: []
state_transition_rule_refs: []
lifecycle_events: []
sensitivity_and_handling:
retention_or_disposition_obligations: []
privacy_consent_or_rights_refs: []
evidence_and_audit_refs: []
process_decision_rule_control_refs: []
kpi_refs: []
standards_and_gov_009_refs: []
quality_expectations: []
external_exchange_or_dependency_refs: []
status:
source_refs: []
downstream_derivation_refs: []
reopen_triggers: []
~~~

## 12.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover business definition, identity, ownership, authoritative source, key attributes, derived logic, state / lifecycle, sensitivity, retention / disposition, quality, evidence, and downstream use. Outputs are the concept model, glossary, ownership / source view, lifecycle and state links, term conflicts, and derivation guidance.

~~~text
Domain / PROC / DEC / BR / CTRL → INFO Concept / State / Attribute
INFO Derived Value → BR Calculation
INFO / GOV-009 → Product responsibility → Data / Privacy / Security / Audit requirements → Data architecture
~~~

Verification checks meaning, ownership, source, lifecycle, state-rule alignment, proportionality, term consistency, and technology neutrality. BUS-010 is complete when critical business concepts are understandable and owned enough for product, requirement, experience, and architecture derivation without inventing business semantics.

Reopen on domain terminology, ownership, source, process, decision, rule, control, lifecycle, sensitivity, retention, privacy, standard applicability, external exchange, KPI, data evidence, or downstream mapping change.

## 12.5 Artifact-Specific Validation Rules

~~~text
BUS10-CVAL-001  Every material information concept has business meaning, owner or ownership gap, source status, lifecycle context, and behavioral links.
BUS10-CVAL-002  Business concept, database entity, table, API payload, class, and screen field remain distinct.
BUS10-CVAL-003  Authoritative source is explicit where known; unresolved or conflicting sources remain governed gaps.
BUS10-CVAL-004  Derived business information traces to an approved calculation or derivation rule.
BUS10-CVAL-005  State and lifecycle transitions trace to applicable rules, decisions, roles, and controls.
BUS10-CVAL-006  Sensitivity, privacy, consent, rights, retention, evidence, and locality obligations trace through GOV-009 where applicable.
BUS10-CVAL-007  Key attributes are proportionate to business meaning and do not become a premature technical data dictionary.
BUS10-CVAL-008  Conflicting definitions and synonyms are resolved or explicitly routed before downstream schema and interface design.
~~~

---

# 13. BUS-011 — KPI & Outcome Measurement Model Contract

~~~yaml
contract_id: CONTRACT-BUS-011
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: BUS-011
artifact_name: KPI & Outcome Measurement Model
target_mode: FAMILY_SECTION
default_activation: CORE
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: DISC-007, business objectives, BUS-002 through BUS-010, measurement evidence, and policy obligations
primary_downstream: BUS-001, BUS-012, G2, PROD-002, REQ-001, verification planning, and operations
~~~

## 13.1 Purpose, Boundary, and Applicability

BUS-011 defines how approved business objectives and outcomes will be measured. It governs KPI identity, meaning, formula / method, unit, population, baseline, target, tolerance, period, cadence, source, quality, owner, interpretation, guardrails, and maturity.

BUS-011 is CORE. Objective and KPI remain distinct: the objective states desired business change; the KPI measures progress or result. A measurement gap may be valid at G2 when explicitly governed and non-blocking. AI may propose a KPI but cannot invent baseline, target, source quality, or approval.

## 13.2 Accountabilities, Inputs, and Questions

- **Owner:** business outcome / performance owner.
- **Metric owner and data steward:** confirm definition, source, formula, quality, cadence, and interpretation.
- **Objective, capability, and process owners:** confirm decision usefulness and guardrails.
- **AI:** may suggest candidates and detect metric ambiguity; it cannot fabricate values, measurement results, source reliability, or target approval.

Inputs include DISC-007 outcomes and success signals, business objectives, capabilities, processes, decisions, information concepts, current metrics, measurement evidence, policies, targets, risks, and known data limitations.

Each KPI answers:

1. Which objective, outcome, capability, process, risk, or obligation does it measure?
2. Is it leading, lagging, input, process, outcome, quality, control, or guardrail measure?
3. What exact formula / method, unit, population, exclusions, aggregation, period, and cadence apply?
4. What authoritative source, freshness, completeness, quality, privacy, and evidence limitations apply?
5. What baseline, target, tolerance, owner, approval status, and due event apply?
6. What undesirable optimization, counter-metric, interpretation limit, or measurement gap must remain visible?

## 13.3 Minimum KPI Record

~~~yaml
kpi_id:
name:
business_definition:
measure_type:
objective_and_outcome_refs: []
capability_and_process_refs: []
formula_or_method:
unit:
population_and_scope:
inclusions: []
exclusions: []
aggregation:
measurement_period:
cadence:
authoritative_source_ref:
source_freshness:
data_quality_and_limitations: []
baseline:
baseline_evidence_ref:
target:
target_authority_ref:
tolerance_or_threshold:
owner:
steward:
status:
leading_or_lagging:
guardrails_or_counter_metrics: []
privacy_control_or_standards_refs: []
interpretation_rules: []
measurement_gap:
downstream_verification_and_operations_refs: []
reopen_triggers: []
~~~

## 13.4 Decisions, Traceability, Verification, Exit, and Reopen

Decisions cover metric identity, usefulness, type, formula, source, scope, cadence, baseline / target status, owner, guardrails, quality, and gap treatment. Outputs are the KPI model, objective-to-measure coverage, measurement gaps, source / quality dependencies, target approvals, and downstream verification / operational monitoring guidance.

~~~text
PRB / OUT / OBJ → KPI
CAP / PROC / CTRL / INFO → KPI Method and Source
KPI → Product KPI / Requirement acceptance / Verification / Operational measure
~~~

Verification reproduces formula and sample interpretation, confirms source and scope, distinguishes unknown from zero, and checks that target is authorized. BUS-011 is complete when major objectives have an approved success measure or explicit non-blocking measurement gap, and no metric invites material ungoverned optimization.

Reopen on objective, outcome, process, capability, formula, population, source, quality, baseline, target, tolerance, cadence, guardrail, policy, standard, privacy, or measurement evidence change.

## 13.5 Artifact-Specific Validation Rules

~~~text
BUS11-CVAL-001  Every KPI traces to an approved objective, outcome, capability, process, control, risk, or governed obligation.
BUS11-CVAL-002  Objective, success signal, KPI definition, baseline, target, threshold, and measurement result remain separate.
BUS11-CVAL-003  Formula or method, unit, population, exclusions, aggregation, period, cadence, and owner are reproducible where applicable.
BUS11-CVAL-004  Baseline and target have evidence and authority or remain explicit unknown / pending values; AI cannot invent them.
BUS11-CVAL-005  Source identity, freshness, quality, privacy, completeness, and interpretation limitations remain visible.
BUS11-CVAL-006  Guardrails or counter-metrics are evaluated where optimizing one KPI could harm another outcome or control.
BUS11-CVAL-007  Activity volume alone cannot masquerade as a business outcome measure without approved rationale.
BUS11-CVAL-008  Every major objective has KPI direction or an owned, non-blocking measurement gap before G2.
~~~

---

# 14. Phase 02 Family Completion Contract

The BUS-002 through BUS-011 family is complete for an activated Phase 02 scope only when:

1. every core logical artifact has a versioned governed representation;
2. every conditional artifact has an approved applicability or NOT_APPLICABLE disposition;
3. capability, value, operating, process, rule, decision, role, control, information, and KPI meanings remain separate;
4. current, target, and transitional states remain identifiable;
5. material objects have owners or explicit authority gaps;
6. exceptions, conflicts, dependencies, risks, assumptions, and open questions are governed;
7. GOV-009 obligations have canonical Phase 02 object links and downstream derivation flags;
8. BUS-001 references rather than duplicates the canonical family objects;
9. BUS-012 can validate the exact versions against all eighteen G2 domains;
10. downstream product and requirements work can proceed without inventing material business behavior.

This completion statement does not approve G2. BUS-012 provides validation evidence, and the designated G2 authority records the gate outcome.
