# Core Artifact Contract — EXP-020 Product Design Handoff

~~~yaml
contract_id: CONTRACT-EXP-020
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: EXP-020
artifact_name: Product Design Handoff
owning_phase: Phase 05 - Experience Architecture
gate_or_baseline: G4A - Experience Baseline / EBL - Experience Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: Accepted EXP-001 through EXP-019 versions, G4A decision and conditions, RBL, GOV-008, GOV-009, and governance registers
primary_downstream: Phase 06 Product Design, G4B Design Baseline, Solution Architecture, Engineering Readiness, Verification, and change governance
semantic_source: ../../../Phase_05_Experience_Architecture.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

EXP-020 is the versioned human- and machine-readable transfer contract for the accepted Experience Baseline after G4A. It tells Product Design exactly what must be realized for each actor, journey, flow, destination, view, route, state, interaction, content responsibility, responsive / platform mode, accessibility context, localization / RTL context, error / recovery behavior, and validation condition.

It answers: **What exact experience logic was handed to Product Design, for which scope and priority, what must Design realize and evidence, which decisions remain open but non-blocking, what is prohibited from changing silently, and how will acknowledgement and later change propagate?**

EXP-020 is not the EBL, G4A approval, final design brief, Figma file, screen list, component specification, Design System, architecture, implementation ticket, or verification result. It references canonical Experience truth and owns transfer / allocation integrity only.

---

# 2. Scope and Applicability

EXP-020 is CORE whenever Phase 05 hands an accepted route to Phase 06. A handoff instance is scoped by product, EBL version, release, market, platform, channel, language / direction, actor / acting capacity, accessibility / operating context, standards profile, Design domain / team, and intended G4B route.

Separate packages may be issued by product area, journey, platform, channel, language, market, accessibility context, or Design team, but all derive from one exact manifest and preserve canonical IDs, versions, conditions, exclusions, access controls, and change identity.

A partial handoff is permitted only when G4A explicitly authorizes the slice, no omitted experience obligation invalidates it, dependencies / exclusions are known, receiver conditions are acknowledged, and controlled completion and change routes exist.

NOT_APPLICABLE requires an authorized alternate Design-input mechanism with equivalent baseline identity, allocation, state / variant coverage, traceability, acknowledgement, integrity, access, change, and reopen semantics.

---

# 3. Accountabilities

- **Owner:** Experience Handoff owner accountable for manifest accuracy, package integrity, distribution, acknowledgements, findings, supersession, and change propagation.
- **Experience authority:** confirms packages reproduce accepted EBL logic without unauthorized narrowing or invention.
- **G4A authority:** confirms route, conditions, restrictions, affected scope, and partial-handoff permissions match the decision.
- **Product Design lead:** accepts responsibility for realization, Design decisions, evidence, deviations, and G4B preparation within assigned scope.
- **Design System / component owner:** acknowledges reusable behavior, states, variants, accessibility, localization, responsive, content, and platform implications where allocated.
- **Content Design / localization / accessibility specialists:** acknowledge allocated content, language / direction, criterion-linked, and validation obligations.
- **Requirements and Product authorities:** receive contradictions or scope questions that require upstream decision rather than Design interpretation.
- **Architecture / Engineering / Verification receivers:** receive Design-adjacent constraints or evidence routes without using the handoff to replace their own baselines.
- **AI / automation:** may generate scoped packages, check IDs and hashes, compare revisions, and route notices; it cannot design by implication, reinterpret logic, fabricate acknowledgement, waive conditions, or approve G4B.

---

# 4. Required Inputs

1. Exact accepted EBL identity and version.
2. G4A outcome, authority, timestamp, rationale, conditions, affected scope, downstream route, and reopen triggers.
3. Exact EXP-001 through EXP-017 canonical versions and applicability dispositions.
4. EXP-018 derived coverage view with GOV-008 revision, scope, filters, freshness, and limitations.
5. EXP-019 validation record, findings, evidence scope, limitations, conditions, and Design follow-ups.
6. Exact RBL and requirement / acceptance refs relevant to Design, including G3B conditions.
7. GOV-009 Experience links and Design / Verification derivation obligations.
8. Receiver identities, assigned scope, authority, access classification, target tool / repository context where known, expected outputs, acknowledgement authority, and due event.

---

# 5. Required Questions

1. Which exact EBL, G4A decision, release, actors, journeys, contexts, platforms, languages / directions, standards profiles, and object versions are transferred?
2. Which Design owner must realize each journey, flow, destination, view, route, state, interaction, content, responsive, accessibility, localization, and recovery obligation?
3. Which Design decisions remain open legitimately, and which Experience decisions are already fixed or change-controlled?
4. Are all normal, alternate, loading, empty, partial, error, unauthorized, not-found, conflict, offline, unknown-outcome, expired, success, interruption, and recovery states allocated?
5. Are responsive, platform, channel, input, orientation, localization, RTL, accessibility, content, document, notification, security, privacy, and third-party variants explicit?
6. Which validation findings and conditions must Design resolve, preserve, re-test, or provide evidence for?
7. Which source file / page / component / prototype identities may receive Design realization without becoming the owner of Experience truth?
8. What constitutes package integrity, successful delivery, acknowledgement, partial acceptance, rejection, supersession, withdrawal, and stale status?
9. How does Design report contradiction, ambiguity, infeasibility, missing state, or proposed experience deviation without silently editing the EBL?
10. Can Design begin and prepare G4B without inventing journey, navigation, state, interaction, content, responsive, accessibility, localization, or recovery logic?

---

# 6. Handoff State Model

~~~text
DRAFT
READY_FOR_ISSUE
ISSUED
DELIVERED
ACKNOWLEDGED
PARTIALLY_ACKNOWLEDGED
REJECTED
SUPERSEDED
WITHDRAWN
STALE
~~~

Design allocation status:

~~~text
ACCEPTED
ACCEPTED_WITH_CONDITIONS
PARTIALLY_ACCEPTED
REJECTED
PENDING
NOT_APPLICABLE
~~~

Delivery, acknowledgement, allocation acceptance, Design completion, Design validation, G4B approval, implementation, and verification remain separate. File delivery or Figma access does not prove understanding or acceptance. Receiver rejection creates a governed issue / change route; it does not authorize local rewriting.

---

# 7. Minimum Product Design Handoff Manifest

~~~yaml
product_design_handoff_id:
handoff_version:
project_id:
product_id:
ebl_id:
ebl_version:
g4a_decision_ref:
g4a_outcome:
rbl_and_g3b_refs: []
release_scope_ref:
scope_contexts:
  actors_and_acting_capacities: []
  markets: []
  platforms_and_channels: []
  languages_and_directions: []
  accessibility_and_operating_contexts: []
  standards_profiles: []
artifact_versions:
  exp_001:
  exp_002:
  exp_003:
  exp_004:
  exp_005:
  exp_006:
  exp_007:
  exp_008:
  exp_009:
  exp_010:
  exp_011:
  exp_012:
  exp_013:
  exp_014:
  exp_015:
  exp_016:
  exp_017:
  exp_018_view:
  exp_019:
canonical_package_refs: []
package_hashes_or_integrity_refs: []
gov_008_revision:
gov_009_entries: []
included_experience_object_refs: []
excluded_refs_and_reasons: []
conditional_or_deferred_refs: []
design_obligations: []
state_and_variant_coverage: []
content_and_message_responsibilities: []
validation_findings_and_evidence_obligations: []
dependencies: []
risks_assumptions_decisions_questions_changes: []
g4a_conditions: []
prohibited_design_assumptions_and_changes: []
access_classification:
issued_by:
issued_at:
receiver_packages: []
acknowledgements: []
rejections_or_partial_acceptance: []
change_notification_route:
supersedes:
superseded_by:
status:
reopen_triggers: []
~~~

---

# 8. Minimum Design Obligation Record

~~~yaml
design_obligation_id:
product_design_handoff_id:
source_experience_object_refs_and_versions: []
requirement_and_acceptance_refs: []
gov_009_refs: []
actor_goal_context_refs: []
scenario_journey_flow_refs: []
destination_view_route_entry_refs: []
state_refs: []
interaction_content_error_recovery_refs: []
responsive_platform_channel_input_variants: []
accessibility_rules_and_criteria: []
localization_rtl_and_market_variants: []
security_privacy_and_sensitive_content_rules: []
design_responsibility:
expected_design_output_type:
expected_component_pattern_or_flow_scope:
design_decisions_allowed: []
design_changes_prohibited_without_approval: []
validation_and_evidence_expectations: []
dependencies_and_sequence: []
owner:
due_event_or_gate:
status:
acknowledgement_ref:
design_realization_refs: []
deviation_issue_or_change_refs: []
~~~

---

# 9. Minimum Receiver Package

~~~yaml
receiver_package_id:
product_design_handoff_id:
handoff_version:
receiver_id:
receiver_role_or_team:
receiver_authority_scope:
design_domain_platform_or_purpose:
package_scope:
included_design_obligation_refs: []
canonical_experience_refs: []
requirements_acceptance_and_traceability_refs: []
state_and_variant_matrix_refs: []
content_and_message_refs: []
accessibility_localization_responsive_and_platform_refs: []
conditions_findings_and_evidence_needs: []
dependencies_and_sequence: []
prohibited_assumptions_and_changes: []
access_and_redaction_rules: []
target_design_tool_or_repository_ref:
package_format:
package_location:
package_hash_or_integrity_ref:
issued_at:
delivery_status:
delivered_at:
acknowledgement_status:
acknowledged_by:
acknowledged_at:
receiver_findings: []
issue_deviation_or_change_refs: []
status:
~~~

---

# 10. Design Realization Boundary

Product Design may decide visual hierarchy, composition, typography, color, spacing, imagery, motion treatment, component realization, visual affordance, responsive layout solution, and Design System contribution within approved constraints.

Product Design may not silently change:

- actor, goal, context, scenario, journey, or flow meaning;
- information-domain or destination responsibility;
- navigation, context persistence, route / entry, back / return, or acting-capacity semantics;
- required states, consequences, error, interruption, recovery, or support behavior;
- interaction contract, action meaning, status vocabulary, content responsibility, or sensitive disclosure boundary;
- requirement, acceptance, applicable accessibility criterion, localization / RTL rule, responsive priority, security / privacy obligation, or G4A condition.

Every material deviation records source object, proposed delta, reason, alternatives, Design / Experience / Requirements / Architecture impact, risk, evidence, decision authority, status, and propagation route. A prettier or technically easier screen is not authority.

---

# 11. Integrity, Delivery, and Acknowledgement

Every issued package records exact canonical versions, generation time, filters, exclusions, access rules, format, location, and checksum or equivalent integrity evidence. Human-readable and machine-readable forms resolve to the same IDs and versions. Target Figma or repository locations are references to realization, not canonical ownership of Experience logic.

Acknowledgement confirms package identity, scope, allocations, conditions, evidence duties, prohibited changes, and notification route. `ACCEPTED_WITH_CONDITIONS` or `PARTIALLY_ACCEPTED` names exact obligations, rationale, owner, evidence, due event, consequence, and issue / change route.

`REJECTED` is required when a package is corrupted, inaccessible, stale, mis-scoped, contradictory, infeasible for the assigned Design route, missing mandatory state / variant context, or inconsistent with G4A. Rejection cannot be treated as approval silence.

Supersession preserves prior identity, receiver history, Design realizations, acknowledgements, deviations, and affected evidence. Withdrawal is authorized, communicated, and accompanied by a safe downstream disposition.

---

# 12. Traceability and Change Impact

Required paths include:

~~~text
Requirement / GOV-009 / Product source
  -> Experience object and EXP-019 validation
  -> G4A decision and exact EBL version
  -> EXP-020 Design obligation and receiver package
  -> Design file / page / component / pattern / prototype realization
  -> Design validation and G4B decision
  -> Engineering handoff / Implementation / Verification / Evidence
~~~

GOV-008 remains canonical for relationships. EXP-020 exposes scoped views, packages, and allocation metadata; it cannot create competing graph truth.

Any approved source, EBL, G4A, requirement, scope, journey, state, content, platform, accessibility, localization, responsive, validation, or condition change identifies affected packages and Design realizations, notifies receivers, marks stale derivatives, routes revalidation / reapproval, and requires re-acknowledgement where material.

Design findings implying product scope, business rules / controls, requirement meaning, standards applicability, or technical feasibility route to Phase 03, Phase 02, Phase 04, GOV-009, or Phase 07 respectively.

---

# 13. Profile Behavior

| Profile | Required handoff behavior |
|---|---|
| Level 1 — Rapid | One compact manifest may cover the small Design scope, but exact versions, critical states / variants, conditions, obligations, integrity, acknowledgement, and change route remain mandatory. |
| Level 2 — Standard | Structured per-team / domain packages, machine-readable obligations, state / variant coverage, acknowledgements, evidence duties, and deviation tracking are required. |
| Level 3 — Comprehensive | Controlled role-based distribution, formal provenance, complete journey / state / variant matrices, specialist obligations, automated impact routing, multi-platform / market separation, and formal re-acknowledgement are required. |

Profile changes packaging and assurance depth, not permission to omit critical recovery, accessibility, localization, or state obligations.

---

# 14. Evidence and Exit Conditions

Evidence may include manifests, package hashes, export logs, access records, delivery receipts, acknowledgements, Design obligation matrices, source-to-frame / component mapping, condition acceptance, receiver findings, deviations, change routes, supersession notices, and re-acknowledgements.

EXP-020 is complete only when:

1. exact EBL, G4A, EXP-001 through EXP-019, RBL, GOV-008, and GOV-009 identities are bound;
2. every authorized Design route has scoped objects, states, variants, content, cross-cutting rules, conditions, and evidence obligations;
3. Design decisions allowed and Experience changes prohibited without authority are explicit;
4. exclusions, deferrals, dependencies, validation limitations, risks, and conditions are visible;
5. package integrity, access, delivery, acknowledgement, rejection, deviation, supersession, and change semantics are operational;
6. Design owners can find canonical truth and report ambiguity or infeasibility without local rewriting;
7. no stale, rejected, inaccessible, unacknowledged, or materially incomplete package is represented as accepted;
8. Phase 06 can begin and prepare G4B without inventing experience logic or applicable obligations.

Reopen on EBL or G4A change, Design receiver / allocation change, package failure, partial / rejected acknowledgement, missed condition, new Design finding, standards-applicability change, stale realization, unauthorized deviation, or failed change notification.

---

# 15. Validation Rules

~~~text
EXP20-CVAL-001  Every handoff binds exact accepted EBL, G4A, EXP-001 through EXP-019, RBL, GOV-008, GOV-009, release, actor, and context versions.
EXP20-CVAL-002  EXP-020 references canonical Experience truth and cannot duplicate it, self-approve G4A / G4B, or upgrade unapproved Design content.
EXP20-CVAL-003  Every Design obligation preserves source IDs, states, variants, content, acceptance, conditions, evidence, access, and integrity metadata.
EXP20-CVAL-004  Delivery, acknowledgement, allocation acceptance, Design realization, Design validation, G4B, implementation, and verification remain separate.
EXP20-CVAL-005  Partial or conditional acceptance names exact obligations, rationale, owner, evidence, due event, consequence, and governed issue / change route.
EXP20-CVAL-006  Product Design can proceed without inventing journey, navigation, state, interaction, content, responsive, accessibility, localization, or recovery logic.
EXP20-CVAL-007  EBL changes identify affected packages and Design realizations, mark stale derivatives, notify receivers, route revalidation, and require re-acknowledgement.
EXP20-CVAL-008  A stale, corrupted, inaccessible, rejected, unacknowledged, deviated, or materially incomplete package cannot be represented as successful Design handoff.
~~~

