# Core Artifact Contract — DES-001 Product Design Direction

~~~yaml
contract_id: CONTRACT-DES-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: DES-001
artifact_name: Product Design Direction
owning_phase: Phase 06 - Product Design
gate_or_baseline: G4B - Design Baseline / DBL - Design Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: Product and Experience Baselines, EXP-020, RBL, brand sources, current Design evidence, platform / market context, GOV-009, and approved constraints
primary_downstream: DES-002 through DES-023, G4B, code / Design System direction, and affected governance registers
semantic_source: ../../../Phase_06_Product_Design.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

DES-001 is the independent source of truth for the approved Product Design direction: the product-specific visual and interaction character, hierarchy, brand relationship, density posture, accessibility / localization posture, representative compositions, constraints, approved and rejected directions, decision rationale, and ownership that guide the Design system and screens.

It answers: **What coherent Design direction should realize the approved product experience, why is it appropriate for these actors and contexts, what alternatives were evaluated or rejected, what remains invariant across modes, and how will later Design decisions demonstrate alignment or request an exception?**

Direction is not a moodboard, visual trend, brand guideline copy, one hero screen, generic style adjectives, AI preference, or permission to redefine Experience logic. It governs Design choices while allowing controlled exploration and evolution.

---

# 2. Scope and Applicability

DES-001 is CORE whenever Product Design is active. Its scope identifies product / sub-product, release, markets, actors, platforms, channels, themes, density modes, languages / directions, accessibility contexts, operating environments, brand relationships, and product stage.

One product may use one direction with explicit platform / domain variants, or separately governed directions for materially different brands, products, audiences, environments, or channels. Variants must preserve common product identity or state why divergence is authorized.

Existing Design or brand assets are evidence, not automatic target truth. Brownfield work classifies current direction and objects as `KEEP`, `CHANGE`, `ADD`, `RETIRE`, or `UNKNOWN` against approved product / Experience needs.

NOT_APPLICABLE requires an authorized alternate Design-direction mechanism for the exact scope with equivalent decisions, constraints, evidence, downstream use, ownership, and reopen behavior.

---

# 3. Accountabilities

- **Owner:** Product Design lead accountable for direction coherence, sources, decision history, and downstream interpretation.
- **Product and Experience authorities:** confirm product identity, users, journey meaning, context, and EBL alignment.
- **Brand authority:** confirms brand inheritance, protected elements, permitted product-UI adaptation, and exceptions.
- **Design System owner:** confirms the direction can be represented through governed foundations, tokens, components, and patterns.
- **Accessibility, content, localization / RTL, platform, security / privacy, and other activated specialists:** challenge direction within their authority.
- **Engineering / Architecture:** challenge feasibility, performance, source, asset, and implementation implications without choosing visual direction unilaterally.
- **G4B authority:** approves the full Design Baseline, not DES-001 in isolation.
- **AI:** may organize sources, generate explorations, compare directions, detect inconsistency, and draft rationale; it cannot invent user / brand evidence, select authority, accept risk, or approve direction.

---

# 4. Required Inputs

1. Exact Product, Requirements, and Experience Baseline identities and gate conditions.
2. EXP-020 Design obligations, actor / context / journey priorities, states, content, responsive, accessibility, localization / RTL, and validation findings.
3. Product identity, positioning, brand architecture, approved brand sources, protected / adaptable elements, assets, and licensing.
4. Platform, channel, device, viewport, input, market, language / direction, accessibility, environment, density, and generated-output scope.
5. Existing Design sources, production UI, Design System, components, code, analytics, support / incident evidence, and current-state classification for brownfield work.
6. Product stage, delivery profile, domain overrides, risks, constraints, dependencies, decisions, assumptions, questions, and GOV-009 implications.

---

# 5. Required Questions

1. Which product, actors, contexts, tasks, markets, platforms, modes, languages, and risks must the direction serve?
2. What visual hierarchy and interaction character support approved goals without obscuring operational density or consequence?
3. Which brand elements are inherited, adapted, product-specific, or prohibited, and who has authority?
4. What is the intended posture for density, contrast, color, typography, imagery, iconography, motion, content, and platform convention?
5. How will accessibility, localization, RTL, responsive recomposition, security / privacy, data density, documents, and third parties influence the direction structurally?
6. Which representative compositions prove the direction works beyond a marketing-style or happy-path screen?
7. Which alternatives were explored, what evidence / criteria distinguished them, and why were directions approved, combined, held, or rejected?
8. Which decisions are direction-level, and which must remain for foundations, components, patterns, screens, or Architecture?
9. How will Design objects demonstrate alignment, record deliberate deviation, and propagate a direction change?
10. Can the direction support the complete EBL without material invention, forced uniformity, or ungoverned exceptions?

---

# 6. Direction Lifecycle and Decision Separation

Direction lifecycle:

~~~text
CAPTURED
EXPLORING
CANDIDATE
IN_REVIEW
APPROVED
APPROVED_WITH_CONDITIONS
REJECTED
SUPERSEDED
RETIRED
~~~

Evidence status:

~~~text
NOT_EVALUATED
PARTIAL
SUPPORTED
CONTRADICTED
VALIDATED_FOR_SCOPE
INVALIDATED
~~~

Direction approval, evidence status, Design-object approval, publication, adoption, verification, and G4B remain separate. An attractive exploration is not approved; an approved direction does not prove every component or screen complies.

---

# 7. Minimum Design Direction Record

~~~yaml
design_direction_id:
direction_version:
product_and_release_scope_refs: []
upstream_baseline_refs: []
actors_contexts_and_priority_journeys: []
markets_platforms_channels_and_modes: []
languages_directions_and_accessibility_contexts: []
product_stage_and_profile:
direction_statement:
design_principles: []
visual_hierarchy_posture:
interaction_character:
density_posture:
brand_relationship:
  inherited: []
  adapted: []
  product_specific: []
  prohibited: []
foundation_implications:
  typography: []
  color_and_theme: []
  layout_and_density: []
  iconography_assets_and_imagery: []
  motion: []
content_posture: []
responsive_platform_input_posture: []
accessibility_posture: []
localization_and_rtl_posture: []
security_privacy_and_sensitive_data_posture: []
data_dense_document_notification_posture: []
constraints_and_non_negotiables: []
representative_composition_refs: []
approved_direction_candidates: []
rejected_or_held_candidates: []
decision_criteria_and_evidence: []
decision_authority_refs: []
owner:
approval_status:
conditions: []
downstream_obligations: []
exception_route:
supersedes:
superseded_by:
reopen_triggers: []
~~~

---

# 8. Direction Exploration Contract

Each exploration records candidate ID, exact source / revision, hypothesis, criteria, intended scope, representative compositions, conditions tested, strengths, weaknesses, accessibility / localization / responsive / platform implications, feasibility findings, evidence limitations, decision, rationale, and relation to the approved direction.

Explorations must include product-realistic composition and state evidence proportionate to risk. A polished dashboard alone cannot prove a consumer flow, operational form, Arabic RTL mode, error recovery, dense data, mobile recomposition, document, or accessibility-critical journey.

Rejected directions remain discoverable to prevent repeated debate and silent reuse. Rejection records what was rejected—the entire direction, one element, or its use in a specific context.

---

# 9. Brand and Product UI Boundary

Brand source controls brand identity within its authority. Product Design decides how that identity realizes usable product UI while preserving requirements, Experience, accessibility, platform conventions, and operating context.

DES-001 records:

- brand source, version, authority, protected elements, and licensing;
- elements directly inherited versus adapted to product UI;
- product-specific hierarchy, density, component, content, data, motion, and state needs;
- conflicts between brand presentation and accessibility / usability / platform obligations;
- approved exceptions, risk, evidence, expiry, and change route.

Brand consistency cannot justify unreadable typography, insufficient contrast, color-only meaning, hidden state, inaccessible motion, or harmful forced uniformity.

---

# 10. Traceability and Change Impact

Required paths include:

~~~text
Product / Brand / Requirement / Experience / GOV-009 source
  -> DES-001 direction decision and evidence
  -> Foundation / Token / Component / Pattern / Screen implication
  -> Design source and validation evidence
  -> DES-023 code / Engineering mapping
~~~

Every downstream Design object cites the exact direction version or governed exception. Direction changes trigger GOV-007, GOV-008 traversal, affected-source / token / component / screen / asset / content / code review, receiver notification, revalidation, migration, and DBL status impact.

---

# 11. Profile Behavior

| Profile | Required direction behavior |
|---|---|
| Level 1 — Rapid | One concise approved direction with representative critical compositions, core foundation implications, constraints, evidence, and downstream decisions is sufficient. |
| Level 2 — Standard | Multiple explored directions or explicit alternative analysis, modular foundation implications, representative state / platform evidence, specialist review, and formal decision are required. |
| Level 3 — Comprehensive | Multi-brand / platform / market variants, formal decision criteria, independent accessibility / localization / feasibility assurance, broader stress testing, adoption / migration strategy, and controlled exception review are required. |

Profile changes exploration and evidence depth, not the need for a coherent product-specific direction.

---

# 12. Evidence and Exit Conditions

Evidence may include approved source snapshots, brand-source comparison, representative compositions, token / component feasibility, state / responsive / RTL / accessibility stress examples, critique records, domain reviews, usability / content / technical findings, candidate comparisons, decisions, and acknowledgements.

DES-001 is complete only when:

1. exact product, EBL, RBL, scope, profile, context, and GOV-009 sources are bound;
2. direction statement, principles, hierarchy, character, density, brand, cross-cutting posture, and non-negotiables are explicit;
3. representative product compositions prove applicability beyond one decorative screen;
4. approved, rejected, held, and combined alternatives retain evidence and rationale;
5. downstream foundation, component, pattern, screen, content, motion, and source obligations are actionable;
6. conflicts and exceptions have authority, evidence, risk, and change routes;
7. Design teams can apply the direction consistently without inventing Experience or requirement meaning;
8. changes can identify all affected Design, code, validation, and handoff objects.

Reopen on material product / Experience / requirement / brand / market / platform / language / accessibility / security / privacy / content / stage / profile change, failed validation, new adoption evidence, or downstream inconsistency.

---

# 13. Validation Rules

~~~text
DES1-CVAL-001  DES-001 binds exact product, RBL, EBL, EXP-020, brand, platform, market, language, accessibility, profile, and GOV-009 sources.
DES1-CVAL-002  Direction, principle, brand rule, foundation, token, component, pattern, screen, visual trend, and implementation mechanism remain distinct.
DES1-CVAL-003  Generic modern, clean, intuitive, premium, simple, delightful, or accessible adjectives cannot satisfy an operational direction alone.
DES1-CVAL-004  Representative compositions cover product-realistic hierarchy, states, density, responsive, accessibility, localization / RTL, content, and risk proportionately.
DES1-CVAL-005  Approved, conditional, held, rejected, and superseded directions retain decision criteria, authority, evidence, limitations, and lineage.
DES1-CVAL-006  Brand inheritance cannot override mandatory usability, accessibility, security, privacy, platform, or Experience obligations silently.
DES1-CVAL-007  Every downstream Design object cites the exact direction version or a governed exception with impact and evidence.
DES1-CVAL-008  Direction changes propagate to affected sources, tokens, components, patterns, screens, assets, content, code mappings, validation, and DBL status.
~~~

