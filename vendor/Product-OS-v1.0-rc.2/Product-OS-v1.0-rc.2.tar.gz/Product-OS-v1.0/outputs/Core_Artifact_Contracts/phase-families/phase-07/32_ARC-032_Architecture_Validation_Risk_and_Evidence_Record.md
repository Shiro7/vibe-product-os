# Core Artifact Contract — ARC-032 Architecture Validation, Risk, and Evidence Record

~~~yaml
contract_id: CONTRACT-ARC-032
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: ARC-032
artifact_name: Architecture Validation, Risk, and Evidence Record
owning_phase: Phase 07 - Solution Architecture
gate_or_baseline: G5A - Architecture Baseline / ABL - Architecture Baseline
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: ARC-001 through ARC-031, candidate ARC-033, PBL / RBL / EBL / DBL, governance registers, GOV-009, architecture sources, and validation evidence
primary_downstream: G5A decision, ABL status, accepted ARC-033, Engineering Readiness, Implementation, Verification, Release, and Operations
semantic_source: ../../../Phase_07_Solution_Architecture.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

ARC-032 is the independent evidence and control record showing how the exact Architecture Baseline candidate, canonical views, decisions, controls, risks, exceptions, debt, traceability, and Engineering handoff were reviewed, tested, challenged, supported, contradicted, corrected, conditioned, or left unresolved before G5A.

It binds exact ARC-001 through ARC-031 versions plus the candidate ARC-033 version, upstream baselines, architecture source revisions, validation methods, participants / authoritative reviewers, findings, severity, treatments, limitations, residual risk, conditions, acknowledgements, and all thirty G5A check domains.

It answers: **Does the approved product have a coherent, secure, private, operable, resilient, measurable, traceable, validated, evolvable, and Engineering-ready architecture—and what exact evidence, risks, or conditions support that conclusion?**

Validation is not a diagram review, technology presentation, ADR count, cloud-console screenshot, repository scan, proof-of-concept demo, checklist completion, matrix row count, deployment presence, vendor assurance, stakeholder confidence, or AI opinion. ARC-032 supplies reproducible evidence to the G5A authority; it does not self-approve the gate.

---

# 2. Scope and Applicability

ARC-032 is CORE whenever Phase 07 is active. It validates the exact ABL identity / candidate, release, system of interest, current / target / transition states, architecture profile / domain overrides, markets, platforms, tenants, regions, languages, accessibility contexts, data classes, integrations, third parties, generated outputs, runtime environments, canonical sources, and Engineering targets.

Different products, releases, architecture domains, systems, platforms, tenants, regions, environments, providers, regulatory scopes, risk classes, or transition states may require separate activities and dispositions within one record or separate scoped records.

Prior evidence may be reused only when object / source revision, architecture state, scope, method, environment, data, workload, participants / reviewers, tool behavior, evidence period, upstream baselines, GOV-009 version, risks, and limitations remain fit for the current G5A decision.

NOT_APPLICABLE is valid only when an authorized alternate architecture baseline and gate mechanism replaces Phase 07 for the exact route with equivalent object identity, source control, decisions, controls, risk / evidence coverage, ARC-033 behavior, authority, and reopen control.

---

# 3. Accountabilities

- **Owner:** Architecture-validation owner independent enough to report structural, data, security, privacy, reliability, performance, deployment, operability, compatibility, source, and handoff defects truthfully.
- **Architecture object owners:** maintain exact object / view / ADR / contract versions, canonical sources, lifecycle status, Engineering mappings, verification expectations, and responses to findings.
- **Product, Requirements, Experience, and Design authorities:** confirm architecture alignment with approved upstream truth and distinguish upstream gaps from architecture defects.
- **Security, privacy, data, identity, reliability, performance, platform, accessibility, localization, and operations specialists:** validate activated obligations within their authority.
- **Engineering and Verification:** challenge implementability, testability, repository / module mapping, interface precision, fitness expectations, migration, rollout, and evidence feasibility without accepting architecture risk.
- **Risk and exception authorities:** accept residual risk or approve exceptions only within explicit delegated scope, evidence, duration, and conditions.
- **G5A decision authority:** decides `PASS`, `PASS_WITH_CONDITIONS`, `HOLD`, or `REJECT` for the exact ABL candidate.
- **Downstream receivers:** acknowledge baseline identity, restrictions, conditions, risks, assumptions, debt, source access, and prohibited invention.
- **AI:** may inspect canonical sources, compare views, detect inconsistency / orphan paths, generate derived coverage, and propose findings; it cannot claim reviews occurred, fabricate evidence, infer current state from diagrams, accept risk, approve exceptions, or decide G5A.

---

# 4. Required Inputs

1. Exact PBL, RBL, EBL, DBL, G3A, G3B, G4A, and G4B identities, outcomes, conditions, and change status.
2. ARC-001 scope, states, profile / overrides, drivers, constraints, principles, assumptions, risks, and authority.
3. ARC-002 quality scenarios and ARC-003 current / target / transition views with source evidence.
4. ARC-004 context / trust boundaries, ARC-005 containers, applicable ARC-006 components, and ARC-007 domains / ownership.
5. ARC-008 data ownership / classification, ARC-009 models, and applicable ARC-010 lifecycle / residency and ARC-011 flows / lineage.
6. Applicable ARC-012 APIs, ARC-013 integrations, ARC-014 asynchronous processing, and ARC-015 connectivity / synchronization.
7. ARC-016 identity, ARC-017 authorization / tenancy / administration, ARC-018 security / threat model, applicable ARC-019 privacy and ARC-020 audit.
8. ARC-021 resilience, ARC-022 performance / capacity / cost, ARC-023 deployment / environment / network, ARC-024 configuration / secrets / keys, and ARC-025 observability.
9. Applicable ARC-026 recovery / continuity and ARC-027 cross-cutting runtime support.
10. ARC-028 compatibility / migration / evolution and ARC-029 ADR set.
11. ARC-030 derived standards / control mapping and ARC-031 derived coverage / traceability view with exact GOV-008 revision, filters, freshness, and limitations.
12. Candidate ARC-033 with ABL / source versions, Engineering targets, repository / module expectations, contracts, controls, fitness functions, rollout / recovery obligations, conditions, and receiver acknowledgement status.
13. GOV-003 decisions, GOV-004 risks, GOV-005 assumptions, GOV-006 questions, GOV-007 changes, GOV-008 paths, and GOV-009 architecture obligations.
14. Review, analysis, modeling, proof-of-concept, benchmark, threat, privacy, resilience, restore, migration, compatibility, fitness, source, coverage, and handoff evidence.

---

# 5. Required Questions

1. Which exact ABL candidate, ARC-001 through ARC-033 candidate versions, sources, states, release, profile, systems, contexts, and Engineering targets are being validated?
2. Which validation method is fit: structured review, model / contract inspection, scenario analysis, threat modeling, privacy review, proof of concept, benchmark, failure injection, restore exercise, migration rehearsal, compatibility test, fitness function, traceability traversal, source / drift inspection, or another governed method?
3. Do participants / reviewers have relevant knowledge, independence, current evidence, and authority for the exact architecture domain?
4. Does the architecture realize approved upstream baselines without inventing or suppressing product, requirement, experience, design, or standards meaning?
5. Are current evidence, target decisions, transition actions, implemented state, deployed state, and observed runtime state truthfully separated?
6. Are material quality requirements expressed as measurable scenarios linked to mechanisms and verification?
7. Are ownership, trust / tenant boundaries, data authority, interfaces, identity, authorization, security, privacy, audit, failure, recovery, operability, and evolution coherent across views?
8. Do ADRs match the architecture objects and views they govern, and are tradeoffs, risks, reversibility, consequences, and reopen conditions visible?
9. Does every applicable GOV-009 obligation resolve to a mechanism, decision, verification expectation, evidence owner, and governed exception if any?
10. Are canonical source revisions accessible and consistent with ARC-030 / ARC-031 derived views and candidate ARC-033?
11. Which finding is an architecture defect, upstream gap, implementation discovery, operational contradiction, evidence limitation, accepted residual risk, exception, or debt?
12. Which open item blocks G5A, and which can proceed only as an authorized, owned, time-bound, evidence-bound condition?
13. Can Engineering consume ARC-033 without materially guessing boundaries, data, contracts, control placement, failure behavior, migration, deployment, observability, or fitness expectations?

---

# 6. Validation, Finding, Risk, Exception, and G5A Status Separation

Validation activity status:

~~~text
PLANNED
IN_PROGRESS
PARTIAL
COMPLETE
INVALIDATED
SUPERSEDED
~~~

Architecture object / finding disposition:

~~~text
CONFIRMED
SUPPORTED
PARTIALLY_SUPPORTED
CONTRADICTED
CORRECTED
UNRESOLVED
NOT_EVALUATED
NOT_APPLICABLE
~~~

Finding severity:

~~~text
BLOCKER
CRITICAL
MAJOR
MODERATE
MINOR
OBSERVATION
~~~

Risk treatment state:

~~~text
IDENTIFIED
ANALYZED
AVOID
MITIGATE
TRANSFER
ACCEPT_PENDING_AUTHORITY
ACCEPTED
CLOSED
MATERIALIZED
~~~

Exception state:

~~~text
PROPOSED
UNDER_REVIEW
APPROVED_ACTIVE
EXPIRED
REVOKED
CLOSED
~~~

G5A check status:

~~~text
PASS
PASS_WITH_CONDITION
FAIL
BLOCKED
NOT_APPLICABLE
~~~

G5A outcome:

~~~text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
~~~

These dimensions remain separate. An approved ADR may be unimplemented or contradicted by current evidence. A deployed service may violate the target architecture. A passed benchmark may not use representative workload. An accepted risk is not a resolved finding. An active exception cannot silently become the normal baseline. G5A PASS approves Architecture Baseline sufficiency only.

---

# 7. Minimum Architecture Validation Activity Record

~~~yaml
architecture_validation_id:
abl_candidate_id:
abl_candidate_version:
release_system_and_architecture_scope_refs: []
architecture_state: CURRENT | TARGET | TRANSITION
architecture_object_refs_and_versions: []
architecture_source_refs_and_revisions: []
upstream_baseline_requirement_design_and_gov_009_refs: []
environment_region_tenant_platform_data_and_workload_context: []
validation_question:
method:
scenario_model_test_exercise_or_inspection:
acceptance_safety_quality_or_control_criteria: []
participant_or_reviewer_refs: []
relevance_independence_and_authority_scope:
materials_tools_code_infrastructure_or_environment_refs: []
evidence_period:
performed_by:
performed_at:
evidence_refs: []
observations: []
findings: []
finding_severity:
object_disposition:
risk_refs_and_treatments: []
exception_refs_and_expiry: []
architecture_debt_refs: []
source_drift_mapping_and_traceability_findings: []
security_privacy_reliability_performance_and_operability_findings: []
implementation_migration_and_verification_findings: []
limitations_uncertainty_and_bias: []
upstream_gap_or_downstream_follow_up_routes: []
recommended_changes: []
owner:
due_event:
status:
reviewed_by: []
supersedes:
superseded_by:
reopen_triggers: []
~~~

---

# 8. Minimum Architecture Validation Summary

~~~yaml
architecture_validation_record_id:
project_id:
abl_candidate_id:
abl_candidate_version:
upstream_baseline_and_gate_refs: []
validated_release_system_and_architecture_scope:
validated_contexts:
  current_target_and_transition_states: []
  products_markets_platforms_and_channels: []
  tenants_regions_environments_and_networks: []
  data_classes_identities_roles_and_trust_boundaries: []
  workloads_failure_modes_recovery_and_operational_contexts: []
  languages_accessibility_outputs_vendors_and_engineering_targets: []
artifact_versions:
  arc_001:
  arc_002:
  arc_003:
  arc_004:
  arc_005:
  arc_006:
  arc_007:
  arc_008:
  arc_009:
  arc_010:
  arc_011:
  arc_012:
  arc_013:
  arc_014:
  arc_015:
  arc_016:
  arc_017:
  arc_018:
  arc_019:
  arc_020:
  arc_021:
  arc_022:
  arc_023:
  arc_024:
  arc_025:
  arc_026:
  arc_027:
  arc_028:
  arc_029:
  arc_030_view:
  arc_031_view:
  arc_033_candidate:
conditional_artifact_dispositions: []
validation_activities: []
coverage:
  scope_drivers_scenarios_states_sources_and_decisions:
  context_structure_domains_data_and_interfaces:
  identity_authorization_security_privacy_and_audit:
  reliability_recovery_performance_cost_and_observability:
  deployment_configuration_cross_cutting_runtime_and_evolution:
  standards_traceability_validation_and_engineering_handoff:
confirmed_objects_and_decisions: []
partial_unresolved_or_contradicted_objects: []
blocking_and_non_blocking_findings: []
current_target_transition_drift_and_source_findings: []
control_risk_exception_and_debt_findings: []
quality_scenario_fitness_and_evidence_gaps: []
traceability_mapping_and_handoff_gaps: []
method_participant_tool_environment_and_evidence_limitations: []
upstream_gaps: []
engineering_verification_release_and_operations_follow_ups: []
conditions: []
residual_risks_and_acceptance_refs: []
active_exceptions_and_expiry_refs: []
g5a_checks: []
recommended_g5a_outcome:
g5a_decision_ref:
approved_by: []
downstream_routes: []
prohibited_downstream_assumptions: []
~~~

---

# 9. G5A Check Contract — All 30 Domains

1. **Scope, profile, and upstream baselines:** exact upstream baseline versions, gate conditions, architecture scope / states, profile, overrides, exclusions, authority, and change status are valid.
2. **Drivers, constraints, principles, and assumptions:** critical drivers / constraints are prioritized, principles state implications, assumptions have validation / expiry, and conflicts are governed.
3. **Quality attribute scenarios:** material NFRs have measurable stimulus-context-response scenarios, mechanisms, priorities, verification, and owners.
4. **Current, target, and transition integrity:** evidence, intent, transition, compatibility, migration, rollback / forward fix, and retirement are not conflated.
5. **System context, external dependencies, and trust boundaries:** boundary, actors, external systems, data / interaction, ownership, criticality, trust / tenant / legal crossings, failure, and fallback are complete.
6. **Container, component, and dependency architecture:** significant responsibilities, interfaces, dependency direction, runtime mapping, data access, controls, scaling, failure, observability, and ownership are coherent.
7. **Domain boundaries and ownership:** domain meaning, vocabulary, rules, data, consistency, commands / queries / events, relationships, and accountable ownership are explicit.
8. **Data ownership and classification:** authoritative sources, owners, writers / readers, purposes, classifications, disclosure, protection, quality, and copy consequences are complete.
9. **Data models, integrity, and concurrency:** applicable conceptual / logical / physical models, identifiers, relationships, invariants, lifecycle states, consistency, transactions, and concurrency controls are fit.
10. **Data lifecycle, retention, deletion, residency, and lineage:** primary, replica, cache, log, analytics, vendor, device, backup, and DR copies have governed lifecycle / location / propagation / evidence.
11. **APIs and machine contracts:** ownership, consumers, schemas, validation, identity, authorization, errors, idempotency, concurrency, limits, versioning, deprecation, SLOs, and observability are explicit.
12. **Integrations and external dependencies:** data, security, privacy, quotas, availability, timeout / retry, unknown outcome, reconciliation, support, change, fallback, exit, and evidence are governed.
13. **Events, jobs, workflows, and synchronization:** semantics, schemas, ordering, delivery, duplicate / idempotency, replay, retry, dead-letter, compensation, conflict, reconciliation, and repair are complete.
14. **Identity, authentication, session, and recovery:** human / service / enterprise identity trust, proofing, assurance, MFA / step-up, federation, sessions, revocation, recovery, monitoring, and audit are governed.
15. **Authorization, tenancy, delegation, and administrative access:** policy authority, decision / enforcement, default deny, isolation, cache / revocation, delegation, support / break-glass access, audit, and verification are complete.
16. **Security architecture and threat model:** assets, boundaries, threats / abuse cases, paths, preventive / detective / response / recovery controls, supply chain, residual risk, and verification are complete.
17. **Privacy, consent, and data rights:** purpose / minimization, processing, consent, disclosure / transfer, rights, analytics, retention / deletion, vendor propagation, evidence, and exceptions are governed.
18. **Audit and evidence:** required events, actor / principal / capacity / tenant context, outcome / reason, integrity, retention, access / disclosure, search / export, coverage, and evidence chain are credible.
19. **Reliability, failure, and reconciliation:** taxonomy, containment, timeout / retry, idempotency, isolation, graceful degradation, unknown outcomes, reconciliation, SLOs, recovery, and tests are coherent.
20. **Backup, restore, disaster recovery, and continuity:** backup scope / separation, RPO / RTO, restore validation, disaster activation, failover / failback, dependencies, exercises, and business-continuity interfaces are adequate.
21. **Performance, capacity, scalability, and cost:** representative workload, end-to-end budgets, bottlenecks, scaling, backpressure, capacity / headroom, fairness, cost behavior, guardrails, and verification are defined.
22. **Deployment, environments, network, and rollback:** topology, isolation, regions / zones, ingress / egress, runtime, production-data controls, deployment strategy, state compatibility, rollback / forward fix, and source control are complete.
23. **Configuration, secrets, keys, and supply chain:** sources, schemas, safe defaults, change / audit, environment separation, access, rotation / revocation, build trust, dependency integrity, leak response, and evidence are complete.
24. **Observability and operational diagnostics:** logs / redaction, correlation, metrics / cardinality, traces, health / readiness, alerts, dashboards, owners, access / retention, and diagnostic scenarios are sufficient.
25. **Accessibility, localization, timezone, money, and generated outputs:** architecture supports applicable semantic / focus / preference behavior, languages / RTL, formats, time, currency, names / addresses, fonts / shaping, documents / email, third parties, and test hooks.
26. **Compatibility, migration, rollout, and evolution:** version policy, client / consumer windows, transition, backfill, parallel run, reconciliation, state compatibility, rollback / forward fix, deprecation, retirement, and debt are governed.
27. **ADR completeness and consistency:** material decisions have context, drivers, alternatives, rationale, authority, consequences, risks, verification, status, supersession, reopen triggers, and agreement with views.
28. **GOV-009 and control mapping:** each active obligation maps to drivers, decisions, mechanisms, affected objects, verification, evidence, exceptions / expiry, and downstream implementation / operations.
29. **Validation, risks, exceptions, and debt:** review scope / evidence / limits are adequate, high-severity findings are resolved, residual risk has authority, exceptions are scoped / expiring, and debt is visible / owned.
30. **Traceability and Engineering readiness:** bidirectional paths, canonical sources, object / interface / data / deployment / control mappings, Phase 08 targets, fitness functions, owners, conditions, ARC-033 acknowledgement, and blocker status are complete.

Each check binds exact artifacts, objects, states, sources, contexts, validation activities, evidence, limitations, findings, risks, exceptions, conditions, owners, and authority. Conditional artifacts require explicit applicability; absence or an empty artifact cannot prove NOT_APPLICABLE.

---

# 10. G5A Outcome Contract

## PASS

The exact ABL candidate is coherent, source-controlled, secure, private, operable, resilient, measurable, traceable, sufficiently validated, evolvable, and Engineering-ready. Blocking findings, unaccepted critical risks, expired / invalid exceptions, hidden debt, and material handoff gaps equal zero.

## PASS_WITH_CONDITIONS

Residual work is non-blocking, exact, owned, time-bound, evidence-bound, authorized, restricted downstream where necessary, acknowledged by receivers, monitored, and unable to force material architecture invention or unacceptable risk.

## HOLD

Used when source truth, boundary / ownership, data, identity, authorization, security / privacy, failure / recovery, critical NFR, migration, standards, validation, risk authority, traceability, or ARC-033 remains materially unresolved.

## REJECT

Used when the proposed ABL conflicts materially with approved upstream baselines, contains unacceptable structural risk, lacks viable implementation / recovery, uses unsupported evidence, or requires substantial architectural rework.

ARC-032 may recommend but cannot issue the outcome. G5A authority, date, rationale, conditions, restrictions, evidence, affected scope, approvals / acknowledgements, risks / exceptions, and reopen triggers are recorded through the governed gate-decision mechanism.

---

# 11. Traceability and Change Impact

Required paths include:

~~~text
Requirement / Design Constraint / GOV-009 / Operational Evidence
  -> Architecture Driver / Quality Attribute Scenario / Risk
  -> ADR / Control / Architecture Object / Canonical Source Revision
  -> ARC-032 Activity / Finding / Treatment / Evidence / G5A Check
  -> G5A Decision and ABL Version
  -> ARC-033 Engineering Mapping / Fitness Function / Condition
  -> Engineering / Implementation / Verification / Release / Operations Evidence
~~~

Any change to upstream baseline, system scope, architecture state, driver, scenario, object, boundary, owner, data, interface, identity, control, dependency, platform, vendor, deployment, configuration, risk, exception, debt, source revision, mapping, or validation evidence triggers impact analysis. Affected results and downstream objects become `STALE` or `REVIEW_REQUIRED` until disposition.

Business, product, requirement, experience, design, standards, implementation, verification, or live-operational contradictions route to their owning phase / control. Phase 07 cannot normalize upstream scope change, missing authority, implementation deviation, or operational failure by redrawing target architecture alone.

---

# 12. Profile Behavior

| Profile | Required validation behavior |
|---|---|
| Level 1 — Rapid | Compact validation may cover the narrow system and release, but every applicable G5A check, critical boundary / data / identity / authorization / failure decision, source, risk, ARC-033 route, and condition remains explicit. |
| Level 2 — Standard | Structured multi-domain review, model / contract inspection, threat / privacy / resilience / performance evidence, traceability, source checks, and handoff assurance are required proportionately. |
| Level 3 — Comprehensive | Independent / segregated assurance, multiple regions / tenants / states, formal control evidence, representative benchmarks, recovery / migration exercises, fitness functions, reproducibility, and condition monitoring are required. |

Profile changes evidence depth, not permission to omit a critical owner, trust boundary, data authority, identity / authorization rule, recovery mechanism, measurable NFR, canonical source, or Engineering mapping.

---

# 13. Evidence and Exit Conditions

Evidence may include governed architecture-source revisions, model / contract reviews, ADR challenge records, repository / schema / infrastructure inspection, current-state runtime evidence, proofs of concept, benchmarks, workload models, threat / privacy analyses, dependency / vendor evidence, failure simulations, restore / DR exercises, migration rehearsals, compatibility tests, fitness-function results, control / coverage traversals, ARC-033 mapping reviews, finding resolutions, risk / exception decisions, and receiver acknowledgements.

ARC-032 is complete only when:

1. exact PBL / RBL / EBL / DBL, ARC-001 through ARC-031, candidate ARC-033, GOV-008, GOV-009, ABL candidate, scope, state, source, and Engineering-target versions are bound;
2. every applicable G5A domain has source, method, relevant authority / participants, evidence, limitations, status, findings, risks, exceptions, and conditions;
3. critical boundaries, ownership, data, interfaces, identity, authorization, controls, failure / recovery, operability, compatibility, migration, and Engineering expectations have adequate validation;
4. current / target / transition contradictions, source drift, orphan paths, decision conflicts, control gaps, unsupported claims, and handoff gaps are resolved or governed;
5. blocker / critical unresolved findings, unowned high risks, unauthorized risk acceptance, expired exceptions, and hidden material debt equal zero for PASS;
6. conditions are non-blocking, exact, owned, time-bound, evidence-bound, restricted, authorized, acknowledged, monitored, and automatically reopen on failure;
7. recommended outcome, residual risks, active exceptions, and G5A decision authority are explicit;
8. ARC-033 is exact, accepted, accessible, and implementable without material architecture invention.

Reopen on ABL / source / upstream change, new system / market / platform / tenant / region / data / integration / runtime scope, changed threat / regulation / vendor, invalidated evidence, failed condition, expired exception, materialized risk, new severe finding, source loss, implementation drift, verification failure, incident contradiction, or incorrect G5A basis.

---

# 14. Validation Rules

~~~text
ARC32-CVAL-001  ARC-032 binds exact upstream baselines, ABL candidate, ARC-001 through ARC-031, candidate ARC-033, GOV-008, GOV-009, scope, state, source, and Engineering-target versions.
ARC32-CVAL-002  Activity status, object / finding disposition, severity, risk treatment, exception state, debt, approval, implementation, verification, G5A check, and G5A outcome remain separate.
ARC32-CVAL-003  Every one of the thirty G5A domains has scoped source evidence, fit method, relevant authority / participants, limitations, status, and conditions.
ARC32-CVAL-004  Diagram review, technology presentation, ADR count, cloud screenshot, repository scan, proof of concept, checklist, matrix rows, deployment presence, vendor claim, or AI confidence cannot substitute for validation.
ARC32-CVAL-005  Blocking ownership, boundary, data, identity, authorization, security / privacy, recovery, critical NFR, source, standards, traceability, risk-authority, or ARC-033 gaps prevent G5A PASS.
ARC32-CVAL-006  Findings, risks, exceptions, debt, and conditions identify exact objects / sources / states / contexts, owner, authority, evidence, due / expiry event, downstream restriction, acknowledgement, and failure route.
ARC32-CVAL-007  Upstream, source, architecture, vendor, implementation, runtime, mapping, risk, exception, or evidence change propagates impact, stale status, revalidation, notification, re-acknowledgement, and re-approval.
ARC32-CVAL-008  ARC-032 supplies evidence and recommendation but cannot self-approve G5A or claim implementation, verification, production resilience / security / accessibility, release safety, or operational success.
~~~
