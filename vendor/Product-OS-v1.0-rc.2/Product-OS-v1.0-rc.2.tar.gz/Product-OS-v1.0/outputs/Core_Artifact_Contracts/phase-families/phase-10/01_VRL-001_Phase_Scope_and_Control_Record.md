# Core Artifact Contract — VRL-001 Phase Scope and Control Record

~~~yaml
contract_id: CONTRACT-VRL-001
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: VRL-001
artifact_name: Phase Scope and Control Record
owning_phase: Phase 10 - Verification and Release
gate_or_baseline: G6B - Verification Baseline / G7 - Release Authorization
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: IMP-029, IMP-031, IBL / G6A, approved baselines, GOV-009, governance registers, and proposed release intent
primary_downstream: VRL-002 through VRL-038, VBL / G6B, G7, release execution, OPS-003, and Phase 11
semantic_source: ../../../Phase_10_Verification_and_Release.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

VRL-001 defines the exact Phase 10 control boundary: verification candidate / scope, release intent, active profiles, G6B and G7 subphase boundaries, included / excluded objects, owners, independence, authority, evidence period, conditions, freeze / change rules, and downstream handoffs.

It prevents Verification and Release from collapsing into one approval or expanding through schedule, ticket, deployment, or verbal intent.

---

# 2. Scope and Applicability

VRL-001 is CORE whenever Phase 10 is active. Separate control records may govern independent candidates, releases, platforms, migrations, targets, cohorts, regions, verification tracks, or emergency paths.

Partial scope is valid only when inclusions, exclusions, shared dependencies, cross-scope controls, evidence, candidate equality, release effects, and prohibited assumptions are explicit. Phase 10 cannot be NOT_APPLICABLE when verification or production exposure is expected.

---

# 3. Accountabilities and Inputs

- **Phase owner:** controls scope, status, separation, and handoffs.
- **Verification authority:** owns G6B evidence and decision path.
- **Release authority:** owns G7 production-exposure decision path.
- **Domain owners:** confirm requirements, design, architecture, security, privacy, accessibility, data, platform, operations, support, and business scope.
- **AI:** may assemble identities and gaps but cannot infer scope, accept risk, approve gates, or operate production.

Required inputs are exact IMP-029 / IMP-031 / G6A; upstream baselines; implementation evidence; candidate / environment / data / identity access; release intent / target; GOV-009; risks, defects, deviations, waivers, conditions; authority and segregation.

---

# 4. Required Decisions and Minimum Record

Decide phase record ID; candidate and verification scope; proposed release scope / target; profiles / overrides; included / excluded / conditional objects; subphase entry / exit; owners / reviewers / authorities; independence; evidence period; condition / waiver / change routes; freeze / expiry; operational and Phase 11 boundaries.

~~~yaml
phase10_scope_control_id:
imp029_imp031_ibl_g6a_refs: []
candidate_and_verification_scope: []
proposed_release_scope_targets_and_windows: []
included_excluded_conditional_and_shared_objects: []
profiles_and_domain_escalations: []
g6b_and_g7_boundaries_entry_exit_and_validity: []
owners_reviewers_decision_authorities_and_separation: []
environments_data_identities_tools_and_access: []
gov009_controls_risks_defects_waivers_and_conditions: []
evidence_period_freeze_change_and_invalidation_rules: []
operations_support_communications_and_phase11_boundary: []
status_and_reopen_triggers: []
~~~

---

# 5. Authority and Traceability

G6B answers whether the exact candidate is independently verified. G7 separately answers whether that verified candidate may enter an exact target, scope, strategy, window, and conditions. Neither decision owns the other.

Required path: IMP-029 / IMP-031 → VRL-001 scope → verification artifacts → VRL-028 / G6B → release artifacts → VRL-035 / G7 → execution / live validation → VRL-038 / OPS-003.

---

# 6. Profiles, Exit, and Reopen

Level 1 allows a compact control record; Level 2 separates verification and release workstreams; Level 3 adds formal segregation, evidence custody, controlled data / environments, qualified reviewers, and signed decision packages.

Exit requires exact scope, candidate, target intent, profiles, owners, authority, conditions, change rules, evidence, and handoff boundaries. Reopen on candidate, baseline, scope, profile, target, owner, authority, risk, standard, environment, data, defect, waiver, condition, or release-intent change.

---

# 7. Validation Rules

~~~text
VRL1-CVAL-001  VRL-001 binds exact IMP-029 / IMP-031 / G6A, candidate, verification scope, proposed release intent, profiles, sources, and evidence period.
VRL1-CVAL-002  Verification scope, VBL, G6B, release scope, G7 authorization, execution, live validation, and operational acceptance remain distinct.
VRL1-CVAL-003  Included, excluded, deferred, shared, conditional, failed, blocked, waived, NOT_APPLICABLE, and stale objects remain explicit.
VRL1-CVAL-004  Verification, business / UAT, risk, release, execution, rollback, and operational authorities are named and separated by profile / risk.
VRL1-CVAL-005  Partial scope records cross-scope dependencies, controls, candidate equality, evidence, release effects, and prohibited assumptions.
VRL1-CVAL-006  A ticket, test plan, release date, team, branch, deployment, or meeting cannot define or approve the Phase 10 scope.
VRL1-CVAL-007  G6B cannot authorize production; G7 cannot change failed results, validate a different candidate, or prove production health.
VRL1-CVAL-008  Material candidate, scope, profile, target, owner, authority, risk, standard, context, waiver, condition, or evidence change triggers impact and revalidation.
~~~

