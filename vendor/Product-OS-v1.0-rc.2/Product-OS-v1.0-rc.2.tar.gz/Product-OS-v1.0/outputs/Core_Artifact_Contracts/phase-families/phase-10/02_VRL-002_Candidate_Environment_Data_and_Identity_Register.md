# Core Artifact Contract — VRL-002 Candidate, Environment, Data, and Identity Register

~~~yaml
contract_id: CONTRACT-VRL-002
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: VRL-002
artifact_name: Candidate, Environment, Data, and Identity Register
owning_phase: Phase 10 - Verification and Release
gate_or_baseline: G6B Checks 01 and 03 / G7 Candidate Equality
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: IMP-029, IMP-031, IBL / G6A, environment / deployment records, test data and identity plans
primary_downstream: all verification runs / evidence, VRL-028, VRL-029 / VRL-030, VRL-035, and candidate invalidation
semantic_source: ../../../Phase_10_Verification_and_Release.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

VRL-002 is the canonical Phase 10 context register for the exact candidate, artifact / schema / migration / configuration / infrastructure / deployment / flag identities; verification environments; data; accounts / roles / tenants / locales; tools; vendors; access; reset; production differences; and invalidation.

It is CORE for every verification run and release decision. Each result must resolve one compatible version of this context.

---

# 2. Accountabilities and Inputs

Candidate owner, environment / platform owner, data owner, identity / access owner, verification lead, security / privacy reviewer, vendor owner, and release authority are named. Inputs include IMP-029 manifest; deployments; configuration / flags; migrations; environment inventory; synthetic / masked data sources; identity profiles; tool versions; access / reset / cleanup; production differences and restrictions.

---

# 3. Required Decisions and Minimum Record

Decide context ID / revision; candidate identity; environment snapshot; data / identity / tool versions; access; vendor / dependency state; production differences; reset / cleanup; sensitivity / retention; allowed methods; validity; evidence binding; and invalidation.

~~~yaml
verification_context_id_and_revision:
candidate_ibl_imp029_and_source_refs: []
artifact_schema_migration_configuration_infrastructure_and_flag_ids: []
project_account_region_network_environment_deployment_database_and_domain_ids: []
vendors_integrations_dependencies_and_versions: []
data_sources_generation_masking_classification_volume_and_scenarios: []
identity_role_permission_tenant_capacity_auth_locale_and_platform_profiles: []
tools_runners_browsers_devices_assistive_technologies_and_versions: []
access_authority_reset_cleanup_retention_and_audit: []
production_similarities_differences_limits_and_prohibited_claims: []
validity_window_status_evidence_and_invalidation_triggers: []
owners_and_reviewers: []
~~~

---

# 4. Truth, Safety, and Change

“Production-like” names only evidenced similarities. It never implies identical scale, data, network, vendors, access, flags, or operations. Production data is exceptional and requires authority, minimization, protection, retention, audit, and deletion.

Candidate, environment, data, identity, tool, vendor, config, or flag change assesses every affected result and evidence as VALID, PARTIALLY_REUSABLE, STALE, or INVALID.

---

# 5. Profiles, Exit, and Reopen

Level 1 retains exact critical context; Level 2 separates environment / data / identity versions; Level 3 adds controlled access, custody, data approvals, multi-environment context, signed snapshots, qualified devices / tools, and independent confirmation.

Exit requires exact reproducible or independently confirmable context, protected data / identities, visible differences, owners, evidence, and invalidation rules. Reopen on any context identity or access change.

---

# 6. Validation Rules

~~~text
VRL2-CVAL-001  Every context binds exact candidate, source / artifact / schema / migration / config / infrastructure / deployment / flag identities and evidence.
VRL2-CVAL-002  Environment identifies actual project / account, region, network, database / schema, domain, vendors, observability, access, reset, and production differences.
VRL2-CVAL-003  Data records source, generation / masking, classification, scenarios, volume, lifecycle, determinism, reset, owner, restrictions, and evidence.
VRL2-CVAL-004  Identity records role, permission, tenant, organization, acting capacity, authentication, session, locale, platform, lifecycle, owner, and restrictions.
VRL2-CVAL-005  Tools / runners / browsers / devices / assistive technologies and vendor versions are exact enough for reproducibility and result interpretation.
VRL2-CVAL-006  Environment label, latest deployment, seeded account, copied database, or tool name cannot alone prove compatible verification context.
VRL2-CVAL-007  Sensitive data and credentials never enter uncontrolled artifacts or evidence; access, retention, audit, reset, cleanup, and deletion are enforced.
VRL2-CVAL-008  Candidate, environment, deployment, data, identity, config, flag, tool, vendor, access, or production-difference change triggers evidence impact and revalidation.
~~~

