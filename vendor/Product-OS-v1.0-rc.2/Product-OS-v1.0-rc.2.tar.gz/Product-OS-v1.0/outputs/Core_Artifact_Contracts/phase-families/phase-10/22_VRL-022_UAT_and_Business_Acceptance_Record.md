# Core Artifact Contract — VRL-022 UAT and Business Acceptance Record

~~~yaml
contract_id: CONTRACT-VRL-022
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: VRL-022
artifact_name: UAT and Business Acceptance Record
owning_phase: Phase 10 - Verification and Release
gate_or_baseline: G6B Check 23 / G7 Check 22
default_activation: CONDITIONAL_BY_PRODUCT_RELEASE_AND_AUTHORITY_MODEL
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: IMP-029 / IMP-031, product outcomes, requirements / acceptance criteria, business rules, experience journeys, VRL-001 through VRL-021
primary_downstream: VRL-023 through VRL-028, VRL-033, VRL-035, release restrictions, and operations
semantic_source: ../../../Phase_10_Verification_and_Release.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose and Applicability

VRL-022 records whether authorized business or representative user authorities accept the exact candidate for defined outcomes, journeys, roles, scope, and conditions. It captures participants / authority, scenarios, data, environment, observations, defects, decision, evidence, limitations, and change rules.

Activate when business, customer, contractual, operational-user, sponsor, or formal UAT acceptance is required. NOT_APPLICABLE requires product / governance authority, rationale, evidence, downstream impact, and reopen condition.

---

# 2. Boundaries and Accountabilities

UAT validates business / user acceptance within stated scope. It does not replace security, privacy, accessibility, performance, data-integrity, technical, deployment, or operational verification.

Business / user acceptance authority, product owner, UAT coordinator, representative participants, environment / data owner, verification lead, defect owners, and decision recipient are named. AI cannot act as representative user authority or issue acceptance.

---

# 3. Required Inputs and Minimum Record

Inputs include exact candidate / context, approved outcomes / requirements / rules / journeys, scope / exclusions, representative roles, scenarios / data, entry / exit, known defects / limits, evidence and decision authority.

~~~yaml
uat_id_and_revision:
candidate_context_and_scope_refs: []
outcome_requirement_rule_and_journey_refs: []
participants_roles_representativeness_and_authority: []
scenarios_data_environment_identity_and_tools: []
entry_exit_and_acceptance_criteria: []
executions_observations_expected_actual_and_evidence: []
defects_questions_conditions_and_followups: []
decision_outcome_rationale_scope_and_restrictions:
owners_reviewers_approvals_and_date: []
limitations_validity_and_reopen_triggers: []
~~~

---

# 4. Decision Contract

Allowed scoped outcomes are ACCEPTED, ACCEPTED_WITH_CONDITIONS, NOT_ACCEPTED, HOLD, or NOT_APPLICABLE under the governing authority model. Conditions have owner, due event, evidence, restriction, expiry, consequence, and reopen trigger. Acceptance cannot change failed technical results.

---

# 5. Profiles, Exit, and Reopen

Level 1 may use focused acceptance of critical journeys; Level 2 requires representative scope and formal decision evidence; Level 3 adds qualified participant selection, segregation, controlled data, contractual / regulatory authority, observation custody, and independent facilitation.

Exit requires exact candidate / scope, authorized representative decision, evidenced scenarios, visible defects / conditions, limitations, and G6B / G7 treatment. Reopen on candidate, scope, outcome, participant authority, scenario, data, environment, defect, condition, or business-rule change.

---

# 6. Validation Rules

~~~text
VRL22-CVAL-001  UAT binds exact candidate / context, approved outcomes / criteria, scope, representative participants, authority, scenarios, result, evidence, and date.
VRL22-CVAL-002  Business acceptance, user preference, product approval, technical verification, risk acceptance, G6B, and G7 remain distinct decisions.
VRL22-CVAL-003  Participants and scenarios represent named roles, journeys, contexts, data, permissions, markets, or operations with rationale and limitations.
VRL22-CVAL-004  Observations preserve expected / actual behavior, impact, evidence, linked defect / question / condition, owner, and disposition.
VRL22-CVAL-005  ACCEPTED_WITH_CONDITIONS states exact scope, owner, closure evidence, restriction, expiry, consequence, and gate / release treatment.
VRL22-CVAL-006  Demo, stakeholder attendance, survey score, verbal approval, or happy-path success cannot alone prove formal scoped UAT acceptance.
VRL22-CVAL-007  UAT cannot waive mandatory controls or replace security, accessibility, privacy, data, performance, resilience, deployment, or operational verification.
VRL22-CVAL-008  Candidate, scope, outcome, participant authority, scenario, data, context, defect, condition, or rule change triggers impact and re-acceptance.
~~~
