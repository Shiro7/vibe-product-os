# Core Artifact Contract — VRL-030 Production Target Identity Record

~~~yaml
contract_id: CONTRACT-VRL-030
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: VRL-030
artifact_name: Production Target Identity Record
owning_phase: Phase 10 - Verification and Release
gate_or_baseline: G7 Checks 03, 06, 07, and 11 / Production Identity Control
default_activation: CORE
target_mode: INDEPENDENT
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: VRL-028, VRL-029, canonical infrastructure / environment / deployment / domain / data / configuration sources, access and ownership evidence
primary_downstream: VRL-031 through VRL-038, G7, execution, post-release validation, OPS-003, and Phase 11
semantic_source: ../../../Phase_10_Verification_and_Release.md
gate_source: ../../../Gate_Map.md
~~~

---

# 1. Purpose

VRL-030 proves the exact production destination and current live identity before mutation: provider / organization / account / project, environment, regions / zones, network / ingress / egress, domains / aliases / DNS / certificates, runtime / clusters, databases / schemas / tenants, storage / queues / caches, configuration / secret / key sources, observability, artifact provenance, ownership, access, current revisions, drift, and evidence.

---

# 2. Scope and Applicability

VRL-030 is CORE for every G7 decision. Each independently mutable production target, region, tenant group, platform store, client channel, or managed service receives explicit identity.

Identity is verified read-only before release mutation. Names such as “prod,” remembered domains, generic repository labels, screenshots, or previous release records are insufficient.

---

# 3. Accountabilities and Inputs

Platform / environment owner, service / application owner, data owner, network / domain / certificate owner, security / secret owner, operations owner, release executor, verifier, and G7 authority are named.

Inputs include canonical provider inventory, provisioning definitions, active domains / certificates, deployment / artifact / config / migration state, database / storage identity, access / ownership, observability, dependencies, current health, drift, and change freeze evidence.

---

# 4. Minimum Target Record

~~~yaml
production_target_id_and_revision:
provider_org_account_project_subscription_environment: []
regions_zones_networks_ingress_egress_domains_aliases_dns_and_certificates: []
clusters_runtimes_services_functions_jobs_and_client_channels: []
databases_schemas_tenants_storage_queues_caches_and_search_targets: []
current_source_artifact_deployment_migration_config_infrastructure_and_flag_ids: []
config_secret_key_certificate_sources_and_owners: []
vendors_integrations_dependencies_and_current_versions: []
health_observability_dashboards_alerts_and_runbooks: []
ownership_access_roles_operators_and_separation: []
read_only_confirmation_methods_evidence_time_and_reviewers: []
drift_unknowns_restrictions_freeze_and_invalidation: []
status_and_reopen_triggers: []
~~~

---

# 5. Identity and Safety Rules

The record distinguishes desired source, provisioned state, provider-reported state, deployed artifact, runtime-effective configuration, data / schema state, domain routing, feature exposure, and observed health. Secrets are identified by metadata only.

Any mismatch is resolved or gate-treated before production mutation. Execution must re-confirm identity at the authorized window.

---

# 6. Profiles, Exit, and Reopen

Level 1 retains exact critical project / domain / data / config identity; Level 2 separates services / regions / data targets; Level 3 adds independent ownership confirmation, signed inventory, custody, segregation, multi-region topology, policy / drift evidence, and four-eyes target confirmation.

Exit requires exact target and current-state truth, ownership / access, drift disposition, health / observability links, evidence time, and revalidation boundary. Reopen on target, provider, region, domain, certificate, runtime, data, config, artifact, access, ownership, drift, or live-state change.

---

# 7. Validation Rules

~~~text
VRL30-CVAL-001  Target identity resolves exact provider / organization / account / project, environment, region, network, domain / alias, runtime, data, and owner identities.
VRL30-CVAL-002  Desired source, provisioned state, provider state, deployed artifact, runtime config, schema / data, routing / certificate, flag exposure, and health remain distinct.
VRL30-CVAL-003  Current artifact, migration, config, infrastructure, flag, dependency, certificate, domain, health, and drift states are evidenced before mutation.
VRL30-CVAL-004  Access, operator roles, separation, break-glass, audit, secret / key sources, and ownership are confirmed without exposing values.
VRL30-CVAL-005  Read-only checks identify method, actor, time, exact target, result, evidence, limitations, and planned re-confirmation at execution.
VRL30-CVAL-006  “Production,” domain memory, CLI context, console screenshot, previous deployment, repository name, or environment-variable set cannot alone prove target identity.
VRL30-CVAL-007  Ambiguous ownership, target mismatch, domain / certificate uncertainty, data-target uncertainty, unreconciled drift, or missing observability blocks affected G7 scope.
VRL30-CVAL-008  Provider, target, region, network, domain, certificate, runtime, data, artifact, config, flag, dependency, access, drift, or live-state change triggers revalidation.
~~~

