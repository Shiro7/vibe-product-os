# Core Artifact Contract — GOV-005 Assumption Register

~~~yaml
contract_id: CONTRACT-GOV-005
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-005
artifact_name: Assumption Register
owning_phase: Cross-phase Governance
gate_or_baseline: Governs provisional truth used by every phase and gate
default_activation: CORE_PERSISTENT_REGISTER
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: Sources, questions, constraints, and affected artifacts
primary_downstream: Decisions, risks, baselines, verification, and change impact
~~~

---

# 1. Purpose

GOV-005 is the canonical cross-phase register of material propositions accepted provisionally so work can proceed while truth remains unverified. It preserves the proposition, reason, source, confidence, impact if false, dependent objects, validation method, owner, due event, result, and downstream disposition.

It answers: **What are we temporarily treating as true, why, who owns validation, which work depends on it, and what happens if it is confirmed, rejected, or expires?**

An assumption never silently becomes a fact, requirement, approval, or decision.

---

# 2. Scope and Applicability

GOV-005 is required for all Product OS scope. A record is required when an unverified proposition materially influences scope, prioritization, business or product behavior, requirement, design, architecture, estimate, implementation, verification, release, operation, risk, standard applicability, or gate outcome.

Trivial working hypotheses may remain local only when their failure cannot alter a governed object. Unrecorded uncertainty is not evidence of certainty.

---

# 3. Accountabilities

- **Register owner:** governance or knowledge-management authority responsible for register integrity.
- **Assumption owner:** accountable for validation, expiry, communication, and downstream disposition.
- **Validation owner:** performs or commissions the approved validation method.
- **Dependent artifact owners:** acknowledge reliance and respond to status change.
- **Decision / gate authorities:** decide whether residual uncertainty permits bounded progression.
- **AI:** may identify implicit assumptions, propose validation, and trace dependencies; it cannot validate a proposition from plausibility or silently promote it to fact.

---

# 4. Required Inputs

1. The exact proposition and context in which it is being used.
2. Available sources, evidence, contradictions, confidence, and information gaps.
3. Affected artifacts, decisions, risks, estimates, baselines, gates, releases, and live scopes.
4. Impact if false and safe bounds for provisional use.
5. Validation method, evidence expectation, owner, due event, and expiry.
6. Active GOV-001 rules and GOV-009 implications.

---

# 5. Required Questions

1. What exact proposition is provisionally treated as true?
2. Why is it an assumption rather than a fact, question, hypothesis, constraint, or decision?
3. What evidence supports or contradicts it and with what confidence?
4. Which objects and gates depend on it?
5. What is the impact and risk if it is false or only partially true?
6. Can work proceed safely under explicit bounds before validation?
7. Who owns validation and what method, sample, environment, or source is required?
8. What due event or expiry prevents indefinite provisional truth?
9. What downstream action follows validation, rejection, expiry, or changed context?
10. Which trigger requires immediate re-review?

---

# 6. Assumption Lifecycle

~~~text
PROPOSED
ACCEPTED_FOR_PLANNING
VALIDATION_IN_PROGRESS
VALIDATED
REJECTED
EXPIRED
SUPERSEDED
~~~

`VALIDATED` requires claim-bound evidence and does not rewrite history; the resulting confirmed fact remains in its owning artifact or source register. `REJECTED` and `EXPIRED` trigger impact handling for every dependent object.

---

# 7. Minimum Assumption Record

~~~yaml
assumption_id:
statement:
context:
scope:
reason_for_assumption:
source_refs: []
supporting_evidence: []
contradicting_evidence: []
confidence:
owner:
validation_owner:
impact_if_false:
risk_refs: []
dependent_artifacts: []
dependent_decisions: []
affected_gates: []
provisional_conditions: []
validation_method:
evidence_expectation: []
due_event:
expires_at:
status:
validation_result:
result_evidence: []
downstream_disposition: []
gov_009_entries: []
supersedes:
superseded_by:
reopen_triggers: []
created_at:
updated_at:
~~~

Confidence communicates current support; it is not approval or validation status.

---

# 8. Information-State Boundary

~~~text
Verified observation with evidence → FACT
Unverified proposition used provisionally → ASSUMPTION
Possible explanation to test → HYPOTHESIS
Information needed → OPEN QUESTION
Accountable choice → DECISION
Fixed boundary → CONSTRAINT
~~~

When validation produces mixed results, split or refine the assumption rather than forcing binary certainty. The original record retains lineage.

---

# 9. Traceability and Change Impact

~~~text
Source Gap / Working Need
→ GOV-005 Assumption
→ Dependent Decision / Artifact / Baseline / Gate
→ Validation Method and Evidence
→ Validated Fact, Rejection, Expiry, or Supersession
→ GOV-007 Change + GOV-008 Impact Traversal
~~~

Every dependent object records the assumption ID and provisional condition. Rejection or expiry records affected approved objects as `REVIEW_REQUIRED` in change-impact assessment and marks their GOV-002 lifecycle entries `STALE` when approved meaning may no longer be relied upon.

---

# 10. Profile Behavior

- **P1:** assumptions may share a concise register, but material statement, owner, dependency, impact, validation, due event, and disposition remain.
- **P2:** validation plans, confidence, dependencies, risks, and gate effects are structured.
- **P3:** formal evidence plans, independent review, sensitivity or scenario analysis, immutable lineage, and automated dependency alerts strengthen.

---

# 11. Verification and Evidence

Verification confirms the statement is atomic and genuinely unverified; sources and confidence are current; dependent objects are complete; validation is proportionate; result evidence addresses the exact proposition; status is not inferred from elapsed time; and downstream effects were acknowledged and resolved.

---

# 12. Exit Criteria

An assumption record is complete for its current state when statement, context, reason, confidence, owner, sources, impact, risks, dependencies, provisional conditions, validation method, evidence expectation, due event, expiry, status, result, downstream disposition, and reopen triggers are explicit. An assumption may remain open across a gate only through an authorized bounded condition.

---

# 13. Reopen and Update Conditions

Update on new or contradictory evidence, source correction, changed scope, missed validation, expiry, dependent artifact change, risk realization, verification failure, incident, user or market change, standard or contract change, or loss of the conditions under which provisional use was permitted.

---

# 14. Artifact-Specific Validation Rules

~~~text
GOV5-CVAL-001  Every material assumption is explicit, atomic, owned, scoped, and dependency-linked.
GOV5-CVAL-002  Assumption, fact, hypothesis, question, constraint, and decision remain distinct.
GOV5-CVAL-003  Confidence is not validation, approval, or evidence of truth.
GOV5-CVAL-004  Every assumption has impact-if-false, validation method, due event, and evidence expectation.
GOV5-CVAL-005  Dependent artifacts expose provisional reliance and gate conditions.
GOV5-CVAL-006  AI cannot silently promote an assumption to fact or validated status.
GOV5-CVAL-007  Rejected or expired assumptions trigger GOV-007 and GOV-008 impact traversal.
GOV5-CVAL-008  Validation preserves the original record and links the resulting confirmed truth.
~~~
