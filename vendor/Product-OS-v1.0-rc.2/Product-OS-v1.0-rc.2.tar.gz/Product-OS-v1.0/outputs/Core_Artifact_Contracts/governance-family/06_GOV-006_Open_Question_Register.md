# Core Artifact Contract — GOV-006 Open Question Register

~~~yaml
contract_id: CONTRACT-GOV-006
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-006
artifact_name: Open Question Register
owning_phase: Cross-phase Governance
gate_or_baseline: Governs information and decision gaps across every phase and gate
default_activation: CORE_PERSISTENT_REGISTER
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: Sources, artifacts, assumptions, risks, and conflicts
primary_downstream: Answers, GOV-003 decisions, GOV-005 assumptions, gates, and handoffs
~~~

---

# 1. Purpose

GOV-006 is the canonical cross-phase register of material unanswered information and decision needs. It preserves the question, why it matters, priority, impact, blocker state, owner, due event, affected artifacts, answer source, decision route, closure evidence, and reopen conditions.

It answers: **What must still be learned or decided, why, by whom, by when, and what work or gate is blocked until it is resolved?**

The register prevents unknowns from being hidden in narrative, repeatedly asked without lineage, or closed by unsupported AI inference.

---

# 2. Scope and Applicability

GOV-006 is required for all Product OS scope. A record is required when missing information or unresolved authority may affect lifecycle routing, scope, obligation, standard applicability, decision, risk, baseline, implementation, verification, release, operation, or gate outcome.

Already answered questions are not repeated unless the source, context, scope, or baseline changed. Low-impact workshop prompts need not become register entries.

---

# 3. Accountabilities

- **Register owner:** governance or discovery / knowledge coordinator responsible for integrity and deduplication.
- **Question owner:** accountable for routing, follow-up, status, and downstream disposition.
- **Answer owner / source authority:** provides authoritative information and evidence.
- **Decision authority:** acts when the answer alone cannot resolve the accountable choice.
- **Affected artifact owners:** identify blocker effect and acknowledge resolution.
- **AI:** may detect gaps, deduplicate, prioritize provisionally, and draft questions; it cannot invent an answer, authority, consensus, or closure evidence.

---

# 4. Required Inputs

1. The information gap, conflict, source ambiguity, decision need, or validation need.
2. Affected artifacts, baselines, gates, risks, assumptions, and GOV-009 entries.
3. Known sources, potential answer owners, evidence requirements, and due events.
4. Priority and blocker criteria from the owning phase or gate.
5. Prior related questions, answers, decisions, and supersession history.

---

# 5. Required Questions About Each Question

1. Is the wording atomic, neutral, answerable, and free of embedded solution or approval?
2. Why does the answer matter and what changes depending on it?
3. Is this an information question, validation question, or decision question?
4. What priority and blocker state apply for the exact phase and gate?
5. Who owns obtaining the answer and who is authoritative to provide it?
6. Which source and evidence quality are sufficient?
7. By what due event must it be answered or explicitly deferred?
8. Which artifacts, assumptions, risks, decisions, or gates are affected?
9. Does an earlier answer exist, and if so what changed?
10. Does the answer require a separate GOV-003 decision?

---

# 6. Priority Contract

~~~text
Q0  CRITICAL_BLOCKER  - without the answer the correct route or safe progression cannot be determined
Q1  HIGH_IMPACT       - may materially change state, scope, profile, priority, or lifecycle path
Q2  IMPORTANT         - required for the responsible phase but not a blocker for the current gate
Q3  DEFERRED          - deliberately routed to the specialized later phase with owner and due event
~~~

Priority is contextual and may change by gate. `Q3` is a governed route, not an abandoned question.

---

# 7. Question Lifecycle

~~~text
OPEN
IN_ANALYSIS
ANSWERED
DECISION_REQUIRED
DEFERRED
CLOSED
SUPERSEDED
REOPENED
~~~

`ANSWERED` means an authoritative answer and source are recorded. `CLOSED` additionally means affected artifacts and decisions have received disposition. `DECISION_REQUIRED` routes the answer and options to GOV-003.

---

# 8. Minimum Question Record

~~~yaml
question_id:
question:
question_type:
why_it_matters:
context:
scope:
priority:
impact:
blocking:
blocked_artifacts: []
affected_artifacts: []
affected_gates: []
owner:
answer_owner:
authority_required:
candidate_sources: []
required_evidence: []
due_event:
status:
answer:
answer_source_refs: []
answer_evidence_refs: []
answered_by:
answered_at:
decision_required:
decision_id:
assumption_if_unresolved:
deferred_to_phase:
closure_disposition: []
duplicate_of:
supersedes:
superseded_by:
reopen_triggers: []
created_at:
updated_at:
~~~

---

# 9. Answer, Decision, and Assumption Boundary

~~~text
Authoritative factual response → ANSWER in GOV-006
Accountable choice between options → GOV-003 DECISION
Provisional proposition used before answer → GOV-005 ASSUMPTION
Uncertainty about adverse effect → GOV-004 RISK
~~~

One question may produce both an answer and a decision, but each keeps its own identity, authority, status, and evidence.

---

# 10. Traceability and Handoff

~~~text
Source Gap / Conflict / Artifact Need
→ GOV-006 Question
→ Answer and Evidence or Explicit Deferral
→ GOV-003 Decision / GOV-005 Assumption as required
→ Affected Artifact Update and Acknowledgement
→ Closure or Reopen
~~~

Every gate view identifies blocking open questions, accepted non-blocking questions, owner, due event, and downstream route. A missing answer cannot be concealed by removing the question from the view.

---

# 11. Profile Behavior

- **P1:** questions may share a concise register, but Q0 / Q1, ownership, blocker, due event, source, decision route, and disposition remain.
- **P2:** question types, deduplication, answer evidence, gate views, and phase routing are structured.
- **P3:** formal source authority, independent review, conflict handling, immutable history, and automated blocker / ageing alerts strengthen.

---

# 12. Verification and Evidence

Verification confirms questions are atomic and non-leading; priorities match actual impact; blocker status is not used to force a preferred answer; answer sources are authoritative and versioned; duplicates retain lineage; decision needs route to GOV-003; and affected artifact owners acknowledge closure.

---

# 13. Exit Criteria

A question record is complete for its current state when question, type, rationale, context, scope, priority, impact, blocker, owner, answer authority, source / evidence need, due event, affected objects, status, answer or deferral, decision route, closure disposition, and reopen triggers are explicit. Q0 blockers cannot pass the affected gate without resolution or authorized safe route.

---

# 14. Reopen and Update Conditions

Reopen when the answer source changes, evidence is corrected or invalidated, scope or baseline changes, an assumption is rejected, a decision is reopened, implementation or verification exposes ambiguity, a standard trigger changes, an owner disputes interpretation, or the prior answer no longer covers the current context.

---

# 15. Artifact-Specific Validation Rules

~~~text
GOV6-CVAL-001  Every material question has stable identity, owner, priority, due event, and affected scope.
GOV6-CVAL-002  Q0 through Q3 reflect actual gate impact; Q3 has a governed destination.
GOV6-CVAL-003  Answer, decision, assumption, recommendation, and inference remain distinct.
GOV6-CVAL-004  ANSWERED requires an authoritative source; CLOSED requires downstream disposition.
GOV6-CVAL-005  Duplicate or superseded questions preserve prior answers and lineage.
GOV6-CVAL-006  AI cannot invent answers, authority, consensus, or closure evidence.
GOV6-CVAL-007  Every gate exposes unresolved blocking questions and accepted conditions.
GOV6-CVAL-008  Changed source, scope, evidence, or baseline can reopen a closed question.
~~~
