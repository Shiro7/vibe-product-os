# Core Artifact Contract — GOV-009 Standards & Compliance Applicability Matrix

~~~yaml
contract_id: CONTRACT-GOV-009
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-009
artifact_name: Standards & Compliance Applicability Matrix
owning_phase: Cross-phase Governance
gate_or_baseline: Applicability and propagation control from G0 through G8
default_activation: CORE_PERSISTENT_REGISTER
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-001, standards sources, project context, and activation triggers
primary_downstream: Business, product, requirement, experience, design, architecture, engineering, verification, release, and operations obligations
semantic_source: ../../GOV_009_Standards_and_Compliance_Applicability_Matrix.md
~~~

---

# 1. Purpose

GOV-009 is the canonical control artifact for determining which universal standards, conditional compliance profiles, and clauses apply to the exact project context; why they apply or do not; who owns and approves the decision; what obligations propagate; what evidence proves realization; and what change reopens applicability.

It answers: **Which standard or profile applies to which exact scope, because of which verified trigger, and how does that obligation remain traceable through delivery and operation?**

GOV-009 does not replace or copy the source standard. It stores applicability, decision, scope, activation, propagation, lineage, verification, evidence, exception, and reopen truth. The detailed governance model and lifecycle examples remain in the canonical [GOV-009 semantic specification](../../GOV_009_Standards_and_Compliance_Applicability_Matrix.md); this specialized contract binds that model to the Shared Core Artifact Contract Standard without creating competing applicability truth.

---

# 2. Scope and Applicability

GOV-009 is required for all Product OS scope. It contains entries for known Product OS universal standards and all conditional profiles discovered through product, customer, geography, industry, contract, regulation, data type, transaction, platform, capability, document, third-party, identity, language, or critical-journey triggers.

Universal standards are applicable by default at their governing level. Individual clauses may be conditional where their source says so. A capability module such as payments, multi-tenancy, or offline synchronization is not itself a compliance profile, although activating it may trigger additional standards or profiles.

---

# 3. Governance Boundary

- **GOV-001** establishes governing standards, non-negotiables, authority, and minimum baselines.
- **GOV-009** owns project-specific applicability, rationale, scope, trigger, approval, propagation, and clause / criterion lineage.
- **Phase artifacts** own their canonical business, product, requirement, design, architecture, implementation, verification, release, and operational realization.
- **GOV-002** registers those artifact identities and lifecycle states.
- **GOV-008** stores relationships without becoming applicability truth.
- **GOV-007** governs material change after applicability or source context changes.

Lower layers may strengthen an obligation. They cannot silently weaken or exclude it.

---

# 4. Accountabilities

- **Register owner:** Product OS governance or delegated standards-governance authority.
- **Applicability owner:** accountable for trigger, scope, rationale, status, propagation, and review.
- **Decision authority:** role empowered to approve applicability or N/A for the exact source and scope.
- **Standard / profile owner:** maintains source identity, version, interpretation boundary, and clause expertise.
- **Phase obligation owners:** create and maintain downstream canonical objects and evidence.
- **Independent reviewers:** required by profile, risk, regulation, contract, or GOV-001.
- **AI:** may discover triggers, compare sources, draft entries, and find gaps; it cannot approve applicability, declare compliance, accept N/A, or weaken an obligation.

---

# 5. Required Inputs

1. Active GOV-001 constitution and authorized standard / profile catalogs.
2. Exact standard, profile, or clause source identity and version.
3. Project / product scope, platforms, markets, languages, directions, data, users, journeys, documents, integrations, vendors, identity, and capabilities.
4. Contractual, customer, regulatory, industry, geography, and transaction evidence.
5. Existing business through operational objects, decisions, exceptions, and evidence.
6. Gate scope, owners, approval route, verification methods, and reopen triggers.

---

# 6. Required Questions

1. Is the source a universal standard, conditional compliance profile, or capability module?
2. What exact version, clauses, criteria, authority level, and precedence apply?
3. Which verified trigger activates or excludes it for which scope?
4. Is applicability `APPLICABLE`, `NOT_APPLICABLE`, or `PENDING`, and is the decision separately approved?
5. Who owns and may approve the decision; what evidence and due gate apply?
6. Which business obligations and product responsibilities result?
7. Which requirements and experience, design, architecture, readiness, implementation, verification, release, and operational work must derive?
8. Which third parties, generated documents, markets, languages, data, journeys, and platforms are included or excluded?
9. What evidence demonstrates current lifecycle realization without making a generic compliance claim?
10. What scope, source, trigger, exception, or context change reopens the entry?

---

# 7. Classification and Status

Source classification:

~~~text
UNIVERSAL_STANDARD
CONDITIONAL_PROFILE
CAPABILITY_MODULE
~~~

Applicability status:

~~~text
APPLICABLE
NOT_APPLICABLE
PENDING
~~~

Decision status:

~~~text
PROPOSED
IN_REVIEW
APPROVED
DEFERRED
REJECTED
REOPENED
~~~

Applicability and decision status are separate. For example, `APPLICABLE + IN_REVIEW` records the current analysis while approval remains pending. `PENDING` records blocker, owner, required evidence, and due gate.

---

# 8. Minimum Applicability Record

~~~yaml
entry_id:
source:
  source_id:
  source_version:
  title:
  classification:
  authority_level:
scope:
  product_id:
  clauses: []
  platforms: []
  markets: []
  languages_and_directions: []
  data_types: []
  transactions: []
  journeys: []
  affected_documents: []
  third_parties: []
applicability:
  status:
  activation_triggers: []
  rationale:
  evidence: []
  decision_owner:
  decision_status:
  approved_by: []
  approved_at:
  blocking:
  due_gate:
business_linkage:
  requirements: []
  rules: []
  policies: []
  controls: []
  information_obligations: []
  evidence_obligations: []
product_implications:
  capabilities: []
  constraints: []
  policies: []
  supported_platforms: []
  affected_journeys: []
  affected_documents: []
  third_parties: []
requirements_derivation:
  required:
  target_types: []
  derived_requirement_ids: []
downstream:
  experience:
  design:
  architecture:
  engineering_readiness:
  implementation:
  verification:
  release_gate:
  operations:
verification:
  methods: []
  evidence_ids: []
  status:
exceptions: []
affected_artifacts: []
reopen_conditions: []
last_reviewed_at:
last_reviewed_by:
~~~

`NOT_APPLICABLE` additionally requires exact reason, decision owner, evidence, approval where required, affected scope, and reopen condition. Absence is missing, not N/A.

---

# 9. Required Propagation Chain

~~~text
Standard / Profile / Criterion
→ GOV-009 Applicability Decision
→ Business Requirement / Rule / Control / Policy / Information / Evidence Obligation
→ Product Capability / Constraint / Policy / Platform / Journey / Document Responsibility
→ FR / NFR / SEC / ACC / AUD / DR / INT Requirement
→ Experience / Design / Architecture Obligation
→ Engineering Allocation / Implementation
→ Verification Method / Result / Evidence
→ Release Decision
→ Live Control / Operational Evidence
→ Change, Exception, Incident, or Evolution Trigger
~~~

Each phase consumes the entry and creates only the canonical object it owns. No applicable obligation first appears at QA.

---

# 10. Gate Use

At each gate, entries required for its scope have explicit applicability, decision authority, rationale, evidence, current phase lineage, owners, verification expectation, and open impact. No blocking `PENDING` entry passes the gate. A gate may accept non-blocking pending work only with owner, due event, safe bounds, affected objects, and decision route.

---

# 11. Profile Behavior

- **P1:** entries may be packaged in one composite governance artifact; complete applicability, authority, rationale, downstream obligation, evidence, and reopen condition remain.
- **P2:** independent entries and explicit business, product, system, gate, and evidence links are maintained.
- **P3:** clause-level applicability, independent owners / approvers, formal evidence, versioned baselines, full lifecycle traceability, and formal impact analysis strengthen.

P1, P2, and P3 change depth and packaging, never whether an applicable obligation exists.

---

# 12. Verification and Evidence

Verification confirms source and version are authentic; classification is correct; triggers and scope are evidence-backed; decision authority is valid; N/A is safe and reopenable; applicable entries propagate to the current lifecycle point; exceptions preserve the original obligation; verification evidence is claim-bound and fresh; and no document presence or test count is presented as generic compliance.

---

# 13. Exit Criteria

GOV-009 is operationally complete for an exact gate when required sources are registered and versioned; applicability and decision statuses are explicit; authority, rationale, evidence, scope, business linkage, current downstream responsibilities, verification expectations, exceptions, and reopen conditions are recorded; and no blocking `PENDING` entry remains.

Persistent completion is evaluated for exact scope, source versions, and lifecycle time, not as a permanent claim of compliance.

---

# 14. Reopen and Update Conditions

Reopen on changed platform, market, country, language or direction, data classification, regulated data, payment or other capability, enterprise customer need, contract, industry, generated document, third party, authentication / identity model, critical journey, standard version, Product OS constitution, exception, source interpretation, implementation, verification, incident, or operational evidence.

Reopening identifies affected canonical objects, creates GOV-007 impact handling, traverses GOV-008, records affected approved artifacts as `REVIEW_REQUIRED` in change impact, and marks their GOV-002 lifecycle entries `STALE` when approved meaning may no longer be relied upon.

---

# 15. Artifact-Specific Validation Rules

~~~text
GOV9-CVAL-001  Every known standard, profile, or triggered clause has a versioned source and canonical entry.
GOV9-CVAL-002  Applicability, decision, artifact, verification, and compliance-claim statuses remain distinct.
GOV9-CVAL-003  Every N/A decision has exact scope, reason, evidence, authority, and reopen trigger.
GOV9-CVAL-004  Every applicable entry propagates to the current lifecycle point or exposes a visible gap.
GOV9-CVAL-005  Phase artifacts reference GOV-009 and do not create competing applicability truth.
GOV9-CVAL-006  Delivery profile cannot weaken constitutional, universal, contractual, or regulated obligations.
GOV9-CVAL-007  AI cannot approve applicability, accept N/A, or declare compliance.
GOV9-CVAL-008  Trigger or source change initiates GOV-007, GOV-008 traversal, and downstream revalidation.
~~~
