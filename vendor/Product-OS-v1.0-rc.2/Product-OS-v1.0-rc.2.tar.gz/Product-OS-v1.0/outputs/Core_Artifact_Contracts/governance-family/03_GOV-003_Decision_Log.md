# Core Artifact Contract — GOV-003 Decision Log

~~~yaml
contract_id: CONTRACT-GOV-003
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-003
artifact_name: Decision Log
owning_phase: Cross-phase Governance
gate_or_baseline: Supports every gate and baseline decision
default_activation: CORE_PERSISTENT_REGISTER
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-001, GOV-002, GOV-006, and authoritative sources
primary_downstream: GOV-007, GOV-008, baselines, gates, and affected artifacts
~~~

---

# 1. Purpose

GOV-003 is the canonical cross-phase register of material decisions. It preserves the question or decision need, context, options, accountable choice, rationale, authority, conditions, validity, affected scope, and downstream effect without duplicating the full content owned by an ADR, gate record, baseline, policy, or phase artifact.

It answers: **What was decided, by whom, under which authority and evidence, for what scope and period, and what must change or remain constrained because of it?**

An idea, recommendation, inferred preference, answered factual question, or AI suggestion is not an approved decision.

---

# 2. Scope and Applicability

GOV-003 is required for all Product OS scope. A record is required when a choice materially affects scope, authority, baseline content, obligations, architecture, experience, design, implementation, verification, release, operation, risk, exception, standard applicability, or lifecycle routing.

Routine working choices may remain in their owning artifact when they have no cross-artifact or gate impact. Their absence from GOV-003 must not hide a material decision.

---

# 3. Accountabilities

- **Owner:** governance or decision-management authority responsible for register integrity.
- **Decision owner:** person accountable for preparing and maintaining the decision need and outcome.
- **Decision authority:** role empowered by GOV-001 to approve, reject, defer, reopen, or supersede the decision.
- **Contributors / reviewers:** source owners and specialists required by scope, profile, risk, or obligation.
- **Affected artifact owners:** acknowledge and disposition downstream impact.
- **AI:** may organize evidence, compare options, identify conflicts, and draft a record; it cannot decide, approve, manufacture consensus, or present inference as authority.

---

# 4. Required Inputs

1. The decision question or need and its originating object.
2. Verified context, source versions, evidence, assumptions, risks, constraints, and open questions.
3. Feasible options, including defer or no-change where valid.
4. Active GOV-001 authority rules and applicable GOV-009 obligations.
5. Affected GOV-002 artifacts, baselines, gates, live scopes, and owners.
6. Required reviews, segregation, exception, expiry, and escalation rules.

---

# 5. Required Questions

1. Is this a material accountable choice, a factual answer, an assumption, or only a recommendation?
2. What exact question, scope, baseline versions, and decision deadline apply?
3. Which options were genuinely considered and on what evidence?
4. Who owns the decision and who has authority to decide it?
5. Which risks, obligations, conditions, exceptions, dissent, or uncertainty remain?
6. Which artifacts, gates, releases, environments, markets, users, or live services are affected?
7. When does the decision take effect, expire, require review, or become invalid?
8. What downstream acknowledgement, implementation, verification, or evidence is required?
9. Does the decision supersede another decision without erasing its history?
10. Which trigger reopens it?

---

# 6. Decision Lifecycle

~~~text
PROPOSED
IN_REVIEW
APPROVED
DEFERRED
REJECTED
SUPERSEDED
EXPIRED
REOPENED
~~~

Decision status remains separate from artifact, applicability, implementation, verification, and approval-status dimensions. `APPROVED` means an accountable choice exists; it does not mean the choice was implemented, verified, released, or successful in operation.

---

# 7. Minimum Decision Record

~~~yaml
decision_id:
question_id:
question:
decision_class:
context:
scope:
baseline_refs: []
options_considered: []
decision:
rationale:
owner:
authority:
participants: []
reviewers: []
status:
conditions: []
assumption_refs: []
risk_refs: []
exception_refs: []
source_refs: []
evidence_refs: []
gov_001_rules: []
gov_009_entries: []
affected_artifacts: []
affected_gates: []
effective_at:
expires_at:
review_due:
supersedes:
superseded_by:
implementation_refs: []
verification_refs: []
acknowledgements: []
reopen_triggers: []
created_at:
updated_at:
~~~

The detailed decision may remain in its canonical ADR, gate record, policy, or baseline. GOV-003 stores the canonical decision identity and links to that content.

---

# 8. Ownership Boundary

- GOV-006 owns the open question until it is answered or routed to accountable choice.
- GOV-003 owns the material decision identity, status, authority, rationale, and cross-phase impact.
- A phase artifact or ADR may own detailed analysis and implementation-specific content.
- GOV-007 owns change execution and impact lifecycle resulting from the decision.
- GOV-008 owns the relationships; it does not become the decision source.
- GOV-009 owns standards applicability decisions and references GOV-003 when a material approval is required.

An answer does not automatically become a decision. A decision does not automatically close its change, implementation, verification, or outcome obligations.

---

# 9. Traceability and Handoff

~~~text
Source / Evidence / GOV-006 Question
→ Options and Risk / Assumption Analysis
→ GOV-003 Decision and Authority
→ Affected Artifact / Baseline / Gate
→ GOV-007 Change or Authorized Action
→ Verification / Evidence / Live Outcome
→ Reopen, Supersession, or Expiry
~~~

Every affected artifact receives the decision ID, exact conditions, effective scope, required action, acknowledgement, and change route.

---

# 10. Profile Behavior

- **P1:** decisions may share one compact register, but authority, scope, rationale, conditions, affected artifacts, and reopen triggers remain explicit.
- **P2:** decision classes, reviews, acknowledgements, and downstream impact are structured and traceable.
- **P3:** formal option analysis, independent review, dissent, signatures / attestations where applicable, immutable history, and automated impact checks strengthen.

Profile packaging cannot turn a material decision into ungoverned narrative.

---

# 11. Verification and Evidence

Verification confirms the authority was valid at decision time; evidence and sources resolve to exact versions; options and rationale support the outcome; conditions and exceptions remain visible; affected objects were acknowledged; supersession preserves history; and implementation or success is not inferred from approval.

---

# 12. Exit Criteria

A decision record is complete for its current state when the question, context, scope, options, rationale, owner, authority, status, evidence, risks, assumptions, conditions, affected artifacts, effective / expiry dates, downstream route, acknowledgements, and reopen triggers are explicit. Deferred and rejected decisions still require rationale and impact disposition.

---

# 13. Reopen and Update Conditions

Reopen on changed evidence, source correction, invalidated assumption, realized or increased risk, scope or authority change, expired condition, GOV-001 or GOV-009 change, upstream baseline change, implementation conflict, verification failure, incident, operational outcome, or explicit review trigger. Reopening preserves the prior decision and creates a governed new revision or decision identity.

---

# 14. Artifact-Specific Validation Rules

~~~text
GOV3-CVAL-001  Every material decision has stable identity, exact scope, owner, and valid authority.
GOV3-CVAL-002  Answer, recommendation, inference, and approval remain distinct.
GOV3-CVAL-003  APPROVED never implies implemented, verified, released, or successful.
GOV3-CVAL-004  Options, rationale, evidence, risks, assumptions, and conditions remain reviewable.
GOV3-CVAL-005  Every affected artifact and gate receives explicit impact disposition.
GOV3-CVAL-006  Superseded, rejected, deferred, expired, and reopened history is preserved.
GOV3-CVAL-007  AI cannot become decision or approval authority.
GOV3-CVAL-008  Material decision change triggers GOV-007 and GOV-008 impact handling.
~~~
