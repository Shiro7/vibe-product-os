# Core Artifact Contract — GOV-004 Risk Register

~~~yaml
contract_id: CONTRACT-GOV-004
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-004
artifact_name: Risk Register
owning_phase: Cross-phase Governance
gate_or_baseline: Supports risk treatment and acceptance at every gate
default_activation: CORE_PERSISTENT_REGISTER
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-001, GOV-002, sources, assumptions, and affected artifacts
primary_downstream: Decisions, controls, requirements, gates, release, and operations
~~~

---

# 1. Purpose

GOV-004 is the canonical cross-phase register of material uncertainty that may affect objectives, users, obligations, delivery, release, or live operation. It preserves cause, uncertain event or condition, impact, exposure, ownership, treatment, controls, indicators, residual risk, acceptance authority, evidence, and review history.

It answers: **What might happen, why, with what impact and likelihood, how is it treated and detected, and who may accept what remains?**

A current issue, defect, incident, known constraint, or unsupported assumption is not disguised as a future risk. When a risk is realized, its risk identity remains linked to the resulting issue or incident.

---

# 2. Scope and Applicability

GOV-004 is required for all Product OS scope. Records cover material product, user, business, operational, delivery, security, privacy, accessibility, data, audit, compliance, safety, reliability, continuity, vendor, financial, legal, market, technology, and lifecycle risks.

Low materiality items may use compact treatment, but a profile cannot omit risks whose impact could alter a gate, mandatory obligation, release, user harm, or live control.

---

# 3. Accountabilities

- **Register owner:** governance or risk-management authority responsible for integrity and cadence.
- **Risk owner:** accountable for understanding exposure and ensuring treatment or escalation.
- **Action / control owners:** accountable for treatment, monitoring, response, and evidence.
- **Risk-acceptance authority:** role empowered by GOV-001 for the exact residual exposure and period.
- **Reviewers:** specialists and independent assurance required by domain, profile, severity, contract, or regulation.
- **AI:** may detect signals, structure analysis, and propose treatments; it cannot accept residual risk, lower severity without evidence, or close a risk from missing data.

---

# 4. Required Inputs

1. Objectives, scope, obligations, baselines, live context, and risk criteria.
2. Sources, evidence, assumptions, dependencies, incidents, defects, findings, and operational signals.
3. Likelihood and impact scales, appetite, tolerance, escalation, and acceptance authority.
4. Existing controls, treatment options, cost / feasibility, and response capability.
5. Applicable GOV-001 rules and GOV-009 standards or profiles.
6. Affected artifacts, releases, environments, markets, users, vendors, and operational scopes.

---

# 5. Required Questions

1. What cause could lead to which uncertain event or condition and what impact?
2. Is the item a risk, issue, incident, defect, assumption, constraint, or opportunity?
3. What scope, objective, user, obligation, baseline, gate, or live service is exposed?
4. What are inherent likelihood, impact, exposure, velocity, and detectability under the approved method?
5. Which preventive, detective, responsive, recovery, or compensating controls exist?
6. What treatment is selected, by whom, and by what due event?
7. What residual exposure remains and who may accept it for the exact period?
8. Which indicators, thresholds, triggers, and escalation route apply?
9. What evidence proves control operation or treatment completion?
10. What change, failure, expiry, or realization reopens or escalates the record?

---

# 6. Risk Lifecycle

~~~text
IDENTIFIED
ASSESSED
TREATMENT_PLANNED
IN_TREATMENT
MONITORED
ACCEPTED
TRANSFERRED
REALIZED
CLOSED
SUPERSEDED
~~~

Status remains separate from exposure rating, treatment decision, control health, issue / incident state, and verification status. `ACCEPTED` does not mean safe or resolved; it records accountable acceptance of bounded residual exposure.

---

# 7. Minimum Risk Record

~~~yaml
risk_id:
title:
statement:
cause:
uncertain_event_or_condition:
impact:
category:
scope:
objectives_at_risk: []
affected_artifacts: []
affected_gates: []
source_refs: []
evidence_refs: []
assumption_refs: []
inherent_assessment:
  likelihood:
  impact:
  exposure:
  velocity:
  detectability:
appetite_or_tolerance:
owner:
treatment_strategy:
treatment_actions: []
control_refs: []
indicators: []
triggers: []
response_and_recovery: []
residual_assessment:
  likelihood:
  impact:
  exposure:
acceptance_authority:
accepted_by:
accepted_at:
acceptance_expires_at:
status:
issue_or_incident_refs: []
gov_009_entries: []
review_cadence:
next_review:
reopen_triggers: []
created_at:
updated_at:
~~~

The risk method may refine scales and calculations, but cannot hide the underlying rationale, uncertainty, impact, owners, treatment, residual exposure, or authority.

---

# 8. Classification and Realization Boundary

~~~text
Uncertain future event or condition → RISK
Current harmful state or work blocker → ISSUE
Observed product or code nonconformance → DEFECT / FINDING
Live service disruption or harm → INCIDENT
Unverified proposition used for planning → ASSUMPTION
Fixed boundary → CONSTRAINT
~~~

When a risk is realized, GOV-004 links the resulting issue, incident, defect, change, response, recovery, and affected baseline. Realization does not delete the prior assessment.

---

# 9. Traceability and Gate Use

~~~text
Source / Assumption / Dependency / Signal
→ GOV-004 Risk
→ Treatment / Control / Requirement / Architecture Mechanism
→ Indicator / Verification / Evidence
→ Residual-Risk Decision or Escalation
→ Gate / Release / Operational Condition
→ Realization, Closure, or Reopen
~~~

Critical and high risks have explicit gate disposition. A gate cannot treat unowned or unassessed material risk as implicitly accepted.

---

# 10. Profile Behavior

- **P1:** risks may share a concise register; material cause-event-impact, owner, exposure, treatment, residual risk, authority, and trigger remain.
- **P2:** domain risks, controls, indicators, reviews, and evidence are structured and traceable.
- **P3:** quantitative or scenario analysis where useful, independent assurance, segregation of treatment and acceptance, formal attestations, and continuous control monitoring strengthen.

---

# 11. Verification and Evidence

Verification confirms classification is correct; assessment follows the approved method; evidence supports ratings; treatments and controls have owners and due events; residual risk is current; acceptance authority matches scope and period; realized risks link to operational records; and absence of evidence is not interpreted as low risk.

---

# 12. Exit Criteria

A risk record is complete for its current state when cause-event-impact, category, scope, sources, inherent exposure, owner, treatment, controls, indicators, residual exposure, decision authority, evidence, cadence, affected artifacts, gate disposition, and reopen triggers are explicit. Closure requires evidence that exposure ended, transferred under valid authority, or is no longer material for the stated scope; expired acceptance reopens review.

---

# 13. Reopen and Update Conditions

Update on new evidence, changed likelihood or impact, failed or degraded control, missed action, changed scope or dependency, assumption invalidation, GOV-001 or GOV-009 change, new vulnerability or threat, verification failure, exception expiry, incident, recovery failure, vendor event, release change, or operational threshold breach.

---

# 14. Artifact-Specific Validation Rules

~~~text
GOV4-CVAL-001  Every risk states cause, uncertain event or condition, impact, scope, and owner.
GOV4-CVAL-002  Risk, issue, defect, incident, assumption, and constraint classifications remain distinct.
GOV4-CVAL-003  Inherent and residual exposure use the approved method and retain rationale.
GOV4-CVAL-004  Every treatment and control has owner, due event, verification, and evidence expectation.
GOV4-CVAL-005  Risk acceptance binds exact authority, scope, exposure, conditions, and expiry.
GOV4-CVAL-006  AI cannot accept residual risk or reduce rating without evidence.
GOV4-CVAL-007  Realized risk links to the issue or incident without erasing history.
GOV4-CVAL-008  Material risk and control change triggers gate and downstream impact review.
~~~
