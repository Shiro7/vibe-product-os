# Core Artifact Contract — GOV-008 Traceability Graph

~~~yaml
contract_id: CONTRACT-GOV-008
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-008
artifact_name: Traceability Graph
owning_phase: Cross-phase Governance
gate_or_baseline: Provides relationship and impact evidence for every gate and baseline
default_activation: DERIVED_PERSISTENT_GRAPH
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-002 and all registered canonical objects
primary_downstream: Coverage views, Change Impact Rules and GOV-007 assessment, gates, release, and operations
lifecycle_semantic_source: ../../Cross_Phase_Traceability.md
implementation_specification: ../../Traceability_Graph/Traceability_Graph_Index.md
~~~

---

# 1. Purpose

GOV-008 is the canonical cross-phase graph of Product OS object identities and governed relationships. It preserves why an object exists, what it derives from, where it is realized, how it is verified, what was released, how it operates, and what must reopen after change.

It answers: **Which exact versioned objects are related, by what controlled meaning, for which scope and period, with what source, authority, evidence, confidence, and current status?**

The graph stores identities and edges. Authoritative content remains in its owning artifact, system, design source, repository, evidence store, incident platform, or operational tool. [Cross-Phase Traceability](../../Cross_Phase_Traceability.md) owns the lifecycle-level lineage model; the dedicated [Traceability Graph framework library](../../Traceability_Graph/Traceability_Graph_Index.md) owns the complete operational graph contract. The graph hands candidate impact sets to [Change Impact Rules](../../Change_Impact_Rules/Change_Impact_Rules_Index.md), while [Source / Evidence Model](../../Source_Evidence_Model/Source_Evidence_Model_Index.md) owns source authority/reliability and evidence content/fitness/custody semantics referenced by SOURCE and EVIDENCE nodes. This specialized artifact contract binds the project’s GOV-008 instance to these sources and to the Shared Core Artifact Contract Standard.

---

# 2. Scope and Applicability

GOV-008 is required wherever Product OS claims traceability, coverage, impact, compliance lineage, verification, release identity, or operational learning. Every activated or governed NOT_APPLICABLE artifact resolves to a GOV-002 entry and graph node.

Its activation class is `DRVD` because the graph derives relationships from canonical sources, but its governance contract is persistent and independent. Phase-local matrices and tool dashboards are derived views, not competing graph truth.

---

# 3. Accountabilities

- **Graph owner:** cross-phase governance authority responsible for vocabulary, integrity, versions, and access.
- **Node owners:** GOV-002 and canonical object owners responsible for identity and content source.
- **Edge contributors:** phase and tool owners that assert relationships under controlled semantics.
- **Edge reviewers / authorities:** confirm material, gate-critical, standards, exception, release, and operational edges.
- **View owners:** produce scoped matrices without changing canonical meaning.
- **AI:** may discover, infer, propose, validate shape, and traverse edges; it cannot convert inferred or assumed edges to confirmed coverage or invent missing source, approval, evidence, or adoption.

---

# 4. Required Inputs

1. GOV-002 canonical artifact identities and lifecycle metadata.
2. Versioned object identities from every activated artifact and tool of record.
3. Controlled node classes, edge vocabulary, direction, scope, and status rules.
4. Sources, decisions, standards applicability, evidence, baselines, candidates, releases, and live identities.
5. Change, supersession, retirement, exception, and invalidation events.
6. Gate-specific coverage and impact questions.

---

# 5. Required Questions

1. Does every node resolve to one canonical owner and GOV-002 identity where applicable?
2. Does the edge type express one controlled meaning in the canonical direction?
3. Which object and baseline versions, scope, environment, release, market, or period does the edge bind?
4. What source, evidence, owner, authority, and confidence support it?
5. Is the relationship proposed, active, confirmed, conflicted, invalidated, superseded, retired, or N/A?
6. Can the graph show gaps and orphans rather than manufacture link coverage?
7. Does a derived view preserve filters, versions, and graph provenance?
8. Which downstream objects become review-required after this node or edge changes?
9. Is evidence fresh for the claim and exact target?
10. Can historical state be reconstructed after supersession, change, or retirement?

---

# 6. Controlled Node Classes

~~~text
ARTIFACT
SOURCE FACT ASSUMPTION QUESTION DECISION RISK EXCEPTION EVIDENCE STANDARD
BUSINESS PRODUCT REQUIREMENT EXPERIENCE DESIGN ARCHITECTURE READINESS
IMPLEMENTATION VERIFICATION RELEASE OPERATION EVOLUTION LIFECYCLE
~~~

Extensions require governed vocabulary change. A node class does not replace the canonical artifact or object type owned by its source.

`ARTIFACT` represents a GOV-002 registered container. Objects owned inside the artifact use their semantic class and link through `INCLUDED_IN`.

---

# 7. Canonical Edge Vocabulary

~~~text
CAPTURED_FROM SUPPORTED_BY CONTRADICTS ASSUMES ANSWERS DECIDES DERIVED_FROM
REFINES DECOMPOSES_TO BOUNDS SATISFIES REALIZES ALLOCATED_TO IMPLEMENTED_BY
CONFIGURED_BY MIGRATED_BY VERIFIED_BY EVIDENCED_BY FAILED_BY WAIVED_BY
DEPENDS_ON CONSTRAINED_BY GOVERNED_BY APPLIES_TO NOT_APPLICABLE_TO INCLUDED_IN
EXCLUDED_FROM BASELINED_IN AUTHORIZED_BY RELEASED_AS DEPLOYED_TO OPERATES_AS
MEASURED_BY OBSERVED_BY TRIGGERED_BY REOPENS INVALIDATES SUPERSEDES RETIRES
TRANSFERRED_TO
~~~

Direction is canonical. For example, `REQ-FR-021 VERIFIED_BY VCASE-090` is valid; the inverse written with the same verb is not.

The exact edge meanings, inverse display labels, domains, ranges, cardinalities, and structural rules are defined by [Edge Vocabulary and Direction](../../Traceability_Graph/02_Edge_Vocabulary_and_Direction.md) and [Edge Domain, Range, and Cardinality](../../Traceability_Graph/03_Edge_Domain_Range_and_Cardinality.md).

---

# 8. Minimum Trace Record

~~~yaml
trace_id:
from:
  node_class:
  id:
  version:
  gov_002_entry:
edge:
to:
  node_class:
  id:
  version:
  gov_002_entry:
scope:
  project_or_product:
  release:
  platform:
  market_or_locale:
  environment_or_target:
  standards_profile:
status:
confidence:
source_ref:
evidence_refs: []
owner:
authority:
created_by:
created_at:
reviewed_by:
reviewed_at:
valid_from:
valid_until:
supersedes:
superseded_by:
notes:
~~~

---

# 9. Status and Confidence

Trace status:

~~~text
PROPOSED ACTIVE CONFIRMED CONFLICTED INVALIDATED SUPERSEDED NOT_APPLICABLE RETIRED
~~~

Confidence:

~~~text
CONFIRMED  approved source and evidence support the edge
SUPPORTED  evidence supports it while authority or completeness remains pending
INFERRED   reasoned relationship awaiting confirmation
ASSUMED    provisional relationship backed by an explicit assumption
UNKNOWN    relationship cannot yet be established
~~~

Inferred, assumed, unknown, conflicted, invalidated, and proposed edges do not count as confirmed gate coverage.

---

# 10. Coverage, Orphan, and N/A Rules

Link count is not coverage. Coverage requires semantic correctness, exact versions, complete scope, relevant evidence, and required authority. A missing required edge is a visible gap. An orphan is a governed object that lacks required upstream, downstream, owner, or disposition relationships.

Every `NOT_APPLICABLE` edge records reason, exact scope, evidence, authority where required, and reopen trigger. Absence is missing, not N/A. Exceptions preserve the original obligation and link authority, risk, controls, expiry, and evidence.

---

# 11. Change Impact Contract

~~~text
1. Identify changed node and version.
2. Traverse downstream active edges.
3. Mark affected objects REVIEW_REQUIRED.
4. Classify each as UNAFFECTED, PARTIAL, INVALID, or SUPERSEDED.
5. Find the earliest owning phase with materially invalid truth.
6. Reopen the exact scope and gate.
7. Update or replace edges and evidence without deleting history.
8. Re-evaluate downstream gates proportionally.
9. Confirm release, live, and evolution effects.
~~~

Unknown impact remains visible. Historical edges are invalidated or superseded, not erased.

---

# 12. Required Cross-Phase Spine

~~~text
Source → Fact / Assumption / Question → Decision / Obligation
→ Business → Product → Requirement → Experience → Design → Architecture
→ Engineering Allocation → Implementation / Candidate
→ Verification / Evidence → Release → Live Operation
→ Insight / Evolution / Lifecycle Route → Earliest Affected Baseline
~~~

Standards additionally trace `GOV-001 → GOV-009 → phase obligation → verification → live evidence` without merging governance responsibilities.

---

# 13. Profile Behavior

- **P1:** one compact graph or governed index may represent the chain; critical source, decision, obligation, implementation, verification, release, and live edges remain exact.
- **P2:** artifact-family views, controlled vocabulary, automated validation, and change traversal are structured.
- **P3:** clause-level lineage, independent assurance, signatures where applicable, temporal graph history, stronger evidence integrity, access control, and continuous drift detection strengthen.

---

# 14. Verification and Evidence

Verification checks unique IDs, canonical directions, node and edge types, version / scope binding, GOV-002 resolution, GOV-009 lineage, evidence freshness, confidence, required path completeness, orphan and conflict visibility, supersession history, and derived-view provenance. Screenshots or generic labels cannot replace canonical source identity.

---

# 15. Exit Criteria

GOV-008 is operational for an exact scope or gate when required nodes resolve, mandatory edges are semantically valid and version-bound, confidence is honest, gaps and orphans are visible, applicable GOV-009 chains reach the lifecycle point, evidence is current, and the scoped view is reproducible. Persistent graph completeness is evaluated by scope and time, not as permanent closure.

---

# 16. Reopen and Update Conditions

Update on any node, source, version, applicability, decision, assumption, risk, exception, baseline, design, architecture, source revision, candidate, verification, evidence, release, live identity, incident, outcome, supersession, transfer, or retirement change.

---

# 17. Artifact-Specific Validation Rules

~~~text
GOV8-CVAL-001  Every artifact node resolves to one canonical GOV-002 identity and current version.
GOV8-CVAL-002  Every edge uses a controlled type, canonical direction, exact scope, and source.
GOV8-CVAL-003  Inferred, assumed, unknown, and proposed edges never count as confirmed coverage.
GOV8-CVAL-004  Link count never substitutes for semantic, versioned, evidence-backed coverage.
GOV8-CVAL-005  Missing, conflicted, invalidated, orphaned, and N/A relationships remain explicit.
GOV8-CVAL-006  Change traversal preserves history and identifies the earliest affected baseline.
GOV8-CVAL-007  Phase matrices and tool views cannot become competing graph truth.
GOV8-CVAL-008  AI cannot invent source, approval, adoption, satisfaction, evidence, or confirmed trace.
~~~
