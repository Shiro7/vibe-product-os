# Core Artifact Contract — GOV-007 Change Register

~~~yaml
contract_id: CONTRACT-GOV-007
contract_version: 0.1.0
contract_status: WORKING_DRAFT
artifact_id: GOV-007
artifact_name: Change Register
owning_phase: Cross-phase Governance
gate_or_baseline: Governs material change across all baselines, releases, and live scopes
default_activation: EVENT_DRIVEN_PERSISTENT_REGISTER
inherits: CORE-ARTIFACT-STANDARD@0.2.0
primary_upstream: GOV-003, changed sources, findings, incidents, and evolution decisions
primary_downstream: GOV-002, GOV-008, GOV-009, affected baselines, implementation, verification, and release
implementation_specification: ../../Change_Impact_Rules/Change_Impact_Rules_Index.md
~~~

---

# 1. Purpose

GOV-007 is the canonical cross-phase register for material change. It separates the requested delta, triage, impact analysis, decision authority, approved scope, execution identity, verification, rollout or migration, closure, rollback, and historical effect.

It answers: **What is proposed to change, why, what does it affect, who may authorize it, how will it be executed and verified, and what is its current lifecycle state?**

The dedicated [Change Impact Rules framework library](../../Change_Impact_Rules/Change_Impact_Rules_Index.md) owns the complete operational materiality, candidate assessment, object/evidence disposition, proportional gate/baseline re-entry, action, acknowledgement, closure, exceptional-change, profile, authority, AI, validation, and exchange contracts. This specialized artifact contract binds the project’s GOV-007 instance to that framework library and the Shared Core Artifact Contract Standard.

A change request is not approval. Approval is not implementation. Implementation is not verification. Verification is not release authorization or successful live outcome.

---

# 2. Scope and Applicability

GOV-007 activates for a material change to governing rules, sources, artifact meaning, scope, applicability, decision, requirement, experience, design, architecture, implementation, data, configuration, infrastructure, evidence, release, live operation, ownership, vendor, standard, or lifecycle disposition.

Routine edits with no semantic, dependency, baseline, gate, release, or operational effect may remain in native version history. If uncertainty exists, register the event and classify impact rather than silently treating it as editorial.

---

# 3. Accountabilities

- **Register owner:** change-governance authority responsible for lifecycle integrity.
- **Requester / source owner:** states the need, evidence, and intended outcome.
- **Change owner:** coordinates analysis, approval route, execution, verification, and closure.
- **Impact owners:** assess affected domains, artifacts, baselines, gates, releases, and live services.
- **Decision authority:** approves, rejects, defers, constrains, or rolls back the exact change scope.
- **Implementation / verification / release authorities:** retain their separate authority and evidence duties.
- **AI:** may detect change, traverse impact, compare versions, and draft plans; it cannot approve, execute outside authorization, accept risk, or claim verification or release.

---

# 4. Required Inputs

1. Exact current and proposed states, source, reason, urgency, and evidence.
2. Active baselines, GOV-001 rules, GOV-002 entries, GOV-003 decisions, GOV-004 risks, and GOV-009 entries.
3. GOV-008 downstream and upstream impact traversal.
4. Affected users, markets, contracts, data, platforms, environments, vendors, releases, and live services.
5. Compatibility, migration, rollback, verification, evidence, communication, and operational requirements.
6. Authority, segregation, emergency, exception, and gate rules.

---

# 5. Required Questions

1. What exact object and version changes from what to what?
2. Why is the change needed and which source, decision, defect, risk, incident, finding, or outcome triggered it?
3. Is it editorial, corrective, adaptive, preventive, evolutionary, emergency, deprecation, or retirement change?
4. What are the earliest affected truth and every downstream object, baseline, gate, release, and live scope?
5. Does GOV-001 require amendment or exception? Must GOV-009 applicability be re-evaluated?
6. What risk, compatibility, data migration, rollback, continuity, access, security, privacy, accessibility, audit, and evidence impact exists?
7. Who may authorize this exact scope and which independent reviews are required?
8. What implementation, verification, release, monitoring, and closure evidence are required?
9. How are partial completion, failed verification, rollback, and residual obligations handled?
10. Which conditions reopen the change after closure?

---

# 6. Change Lifecycle

~~~text
PROPOSED
TRIAGED
IMPACT_ASSESSED
APPROVED
REJECTED
DEFERRED
IN_PROGRESS
IMPLEMENTED
VERIFIED
CLOSED
ROLLED_BACK
SUPERSEDED
~~~

Status transitions require their own authority and evidence. A record may expose separate analysis, decision, execution, verification, release, and outcome statuses when one label would hide state.

---

# 7. Minimum Change Record

~~~yaml
change_id:
title:
change_class:
source_event:
reason:
current_state:
proposed_state:
intended_outcome:
scope:
priority:
urgency:
requester:
owner:
source_refs: []
evidence_refs: []
decision_refs: []
risk_refs: []
gov_001_rules: []
gov_002_entries: []
gov_008_impact_traversal:
gov_009_entries: []
affected_artifacts: []
affected_baselines: []
affected_gates: []
affected_releases: []
affected_live_scopes: []
impact_assessments: []
compatibility_plan:
migration_plan:
rollback_plan:
verification_plan:
evidence_expectations: []
communication_plan:
monitoring_plan:
decision_authority:
decision_status:
conditions: []
approved_scope:
implementation_refs: []
verification_refs: []
release_refs: []
outcome_refs: []
status:
closure_evidence: []
residual_obligations: []
reopen_triggers: []
created_at:
updated_at:
closed_at:
~~~

---

# 8. Impact Classification

Each traversed object receives an explicit disposition:

~~~text
UNAFFECTED
REVIEW_REQUIRED
PARTIALLY_AFFECTED
INVALIDATED
STALE
SUPERSEDED
NEWLY_REQUIRED
NOT_APPLICABLE_WITH_EVIDENCE
~~~

No response or missing link is `UNKNOWN`, not `UNAFFECTED`. The earliest invalid owning phase determines the minimum reopen route; downstream work cannot patch over invalid upstream truth.

---

# 9. Emergency Change Boundary

Emergency response may act immediately only within pre-authorized GOV-001 and operational authority. The register captures reason, exact scope, actor, time, affected target, safeguards, evidence, retrospective review, lasting-change route, verification, and rollback. Emergency does not erase segregation, history, or post-action accountability.

---

# 10. Traceability and Handoff

~~~text
Trigger / Source / GOV-003 Decision
→ GOV-007 Change Request
→ GOV-008 Impact Traversal + GOV-009 Re-evaluation
→ Authority and Approved Scope
→ Updated GOV-002 Artifacts / Baselines
→ Implementation Identity
→ Verification and Release Decision
→ Live Monitoring / Outcome
→ Closure, Rollback, or Reopen
~~~

Every receiver gets exact included and excluded scope, current and target versions, conditions, dependencies, prohibited actions, evidence expectations, and acknowledgement.

---

# 11. Profile Behavior

- **P1:** one compact record may combine request, analysis, plan, and disposition; exact authority, impact, implementation, verification, and closure states remain distinct.
- **P2:** domain impact, migration, rollback, evidence, and gate reviews are modular and traceable.
- **P3:** formal change board or equivalent authority, independent impact assurance, segregation, signed approvals where applicable, immutable audit history, and automated graph traversal strengthen.

---

# 12. Verification and Evidence

Verification confirms the delta binds exact versions; impact traversal covers all known active edges; authority matches scope; execution matches approved content; implementation, verification, release, and outcome identities remain separate; rollback is feasible where required; GOV-002 / GOV-008 / GOV-009 are updated; and closure evidence covers residual obligations.

---

# 13. Exit Criteria

A change is complete for its current state when trigger, current and proposed truth, scope, owner, impact, risks, affected objects, authority, conditions, compatibility / migration / rollback, implementation, verification, release, communication, monitoring, evidence, residual obligations, and reopen triggers are explicit. `CLOSED` requires acknowledged downstream disposition and no hidden incomplete impact.

---

# 14. Reopen Conditions

Reopen on source correction, impact discovery, failed migration or rollback, implementation drift, verification failure, release anomaly, live incident, unmet outcome, expired condition, risk increase, GOV-001 or GOV-009 change, affected artifact mismatch, or evidence invalidation.

---

# 15. Artifact-Specific Validation Rules

~~~text
GOV7-CVAL-001  Every material change binds exact current and proposed objects, versions, scope, and owner.
GOV7-CVAL-002  Request, approval, implementation, verification, release, and outcome statuses remain distinct.
GOV7-CVAL-003  Every change performs GOV-008 traversal and GOV-009 re-evaluation where triggered.
GOV7-CVAL-004  Unknown impact cannot be recorded as unaffected.
GOV7-CVAL-005  Approval binds authority, conditions, exact scope, compatibility, migration, and rollback duties.
GOV7-CVAL-006  Emergency action remains bounded, evidenced, reviewable, and routed for lasting change.
GOV7-CVAL-007  AI cannot approve change, accept risk, or claim execution, verification, or release.
GOV7-CVAL-008  Closure requires updated identities, acknowledged impact, evidence, and residual-obligation disposition.
~~~
