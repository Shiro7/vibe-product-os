# Product OS v1.0 — Shared Gate Contract

~~~yaml
contract_id: SHARED-GATE-CONTRACT
contract_version: 0.1.0
contract_status: WORKING_DRAFT
completion_state: SHARED_GATE_CONTRACT_COMPLETE
applies_to:
  - G0
  - G1
  - G2
  - G3A
  - G3B
  - G4A
  - G4B
  - G5A
  - G5B
  - G6A
  - G6B
  - G7
  - G8
classification_source: ../Classification_Rules.md
gate_map_source: ../Gate_Map.md
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This contract defines the obligations inherited by every Product OS gate specification and every project gate decision.

It standardizes:

- exact decision scope;
- applicability and activation;
- upstream decision and baseline identity;
- check status;
- evidence;
- authority, quorum, and independence;
- outcomes;
- conditions;
- risk and exception boundaries;
- validity and expiry;
- handoff permissions and prohibitions;
- reopen, invalidation, and re-entry;
- emergency handling;
- profile behavior;
- automation and AI boundaries;
- decision history and change control.

Individual gate specifications define the decision question, check set, gate-specific blockers, evidence anchors, authorities, outcomes, handoff, and reopen triggers.

---

# 2. Gate Definition

A Product OS gate is an accountable decision on an exact scope and exact baseline, candidate, target, or live state.

A gate is not:

- a date;
- a phase-completion percentage;
- a meeting;
- a document count;
- a checklist total;
- a status imported from a tool;
- evidence of future-phase work;
- a substitute for human or organizational authority;
- a permanent certificate after material change.

---

# 3. Gate Operating Layer

Gate Specifications are FRAMEWORK_ASSET objects.

A project gate decision is a PROJECT_OBJECT governed through:

- GOV-003 decision identity and lifecycle;
- GOV-002 artifact and baseline identities;
- GOV-008 relationships and impact paths;
- GOV-009 applicability and obligation propagation;
- phase validation, baseline, handoff, or dedicated decision artifacts;
- evidence references.

No new project artifact ID is created merely because a gate specification exists.

---

# 4. Gate Activation and Applicability

## 4.1 Activation

A gate activates when:

- its owning phase seeks to accept a baseline or decision scope;
- a downstream consumer requires a valid gate decision;
- material change reopens its decision;
- a recurring or trigger-based G8 review is due;
- an emergency or recovery route requires a bounded decision.

## 4.2 Gate applicability

Use:

~~~text
APPLICABLE
NOT_APPLICABLE
PENDING
~~~

G0 is required for every Product OS entry.

G6B is required for every candidate seeking G7.

G7 is required for every governed production exposure in its scope.

G8 is required for every governed live scope at cadence and trigger events.

For other gates, an unaffected scope may rely on a valid prior decision or be governed N/A for the exact route. Reuse is not N/A.

## 4.3 N/A record

Gate or check N/A requires:

~~~yaml
subject:
scope:
applicability: NOT_APPLICABLE
reason:
source_refs: []
evidence_refs: []
decision_owner:
decision_authority:
approved_by: []
approved_at:
downstream_implications: []
reopen_conditions: []
~~~

Identity, authority, exact scope, decision history, and evidence-index checks cannot be omitted through N/A when a gate decision is issued.

## 4.4 Pending applicability

PENDING identifies missing evidence, owner, due event, safe interim treatment, gate effect, and escalation.

PENDING blocks when either possible answer can materially change scope, obligation, control, design, architecture, implementation, verification, release, or operation.

---

# 5. Exact Gate Scope

Every decision binds:

- project and product identity;
- lifecycle mode;
- phase and gate;
- baseline, candidate, target, or live scope;
- included capabilities, changes, and releases;
- platforms, channels, markets, regions, languages, directions, data classes, users, tenants, cohorts, environments, and third parties where relevant;
- profile and domain overrides;
- explicit exclusions;
- upstream decision versions;
- evidence period;
- decision-validity period.

No decision generalizes to another product, release, target, market, candidate, version, or evidence period without an explicit equivalence decision.

---

# 6. Upstream Decision Integrity

Every gate:

1. identifies exact upstream gate decisions;
2. confirms current lifecycle disposition;
3. confirms baseline or candidate equality;
4. evaluates open conditions;
5. checks change-impact status;
6. verifies that no material upstream decision has expired, reopened, become stale, or been superseded;
7. records reused valid decisions instead of copying approval.

An invalid upstream decision blocks the affected downstream scope unless an authorized emergency route explicitly governs the risk and reconciliation.

---

# 7. Gate Check Contract

Every detailed check records:

~~~yaml
check_id:
check_name:
scope:
applicability:
status:
decision_test:
source_obligations: []
artifact_refs: []
evidence_refs: []
evidence_period:
reviewer:
specialist_reviewers: []
findings: []
condition_refs: []
defect_refs: []
risk_refs: []
exception_refs: []
notes:
last_evaluated_at:
reopen_conditions: []
~~~

Allowed check status:

~~~text
PASS
FAIL
BLOCKED
NOT_REVIEWED
NOT_APPLICABLE
SUPERSEDED
~~~

Rules:

- PASS means the exact decision test is satisfied by current evidence.
- FAIL means evidence demonstrates the test is not satisfied.
- BLOCKED means the check cannot be evaluated because required input, authority, environment, or evidence is unavailable.
- NOT_REVIEWED means no valid evaluation exists.
- NOT_APPLICABLE requires a governed N/A record.
- SUPERSEDED preserves prior check history after a new decision.
- CONDITION is not a check status.
- A non-blocking condition attaches to a PASS check through condition_refs.
- A blocking issue produces FAIL or BLOCKED and prevents a positive gate outcome.

---

# 8. No Percentage Approval Rule

Gate outcome is not calculated by pass percentage.

Rules:

- one material blocker can hold or reject the gate;
- 29 of 30 passed checks cannot offset one critical failed check;
- N/A does not increase completion quality;
- weighted scores may support diagnosis but cannot replace gate authority;
- green dashboards cannot self-approve.

---

# 9. Gate Evidence Contract

The [Source / Evidence Model](../Source_Evidence_Model/Source_Evidence_Model_Index.md) defines source authority/reliability, claim binding, evidence types, fitness/sufficiency/admissibility, provenance/custody/integrity, reuse, access, retention, and evidence-pack semantics consumed by every gate. This section retains the gate-specific minimum and gate-authority boundary.

Every evidence item identifies:

- evidence ID;
- claim or check supported;
- exact target and version;
- method;
- environment and data context;
- result;
- producer;
- reviewer;
- time or evidence period;
- integrity and provenance;
- confidentiality and access;
- retention;
- freshness;
- invalidation triggers.

Evidence must be:

~~~text
RELEVANT
SCOPE_BOUND
VERSION_BOUND
REVIEWABLE
CURRENT_ENOUGH
PROTECTED
DURABLE
HONEST_ABOUT_LIMITATIONS
~~~

File presence, screenshot presence, row count, meeting attendance, AI confidence, or tool status is not sufficient evidence by itself.

---

# 10. Evidence Reuse

Evidence may be reused only when:

- the claim is identical;
- target version and scope are identical or equivalence is proven;
- method remains valid;
- environment and data remain representative;
- source integrity is intact;
- evidence is fresh enough;
- no material change or incident invalidated it;
- the accepting reviewer and authority allow reuse.

Reuse records the original evidence ID and the reuse decision. It does not duplicate evidence or change its period.

---

# 11. Gate Evidence Index

Every decision has an index mapping:

~~~text
Gate Check
→ Source Obligation
→ Artifact or Baseline Object
→ Validation or Verification Method
→ Evidence ID and Period
→ Check Status
→ Reviewer
→ Finding, Condition, Defect, Risk, or Exception
→ Gate Decision Effect
~~~

The evidence index is a view over canonical objects. It cannot create competing truth.

---

# 12. Gate Authority Model

Every gate defines:

- accountable gate owner;
- decision authority;
- required reviewers;
- conditional specialist reviewers;
- risk and exception authorities;
- quorum;
- permitted substitutions;
- acknowledgers;
- conflict-of-interest handling;
- escalation route;
- authority limit.

Actual project roles are mapped through the authority model. A generic role label is not evidence that authority exists.

---

# 13. Quorum

Quorum is satisfied only when:

- all mandatory authority domains for the exact scope are represented;
- substitutions are authorized and recorded;
- decision-makers reviewed the same scope and evidence version;
- conflicts of interest are disclosed and handled;
- risk acceptance is within authority limits;
- required receiving owners acknowledge conditions and restrictions.

Silence, invitation, attendance, or tool access is not approval.

---

# 14. Segregation and Independence

The artifact author may present evidence but cannot be the only approver where:

- independent validation or verification is required;
- the gate authorizes material financial, safety, security, privacy, accessibility, release, or operational risk;
- P3 or an active standard requires segregation;
- the person created the change and controls the only evidence source;
- conflict of interest is material.

P1 can combine roles only when authority is valid, risk is bounded, and the decision record explains how independent challenge was preserved.

---

# 15. AI and Automation Authority Boundary

The complete governing semantics are defined by the [AI Operating Specification](../AI_Operating_Specification/AI_Operating_Specification_Index.md). This section preserves the gate-specific boundary.

AI and automation may:

- collect identities;
- check required fields;
- compare versions;
- detect stale, missing, conflicting, or orphaned objects;
- calculate coverage views;
- validate deterministic rules;
- draft check evaluations;
- summarize evidence;
- recommend outcomes;
- prepare decision records.

AI and automation cannot:

- approve a gate;
- accept risk or exception;
- approve N/A;
- declare compliance;
- invent evidence;
- convert PENDING into PASS;
- authorize production exposure;
- sustain unsafe operation;
- silently substitute decision authority.

Every AI-produced evaluation remains attributable, reviewable, and unapproved until valid authority acts.

---

# 16. Decision Workflow and Outcome

Decision workflow status:

~~~text
OPEN
PROPOSED
IN_REVIEW
APPROVED
DEFERRED
REJECTED
~~~

Decision lifecycle disposition:

~~~text
CURRENT
SUPERSEDED
EXPIRED
REOPENED
~~~

Gate outcome is stored separately.

Examples:

- an approved G5A decision with outcome PASS has workflow status APPROVED and lifecycle CURRENT;
- a G7 authorization after its window has workflow status APPROVED and lifecycle EXPIRED;
- a prior G3B PASS replaced after requirement change has lifecycle SUPERSEDED;
- a reopened G4B decision preserves the prior outcome and uses lifecycle REOPENED until a new decision is issued.

---

# 17. Baseline Outcomes

G0 through G6B use:

## 17.1 PASS

The exact scope is accepted for downstream use with no material blocking deficiency and no special restriction beyond normal controls.

## 17.2 PASS_WITH_CONDITIONS

The exact scope is accepted with explicit, non-blocking conditions and downstream restrictions.

## 17.3 HOLD

Required evidence, decision, authority, dependency, environment, or remediation is incomplete but recoverable. HOLD creates no accepted new baseline.

## 17.4 REJECT

A material deficiency makes the proposed scope unacceptable and requires rework, revised baseline, changed candidate, or changed route. REJECT preserves evidence and identifies re-entry.

---

# 18. G7 Authorization Outcomes

## 18.1 AUTHORIZE

Permits the exact candidate, target, scope, window, and rollout strategy.

## 18.2 AUTHORIZE_WITH_CONDITIONS

Permits only the exact bounded exposure and restrictions recorded.

## 18.3 HOLD

Pauses authorization while readiness, authority, evidence, target state, or dependency is unresolved.

## 18.4 REJECT

Rejects the proposed release and requires a material revision, different candidate, target, strategy, or renewed verification.

Authorization never generalizes to another target or window.

---

# 19. G8 Operational Outcomes

G8 may assign different outcomes to partitioned live scopes.

- SUSTAIN continues operation within accepted boundaries.
- SUSTAIN_WITH_ACTIONS continues with owned non-blocking actions.
- REMEDIATE prioritizes restoration of accepted operating or control state.
- EVOLVE routes an evidence-backed change to the earliest affected phase.
- CONSTRAIN restricts exact live exposure while risk or strategy is resolved.
- SUNSET_REVIEW starts governed retirement analysis.
- TRANSFER_REVIEW starts governed ownership-transfer analysis.
- CRITICAL_ESCALATION starts immediate containment and authority escalation.

G8 outcome does not authorize implementation or release.

---

# 20. Condition Contract

Every condition records:

~~~yaml
condition_id:
originating_gate:
originating_decision:
scope:
statement:
rationale:
non_blocking_basis:
owner:
decision_authority:
receiving_phase:
permitted_actions: []
prohibited_actions: []
required_evidence: []
closure_method:
closure_authority:
due_at:
due_event:
monitoring:
consequence_if_unmet:
reopen_trigger:
status:
closed_at:
closure_evidence: []
~~~

Allowed condition status:

~~~text
OPEN
IN_PROGRESS
SATISFIED
BREACHED
EXPIRED
SUPERSEDED
~~~

---

# 21. Condition Eligibility

A condition is eligible only when:

- it is non-blocking for the current gate question;
- exact affected scope is known;
- risk is understood and within authority;
- owner and due point exist;
- closure evidence and authority exist;
- permitted and prohibited downstream actions are explicit;
- it does not silently weaken a mandatory obligation;
- failure consequence and reopen trigger are explicit.

PASS_WITH_CONDITIONS is not a container for unfinished critical work.

---

# 22. Condition Propagation

Every handoff carries:

- originating gate and decision;
- condition ID;
- affected scope;
- owner;
- due date or trigger;
- permitted work;
- prohibited work;
- required evidence;
- closure authority;
- consequence;
- receiving-phase acknowledgement.

A later gate cannot remove, rename, broaden, or close an upstream condition without the defined authority.

---

# 23. Condition Closure

Close only when accepted closure evidence satisfies the method and scope.

If closure changes an approved baseline, reopen the owning gate and issue a new decision instead of editing the old decision silently.

BREACHED or EXPIRED conditions:

- trigger the recorded consequence;
- reevaluate downstream permissions;
- create change impact;
- reopen the owning or affected gate when material.

---

# 24. Risk, Exception, Waiver, and Condition Separation

- Risk records uncertain exposure and treatment.
- Exception records deviation from a governing obligation or standard.
- Waiver records authorized temporary acceptance where allowed.
- Condition limits or obligates downstream activity after a positive gate outcome.
- Defect records observed failure.
- Open question records missing information or decision need.

One object cannot substitute for another.

---

# 25. Minimum Gate Decision Record

~~~yaml
gate_decision_id:
gate_id:
gate_specification_version:
decision_workflow_status:
decision_lifecycle_disposition:
project_id:
product_id:
phase:
lifecycle_mode:
scope:
  scope_id:
  inclusions: []
  exclusions: []
  releases: []
  platforms: []
  markets: []
  regions: []
  languages_and_directions: []
  data_classes: []
  user_or_tenant_scopes: []
profile:
  default:
  domain_overrides: []
constitution:
  gov_001_version:
  exception_refs: []
upstream:
  gate_decisions: []
  baselines: []
  conditions: []
artifact_register_view:
  gov_002_view_id:
  generated_at:
  artifact_versions: []
standards:
  gov_009_version:
  blocking_pending_entries: []
checks:
  total:
  passed: []
  failed: []
  blocked: []
  not_reviewed: []
  not_applicable: []
  superseded: []
conditions: []
risks: []
exceptions: []
waivers: []
open_questions: []
evidence_index:
decision:
  outcome:
  rationale:
  permitted_next_actions: []
  prohibited_next_actions: []
authority:
  gate_owner:
  decision_makers: []
  reviewers: []
  specialist_reviewers: []
  risk_acceptors: []
  acknowledgers: []
  quorum_rule:
  substitutions: []
  conflicts_of_interest: []
time:
  proposed_at:
  reviewed_at:
  decided_at:
  valid_from:
  valid_until:
handoff:
  receiving_phase:
  handoff_artifact:
  receiver_acknowledgements: []
change:
  reopen_triggers: []
  supersedes:
  superseded_by:
  impact_record:
trace:
  gov_003_decision:
  gov_008_node:
  gov_009_entries: []
~~~

Unknown required values remain explicit. They are never fabricated.

---

# 26. Decision Immutability

An issued gate decision is immutable.

Corrections create:

- a linked correction record for non-semantic clerical error; or
- a superseding gate decision for changed meaning, scope, evidence, authority, condition, or outcome.

The historical decision, evidence, and time remain reconstructable.

---

# 27. Baseline Creation

For G0 through G6B:

- PASS accepts the exact baseline or candidate scope;
- PASS_WITH_CONDITIONS accepts it with restrictions;
- HOLD and REJECT do not create an accepted new baseline;
- baseline identity includes artifact versions, decision ID, GOV-001 version, GOV-002 view, GOV-009 version, evidence index, and conditions.

G7 creates an authorization, not a product baseline.

G8 records operational routing and may update OBL and evolution objects.

---

# 28. Handoff Contract

A positive outcome handoff contains:

- exact decision and baseline identity;
- included and excluded scope;
- accepted evidence index;
- open conditions;
- risks, exceptions, waivers, defects, and questions;
- permitted and prohibited next actions;
- receiving owner;
- acknowledgement;
- change and rejection route;
- validity and reopen triggers.

HOLD and REJECT produce disposition records, not normal downstream authorization.

---

# 29. Consumer Boundary

A downstream consumer may:

- rely on the accepted scope within validity;
- refine its own canonical objects;
- add stronger controls;
- request clarification;
- raise a change or reopen trigger.

A downstream consumer may not:

- reinterpret upstream scope silently;
- close conditions without authority;
- turn a candidate into approved meaning;
- generalize a gate outcome;
- bypass a later gate;
- present a baseline as implementation or verification.

---

# 30. Gate Validity

Validity depends on:

- unchanged material scope;
- unchanged baseline or candidate;
- current assumptions and dependencies;
- current standards applicability;
- current evidence;
- active authority and approval;
- open conditions within bounds;
- no invalidating incident or finding.

G7 also expires at the end of its release window.

G8 expires at its next review or trigger event.

---

# 31. Common Reopen Triggers

~~~text
MATERIAL_SCOPE_CHANGE
UPSTREAM_BASELINE_REVISION
NEW_OR_INVALIDATED_EVIDENCE
CRITICAL_DEFECT_OR_INCIDENT
STANDARDS_OR_APPLICABILITY_CHANGE
EXPIRED_CONDITION_EXCEPTION_WAIVER_OR_APPROVAL
DEPENDENCY_OR_VENDOR_CHANGE
TARGET_ENVIRONMENT_OR_CONFIGURATION_CHANGE
NEW_USER_MARKET_PLATFORM_REGION_LANGUAGE_OR_DATA_SCOPE
MATERIAL_RISK_OR_ASSUMPTION_CHANGE
FAILED_DOWNSTREAM_VALIDATION
LIFECYCLE_MODE_CHANGE
AUTHORITY_CHANGE
~~~

Each gate specification adds gate-specific triggers.

---

# 32. Downstream Impact Status

When an upstream gate reopens, downstream decisions are classified:

~~~text
UNAFFECTED
REVIEW_REQUIRED
PARTIALLY_INVALIDATED
FULLY_INVALIDATED
SUPERSEDED
~~~

Impact status does not change automatically from adjacency alone. It follows exact trace relationships and changed meaning.

---

# 33. HOLD Routing

Route the missing or invalid meaning to its canonical owner:

| Gap | Normal route |
|---|---|
| Project identity, entry, source, or immediate classification | Phase 00 |
| Problem, current state, cause, outcome, or discovery evidence | Phase 01 |
| Business rule, control, ownership, process, or business information | Phase 02 |
| Product boundary, capability, module, state, policy, or release scope | Phase 03 |
| Requirement, acceptance, quality, data, integration, or control obligation | Phase 04 |
| Journey, flow, IA, navigation, state, interaction, or experience content | Phase 05 |
| Design system, component, screen, visual state, content realization, or design source | Phase 06 |
| Architecture mechanism, data design, trust boundary, deployment, or ADR | Phase 07 |
| Allocation, work item, dependency, DoR, DoD, environment, or evidence plan | Phase 08 |
| Source change, build, migration, implementation, deployment candidate, or deviation | Phase 09 |
| Verification evidence, defect, waiver, release target, authorization, or execution | Phase 10 |
| Live health, incident, sustainability, lifecycle, evolution, sunset, or transfer | Phase 11 |

---

# 34. REJECT Routing

REJECT identifies:

- material deficiency;
- rejected exact scope;
- evidence and rationale;
- earliest affected owner and phase;
- required rework or alternate route;
- downstream decisions invalidated;
- resubmission requirements.

The team does not automatically repeat unaffected phases.

---

# 35. Brownfield Decision Reuse

A prior gate decision is reusable only when:

- scope matches;
- baseline identity resolves;
- decision is current;
- evidence remains fit;
- conditions remain satisfied or bounded;
- standards applicability remains valid;
- no incident or change invalidated it;
- receiving authority accepts reuse.

If a prior decision cannot be reconstructed, it cannot be treated as approved history.

---

# 36. Emergency Handling

Emergency handling may compress preparation, review sequence, and meeting form. It does not remove:

- exact identity;
- minimum decision evidence;
- authority;
- risk and impact;
- containment, pause, rollback, or recovery;
- observability;
- decision and execution record;
- post-event reconciliation.

Emergency action outside a normal positive gate outcome records:

- emergency authority;
- exact allowed action;
- time bound;
- risk;
- reason normal sequence cannot be used;
- evidence preserved;
- required post-event gate review.

---

# 37. Profile Behavior

## 37.1 P1

- gate record may be embedded in a compact pack;
- all check IDs and dispositions remain addressable;
- one person may hold multiple roles only within authority and independence limits;
- evidence may be compact but remains scope- and version-bound;
- no applicable check disappears.

## 37.2 P2

- independently reviewable decision record;
- explicit check-evidence matrix;
- named specialist reviews;
- formal condition and handoff tracking;
- reproducible artifact-register view.

## 37.3 P3

- formal quorum;
- segregation of duties;
- independent assurance;
- controlled evidence custody and retention;
- signatures or attestations where required;
- formal minutes and dissent;
- stricter expiry and revalidation;
- machine-enforced policy checks plus human decision.

---

# 38. Domain Overrides

The highest active domain profile governs:

- relevant checks;
- required specialist reviewers;
- evidence depth;
- authority;
- retention;
- independent review;
- closure evidence.

A P1 project with P3 security or privacy treatment applies P3 to affected gate checks across all phases.

---

# 39. Gate Session Contract

A gate session requires:

- published exact scope;
- evidence index version;
- decision question;
- check dispositions;
- known blockers and conditions;
- required authorities;
- conflict and dissent handling;
- decision recording owner.

Last-minute material evidence changes pause the decision unless all required reviewers can evaluate the same updated version.

---

# 40. Dissent and Conflict

Material dissent records:

- dissenting role;
- affected check;
- evidence;
- risk;
- proposed outcome;
- authority route;
- final disposition.

Quorum cannot erase unresolved specialist veto or authority limit defined by GOV-001, law, contract, safety, or active standards.

---

# 41. Gate Metrics Guardrail

Allowed diagnostic measures include:

- check coverage;
- blocked and failed checks;
- condition age and breach;
- evidence freshness;
- decision cycle time;
- reopen rate;
- stale decision count;
- invalidation propagation time.

Metrics cannot prove correctness, approval quality, compliance, or safety by themselves.

---

# 42. Gate Automation

Automation may enforce:

- schema completeness;
- ID uniqueness;
- allowed vocabulary;
- link resolution;
- exact version binding;
- evidence freshness;
- digest equality;
- check count;
- condition fields;
- signature presence;
- invalidation triggers;
- prohibited candidate or target mismatch.

Automated failure blocks the automated policy check. Human authority decides only within permitted override and exception rules.

---

# 43. Tool Boundary

Ticket, document, spreadsheet, design, repository, CI, test, release, and operations tools may store gate objects.

The canonical gate index preserves:

- stable decision ID;
- source tool and record ID;
- version;
- owner;
- outcome;
- validity;
- evidence index;
- canonical URL or location;
- supersession.

Moving a record between tools does not create new approval.

---

# 44. Gate Anti-Patterns

Invalid practices:

1. gate by calendar;
2. gate by document length;
3. gate by percentage;
4. gate by tool color;
5. approving unknown scope;
6. approving without exact baseline version;
7. silent positive outcome with conditions;
8. condition without consequence;
9. HOLD used to hide a known failure;
10. REJECT without re-entry;
11. stale evidence reuse;
12. self-authorized material risk;
13. copied approval;
14. N/A without evidence;
15. G6A presented as independent verification;
16. G6B presented as release permission;
17. G7 presented as production-health proof;
18. G8 presented as permanent certification;
19. AI-issued gate outcome;
20. editing an issued decision in place.

---

# 45. Shared Validation Rules

~~~text
GATE-VAL-001  Every gate binds exact project, product, scope, and version.
GATE-VAL-002  Every positive outcome identifies exact permitted and prohibited next actions.
GATE-VAL-003  Every required check has an allowed status and evidence or governed N/A.
GATE-VAL-004  CONDITION is not used as a canonical check status.
GATE-VAL-005  Every check condition reference resolves to a complete condition record.
GATE-VAL-006  Every outcome has accountable human or organizational authority.
GATE-VAL-007  Every gate records quorum, substitutions, and conflicts of interest.
GATE-VAL-008  Every risk acceptance is within named authority limits.
GATE-VAL-009  Every evidence item binds claim, target, version, method, result, time, producer, and integrity.
GATE-VAL-010  Evidence reuse has an explicit fitness decision.
GATE-VAL-011  File, meeting, screenshot, row count, or tool status alone cannot pass a check.
GATE-VAL-012  Pass percentage cannot override a material failed or blocked check.
GATE-VAL-013  Every condition is non-blocking for the current gate question.
GATE-VAL-014  Every condition has scope, owner, due point, evidence, restriction, consequence, and closure authority.
GATE-VAL-015  Conditions propagate to every affected downstream consumer.
GATE-VAL-016  A breached or expired condition triggers its recorded consequence.
GATE-VAL-017  Every HOLD identifies the missing input, owner, and route.
GATE-VAL-018  Every REJECT identifies material deficiency, affected scope, and re-entry.
GATE-VAL-019  Every gate identifies upstream decision and baseline versions.
GATE-VAL-020  Every reopened upstream gate triggers downstream impact assessment.
GATE-VAL-021  Every issued decision is immutable and historically reconstructable.
GATE-VAL-022  Every superseding decision links prior and new meaning.
GATE-VAL-023  Every gate records active GOV-001 version and exceptions.
GATE-VAL-024  Every gate consumes a reproducible exact-scope GOV-002 view.
GATE-VAL-025  Every gate links relevant GOV-008 relationships.
GATE-VAL-026  Every gate evaluates relevant GOV-009 entries and blocking pending applicability.
GATE-VAL-027  Every gate preserves applicability, check status, decision status, outcome, and lifecycle as separate dimensions.
GATE-VAL-028  Gate N/A follows Classification Rules and cannot mean missing.
GATE-VAL-029  Reused gate decisions remain exact, current, reconstructable, and accepted for reuse.
GATE-VAL-030  Brownfield and re-entry review the earliest affected gate rather than restarting automatically.
GATE-VAL-031  Emergency handling preserves minimum identity, authority, evidence, containment, and reconciliation.
GATE-VAL-032  P1 packaging preserves all applicable check identities and evidence.
GATE-VAL-033  Domain overrides apply the highest required treatment to affected checks.
GATE-VAL-034  Independent review is preserved when risk, profile, or standard requires it.
GATE-VAL-035  AI and automation cannot approve outcome, N/A, risk, exception, waiver, release, or operation.
GATE-VAL-036  Automated checks expose override authority and evidence.
GATE-VAL-037  G6A cannot mark independent verification complete.
GATE-VAL-038  G6B cannot authorize production exposure.
GATE-VAL-039  G7 cannot authorize an unequal candidate, ambiguous target, or reused expired window.
GATE-VAL-040  G8 cannot replace G7 for live change.
GATE-VAL-041  G8 partitions live scope when outcomes differ.
GATE-VAL-042  Gate metrics cannot substitute for decision evidence or authority.
GATE-VAL-043  Gate-tool migration preserves identity, history, versions, and approval.
GATE-VAL-044  Every gate lists gate-specific validity and reopen triggers.
GATE-VAL-045  Every gate handoff has receiving-owner acknowledgement where required.
GATE-VAL-046  No gate claims more than its decision question.
GATE-VAL-047  HOLD and REJECT do not create an accepted new baseline.
GATE-VAL-048  G7 creates a time-bound authorization rather than a product baseline.
GATE-VAL-049  G8 outcome does not authorize implementation or release.
GATE-VAL-050  Gate Specifications remain framework assets and do not alter the 281 project-artifact count.
~~~

---

# 46. Shared Exit Criteria

An individual gate specification is complete when it defines:

- purpose and boundary;
- exact scope and activation;
- upstream decision and artifact map;
- authorities and quorum;
- complete detailed check set;
- evidence anchors;
- outcome and blocker rules;
- condition treatment;
- decision record specialization;
- handoff permissions and prohibitions;
- validity and reopen triggers;
- profile and domain override behavior;
- automation and AI boundaries;
- gate-specific validation rules.

---

# 47. Change Control

Changing this Shared Gate Contract requires:

- changed rule IDs;
- affected gate specifications;
- phase-methodology impact;
- Gate Map impact;
- Core Artifact Contract impact;
- Classification Rules impact;
- traceability and change-impact consequences;
- schema, repository, tool, and automation impact;
- migration;
- approving Product OS authority;
- version update.

---

# 48. Final Shared Gate Principle

> **A gate is trustworthy only when an accountable authority can reconstruct exactly what was decided, for which scope and version, from which evidence, under which conditions, for how long, what is allowed next, and what reopens the decision.**
