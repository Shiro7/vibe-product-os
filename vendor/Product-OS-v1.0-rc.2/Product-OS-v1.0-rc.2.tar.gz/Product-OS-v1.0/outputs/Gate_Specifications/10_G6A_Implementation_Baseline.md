# Gate Specification — G6A Implementation Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G6A
version: 0.1.0
status: WORKING_DRAFT
gate_id: G6A
gate_name: Implementation Baseline
owning_phase: Phase 09 - Implementation
primary_object: IBL - Implementation Baseline / IVCAND
check_count: 30
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
candidate_register: IMP-029
validation_artifact: IMP-030
handoff_artifact: IMP-031
baseline_index: IMP-032
semantic_source: ../Phase_09_Implementation.md
~~~

---

# 1. Decision and Boundary

G6A decides whether named scope exists as traceable, reviewed, check-passing, safely migrated, deployable implementation with truthful status, controlled deviations, complete implementation evidence, and a stable Phase 10 verification candidate.

G6A does not perform independent Phase 10 verification and does not authorize release.

---

# 2. Scope and Activation

G6A binds one coherent implementation snapshot:

- release and slice scope;
- repositories, remotes, branches, base and head revisions;
- artifacts and digests;
- schemas, migrations, configuration, infrastructure, environments, deployments, flags, and data state;
- profile and domain overrides;
- known defects, deviations, debt, and conditions;
- exact IMP-029 candidate identity.

Partial scope records exclusions, shared dependencies, prohibited verification, and invalidation behavior.

---

# 3. Canonical Inputs and Records

IMP-001 through IMP-028 own implementation scope, execution, change, controls, evidence, defects, deviations, and readiness data. IMP-029 owns candidate identity. IMP-030 owns validation evidence. IMP-031 owns the Phase 10 handoff. IMP-032 indexes the implementation baseline. GOV-003 stores the typed G6A decision.

---

# 4. Authority

Required roles are selected from:

- Engineering Lead;
- Repository or Module Owners;
- Solution Architect;
- Product Design or Experience Owner;
- Security or Privacy Owner;
- Data or Migration Owner;
- Platform or Operations Owner;
- QA or Verification Lead;
- Product Owner;
- business or regulatory authority when required.

Verification acknowledgement confirms the candidate can be evaluated. It does not approve verification results.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G6A-01 Scope and Baseline Integrity | G5B scope, upstream versions, profile, conditions, and implemented boundaries match with no hidden expansion. | IMP-001; ENG-031; upstream decisions |
| G6A-02 Repository, Branch, and Revision Identity | Canonical repositories, remotes, branches, base and head revisions, and intended changes resolve. | IMP-003; repository evidence |
| G6A-03 Work-Item Implementation Status | Every scoped item has truthful disposition, owner, source changes, and evidence. | IMP-001; work records |
| G6A-04 Change Set and Review Integrity | Changes are coherent, required reviewers acted on exact revisions, findings are resolved, and unrelated changes are visible. | IMP-003; review evidence |
| G6A-05 Build and Artifact Integrity | Builds, locks, warnings, artifacts, provenance, signing where required, and source mapping are valid. | IMP-027; IMP-028 |
| G6A-06 Developer and Integration Checks | Required format, lint, type, static, unit, component, contract, integration, build, startup, and smoke checks pass. | IMP-028; CI evidence |
| G6A-07 UI and Design-System Implementation | Tokens, components, screens, states, content, assets, responsive, platform, RTL, accessibility, motion, and outputs are implemented. | IMP-005; DES-023 |
| G6A-08 Design Parity and Adoption | Design source revisions, actual product adoption, parity evidence, and approved divergence are exact. | IMP-005; design evidence |
| G6A-09 Domain and Application Behavior | Rules, transitions, validation, concurrency, errors, recovery, and approved behavior are implemented. | implementation records; requirement trace |
| G6A-10 API, Event, Job, and Integration Contracts | Schemas, versions, security, errors, idempotency, ordering, retry, compatibility, observability, and checks are implemented. | IMP-007 |
| G6A-11 Data and Schema Integrity | Ownership, classification, constraints, indexes, lifecycle, access, and compatibility are implemented. | IMP-008 |
| G6A-12 Migration and Backfill Execution | Prechecks, backup, execution, validation, reconciliation, recovery, evidence, and environment status are complete. | IMP-008; execution evidence |
| G6A-13 Identity, Authentication, Session, and Recovery | Identity trust, credentials, MFA or federation, sessions, revocation, recovery, failure controls, and evidence match ABL/RBL. | IMP-009 |
| G6A-14 Authorization, Tenancy, and Administrative Access | Policy enforcement, default deny, tenant propagation, isolation, delegation, support access, audit, and checks exist. | IMP-010 |
| G6A-15 Security and Privacy Controls | Controls exist in source, configuration, and infrastructure with safe failure, telemetry, evidence, and no exposed secret. | IMP-011 |
| G6A-16 Audit and Evidence Mechanisms | Required events, context, outcomes, integrity, retention, access, monitoring, and samples exist. | IMP-012 |
| G6A-17 Accessibility and Localization | Semantics, keyboard, focus, forms, errors, reflow, reduced motion, locale, RTL, time, money, fonts, and outputs are implemented. | IMP-013 |
| G6A-18 Reliability and Failure Handling | Timeouts, retries, idempotency, isolation, degradation, unknown outcomes, reconciliation, backup, restore, and recovery exist. | IMP-014 |
| G6A-19 Performance, Capacity, and Resource Controls | Budgets, caching, queries, payloads, queues, backpressure, quotas, scaling, instrumentation, and sanity evidence exist. | IMP-015 |
| G6A-20 Observability, Logging, Health, and Alerts | Safe logs, metrics, traces, correlation, health, dashboards, alerts, redaction, retention, access, and ownership exist. | IMP-016 |
| G6A-21 Configuration, Secrets, Keys, and Flags | Sources, schemas, isolation, access, rotation, revocation, defaults, failure, rollout, removal, and evidence are controlled. | IMP-017 |
| G6A-22 Infrastructure, Environment, and Network Changes | Plans, approvals, target identity, apply results, access, exposure, cost, validation, drift, and rollback are controlled. | IMP-018 |
| G6A-23 CI/CD and Supply Chain | Source protections, checks, scans, build identity, artifacts, registries, promotion, migration, deployment, and retention are governed. | IMP-027 |
| G6A-24 Deployment, Rollout, and Runtime Health | Exact project, environment, domain, artifact, config, migration, flag, startup, smoke, health, and rollback identity resolve. | deployment evidence; IMP-016 through IMP-018 |
| G6A-25 Dependencies, Licenses, and Generated Code | Purpose, source, version, lock, license, security, provenance, review, tests, update, and removal are governed. | dependency and supply-chain evidence |
| G6A-26 Defects, Blockers, Deviations, and Debt | No hidden critical item exists; deviations and debt have approved Phase 10 and release treatment. | defect, deviation, debt records |
| G6A-27 GOV-009 Implementation Status | Every active obligation has mechanism, evidence, remaining verification, exception, and operational owner without overstated conformity. | GOV-009; implementation maps |
| G6A-28 Coverage and Traceability | Requirements, states, designs, architecture, controls, work, changes, candidate, and evidence form a complete bidirectional chain. | GOV-008; implementation coverage views |
| G6A-29 Verification Candidate Integrity | Source, artifact, schema, migration, config, environment, deployment, flag, data, known items, and evidence are immutable and exact. | IMP-029 |
| G6A-30 Phase 10 Handoff | Verification owners acknowledge candidate, scope, environments, data, allocations, evidence, restrictions, change rules, and open items. | IMP-031 |

---

# 6. Gate-Specific Blocking Conditions

G6A cannot pass with a material:

- invalid G5B scope or revision;
- unreviewed or untraceable source change;
- failed required build, startup, migration, or check;
- unknown repository, artifact, deployment, environment, or configuration identity;
- missing critical state, control, or migration;
- unresolved critical or high defect;
- unapproved design, architecture, requirement, or standard deviation;
- exposed secret or unsafe configuration;
- unknown migration integrity;
- missing runtime-health or diagnostic evidence;
- mutable or ambiguous candidate;
- absent Phase 10 acknowledgement.

---

# 7. Outcomes

- PASS permits the exact IMP-029 candidate to enter full Phase 10 verification.
- PASS_WITH_CONDITIONS permits named verification only within explicit limits and prohibits affected sign-off or release.
- HOLD pauses for missing implementation, evidence, environment, identity, or decision.
- REJECT requires correction and a new or superseding candidate decision.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G6A
implementation_baseline:
engineering_readiness_baseline:
candidate_id:
release_and_slice_scope:
source_revisions: []
artifact_digests: []
schema_and_migration_state:
configuration_profile:
infrastructure_and_environment_state:
deployment_ids: []
feature_flag_state: []
required_check_results: []
known_defects: []
deviations: []
debt: []
phase_10_handoff:
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

---

# 9. Candidate Equality and Handoff

IMP-031 carries exact candidate and baseline identities, scope, acceptance and verification allocations, data and identities, design and architecture mappings, evidence, defects, deviations, conditions, invalidation rules, owners, and support contacts.

Any material candidate change after G6A invalidates the positive decision and requires the approved delta or re-gate path.

---

# 10. Validity and Reopen

Reopen for source, artifact, schema, migration, configuration, secret reference, infrastructure, environment, deployment, flag, dependency, generated code, defect, deviation, standards status, evidence, or candidate-integrity change.

---

# 11. Profile and Automation

- P1 preserves thirty checks and exact candidate identity even when implementation records are composed.
- P2 independently reviews material implementation domains, validation, handoff, and baseline index.
- P3 strengthens review segregation, provenance, signing, migration assurance, supply-chain evidence, independent control review, and immutable candidate custody.
- Automation may verify commits, digests, builds, checks, mappings, manifests, migrations, and deployment identity; it cannot claim independent verification or approve risk.

---

# 12. G6A Validation Rules

~~~text
G6A-VAL-001  All thirty G6A checks exist exactly once.
G6A-VAL-002  G6A binds one immutable, reproducible candidate snapshot.
G6A-VAL-003  Build success cannot substitute for implementation coverage or runtime evidence.
G6A-VAL-004  Critical defects, failed required checks, and ambiguous identity prevent a positive outcome.
G6A-VAL-005  Candidate changes trigger invalidation or an approved delta route.
G6A-VAL-006  IMP-030 validates and does not self-approve G6A.
G6A-VAL-007  IMP-031 acknowledgement is required for permitted Phase 10 verification.
G6A-VAL-008  G6A cannot claim independent verification or release authorization.
~~~
