# Gate Specification — G6B Verification Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G6B
version: 0.1.0
status: WORKING_DRAFT
gate_id: G6B
gate_name: Verification Baseline
owning_phase: Phase 10A - Verification
primary_object: VBL - Verification Baseline
check_count: 30
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
decision_artifact: VRL-028
primary_candidate_source: IMP-029
semantic_source: ../Phase_10_Verification_and_Release.md
~~~

---

# 1. Decision and Boundary

G6B decides whether the exact G6A-accepted candidate satisfies applicable approved obligations with independent, traceable, risk-proportionate, candidate-bound evidence.

G6B verifies the candidate. It does not authorize production exposure.

---

# 2. Scope and Activation

G6B is mandatory for every candidate seeking G7.

It binds exact:

- candidate revision and artifact digests;
- source, schema, migration, configuration, environment, deployment, feature-flag, data, identity, platform, market, language, and third-party scope;
- verification strategy and evidence period;
- applicable standards and profiles;
- known defects, waivers, residual risks, and release restrictions.

Cancellation or rejection is an outcome, not N/A.

---

# 3. Canonical Inputs and Records

VRL-001 through VRL-027 provide verification scope, candidate identity, strategy, results, coverage, defects, acceptance, evidence, and readiness. VRL-028 is the immutable VBL and G6B decision artifact. GOV-003 registers the decision; GOV-008 and GOV-009 preserve lineage.

---

# 4. Authority and Independence

Required roles are selected from:

- Verification or Quality authority;
- Product authority;
- Engineering authority;
- Security or Privacy authority when applicable;
- Accessibility authority when applicable;
- Data or Platform authority when applicable;
- Business or UAT authority when required.

The evidence producer cannot be the only verifier for material risk. G6B requires independent challenge proportional to profile and risk.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G6B-01 Scope and Candidate Identity | Scope, exclusions, commits, artifacts, manifests, dependencies, schema, configuration, and integrity match G6A. | IMP-029; VRL-002; G6A decision |
| G6B-02 Strategy and Risk | Methods, depth, independence, prioritization, and risk model cover the accepted scope. | verification strategy; GOV-004 |
| G6B-03 Environment, Data, and Identity | Environments, data, roles, tenants, clients, platforms, and variants are controlled and representative. | VRL-002; environment evidence |
| G6B-04 Functional and Business Rules | Behavior, criteria, calculations, validations, policies, lifecycle rules, and critical outcomes are satisfied. | functional results; REQ trace |
| G6B-05 States, Failure, and Recovery | Empty, loading, partial, error, retry, timeout, degraded, interrupted, recovery, and terminal states are verified. | state and recovery results |
| G6B-06 Concurrency and Idempotency | Duplicate, concurrent, replayed, delayed, reordered, and interrupted operations preserve invariants. | concurrency evidence |
| G6B-07 API, Contracts, and Integrations | Behavior, compatibility, schema, auth, error, limit, dependency, and fallback obligations are verified. | contract and integration results |
| G6B-08 Events, Jobs, Offline, and Sync | Retry, dead-letter, reconciliation, scheduling, background, offline, conflict, and synchronization behavior are verified. | asynchronous and sync evidence |
| G6B-09 Design, Interaction, and Content | Approved design behavior, states, responsive, motion, content, and generated surfaces are verified. | design QA evidence |
| G6B-10 Accessibility | Applicable requirements are verified across platforms, assistive technologies, inputs, journeys, errors, documents, and third parties. | accessibility results and evidence |
| G6B-11 Localization and Global Behavior | Locales, scripts, RTL/LTR, formatting, time, calendar, currency, pluralization, truncation, and fallback work. | localization results |
| G6B-12 Security, Authentication, and Sessions | Identity, credential, MFA, session, token, expiry, rotation, revocation, and abuse defenses are verified. | security test evidence |
| G6B-13 Authorization, Tenancy, and Administration | Least privilege, object access, role transition, isolation, impersonation, elevation, and administrative controls are verified. | authorization and tenancy evidence |
| G6B-14 Privacy | Collection, purpose, minimization, consent, rights, retention, disclosure, and sensitive handling are verified. | privacy validation evidence |
| G6B-15 Auditability | Required events, actors, timestamps, context, outcomes, integrity, protection, retrieval, retention, and access are verified. | audit evidence |
| G6B-16 Performance and Capacity | Latency, throughput, concurrency, resources, limits, scaling assumptions, and critical workloads meet requirements. | load and capacity evidence |
| G6B-17 Resilience and Failure Modes | Timeout, retry, backpressure, circuit, degradation, partial failure, recovery, and fail-open or fail-closed behavior are verified. | fault and resilience evidence |
| G6B-18 Backup, Restore, and Disaster Recovery | Backup success, protection, restore validity, procedures, objectives, ownership, and exercises are evidenced. | backup and recovery evidence |
| G6B-19 Migration and Data Integrity | Migration, transform, backfill, compatibility, checksum, reconciliation, restart, repair, and rehearsal are verified. | migration evidence |
| G6B-20 Deployment, Configuration, and Supply Chain | Deployment, infrastructure, config, secret references, provenance, dependency risk, and parity are verified. | deployment and supply-chain evidence |
| G6B-21 Observability and Operations | Health, logs, metrics, traces, dashboards, alerts, synthetics, runbooks, diagnostics, and critical visibility work. | operational-readiness evidence |
| G6B-22 Enterprise and Conditional Profiles | Enterprise identity, provisioning, export, retention, residency, contract, market, and conditional profiles are verified. | active-profile evidence |
| G6B-23 User and Business Acceptance | UAT covers approved journeys and policies under representative conditions with authorized disposition. | VRL-022; UAT evidence |
| G6B-24 Defects, Retest, and Regression | Defects are classified; fixes retested; regression complete; unresolved items governed. | defect and regression records |
| G6B-25 Waivers and Residual Risk | Waivers are permitted, scoped, current, authorized, monitored, time-limited, and visible to G7. | waiver and risk records |
| G6B-26 Evidence Quality | Evidence is durable, reviewable, relevant, candidate-bound, environment-bound, protected, and sufficient. | evidence index |
| G6B-27 Coverage and Traceability | Obligations, risks, platforms, roles, variants, controls, changes, and historical failures have visible coverage and gaps. | GOV-008; coverage views |
| G6B-28 GOV-009 Applicability | Applicable standards and profiles are verified; exceptions are governed; claims do not exceed evidence. | GOV-009; criterion evidence |
| G6B-29 Candidate Stability | Candidate is frozen, reproducible, stored, integrity-checked, and protected from uncontrolled change. | IMP-029; artifact custody evidence |
| G6B-30 Release Handoff | Release receives VBL, candidate, evidence, defects, waivers, risks, constraints, monitoring, and prohibitions. | VRL-028; release handoff |

---

# 6. Gate-Specific Blocking Conditions

G6B cannot pass when:

- candidate identity is ambiguous, mutable, unequal to G6A, or compromised;
- a critical obligation is untested or failed;
- a critical defect remains;
- tenant isolation or core authorization is unproven;
- material migration or data integrity is uncontrolled;
- required accessibility, security, privacy, audit, legal, or conditional profile is unproven;
- recovery-critical behavior is unverified;
- evidence cannot be reviewed or tied to the candidate;
- residual risk lacks valid authority;
- conformity is overstated;
- required UAT authority is absent;
- Release cannot identify operating constraints.

---

# 7. Outcomes

- PASS accepts the exact VBL for G7 consideration.
- PASS_WITH_CONDITIONS accepts VBL with explicit release prerequisites or restrictions.
- HOLD pauses for incomplete evidence, execution, environment, ownership, or remediation.
- REJECT declares the candidate unacceptable and requires a new or materially revised candidate.

---

# 8. Decision Record Specialization

VRL-028 includes:

~~~yaml
gate_id: G6B
verification_baseline:
implementation_candidate:
scope:
strategy:
environment_data_identity_profile:
check_results:
verification_results: []
coverage_summary:
blocking_defects: []
open_defects: []
accepted_waivers: []
residual_risks: []
release_restrictions: []
outcome:
conditions: []
decision_makers: []
valid_until:
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

The G7 handoff includes VBL, exact candidate, known limitations, waivers, residual risks, conditions, production validation, monitoring, rollback triggers, support implications, and prohibited targets, cohorts, or configurations.

G7 may decide exposure. It may not rewrite verification results or substitute a different candidate.

---

# 10. Validity and Reopen

Reopen for material candidate change, invalidated evidence, new critical defect, changed applicability, expired waiver, compromised artifact, changed target assumptions, failed rehearsal, external dependency change, stale threat intelligence, expired certificate, or changed platform policy.

---

# 11. Profile and Automation

- P1 preserves thirty checks, independence, candidate binding, and evidence even when reporting is compact.
- P2 uses independent verification records and reviewable evidence indexes.
- P3 strengthens segregation, controlled environments, specialist assurance, custody, replayability, retention, and formal risk acceptance.
- Automation may execute and evaluate deterministic tests, coverage, digests, and freshness; it cannot approve residual risk, waiver, conformity, or G6B outcome.

---

# 12. G6B Validation Rules

~~~text
G6B-VAL-001  All thirty G6B checks exist exactly once.
G6B-VAL-002  VRL-028 binds the exact G6A candidate and verification evidence.
G6B-VAL-003  Candidate, environment, data, identity, and evidence scope are explicit.
G6B-VAL-004  Critical failed or untested obligations prevent a positive outcome.
G6B-VAL-005  Waivers and residual risks have valid authority and visible G7 effect.
G6B-VAL-006  Independent challenge is preserved at the required profile and risk.
G6B-VAL-007  Evidence quality and coverage cannot be replaced by test count.
G6B-VAL-008  G6B cannot authorize production exposure.
~~~
