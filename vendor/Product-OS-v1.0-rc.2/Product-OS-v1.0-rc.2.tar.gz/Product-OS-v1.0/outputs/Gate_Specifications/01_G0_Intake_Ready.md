# Gate Specification — G0 Intake Ready

~~~yaml
gate_specification_id: GATE-SPEC-G0
version: 0.1.0
status: WORKING_DRAFT
gate_id: G0
gate_name: Intake Ready
owning_phase: Phase 00 - Initialization and Intake
primary_object: ICB - Initial Context Baseline
check_count: 15
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifacts:
  - INIT-005
handoff_artifact: INIT-007
semantic_source: ../Phase_00_Initialization_and_Intake_v1.1.md
~~~

---

# 1. Decision and Boundary

G0 decides whether enough truthful, source-identified context exists to begin the correct Product OS route safely.

G0 does not approve:

- the problem definition;
- business or product scope;
- requirements;
- design or architecture;
- implementation;
- a commercial engagement;
- final risk or standards applicability.

---

# 2. Scope and Activation

G0 is required for every Product OS entry, including greenfield, brownfield, recovery, migration, evolution, incident-remediation, regulatory-change, sunset, and transfer contexts.

Critical recovery signals may route immediately to containment. They do not remove the minimum G0 identity, source, authority, risk, route, and decision record.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| Project, need, outcome, and constraints | INIT-001 |
| Source identity and authority context | INIT-002 |
| Facts, assumptions, ideas, questions, contradictions, and signals | INIT-003 |
| Stakeholders and authority | INIT-004 |
| State, profile, risk, engagement, and route classification | INIT-005 |
| Existing assets where applicable | INIT-006 |
| Standards triggers and pending applicability | GOV-009 |
| Gate decision | GOV-003 typed G0 decision |
| Accepted handoff | INIT-007 |

---

# 4. Authority

Required:

- Intake or Product Analysis owner;
- person or role authorized to accept the initial route;
- risk or specialist authority when immediate escalation signals exist;
- receiving-route owner acknowledgement for PASS or PASS_WITH_CONDITIONS.

Final budget or product authority may remain a condition only when its absence does not prevent safe discovery or route selection.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G0-01 Project Identity | The project, product, organization, or live scope being assessed is distinguishable and stable enough for routing. | INIT-001 identity; INIT-002 source references; GOV-002 entry |
| G0-02 Entry Reason | The trigger for entering Product OS is explicit and typed. | INIT-001 entry reason; source evidence |
| G0-03 Product State | Primary S0–S6 state is known or narrowed enough for a safe route; material secondary context remains visible. | INIT-005 state, rationale, confidence, sources |
| G0-04 Source Baseline | Material received sources are registered with exact identity, authority, recency, and contradiction status. | INIT-002; INIT-003 lineage |
| G0-05 Authority Context | Information providers, decision owners, authority gaps, and escalation route are visible. | INIT-004; GOV-006 authority questions |
| G0-06 Problem / Need | A meaningful need, opportunity, failure, obligation, or lifecycle trigger exists without being misrepresented as an approved solution. | INIT-001; INIT-003 typed items |
| G0-07 Desired Outcome | An initial outcome is explicit or UNKNOWN with owner and downstream clarification route. | INIT-001 outcome; GOV-006 question |
| G0-08 Current State | Minimum current-state context appropriate to the product state and lifecycle mode is captured. | INIT-001; applicable INIT-006 |
| G0-09 Constraints | Critical known constraints and uncertain constraint candidates are visible and sourced. | INIT-001; INIT-003; GOV-005 |
| G0-10 Critical Risk Signals | Security, data loss, outage, financial-control, safety, identity, legal-stop, and other immediate signals were evaluated. | INIT-003 signals; INIT-005 risk; GOV-004 |
| G0-11 Critical Contradictions | No unresolved contradiction prevents identity, state, authority, risk, or route selection. | INIT-003 contradiction records; GOV-006 |
| G0-12 Blocking Questions | No open Q0 question prevents a safe route; downstream discovery questions are transferred. | GOV-006; INIT-005 blocking questions |
| G0-13 Preliminary Classification | State, P-profile candidate, domain overrides, R-class candidate, confidence, and route are explicit. | INIT-005; Classification Rules |
| G0-14 Downstream Route | Normal, alternate, containment, recovery, or operational route and receiving owner are identified. | INIT-005 route; INIT-007 candidate handoff |
| G0-15 Standards Applicability Trigger Capture | Known material triggers are recorded in GOV-009; unresolved entries are PENDING with owner and due route. | GOV-009 entries; INIT-003 triggers |

---

# 6. Gate-Specific Blocking Conditions

G0 cannot pass when:

- the assessed product or project cannot be identified;
- there is no usable statement of need, event, or entry reason;
- sources materially conflict on what is being assessed;
- product state or lifecycle route cannot be narrowed safely;
- active severe harm requires escalation but no responsible route exists;
- prohibited access or source handling prevents lawful or safe work;
- a Q0 question blocks route selection;
- standards triggers are hidden or intentionally omitted.

---

# 7. Outcomes

- PASS authorizes the exact downstream route without special conditions.
- PASS_WITH_CONDITIONS authorizes the route with non-blocking information, authority, or evidence conditions.
- HOLD pauses routing until named blockers are resolved.
- REJECT records that the Product OS route is unsuitable, prohibited, cancelled, or impossible for the exact scope. It is not a judgment on idea quality.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G0
initial_context_baseline:
product_state:
lifecycle_mode:
profile_candidate:
domain_overrides: []
risk_candidate:
immediate_escalation:
entry_reason:
downstream_route:
alternate_routes: []
standards_trigger_entries: []
blocking_q0_questions: []
outcome:
conditions: []
decision_makers: []
receiving_owner:
evidence_index:
~~~

---

# 9. Handoff

PASS or PASS_WITH_CONDITIONS creates INIT-007 with:

- exact ICB identity;
- sources and information-state distinctions;
- preliminary classification;
- risk and escalation state;
- open downstream questions;
- standards triggers;
- conditions;
- prohibited assumptions;
- receiving-owner acknowledgement.

HOLD and REJECT create disposition records and do not masquerade as an accepted normal handoff.

---

# 10. Validity and Reopen

Reopen G0 for:

- corrected identity;
- newly discovered operating product or implementation;
- product-state or lifecycle-mode change;
- new immediate risk;
- material source contradiction;
- authority change affecting route;
- prohibited or newly allowed access;
- materially different requested outcome or engagement;
- new standards trigger that changes the safe route.

---

# 11. Profile and Automation

- P1 may place G0 inside INIT-000 while preserving all fifteen check IDs.
- P2 keeps INIT-005 and INIT-007 independently reviewable.
- P3 strengthens source authority, specialist review, evidence custody, formal routing, and attestations where required.
- Automation may detect missing IDs, contradictions, low-confidence critical dimensions, and unresolved Q0 questions; it cannot approve state, profile, risk, applicability, or route.

---

# 12. G0 Validation Rules

~~~text
G0-VAL-001  All fifteen G0 checks exist exactly once.
G0-VAL-002  G0 does not claim problem understanding, scope approval, or requirements completion.
G0-VAL-003  Final standards applicability is not required unless its absence blocks safe routing.
G0-VAL-004  Immediate escalation takes precedence over routine intake.
G0-VAL-005  Discovery questions are not incorrectly treated as G0 blockers.
G0-VAL-006  PASS or PASS_WITH_CONDITIONS resolves to INIT-007 and receiving-owner acknowledgement.
G0-VAL-007  REJECT is scoped to route suitability and preserves rationale.
G0-VAL-008  No AI output self-approves G0.
~~~
