# Gate Specification — G1 Problem Understood

~~~yaml
gate_specification_id: GATE-SPEC-G1
version: 0.1.0
status: WORKING_DRAFT
gate_id: G1
gate_name: Problem Understood
owning_phase: Phase 01 - Discovery and Problem Definition
primary_object: DSBL - Discovery Baseline
check_count: 16
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: DISC-009
baseline_anchor: DISC-002
semantic_source: ../Phase_01_Discovery_and_Problem_Definition_v1.1.md
~~~

---

# 1. Decision and Boundary

G1 decides whether the current condition, affected people, primary problems, causes, impacts, outcomes, constraints, and uncertainty are understood well enough to proceed without building a solution to the wrong problem.

G1 approves problem understanding. It does not approve a preferred product solution, business operating model, feature list, requirement set, design, or architecture.

---

# 2. Scope and Activation

G1 applies when Discovery is active or when brownfield, recovery, evolution, or incident evidence requires the problem baseline to reopen.

A no-product outcome is valid when evidence supports process, policy, training, organization, or vendor action instead.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| Discovery plan and scope | DISC-001 |
| Canonical findings | DISC-002 |
| Stakeholder coverage | DISC-003 |
| Current state | DISC-004 |
| Problem and impact | DISC-005 |
| Cause and hypothesis | DISC-006 |
| Outcomes and success direction | DISC-007 |
| Scope hypothesis | DISC-008 |
| Validation evidence and check results | DISC-009 |
| Gate decision | GOV-003 typed G1 decision |
| Standards evidence | GOV-009 |

---

# 4. Authority

Required:

- Product Analyst or Discovery owner;
- Business authority able to accept the problem baseline or non-product disposition;
- specialist reviewers for material research, operational, safety, legal, security, privacy, accessibility, or data claims;
- receiving Business Architecture or alternate-route owner.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G1-01 Current State Understood | The relevant current condition is evidence-backed at the selected profile depth. | DISC-002; DISC-004 |
| G1-02 Primary Problems Defined | Primary problems are explicit, scoped, evidence-backed, and separated from proposed solutions. | DISC-005; sources |
| G1-03 Symptoms Distinguished | Symptoms, causes, and hypotheses are not conflated. | DISC-005; DISC-006 |
| G1-04 Impacts Understood | Every critical or high problem has material user, business, operational, risk, or compliance impact. | DISC-005 impact records |
| G1-05 Causes Handled | Supported causes are evidenced; unresolved causes remain explicit hypotheses rather than false root causes. | DISC-006; validation evidence |
| G1-06 Stakeholder Coverage | Required user, operator, business, authority, minority, and affected-party perspectives are sufficiently represented. | DISC-003; DISC-009 |
| G1-07 Desired Outcomes Defined | Desired change is expressed as an outcome rather than only a requested build. | DISC-007 |
| G1-08 Success Direction Defined | Major outcomes have measurable direction, signal, or governed measurement gap. | DISC-007 |
| G1-09 Constraints Validated | Critical constraints are confirmed, contradicted, or explicitly uncertain. | DISC-002; GOV-005 |
| G1-10 Major Dependencies Known | Dependencies affecting the next decision are identified with owners and uncertainty. | DISC-002; DISC-008 |
| G1-11 Critical Conflicts Resolved | No conflict prevents a coherent problem or route baseline. | DISC-009; GOV-006 |
| G1-12 Discovery Blocking Questions | No blocking discovery question remains for the exact scope. | GOV-006; DISC-009 |
| G1-13 Scope Hypothesis Exists | A preliminary boundary identifies what the next phase will and will not address. | DISC-008 |
| G1-14 Risk Reassessed | Risk and domain profiles reflect Discovery evidence rather than intake assumptions alone. | GOV-004; classification update |
| G1-15 Downstream Route Known | Business Architecture, Product Definition, gap analysis, recovery, delta, or no-product route is explicit. | DISC-002 disposition; GOV-003 |
| G1-16 Standards Applicability Evidence Coverage | Material triggers were investigated; pending entries identify evidence need, owner, and next route. | GOV-009; DISC-009 |

---

# 6. Gate-Specific Blocking Conditions

G1 cannot pass when:

- no coherent primary problem or opportunity exists;
- critical stakeholders provide materially contradictory current-state evidence;
- no responsible business or product authority can be established;
- a proposed solution is presented as the problem baseline;
- critical causes are falsely asserted as fact;
- blocking discovery conflicts or questions remain;
- standards uncertainty prevents safe problem or route definition.

---

# 7. Outcomes

- PASS accepts DSBL for the next route.
- PASS_WITH_CONDITIONS accepts DSBL with non-blocking uncertainty such as a later measurement baseline.
- HOLD pauses for missing evidence, authority, conflict resolution, or essential stakeholder coverage.
- REJECT records cancellation, no meaningful product opportunity, outside-scope disposition, or an approved non-product intervention.

NO_PRODUCT_CHANGE_RECOMMENDED is a routed disposition represented through rationale and next actions; it is not a fifth G1 gate outcome.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G1
discovery_baseline:
current_state_scope:
primary_problem_ids: []
supported_cause_ids: []
unresolved_hypothesis_ids: []
outcome_ids: []
scope_hypothesis:
risk_reassessment:
standards_pending_entries: []
downstream_route:
non_product_disposition:
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

Positive outcomes hand off validated problem, current state, outcomes, constraints, dependencies, risk, standards evidence, and explicit uncertainty.

Downstream teams may not treat:

- scope hypothesis as approved product scope;
- requested ideas as requirements;
- causes as verified when they remain hypotheses;
- discovery success direction as a final KPI target.

---

# 10. Validity and Reopen

Reopen for new contradictory research, changed affected population, material current-state change, newly observed cause, changed outcome, incident evidence, new standard trigger, invalidated source, or downstream discovery that the accepted problem is materially wrong.

---

# 11. Profile and Automation

- P1 compresses evidence presentation but preserves all sixteen checks and critical perspectives.
- P2 separates findings, models, validation, and decision evidence.
- P3 strengthens research design, sampling, independent challenge, bias analysis, source custody, and specialist authority.
- Automation may detect solution-biased problem statements, orphan outcomes, missing impacts, and unresolved conflicts; it cannot approve a problem interpretation.

---

# 12. G1 Validation Rules

~~~text
G1-VAL-001  All sixteen G1 checks exist exactly once.
G1-VAL-002  Problems remain separate from solutions.
G1-VAL-003  Unsupported root causes remain hypotheses.
G1-VAL-004  A no-product route is recorded without misclassifying Discovery as failure.
G1-VAL-005  Scope hypothesis is not promoted to product approval.
G1-VAL-006  Risk and standards evidence are updated from Discovery findings.
G1-VAL-007  Blocking discovery questions equal zero for a positive outcome.
G1-VAL-008  DISC-009 supplies evidence and does not self-approve G1.
~~~
