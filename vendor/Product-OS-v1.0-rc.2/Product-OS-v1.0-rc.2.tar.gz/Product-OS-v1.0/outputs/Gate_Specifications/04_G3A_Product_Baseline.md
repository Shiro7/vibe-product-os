# Gate Specification — G3A Product Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G3A
version: 0.1.0
status: WORKING_DRAFT
gate_id: G3A
gate_name: Product Baseline
owning_phase: Phase 03 - Product Definition
primary_object: PBL - Product Baseline
check_count: 18
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: PROD-014
baseline_anchors:
  - PROD-001
  - PROD-002
semantic_source: ../Phase_03_Product_Definition_v1.1.md
~~~

---

# 1. Decision and Boundary

G3A decides whether product purpose, responsibility, audience, boundary, capabilities, domains, modules, states, policies, integrations, dependencies, release scope, roadmap direction, and standards implications are coherent enough for Requirements Engineering.

Feature candidates remain candidates. G3A does not approve atomic requirements, screens, technical mechanisms, or implementation.

---

# 2. Scope and Activation

G3A applies to each product baseline, market, platform, release boundary, user group, language, product state, ecosystem boundary, and supported capability scope.

Materially separate products require separate PBL identities.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| Vision and mission | PROD-001 |
| Scope and boundary | PROD-002 |
| Objectives | PROD-003 |
| Users and roles | PROD-004 |
| Capabilities | PROD-005 |
| Domains and modules | PROD-006 |
| Feature candidates | PROD-007 |
| States and lifecycle | PROD-008 when applicable |
| Policies and constraints | PROD-009 |
| Integrations and dependencies | PROD-010 when applicable |
| MVP and release scope | PROD-011 |
| Roadmap | PROD-012 when applicable |
| Product KPIs | PROD-013 |
| Validation | PROD-014 |
| Gate decision | GOV-003 typed G3A decision |
| Applicability | GOV-009 |

---

# 4. Authority

Required:

- Product Owner or Product authority;
- Business authority for scope and value alignment;
- product analysis or management owner;
- standards, legal, security, privacy, accessibility, data, platform, or commercial reviewers when triggered;
- Requirements owner acknowledgement.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G3A-01 Vision | Product purpose, value, and intended change are explicit and align with BBL. | PROD-001; BUS-001 |
| G3A-02 Product Boundary | Product-owned, external, manual, platform, partner, and excluded responsibilities are explicit. | PROD-002 |
| G3A-03 Product Scope | In-scope, out-of-scope, future, release, market, platform, and channel boundaries are coherent. | PROD-002; PROD-011 |
| G3A-04 User Model | Primary users, roles, acting capacities, administrators, external actors, and affected non-users are known. | PROD-004 |
| G3A-05 Capability Coverage | Critical business capabilities have product, manual, external, deferred, or rejected disposition. | PROD-005; BUS-002 |
| G3A-06 Product Domains | Major responsibility areas have coherent meaning and ownership. | PROD-006 |
| G3A-07 Module Coherence | Modules reflect product responsibilities and are not arbitrary UI or team buckets. | PROD-006 |
| G3A-08 Feature Candidate Coverage | Candidates explain possible realization without being presented as approved requirements. | PROD-007 |
| G3A-09 Product States | Material object and workflow states, transitions, terminal states, and recovery are modeled. | PROD-008 |
| G3A-10 Product Policies | Critical product invariants, permissions, limits, defaults, and constraints are known. | PROD-009 |
| G3A-11 Integrations | Major external interactions, ownership, trust, value, and dependency are identified. | PROD-010 |
| G3A-12 Dependencies | Blocking product, platform, business, vendor, policy, data, and delivery dependencies are known. | PROD-010; GOV-006 |
| G3A-13 MVP / Release Boundary | The initial value slice is coherent, complete enough, and explicit where applicable. | PROD-011 |
| G3A-14 Roadmap Direction | Near-term sequencing, dependencies, options, and uncertainty are understood without false commitment. | PROD-012 |
| G3A-15 Risk Review | Product risk, criticality, domain profiles, and standards triggers reflect the proposed boundary. | GOV-004; INIT-005 update |
| G3A-16 Open Decisions | No blocking product responsibility, boundary, policy, release, or integration decision remains. | GOV-003; GOV-006; PROD-014 |
| G3A-17 Requirements Readiness | Requirements can be derived without inventing scope, responsibility, policy, state, or integration intent. | PROD-014 downstream assessment |
| G3A-18 Standards Applicability Review | Applicable obligations have product capability, constraint, policy, platform, journey, document, third-party, or approved no-product-impact disposition. | GOV-009; product object IDs |

---

# 6. Gate-Specific Blocking Conditions

G3A cannot pass when:

- product responsibility or boundary is materially contradictory;
- included capability has no owner or disposition;
- MVP omits necessary end-to-end value or mandatory control;
- payment, identity, data, platform, or other major responsibility remains unresolved;
- a blocking regulatory or standards decision affects current scope;
- Phase 04 would need to invent product behavior;
- product concepts were split or transferred without new baseline identities.

---

# 7. Outcomes

- PASS accepts PBL for requirement derivation.
- PASS_WITH_CONDITIONS accepts only non-blocking future-release or detail conditions.
- HOLD pauses for unresolved responsibility, boundary, policy, release, integration, or standards decisions.
- REJECT records abandonment, non-product disposition, product split, or invalidated upstream business baseline.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G3A
product_baseline:
business_baseline:
product_scope:
product_boundary:
user_model:
capability_ids: []
module_ids: []
state_model_ids: []
policy_ids: []
integration_ids: []
mvp_or_release_scope:
standards_product_implications: []
phase_04_derivation_types: []
blocking_product_decisions: []
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

Positive outcomes provide exact PBL, business lineage, product objects, standards implications, release scope, risks, conditions, and requirement-derivation obligations.

Phase 04 may derive atomic obligations. It may not invent product capability, change scope, convert candidates automatically, or hide external and manual responsibility.

---

# 10. Validity and Reopen

Reopen for material purpose, audience, capability, boundary, platform, market, module, state, policy, integration, release, roadmap, standard, business-baseline, or product ownership change.

---

# 11. Profile and Automation

- P1 may compose product objects while retaining all eighteen check IDs and canonical object identities.
- P2 separates scope, capability, states, policies, integrations, release, and validation.
- P3 strengthens product portfolio, market, platform, standards, authority, evidence, and change governance.
- Automation may detect capability orphans, scope contradictions, feature candidates presented as requirements, and standards gaps; it cannot approve scope or priority.

---

# 12. G3A Validation Rules

~~~text
G3A-VAL-001  All eighteen G3A checks exist exactly once.
G3A-VAL-002  Feature candidates remain distinct from requirements.
G3A-VAL-003  Product boundary distinguishes product, manual, external, and platform responsibility.
G3A-VAL-004  MVP preserves necessary value and mandatory obligations.
G3A-VAL-005  Blocking product decisions equal zero for a positive outcome.
G3A-VAL-006  Applicable standards have product-level disposition and Phase 04 derivation route.
G3A-VAL-007  PROD-014 validates and does not self-approve G3A.
G3A-VAL-008  Positive handoff prevents requirement authors from inventing product scope.
~~~
