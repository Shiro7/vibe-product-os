# Gate Specification — G4B Design Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G4B
version: 0.1.0
status: WORKING_DRAFT
gate_id: G4B
gate_name: Design Baseline
owning_phase: Phase 06 - Product Design
primary_object: DBL - Design Baseline
check_count: 25
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: DES-022
handoff_artifact: DES-023
semantic_source: ../Phase_06_Product_Design.md
~~~

---

# 1. Decision and Boundary

G4B decides whether approved experience is represented by a coherent, complete, accessible, localized, traceable, validated, source-controlled, and implementation-ready design baseline.

G4B cannot silently approve product, requirement, or experience change. Design sources are canonical representations only when their identity, revision, ownership, adoption, and supersession are governed.

---

# 2. Scope and Activation

G4B binds exact RBL and EBL versions, release, design profile, markets, platforms, channels, viewports, input modes, themes, density modes, languages, directions, accessibility contexts, generated outputs, third parties, design sources, and implementation targets.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| Design direction | DES-001 |
| Foundations and tokens | DES-002 |
| Layout and density | DES-003 |
| Typography | DES-004 |
| Color, theme, and contrast | DES-005 |
| Iconography and assets | DES-006 |
| Components | DES-007 |
| Product patterns | DES-008 |
| Screens and views | DES-009 |
| States and feedback | DES-010 |
| Forms and inputs | DES-011 |
| Data-dense and visualization | DES-012 when applicable |
| Content and messages | DES-013 |
| Responsive and cross-platform | DES-014 when applicable |
| Accessibility | DES-015 |
| Localization and RTL | DES-016 when applicable |
| Motion | DES-017 when applicable |
| Generated output and notifications | DES-018 when applicable |
| Prototype | DES-019 when applicable |
| Design source and library identity | DES-020 |
| Coverage view | DES-021 |
| Validation | DES-022 |
| Handoff | DES-023 |
| Gate decision | GOV-003 typed G4B decision |

---

# 4. Authority

Required roles are selected by profile and risk from:

- Product Design Lead;
- Product Owner;
- Experience Architect or UX Lead;
- Design System Owner;
- Accessibility Owner;
- Content or Localization Owner;
- Engineering Lead;
- Solution Architect;
- Security or Privacy Owner;
- QA or Verification Lead;
- business or regulatory authority when required.

Engineering acknowledgement confirms implementability, not product or design approval.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G4B-01 Scope and Upstream Baselines | G3B and G4A decisions, design scope, profile, overrides, and upstream conditions are valid with no invented scope. | DBL scope; RBL/EBL decisions |
| G4B-02 Design Direction | Direction is coherent, product-specific, usable, and proven in representative compositions. | DES-001; representative DES-009 |
| G4B-03 Foundations and Tokens | Semantic foundations, token hierarchy, themes, modes, ownership, and code-mapping strategy cover scope. | DES-002; DES-020 |
| G4B-04 Layout and Density | Grid, spacing, composition, layering, density, overflow, and templates work across required surfaces. | DES-003; screen evidence |
| G4B-05 Typography | Readability, hierarchy, scripts, fallbacks, scaling, data presentation, Arabic, and complex-script quality are evidenced. | DES-004; DES-016 |
| G4B-06 Color, Theme, and Contrast | Semantic color, themes, interactive states, non-text contrast, and visualization evidence meet obligations. | DES-005; contrast evidence |
| G4B-07 Iconography and Assets | Meaning, consistency, RTL, accessibility responsibility, licensing, format, optimization, and ownership are governed. | DES-006 |
| G4B-08 Component Completeness | Required components define properties, variants, states, behavior, semantics, responsive, RTL, and content constraints. | DES-007 |
| G4B-09 Component Adoption and Governance | Canonical sources, actual product adoption, overrides, code mappings, duplicates, ownership, and deprecation are controlled. | DES-007; DES-020; adoption evidence |
| G4B-10 Product Patterns | Recurring tasks use documented patterns preserving approved experience and states. | DES-008 |
| G4B-11 Screen and View Coverage | Every design subject is designed, pattern-covered, or explicitly dispositioned. | DES-009; DES-021 |
| G4B-12 State, Feedback, and Recovery Coverage | Required loading, empty, denied, unavailable, offline, conflict, processing, unknown-outcome, interruption, expiry, and recovery states exist. | DES-010 |
| G4B-13 Forms and Input | Structure, labels, validation, errors, help, sensitive fields, submit, keyboard, and recovery behavior are complete. | DES-011 |
| G4B-14 Data-Dense and Visualization Design | Tables, search, filters, bulk actions, pagination, dashboards, charts, alternatives, and states are complete where applicable. | DES-012 |
| G4B-15 Content and Messages | Critical labels, actions, errors, confirmations, variables, ownership, localization, and security constraints are governed. | DES-013 |
| G4B-16 Responsive and Cross-Platform Design | Supported modes, viewports, platforms, orientations, input methods, and intentional divergence are specified. | DES-014 |
| G4B-17 Localization and RTL | Locale formats, expansion, shaping, mixed direction, ordering, icon behavior, and localized evidence are complete. | DES-016 |
| G4B-18 Accessibility | Tokens, components, screens, states, semantics, content, motion, prototypes, and outputs realize applicable obligations. | DES-015; validation evidence |
| G4B-19 Security and Privacy | Masking, consent, permissions, consequential actions, session, reauthentication, safe error, and sensitive outputs are designed. | design objects; REQ-007 |
| G4B-20 Motion and Transitions | Motion has purpose, controlled timing, interruption behavior, reduced-motion alternative, and implementation specification. | DES-017 |
| G4B-21 Generated Outputs, Notifications, and Third Parties | Documents, print, email, notifications, embedded services, and fallback paths are designed where applicable. | DES-018 |
| G4B-22 Prototype and Validation | Representative critical journeys and risks were validated; limitations and findings are governed. | DES-019; DES-022 |
| G4B-23 Traceability and GOV-009 | Bidirectional lineage, standards-control mapping, evidence, exceptions, and downstream obligations are complete. | DES-021; GOV-008; GOV-009 |
| G4B-24 Source, Version, and Design-to-Code Readiness | Canonical files, libraries, revisions, assets, token and component mappings, annotations, and verification expectations resolve. | DES-020; DES-023 |
| G4B-25 Open Items and Engineering Readiness | No hidden blocker remains; risks, questions, upstream changes, Phase 07/08 obligations, and implementability are governed. | DES-022; DES-023 acknowledgement |

---

# 6. Gate-Specific Blocking Conditions

G4B cannot pass with a material:

- invalid RBL or EBL;
- uncontrolled product, requirement, or experience change;
- missing critical screen, component, or state;
- unresolved accessibility, security, or privacy blocker;
- unknown canonical source;
- prototype-only behavior without specification;
- missing responsive, RTL, content, or generated-output realization;
- missing design-to-code handoff;
- unowned high-severity finding;
- missing traceability or evidence.

---

# 7. Outcomes

- PASS accepts DBL for downstream use.
- PASS_WITH_CONDITIONS accepts a non-blocking, scoped item with explicit implementation restriction.
- HOLD pauses until source, design, validation, upstream, authority, or handoff evidence exists.
- REJECT requires design rework or upstream rebaseline.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G4B
design_baseline:
requirements_baseline:
experience_baseline:
design_source_revisions: []
library_revisions: []
token_and_component_scope:
screen_and_state_coverage:
accessibility_evidence: []
localization_and_rtl_evidence: []
prototype_and_validation_evidence: []
design_to_code_handoff:
unresolved_findings: []
outcome:
conditions: []
approvals:
  product_design:
  product:
  experience:
  engineering_acknowledgement:
  specialist_approvals: []
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

DES-023 carries design source versions, tokens, components, screens, states, content, assets, responsive, RTL, accessibility, motion, output, validation, mapping, restrictions, and verification expectations.

Architecture and Engineering may not redesign the experience, substitute unapproved components, or present a prototype as complete specification.

---

# 10. Validity and Reopen

Reopen for upstream scope change, design-source or library supersession, component contract change, design-system adoption failure, new critical finding, accessibility or localization failure, content or brand change, platform change, changed implementation target, or material design-to-code deviation.

---

# 11. Profile and Automation

- P1 may combine design artifacts but preserves twenty-five checks, canonical source identity, and design-to-code mapping.
- P2 independently reviews foundations, components, screens, validation, and handoff.
- P3 strengthens source governance, adoption evidence, independent accessibility review, multi-platform validation, content and localization authority, and evidence custody.
- Automation may validate tokens, component variants, contrast, link identity, coverage, and version mappings; it cannot approve design quality, accessibility conformance, or user risk.

---

# 12. G4B Validation Rules

~~~text
G4B-VAL-001  All twenty-five G4B checks exist exactly once.
G4B-VAL-002  Canonical design source and revision resolve.
G4B-VAL-003  Prototype presence cannot substitute for component, screen, state, or handoff completeness.
G4B-VAL-004  Actual component adoption is distinguished from library existence.
G4B-VAL-005  Accessibility, localization, RTL, responsive, and generated-output scope have evidence.
G4B-VAL-006  Blocking design findings equal zero for a positive outcome.
G4B-VAL-007  DES-022 validates and does not self-approve G4B.
G4B-VAL-008  DES-023 prevents downstream invention or silent design substitution.
~~~
