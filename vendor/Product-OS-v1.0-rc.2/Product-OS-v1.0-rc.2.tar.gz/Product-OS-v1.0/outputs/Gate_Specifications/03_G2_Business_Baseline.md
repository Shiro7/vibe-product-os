# Gate Specification — G2 Business Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G2
version: 0.1.0
status: WORKING_DRAFT
gate_id: G2
gate_name: Business Baseline
owning_phase: Phase 02 - Business Architecture
primary_object: BBL - Business Baseline
check_count: 18
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: BUS-012
baseline_anchor: BUS-001
semantic_source: ../Phase_02_Business_Architecture_v1.1.md
~~~

---

# 1. Decision and Boundary

G2 decides whether business objectives, capabilities, processes, roles, decisions, rules, controls, information, ownership, exceptions, measures, and applicability are defined sufficiently for product and requirement work.

G2 does not define system features, screens, technical mechanisms, data schemas, or architecture.

---

# 2. Scope and Activation

G2 applies to the business domains, operating models, legal entities, markets, processes, policies, and change scope requiring a Business Baseline.

Different business scopes are partitioned when owners, rules, controls, or applicability differ.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| Business source of truth | BUS-001 |
| Capabilities | BUS-002 |
| Value streams | BUS-003 when applicable |
| Target operating model | BUS-004 when applicable |
| Processes | BUS-005 |
| Rules | BUS-006 |
| Decisions | BUS-007 when applicable |
| Roles and responsibilities | BUS-008 |
| Controls | BUS-009 when applicable |
| Information | BUS-010 |
| KPIs and outcomes | BUS-011 |
| Validation | BUS-012 |
| Gate decision | GOV-003 typed G2 decision |
| Standards applicability | GOV-009 |

---

# 4. Authority

Required:

- Business authority for the exact operating scope;
- Business Architecture or Business Analysis owner;
- policy, control, finance, legal, regulatory, data, or operational authorities when applicable;
- Product owner acknowledgement of downstream implications.

An authority gap in a material rule, control, or business decision blocks acceptance.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G2-01 Business Objectives | Major objectives are explicit, owned, and trace to Discovery outcomes. | BUS-001; DISC-007 |
| G2-02 Business Scope | Included, excluded, current, target, and transitional business boundaries are explicit. | BUS-001; applicable BUS-004 |
| G2-03 Capability Coverage | Material objectives have capability disposition and no unexplained capability orphan. | BUS-002; coverage evidence |
| G2-04 Ownership | Major capabilities and processes have accountable business owners. | BUS-002; BUS-005; BUS-008 |
| G2-05 Roles & Responsibilities | Critical execution, decision, approval, control, and escalation responsibilities are unambiguous. | BUS-008 |
| G2-06 Process Coverage | Major normal, alternative, exception, and handoff flows are understood at business level. | BUS-005; applicable BUS-003 |
| G2-07 Business Decisions | Material choices have decision IDs, authority, rationale, status, and reopen conditions. | BUS-007; GOV-003 |
| G2-08 Business Rules | Critical business logic is atomic enough for downstream derivation and has canonical ownership. | BUS-006 |
| G2-09 Control Coverage | Critical and high-risk flows have preventive, detective, corrective, or explicit control-gap treatment. | BUS-009; GOV-004 |
| G2-10 Exception Coverage | Material exception, override, escalation, and recovery business behavior is visible. | BUS-005; BUS-006; BUS-009 |
| G2-11 Business Information | Key concepts, semantics, ownership, sensitivity, and information obligations are defined. | BUS-010 |
| G2-12 Dependencies | Business, organizational, policy, vendor, legal, data, and timing dependencies are governed. | BUS-001; BUS-005 |
| G2-13 KPI Direction | Objectives have success measures or explicit measurement gaps and owners. | BUS-011 |
| G2-14 Conflicts | No blocking conflict exists across rules, decisions, ownership, process, controls, or standards. | BUS-012; GOV-006 |
| G2-15 Open Questions | Blocking Business Architecture questions equal zero. | GOV-006; BUS-012 |
| G2-16 Risk Review | Risk, controls, residual exposure, and domain profiles reflect the Business Baseline. | GOV-004; BUS-009 |
| G2-17 Downstream Readiness | Product and Requirements owners can derive responsibilities without inventing business behavior. | BUS-012 downstream assessment |
| G2-18 Standards & Compliance Business Linkage | Applicable entries map to canonical BREQ, BR, CTRL, POL, INFO, or EVID objects and explicit product and requirement implications. | GOV-009; BUS-001; BUS-006; BUS-009 |

---

# 6. Gate-Specific Blocking Conditions

G2 cannot pass when:

- critical business ownership is unknown;
- a material policy or rule is contradictory;
- target process depends on an unresolved blocking decision;
- critical controls or exceptions are absent or hidden;
- business information meaning is too ambiguous for product or requirement derivation;
- a mandatory standard has no business disposition;
- Product Definition or Requirements would need to invent material business behavior.

---

# 7. Outcomes

- PASS accepts the exact BBL.
- PASS_WITH_CONDITIONS accepts a non-blocking measurement, detail, or future-scope item with restrictions.
- HOLD pauses until business authority, policy, rule, control, ownership, or evidence is resolved.
- REJECT records cancellation, absence of a viable operating model, prohibited business change, or upstream rebaseline need.

A PENDING GOV-009 entry may coexist with PASS_WITH_CONDITIONS only when it cannot change current Product Definition or Requirements meaning materially.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G2
business_baseline:
business_scope:
objective_ids: []
capability_ids: []
process_ids: []
rule_ids: []
control_ids: []
information_ids: []
business_decision_ids: []
standards_business_object_ids: []
product_implications: []
requirements_derivation_obligations: []
blocking_authority_gaps: []
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

Positive outcomes provide canonical business objectives, boundaries, capabilities, processes, rules, controls, exceptions, roles, information, measures, risks, standards lineage, and conditions.

Downstream phases may not:

- rewrite business rules as competing truth;
- convert business capabilities directly into screens;
- select architecture mechanisms at G2;
- hide manual or external responsibility;
- defer applicable standards silently.

---

# 10. Validity and Reopen

Reopen for material objective, operating model, policy, rule, control, ownership, legal entity, market, process, vendor, information, standard, or risk change.

---

# 11. Profile and Automation

- P1 may combine business artifacts physically while preserving typed IDs and all eighteen checks.
- P2 separates independently owned rules, processes, controls, information, and validation.
- P3 strengthens authority, control evidence, segregation, regulatory lineage, auditability, and transition modeling.
- Automation may detect orphan objectives, conflicting rules, missing owners, and standards linkage gaps; it cannot approve business policy or residual risk.

---

# 12. G2 Validation Rules

~~~text
G2-VAL-001  All eighteen G2 checks exist exactly once.
G2-VAL-002  Business meaning remains free of invented product or technical mechanism.
G2-VAL-003  Every material rule and control has canonical ownership.
G2-VAL-004  Blocking authority, policy, rule, and control gaps prevent a positive outcome.
G2-VAL-005  Standards obligations map to business objects before downstream derivation.
G2-VAL-006  PENDING applicability is conditional only when current downstream meaning is safe.
G2-VAL-007  BUS-012 validates and does not self-approve G2.
G2-VAL-008  Positive handoff prevents downstream invention of material business behavior.
~~~
