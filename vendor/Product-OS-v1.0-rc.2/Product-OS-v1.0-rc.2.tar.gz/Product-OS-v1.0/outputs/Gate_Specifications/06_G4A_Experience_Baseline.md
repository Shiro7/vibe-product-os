# Gate Specification — G4A Experience Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G4A
version: 0.1.0
status: WORKING_DRAFT
gate_id: G4A
gate_name: Experience Baseline
owning_phase: Phase 05 - Experience Architecture
primary_object: EBL - Experience Baseline
check_count: 22
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: EXP-019
baseline_anchor: EXP-001
handoff_artifact: EXP-020
semantic_source: ../Phase_05_Experience_Architecture.md
~~~

---

# 1. Decision and Boundary

G4A decides whether actors, goals, journeys, flows, information architecture, navigation, states, interaction, content meaning, failure, recovery, accessibility, localization, privacy, and cross-platform experience are coherent enough for Product Design.

G4A approves experience logic. It does not approve final visual treatment, component styling, detailed tokens, code, or architecture mechanisms.

---

# 2. Scope and Activation

G4A binds exact product and requirement baselines, release, platforms, channels, markets, languages and directions, accessibility contexts, user capacities, third parties, documents, and critical journeys.

Experience scopes with different actors, channels, or obligations are partitioned when one outcome would hide material differences.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| Integrated experience baseline | EXP-001 |
| Principles and constraints | EXP-002 |
| Actors, goals, and contexts | EXP-003 |
| Scenarios | EXP-004 |
| Journeys | EXP-005 |
| Flows | EXP-006 |
| Information architecture | EXP-007 |
| Navigation and context | EXP-008 |
| Views, screens, routes, and entries | EXP-009 |
| UX states | EXP-010 |
| Error, safety, interruption, and recovery | EXP-011 |
| Interaction behavior | EXP-012 |
| Content meaning | EXP-013 |
| Responsive and cross-platform | EXP-014 when applicable |
| Accessibility | EXP-015 |
| Localization and RTL | EXP-016 when applicable |
| Structural prototype | EXP-017 when applicable |
| Coverage view | EXP-018 |
| Validation | EXP-019 |
| Handoff | EXP-020 |
| Gate decision | GOV-003 typed G4A decision |

---

# 4. Authority

Required:

- Experience Architect or UX Lead;
- Product Owner;
- Requirements Lead;
- Accessibility reviewer for applicable scope;
- security, privacy, localization, content, research, business, or regulatory authorities when triggered;
- Product Design receiving-owner acknowledgement.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G4A-01 Scope and Baselines | Experience scope and PBL/RBL versions match release, platforms, channels, markets, languages, and open conditions. | EXP-001; G3A/G3B decisions |
| G4A-02 Principles, Actors, Goals, Contexts | Principles and material actors, goals, contexts, and acting capacities are explicit. | EXP-002; EXP-003 |
| G4A-03 Scenario Coverage | Primary, alternative, sensitive, accessibility, interruption, recovery, and cross-channel scenarios exist where applicable. | EXP-004 |
| G4A-04 Journey Completeness | Critical goals have end-to-end stages, handoffs, outcomes, interruptions, and recovery. | EXP-005 |
| G4A-05 Flow Completeness | Critical flows include decisions, branches, exceptions, failures, loops, transitions, and exits. | EXP-006; EXP-010 |
| G4A-06 Information Architecture | Concepts, taxonomy, hierarchy, labels, destinations, and findability align with domain language and mental models. | EXP-007 |
| G4A-07 Navigation and Context | Workspace, location, switching, persistence, deep-link, entry, and return behavior preserve required context. | EXP-008 |
| G4A-08 View / Screen / Route Inventory | Required destinations and surfaces are identified without orphan views or state inflation. | EXP-009; EXP-018 |
| G4A-09 UX State Coverage | Applicable loading, empty, partial, error, denied, conflict, offline, processing, unknown-outcome, success, and interruption states exist. | EXP-010 |
| G4A-10 Error, Safety, and Recovery | Critical failure and consequential-action behavior protects integrity, preserves work appropriately, and provides valid recovery. | EXP-011 |
| G4A-11 Interaction Behavior | Forms, tables, search, filters, bulk actions, notifications, and background work have behavior contracts. | EXP-012 |
| G4A-12 Content and Messages | Critical labels, instructions, statuses, errors, confirmations, empty states, and recovery messages have meaning and owner. | EXP-013 |
| G4A-13 Responsive and Cross-Platform | Content priority, input modes, transformations, platform variants, and continuity are explicit. | EXP-014 |
| G4A-14 Localization and RTL | Direction, mixed content, locale formats, search, sort, expansion, documents, and notifications are covered. | EXP-016 |
| G4A-15 Accessibility Experience | ACC requirements have keyboard, focus, semantics, form, error, status, reflow, motion, input, document, and third-party dispositions. | EXP-015; REQ-008 |
| G4A-16 Security and Privacy Experience | Authentication, authorization visibility, session, reauthentication, sensitive content, consent, sharing, safe error, and recovery are covered. | EXP-011; EXP-012; REQ-007 |
| G4A-17 Requirements Traceability | Every user-affecting requirement has experience disposition and every experience object has upstream purpose. | EXP-018; GOV-008 |
| G4A-18 Validation | Critical journeys, IA, state, recovery, accessibility, and high-risk interactions have fit evidence. | EXP-017; EXP-019 |
| G4A-19 Standards / GOV-009 Experience Linkage | Applicable entries map to canonical experience objects and explicit Phase 06 obligations. | GOV-009; EXP object IDs |
| G4A-20 Open Questions and Decisions | Blocking experience questions, decisions, and validation findings equal zero. | GOV-006; GOV-003; EXP-019 |
| G4A-21 Product Design Readiness | Phase 06 can identify each design subject, state, variant, content, responsive, accessibility, and trace obligation without invention. | EXP-020 candidate |
| G4A-22 Change Governance | EBL version, owners, approval, impact, downstream objects, and reopen rules are explicit. | EXP-001 metadata; GOV-007 |

---

# 6. Gate-Specific Blocking Conditions

G4A cannot pass when:

- a critical goal lacks an end-to-end journey;
- authorization, tenant, payment, or unknown-outcome behavior is contradictory;
- critical flows omit failure, interruption, or recovery;
- navigation cannot preserve required context;
- critical forms omit error or focus behavior;
- accessibility is generic rather than behaviorally allocated;
- RTL, mobile, or platform behavior changes the journey but remains undefined;
- blocking GOV-009 linkage or validation findings remain;
- Product Design would need to invent material interaction logic.

---

# 7. Outcomes

- PASS accepts EBL for Product Design.
- PASS_WITH_CONDITIONS accepts only non-blocking future or partitioned experience work that does not weaken critical security, accessibility, or recovery.
- HOLD pauses for missing journey, state, interaction, content, validation, or authority evidence.
- REJECT records invalid upstream baselines, cancelled or split scope, product transfer, or evidence that the selected channel cannot meet the outcome without upstream change.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G4A
experience_baseline:
product_baseline:
requirements_baseline:
release_scope:
critical_journey_ids: []
critical_flow_ids: []
view_and_route_scope: []
state_coverage:
accessibility_scope:
localization_and_rtl_scope:
validation_findings: []
standards_experience_links: []
design_derivation_obligations: []
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

EXP-020 carries EBL identity, actors, scenarios, journeys, flows, IA, navigation, views, states, recovery, interaction, content, responsive, accessibility, localization, validation, conditions, and design obligations.

Phase 06 may realize visual design. It may not invent or silently change journey, navigation, state, interaction, content meaning, or recovery behavior.

---

# 10. Validity and Reopen

Reopen for changed actor, goal, journey, channel, platform, market, language, direction, accessibility context, requirement, product boundary, state, navigation, security or privacy behavior, validation finding, standard, or design-discovered contradiction.

---

# 11. Profile and Automation

- P1 may compose EXP objects while preserving all twenty-two checks.
- P2 separates independently reviewed experience models and validation.
- P3 strengthens research coverage, critical-journey evidence, accessibility review, multi-market and multi-platform variants, and independent assurance.
- Automation may detect orphan screens, missing states, broken trace, unsupported variants, and unresolved findings; it cannot approve experience meaning or user risk.

---

# 12. G4A Validation Rules

~~~text
G4A-VAL-001  All twenty-two G4A checks exist exactly once.
G4A-VAL-002  Experience logic remains distinct from final visual design.
G4A-VAL-003  Every critical journey includes interruption, failure, and recovery where applicable.
G4A-VAL-004  Accessibility and RTL are behaviorally allocated rather than generic labels.
G4A-VAL-005  Blocking questions, decisions, and validation findings equal zero for a positive outcome.
G4A-VAL-006  EXP-019 validates and does not self-approve G4A.
G4A-VAL-007  EXP-020 prevents Phase 06 from inventing experience behavior.
G4A-VAL-008  No applicable standard is silently deferred to Design or QA.
~~~
