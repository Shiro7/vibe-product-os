# Gate Specification — G3B Requirements Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G3B
version: 0.1.0
status: WORKING_DRAFT
gate_id: G3B
gate_name: Requirements Baseline
owning_phase: Phase 04 - Requirements Engineering
primary_object: RBL - Requirements Baseline
check_count: 19
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: REQ-013
baseline_anchor: REQ-001
handoff_artifact: REQ-014
semantic_source: ../Phase_04_Requirements_Engineering.md
~~~

---

# 1. Decision and Boundary

G3B decides whether approved obligations are represented by atomic, coherent, feasible, testable, traceable, change-controlled requirements with acceptance and verification intent.

Requirements define obligations. They do not silently define screens, detailed experience, design realization, architecture mechanisms, code, or test implementation.

---

# 2. Scope and Activation

G3B binds an exact product and release scope, PBL version, markets, platforms, channels, languages, actors, data contexts, integrations, conditional profiles, and operating conditions.

Future-release requirements are partitioned when they have different validity or readiness.

---

# 3. Canonical Inputs and Records

| Purpose | Canonical source |
|---|---|
| SRS and integrated baseline | REQ-001 |
| Requirement identity and index | REQ-002 |
| Functional requirements | REQ-003 |
| Non-functional requirements | REQ-004 |
| Data requirements | REQ-005 |
| Integration requirements | REQ-006 |
| Security and privacy | REQ-007 |
| Accessibility | REQ-008 |
| Audit and evidence | REQ-009 |
| Acceptance and verification view | REQ-010 |
| Traceability view | REQ-011 |
| Issues and conflicts | REQ-012 |
| Validation | REQ-013 |
| Handoff | REQ-014 |
| Gate decision | GOV-003 typed G3B decision |
| Trace source | GOV-008 |
| Standards applicability | GOV-009 |

---

# 4. Authority

Required:

- Requirements Lead or accountable requirements owner;
- Product Owner;
- Business authority for business-rule and control meaning;
- specialist owners for security, privacy, accessibility, data, integration, audit, reliability, performance, legal, and compliance when applicable;
- downstream Experience, Design, Architecture, Engineering, and Verification acknowledgement at the required profile.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G3B-01 Baseline Scope | SRS, product, release, platform, market, actor, data, and source versions are explicit and consistent with G3A. | REQ-001; PBL and G3A decision |
| G3B-02 Upstream Derivation Coverage | Business and product objects have requirement or explicit non-system disposition. | REQ-011; GOV-008 |
| G3B-03 Requirement Quality | Baselined statements are atomic, unambiguous, consistent, feasible, implementation-independent, and use SHALL or SHALL NOT. | REQ-001 through REQ-009; REQ-013 |
| G3B-04 Functional Coverage | Capabilities, processes, states, decisions, rules, controls, exceptions, errors, and recovery have functional disposition. | REQ-003; coverage view |
| G3B-05 Non-Functional Coverage | Applicable quality attributes have measurable scope, target, conditions, and verification intent. | REQ-004 |
| G3B-06 Data Coverage | Semantics, ownership, quality, classification, lifecycle, retention, residency, migration, integrity, and privacy are covered. | REQ-005; REQ-007 |
| G3B-07 Integration Coverage | In-scope integrations define behavior, boundary, errors, recovery, reconciliation, security, compatibility, and observable outcomes. | REQ-006 |
| G3B-08 Security and Privacy Coverage | Critical users, actions, data, journeys, integrations, abuse, rights, and controls have traceable obligations. | REQ-007; GOV-004 |
| G3B-09 Accessibility Coverage | Platforms, journeys, states, outputs, languages, directions, and third parties have atomic ACC requirements. | REQ-008; GOV-009 |
| G3B-10 Audit and Evidence Coverage | Critical decisions, approvals, administrative actions, sensitive events, and evidence obligations have AUD coverage. | REQ-009 |
| G3B-11 Acceptance and Testability | Every baselined requirement has acceptance criteria, verification method, level, and evidence expectation. | REQ-010; requirement records |
| G3B-12 Traceability | Bidirectional lineage detects upstream gaps, downstream orphans, duplicates, conflicts, and impact. | REQ-011; GOV-008 |
| G3B-13 Priority and Release Integrity | Business priority, criticality, release allocation, and mandatory scope are explicit and coherent. | requirement metadata; PROD-011 |
| G3B-14 Dependencies and Feasibility | Blocking dependency and feasibility concerns are resolved or safely conditioned. | REQ-012; feasibility evidence |
| G3B-15 Conflict and Duplicate Control | No material conflict, semantic duplicate, or contradictory source interpretation remains. | REQ-012; REQ-013 |
| G3B-16 Open Questions and Decisions | Blocking requirement questions and decisions equal zero. | GOV-006; GOV-003; REQ-012 |
| G3B-17 Standards Derivation Coverage | Every applicable GOV-009 obligation has required-type disposition, derived IDs or approved rationale, clause lineage, acceptance, and verification. | GOV-009; REQ-003 through REQ-009 |
| G3B-18 Downstream Readiness | Downstream phases can identify obligations without reinterpreting intent. | REQ-014 candidate; stakeholder acknowledgements |
| G3B-19 Change Governance | Baseline version, owner, approval, impact, trace, supersession, and reopen routes are explicit. | REQ-001 metadata; GOV-007; GOV-008 |

---

# 6. Gate-Specific Blocking Conditions

G3B cannot pass when:

- a critical product capability lacks functional behavior;
- authorization, payment unknown outcome, state recovery, or other critical behavior is contradictory or missing;
- a critical NFR is not measurable;
- mandatory accessibility, security, privacy, data, integration, or audit scope is generic or absent;
- acceptance or verification cannot establish satisfaction;
- a blocking GOV-009 derivation gap exists;
- a material conflict, duplicate, feasibility issue, or open decision remains;
- release scope omits a mandatory control for an included journey.

---

# 7. Outcomes

- PASS accepts RBL for downstream consumption.
- PASS_WITH_CONDITIONS accepts only explicit, owned, time-bound, future or non-blocking gaps that do not weaken mandatory current scope.
- HOLD pauses for missing or failed obligations, acceptance, evidence intent, feasibility, authority, or derivation.
- REJECT records withdrawn PBL, cancellation, product transfer, split, or upstream rebaseline that invalidates the requirement scope.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G3B
requirements_baseline:
product_baseline:
release_scope:
requirement_counts_by_type:
  FR:
  NFR:
  DR:
  INT:
  SEC:
  ACC:
  AUD:
upstream_disposition_coverage:
acceptance_coverage:
verification_allocation_coverage:
traceability_coverage:
blocking_conflicts: []
blocking_questions: []
standards_derivation_gaps: []
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

Counts are diagnostic and cannot replace semantic coverage.

---

# 9. Handoff and Prohibitions

REQ-014 carries exact RBL, requirement IDs, acceptance, verification intent, traceability, conditions, standards lineage, risks, conflicts, release allocation, and change rules.

Downstream phases may not:

- rewrite requirements;
- weaken SHALL or SHALL NOT through design choice;
- treat business priority as normative language;
- choose a mechanism and present it as requirement intent;
- hide unresolved scope inside implementation.

---

# 10. Validity and Reopen

Reopen for material product, business, standard, platform, market, language, data, integration, security, accessibility, audit, quality target, release, acceptance, feasibility, or authority change; invalidated evidence; downstream discovery of contradiction; or changed system responsibility.

---

# 11. Profile and Automation

- P1 may package catalogs in REQ-000 while preserving every logical ID, nineteen checks, and atomic requirements.
- P2 independently reviews material requirement families and derived views.
- P3 strengthens formal modeling, specialist approval, independent verification planning, clause lineage, evidence, and change control.
- Automation may validate syntax, missing fields, duplicates, conflicts, trace gaps, acceptance presence, and vocabulary; it cannot approve requirement meaning, priority, feasibility, or risk.

---

# 12. G3B Validation Rules

~~~text
G3B-VAL-001  All nineteen G3B checks exist exactly once.
G3B-VAL-002  Normative statements use SHALL or SHALL NOT.
G3B-VAL-003  MUST, SHOULD, COULD, and WONT_NOW remain business-priority values.
G3B-VAL-004  Every baselined requirement has acceptance and verification intent.
G3B-VAL-005  Every applicable standards obligation has derived IDs or approved rationale.
G3B-VAL-006  Blocking questions, conflicts, feasibility gaps, and derivation gaps equal zero for a positive outcome.
G3B-VAL-007  REQ-013 validates and does not self-approve G3B.
G3B-VAL-008  REQ-014 prevents downstream reinterpretation of requirement intent.
G3B-VAL-009  G3B does not select design or architecture mechanisms.
G3B-VAL-010  Count-based coverage cannot substitute for semantic completeness.
~~~
