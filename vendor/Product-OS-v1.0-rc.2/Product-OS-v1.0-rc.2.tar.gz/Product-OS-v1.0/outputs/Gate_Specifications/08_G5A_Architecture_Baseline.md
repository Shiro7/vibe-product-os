# Gate Specification — G5A Architecture Baseline

~~~yaml
gate_specification_id: GATE-SPEC-G5A
version: 0.1.0
status: WORKING_DRAFT
gate_id: G5A
gate_name: Architecture Baseline
owning_phase: Phase 07 - Solution Architecture
primary_object: ABL - Architecture Baseline
check_count: 30
outcome_family: BASELINE
inherits: SHARED-GATE-CONTRACT@0.1.0
validation_artifact: ARC-032
baseline_anchor: ARC-001
handoff_artifact: ARC-033
semantic_source: ../Phase_07_Solution_Architecture.md
~~~

---

# 1. Decision and Boundary

G5A decides whether the approved product has a coherent, secure, private, operable, resilient, measurable, traceable, validated, evolvable, and engineering-ready architecture with explicit decisions, mechanisms, tradeoffs, risks, and transition.

Target architecture is approved intent, not implemented or operating reality.

---

# 2. Scope and Activation

G5A binds exact upstream baselines, system of interest, release, current, target and transition states, markets, platforms, tenants, regions, languages, data classes, integrations, third parties, generated outputs, runtime environments, profile, and domain overrides.

---

# 3. Canonical Inputs and Records

ARC-001 through ARC-029 own architecture meaning. ARC-030 and ARC-031 are derived control and coverage views. ARC-032 owns validation evidence. ARC-033 owns the engineering handoff. GOV-003 stores the typed G5A decision; GOV-008 and GOV-009 retain trace and standards lineage.

---

# 4. Authority

Required roles are selected by profile and risk from:

- Solution Architect;
- Product Owner;
- Engineering Lead;
- Security Owner;
- Privacy or Compliance Owner;
- Data Owner or Architect;
- Platform or Infrastructure Owner;
- Operations or SRE Owner;
- Experience or Design representative;
- QA or Verification Lead;
- business or regulatory authority when required.

---

# 5. Detailed Check Contract

| Check | Decision test | Minimum evidence anchors |
|---|---|---|
| G5A-01 Scope, Profile, and Upstream Baselines | Upstream decisions, architecture scope, states, profile, overrides, and conditions are current and exact. | ARC-001; upstream gate decisions |
| G5A-02 Drivers, Constraints, Principles, and Assumptions | Drivers and constraints are prioritized; principles have consequences; critical assumptions are governed. | ARC-001; GOV-005 |
| G5A-03 Quality Attribute Scenarios | Material NFRs map to measurable scenarios, mechanisms, priorities, and verification. | ARC-002; REQ-004 |
| G5A-04 Current, Target, and Transition Integrity | Current evidence, target intent, transition work, compatibility, and retirement are not conflated. | ARC-003 |
| G5A-05 System Context, External Dependencies, and Trust Boundaries | Boundary, actors, external systems, ownership, critical relationships, and trust are explicit. | ARC-004 |
| G5A-06 Container, Component, and Dependency Architecture | Responsibilities, interfaces, runtime mappings, dependencies, and owners are coherent. | ARC-005; ARC-006 |
| G5A-07 Domain Boundaries and Ownership | Domain meaning, rules, data, consistency, relationships, and ownership are explicit. | ARC-007 |
| G5A-08 Data Ownership and Classification | Material data has authoritative source, writers, readers, classification, purpose, and protection consequences. | ARC-008 |
| G5A-09 Data Models, Integrity, and Concurrency | Identifiers, relationships, invariants, consistency, and concurrent-state controls are adequate. | ARC-009 |
| G5A-10 Data Lifecycle, Retention, Deletion, Residency, and Lineage | Primary, replicated, backup, vendor, log, and analytical copies have lifecycle treatment. | ARC-010; ARC-011 |
| G5A-11 APIs and Machine Contracts | Ownership, schema, validation, auth, errors, idempotency, limits, versioning, and observability are governed. | ARC-012 |
| G5A-12 Integrations and External Dependencies | Security, privacy, failure, quotas, support, change, fallback, and exit exist. | ARC-013 |
| G5A-13 Events, Jobs, Workflows, and Synchronization | Ordering, delivery, duplicate, replay, retry, dead-letter, compensation, conflict, and repair are governed. | ARC-014; ARC-015 |
| G5A-14 Identity, Authentication, Session, and Recovery | Human, service, and enterprise identity trust, assurance, sessions, revocation, recovery, and audit are defined. | ARC-016 |
| G5A-15 Authorization, Tenancy, Delegation, and Administrative Access | Policy source, enforcement, default deny, isolation, revocation, support access, delegation, and verification are explicit. | ARC-017 |
| G5A-16 Security Architecture and Threat Model | Threats and abuse cases map to preventive, detective, response, recovery, and residual-risk decisions. | ARC-018; GOV-004 |
| G5A-17 Privacy, Consent, and Data Rights | Minimization, purpose, consent, disclosure, rights, analytics, retention, deletion, and vendors are addressed. | ARC-019 |
| G5A-18 Audit and Evidence | Audit events, actor, context, integrity, retention, access, disclosure, and evidence-chain obligations are designed. | ARC-020 |
| G5A-19 Reliability, Failure, and Reconciliation | Containment, timeout, retry, idempotency, degradation, unknown outcomes, reconciliation, and SLO support are explicit. | ARC-021 |
| G5A-20 Backup, Restore, Disaster Recovery, and Continuity | Backup scope, separation, RPO, RTO, restore, failover, failback, exercises, and dependencies are governed. | ARC-026 |
| G5A-21 Performance, Capacity, Scalability, and Cost | Workload, budgets, bottlenecks, scaling, backpressure, assumptions, cost, and verification are defined. | ARC-022 |
| G5A-22 Deployment, Environments, Network, and Rollback | Topology, isolation, regions, ingress, egress, deployment, state compatibility, and rollback limits are explicit. | ARC-023 |
| G5A-23 Configuration, Secrets, Keys, and Supply Chain | Sources, validation, access, separation, rotation, revocation, build trust, and leak response are governed. | ARC-024 |
| G5A-24 Observability and Operational Diagnostics | Logs, redaction, correlation, metrics, traces, health, alerts, dashboards, owners, and retention cover critical behavior. | ARC-025 |
| G5A-25 Accessibility, Localization, Timezone, Money, and Generated Outputs | Runtime architecture can realize all applicable cross-cutting product and design obligations. | ARC-027 |
| G5A-26 Compatibility, Migration, Rollout, and Evolution | Transition, backfill, compatibility window, parallel operation, rollback or repair, deprecation, and retirement are safe. | ARC-028 |
| G5A-27 ADR Completeness and Consistency | Material decisions have drivers, options, rationale, consequences, status, supersession, and reopen rules without view conflict. | ARC-029 |
| G5A-28 GOV-009 and Control Mapping | Every active architecture obligation maps to mechanism, decision, verification, evidence, and exception. | ARC-030; GOV-009 |
| G5A-29 Validation, Risks, Exceptions, and Debt | Reviews are complete; high-severity findings are resolved; residual risks, exceptions, and debt are governed. | ARC-032; GOV-004 |
| G5A-30 Traceability and Engineering Readiness | Canonical sources, implementation mappings, fitness functions, owners, Phase 08 obligations, and trace are complete. | ARC-031; ARC-033; GOV-008 |

---

# 6. Gate-Specific Blocking Conditions

G5A cannot pass with a material:

- invalid upstream baseline or uncontrolled change;
- unknown critical data owner or trust boundary;
- missing identity, authorization, tenancy, security, privacy, failure, or recovery decision;
- unmeasurable critical NFR;
- residency or retention contradiction;
- target state misrepresented as current evidence;
- critical integration without failure or exit strategy;
- unknown canonical architecture source;
- missing GOV-009 control mapping;
- missing architecture-to-engineering handoff;
- unowned high-severity finding.

---

# 7. Outcomes

- PASS accepts ABL for Engineering Readiness.
- PASS_WITH_CONDITIONS accepts only bounded architecture work with explicit Phase 08 and implementation restrictions.
- HOLD pauses for missing evidence, mechanism, authority, decision, or validation.
- REJECT requires architecture rework or upstream rebaseline.

---

# 8. Decision Record Specialization

~~~yaml
gate_id: G5A
architecture_baseline:
upstream_baselines: []
system_of_interest:
architecture_states:
  current:
  target:
  transition:
architecture_source_revisions: []
adr_set:
critical_quality_scenarios: []
critical_control_mappings: []
validation_findings: []
residual_risks: []
exceptions: []
debt: []
engineering_handoff:
outcome:
conditions: []
decision_makers: []
evidence_index:
~~~

---

# 9. Handoff and Prohibitions

ARC-033 carries architecture identities, domains, data, contracts, controls, deployment, observability, ADRs, fitness functions, verification, risks, conditions, and change rules.

Phase 08 may allocate implementation. It may not invent architecture, treat target intent as existing implementation, or hide transition and migration obligations.

---

# 10. Validity and Reopen

Reopen for changed requirement, design, platform, data, trust boundary, integration, standard, threat, region, deployment, configuration, vendor, NFR, migration, incident, validation finding, or implementation evidence contradicting the baseline.

---

# 11. Profile and Automation

- P1 may compose architecture objects while preserving thirty checks, ADRs, control mapping, and handoff.
- P2 separates material domain, data, integration, security, reliability, deployment, and validation views.
- P3 strengthens formal assurance, threat and privacy review, DR evidence, independent challenge, decision custody, and architecture fitness controls.
- Automation may validate model consistency, ADR links, dependency rules, policy coverage, and fitness functions; it cannot approve tradeoffs or residual risk.

---

# 12. G5A Validation Rules

~~~text
G5A-VAL-001  All thirty G5A checks exist exactly once.
G5A-VAL-002  Current, target, and transition architecture remain distinct.
G5A-VAL-003  Critical NFRs map to measurable scenarios and verification.
G5A-VAL-004  Identity, authorization, data, security, privacy, reliability, recovery, and deployment decisions cannot be hidden.
G5A-VAL-005  Every active GOV-009 architecture obligation maps to mechanism and evidence intent.
G5A-VAL-006  Blocking architecture findings equal zero for a positive outcome.
G5A-VAL-007  ARC-032 validates and does not self-approve G5A.
G5A-VAL-008  ARC-033 prevents Phase 08 from inventing material architecture.
~~~
