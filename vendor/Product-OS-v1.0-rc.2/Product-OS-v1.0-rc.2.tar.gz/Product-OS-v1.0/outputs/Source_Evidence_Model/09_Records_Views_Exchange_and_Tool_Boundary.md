# Product OS v1.0 — Records, Views, Exchange, and Tool Boundary

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-09
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
canonical_view_count: 14
governed_scope: LOGICAL_SOURCE_EVIDENCE_REPRESENTATION
~~~

---

# 1. Purpose

This specification defines logical records, events, fourteen canonical views, exchange, federation, migration, extension, automation hooks, and tool boundaries so source/evidence truth can move across systems without semantic loss or invented authority.

---

# 2. Logical Record Families

| Record | Responsibility |
|---|---|
| Source registration | Identity, type, origin, version, authority, reliability, freshness, access, lifecycle, and relationships |
| Extraction/transformation | Exact input locator, method/tool/model, semantic/loss changes, output, review, and provenance |
| Claim | Atomic assertion, type, information state, scope/time, owner, authority, confidence, support, and lifecycle |
| Evidence expectation | Claim, intended decision, method/type, target/scope, independence, fitness/sufficiency, custody, and due event |
| Evidence item | Immutable target/method/result/context/period/producer/locator/integrity/limitations identity |
| Evidence use | Evidence-to-claim relationship, intended use, scope, fitness, sufficiency, and accepting authority |
| Fitness assessment | Fourteen dimension results and bounded evidence usability decision |
| Sufficiency/admissibility | Complete set, contradictions/gaps, decision strength, accepting rules/authority, and result |
| Review/corroboration | Reviewer competence/independence, findings, common origins, conflicts, and actions |
| Provenance/custody | Origin, transformations, possession/access/transfer, integrity, authenticity, and temporal history |
| Access/retention/disposal | Classification, purpose/access, redaction, hold, archive, retention, disposal, and verification |
| Evidence pack | Reproducible decision/gate/compliance/release/live projection over canonical records |

Physical implementations may combine records. Stable IDs and state/authority separation remain mandatory.

---

# 3. Append-Only Event

~~~yaml
source_evidence_event_id:
subject_ref:
event_type:
prior_state:
new_state:
effective_scope:
actor:
actor_role:
authority_ref:
reason:
source_or_evidence_refs: []
integrity_ref:
occurred_at:
recorded_at:
system_ref:
correlation_ref:
corrects_event_ref:
~~~

Events cover capture, registration, extraction, assertion, review, fitness, sufficiency, admission, access, transfer, transformation, correction, expiry, invalidation, supersession, hold, release from hold, archive, disposal, compromise, and reopen.

---

# 4. Canonical Views

## SEM-VIEW-01 — Source Register

Sources by type, identity/revision, origin, owner, authority, reliability, freshness, completeness, access, classification, lifecycle, relationships, claims, and consumers.

## SEM-VIEW-02 — Source Conflict and Correction

Duplicates, corrections, contradictions, supersession, disputed authority/reliability, unresolved claims, affected artifacts/decisions, owners, and due events.

## SEM-VIEW-03 — Claim Register

Atomic claims by type, information state, scope/time, owner, authority requirement, confidence, support, contradiction, status, and canonical artifact.

## SEM-VIEW-04 — Claim-to-Evidence Matrix

Every claim with evidence uses, relationship, fitness, sufficiency, admissibility, gaps, limitations, decision use, and validity.

## SEM-VIEW-05 — Evidence Inventory

Evidence by type, identity, target, method, result, producer, period, status, location, integrity, access, retention, and claim uses.

## SEM-VIEW-06 — Fitness and Sufficiency Queue

Unreviewed/limited/unfit/expired/invalidated items, insufficient/conflicted sets, required reviewers, actions, and due events.

## SEM-VIEW-07 — Contradiction and Limitation

Conflicting sources/claims/evidence, negative and inconclusive results, limitations, common-origin risks, authority route, and current disposition.

## SEM-VIEW-08 — Provenance and Custody

Origin, acquisition, transformation, version, integrity, authenticity, custody, access/export, hold, compromise, and disposal timeline.

## SEM-VIEW-09 — Access and Sensitive Data

Classification, flags, purpose/access grants, redactions, break-glass, disclosure, residency, incidents, review, and revocation.

## SEM-VIEW-10 — Retention, Hold, Archive, and Disposal

Retention basis/period, hold scope, archive/migration, approaching review/disposal, verified disposal, exceptions, and owner.

## SEM-VIEW-11 — Gate and Baseline Evidence

Thirteen gates with exact checks/claims, source obligations, evidence uses, fitness/sufficiency, findings/conditions/risks/exceptions, reviewers, decisions, and invalidation.

## SEM-VIEW-12 — Standards and Compliance Evidence

Standard/version/clause, GOV-009 scope, obligation/control/implementation/verification/evidence/exception/gate/release/live-effectiveness chain.

## SEM-VIEW-13 — Release and Live Evidence

Approved/built/verified/authorized/deployed/live identities, targets/cohorts/configuration, production validation, telemetry period, incidents, outcomes, and mismatch.

## SEM-VIEW-14 — AI, External, Brownfield, and Emergency Evidence

Special source type, untrusted-input state, model/provider/input/prompt, third-party issuer, synthetic/legacy/emergency limitations, reviews, allowed/prohibited uses, and remediation.

Views are derived projections. Filters and access redactions are explicit.

---

# 5. Query Contract

~~~yaml
view_or_query_id:
view_type:
as_of_system_time:
as_of_valid_time:
source_claim_evidence_scope:
artifact_phase_gate_filters: []
release_live_filters: []
status_and_fitness_filters: []
access_context:
redaction_policy_ref:
canonical_record_revisions: []
generated_at:
generated_by:
result_integrity_ref:
~~~

Snapshots state freshness and source revisions. A redacted/incomplete result cannot appear complete.

---

# 6. Exchange Envelope

~~~yaml
source_evidence_exchange:
  specification: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
  exchange_id:
  exported_at:
  exported_by:
  source_system:
  source_revision:
  scope:
  access_classification:
  redactions: []
  source_records: []
  extraction_and_transformation_records: []
  claim_records: []
  evidence_expectations: []
  evidence_records: []
  evidence_uses: []
  fitness_assessments: []
  sufficiency_and_admissibility_decisions: []
  reviews_and_corroboration: []
  provenance_and_custody_events: []
  access_retention_hold_disposal_records: []
  evidence_pack_manifests: []
  referenced_artifact_graph_gate_change_refs: []
  integrity:
    algorithm:
    digest:
  validation_result_ref:
~~~

The envelope may be implemented in JSON, YAML, relational, graph, document, or API form after Schemas & Repository Standard. Controlled semantics round-trip.

---

# 7. Import

Importer requirements:

1. validate specification/version and integrity where provided;
2. treat imported content as untrusted until access/malware/authenticity review;
3. preserve external IDs, origin, revisions, timestamps, authority claims, and history;
4. resolve/quarantine duplicate and conflicting IDs;
5. map vocabularies explicitly and quarantine unknown mandatory values;
6. preserve redaction, license, confidentiality, purpose, residency, retention, and hold constraints;
7. distinguish proposals/self-assertions from approvals/independent evidence;
8. validate references before activation;
9. issue an import reconciliation report;
10. never fabricate earlier custody or governance.

---

# 8. Export and Disclosure

Exporter requirements:

- exact scope, purpose, recipient, authority, and access context;
- minimum necessary content and metadata;
- included/omitted/redacted items and material effect;
- canonical IDs/revisions/locators and evidence periods;
- preserved native results, contradictions, limitations, invalidation, and history;
- license/contract/consent/privilege/residency/retention conditions;
- integrity and secure delivery where required;
- disclosure and recipient acknowledgement where required.

---

# 9. Federation

When sources/evidence live across systems:

- one canonical locator and owner exist per logical record;
- correlation IDs bind duplicates/projections;
- caches state source revision and freshness;
- access differences do not create silent semantic forks;
- native evidence remains where custody/integrity require;
- references survive tool migration;
- reconciliation detects orphan claims, broken locators, unreviewed evidence, stale fitness, expired access/retention, and mismatched releases.

---

# 10. Migration

Migration plans cover:

~~~text
inventory and counts
identity/correlation mapping
content and metadata completeness
controlled vocabulary mapping
versions and temporal history
provenance/custody/integrity
access/redaction/classification
retention/hold/disposal
links to claims/artifacts/graph/gates/changes
validation and exception reconciliation
rollback and old-system preservation
authority acceptance
~~~

Successful file transfer is not successful evidence migration.

---

# 11. Extension Namespace

Projects may add qualified source/evidence subtypes, method fields, or domain metadata under approved namespaces. Extensions declare owner, semantics, parent canonical type, compatibility, validation, profile/domain activation, exchange mapping, migration, and deprecation.

Projects may not redefine canonical values or create parallel fields that collapse authority, reliability, confidence, result, fitness, sufficiency, admissibility, verification, and approval.

---

# 12. Automation Hooks

Automation may:

- assign/validate IDs and references;
- capture native version, digest, timestamps, tool/method identity, and manifests;
- detect duplicates, broken locators, expiry, missing claims/targets/results/reviewers, and inconsistent status;
- enforce access, retention, hold, disclosure, and disposal workflows;
- generate candidate provenance, source/evidence classifications, claim extractions, packs, and views;
- compare candidates/environments/releases/live identities;
- trigger fitness review and Change Impact discovery.

Automation cannot decide semantic authority, reliability, claim truth, final fitness/sufficiency/admissibility, compliance, gate, release, or disposal authority where judgment is required.

---

# 13. Tool Boundary

Typical systems may store:

| Content | Possible system |
|---|---|
| Documents/policies/contracts/standards | Controlled document or records repository |
| Designs | Figma/design source with stable file/node/version |
| Code/config/build | Git/repository, CI, artifact registry, signing/provenance service |
| Requirements/work/change | Spec system, issue tracker, change platform |
| Tests/scans/reviews | Test management, CI, security/accessibility/quality tools |
| Data/telemetry | Warehouse, analytics, logging, metrics, traces, observability |
| Decisions/approvals | Governed decision workflow/signature system |
| Evidence custody | Evidence vault, controlled records store, audited native system |

No listed system gains authority by category. Tool Mapping later selects project physical ownership.

---

# 14. Schema Boundary

This library freezes logical records and vocabularies. The later `Schemas & Repository Standard` owns required/optional machine fields, serialization, IDs, constraints, APIs, directory layout, validation schemas, and migrations without weakening this semantic contract.

---

# 15. Final Records and Exchange Principle

> **Sources and evidence may be physically federated, but Product OS requires one logical, versioned, access-aware history in which imports stay untrusted until reviewed, exports preserve limitations, migrations preserve custody and decisions, and no tool status creates authority.**
