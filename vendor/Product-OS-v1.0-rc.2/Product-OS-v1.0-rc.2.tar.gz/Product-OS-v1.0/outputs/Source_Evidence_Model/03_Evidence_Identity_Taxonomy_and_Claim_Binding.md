# Product OS v1.0 — Evidence Identity, Taxonomy, and Claim Binding

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-03
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
evidence_type_count: 22
governed_scope: ALL_EVD_AND_CLAIM_BEARING_ARTIFACTS
~~~

---

# 1. Purpose

This specification defines 22 canonical evidence types, immutable evidence identity, claim binding, target/method/result/context requirements, lifecycle, negative and inconclusive results, compound evidence, and evidence boundaries.

---

# 2. Evidence Creation Rule

Create an `evidence_id` when reviewable material is intended to support, contradict, limit, or establish a defined claim. A source used only for context remains a source. When that source is offered as proof, create a claim-bound evidence record referencing the source rather than altering source identity.

---

# 3. Canonical Evidence Types

| ID | `evidence_type` | What it can establish when fit | Mandatory context |
|---|---|---|---|
| SEM-EVD-01 | SOURCE_EXCERPT_OR_OFFICIAL_RECORD | Exact attributed content or official recorded state | Source/revision/locator, authority, scope/time, extraction integrity |
| SEM-EVD-02 | DECISION_APPROVAL_OR_SIGNATURE_RECORD | A defined authority made/approved/rejected a decision | Decision/scope/version, actor authority, time, conditions, signature/workflow integrity |
| SEM-EVD-03 | INTERVIEW_TESTIMONY_OR_RESEARCH_NOTE | Attributed experience, perception, behavior, need, or context | Protocol, participant class, consent, researcher, session, raw/interpretive separation |
| SEM-EVD-04 | OBSERVATION_OR_INSPECTION_RECORD | Directly observed state, behavior, environment, or implementation | Observer/inspector, method, target, time/place, checklist, limitations |
| SEM-EVD-05 | SURVEY_EXPERIMENT_OR_RESEARCH_DATA | Structured research result for a population/hypothesis | Instrument, sample, recruitment, method, period, analysis, exclusions, uncertainty |
| SEM-EVD-06 | REQUIREMENT_ACCEPTANCE_OR_TRACE_RECORD | Governed obligation, acceptance, allocation, or trace coverage state | Exact requirement/claim, versions, edge/path, scope, owner, status |
| SEM-EVD-07 | REVIEW_OR_VALIDATION_RECORD | Expert/peer/formal review result against criteria | Subject/version, criteria, reviewers, independence, findings, decision effect |
| SEM-EVD-08 | FUNCTIONAL_OR_INTEGRATION_TEST_RESULT | Executed behavioral/API/event/job/integration result | Test/method version, candidate, environment, data, expected/actual, logs/artifacts |
| SEM-EVD-09 | QUALITY_PERFORMANCE_OR_RELIABILITY_RESULT | Performance, capacity, resilience, recovery, compatibility, or quality measurement | Workload/scenario, environment, sample/window, target, actual, variability |
| SEM-EVD-10 | SECURITY_PRIVACY_OR_THREAT_ASSESSMENT | Security/privacy control, threat, vulnerability, access, data, or abuse-case result | Target/version, methodology/tool, threat/data scope, severity, limitations, reviewer |
| SEM-EVD-11 | ACCESSIBILITY_OR_INCLUSIVE_USE_EVALUATION | Accessibility conformance/usability result from automated/manual/assistive testing | Standard/criteria, platform, user agent/AT, locale, states, evaluator, coverage |
| SEM-EVD-12 | STATIC_ANALYSIS_SCAN_OR_LINT_RESULT | Deterministic analysis of code/config/schema/content/design against rules | Tool/ruleset/version, target digest, exclusions, result, false-positive treatment |
| SEM-EVD-13 | BUILD_PACKAGE_OR_DIGEST_RECORD | Exact artifact was built/packaged/signed with an identity | Source revision, toolchain, dependencies, configuration, artifact/digest/signature |
| SEM-EVD-14 | DATA_QUALITY_MIGRATION_OR_RECONCILIATION_RESULT | Data mapping, migration, backfill, integrity, completeness, or reconciliation outcome | Source/target schemas, dataset/cohort, counts/checksums, exceptions, rollback state |
| SEM-EVD-15 | DEPLOYMENT_CONFIGURATION_OR_RELEASE_RECORD | Exact candidate/configuration reached an authorized target/cohort | Candidate/digest, config, target, window, actor, authorization, rollout/rollback state |
| SEM-EVD-16 | RUNTIME_LOG_METRIC_TRACE_OR_SLO_RESULT | Observed live behavior/service/control performance over exact period | Service/live identity, query, period/timezone, sampling, filters, exclusions, retention |
| SEM-EVD-17 | INCIDENT_PROBLEM_OR_CORRECTIVE_ACTION_RECORD | Actual failure/harm, response, cause, correction, or learned control state | Incident/scope/timeline, evidence preservation, severity, cause confidence, actions |
| SEM-EVD-18 | USER_FEEDBACK_SUPPORT_OR_OUTCOME_RECORD | User experience, support burden, adoption, satisfaction, behavior, or outcome signal | Population/channel, live version, period, method, bias, privacy, representativeness |
| SEM-EVD-19 | FINANCIAL_COMMERCIAL_OR_BUSINESS_RESULT | Cost, revenue, benefit, transaction, SLA, contractual, or business result | System/contract, period, accounting/metric method, scope, reconciliation, authority |
| SEM-EVD-20 | CONTROL_AUDIT_OR_COMPLIANCE_ASSESSMENT | Control design/operation, audit finding, standard clause, or compliance assessment | Obligation/control, scope/period, method, assessor independence, exceptions, opinion limit |
| SEM-EVD-21 | THIRD_PARTY_ATTESTATION_CERTIFICATE_OR_REPORT | External party asserts assessed state for subject/scope/period | Issuer competence/independence, method, scope, period, qualifications, authenticity |
| SEM-EVD-22 | GENERATED_REPORT_EXPORT_OR_REPRODUCIBLE_ANALYSIS | Deterministic or AI-assisted compilation/analysis derived from governed inputs | Generator/model/version, inputs, query/method, config, run, human review, limitations |

Evidence type does not determine fitness. A certificate, screenshot, test, audit, or official record may still be out of scope, stale, unreliable, incomplete, or invalid for the claim.

---

# 4. Evidence Identity

Identity is the combination of:

- immutable content/result or governed native record identity;
- evidence type;
- producer and production event;
- exact target and target revision;
- method and method version;
- environment/population/data context;
- actual result and evidence period;
- integrity reference or native authenticity controls;
- canonical location.

Changing result, target, method, material inputs, period, or content produces a new evidence identity. Metadata correction creates a correcting event without changing the original result.

---

# 5. Claim Binding

~~~yaml
evidence_use_id:
evidence_ref:
claim_ref:
relationship_to_claim:
intended_use:
decision_or_gate_ref:
effective_scope:
fitness_assessment_ref:
sufficiency_set_ref:
accepting_authority:
accepted_at:
valid_until_or_event:
~~~

Every use receives its own fitness assessment. Evidence content may remain one item while it serves several claims.

---

# 6. Relationship to Claim

~~~text
SUPPORTS
CONTRADICTS
LIMITS
ESTABLISHES_PROVENANCE
ESTABLISHES_IDENTITY
ESTABLISHES_EXECUTION
ESTABLISHES_RESULT
INCONCLUSIVE
~~~

The relationship is a reviewed conclusion. Producer intent does not control it. Evidence must not be labeled only “PASS” when it contradicts a broader claim or exposes material limitations.

---

# 7. Target Binding

Evidence names the exact target:

- claim/requirement/control/decision;
- artifact/object version;
- code/design/schema/configuration revision;
- candidate/package/digest;
- environment/target/deployment/live identity;
- dataset/population/cohort/tenant/region/language/platform;
- operational period or lifecycle state.

“Latest”, “production”, “current design”, “the API”, or “the app” is invalid unless resolved to a stable identity at evidence time.

---

# 8. Method Binding

Record:

~~~yaml
method_id:
method_type:
method_version:
procedure_or_protocol_ref:
criteria_or_oracle:
instrument_tool_or_model:
configuration:
sampling_or_selection:
expected_result:
known_limitations: []
required_independence:
competence_requirements: []
~~~

A method run is not evidence of conformance unless actual result, target, context, limitations, and fitness support that claim.

---

# 9. Result Vocabulary

Evidence records the native result plus a normalized semantic result:

~~~text
POSITIVE
NEGATIVE
PARTIAL
INCONCLUSIVE
NOT_OBSERVED
NOT_EXECUTED
BLOCKED
ERROR
~~~

| Result | Meaning |
|---|---|
| POSITIVE | Observation meets the evidence method’s defined expected criterion for tested scope |
| NEGATIVE | Observation fails or contradicts the criterion/claim for tested scope |
| PARTIAL | Mixed result across explicit partitions or incomplete criteria |
| INCONCLUSIVE | Method ran but cannot establish a responsible result |
| NOT_OBSERVED | Target behavior/event did not occur within observation window |
| NOT_EXECUTED | Planned method did not run |
| BLOCKED | External condition prevented valid execution/review |
| ERROR | Method/tool/process failed, making result unusable until assessed |

`POSITIVE` is not universal verification or gate approval. `NOT_OBSERVED` is not proof of impossibility.

---

# 10. Limitations

Limitations include:

- excluded scope/states/platforms/locales/populations;
- unavailable data or access;
- sampling and statistical uncertainty;
- tool/method blind spots;
- simulation/synthetic differences;
- environmental non-equivalence;
- conflicts of interest or lack of independence;
- evidence delay/freshness;
- integrity/custody gaps;
- known defects, exceptions, waivers, or conditions;
- interpretation or translation uncertainty.

A limitation has affected claim/scope, severity, owner, mitigation/corroboration, decision effect, and expiry/reopen rule.

---

# 11. Compound and Packaged Evidence

A report, archive, dashboard, video, test suite, audit, or gate pack may contain many evidence items. The container receives an identity, but each material result retains claim/target/method/result granularity.

~~~text
Container/package
├── manifest
├── item identities
├── claim bindings
├── integrity references
├── access/retention rules
└── package-level limitations
~~~

Package signature proves package integrity/authenticity within its method. It does not make every contained claim true.

---

# 12. Evidence Lifecycle

~~~text
CAPTURED
REGISTERED
UNDER_REVIEW
ACTIVE
LIMITED
STALE
INVALIDATED
SUPERSEDED
RETAINED_HISTORY
DISPOSED
~~~

| State | Meaning |
|---|---|
| CAPTURED | Material exists but registration/review is incomplete |
| REGISTERED | Identity, origin, target, method, result, and location are recorded |
| UNDER_REVIEW | Fitness, integrity, access, or interpretation review is active |
| ACTIVE | Eligible for one or more current claim uses through fitness decisions |
| LIMITED | Usable only for explicit bounded claims/conditions |
| STALE | Freshness or changed context requires review before reliance |
| INVALIDATED | Known change/finding defeats current reliance for affected scope |
| SUPERSEDED | New evidence replaces the intended current use while history remains |
| RETAINED_HISTORY | No current support use; preserved for audit, incident, legal, or lifecycle history |
| DISPOSED | Content was lawfully destroyed/removed; disposal proof and minimal metadata remain where required |

Lifecycle does not replace result, fitness, sufficiency, admissibility, verification status, or gate decision.

---

# 13. Evidence NOT_APPLICABLE

An evidence obligation may be `NOT_APPLICABLE` only for exact claim/method/scope with reason, authority, evidence, downstream effect, and reopen conditions. An absent result is `MISSING`, `NOT_EXECUTED`, or `BLOCKED`, not N/A.

---

# 14. Evidence Verification

Verify:

1. evidence identity and content/result resolve;
2. source/provenance and producer are attributable;
3. claim, target, version, scope, method, environment/population, data, result, and period are exact;
4. integrity and custody are sufficient for intended use;
5. limitations and contradictory results are included;
6. access and retention are enforceable;
7. lifecycle and invalidation state are current;
8. fitness/sufficiency decisions exist before decision reliance.

---

# 15. Final Evidence Identity Principle

> **An evidence item is not “a test” or “a report”; it is an immutable result tied to an exact claim, target, method, context, period, producer, and limitation set—then separately judged for whether a particular decision may rely on it.**
