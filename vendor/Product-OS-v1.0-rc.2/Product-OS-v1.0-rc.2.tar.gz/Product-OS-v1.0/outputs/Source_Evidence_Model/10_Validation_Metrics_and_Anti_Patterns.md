# Product OS v1.0 — Source / Evidence Validation, Metrics, and Anti-Patterns

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-10
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
validation_rule_count: 70
anti_pattern_count: 35
~~~

---

# 1. Purpose

This specification defines 70 validation rules, review modes, severity, metrics, cadence, and 35 anti-patterns for source/evidence integrity. Deterministic conformance supports but never manufactures semantic authority.

---

# 2. Validation Result and Severity

~~~text
PASS
FAIL
BLOCKED
NOT_REVIEWED
NOT_APPLICABLE
SUPERSEDED
~~~

~~~text
BLOCKER
MAJOR
MINOR
ADVISORY
~~~

Each result records rule, subject, scope/version, observed/expected, evidence, validator, time, severity, owner, due event, and decision effect.

---

# 3. Source Identity and Authority Rules

~~~text
SEM-VAL-001  Every material source has stable source_id, type, canonical locator, exact revision or capture event, owner, and registration time.
SEM-VAL-002  Every source type is exactly SEM-SRC-01 through SEM-SRC-22 with qualified subtype only under an approved namespace.
SEM-VAL-003  Source identity, origin, revision, derivation role, authority, reliability, freshness, completeness, access, confidentiality, and lifecycle remain separate.
SEM-VAL-004  Raw source content and received correction history are never overwritten to match extraction or downstream interpretation.
SEM-VAL-005  Every transformation binds exact inputs, method/tool/model/version, configuration, output, time, lossiness, and reviewer where required.
SEM-VAL-006  Authority uses A0 through A5 and binds domain, action/claim type, scope, effective period, rationale, and reviewer.
SEM-VAL-007  Organizational title, source location, publication appearance, or tool ownership cannot create authority outside explicit scope.
SEM-VAL-008  Reliability uses HIGH, MEDIUM, LOW, or UNKNOWN independently of authority and records material dimensions/rationale.
SEM-VAL-009  Freshness, completeness, and access states are explicit; unknown/inaccessible/missing are never converted to N/A.
SEM-VAL-010  Duplicate, transcription, extraction, derivation, correction, contradiction, and supersession preserve exact source relationships and history.
~~~

---

# 4. Claim and Extraction Rules

~~~text
SEM-VAL-011  Every material claim has stable ID/version, one SEM-CLM-01 through SEM-CLM-12 type, information state, atomic statement, subject, scope, time, and canonical owner.
SEM-VAL-012  Every source-derived claim links exact source revision, locator, and extraction record.
SEM-VAL-013  Transcription, OCR, translation, parsing, summarization, and AI extraction disclose method/version, uncertainty, context, and review.
SEM-VAL-014  Compound prose is decomposed when constituent assertions can differ in truth, authority, scope, verification, or disposition.
SEM-VAL-015  FACT, ASSUMPTION, REQUESTED_IDEA, DECISION, REQUIREMENT, and OPEN_QUESTION retain Shared Core meanings.
SEM-VAL-016  Requested idea, assumption, question, fact, decision, and requirement promotion requires the defined authority, evidence, canonical owner, and preserved prior state.
SEM-VAL-017  Claim confidence uses HIGH, MEDIUM, LOW, or UNKNOWN and never substitutes for truth, authority, probability, verification, or AI certainty.
SEM-VAL-018  Claim scope resolves relevant population, market, platform, locale, data, target, environment, release/live identity, and valid time.
SEM-VAL-019  Contradictory claims preserve all sources/evidence and receive explicit resolution authority and disposition.
SEM-VAL-020  Aggregated claims preserve inputs, query/method, filters, exclusions, missingness, units, period, uncertainty, and drill-down route.
~~~

---

# 5. Evidence Identity and Result Rules

~~~text
SEM-VAL-021  Every evidence item has stable immutable ID and exactly one SEM-EVD-01 through SEM-EVD-22 primary type.
SEM-VAL-022  Every evidence use binds exact claim, relationship, target/version, scope, intended use, fitness assessment, and accepting context.
SEM-VAL-023  Evidence records method/version, environment/population/data, expected and actual result, producer, period, source, location, integrity, limitations, and lifecycle.
SEM-VAL-024  Changing target, material method/input/context/period, native result, or content creates a new evidence identity.
SEM-VAL-025  POSITIVE, NEGATIVE, PARTIAL, INCONCLUSIVE, NOT_OBSERVED, NOT_EXECUTED, BLOCKED, and ERROR results remain honest and distinguishable.
SEM-VAL-026  Negative, failed, error, blocked, partial, and inconclusive results are retained and cannot be suppressed from affected decisions.
SEM-VAL-027  Evidence relationship to claim uses SUPPORTS, CONTRADICTS, LIMITS, ESTABLISHES_PROVENANCE, ESTABLISHES_IDENTITY, ESTABLISHES_EXECUTION, ESTABLISHES_RESULT, or INCONCLUSIVE.
SEM-VAL-028  Compound evidence containers expose item manifest, claim bindings, integrity, access/retention, and package limitations.
SEM-VAL-029  Evidence lifecycle remains separate from native result, verification, fitness, sufficiency, admissibility, gate, and change states.
SEM-VAL-030  Missing, unexecuted, or blocked evidence obligations cannot be recorded NOT_APPLICABLE without exact reason, authority, evidence, downstream effect, and reopen trigger.
~~~

---

# 6. Fitness, Sufficiency, and Admissibility Rules

~~~text
SEM-VAL-031  Every evidence use evaluates all applicable SEM-FIT-01 through SEM-FIT-14 dimensions.
SEM-VAL-032  One material failed fitness dimension cannot be hidden by aggregate score or pass count.
SEM-VAL-033  Fitness uses FIT, FIT_WITH_LIMITATIONS, UNFIT, EXPIRED, INVALIDATED, or NOT_REVIEWED for exact claim/use/scope.
SEM-VAL-034  FIT does not become claim truth, sufficiency, admissibility, verification, compliance, or approval automatically.
SEM-VAL-035  Sufficiency includes supportive, contradictory, limiting, excluded, missing, inaccessible, and invalidated evidence obligations.
SEM-VAL-036  Sufficiency uses SUFFICIENT, SUFFICIENT_WITH_LIMITATIONS, INSUFFICIENT, CONFLICTED, or NOT_ASSESSED with accepting authority.
SEM-VAL-037  Corroboration records origin/method groups and discounts duplicates, common data, common queries, circular citations, and shared blind spots.
SEM-VAL-038  Absence of incidents, complaints, alerts, findings, or failures is evidence only when detection/reporting/instrumentation/population/period capability is established.
SEM-VAL-039  Admissibility uses ADMITTED, ADMITTED_WITH_LIMITATIONS, EXCLUDED, QUARANTINED, or PENDING_REVIEW under exact rules and authority.
SEM-VAL-040  Broader or higher-consequence decisions require evidence scope, duration, representativeness, independence, integrity, and corroboration proportionate to the claim.
~~~

---

# 7. Production, Review, Reuse, and Gate Rules

~~~text
SEM-VAL-041  Material evidence expectations define claim, decision, target/scope, method/type, period/sample, independence, fitness/sufficiency, producer, reviewer, authority, and due event.
SEM-VAL-042  Collection has legitimate purpose/authority, minimization, participant/data protections, access, retention, custody, and incident route.
SEM-VAL-043  Evidence production events preserve native outputs, deviations, tool/instrument/model/configuration, time, result, errors, and custody start.
SEM-VAL-044  Evidence review records reviewer competence/authority, independence/conflict, method, findings, interpretation, claim relationships, actions, and status.
SEM-VAL-045  Review acceptance cannot substitute for fitness, sufficiency, claim approval, gate outcome, or release authorization.
SEM-VAL-046  Evidence reuse creates a new decision and fitness assessment without changing original producer, result, period, or limitations.
SEM-VAL-047  Reuse proves claim, target/version, scope, method, environment/data, integrity, freshness, and invalidation equivalence.
SEM-VAL-048  Every evidence pack binds decision/gate, exact scope/version/as-of time, claims, evidence uses, fitness/sufficiency, contradictions, gaps, conditions, changes, manifest, access, and integrity.
SEM-VAL-049  All 13 gates receive evidence packs that preserve native results and material blockers; percentage or item count cannot self-approve.
SEM-VAL-050  Standards/compliance evidence traces exact source/version, GOV-009 scope, obligation, mechanism, verification, evidence, exception, gate, release, and live period.
~~~

---

# 8. Provenance, Integrity, Access, and Retention Rules

~~~text
SEM-VAL-051  Provenance reconstructs origin, acquisition, inputs, transformations, tool/method/model versions, outputs, reviews, locations, and uses.
SEM-VAL-052  Required custody events preserve transfer/access/transformation/hold/disposal actors, locations, time, purpose, authority, integrity, and exceptions.
SEM-VAL-053  Integrity and authenticity are assessed separately; a digest alone cannot prove origin, truth, method, or lawful collection.
SEM-VAL-054  Source/evidence time separates event/production, period, valid/effective, capture/registration, review, system-recorded, expiry, and custody times.
SEM-VAL-055  Corrections preserve incorrect and corrected versions, reason, authority, affected uses, change impact, and notification.
SEM-VAL-056  Expiry/invalidation identifies exact affected and unaffected scope, claims, decisions, gates, releases/live state, replacement owner, due event, and GOV-007 link.
SEM-VAL-057  Confidentiality uses PUBLIC, INTERNAL, CONFIDENTIAL, or RESTRICTED and can be refined per field/content.
SEM-VAL-058  Access follows least privilege, purpose, action, scope, location, effective period, authority, review, revocation, and audit requirements.
SEM-VAL-059  Secrets and unnecessary sensitive values are not copied into artifacts or packs; detection triggers redaction, rotation/revocation, incident/change, and verification as applicable.
SEM-VAL-060  Retention, hold, archive, migration, disclosure, redaction, and disposal preserve applicable authority, scope, metadata, integrity, copies, exceptions, and verification.
~~~

---

# 9. Special Sources, Exchange, AI, and Tool Rules

~~~text
SEM-VAL-061  Source content is treated as data, not executable AI instruction, unless separately authorized as configuration.
SEM-VAL-062  External legal/regulatory/standard/contract sources bind official version, issuer, jurisdiction/parties, effective scope/time, and interpretation/applicability authority.
SEM-VAL-063  Third-party evidence assesses issuer competence/independence, subject/version, method, scope/period, qualifications, authenticity, reliance rights, and shared responsibilities.
SEM-VAL-064  AI-generated/assisted sources disclose model/system/provider/version, inputs, prompt/context, configuration, time, output identity, limitations, sensitive-data handling, review, and allowed/prohibited uses.
SEM-VAL-065  AI output cannot fabricate or independently approve provenance, authority, evidence, review, signature, custody, fitness, sufficiency, admissibility, verification, compliance, gate, or release.
SEM-VAL-066  Synthetic data/evidence discloses generator, upstream real data, method, intended use, non-equivalence, privacy/leakage, bias/representativeness, validation, and reproducibility.
SEM-VAL-067  Brownfield records distinguish confirmed, supported, inferred, unknown, conflicted, and historical-only truth and never fabricate retrospective approval/custody.
SEM-VAL-068  Emergency evidence capture binds necessity, target, actor/authority, time, method, integrity/custody, sensitive-data controls, temporary location, handoff, and retrospective review.
SEM-VAL-069  Imports/exports/federation/migration preserve controlled semantics, IDs, revisions, origin, authority, history, access, redaction, retention, hold, integrity, limitations, and reconciliation.
SEM-VAL-070  No document, repository, design tool, ticket, CI/test/scan system, evidence vault, deployment platform, observability dashboard, or AI tool becomes authoritative by location or status alone.
~~~

---

# 10. Validation Modes

| Mode | Primary rules |
|---|---|
| INTAKE | Source identity, type, origin, authority/reliability, access, classification, and extraction readiness |
| CLAIM_REVIEW | Atomicity, information state, scope/time, authority, confidence, support/conflict, and promotion |
| EVIDENCE_REGISTRATION | Evidence identity, target/method/result/context, provenance, integrity, access, retention, and lifecycle |
| FITNESS_REVIEW | Fourteen dimensions, limitations, reviewer authority, validity, and reuse |
| DECISION_OR_GATE | Complete set sufficiency, admissibility, contradictions, gaps, pack, independence, and accepting authority |
| PRE_RELEASE_OR_LIVE | Candidate/configuration/target/cohort equivalence, release pack, monitoring, production validation, and operational period |
| CHANGE_OR_INCIDENT | Freshness, expiry, invalidation, impact propagation, replacement, containment, and reopen |
| RETENTION_OR_MIGRATION | Hold, archive, access, export/import, integrity, reconciliation, disposal, and proof |
| CONTINUOUS | Broken locators, stale sources, expired fitness, access drift, missing reviews, evidence loss, live effectiveness, and residual obligations |

---

# 11. Metrics

| Metric | Definition | Guardrail |
|---|---|---|
| Source registration coverage | Material source-linked claims with registered exact source / material source-linked claims | Explicit inference/unknown remains visible |
| Source locator resolution | Active source locators that resolve / active locators checked | Restricted access is measured separately from broken |
| Authority review coverage | Material sources/claims with current scoped authority review / applicable set | A0 remains visible |
| Reliability review coverage | Material sources with dimensioned reliability / applicable set | Do not reward optimistic ratings |
| Claim atomicity defect rate | Claims split after gate/change due to mixed semantics / reviewed claims | Use to improve extraction |
| Unsupported material claim rate | Material claims lacking source/inference and evidence expectation / material claims | Ideas/questions are not falsely counted as claims requiring proof |
| Contradiction resolution age | Time material conflicts remain unresolved | Preserve unresolved count and severity |
| Evidence registration completeness | Evidence records passing SEM-VAL-021..030 / reviewed evidence | Presence alone is excluded |
| Fitness review coverage | Evidence uses with current fitness / active material uses | Each reuse counts as new use |
| Sufficiency gap rate | Decision packs with INSUFFICIENT/CONFLICTED/missing obligations / reviewed packs | Finding gaps is healthy; hiding them is not |
| Common-origin corroboration rate | Claimed corroboration groups failing independence / reviewed groups | Lower is better after honest detection |
| Evidence reuse rate | Approved reuse uses / all evidence uses | High rate is not inherently good |
| Reuse reversal rate | Reuse decisions later invalidated for missed non-equivalence / reuse decisions | Segment genuinely new change |
| Evidence invalidation propagation time | Time from trigger to affected claim/decision disposition | Segment critical scopes |
| Stale evidence age | Age of active stale items before review/replacement | Do not delete to improve metric |
| Evidence pack reproducibility | Packs reproduced semantically / sampled packs | Access-aware redactions remain explicit |
| Negative-result visibility | Material negative/partial/inconclusive/error results included in packs / applicable results | Suppression is a blocker |
| Custody exception rate | Lost, unconfirmed, compromised, or unexplained custody events / custody-required items | Severity matters |
| Sensitive-data exposure rate | Unauthorized secret/personal/restricted exposures / handled items | Zero tolerance may apply by domain |
| Retention/hold conformance | Items within retention/hold/disposal rules / reviewed governed items | Over-retention and early disposal both fail |
| Broken lineage rate | Broken source→claim→evidence→decision links / required links | Derived views do not fix canonical gaps |
| Gate evidence escape rate | Favorable decisions reopened due to evidence issue discoverable at decision time / decisions | Separate later unforeseeable change |
| External/third-party expiry coverage | External evidence with current expiry/change monitoring / active external uses | Contract notice gaps remain visible |
| AI attribution/review coverage | AI-assisted material with full generation metadata and required human review / applicable items | Human click-through is not meaningful review |

Metrics drive improvement, not evidence volume, optimistic statuses, surveillance, or premature disposal.

---

# 12. Review Cadence

Review at source intake, claim promotion, evidence registration/reuse, every affected gate, pre-release/live, standard/contract/authority change, source/evidence expiry, incident/finding, material GOV-007 change, access/retention/hold event, tool/schema migration, third-party renewal, AI/model update, and applicable audit cadence.

---

# 13. Anti-Patterns

~~~text
SEM-AP-01  Treating source presence as proof of a claim.
SEM-AP-02  Treating a FACT information state as universally verified truth.
SEM-AP-03  Ranking source authority solely by job title or tool location.
SEM-AP-04  Conflating source authority with reliability, freshness, or confidence.
SEM-AP-05  Editing raw source history to match a later correction or interpretation.
SEM-AP-06  Extracting a claim without exact source revision and locator.
SEM-AP-07  Letting OCR, translation, transcription, summarization, or AI extraction hide uncertainty or context loss.
SEM-AP-08  Promoting an idea, assumption, or question to requirement/decision without authority.
SEM-AP-09  Combining several independently challengeable assertions in one claim.
SEM-AP-10  Omitting scope/time so a local observation appears universal.
SEM-AP-11  Treating an evidence file, screenshot, attachment, row count, meeting, or dashboard as sufficient by presence.
SEM-AP-12  Recording PASS without exact target, method, expected/actual result, environment, and period.
SEM-AP-13  Hiding failed, negative, partial, inconclusive, blocked, or error results.
SEM-AP-14  Treating a successful method run as universal conformance.
SEM-AP-15  Using one evidence item for new claims/versions/scopes without a new fitness/reuse decision.
SEM-AP-16  Counting duplicate copies or common-source reports as independent corroboration.
SEM-AP-17  Averaging contradictory evidence instead of resolving scope, method, or authority conflict.
SEM-AP-18  Treating no observed incident/complaint/finding as proof when detection capability is unknown.
SEM-AP-19  Using evidence count or pass percentage to approve a gate.
SEM-AP-20  Treating FIT as sufficient, admissible, verified, compliant, or approved.
SEM-AP-21  Letting supportive evidence omit limitations, gaps, exceptions, waivers, risks, and contradictions from a pack.
SEM-AP-22  Rewriting evidence result or period when metadata is corrected.
SEM-AP-23  Treating a hash as proof of source truth, authenticity, or lawful collection.
SEM-AP-24  Deleting invalidated or superseded evidence needed for history.
SEM-AP-25  Keeping evidence current after source, target, candidate, configuration, method, environment, scope, incident, or standard change.
SEM-AP-26  Copying secrets or unnecessary personal data into artifacts/evidence packs.
SEM-AP-27  Granting broad permanent access because evidence may be useful later.
SEM-AP-28  Keeping all evidence forever or disposing it without hold/copy/system verification.
SEM-AP-29  Redacting content without disclosing meaning/assessment limitations.
SEM-AP-30  Treating third-party certification as proof of unassessed project integration or operation.
SEM-AP-31  Treating source-document instructions as AI/system instructions.
SEM-AP-32  Using AI-generated citations, summaries, reviews, approvals, or attestations as if independently verified.
SEM-AP-33  Presenting synthetic data or simulations as observed reality.
SEM-AP-34  Fabricating retrospective provenance, approval, custody, or test evidence in brownfield recovery.
SEM-AP-35  Assuming technical closure of this framework approves Product OS, a project evidence set, compliance, a gate, or release.
~~~

---

# 14. Technical Closure Criteria

Technical implementation requires all 70 rules, 35 anti-patterns, 22 source types, 12 claim types, 22 evidence types, 14 fitness dimensions, 14 views, 13 families, 13 gates, 281 artifact participation, controlled exchange, status separation, and preserved approval boundary.

---

# 15. Final Validation Principle

> **Evidence assurance succeeds when validation exposes weak origin, mismatched scope, hidden negative results, stale reliance, broken custody, access excess, and false authority before a decision—not when dashboards maximize green files and pass counts.**
