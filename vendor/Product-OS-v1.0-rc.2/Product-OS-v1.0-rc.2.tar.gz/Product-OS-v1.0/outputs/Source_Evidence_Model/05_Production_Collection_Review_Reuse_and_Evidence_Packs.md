# Product OS v1.0 — Production, Collection, Review, Reuse, and Evidence Packs

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-05
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
gate_count: 13
artifact_family_count: 13
~~~

---

# 1. Purpose

This specification governs evidence planning, lawful and proportionate collection, production, review, independence, reuse/equivalence, gate and decision packs, standards/compliance lineage, release/live reconciliation, and operational periods.

---

# 2. Evidence Expectation

Define evidence before material execution when practical:

~~~yaml
evidence_expectation_id:
claim_or_obligation_ref:
intended_decision_or_gate:
required_evidence_types: []
required_method_or_criteria:
target_and_scope:
environment_population_data:
required_period_or_sample:
required_independence:
fitness_threshold:
sufficiency_threshold:
integrity_and_custody:
access_and_retention:
producer:
reviewer:
accepting_authority:
due_event:
invalidation_triggers: []
~~~

Expectations may allow several valid methods. They do not predetermine the result.

---

# 3. Collection Authorization and Minimization

Before collection, confirm:

1. defined claim and legitimate purpose;
2. lawful/contractual/organizational authority;
3. minimum necessary people, data, systems, environments, period, and granularity;
4. consent/notice or approved alternative where required;
5. safety, security, privacy, accessibility, and participant protections;
6. access, confidentiality, transfer, residency, retention, and disposal;
7. method competence, calibration, and bias controls;
8. expected custody and integrity;
9. incident/escalation route for unexpected sensitive or harmful content;
10. whether synthetic or lower-risk evidence can meet the same claim without weakening it.

Collecting more data is not automatically stronger evidence.

---

# 4. Evidence Production Event

~~~yaml
production_event_id:
evidence_expectation_ref:
claim_refs: []
target_identity_and_revision:
method_ref:
producer:
producer_role_and_competence:
tool_instrument_model_and_version:
configuration:
environment_population_data:
started_at:
completed_at:
expected_result:
actual_result:
native_output_refs: []
deviations: []
limitations: []
custody_start_event:
integrity_ref:
incident_or_error_refs: []
~~~

Production preserves negative, failed, blocked, error, and inconclusive results. Re-execution receives a new event and evidence identity.

---

# 5. Review Contract

Review answers:

- Was the correct target/version/scope tested or observed?
- Was the method appropriate and executed as declared?
- Does the actual result support the producer’s interpretation?
- Are exclusions, limitations, failures, anomalies, bias, and contradictions complete?
- Are provenance, integrity, custody, access, and retention sufficient?
- Does reviewer competence and independence match consequence?
- Which claims are supported, contradicted, limited, or unresolved?
- What fitness, corroboration, action, or re-run is required?

~~~yaml
evidence_review_id:
evidence_ref:
review_scope:
reviewer:
competence_and_authority:
independence_assessment:
conflicts_of_interest: []
review_method:
findings: []
interpretation:
claim_relationships: []
required_corrections_or_actions: []
review_status:
reviewed_at:
reopen_triggers: []
~~~

---

# 6. Review Status

~~~text
NOT_REVIEWED
IN_REVIEW
ACCEPTED_AS_RECORDED
ACCEPTED_WITH_LIMITATIONS
CHALLENGED
REJECTED_UNRELIABLE
REVIEW_SUPERSEDED
~~~

Review acceptance does not equal claim approval or evidence sufficiency.

---

# 7. Independence and Segregation

Independence strength increases with consequence, profile, and domain override.

Potential conflicts include:

- producer reviewing their own material claim;
- implementer controlling test data/oracle and accepting result;
- vendor self-attestation used as sole assurance;
- outcome owner selecting only favorable cohorts/periods;
- AI generating and evaluating its own output without independent ground truth;
- audit/review scope or compensation controlled by the subject in a way that impairs judgment.

Where full independence is not possible, record the limitation, compensating review, accepting authority, exact permitted use, and expiry. Mandatory external/accredited independence cannot be waived by convenience.

---

# 8. Evidence Reuse and Equivalence

Reuse requires a new `reuse_decision_id`:

~~~yaml
reuse_decision_id:
original_evidence_ref:
new_claim_ref:
new_intended_use:
original_target_scope_context_period:
new_target_scope_context_period:
claim_equivalence:
target_version_equivalence:
scope_equivalence:
method_continues_valid:
environment_data_representative:
integrity_intact:
freshness_sufficient:
invalidation_review:
limitations_carried_forward: []
fitness_assessment_ref:
reviewer:
accepting_authority:
result:
decided_at:
~~~

Reuse result:

~~~text
REUSE_APPROVED
REUSE_APPROVED_WITH_LIMITATIONS
NEW_EVIDENCE_REQUIRED
REUSE_PROHIBITED
PENDING_REVIEW
~~~

Original producer, result, period, and limitations remain unchanged. Copies do not become independent evidence.

---

# 9. Reproducibility and Repeatability

Where applicable, evidence records enough to:

- repeat the same method on the same target/context;
- reproduce derived results from governed inputs and transformation;
- explain nondeterminism, stochastic variation, external dependencies, or unavailable historic systems;
- compare reruns without overwriting prior results.

Non-reproducible evidence may still be valid for unique events, testimony, incidents, or field observation when authenticity, custody, method, corroboration, and limitations are appropriate.

---

# 10. Evidence Pack Contract

An evidence pack is a versioned projection, not a new truth store.

~~~yaml
evidence_pack_id:
pack_type:
decision_or_gate_ref:
scope_and_version:
as_of_time:
claim_refs: []
evidence_use_refs: []
fitness_assessment_refs: []
sufficiency_decision_refs: []
contradictions_and_limitations: []
missing_evidence_obligations: []
conditions_exceptions_waivers_risks: []
change_impact_refs: []
pack_owner:
reviewers: []
query_or_manifest:
source_revisions: []
generated_at:
integrity_ref:
access_and_retention:
~~~

Rebuilding the same pack as-of the same governed revisions and access context returns semantically equivalent results.

---

# 11. Thirteen-Gate Evidence Packs

| Gate | Minimum evidence focus |
|---|---|
| G0 — Intake Ready | Project identity, source register, authority/reliability, preliminary profile/risk/standards triggers, access and unknowns |
| G1 — Problem Understood | Research sources, stakeholder/user scope, facts/assumptions/questions, current state, cause, outcome, contradictions, discovery limitations |
| G2 — Business Baseline | Business rules/process/capability/information/control/owner/risk evidence, source authority, validation findings, obligations |
| G3A — Product Baseline | Product boundary/capability/policy/platform/market/journey/release-scope evidence, feasibility and standards applicability |
| G3B — Requirements Baseline | Requirement origins, authority, atomicity, acceptance, verification/evidence expectations, conflict and coverage evidence |
| G4A — Experience Baseline | Journey/state/IA/flow/content/recovery/accessibility/localization validation across representative users/platforms |
| G4B — Design Baseline | Screen/component/token/state/responsive/locale/accessibility/design-system review and implementation-ready handoff evidence |
| G5A — Architecture Baseline | Driver/ADR/data/integration/trust/security/privacy/reliability/deployment/recovery/observability decision and validation evidence |
| G5B — Engineering Readiness | Work/dependency/environment/migration/control/test/evidence/rollback/ownership readiness proof |
| G6A — Implementation Baseline | Exact revision/candidate/configuration/build/migration/deviation/review/check and upstream conformance evidence |
| G6B — Verification Baseline | Candidate-bound risk/requirement/control coverage, native results, defects, exceptions, limitations, independent verification, VBL |
| G7 — Release Authorization | Candidate equivalence, current G6B, target/cohort/window, conditions, risk, rollout/rollback, monitoring, communications, authority |
| G8 — Operational Sustainability and Evolution | Exact live scope, SLOs/incidents/support/controls/security/privacy/accessibility/data/cost/outcomes/evolution and period-bound effectiveness |

The gate authority determines sufficiency. One failed material check cannot be offset by supportive item count.

---

# 12. Artifact-Family Evidence Responsibilities

| Family | Evidence responsibility |
|---|---|
| GOV | Authority, decision, risk, assumption, question, change, traceability, applicability, and governance-control proof |
| INIT | Source identity, authority/reliability, intake/classification, asset/access, governance activation, and G0 validation |
| DISC | Research method, raw/processed findings, participant/stakeholder context, corroboration, contradiction, and G1 validation |
| BUS | Business object/rule/process/control/information/measure/owner validation and G2 evidence |
| PROD | Product boundary/capability/policy/measure/release-scope validation and G3A evidence |
| REQ | Source/authority/requirement/acceptance/verification expectation/coverage/validation and G3B evidence |
| EXP | Journey/state/flow/interaction/content/accessibility/localization evaluation and G4A evidence |
| DES | Component/token/screen/state/output/accessibility/design review and G4B evidence |
| ARC | Architecture decision/scenario/control/data/integration/deployment/risk validation and G5A evidence |
| ENG | Readiness, allocation, dependency, environment, migration, test/evidence plan, control, and G5B validation |
| IMP | Revision/build/implementation/configuration/migration/deviation/check/candidate and G6A evidence |
| VRL | Verification result/coverage/defect/exception/candidate/release/production-validation and G6B/G7 evidence |
| OPS | Live identity/telemetry/SLO/incident/support/control/cost/outcome/evolution/transfer/retirement and G8 evidence |

---

# 13. Standards and Compliance Pack

Minimum chain:

~~~text
authoritative standard/source and edition
→ GOV-009 applicability decision and exact scope
→ obligation/control/requirement
→ design/architecture/implementation mechanism
→ verification method and evidence expectation
→ evidence item and fitness assessment
→ exception/waiver/risk/condition where any
→ gate/release/live decision
→ operational effectiveness period
~~~

A compliance claim states exact standard/version, clauses/controls, scope, period, exclusions, method, assessor authority/independence, evidence set, limitations, and decision. Product OS never claims universal compliance from file presence or partial coverage.

---

# 14. Release-to-Live Reconciliation

Evidence distinguishes:

- approved baseline;
- built candidate and digest;
- verified candidate/configuration/environment;
- release-authorized scope/conditions/target/window;
- actually deployed candidate/configuration;
- actual exposed population/cohort/tenant/region;
- observed live period and operational result.

Mismatch creates a finding/change and invalidates unsupported release/live claims. Deployment success does not prove user outcome or control effectiveness.

---

# 15. Operational Evidence Period

Continuous-effectiveness claims require defined observation window, SLI/measure/query, target/live identity, population, exclusions, sampling, downtime/data gaps, timezone, threshold, owner, and invalidation triggers.

One period cannot prove later continuous operation after material change, incident, telemetry gap, control change, or scope expansion.

---

# 16. Pack Closure

An evidence pack is ready for authority decision when:

1. claims, exact scope/version, and intended decision resolve;
2. all required evidence obligations have items or governed missing/N/A dispositions;
3. native results, negative evidence, contradictions, limitations, defects, exceptions, waivers, risks, and conditions are visible;
4. fitness and sufficiency decisions are current;
5. integrity, access, custody, retention, freshness, and change impact are acceptable;
6. reviewers/authority/independence meet the contract;
7. pack manifest/query is reproducible.

---

# 17. Final Production and Pack Principle

> **Plan evidence around the claim and decision before collecting it; preserve every result rather than only successes; reuse only through explicit equivalence; and let each gate see the complete current evidence set—including contradictions, limitations, and missing obligations—not a curated folder of favorable files.**
