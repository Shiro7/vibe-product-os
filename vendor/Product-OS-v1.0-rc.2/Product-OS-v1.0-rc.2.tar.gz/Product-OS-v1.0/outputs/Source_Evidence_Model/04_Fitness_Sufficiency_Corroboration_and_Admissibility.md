# Product OS v1.0 — Fitness, Sufficiency, Corroboration, and Admissibility

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-04
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
fitness_dimension_count: 14
fitness_result_count: 6
sufficiency_result_count: 5
admissibility_result_count: 5
~~~

---

# 1. Purpose

This specification decides whether one evidence item is fit for one exact claim/use, whether the complete evidence set is sufficient, whether corroboration is genuinely independent, and whether the accepting decision context admits the evidence.

Fitness, sufficiency, and admissibility are distinct:

- fitness: can this item responsibly inform this claim/use?
- sufficiency: does the relevant evidence set justify the claimed decision strength?
- admissibility: may the item/set be used under the applicable authority, procedure, law, contract, standard, or gate rule?

---

# 2. Fourteen Fitness Dimensions

| ID | Dimension | Decision test |
|---|---|---|
| SEM-FIT-01 | IDENTITY_MATCH | Does evidence identity resolve to unaltered content/result and intended source? |
| SEM-FIT-02 | CLAIM_RELEVANCE | Does the observed result logically bear on the exact claim rather than an adjacent claim? |
| SEM-FIT-03 | SCOPE_MATCH | Does user/role/market/region/language/platform/data/feature/control scope match? |
| SEM-FIT-04 | VERSION_TARGET_MATCH | Does evidence bind exact artifact/candidate/configuration/deployment/live version? |
| SEM-FIT-05 | METHOD_VALIDITY | Is method/protocol/oracle suitable and correctly executed for the claim? |
| SEM-FIT-06 | RESULT_CLARITY | Are expected/actual/native/normalized results and interpretation unambiguous? |
| SEM-FIT-07 | ENVIRONMENT_REPRESENTATIVENESS | Are environment, population, sample, workload, devices, integrations, and data representative? |
| SEM-FIT-08 | PRODUCER_COMPETENCE_AUTHORITY | Is producer competent and authorized for the evidence production/statement being made? |
| SEM-FIT-09 | INDEPENDENCE_AND_BIAS | Is required independence present and material bias/conflict controlled? |
| SEM-FIT-10 | PROVENANCE_AUTHENTICITY | Can origin, transformation, attribution, and authenticity be reconstructed? |
| SEM-FIT-11 | INTEGRITY_CUSTODY | Is content/result protected against unauthorized alteration, substitution, loss, or custody ambiguity? |
| SEM-FIT-12 | FRESHNESS_PERIOD | Is production/observation period current enough and long enough for this claim/use? |
| SEM-FIT-13 | COMPLETENESS_LIMITATIONS | Are relevant states, exclusions, gaps, negative results, and limitations sufficiently represented? |
| SEM-FIT-14 | REVIEWABILITY_ACCESS_RETENTION | Can authorized reviewers inspect/reproduce enough evidence, and will it remain available for required duration? |

Dimension results:

~~~text
PASS
PASS_WITH_LIMITATION
FAIL
UNKNOWN
NOT_APPLICABLE_WITH_REASON
~~~

One material `FAIL` may make the item unfit regardless of other passes.

---

# 3. Fitness Results

~~~text
FIT
FIT_WITH_LIMITATIONS
UNFIT
EXPIRED
INVALIDATED
NOT_REVIEWED
~~~

| Result | Meaning |
|---|---|
| FIT | All required dimensions support the exact use with no decision-changing limitation |
| FIT_WITH_LIMITATIONS | Usable only for explicit bounded claim/scope/decision conditions |
| UNFIT | One or more limitations defeat responsible use for this claim |
| EXPIRED | Time, standard, approval, period, or freshness rule has elapsed |
| INVALIDATED | Material change, incident, contradiction, integrity issue, or target mismatch defeated prior use |
| NOT_REVIEWED | No authorized fitness decision exists |

`FIT` is not proof that the claim is true or that the evidence set is sufficient.

---

# 4. Fitness Assessment Algorithm

~~~text
1. Bind evidence identity, claim, intended use, accepting context, scope, and time.
2. Resolve target/version, source, method, environment/population/data, result, and period.
3. Evaluate all applicable SEM-FIT dimensions.
4. Record conflicts, unknowns, access restrictions, and limitations.
5. Determine whether additional evidence or independent review is required.
6. Assign FIT, FIT_WITH_LIMITATIONS, UNFIT, EXPIRED, INVALIDATED, or NOT_REVIEWED.
7. Bind assessor competence/authority, date, validity, and reopen triggers.
8. Route the item into evidence-set sufficiency and admissibility assessment.
~~~

---

# 5. Fitness Assessment Record

~~~yaml
fitness_assessment_id:
evidence_ref:
claim_ref:
intended_use:
accepting_context_ref:
scope:
dimension_results:
  SEM-FIT-01:
  SEM-FIT-02:
  SEM-FIT-03:
  SEM-FIT-04:
  SEM-FIT-05:
  SEM-FIT-06:
  SEM-FIT-07:
  SEM-FIT-08:
  SEM-FIT-09:
  SEM-FIT-10:
  SEM-FIT-11:
  SEM-FIT-12:
  SEM-FIT-13:
  SEM-FIT-14:
fitness_result:
limitations: []
additional_evidence_required: []
assessor:
assessor_competence_or_authority:
assessed_at:
valid_until_or_event:
reopen_triggers: []
~~~

---

# 6. Evidence-Set Sufficiency

Sufficiency evaluates the complete relevant set, not only supportive items.

~~~text
SUFFICIENT
SUFFICIENT_WITH_LIMITATIONS
INSUFFICIENT
CONFLICTED
NOT_ASSESSED
~~~

Assess:

- claim criticality and consequence of error;
- applicable gate, standard, contract, policy, domain override, and authority threshold;
- coverage of scope, states, risks, controls, acceptance, negative paths, and operational periods;
- fitness and independence of included items;
- contradiction and disconfirming evidence;
- method diversity and triangulation;
- missing/blocked/inaccessible evidence obligations;
- residual uncertainty and whether it can be bounded lawfully;
- freshness, durability, and reproducibility;
- known defects, exceptions, waivers, conditions, and change impact.

---

# 7. Sufficiency Decision Record

~~~yaml
sufficiency_decision_id:
claim_ref:
intended_decision_or_gate_ref:
decision_strength_requested:
scope:
evidence_use_refs: []
supporting_items: []
contradicting_items: []
limiting_items: []
excluded_items: []
missing_evidence_obligations: []
coverage_assessment:
independence_assessment:
uncertainty:
sufficiency_result:
conditions: []
residual_gaps: []
reviewers: []
accepting_authority:
decided_at:
valid_until_or_event:
reopen_triggers: []
~~~

---

# 8. Evidence Strength Is Contextual

No universal numerical hierarchy makes one evidence type stronger than another. Strength depends on the claim.

Examples:

- a signed contract is strong evidence of a contractual term, not actual runtime behavior;
- production telemetry is strong for observed live behavior, not user intent or legal authority;
- user interviews are strong for lived experience and language, not population prevalence without sampling support;
- a deterministic test is strong for the tested candidate/context, not untested environments or continuous effectiveness;
- a certificate is strong only within issuer, method, scope, period, and qualifications;
- source code is evidence of implementation intent/content, not proof of deployed live identity or correct behavior by itself.

---

# 9. Corroboration

Evidence corroborates when independently originated or independently measured items support compatible claims for overlapping scope/time.

Record:

~~~yaml
corroboration_group_id:
claim_ref:
evidence_refs: []
origin_groups: []
method_groups: []
shared_dependencies: []
independence_assessment:
common_mode_risks: []
combined_scope:
combined_limitations: []
reviewer:
~~~

Not independent:

- copied reports from the same underlying dataset;
- several dashboards using the same broken query;
- multiple AI summaries of one source;
- a vendor assertion and certificate relying on the same unreviewed self-report;
- rerunning the same test against identical blind spots;
- several stakeholders repeating one unverified rumor.

---

# 10. Contradictory Evidence

When evidence conflicts:

1. preserve all items and native results;
2. compare claim, target, version, scope, period, method, population, and source origin;
3. assess integrity, competence, independence, and limitations;
4. avoid averaging incompatible evidence;
5. obtain additional evidence where material;
6. route domain/decision authority;
7. issue `CONFLICTED`, bounded sufficiency, or resolved claim decision;
8. trigger Change Impact Rules when prior reliance changes.

A later item does not automatically erase earlier valid-period evidence.

---

# 11. Negative and Absence Evidence

Negative evidence may strongly contradict a universal claim within tested scope. Absence of observed failure supports only the exact observation window/method sensitivity and never proves impossibility.

“No incidents”, “no complaints”, “no alerts”, and “no scan findings” require proof that reporting, detection, access, instrumentation, population, and retention were capable of observing the event.

---

# 12. Admissibility

~~~text
ADMITTED
ADMITTED_WITH_LIMITATIONS
EXCLUDED
QUARANTINED
PENDING_REVIEW
~~~

Admissibility may depend on:

- lawful/authorized collection and purpose;
- consent, contract, license, confidentiality, and disclosure rights;
- authenticity, integrity, custody, signature, or certification;
- required method/accreditation/independence;
- timeliness and procedural requirements;
- personal data, privilege, trade secret, export, jurisdiction, or legal-hold rules;
- gate, audit, regulator, customer, insurer, or contractual evidence requirements.

`EXCLUDED` evidence remains referenced with exclusion reason and material effect unless lawful requirements prohibit even metadata. `QUARANTINED` content cannot enter ordinary decision use pending safety, integrity, access, malware, legal, or authenticity review.

---

# 13. Admissibility Record

~~~yaml
admissibility_decision_id:
evidence_or_set_ref:
intended_context:
applicable_rules: []
scope:
result:
limitations_or_redactions: []
exclusion_or_quarantine_reason:
authority:
reviewers: []
decided_at:
valid_until_or_event:
appeal_or_reconsideration_route:
~~~

Admissibility does not make evidence true or sufficient.

---

# 14. Decision Strength Rule

Evidence supports only the strength justified by its fitness and set sufficiency.

~~~text
informative signal
< supported working claim
< bounded decision
< verified conformance claim
< release authorization evidence
< continuous operational effectiveness claim
~~~

Higher-consequence or broader claims require stronger scope, duration, representativeness, independence, and corroboration. A narrow test cannot justify a broad continuous claim.

---

# 15. Final Fitness Principle

> **Evidence quality is not a badge attached to an item forever: fitness is decided for one claim and use, sufficiency considers every supportive and contradictory item, corroboration discounts shared origins, and admissibility governs whether the decision context may rely on the result at all.**
