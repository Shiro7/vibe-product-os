# Product OS v1.0 — Access, Classification, Privacy, Retention, and Disposal

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-07
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
confidentiality_levels: [PUBLIC, INTERNAL, CONFIDENTIAL, RESTRICTED]
governed_scope: ALL_SOURCE_EVIDENCE_CONTENT_AND_METADATA
~~~

---

# 1. Purpose

This specification protects source/evidence content throughout collection, storage, access, processing, transfer, disclosure, retention, legal hold, archive, redaction, and disposal while preserving enough metadata to govern claims, decisions, contradictions, and change impact.

---

# 2. Confidentiality Classification

The Phase 00 levels are canonical:

~~~text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
~~~

| Level | Normal treatment |
|---|---|
| PUBLIC | Approved for public disclosure within license/attribution/integrity constraints |
| INTERNAL | Available to authorized organizational/project participants; not public by default |
| CONFIDENTIAL | Need-to-know access with controlled storage, sharing, export, and audit |
| RESTRICTED | Highest limited access due to severe harm, secrets, privileged, regulated, security, incident, personal, contractual, or legal sensitivity |

Classification applies per content/field/attachment where needed. A public source may contain confidential annotations; a restricted report may expose a public non-sensitive metadata record.

---

# 3. Sensitive Content Flags

~~~text
PERSONAL_DATA
SENSITIVE_PERSONAL_DATA
CREDENTIAL_OR_SECRET
SECURITY_SENSITIVE
FINANCIAL_OR_PAYMENT
HEALTH_OR_SAFETY
LEGAL_PRIVILEGED
CONTRACT_CONFIDENTIAL
TRADE_SECRET
CUSTOMER_OR_TENANT_DATA
SOURCE_CODE_OR_MODEL_SENSITIVE
INCIDENT_OR_INVESTIGATION
MINOR_OR_VULNERABLE_PERSON
EXPORT_OR_RESIDENCY_CONTROLLED
LICENSE_RESTRICTED
~~~

Flags trigger exact policies; they do not replace classification or data inventory.

---

# 4. Access Decision

~~~yaml
access_policy_ref:
subject_or_role:
source_or_evidence_scope:
permitted_actions: []
purpose:
lawful_contractual_or_governance_basis:
conditions: []
field_or_content_redactions: []
environment_or_location_restrictions: []
valid_from:
valid_until_or_event:
approving_authority:
review_cadence:
revocation_triggers: []
~~~

Actions distinguish discover metadata, view, download, copy, transform, annotate, export, disclose, approve, place on hold, and dispose.

---

# 5. Least Privilege and Segregation

Grant only necessary content/actions/time for the legitimate task. Privileged evidence administration, production, review, approval, and disposal may require separate roles.

Break-glass access records reason, authority or necessity, exact scope, actor, time, actions, evidence, expiry, notification, and retrospective review.

---

# 6. Data Minimization and Purpose Limitation

Collect and retain only information needed for explicit claim/evidence/governance purposes. Before copying content into artifacts:

- prefer stable locator and minimal metadata;
- remove secrets and unnecessary personal fields;
- pseudonymize/anonymize when identity is not material;
- aggregate only when claim remains supportable and re-identification risk is controlled;
- separate raw sensitive evidence from broadly shared summaries;
- prohibit secondary use without compatible purpose and authority.

Evidence convenience does not justify excessive surveillance or data collection.

---

# 7. Secrets

Passwords, API keys, tokens, private keys, session values, recovery codes, signing secrets, and equivalent credentials are not stored in Product OS artifacts or ordinary evidence packs.

Record:

~~~yaml
secret_detection_event_id:
source_or_evidence_ref:
secret_type:
value_stored: false
exposure_scope:
action:
rotation_or_revocation_ref:
incident_or_change_ref:
handled_by:
handled_at:
verification_ref:
~~~

Redaction does not complete incident response; rotation/revocation, history review, notification, and verification may be required.

---

# 8. Redaction

~~~yaml
redaction_event_id:
original_ref:
redacted_derivative_ref:
fields_or_regions_redacted: []
reason_and_authority:
method:
performed_by:
performed_at:
integrity_refs: []
reversibility:
reviewer:
disclosure_scope:
~~~

Redaction preserves original in the authorized store when retention allows. It must not change the apparent meaning without disclosure. Metadata states that content is redacted and whether assessment is limited.

---

# 9. Anonymization and Pseudonymization

Record technique, fields, population, key/linkage custody, re-identification assessment, permitted joins, reviewer, and residual risk.

Pseudonymous data remains personal data when re-linking is possible. “Anonymous” is a reviewed claim, not a label.

---

# 10. Disclosure and Sharing

Before external or wider sharing, confirm:

- recipient identity/authority and purpose;
- contract, consent, license, privilege, regulatory, and jurisdiction restrictions;
- minimum content and appropriate redaction;
- secure transfer and recipient controls;
- onward-sharing and retention restrictions;
- disclosure log and expiry/revocation where feasible;
- incident route for misdelivery or unauthorized access.

Evidence-pack access may differ from gate-decision visibility. A decision can cite restricted evidence without exposing content to unauthorized users.

---

# 11. Retention Schedule

~~~yaml
retention_rule_id:
source_or_evidence_class:
scope:
retention_basis: []
start_event:
minimum_period:
maximum_period_or_review:
archive_requirements:
access_during_retention:
legal_hold_override:
disposal_method:
disposal_approver:
exceptions: []
owner:
review_cadence:
~~~

Retention considers Product OS history, law/regulation, contracts, audit, tax/finance, incidents, security, safety, privacy, employment, customer commitments, intellectual property, model/AI governance, standards, release/support periods, and limitation/dispute windows.

Keeping everything forever is not a valid default.

---

# 12. Legal and Governance Hold

~~~yaml
hold_id:
authority_or_trigger:
reason:
subject_scope:
source_evidence_and_system_refs: []
issued_by:
issued_at:
custodians_notified: []
preservation_actions: []
collection_or_disposal_restrictions: []
access_conditions: []
review_cadence:
release_authority:
released_at:
~~~

A hold suspends conflicting disposal for exact scope. It does not authorize unlimited access or unrelated reuse.

---

# 13. Archive

Archive preserves format readability, metadata, integrity, authenticity, custody, access, encryption/key continuity, search/discovery, migration history, and retention/disposal schedule.

Format or platform migration requires pre/post inventory, checksums or equivalent integrity, access comparison, exception handling, rollback/recovery, and migration evidence.

---

# 14. Disposal

~~~yaml
disposal_event_id:
source_or_evidence_refs: []
retention_rule_ref:
hold_check:
scope:
method:
systems_and_copies_covered: []
backups_or_residual_copies:
performed_by:
authorized_by:
performed_at:
verification_ref:
minimal_metadata_retained:
exceptions_or_failures: []
~~~

Disposal is proportionate to media/system and sensitivity. Deleting a link or database row does not prove content disposal from replicas, exports, caches, backups, or third parties.

---

# 15. Data Subject, Customer, or Authority Requests

Requests for access, correction, restriction, export, deletion, confidentiality, audit, subpoena, discovery, or regulatory review are routed to competent authority. Product OS preserves identity, scope, legal basis, deadline, search systems, decisions, disclosures/redactions, actions, verification, and evidence-impact consequences.

Correcting personal data does not permit rewriting historical evidence secretly; preserve lawful correction history and limit old-data use.

---

# 16. Access Loss and Evidence Fitness

If reviewers cannot access required evidence:

- mark access state and reason;
- determine whether independent authorized review/attestation can supply enough information;
- limit or block fitness/sufficiency/admissibility;
- avoid exposing content to solve a convenience issue;
- assign access resolution owner and due event;
- trigger change impact if existing decisions relied on continued reviewability.

---

# 17. Final Access and Retention Principle

> **Trustworthy evidence must remain available to the right people for the right purpose and period—while secrets, personal data, privileged content, and unnecessary copies remain protected, redacted, held, archived, or verifiably disposed under explicit authority.**
