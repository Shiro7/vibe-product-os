# Product OS v1.0 — Claim and Assertion Model

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-02
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
claim_type_count: 12
information_state_count: 6
governed_scope: ALL_281_ARTIFACTS
~~~

---

# 1. Purpose

This specification defines atomic claim identity, 12 claim types, relation to Product OS information states, assertion authority, extraction, scope/time, confidence, promotion, conflict, aggregation, and lifecycle.

Claims are the bridge between sources and evidence. Evidence cannot be assessed without knowing exactly what it is intended to establish.

---

# 2. Canonical Claim Types

| ID | `claim_type` | Meaning | Example |
|---|---|---|---|
| SEM-CLM-01 | DESCRIPTIVE | States an observable or recorded condition, event, value, identity, or current/past behavior | “The current workflow has four approval steps.” |
| SEM-CLM-02 | INTERPRETIVE | States a finding, classification, theme, diagnosis, or meaning derived from observations | “Users abandon because terminology is unclear.” |
| SEM-CLM-03 | CAUSAL | States that one condition causes or materially contributes to another | “Retry absence caused duplicate failure.” |
| SEM-CLM-04 | PREDICTIVE | Forecasts future behavior, demand, risk, capacity, cost, outcome, or effect | “Peak load will exceed present capacity.” |
| SEM-CLM-05 | ASSUMPTIVE | Temporarily asserts a proposition without sufficient confirmation | “Identity provider will support Arabic names.” |
| SEM-CLM-06 | PREFERENCE_OR_IDEA | Expresses requested, desired, proposed, or optional behavior without authority | “Add biometric login.” |
| SEM-CLM-07 | DECISIONAL | Records an authorized choice, approval, rejection, deferment, condition, or route | “G3A passes for web scope.” |
| SEM-CLM-08 | NORMATIVE_OR_OBLIGATORY | States a requirement, prohibition, rule, control, or applicable obligation | “The service SHALL preserve tenant isolation.” |
| SEM-CLM-09 | CONFORMANCE | Claims alignment with a requirement, standard, policy, control, architecture, or design | “Component conforms to focus-order rules.” |
| SEM-CLM-10 | VERIFICATION | Claims that a method produced a result for an exact target and expectation | “Test T-42 passed candidate digest X.” |
| SEM-CLM-11 | RELEASE_OR_LIVE_STATE | Claims authorization, deployment, configuration, exposure, live identity, or operational state | “Candidate X is deployed to cohort Y.” |
| SEM-CLM-12 | EFFECTIVENESS_OR_OUTCOME | Claims an implemented control/product/service achieved intended effect over a period/population | “Error rate remained below SLO for 30 days.” |

Claim type is separate from source type and information state. One source may contain several claim types.

---

# 3. Information-State Mapping

The existing Product OS information states remain canonical:

~~~text
FACT
ASSUMPTION
REQUESTED_IDEA
DECISION
REQUIREMENT
OPEN_QUESTION
~~~

| Information state | Normal claim types | Required guardrail |
|---|---|---|
| FACT | DESCRIPTIVE, INTERPRETIVE, CAUSAL, PREDICTIVE, CONFORMANCE, VERIFICATION, RELEASE_OR_LIVE_STATE, EFFECTIVENESS_OR_OUTCOME | “Fact” means represented as true by a source/owner; it may still be contradicted, stale, or unverified |
| ASSUMPTION | ASSUMPTIVE and provisional forms of other types | Owner, impact if wrong, validation, due/expiry, affected objects, final disposition |
| REQUESTED_IDEA | PREFERENCE_OR_IDEA | Cannot become scope/requirement without validation and authority |
| DECISION | DECISIONAL | Exact authority, options, rationale, scope, date, conditions, status, and reopen |
| REQUIREMENT | NORMATIVE_OR_OBLIGATORY | Valid origin/authority, atomic normative statement, scope, acceptance, verification, priority, and traceability |
| OPEN_QUESTION | A question about any claim type | Owner, impact, blocking status, due event, answer source, and decision need |

Information state is not truth status, evidence fitness, verification status, confidence, or approval.

---

# 4. Atomic Claim Test

A claim is atomic when it can receive one coherent:

- subject and predicate;
- scope and valid time;
- information state;
- authority requirement;
- support/contradiction set;
- confidence;
- verification/evidence expectation;
- status and disposition.

Split a sentence when clauses can differ in scope, truth, authority, verification, or decision. Preserve the original source segment and their grouping relationship.

---

# 5. Claim Identity

~~~yaml
claim_id:
claim_version:
claim_type:
information_state:
statement:
subject_ref:
predicate:
object_or_value:
units_or_vocabulary:
scope:
valid_from:
valid_until_or_event:
asserted_by:
asserted_at:
canonical_owner:
source_refs: []
source_locators: []
extraction_refs: []
authority_requirement:
confidence:
status:
group_ref:
supersedes_claim_ref:
~~~

A semantic change creates a new claim version. Historical wording and support remain reconstructable.

---

# 6. Extraction Record

~~~yaml
extraction_id:
source_ref:
source_revision:
source_locator:
raw_segment_digest_or_reference:
extracted_claim_refs: []
extraction_method:
extractor:
tool_or_model_identity:
interpretation_notes:
language_and_translation:
context_preserved:
reviewer:
review_status:
extracted_at:
~~~

Translation, transcription, OCR, parsing, summarization, and AI extraction expose method, version, uncertainty, and review. Raw source is not modified.

---

# 7. Scope and Time

Every material claim binds applicable:

- organization/project/product/tenant;
- user/role/population/cohort;
- market/jurisdiction/region/language/platform/channel;
- capability/journey/feature/component/service/API/data/control;
- environment/configuration/candidate/release/live instance;
- evidence or observation period;
- effective and recorded time.

Claims with different time/scope partitions may coexist without contradiction. Missing scope produces uncertainty, not global truth.

---

# 8. Assertion Authority

Different claim types require different authority:

| Claim type | Normal authority need |
|---|---|
| Descriptive observation | Competent source/reviewer and reliable method; not necessarily decision authority |
| Interpretation/causality/prediction | Competent method/domain reviewer and uncertainty disclosure |
| Assumption/idea | Attributable owner; no approval implied |
| Decision | A4 or specifically delegated decision authority for scope |
| Normative obligation | Valid originating authority and canonical artifact approval |
| Conformance/verification | Qualified verifier/reviewer with required independence |
| Release/live state | Release/deployment/operations system plus authorized owner/reconciliation |
| Effectiveness/outcome | Valid measurement method, period, population, guardrails, and outcome authority |

A5 official record can evidence a recorded event, but it cannot make an unauthorized product decision.

---

# 9. Claim Confidence

~~~text
HIGH
MEDIUM
LOW
UNKNOWN
~~~

Confidence considers source clarity, authority, reliability, consistency, corroboration, recency, scope/version fit, contradiction, and evidence quality. Record material dimensions instead of hiding a weak dimension in an average.

Confidence is not probability, truth, approval, verification, AI certainty, or residual-risk acceptance.

---

# 10. Promotion Rules

| Promotion | Required conditions |
|---|---|
| REQUESTED_IDEA → REQUIREMENT | Valid origin, product/scope decision, canonical requirement owner, normative statement, acceptance, verification, priority, and approval |
| ASSUMPTION → FACT | Validating evidence, exact scope/time, competent reviewer, source/canonical claim update, and contradiction disposition |
| OPEN_QUESTION → FACT | Answer supported by source/evidence and claim owner review |
| OPEN_QUESTION → DECISION | Options/context plus valid decision authority and record |
| FACT → REQUIREMENT | A fact alone is insufficient; requires normative authority and requirements engineering |
| VERIFICATION claim → CONFORMANCE claim | Required coverage, method, target, evidence, limitations, and accepting authority |
| RELEASE state → EFFECTIVENESS outcome | Live identity plus representative operational period and outcome method |

Promotion produces a new governed state/version and preserves the earlier object. AI/tooling cannot perform it silently.

---

# 11. Support Relationships

Evidence relates to a claim as:

~~~text
SUPPORTS
CONTRADICTS
LIMITS
ESTABLISHES_PROVENANCE
ESTABLISHES_IDENTITY
ESTABLISHES_EXECUTION
ESTABLISHES_RESULT
INCONCLUSIVE
~~~

One evidence item may have different relationships to different claims. A passing accessibility scan may support selected automated rules while limiting or contradicting a universal accessibility-conformance claim.

---

# 12. Contradiction and Claim Conflict

Claims conflict only when subject, predicate, scope, time, and semantic vocabulary overlap incompatibly.

Conflict handling:

1. preserve each claim and exact sources;
2. normalize vocabulary/units without altering originals;
3. check scope/time/version distinctions;
4. assess authority, reliability, method, integrity, and common origin;
5. collect independent evidence where material;
6. assign canonical owner and resolution authority;
7. record `CONFIRMED`, `PARTIALLY_CONFIRMED`, `CONTRADICTED`, `UNRESOLVED`, or `SUPERSEDED` claim disposition;
8. trigger Change Impact Rules if relied-on truth changes.

Contradictory evidence is never deleted from the decision pack.

---

# 13. Aggregated Claims

Metrics, summaries, dashboards, and reports preserve:

- constituent claims/data sources;
- query/transformation/method version;
- population, filters, exclusions, missingness, sampling, and period;
- unit and aggregation logic;
- uncertainty and limitations;
- drill-down or audit route;
- refresh/freshness behavior.

An aggregate cannot be more authoritative or precise than its method and inputs support.

---

# 14. Claim Lifecycle

~~~text
DRAFT
ASSERTED
UNDER_REVIEW
CURRENT
CONDITIONED
CONTRADICTED
STALE
SUPERSEDED
RETRACTED
RETIRED
~~~

Lifecycle is separate from information state and confidence. Retraction preserves why and by whom; it does not erase the historical assertion.

---

# 15. Claim Exit Criteria

A material claim is fit to enter a baseline/decision pack when:

1. identity, atomic statement, subject, vocabulary, scope, and time resolve;
2. canonical owner and required authority are known;
3. source/extraction lineage is exact;
4. information state and confidence are honest;
5. support, contradiction, limitations, and unknowns are visible;
6. evidence expectation and accepting context are defined;
7. supersession/reopen triggers exist.

---

# 16. Final Claim Principle

> **Product OS does not ask whether a document is true; it asks which atomic claim is asserted, for which scope and time, by what authority, from which exact source, with what support and contradiction, and what decision that support is allowed to justify.**
