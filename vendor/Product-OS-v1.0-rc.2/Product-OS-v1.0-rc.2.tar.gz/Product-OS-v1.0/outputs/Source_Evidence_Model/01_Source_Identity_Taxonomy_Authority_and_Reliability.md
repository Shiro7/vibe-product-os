# Product OS v1.0 — Source Identity, Taxonomy, Authority, and Reliability

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-01
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
source_type_count: 22
source_authority_level_count: 6
source_reliability_level_count: 4
governed_project_artifact: INIT-002
~~~

---

# 1. Purpose

This specification defines canonical source identity, 22 source types, source derivation roles, A0–A5 authority, reliability, lifecycle, freshness, completeness, duplication, correction, contradiction, and source-conflict resolution.

---

# 2. Source Registration Rule

Every source used for a material claim receives a stable `source_id`, even when the content is missing, inaccessible, disputed, or later superseded. Registration records existence and context; it does not approve the source or prove a claim.

Register the smallest source unit with independent identity, revision, authority, access, and retention. A repository, folder, website, meeting series, or telemetry platform may be a collection source while exact files, commits, pages, sessions, queries, or periods receive child identities.

---

# 3. Canonical Source Types

| ID | `source_type` | Definition | Required locator/context |
|---|---|---|---|
| SEM-SRC-01 | HUMAN_STATEMENT | Attributable spoken, written, or signed statement from a person | Person/role, capture method, date, exact quotation/locator, consent or authority context |
| SEM-SRC-02 | MEETING_OR_WORKSHOP_RECORD | Transcript, minutes, recording, board, or structured session output | Session identity, participants, facilitator/recorder, date, recording/minutes revision |
| SEM-SRC-03 | INTERVIEW_OR_RESEARCH_SESSION | User/stakeholder interview, contextual inquiry, diary, focus group, or research session | Participant class, protocol, consent, session, researcher, raw/processed distinction |
| SEM-SRC-04 | SURVEY_OR_FORM_RESPONSE | Structured self-reported responses and metadata | Instrument version, sampling/recruitment, response period, population, anonymization |
| SEM-SRC-05 | OBSERVATION_OR_FIELD_NOTE | Direct observation of behavior, environment, workflow, or event | Observer, method, place/environment, time, subject scope, interpretation separation |
| SEM-SRC-06 | USER_FEEDBACK_OR_SUPPORT | Feedback, complaint, review, support contact, feature request, or usability comment | Channel, user/population context, product/live scope, time, consent/access limits |
| SEM-SRC-07 | ORGANIZATIONAL_POLICY_OR_PROCEDURE | Approved policy, rule, process, manual, control, or internal standard | Issuer, approval, effective period, scope, revision, supersession |
| SEM-SRC-08 | LEGAL_REGULATORY_OR_GOVERNMENT | Law, regulation, court/authority decision, official guidance, permit, or filing | Jurisdiction, issuing authority, authoritative publication, effective/version dates |
| SEM-SRC-09 | CONTRACT_OR_COMMERCIAL_COMMITMENT | Contract, SOW, SLA, license, procurement term, order, or formal commitment | Parties, executed revision, effective/expiry dates, governing scope, access |
| SEM-SRC-10 | STANDARD_OR_ASSURANCE_REFERENCE | Standard, framework, certification criteria, normative specification, or assurance guidance | Publisher, edition/version, normative status, licensed location, applicability decision |
| SEM-SRC-11 | BUSINESS_OR_ADMINISTRATIVE_RECORD | Transaction, register, master data, financial, HR, audit, inventory, case, or operational business record | System of record, record ID, period, owner, extraction/query, data quality |
| SEM-SRC-12 | PRODUCT_ANALYTICS_OR_RESEARCH_DATASET | Analytics events, experiments, datasets, survey aggregates, research repository, or behavioral measure | Schema/instrument, population, query, filters, period, exclusions, data lineage |
| SEM-SRC-13 | DESIGN_SOURCE | Figma/design file, prototype, token library, asset, content model, or generated-document design source | File/node/version, library, branch, export identity, owner, approval state |
| SEM-SRC-14 | CODE_OR_CONFIGURATION_REPOSITORY | Code, infrastructure, policy-as-code, configuration, model, prompt, migration, or build source | Repository, path, commit/digest, branch/tag, dependency lock, signing context |
| SEM-SRC-15 | TECHNICAL_SPEC_SCHEMA_OR_DIAGRAM | API/async/data contract, ERD, architecture diagram, ADR, schema, interface docs, or technical specification | Canonical system, object/version, generator if any, owner, effective scope |
| SEM-SRC-16 | WORK_ITEM_CHANGE_OR_INCIDENT_RECORD | Ticket, backlog item, change, defect, finding, incident, problem, exception, or decision record | System/object ID, status history, owner, affected scope, correlation links |
| SEM-SRC-17 | TEST_SCAN_REVIEW_OR_REPORT | Test output, scan, inspection, review, audit report, benchmark, or validation document as source material | Tool/method/version, target, run/review ID, environment, time, raw result locator |
| SEM-SRC-18 | RUNTIME_TELEMETRY_OR_OPERATIONAL_EVENT | Logs, metrics, traces, alerts, SLO data, deployment/runtime events, or operational observations | Query, service/target, environment, period, timezone, sampling, retention |
| SEM-SRC-19 | EXTERNAL_PUBLICATION_OR_WEB_RESOURCE | Research, market report, article, vendor docs, public dataset, website, or publication | Publisher/author, title, URL/identifier, version/date, capture/archive, license |
| SEM-SRC-20 | THIRD_PARTY_ATTESTATION_OR_DELIVERABLE | Supplier assertion, certificate, audit, pen test, SOC report, compliance response, or delivered artifact | Issuer, subject, scope, period, method, qualifications, contractual rights |
| SEM-SRC-21 | MACHINE_GENERATED_OUTPUT | Deterministic generated report, export, compiled artifact, transformed dataset, or automated summary | Generator/version, inputs, configuration, run ID, transform lineage, integrity |
| SEM-SRC-22 | AI_GENERATED_OR_ASSISTED_OUTPUT | Probabilistic model output, extraction, classification, summary, analysis, synthetic content, or recommendation | Model/system/version, prompt/context/input refs, generation settings, time, reviewer status |

One primary type identifies the source’s direct form. Qualifiers may capture channel, format, domain, and subtype. Do not invent synonyms that break exchange.

---

# 4. Source Derivation Role

~~~text
ORIGINAL
TRANSCRIBED
EXTRACTED
TRANSFORMED
AGGREGATED
DERIVED
SYNTHETIC
~~~

| Role | Meaning |
|---|---|
| ORIGINAL | First governed capture available from the producing person/system/event |
| TRANSCRIBED | Format conversion intended to preserve semantic content |
| EXTRACTED | Selected subset copied from a larger source with locator and context |
| TRANSFORMED | Content changed by documented deterministic normalization/conversion |
| AGGREGATED | Multiple records summarized or calculated into a combined dataset/result |
| DERIVED | New interpretation, metric, report, or conclusion produced from upstream sources |
| SYNTHETIC | Artificially generated data/content intended to simulate, augment, or test rather than record real events |

Original does not mean authoritative or reliable. Derived does not mean invalid. Each role carries its provenance and method.

---

# 5. Canonical Identity

Source identity is determined by:

- producing person/system/authority;
- external or native object identity;
- source type and derivation role;
- exact revision, capture event, query/run, or evidence period;
- canonical location and collection context;
- integrity reference where required;
- scope and access partition.

A changed content digest, executed contract revision, repository commit, Figma version, telemetry query/period, meeting session, or AI generation creates a new source revision or source identity according to native semantics. Corrections never overwrite received history.

---

# 6. Authority Levels

The Phase 00 A0–A5 model is canonical:

| Level | Name | Meaning |
|---|---|---|
| A0 | UNKNOWN | Authority cannot yet be established |
| A1 | INFORMAL | Personal, exploratory, unofficial, or non-authoritative input |
| A2 | DOMAIN_INFORMED | Relevant experience or knowledge without formal domain decision authority |
| A3 | DOMAIN_AUTHORITY | Recognized authority to state or interpret truth within a defined domain/scope |
| A4 | DECISION_AUTHORITY | Authorized to make/approve a defined decision for exact scope and time |
| A5 | AUTHORITATIVE_RECORD | Official record/system/publication designated as canonical evidence of the recorded matter |

Authority binds:

~~~yaml
level:
domain:
claim_or_action_types: []
scope:
jurisdiction_or_organization:
effective_from:
effective_until_or_event:
delegation_or_appointment_ref:
rationale:
reviewer:
~~~

Rules:

1. A5 for a recorded transaction does not grant decision authority over product strategy.
2. A4 to approve policy does not imply reliable knowledge of every operational detail.
3. A3 expertise is domain-bound.
4. A0 is an explicit unknown, not low authority and not N/A.
5. Authority may differ by claim/action and scope within one source.
6. External law, contract, and standards authority still requires project applicability interpretation through competent owners and GOV-009 where relevant.

---

# 7. Reliability Levels

~~~text
HIGH
MEDIUM
LOW
UNKNOWN
~~~

Assess reliability independently across:

- producer competence and proximity to the observed matter;
- method suitability and repeatability;
- internal consistency;
- source-system control and data quality;
- corroboration and common-origin risk;
- completeness and known exclusions;
- recency/period fit;
- observed correction/error history;
- incentives, bias, conflict of interest, and limitations;
- authenticity and integrity confidence.

| Level | Meaning |
|---|---|
| HIGH | Strong competence/method/control, internally consistent, current for use, and corroborated where material with no unresolved defeating limitation |
| MEDIUM | Credible and usable with bounded non-critical gaps, limited corroboration, or known manageable limitations |
| LOW | Material method, competence, bias, consistency, completeness, freshness, integrity, or corroboration weakness |
| UNKNOWN | Insufficient review or access to judge responsibly |

Reliability is not truth, authority, approval, confidence, evidence fitness, or admissibility.

---

# 8. Freshness

~~~text
CURRENT
CURRENT_WITH_LIMITATIONS
STALE
EXPIRED
UNKNOWN
NOT_TIME_SENSITIVE
~~~

Freshness compares source date/period and last material change to the claim/use’s required horizon. `NOT_TIME_SENSITIVE` requires rationale; it is not a permanent exemption from version or authority change.

Every freshness rule records threshold or trigger, owner, assessment date, next review, and consequence.

---

# 9. Completeness

~~~text
COMPLETE_FOR_STATED_SCOPE
PARTIAL_WITH_KNOWN_GAPS
TRUNCATED
MISSING_CONTEXT
UNKNOWN
~~~

Completeness applies to the intended source capture, not universal knowledge. A partial source may remain useful when gaps and prohibited claims are explicit.

---

# 10. Access Status

~~~text
ACCESSIBLE
ACCESSIBLE_WITH_RESTRICTIONS
TEMPORARILY_UNAVAILABLE
INACCESSIBLE
MISSING
DESTROYED_OR_LOST
~~~

Inaccessible or missing source existence remains registered. Its content cannot be inferred or summarized as reviewed.

---

# 11. Source Lifecycle

~~~text
REGISTERED
ACTIVE
REVIEW_REQUIRED
STALE
SUPERSEDED
INACCESSIBLE
RETIRED
~~~

Lifecycle is separate from authority, reliability, freshness, completeness, and access. `RETIRED` preserves history and retention obligations.

---

# 12. Duplicate, Correction, Contradiction, and Supersession

| Relationship | Use when | Rule |
|---|---|---|
| DUPLICATE_OF | Same source object/content is registered twice | Preserve intake audit; select canonical identity |
| TRANSCRIPTION_OF | One source renders another without intended meaning change | Preserve raw source and transcription method/review |
| EXTRACTED_FROM | Subset is selected from a parent | Preserve exact locator and surrounding context |
| DERIVED_FROM | New content/result uses upstream sources | Preserve transformation/method and all material inputs |
| CORRECTS | Later source explicitly corrects earlier recorded content | Preserve both; route affected claims/change impact |
| CONTRADICTS | Sources assert incompatible claims for overlapping scope/time | Preserve conflict and route assessment |
| SUPERSEDES | New version becomes current authority for future use | Preserve old effective period and dependents |

Supersession does not prove the old source was false for its historical period.

---

# 13. Source Conflict Resolution

Resolve source conflict by:

1. confirming identity, version, scope, time, and terminology;
2. distinguishing authority from reliability and observation from decision;
3. checking common-origin and circular citation;
4. examining raw material, method, completeness, bias, and integrity;
5. obtaining competent domain review or additional independent sources;
6. preserving dissent and uncertainty;
7. issuing a claim/decision disposition with valid authority;
8. updating traceability and Change Impact Rules where relied-on meaning changes.

Higher authority does not erase reliable contradictory operational observation. It decides only within its defined action scope.

---

# 14. Source Verification

Verify that:

- identity and revision resolve;
- the content captured matches the native source or records transformation;
- origin and producer are attributable where required;
- authority/reliability/freshness/completeness are reviewed for intended use;
- access, sensitive-data, consent/license, and retention controls apply;
- correction/supersession/conflict history is intact;
- extracted claims link to exact locators;
- AI or machine generation is disclosed.

---

# 15. Final Source Principle

> **The safest source register does not rank documents by appearance or people by title; it preserves exact origin and revision, then judges authority, reliability, freshness, scope, access, and contradiction as separate questions for the specific claim being made.**
