# Product OS v1.0 — Provenance, Custody, Integrity, Versioning, and Invalidation

~~~yaml
document_id: FRAMEWORK-SOURCE-EVIDENCE-06
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-SOURCE-EVIDENCE-CONTRACT@0.1.0
governed_scope: ALL_MATERIAL_SOURCE_EVIDENCE_HISTORY
~~~

---

# 1. Purpose

This specification preserves the reconstructable history of sources and evidence: origin, acquisition, transformation, attribution, custody, authenticity, integrity, versioning, temporal validity, correction, supersession, expiry, invalidation, and replacement.

---

# 2. Provenance Model

Provenance answers:

- who/what originated the material;
- who/what captured it and under which context;
- which version, query, configuration, prompt, model, method, or instrument produced it;
- which upstream inputs and transformations contributed;
- what changed between stages;
- who reviewed and accepted the transformation;
- where canonical content and each governed copy reside;
- which claim/evidence/decision uses depend on it.

~~~yaml
provenance_record_id:
subject_ref:
origin_ref:
origin_actor_or_system:
origin_time:
acquisition_method:
acquired_by:
acquired_at:
upstream_refs: []
transformation_events: []
tool_model_method_versions: []
source_and_target_digests: []
review_events: []
canonical_location:
derived_locations: []
claim_and_evidence_uses: []
~~~

---

# 3. Transformation Event

~~~yaml
transformation_event_id:
input_refs: []
input_revisions: []
operation:
method_or_code_ref:
tool_or_model_identity:
configuration_or_prompt_ref:
performed_by:
performed_at:
output_ref:
output_revision:
semantic_change_intended:
lossiness:
normalization_or_filtering:
errors_or_warnings: []
integrity_before_after: []
reviewer:
~~~

OCR, translation, transcription, anonymization, redaction, aggregation, sampling, query, export, compression, image conversion, model summarization, and report generation are transformations. Each discloses loss or uncertainty.

---

# 4. Chain of Custody

Custody is required when evidence consequence, law/contract/standard, security incident, audit, dispute, regulated data, formal assurance, or P3 treatment requires proof of possession and handling.

~~~yaml
custody_event_id:
evidence_or_source_ref:
event_type:
from_custodian:
to_custodian:
from_location:
to_location:
access_or_container_identity:
content_digest_or_seal:
purpose:
authorized_by:
occurred_at:
received_confirmed_at:
exceptions_or_damage: []
signature_or_audit_ref:
~~~

Custody event types:

~~~text
CAPTURED
RECEIVED
TRANSFERRED
COPIED
ACCESSED
EXPORTED
TRANSFORMED
SEALED
UNSEALED
REDACTED
ARCHIVED
PLACED_ON_HOLD
RELEASED_FROM_HOLD
DISPOSED
LOST_OR_COMPROMISED
~~~

---

# 5. Integrity and Authenticity

Integrity asks whether content/result remained unchanged from a known state. Authenticity asks whether it is what it claims to be and attributable to the claimed origin.

Possible mechanisms:

- native immutable/audited record ID;
- cryptographic digest and manifest;
- digital signature, certificate, timestamp, or notarization;
- signed commit/tag/build/provenance attestation;
- append-only event/audit log;
- write-once or version-retaining repository;
- controlled export plus independent receipt verification;
- witnessed/manual custody for physical/unique evidence.

An unverified hash proves equality only to the hashed bytes; it does not prove origin, truth, method correctness, or lawful collection.

---

# 6. Integrity Reference

~~~yaml
integrity_ref_id:
subject_ref:
mechanism:
algorithm_or_scheme:
digest_signature_or_native_id:
signer_or_issuer:
certificate_or_key_ref:
timestamp_authority_or_system_time:
verified_by:
verified_at:
verification_result:
coverage:
limitations: []
~~~

Credentials, secret keys, or sensitive signing material are never copied into the record.

---

# 7. Time Model

Preserve:

- source/observation/production time;
- evidence period;
- valid/effective time of the claim/source/decision;
- capture/registration time;
- review/acceptance time;
- system-recorded time;
- expiry/review event;
- custody and transformation times;
- timezone and clock source where material.

Late registration does not pretend the material was governed earlier. Backfilled records state original event time and discovery/registration time separately.

---

# 8. Versioning

Use immutable version identities for:

- source revisions/captures;
- claims and canonical artifacts;
- methods, criteria, tools, models, prompts/configurations;
- target/candidate/configuration/environment/schema/data;
- evidence content/results and packs;
- fitness/sufficiency/admissibility decisions;
- standards/obligations and authority/delegation;
- retention/access policies.

Mutable “latest” locators may aid discovery but cannot substitute for decision-bound version identity.

---

# 9. Correction

Correction preserves:

~~~yaml
correction_event_id:
subject_ref:
incorrect_revision_ref:
corrected_revision_ref:
error_description:
reason:
detected_by:
detected_at:
corrected_by:
authority:
affected_claims_evidence_decisions: []
change_impact_ref:
notification_refs: []
~~~

Correct metadata without changing native result semantics only through append-only correction. A changed result creates new evidence and explicit invalidation/supersession.

---

# 10. Freshness, Expiry, and Validity

Validity may end by:

- date/time or evidence-period end;
- new source/revision/standard/method;
- target/candidate/configuration/environment/data change;
- scope/population/platform/locale expansion;
- condition/exception/waiver/authority expiry;
- incident/finding/contradiction;
- integrity/custody/access compromise;
- retention/disposal event;
- scheduled review failure;
- claim/decision supersession.

Expiry does not mean the historical evidence was false. It prevents unqualified current reliance.

---

# 11. Invalidation

~~~yaml
invalidation_event_id:
evidence_or_source_ref:
affected_claim_uses: []
trigger_ref:
reason:
affected_scope:
unaffected_scope:
prior_status_or_fitness:
new_status_or_fitness:
decision_authority:
effective_at:
replacement_required:
replacement_owner:
due_event:
affected_gate_release_live_refs: []
notifications: []
change_ref:
~~~

Invalidation is scope-bound. Preserve unaffected partitions only with positive equivalence and review.

---

# 12. Invalidation Propagation

~~~text
source/evidence integrity, authority, method, target, or validity changes
→ identify claims SUPPORTED_BY / EVIDENCED_BY item
→ identify decisions, baselines, gates, verification, release, live, compliance, and outcome claims relying on them
→ mark REVIEW_REQUIRED / STALE / INVALIDATED as owned by each state dimension
→ create GOV-007 impact assessment
→ replace, reverify, rebaseline, constrain, roll back, or otherwise disposition
→ acknowledge downstream effect and preserve history
~~~

The graph discovers candidate dependents. Change Impact Rules decides material effect and action.

---

# 13. Supersession

Supersession requires a current successor appropriate for stated use. Record predecessor/successor IDs, effective scope/time, migration of claim uses, unresolved consumers, historical retention, and authority.

Newer is not automatically better or broader. Evidence from distinct periods may coexist rather than supersede.

---

# 14. Loss or Compromise

On missing, corrupted, altered, leaked, unauthenticated, or custody-compromised material:

1. preserve the detection event and known metadata;
2. prevent unsupported reliance;
3. classify security/privacy/legal/operational consequences;
4. activate incident and Change Impact Rules as applicable;
5. identify affected claims, decisions, people, systems, and disclosures;
6. recover from verified copies or regenerate evidence without pretending equivalence;
7. notify authorities/owners within required windows;
8. record residual uncertainty and future controls.

---

# 15. Provenance Exit Criteria

Provenance/custody is sufficient for intended use when origin, acquisition, transformations, versions, time, canonical location, integrity/authenticity method, custody events, access, review, and dependent claim uses are reconstructable to the strength required by the accepting context.

---

# 16. Final Provenance Principle

> **Evidence remains trustworthy through time only when Product OS can reconstruct what it was, who produced and handled it, which transformations occurred, which bytes/result/version were reviewed, when validity changed, and which claims and decisions lost support as a consequence.**
