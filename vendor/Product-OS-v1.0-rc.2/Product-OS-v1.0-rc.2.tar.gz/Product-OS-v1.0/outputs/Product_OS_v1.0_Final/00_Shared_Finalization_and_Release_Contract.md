# Product OS v1.0 — Shared Finalization and Release Contract

~~~yaml
contract_id: SHARED-PRODUCT-OS-FINALIZATION-RELEASE-CONTRACT
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
applies_to: PRODUCT_OS_V1_FINALIZATION_DISTRIBUTION_PROMOTION_AND_BASELINE
automation_authority: NONE
~~~

# 1. Purpose

This contract governs every Product OS finalization, release candidate, approved release, distribution, baseline, patch, migration, and retirement action. A specialized process may add controls but cannot weaken exact identity, reproducibility, integrity, authority, evidence, compatibility, recovery, or retained-history requirements.

# 2. Release Identity

Every candidate or release declares:

- product name and semantic version;
- candidate/build identity;
- complete component catalog;
- exact source manifest and archive digest;
- compatibility matrix;
- acceptance criteria and verification report;
- pilot and retained-failure evidence;
- baseline candidate/record;
- authority decision and conditions;
- distribution, support, change, and retirement owners.

Human-friendly filenames are not sufficient identity. The archive, manifest, build-report, baseline-candidate, and authority-packet SHA-256 values bind the reviewed bytes. Generated decision packets must validate against their schemas before authority review.

# 3. Source and Distribution Boundary

Canonical source remains the governed Product OS output set at the reviewed revision. A distribution is a deterministic, immutable snapshot of that source plus an embedded release manifest. The distribution does not become a competing editable source. Changes are made in canonical source, reviewed, and released as a new version.

# 4. Technical Finalization

Technical finalization may:

- inventory components/files;
- validate syntax, schemas, links, counts, tests, and evidence;
- build deterministic archives;
- calculate and verify digests;
- evaluate deterministic and assisted completeness criteria;
- prepare baseline and authority packets;
- recommend technical PASS/HOLD.

It may not approve, sign, accept risk, waive conditions, establish a baseline, or authorize distribution as final.

# 5. Authority Decision

Only an identified Product OS Authority may select:

1. approve v1.0 and establish baseline;
2. approve with conditions;
3. require additional real-project pilot;
4. hold for remediation;
5. reject the candidate.

Approval with conditions requires condition ID, owner, due date, verification method, evidence, restriction, and reopen trigger. Risk acceptance requires a separate governed reference.

# 6. Baseline Establishment

A baseline exists only when the approved decision records exact release version, manifest digest, archive digest, effective time, authority, conditions, accepted risks, supersession, retention, and reopen triggers. A `CANDIDATE` file or green audit is not a baseline.

# 7. Reproducibility

The same source bytes, safe NFC paths in UTF-8 bytewise POSIX order, normalized modes, fixed archive timestamp/ownership, embedded manifest, POSIX ustar encoding, and canonical stored-DEFLATE gzip shall reproduce the same archive bytes. The builder performs two independent source scans, reads, manifests, and archive builds; Final audit performs another rebuild. Any differing byte blocks promotion.

# 8. Change after Review

Any source, document, catalog, schema, script, pilot evidence, decision packet, compatibility statement, or release process change after the final audit invalidates the candidate evidence. Rebuild, re-audit, and rebind authority to the new digest.

# 9. Distribution and Installation

Only the approved archive/digest pair may be labeled `1.0.0`. Recipients verify SHA-256 before extraction, retain the manifest, use a new target, reject path traversal/symlinks, and pin the framework version in projects. Installation must not auto-create projects or modify native tools.

# 10. Support and Security

The release declares owners for support, vulnerabilities, compatibility, changes, evidence, and deprecation. Security reports are triaged without publishing sensitive details. Compromised or incorrectly signed distributions are revoked and replaced through an incident and release process.

# 11. Acceptance

Technical closure requires FAC-001..029 PASS. Final release closure additionally requires FAC-030 through an authority decision bound to exact verified bytes.
