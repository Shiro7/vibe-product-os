# Product OS v1.0 — Final Verification, Release, and Handoff Runbook

~~~yaml
document_id: PRODUCT-OS-V1-FINAL-VERIFICATION-RELEASE-HANDOFF
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
builder_ref: scripts/build-release.js
auditor_ref: scripts/audit-final.js
authority_packet_ref: releases/Product-OS-v1.0-rc.2/authority-decision-packet.json
~~~

# 1. Preflight

1. Confirm all source workstreams report technical PASS.
2. Confirm Automation tests/audit and Pilot audit pass.
3. Confirm final catalogs/templates/schemas/documents and all six scripts are complete.
4. Confirm release target and verification report do not exist.
5. Confirm no source change is pending during build/audit.
6. Confirm Product OS Authority and review route are identified before promotion.

# 2. Build Candidate

~~~bash
node outputs/Product_OS_v1.0_Final/scripts/build-release.js --release-id Product-OS-v1.0-rc.2
~~~

The pure-Node builder scans and reads all Product OS sources twice except generated `releases/` and `verification/`, requires byte-identical manifests and archives, validates the generated packets, and atomically creates six files in a new-only release root: archive, manifest, build report, baseline candidate, authority packet, and checksums.

# 3. Audit Candidate

~~~bash
node outputs/Product_OS_v1.0_Final/scripts/audit-final.js --release-id Product-OS-v1.0-rc.2 --write-report
node outputs/Product_OS_v1.0_Final/scripts/audit-binary.js --release-id Product-OS-v1.0-rc.2 --write-report
node outputs/Product_OS_v1.0_Final/scripts/audit-adversarial.js --release-id Product-OS-v1.0-rc.2 --write-report
node outputs/Product_OS_v1.0_Final/scripts/audit-expert.js --release-id Product-OS-v1.0-rc.2 --write-report
~~~

Final verifies acceptance and independently rebuilds; Binary parses canonical gzip/ustar and verifies every payload; Adversarial proves unsafe, tampered, unpinned, or overwrite attempts fail closed; Expert closes the prior rc.1 blockers and decides only technical authority readiness. All reports are new-only under `verification/rc.2/`.

# 4. Freeze

After audit, freeze source or record the exact revision. Any source byte change invalidates the manifest/audit and requires a new candidate. Do not patch an archive or edit checksums manually.

# 5. Authority Review

Provide the decision packet inputs and exact archive/manifest digests. Authority records one allowed decision, rationale, conditions, risk references, identity, time, and approval/signature. FAC-030 remains pending until this occurs.

# 6. Promote

If approved:

1. bind the exact candidate archive/manifest SHA-256 as v1.0;
2. establish the baseline record and effective time;
3. record conditions/accepted risks/support owners;
4. produce approved release notes and channel metadata;
5. publish archive, checksum, manifest, decision/baseline, compatibility, migration, and non-claims;
6. verify the published copy matches approved bytes.

Approval with a byte change requires rebuild and re-audit before promotion.

# 7. Handoff Package

Recipients receive:

- approved archive and checksums;
- release manifest and baseline/decision;
- Finalization Index and Closure Review;
- compatibility and migration guidance;
- operations/support/security/incident guidance;
- limitations and conditions;
- Automation install/use and Pilot evidence references;
- owner/contact/escalation assignments.

# 8. Allowed and Prohibited Recipient Actions

Allowed: verify, extract to a new root, review, pin in a project, initialize through dry-run/apply, and perform Phase 00 decisions.

Prohibited: edit the release archive, claim approval without decision/baseline, auto-create all artifacts, reuse synthetic facts, bypass applicability/gates, or enable remote/native writes without separate authority.

# 9. Post-Release Verification

Confirm download digest, extraction manifest, installed framework lock, support route, security route, first adopter readiness, and restoration of the archived distribution. Record any discrepancy as an incident/change.

# 10. Reopen Triggers

Archive mismatch, manifest failure, invalid approval identity, unmet condition, security issue, artifact/gate/schema/command change, pilot escape defect, compatibility failure, or required additional pilot reopens finalization and invalidates promotion until resolved.
