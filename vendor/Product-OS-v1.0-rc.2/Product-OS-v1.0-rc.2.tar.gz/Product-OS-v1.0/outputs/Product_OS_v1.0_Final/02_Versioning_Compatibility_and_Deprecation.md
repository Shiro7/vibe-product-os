# Product OS v1.0 — Versioning, Compatibility, and Deprecation

~~~yaml
document_id: PRODUCT-OS-V1-VERSION-COMPATIBILITY-DEPRECATION
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
compatibility_matrix_ref: config/compatibility-matrix.json
compatibility_entry_count: 13
~~~

# 1. Version Axes

Product OS release, phase documents, component libraries, schemas, catalogs, commands, pilot definitions, and project framework locks have distinct versions. The release catalog and manifest bind the compatible set. Equality between every internal document version is neither required nor implied.

# 2. Release Semantics

- `1.0.0-rc.1`: retained immutable candidate that failed expert promotion review and is not eligible for silent replacement.
- `1.0.0-rc.2`: remediated exact candidate, subject to Final, Binary, Adversarial, and Expert audits, authority pending.
- `1.0.0`: approved/baselined release using authority-bound exact candidate bytes or an explicitly rebuilt/re-audited candidate.
- `1.0.x`: compatible corrections that do not change authority, required fields, defaults, artifact IDs, gate meaning, profile meaning, or migration semantics.
- `1.x.0`: backward-compatible optional capabilities, schemas, commands, or conditional modules.
- `x.0.0`: breaking changes to identity, obligations, authority, schemas, catalogs, defaults, profiles, gates, repository contract, or command behavior.

# 3. Internal Document Versions

Phase 00–03 remain document v1.1 because they received GOV-009 housekeeping; Phase 04–11 remain v1.0. The release manifest preserves exact bytes and names. Product OS `1.0.0` is the distribution version, not a forced rewrite of this intentional document history.

# 4. Compatibility Rules

- 281 artifact IDs remain stable.
- P1/P2/P3 preserve logical semantics across packaging differences.
- Schema/canonical command majors must match the supported matrix.
- JSON/YAML parsing remains fail-closed on ambiguity.
- Native-tool mappings remain logical until an adapter is separately versioned and authorized.
- A project pins the framework release and catalog/schema digests.
- A candidate may be evaluated without migrating a project; project adoption follows the migration contract.

# 5. Breaking Changes

The following require a major or explicit compatibility/migration decision:

- add/retire/repurpose artifact or gate identity;
- weaken authority, evidence, applicability, N/A, risk, or change rules;
- reinterpret a profile as reduced obligation;
- change schema required fields or accepted meaning incompatibly;
- change command exit meaning, default mutation, or safety boundary;
- change repository canonical ownership or native-tool source of truth;
- remove access, retention, provenance, or audit obligations.

# 6. Deprecation

Deprecation records subject, replacement, announcement version, detection, compatibility window, migration, support end, removal version, evidence, and authority. Deprecated elements remain testable until removal. Silent aliases or reused IDs are prohibited.

# 7. Support Window

The final authority assigns the supported lifetime and maintenance owner. Until assigned, this release candidate is evaluation-only. No implied long-term support, security response time, or compatibility duration is created by publication of the files.

# 8. Candidate-to-Final Compatibility

If authority approves the exact `rc.2` subject digests without source change, those bytes may be promoted and the decision/baseline records bind them as `1.0.0`. Any byte change requires a new candidate suffix, rebuild, all four audits, and a new decision. `rc.1` remains retained evidence and is never overwritten by `rc.2`.
