# Product OS v1.0 — Baseline Candidate and Authority Decision

~~~yaml
document_id: PRODUCT-OS-V1-BASELINE-AUTHORITY
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
baseline_candidate_template_ref: config/baseline-candidate.template.json
authority_packet_template_ref: config/authority-decision-packet.template.json
generated_baseline_candidate_ref: releases/Product-OS-v1.0-rc.2/baseline-candidate.json
generated_authority_packet_ref: releases/Product-OS-v1.0-rc.2/authority-decision-packet.json
authority_decision_status: PENDING
baseline_established: false
~~~

# 1. Baseline Candidate

`PRODUCT-OS-V1.0-BASELINE-CANDIDATE-002` is generated only after the archive, manifest, and build report bytes exist. It identifies the complete reviewed scope and binds their exact digest and size, the aggregate source identity, component catalog, compatibility matrix, four technical audits, passing pilot evidence, and retained failed pilot evidence.

The candidate intentionally contains null authority, decision time, effective time, and baseline digest. Those values are not missing authoring; they represent authority actions that have not occurred.

# 2. Authority Review Inputs

The authority reviews:

- Finalization Index and Closure Review;
- Final, Binary, Adversarial, and Expert audit reports and all FAC results;
- release manifest/build report/archive digest;
- compatibility matrix;
- baseline candidate;
- Pilot Closure, failed Run-001, and passing Run-002;
- known limitations and remaining risks;
- migration, support, security, retention, and handoff contracts.

# 3. Allowed Decisions

| Decision | Effect |
|---|---|
| `APPROVE_V1_0_AND_ESTABLISH_BASELINE` | Bind exact archive/manifest digest as Product OS v1.0 |
| `APPROVE_WITH_CONDITIONS` | Approve with explicit restrictions and governed conditions |
| `REQUIRE_ADDITIONAL_REAL_PROJECT_PILOT` | Keep candidate unbaselined until required evidence passes |
| `HOLD_FOR_REMEDIATION` | Block promotion pending specified correction and re-audit |
| `REJECT_RELEASE_CANDIDATE` | Reject rc.2; successor candidate requires new identity |

# 4. Approval with Conditions

Every condition must include ID, statement, owner, authority, due date, scope restriction, verification method, evidence reference, status, failure effect, and reopen trigger. A condition cannot silently waive a safety, authority, evidence, or legal obligation.

# 5. Risk Acceptance

Known limitations are not automatically accepted risks. Each accepted residual risk requires a governed risk reference, accountable authority, rationale, scope, duration, mitigations, monitoring, and reopen/escalation conditions.

# 6. Signature and Binding

The decision packet records authority identity and an approval/signature record appropriate to the organization. It must bind:

~~~text
Product OS 1.0.0
+ release manifest SHA-256
+ distribution archive SHA-256
+ release build-report SHA-256
+ aggregate source identity SHA-256
+ baseline candidate ID
+ baseline candidate SHA-256
+ decision ID and timestamp
+ conditions and accepted-risk references
~~~

# 7. Promotion

After approval, create an immutable baseline record or approved revision of the candidate without altering the reviewed source archive. Populate authority, decision, effective time, baseline digest, conditions, risk references, supersession, and retention. Publish only through the authorized channel.

# 8. Current Decision

The current technical result recommends final authority review. It does not select an allowed decision. FAC-030 remains `PENDING_AUTHORITY`.
