#!/usr/bin/env node
'use strict';

const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const { compareUtf8Path, inspectCanonicalGzip, parseUstar } = require('./release-format');
const { SchemaValidator } = require('../../Automation_Commands/lib/schema-validator');

const releaseId = 'Product-OS-v1.0-rc.2';
const finalRoot = path.resolve(__dirname, '..');
const releaseRoot = path.join(finalRoot, 'releases', releaseId);
const verificationRoot = path.join(finalRoot, 'verification', 'rc.2');
const reportFile = path.join(verificationRoot, 'expert-audit-report.json');
const rc1Digests = {
  'Product-OS-v1.0-rc.1.tar.gz': '58425470e9a3e2873d976cee38fd1891bd8a6929d873269bd58d1b64e457f9c9',
  'SHA256SUMS': '947d5daf3156f446737a380407077ac41182358875c28b7261d2dbf833c79a8f',
  'release-build-report.json': '26f2f6d69ea19aeb278bad42105ec4d3359a823bdf95dd9419f5d14353a88e84',
  'release-manifest.json': 'e885015b72361b89ebfbec2c6a14250f8f4d8065db4f714905f67ab01e61febe'
};

function parseArgs(argv) {
  let selected = releaseId;
  let writeReport = false;
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--release-id') { if (!argv[index + 1]) throw new Error('--release-id requires a value.'); selected = argv[index + 1]; index += 1; }
    else if (argv[index] === '--write-report') writeReport = true;
    else if (argv[index] === '--help') { process.stdout.write(`Usage: node scripts/audit-expert.js [--release-id ${releaseId}] [--write-report]\n`); process.exit(0); }
    else throw new Error(`Unknown expert-audit option ${argv[index]}.`);
  }
  if (selected !== releaseId) throw new Error(`This audit is pinned to ${releaseId}.`);
  return { writeReport };
}

function sha256(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function load(file) { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function releaseBytes(name) { return fs.readFileSync(path.join(releaseRoot, name)); }
function validate(schema, value) {
  const validator = new SchemaValidator(new Map([[schema.$id, schema]]));
  return validator.validate(schema, value, schema);
}

function main() {
  const { writeReport } = parseArgs(process.argv.slice(2));
  const finalAudit = load(path.join(verificationRoot, 'final-audit-report.json'));
  const binaryAudit = load(path.join(verificationRoot, 'binary-audit-report.json'));
  const adversarialAudit = load(path.join(verificationRoot, 'adversarial-audit-report.json'));
  assert.strictEqual(finalAudit.technical_result, 'PASS_WITH_AUTHORITY_PENDING');
  assert.strictEqual(finalAudit.criteria_passed, 29);
  assert.strictEqual(finalAudit.criteria_pending_authority, 1);
  assert.strictEqual(finalAudit.criteria_failed, 0);
  assert.strictEqual(binaryAudit.technical_result, 'PASS');
  assert.strictEqual(adversarialAudit.technical_result, 'PASS');
  assert.strictEqual(adversarialAudit.tests_passed, 20);

  const builderSource = fs.readFileSync(path.join(finalRoot, 'scripts', 'build-release.js'), 'utf8');
  const formatSource = fs.readFileSync(path.join(finalRoot, 'scripts', 'release-format.js'), 'utf8');
  assert.ok(!builderSource.includes('localeCompare'), 'Builder still uses locale-sensitive sorting.');
  assert.ok(!builderSource.includes("require('child_process')"), 'Builder still invokes an external process.');
  assert.ok(formatSource.includes('Buffer.compare'), 'Bytewise comparator is absent.');
  assert.ok(formatSource.includes('CANONICAL') || formatSource.includes('createCanonicalGzip'));

  const toolchain = load(path.join(finalRoot, 'config', 'release-toolchain.json'));
  assert.strictEqual(toolchain.runtime.verified_exact_version, process.versions.node);
  assert.deepStrictEqual(toolchain.external_commands, []);
  assert.strictEqual(toolchain.archive_contract.path_order, 'UTF8_BYTEWISE_POSIX');
  assert.strictEqual(toolchain.archive_contract.gzip_method, 'CANONICAL_STORED_DEFLATE');
  assert.strictEqual(toolchain.build_contract.independent_source_scans, 2);
  assert.strictEqual(toolchain.build_contract.independent_source_reads, 2);
  assert.strictEqual(toolchain.build_contract.independent_archive_builds, 2);

  const archiveBytes = releaseBytes(`${releaseId}.tar.gz`);
  const manifestBytes = releaseBytes('release-manifest.json');
  const buildReportBytes = releaseBytes('release-build-report.json');
  const baselineBytes = releaseBytes('baseline-candidate.json');
  const authorityBytes = releaseBytes('authority-decision-packet.json');
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  const buildReport = JSON.parse(buildReportBytes.toString('utf8'));
  const baseline = JSON.parse(baselineBytes.toString('utf8'));
  const authority = JSON.parse(authorityBytes.toString('utf8'));
  assert.strictEqual(manifest.entries.length, 503);
  for (let index = 1; index < manifest.entries.length; index += 1) assert.ok(compareUtf8Path(manifest.entries[index - 1].relative_path, manifest.entries[index].relative_path) < 0, `Manifest order violation at ${index}`);
  assert.strictEqual(buildReport.independent_source_scans, 2);
  assert.strictEqual(buildReport.independent_source_reads, 2);
  assert.strictEqual(buildReport.independent_archive_builds, 2);
  assert.strictEqual(buildReport.independent_builds_byte_identical, true);
  assert.deepStrictEqual(buildReport.external_commands, []);
  assert.strictEqual(buildReport.archive_sha256, sha256(archiveBytes));
  assert.strictEqual(buildReport.manifest_sha256, sha256(manifestBytes));
  assert.strictEqual(finalAudit.release_archive_sha256, sha256(archiveBytes));
  assert.strictEqual(binaryAudit.archive_sha256, sha256(archiveBytes));

  const parsed = parseUstar(inspectCanonicalGzip(archiveBytes).payload);
  assert.strictEqual(parsed.entries.length, 504);
  const baselineSchema = load(path.join(finalRoot, 'config', 'baseline-candidate.schema.json'));
  const authoritySchema = load(path.join(finalRoot, 'config', 'authority-decision-packet.schema.json'));
  assert.deepStrictEqual(validate(baselineSchema, baseline), []);
  assert.deepStrictEqual(validate(authoritySchema, authority), []);
  for (const subject of [baseline.subject_binding, authority.subject_binding]) {
    assert.strictEqual(subject.archive.sha256, sha256(archiveBytes));
    assert.strictEqual(subject.manifest.sha256, sha256(manifestBytes));
    assert.strictEqual(subject.build_report.sha256, sha256(buildReportBytes));
    assert.strictEqual(subject.aggregate_source_identity_sha256, manifest.aggregate_source_identity_sha256);
  }
  assert.strictEqual(authority.subject_binding.baseline_candidate.sha256, sha256(baselineBytes));
  assert.strictEqual(authority.workflow_status, 'PENDING_AUTHORITY_REVIEW');
  assert.strictEqual(authority.decision, null);
  assert.strictEqual(authority.authority, null);
  assert.strictEqual(authority.signature_or_approval_record, null);

  const rc1Root = path.join(finalRoot, 'releases', 'Product-OS-v1.0-rc.1');
  for (const [name, digest] of Object.entries(rc1Digests)) assert.strictEqual(sha256(fs.readFileSync(path.join(rc1Root, name))), digest, `rc.1 changed: ${name}`);

  const blockerDispositions = [
    { prior_blocker: 'Locale-sensitive localeCompare path order', disposition: 'CLOSED', evidence: 'Buffer.compare over UTF-8 bytes; 503-entry order independently verified.' },
    { prior_blocker: 'Undeclared external release toolchain', disposition: 'CLOSED', evidence: 'Pure-Node builder; external_commands=[]; exact Node.js runtime pinned.' },
    { prior_blocker: 'Dual-build claim exceeded implementation', disposition: 'CLOSED', evidence: 'Two fresh scans, reads, manifests, and archive builds plus independent Final-audit rebuild.' },
    { prior_blocker: 'Authority packet lacked explicit digest binding', disposition: 'CLOSED', evidence: 'Schema-validated generated packet binds archive, manifest, build report, source aggregate, and baseline packet digest.' }
  ];
  assert.ok(blockerDispositions.every((item) => item.disposition === 'CLOSED'));
  const findings = [];
  const report = {
    report_id: 'PRODUCT-OS-V1-EXPERT-AUDIT-002', release_id: releaseId, release_version: '1.0.0-rc.2',
    audited_at: new Date().toISOString(), audit_runtime_node: process.versions.node,
    technical_result: 'PASS_WITH_AUTHORITY_PENDING', authority_readiness: 'READY_FOR_AUTHORITY_REVIEW',
    reviewed_layers: ['FINAL', 'BINARY', 'ADVERSARIAL', 'EXPERT'],
    prior_rc1_blocker_dispositions: blockerDispositions, open_blocking_findings: findings,
    open_blocking_finding_count: 0, source_file_count: 503, archive_entry_count: 504,
    exact_release_subject: {
      archive: { path: `${releaseId}.tar.gz`, sha256: sha256(archiveBytes), size_bytes: archiveBytes.length },
      manifest: { path: 'release-manifest.json', sha256: sha256(manifestBytes), size_bytes: manifestBytes.length },
      build_report: { path: 'release-build-report.json', sha256: sha256(buildReportBytes), size_bytes: buildReportBytes.length },
      baseline_candidate: { path: 'baseline-candidate.json', sha256: sha256(baselineBytes), size_bytes: baselineBytes.length },
      authority_decision_packet: { path: 'authority-decision-packet.json', sha256: sha256(authorityBytes), size_bytes: authorityBytes.length }
    },
    rc1_preservation: 'PASS', authority_approval: 'NOT_PERFORMED', baseline_state: 'NOT_ESTABLISHED',
    recommendation: 'Present the exact rc.2 release-bound packet and all four audit reports to Product OS Authority. Do not rename, mutate, or baseline the candidate before its decision.'
  };
  if (writeReport) {
    assert.ok(!fs.existsSync(reportFile), `Audit report will not be overwritten: ${reportFile}`);
    fs.mkdirSync(path.dirname(reportFile), { recursive: true });
    fs.writeFileSync(reportFile, `${JSON.stringify(report, null, 2)}\n`, { flag: 'wx' });
  }
  process.stdout.write(`EXPERT AUDIT PASS_WITH_AUTHORITY_PENDING release=${releaseId} prior_blockers_closed=4 open_blockers=0 authority_readiness=READY_FOR_AUTHORITY_REVIEW archive_sha256=${sha256(archiveBytes)}\n`);
}

try { main(); }
catch (error) { process.stderr.write(`EXPERT_AUDIT_ERROR ${error.stack}\n`); process.exitCode = 1; }
