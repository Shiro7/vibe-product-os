#!/usr/bin/env node
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const { SchemaValidator } = require('../../Automation_Commands/lib/schema-validator');
const {
  sha256Buffer,
  compareUtf8Path,
  validateRelativePath,
  createUstar,
  createCanonicalGzip
} = require('./release-format');

const releaseId = 'Product-OS-v1.0-rc.2';
const releaseVersion = '1.0.0-rc.2';
const fixedTimestamp = '2026-08-16T12:00:00+08:00';
const fixedEpochSeconds = Math.floor(Date.parse(fixedTimestamp) / 1000);
const finalRoot = path.resolve(__dirname, '..');
const outputsRoot = path.resolve(finalRoot, '..');
const configRoot = path.join(finalRoot, 'config');
const toolchain = JSON.parse(fs.readFileSync(path.join(configRoot, 'release-toolchain.json'), 'utf8'));

function parseArgs(argv) {
  let selectedReleaseId = releaseId;
  let dryRun = false;
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--release-id') {
      if (!argv[index + 1]) throw new Error('--release-id requires a value.');
      selectedReleaseId = argv[index + 1];
      index += 1;
    } else if (argv[index] === '--dry-run') dryRun = true;
    else if (argv[index] === '--help') {
      process.stdout.write(`Usage: node scripts/build-release.js [--release-id ${releaseId}] [--dry-run]\n`);
      process.exit(0);
    } else throw new Error(`Unknown build option ${argv[index]}.`);
  }
  if (selectedReleaseId !== releaseId) throw new Error(`This finalization source is pinned to ${releaseId}.`);
  return { selectedReleaseId, dryRun };
}

function assertToolchain() {
  assert.strictEqual(process.versions.node, toolchain.runtime.verified_exact_version, `Release build requires Node.js ${toolchain.runtime.verified_exact_version}; current runtime is ${process.versions.node}.`);
  assert.strictEqual(toolchain.external_commands.length, 0, 'Canonical release build must not depend on external commands.');
  assert.strictEqual(toolchain.archive_contract.path_order, 'UTF8_BYTEWISE_POSIX');
  assert.strictEqual(toolchain.archive_contract.gzip_method, 'CANONICAL_STORED_DEFLATE');
  assert.strictEqual(toolchain.archive_contract.gzip_os_byte, 255);
  assert.strictEqual(toolchain.archive_contract.mtime_epoch_seconds, fixedEpochSeconds);
  assert.strictEqual(toolchain.build_contract.independent_source_scans, 2);
  assert.strictEqual(toolchain.build_contract.independent_archive_builds, 2);
}

function excluded(relative) {
  return relative === 'Product_OS_v1.0_Final/releases'
    || relative.startsWith('Product_OS_v1.0_Final/releases/')
    || relative === 'Product_OS_v1.0_Final/verification'
    || relative.startsWith('Product_OS_v1.0_Final/verification/');
}

function collectSourceFiles() {
  const files = [];
  const queue = [outputsRoot];
  while (queue.length) {
    const directory = queue.shift();
    const names = fs.readdirSync(directory).sort(compareUtf8Path);
    for (const name of names) {
      const target = path.join(directory, name);
      const relative = path.relative(outputsRoot, target).split(path.sep).join('/');
      validateRelativePath(relative);
      if (excluded(relative)) continue;
      const stat = fs.lstatSync(target);
      if (stat.isDirectory()) queue.push(target);
      else if (stat.isFile()) files.push({ absolute: target, relative, stat });
      else throw new Error(`Unsupported release-source filesystem object: ${relative}`);
    }
  }
  files.sort((left, right) => compareUtf8Path(left.relative, right.relative));
  for (let index = 1; index < files.length; index += 1) assert.ok(compareUtf8Path(files[index - 1].relative, files[index].relative) < 0, `Duplicate or unsorted source path: ${files[index].relative}`);
  return files;
}

function normalizedMode(file) {
  return (file.stat.mode & 0o111) !== 0 ? 0o755 : 0o644;
}

function roleFor(relative) {
  if (relative.endsWith('.md')) return 'NORMATIVE_OR_EVIDENCE_MARKDOWN';
  if (relative.endsWith('.schema.json')) return 'JSON_SCHEMA';
  if (relative.endsWith('.json')) return 'MACHINE_RECORD_OR_CATALOG';
  if (/\.ya?ml$/.test(relative)) return 'GOVERNED_YAML';
  if (relative.endsWith('.js')) return 'EXECUTABLE_OR_TEST_SOURCE';
  if (relative.endsWith('.html')) return 'REFERENCE_VIEW';
  if (relative.endsWith('.txt')) return 'TEXT_EVIDENCE_OR_CHECKSUM';
  return 'BINARY_OR_OTHER_SOURCE';
}

async function readSourceRecords(files, concurrency = 32) {
  const records = new Array(files.length);
  let nextIndex = 0;
  async function worker() {
    while (true) {
      const index = nextIndex;
      nextIndex += 1;
      if (index >= files.length) return;
      const file = files[index];
      const content = await fs.promises.readFile(file.absolute);
      assert.strictEqual(content.length, file.stat.size, `Source changed during read: ${file.relative}`);
      records[index] = { ...file, content, mode: normalizedMode(file), sha256: sha256Buffer(content) };
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, files.length) }, () => worker()));
  return records;
}

function buildManifest(records, selectedReleaseId = releaseId) {
  const entries = records.map((record) => ({
    relative_path: record.relative,
    role: roleFor(record.relative),
    size_bytes: record.content.length,
    normalized_mode: record.mode.toString(8).padStart(4, '0'),
    sha256: record.sha256
  }));
  const aggregateSourceIdentity = sha256Buffer(Buffer.from(entries.map((entry) => `${entry.relative_path}\0${entry.sha256}\0${entry.size_bytes}\n`).join('')));
  return {
    release_id: selectedReleaseId,
    product: 'Product OS',
    release_version: releaseVersion,
    status: 'RELEASE_CANDIDATE',
    reproducible_timestamp: fixedTimestamp,
    source_root_label: 'outputs',
    source_file_count: entries.length,
    source_total_bytes: entries.reduce((sum, entry) => sum + entry.size_bytes, 0),
    aggregate_source_identity_sha256: aggregateSourceIdentity,
    logical_project_artifact_count: 281,
    release_component_count: 17,
    lifecycle_phase_count: 12,
    gate_count: 13,
    schema_count: 21,
    command_count: 12,
    pilot_passing_run: 'PILOT-RUN-002',
    toolchain_id: toolchain.toolchain_id,
    build_contract: {
      archive_format: 'POSIX_USTAR_GZIP',
      archive_root: 'Product-OS-v1.0',
      path_order: 'UTF8_BYTEWISE_POSIX',
      path_normalization: 'NFC',
      normalized_file_modes: ['0644', '0755'],
      uid: 0,
      gid: 0,
      mtime_epoch_seconds: fixedEpochSeconds,
      gzip_method: 'CANONICAL_STORED_DEFLATE',
      gzip_mtime: 0,
      gzip_os_byte: 255,
      independent_build_passes: 2,
      external_commands: [],
      self_generated_directories_excluded: ['Product_OS_v1.0_Final/releases/', 'Product_OS_v1.0_Final/verification/']
    },
    entries,
    authority_approval: 'PENDING',
    baseline_state: 'NOT_BASELINED',
    automation_authority: 'NONE'
  };
}

function buildArchive(records, manifestBytes) {
  const entries = records.map((record) => ({
    path: `Product-OS-v1.0/outputs/${record.relative}`,
    content: record.content,
    mode: record.mode,
    mtime: fixedEpochSeconds
  }));
  entries.push({ path: 'Product-OS-v1.0/RELEASE-MANIFEST.json', content: manifestBytes, mode: 0o644, mtime: fixedEpochSeconds });
  return createCanonicalGzip(createUstar(entries));
}

async function buildPass(selectedReleaseId = releaseId) {
  const files = collectSourceFiles();
  assert.strictEqual(files.length, toolchain.build_contract.expected_source_file_count, `Expected ${toolchain.build_contract.expected_source_file_count} release source files, found ${files.length}.`);
  const records = await readSourceRecords(files);
  const manifest = buildManifest(records, selectedReleaseId);
  const manifestBytes = Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`);
  const archiveBytes = buildArchive(records, manifestBytes);
  return { files, records, manifest, manifestBytes, archiveBytes };
}

async function buildCandidate(selectedReleaseId = releaseId) {
  assertToolchain();
  const first = await buildPass(selectedReleaseId);
  const second = await buildPass(selectedReleaseId);
  assert.deepStrictEqual(first.files.map((file) => file.relative), second.files.map((file) => file.relative), 'Independent source scans differ.');
  assert.ok(first.manifestBytes.equals(second.manifestBytes), 'Independent release manifests are not byte-identical.');
  assert.ok(first.archiveBytes.equals(second.archiveBytes), 'Independent release archives are not byte-identical.');
  return {
    ...first,
    independent_manifest_sha256: sha256Buffer(second.manifestBytes),
    independent_archive_sha256: sha256Buffer(second.archiveBytes),
    independent_builds_byte_identical: true
  };
}

function boundFile(filePath, bytes) {
  return { path: filePath, sha256: sha256Buffer(bytes), size_bytes: bytes.length };
}

function validateGeneratedPacket(schemaFile, packet) {
  const schema = JSON.parse(fs.readFileSync(schemaFile, 'utf8'));
  const validator = new SchemaValidator(new Map([[schema.$id, schema]]));
  const errors = validator.validate(schema, packet, schema);
  assert.deepStrictEqual(errors, [], `Generated packet violates ${schema.$id}: ${JSON.stringify(errors)}`);
}

function createReleaseBoundPackets(candidate, buildReportBytes) {
  const baselineTemplate = JSON.parse(fs.readFileSync(path.join(configRoot, 'baseline-candidate.template.json'), 'utf8'));
  const authorityTemplate = JSON.parse(fs.readFileSync(path.join(configRoot, 'authority-decision-packet.template.json'), 'utf8'));
  const archiveName = `${releaseId}.tar.gz`;
  const subjectBinding = {
    archive: boundFile(archiveName, candidate.archiveBytes),
    manifest: boundFile('release-manifest.json', candidate.manifestBytes),
    build_report: boundFile('release-build-report.json', buildReportBytes),
    aggregate_source_identity_sha256: candidate.manifest.aggregate_source_identity_sha256
  };
  const baselineCandidate = {
    schema_id: baselineTemplate.generated_schema_id,
    schema_version: '1.0.0',
    candidate_id: baselineTemplate.generated_candidate_id,
    release_id: releaseId,
    release_version: releaseVersion,
    status: 'CANDIDATE',
    scope: baselineTemplate.scope,
    subject_binding: subjectBinding,
    component_catalog_ref: baselineTemplate.component_catalog_ref,
    compatibility_matrix_ref: baselineTemplate.compatibility_matrix_ref,
    technical_verification_refs: baselineTemplate.technical_verification_refs,
    pilot_evidence_ref: baselineTemplate.pilot_evidence_ref,
    retained_failed_pilot_ref: baselineTemplate.retained_failed_pilot_ref,
    logical_project_artifact_count: baselineTemplate.logical_project_artifact_count,
    release_component_count: baselineTemplate.release_component_count,
    authority: null,
    authority_decision_ref: baselineTemplate.authority_decision_ref,
    approved_at: null,
    effective_at: null,
    baseline_digest: null,
    conditions: [],
    accepted_risks: [],
    supersedes: null,
    reopen_triggers: baselineTemplate.reopen_triggers,
    automation_authority: 'NONE',
    baseline_established: false
  };
  const baselineBytes = Buffer.from(`${JSON.stringify(baselineCandidate, null, 2)}\n`);
  const authorityPacket = {
    schema_id: authorityTemplate.generated_schema_id,
    schema_version: '1.0.0',
    decision_id: authorityTemplate.generated_decision_id,
    release_id: releaseId,
    release_version: releaseVersion,
    workflow_status: 'PENDING_AUTHORITY_REVIEW',
    decision: null,
    allowed_decisions: authorityTemplate.allowed_decisions,
    subject_binding: {
      ...subjectBinding,
      baseline_candidate: {
        path: 'baseline-candidate.json',
        candidate_id: baselineCandidate.candidate_id,
        sha256: sha256Buffer(baselineBytes),
        size_bytes: baselineBytes.length
      }
    },
    review_inputs: authorityTemplate.review_inputs,
    confirmations: authorityTemplate.required_confirmations.map((confirmation) => ({
      ...confirmation,
      status: 'PENDING_AUTHORITY',
      confirmed_by: null,
      confirmed_at: null
    })),
    authority: null,
    decided_at: null,
    rationale: null,
    conditions: [],
    accepted_risks: [],
    signature_or_approval_record: null,
    baseline_effect: 'NONE_UNTIL_APPROVED',
    automation_decision: 'NOT_AUTHORIZED'
  };
  const authorityBytes = Buffer.from(`${JSON.stringify(authorityPacket, null, 2)}\n`);
  validateGeneratedPacket(path.join(configRoot, 'baseline-candidate.schema.json'), baselineCandidate);
  validateGeneratedPacket(path.join(configRoot, 'authority-decision-packet.schema.json'), authorityPacket);
  return { baselineCandidate, baselineBytes, authorityPacket, authorityBytes };
}

function createBuildReport(candidate, executedAt) {
  const builderRelativePath = 'Product_OS_v1.0_Final/scripts/build-release.js';
  const builderEntry = candidate.manifest.entries.find((entry) => entry.relative_path === builderRelativePath);
  const toolchainEntry = candidate.manifest.entries.find((entry) => entry.relative_path === 'Product_OS_v1.0_Final/config/release-toolchain.json');
  assert.ok(builderEntry && toolchainEntry, 'Builder or toolchain source entry is absent from the release manifest.');
  return {
    release_id: releaseId,
    release_version: releaseVersion,
    status: 'RELEASE_CANDIDATE',
    builder_version: releaseVersion,
    builder_path: builderRelativePath,
    builder_sha256: builderEntry.sha256,
    toolchain_id: toolchain.toolchain_id,
    toolchain_record_sha256: toolchainEntry.sha256,
    executed_at: executedAt,
    reproducible_timestamp: fixedTimestamp,
    runtime: {
      node: process.versions.node,
      platform: process.platform,
      architecture: process.arch,
      zlib: process.versions.zlib
    },
    source_root_label: 'outputs',
    source_revision_state: 'CONTENT_ADDRESSED_NO_VCS_CLAIM',
    source_file_count: candidate.files.length,
    source_total_bytes: candidate.manifest.source_total_bytes,
    aggregate_source_identity_sha256: candidate.manifest.aggregate_source_identity_sha256,
    archive_entry_count: candidate.files.length + 1,
    archive_size_bytes: candidate.archiveBytes.length,
    archive_sha256: sha256Buffer(candidate.archiveBytes),
    manifest_size_bytes: candidate.manifestBytes.length,
    manifest_sha256: sha256Buffer(candidate.manifestBytes),
    independent_source_scans: 2,
    independent_source_reads: 2,
    independent_archive_builds: 2,
    independent_rebuild_archive_sha256: candidate.independent_archive_sha256,
    independent_rebuild_manifest_sha256: candidate.independent_manifest_sha256,
    independent_builds_byte_identical: candidate.independent_builds_byte_identical,
    external_commands: [],
    authority_approval: 'PENDING',
    baseline_state: 'NOT_BASELINED'
  };
}

function writeReleaseAtomically(releaseRoot, files) {
  const releasesRoot = path.dirname(releaseRoot);
  fs.mkdirSync(releasesRoot, { recursive: true });
  assert.ok(!fs.existsSync(releaseRoot), `Release root already exists and will not be overwritten: ${releaseRoot}`);
  const stagingRoot = fs.mkdtempSync(path.join(releasesRoot, `.${releaseId}-staging-`));
  try {
    for (const [name, bytes] of files) fs.writeFileSync(path.join(stagingRoot, name), bytes, { flag: 'wx' });
    fs.renameSync(stagingRoot, releaseRoot);
  } catch (error) {
    fs.rmSync(stagingRoot, { recursive: true, force: true });
    throw error;
  }
}

async function main() {
  const { selectedReleaseId, dryRun } = parseArgs(process.argv.slice(2));
  const targetRoot = path.join(finalRoot, 'releases', selectedReleaseId);
  if (!dryRun) assert.ok(!fs.existsSync(targetRoot), `Release root already exists and will not be overwritten: ${targetRoot}`);
  const executedAt = new Date().toISOString();
  const candidate = await buildCandidate(selectedReleaseId);
  const buildReport = createBuildReport(candidate, executedAt);
  const buildReportBytes = Buffer.from(`${JSON.stringify(buildReport, null, 2)}\n`);
  const packets = createReleaseBoundPackets(candidate, buildReportBytes);
  const archiveName = `${selectedReleaseId}.tar.gz`;
  const checksumRows = [
    [archiveName, candidate.archiveBytes],
    ['release-manifest.json', candidate.manifestBytes],
    ['release-build-report.json', buildReportBytes],
    ['baseline-candidate.json', packets.baselineBytes],
    ['authority-decision-packet.json', packets.authorityBytes]
  ];
  const checksumBytes = Buffer.from(`${checksumRows.map(([name, bytes]) => `${sha256Buffer(bytes)}  ${name}`).join('\n')}\n`);
  if (!dryRun) {
    writeReleaseAtomically(targetRoot, [
      [archiveName, candidate.archiveBytes],
      ['release-manifest.json', candidate.manifestBytes],
      ['release-build-report.json', buildReportBytes],
      ['baseline-candidate.json', packets.baselineBytes],
      ['authority-decision-packet.json', packets.authorityBytes],
      ['SHA256SUMS', checksumBytes]
    ]);
  }
  process.stdout.write(`RELEASE BUILD ${dryRun ? 'DRY_RUN_' : ''}PASS id=${selectedReleaseId} source_files=${candidate.files.length} archive_entries=${candidate.files.length + 1} archive_bytes=${candidate.archiveBytes.length} archive_sha256=${sha256Buffer(candidate.archiveBytes)} manifest_sha256=${sha256Buffer(candidate.manifestBytes)} independent_builds=2 byte_identical=true external_commands=0\n`);
}

if (require.main === module) {
  main().catch((error) => {
    process.stderr.write(`RELEASE_BUILD_ERROR ${error.stack}\n`);
    process.exitCode = 1;
  });
}

module.exports = {
  releaseId,
  releaseVersion,
  fixedTimestamp,
  fixedEpochSeconds,
  finalRoot,
  outputsRoot,
  toolchain,
  collectSourceFiles,
  readSourceRecords,
  buildManifest,
  buildArchive,
  buildPass,
  buildCandidate,
  createBuildReport,
  createReleaseBoundPackets,
  sha256Buffer,
  compareUtf8Path
};
