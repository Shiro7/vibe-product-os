#!/usr/bin/env node
'use strict';

const assert = require('assert');
const crypto = require('crypto');

const GZIP_HEADER = Buffer.from([0x1f, 0x8b, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff]);
const TAR_BLOCK_SIZE = 512;
const STORED_BLOCK_MAX = 65535;

function sha256Buffer(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function compareUtf8Path(left, right) {
  return Buffer.compare(Buffer.from(left, 'utf8'), Buffer.from(right, 'utf8'));
}

function validateRelativePath(value) {
  assert.strictEqual(typeof value, 'string', 'Path must be a string.');
  assert.ok(value.length > 0, 'Path must not be empty.');
  assert.ok(!value.startsWith('/'), `Absolute path is prohibited: ${value}`);
  assert.ok(!value.includes('\\'), `Backslash path is prohibited: ${value}`);
  assert.ok(!/[\u0000-\u001f\u007f]/.test(value), `Control character is prohibited in path: ${JSON.stringify(value)}`);
  assert.strictEqual(value.normalize('NFC'), value, `Path must use NFC normalization: ${value}`);
  const segments = value.split('/');
  assert.ok(segments.every((segment) => segment && segment !== '.' && segment !== '..'), `Unsafe path segment: ${value}`);
  return value;
}

function writeString(buffer, offset, length, value) {
  const bytes = Buffer.from(value, 'utf8');
  assert.ok(bytes.length <= length, `TAR field exceeds ${length} bytes: ${value}`);
  bytes.copy(buffer, offset);
}

function writeOctal(buffer, offset, length, value) {
  assert.ok(Number.isInteger(value) && value >= 0, `Invalid TAR octal value: ${value}`);
  const encoded = value.toString(8).padStart(length - 1, '0');
  assert.ok(encoded.length <= length - 1, `TAR octal field overflow: ${value}`);
  writeString(buffer, offset, length, `${encoded}\0`);
}

function splitUstarPath(value) {
  validateRelativePath(value);
  if (Buffer.byteLength(value, 'utf8') <= 100) return { name: value, prefix: '' };
  const separators = [];
  for (let index = 0; index < value.length; index += 1) if (value[index] === '/') separators.push(index);
  for (let index = separators.length - 1; index >= 0; index -= 1) {
    const prefix = value.slice(0, separators[index]);
    const name = value.slice(separators[index] + 1);
    if (Buffer.byteLength(prefix, 'utf8') <= 155 && Buffer.byteLength(name, 'utf8') <= 100) return { name, prefix };
  }
  throw new Error(`Path cannot be represented by POSIX ustar: ${value}`);
}

function createUstarHeader(entry) {
  const header = Buffer.alloc(TAR_BLOCK_SIZE, 0);
  const split = splitUstarPath(entry.path);
  writeString(header, 0, 100, split.name);
  writeOctal(header, 100, 8, entry.mode);
  writeOctal(header, 108, 8, 0);
  writeOctal(header, 116, 8, 0);
  writeOctal(header, 124, 12, entry.content.length);
  writeOctal(header, 136, 12, entry.mtime);
  header.fill(0x20, 148, 156);
  header[156] = 0x30;
  writeString(header, 257, 6, 'ustar\0');
  writeString(header, 263, 2, '00');
  writeString(header, 345, 155, split.prefix);
  const checksum = header.reduce((sum, byte) => sum + byte, 0);
  writeString(header, 148, 8, `${checksum.toString(8).padStart(6, '0')}\0 `);
  return header;
}

function createUstar(entries) {
  assert.ok(Array.isArray(entries) && entries.length > 0, 'Ustar requires at least one entry.');
  const seen = new Set();
  const parts = [];
  for (const entry of entries) {
    validateRelativePath(entry.path);
    assert.ok(!seen.has(entry.path), `Duplicate ustar path: ${entry.path}`);
    seen.add(entry.path);
    assert.ok(Buffer.isBuffer(entry.content), `Ustar content must be a Buffer: ${entry.path}`);
    assert.ok(entry.mode === 0o644 || entry.mode === 0o755, `Unsupported normalized mode for ${entry.path}`);
    assert.ok(Number.isInteger(entry.mtime) && entry.mtime >= 0, `Invalid mtime for ${entry.path}`);
    const header = createUstarHeader(entry);
    const padding = Buffer.alloc((TAR_BLOCK_SIZE - (entry.content.length % TAR_BLOCK_SIZE)) % TAR_BLOCK_SIZE, 0);
    parts.push(header, entry.content, padding);
  }
  parts.push(Buffer.alloc(TAR_BLOCK_SIZE * 2, 0));
  return Buffer.concat(parts);
}

function readTextField(buffer, offset, length) {
  const field = buffer.subarray(offset, offset + length);
  const zeroIndex = field.indexOf(0);
  return field.subarray(0, zeroIndex === -1 ? field.length : zeroIndex).toString('utf8');
}

function readOctalField(buffer, offset, length) {
  const value = readTextField(buffer, offset, length).trim();
  return value ? Number.parseInt(value, 8) : 0;
}

function parseUstar(tar) {
  assert.ok(Buffer.isBuffer(tar), 'Ustar input must be a Buffer.');
  const entries = [];
  let offset = 0;
  let zeroStart = -1;
  while (offset + TAR_BLOCK_SIZE <= tar.length) {
    const header = tar.subarray(offset, offset + TAR_BLOCK_SIZE);
    if (header.every((byte) => byte === 0)) {
      zeroStart = offset;
      break;
    }
    const checksumHeader = Buffer.from(header);
    checksumHeader.fill(0x20, 148, 156);
    const recordedChecksum = readOctalField(header, 148, 8);
    const computedChecksum = checksumHeader.reduce((sum, byte) => sum + byte, 0);
    assert.strictEqual(recordedChecksum, computedChecksum, `Ustar checksum mismatch at offset ${offset}`);
    const prefix = readTextField(header, 345, 155);
    const name = readTextField(header, 0, 100);
    const entryPath = prefix ? `${prefix}/${name}` : name;
    validateRelativePath(entryPath);
    const size = readOctalField(header, 124, 12);
    const contentStart = offset + TAR_BLOCK_SIZE;
    const contentEnd = contentStart + size;
    assert.ok(contentEnd <= tar.length, `Ustar content exceeds archive: ${entryPath}`);
    assert.strictEqual(String.fromCharCode(header[156] || 0x30), '0', `Non-regular ustar entry: ${entryPath}`);
    assert.strictEqual(header.subarray(257, 263).toString('latin1'), 'ustar\0', `Invalid ustar magic: ${entryPath}`);
    assert.strictEqual(header.subarray(263, 265).toString('latin1'), '00', `Invalid ustar version: ${entryPath}`);
    entries.push({
      path: entryPath,
      mode: readOctalField(header, 100, 8),
      uid: readOctalField(header, 108, 8),
      gid: readOctalField(header, 116, 8),
      size,
      mtime: readOctalField(header, 136, 12),
      content: tar.subarray(contentStart, contentEnd)
    });
    offset = contentStart + Math.ceil(size / TAR_BLOCK_SIZE) * TAR_BLOCK_SIZE;
  }
  assert.ok(zeroStart >= 0, 'Ustar terminator is missing.');
  assert.strictEqual(tar.length - zeroStart, TAR_BLOCK_SIZE * 2, 'Ustar must end with exactly two zero blocks.');
  assert.ok(tar.subarray(zeroStart).every((byte) => byte === 0), 'Ustar has non-zero bytes after the terminator.');
  assert.strictEqual(new Set(entries.map((entry) => entry.path)).size, entries.length, 'Ustar contains duplicate paths.');
  return { entries, trailing_zero_bytes: tar.length - zeroStart };
}

function createCrcTable() {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
    table[index] = value >>> 0;
  }
  return table;
}

const CRC_TABLE = createCrcTable();

function crc32(buffer) {
  let value = 0xffffffff;
  for (const byte of buffer) value = CRC_TABLE[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

function createStoredDeflate(payload) {
  const parts = [];
  if (payload.length === 0) {
    const block = Buffer.alloc(5);
    block[0] = 1;
    block.writeUInt16LE(0, 1);
    block.writeUInt16LE(0xffff, 3);
    return block;
  }
  for (let offset = 0; offset < payload.length; offset += STORED_BLOCK_MAX) {
    const length = Math.min(STORED_BLOCK_MAX, payload.length - offset);
    const final = offset + length >= payload.length;
    const header = Buffer.alloc(5);
    header[0] = final ? 1 : 0;
    header.writeUInt16LE(length, 1);
    header.writeUInt16LE((~length) & 0xffff, 3);
    parts.push(header, payload.subarray(offset, offset + length));
  }
  return Buffer.concat(parts);
}

function createCanonicalGzip(payload) {
  assert.ok(Buffer.isBuffer(payload), 'Gzip payload must be a Buffer.');
  const trailer = Buffer.alloc(8);
  trailer.writeUInt32LE(crc32(payload), 0);
  trailer.writeUInt32LE(payload.length >>> 0, 4);
  return Buffer.concat([GZIP_HEADER, createStoredDeflate(payload), trailer]);
}

function inspectCanonicalGzip(gzip) {
  assert.ok(Buffer.isBuffer(gzip), 'Gzip input must be a Buffer.');
  assert.ok(gzip.length >= 23, 'Gzip input is too short.');
  assert.ok(gzip.subarray(0, GZIP_HEADER.length).equals(GZIP_HEADER), 'Gzip header is not canonical.');
  const trailerStart = gzip.length - 8;
  const payloadParts = [];
  let offset = GZIP_HEADER.length;
  let final = false;
  let blockCount = 0;
  while (!final) {
    assert.ok(offset + 5 <= trailerStart, 'Stored DEFLATE block header is truncated.');
    const header = gzip[offset];
    assert.ok(header === 0 || header === 1, 'DEFLATE stream is not canonical stored-block encoding.');
    final = header === 1;
    const length = gzip.readUInt16LE(offset + 1);
    const inverse = gzip.readUInt16LE(offset + 3);
    assert.strictEqual(inverse, ((~length) & 0xffff), 'Stored DEFLATE LEN/NLEN mismatch.');
    offset += 5;
    assert.ok(offset + length <= trailerStart, 'Stored DEFLATE block data is truncated.');
    payloadParts.push(gzip.subarray(offset, offset + length));
    offset += length;
    blockCount += 1;
  }
  assert.strictEqual(offset, trailerStart, 'Unexpected bytes exist between DEFLATE stream and gzip trailer.');
  const payload = Buffer.concat(payloadParts);
  assert.strictEqual(gzip.readUInt32LE(trailerStart), crc32(payload), 'Gzip CRC32 mismatch.');
  assert.strictEqual(gzip.readUInt32LE(trailerStart + 4), payload.length >>> 0, 'Gzip ISIZE mismatch.');
  return { payload, block_count: blockCount, os_byte: gzip[9], mtime: gzip.readUInt32LE(4) };
}

module.exports = {
  GZIP_HEADER,
  TAR_BLOCK_SIZE,
  sha256Buffer,
  compareUtf8Path,
  validateRelativePath,
  createUstar,
  parseUstar,
  crc32,
  createCanonicalGzip,
  inspectCanonicalGzip
};
