#!/usr/bin/env node
'use strict';

const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const { inspectCanonicalGzip, parseUstar, compareUtf8Path, validateRelativePath } = require('./release-format');

const releaseId = 'Product-OS-v1.0-rc.2';
const finalRoot = path.resolve(__dirname, '..');
const releaseRoot = path.join(finalRoot, 'releases', releaseId);
const reportFile = path.join(finalRoot, 'verification', 'rc.2', 'binary-audit-report.json');
const rc1ArchiveDigest = '58425470e9a3e2873d976cee38fd1891bd8a6929d873269bd58d1b64e457f9c9';

function parseArgs(argv) {
  let selected = releaseId;
  let writeReport = false;
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--release-id') { if (!argv[index + 1]) throw new Error('--release-id requires a value.'); selected = argv[index + 1]; index += 1; }
    else if (argv[index] === '--write-report') writeReport = true;
    else if (argv[index] === '--help') { process.stdout.write(`Usage: node scripts/audit-binary.js [--release-id ${releaseId}] [--write-report]\n`); process.exit(0); }
    else throw new Error(`Unknown binary-audit option ${argv[index]}.`);
  }
  if (selected !== releaseId) throw new Error(`This audit is pinned to ${releaseId}.`);
  return { writeReport };
}

function sha256(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function bytes(name) { return fs.readFileSync(path.join(releaseRoot, name)); }
function json(name) { return JSON.parse(bytes(name).toString('utf8')); }

function parseSums(payload) {
  const values = new Map();
  for (const row of payload.toString('utf8').trim().split(/\r?\n/)) {
    const match = row.match(/^([a-f0-9]{64})  ([A-Za-z0-9._-]+)$/);
    assert.ok(match, `Malformed checksum row: ${row}`);
    assert.ok(!values.has(match[2]), `Duplicate checksum subject: ${match[2]}`);
    values.set(match[2], match[1]);
  }
  return values;
}

function assertBound(bound, name, payload) {
  assert.strictEqual(bound.path, name);
  assert.strictEqual(bound.size_bytes, payload.length);
  assert.strictEqual(bound.sha256, sha256(payload));
}

function secretFindings(entries) {
  const patterns = [
    { id: 'PEM_PRIVATE_KEY', expression: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/ },
    { id: 'AWS_ACCESS_KEY', expression: /\bAKIA[0-9A-Z]{16}\b/ },
    { id: 'GITHUB_CLASSIC_TOKEN', expression: /\bghp_[A-Za-z0-9]{36}\b/ },
    { id: 'STRIPE_LIVE_SECRET', expression: /\bsk_live_[A-Za-z0-9]{20,}\b/ }
  ];
  const findings = [];
  for (const entry of entries) {
    const text = entry.content.toString('utf8');
    for (const pattern of patterns) if (pattern.expression.test(text)) findings.push({ path: entry.path, pattern_id: pattern.id });
  }
  return findings;
}

function main() {
  const { writeReport } = parseArgs(process.argv.slice(2));
  const archive = bytes(`${releaseId}.tar.gz`);
  const manifestBytes = bytes('release-manifest.json');
  const buildReportBytes = bytes('release-build-report.json');
  const baselineBytes = bytes('baseline-candidate.json');
  const authorityBytes = bytes('authority-decision-packet.json');
  const manifest = json('release-manifest.json');
  const buildReport = json('release-build-report.json');
  const baseline = json('baseline-candidate.json');
  const authority = json('authority-decision-packet.json');

  const gzip = inspectCanonicalGzip(archive);
  assert.strictEqual(gzip.os_byte, 255);
  assert.strictEqual(gzip.mtime, 0);
  const tar = parseUstar(gzip.payload);
  assert.strictEqual(tar.trailing_zero_bytes, 1024);
  assert.strictEqual(tar.entries.length, 504);
  assert.strictEqual(new Set(tar.entries.map((entry) => entry.path)).size, 504);
  assert.strictEqual(manifest.entries.length, 503);
  assert.strictEqual(buildReport.archive_entry_count, 504);
  assert.strictEqual(buildReport.archive_sha256, sha256(archive));
  assert.strictEqual(buildReport.manifest_sha256, sha256(manifestBytes));

  const sourceEntries = tar.entries.slice(0, -1);
  const embeddedManifest = tar.entries.at(-1);
  assert.strictEqual(embeddedManifest.path, 'Product-OS-v1.0/RELEASE-MANIFEST.json');
  assert.ok(embeddedManifest.content.equals(manifestBytes), 'Embedded manifest differs from external manifest.');
  for (let index = 1; index < manifest.entries.length; index += 1) assert.ok(compareUtf8Path(manifest.entries[index - 1].relative_path, manifest.entries[index].relative_path) < 0, `Manifest byte-order violation at index ${index}`);

  const aggregateRows = [];
  for (let index = 0; index < manifest.entries.length; index += 1) {
    const declared = manifest.entries[index];
    validateRelativePath(declared.relative_path);
    const actual = sourceEntries[index];
    const expectedPath = `Product-OS-v1.0/outputs/${declared.relative_path}`;
    assert.strictEqual(actual.path, expectedPath, `Archive order/path mismatch at ${index}`);
    assert.strictEqual(actual.mode, Number.parseInt(declared.normalized_mode, 8));
    assert.ok(actual.mode === 0o644 || actual.mode === 0o755);
    assert.strictEqual(actual.uid, 0);
    assert.strictEqual(actual.gid, 0);
    assert.strictEqual(actual.mtime, 1786852800);
    assert.strictEqual(actual.size, declared.size_bytes);
    assert.strictEqual(sha256(actual.content), declared.sha256);
    aggregateRows.push(`${declared.relative_path}\0${declared.sha256}\0${declared.size_bytes}\n`);
  }
  assert.strictEqual(sha256(Buffer.from(aggregateRows.join(''))), manifest.aggregate_source_identity_sha256);
  assert.strictEqual(embeddedManifest.mode, 0o644);
  assert.strictEqual(embeddedManifest.uid, 0);
  assert.strictEqual(embeddedManifest.gid, 0);
  assert.strictEqual(embeddedManifest.mtime, 1786852800);

  const sums = parseSums(bytes('SHA256SUMS'));
  const subjects = new Map([[`${releaseId}.tar.gz`, archive], ['release-manifest.json', manifestBytes], ['release-build-report.json', buildReportBytes], ['baseline-candidate.json', baselineBytes], ['authority-decision-packet.json', authorityBytes]]);
  assert.strictEqual(sums.size, 5);
  for (const [name, payload] of subjects) assert.strictEqual(sums.get(name), sha256(payload));
  for (const binding of [baseline.subject_binding, authority.subject_binding]) {
    assertBound(binding.archive, `${releaseId}.tar.gz`, archive);
    assertBound(binding.manifest, 'release-manifest.json', manifestBytes);
    assertBound(binding.build_report, 'release-build-report.json', buildReportBytes);
    assert.strictEqual(binding.aggregate_source_identity_sha256, manifest.aggregate_source_identity_sha256);
  }
  assertBound(authority.subject_binding.baseline_candidate, 'baseline-candidate.json', baselineBytes);

  const findings = secretFindings(sourceEntries);
  assert.deepStrictEqual(findings, [], `High-confidence secret findings: ${JSON.stringify(findings)}`);
  const rc1Archive = fs.readFileSync(path.join(finalRoot, 'releases', 'Product-OS-v1.0-rc.1', 'Product-OS-v1.0-rc.1.tar.gz'));
  assert.strictEqual(sha256(rc1Archive), rc1ArchiveDigest, 'rc.1 archive changed.');

  const report = {
    report_id: 'PRODUCT-OS-V1-BINARY-AUDIT-002', release_id: releaseId, release_version: '1.0.0-rc.2',
    audited_at: new Date().toISOString(), technical_result: 'PASS', archive_sha256: sha256(archive),
    archive_size_bytes: archive.length, gzip_contract: { method: 'CANONICAL_STORED_DEFLATE', mtime: gzip.mtime, os_byte: gzip.os_byte, block_count: gzip.block_count },
    tar_contract: { format: 'POSIX_USTAR', entry_count: tar.entries.length, regular_files: tar.entries.length, terminal_zero_blocks: 2, unique_paths: true, safe_paths: true },
    manifest_source_entries: manifest.entries.length, source_digest_size_mode_ownership_time_checks: 'PASS',
    embedded_manifest_byte_identical: true, aggregate_source_identity_check: 'PASS', checksum_subjects_verified: 5,
    release_bound_packet_reconciliation: 'PASS', high_confidence_secret_findings: findings,
    rc1_preservation: 'PASS', authority_approval: 'NOT_PERFORMED', baseline_state: 'NOT_ESTABLISHED'
  };
  if (writeReport) {
    assert.ok(!fs.existsSync(reportFile), `Audit report will not be overwritten: ${reportFile}`);
    fs.mkdirSync(path.dirname(reportFile), { recursive: true });
    fs.writeFileSync(reportFile, `${JSON.stringify(report, null, 2)}\n`, { flag: 'wx' });
  }
  process.stdout.write(`BINARY AUDIT PASS release=${releaseId} archive_entries=504 source_entries=503 checksum_subjects=5 secret_findings=0 rc1_preserved=true archive_sha256=${sha256(archive)}\n`);
}

try { main(); }
catch (error) { process.stderr.write(`BINARY_AUDIT_ERROR ${error.stack}\n`); process.exitCode = 1; }
