#!/usr/bin/env node
'use strict';

const assert = require('assert');
const childProcess = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const builder = require('./build-release');
const { compareUtf8Path } = require('./release-format');
const { JsonReader } = require('../../Automation_Commands/lib/serialization');
const { SchemaValidator } = require('../../Automation_Commands/lib/schema-validator');

const releaseId = 'Product-OS-v1.0-rc.2';
const releaseVersion = '1.0.0-rc.2';
const finalRoot = path.resolve(__dirname, '..');
const outputsRoot = path.resolve(finalRoot, '..');
const releaseRoot = path.join(finalRoot, 'releases', releaseId);
const reportFile = path.join(finalRoot, 'verification', 'rc.2', 'final-audit-report.json');
const plannedAuditFiles = new Set(['final-audit-report.json', 'binary-audit-report.json', 'adversarial-audit-report.json', 'expert-audit-report.json'].map((name) => path.join(finalRoot, 'verification', 'rc.2', name)));
const rc1Digests = {
  'Product-OS-v1.0-rc.1.tar.gz': '58425470e9a3e2873d976cee38fd1891bd8a6929d873269bd58d1b64e457f9c9',
  'SHA256SUMS': '947d5daf3156f446737a380407077ac41182358875c28b7261d2dbf833c79a8f',
  'release-build-report.json': '26f2f6d69ea19aeb278bad42105ec4d3359a823bdf95dd9419f5d14353a88e84',
  'release-manifest.json': 'e885015b72361b89ebfbec2c6a14250f8f4d8065db4f714905f67ab01e61febe'
};

function parseArgs(argv) {
  let selected = releaseId;
  let writeReport = false;
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--release-id') {
      if (!argv[index + 1]) throw new Error('--release-id requires a value.');
      selected = argv[index + 1];
      index += 1;
    } else if (argv[index] === '--write-report') writeReport = true;
    else if (argv[index] === '--help') {
      process.stdout.write(`Usage: node scripts/audit-final.js [--release-id ${releaseId}] [--write-report]\n`);
      process.exit(0);
    } else throw new Error(`Unknown audit option ${argv[index]}.`);
  }
  if (selected !== releaseId) throw new Error(`This audit is pinned to ${releaseId}.`);
  return { writeReport };
}

function sha256(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function fileBytes(name) { return fs.readFileSync(path.join(releaseRoot, name)); }
function parseJson(file) { return new JsonReader(fs.readFileSync(file, 'utf8'), file).parse(); }
function parseReleaseJson(name) { return parseJson(path.join(releaseRoot, name)); }

function runNode(args, cwd) {
  const result = childProcess.spawnSync(process.execPath, args, { cwd, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  assert.strictEqual(result.status, 0, result.stderr || result.stdout || `Node process failed: ${args.join(' ')}`);
  return result.stdout.trim();
}

function validatePacket(schemaName, packet) {
  const schemaFile = path.join(finalRoot, 'config', schemaName);
  const schema = parseJson(schemaFile);
  const validator = new SchemaValidator(new Map([[schema.$id, schema]]));
  const errors = validator.validate(schema, packet, schema);
  assert.deepStrictEqual(errors, [], `${schemaName} validation failed: ${JSON.stringify(errors)}`);
}

function parseSums(bytes) {
  const result = new Map();
  for (const line of bytes.toString('utf8').trim().split(/\r?\n/)) {
    const match = line.match(/^([a-f0-9]{64})  ([A-Za-z0-9._-]+)$/);
    assert.ok(match, `Invalid SHA256SUMS row: ${line}`);
    assert.ok(!result.has(match[2]), `Duplicate SHA256SUMS subject: ${match[2]}`);
    result.set(match[2], match[1]);
  }
  return result;
}

function assertBinding(binding, name, bytes) {
  assert.strictEqual(binding.path, name);
  assert.strictEqual(binding.size_bytes, bytes.length);
  assert.strictEqual(binding.sha256, sha256(bytes));
}

function verifyRc1() {
  const root = path.join(finalRoot, 'releases', 'Product-OS-v1.0-rc.1');
  assert.deepStrictEqual(fs.readdirSync(root).sort(compareUtf8Path), Object.keys(rc1Digests).sort(compareUtf8Path));
  for (const [name, digest] of Object.entries(rc1Digests)) assert.strictEqual(sha256(fs.readFileSync(path.join(root, name))), digest, `rc.1 changed: ${name}`);
}

function checkMarkdown(files) {
  let checkedLinks = 0;
  for (const file of files.filter((item) => item.relative.endsWith('.md'))) {
    const content = fs.readFileSync(file.absolute, 'utf8');
    assert.strictEqual((content.match(/^(?:```|~~~)/gm) || []).length % 2, 0, `Unbalanced Markdown fence: ${file.relative}`);
    const pattern = /\[[^\]\r\n]+\]\(([^)\r\n]+)\)/g;
    let match;
    while ((match = pattern.exec(content)) !== null) {
      let target = match[1].trim().replace(/^<|>$/g, '');
      if (target.startsWith('#') || /^[a-z]+:/i.test(target)) continue;
      target = target.split('#')[0];
      if (!target) continue;
      const resolved = path.resolve(path.dirname(file.absolute), decodeURIComponent(target));
      assert.ok(fs.existsSync(resolved) || plannedAuditFiles.has(resolved), `Broken Markdown link ${file.relative} -> ${target}`);
      checkedLinks += 1;
    }
  }
  return checkedLinks;
}

function criterion(definitions, id, result, evidence) {
  const definition = definitions.find((item) => item.criterion_id === id);
  assert.ok(definition, `Unknown criterion ${id}`);
  return { ...definition, result, evidence, automation_authority: 'NONE' };
}

async function main() {
  const { writeReport } = parseArgs(process.argv.slice(2));
  assert.strictEqual(process.versions.node, builder.toolchain.runtime.verified_exact_version);
  const required = [`${releaseId}.tar.gz`, 'release-manifest.json', 'release-build-report.json', 'baseline-candidate.json', 'authority-decision-packet.json', 'SHA256SUMS'];
  assert.deepStrictEqual(fs.readdirSync(releaseRoot).sort(compareUtf8Path), required.sort(compareUtf8Path), 'Unexpected rc.2 release-root contents.');

  const archiveBytes = fileBytes(`${releaseId}.tar.gz`);
  const manifestBytes = fileBytes('release-manifest.json');
  const buildReportBytes = fileBytes('release-build-report.json');
  const baselineBytes = fileBytes('baseline-candidate.json');
  const authorityBytes = fileBytes('authority-decision-packet.json');
  const manifest = parseReleaseJson('release-manifest.json');
  const buildReport = parseReleaseJson('release-build-report.json');
  const baseline = parseReleaseJson('baseline-candidate.json');
  const authority = parseReleaseJson('authority-decision-packet.json');
  const componentCatalog = parseJson(path.join(finalRoot, 'config', 'release-component-catalog.json'));
  const compatibility = parseJson(path.join(finalRoot, 'config', 'compatibility-matrix.json'));
  const criteriaCatalog = parseJson(path.join(finalRoot, 'config', 'final-acceptance-criteria.json'));

  assert.strictEqual(componentCatalog.component_count, 17);
  assert.strictEqual(componentCatalog.components.length, 17);
  assert.strictEqual(new Set(componentCatalog.components.map((item) => item.component_id)).size, 17);
  for (const component of componentCatalog.components) {
    assert.strictEqual(component.technical_status, 'PASS');
    assert.ok(fs.existsSync(path.join(outputsRoot, component.entry_point)), `Missing component ${component.entry_point}`);
  }
  assert.strictEqual(compatibility.entry_count, 13);
  assert.strictEqual(compatibility.entries.length, 13);
  assert.strictEqual(criteriaCatalog.criterion_count, 30);
  assert.strictEqual(criteriaCatalog.criteria.length, 30);

  assert.strictEqual(fs.readdirSync(outputsRoot).filter((name) => /^Phase_[0-9]{2}_.*\.md$/.test(name)).length, 12);
  const artifactCatalog = parseJson(path.join(outputsRoot, 'Schemas_Repository_Standard/catalogs/artifact-catalog.json'));
  const gateCatalog = parseJson(path.join(outputsRoot, 'Schemas_Repository_Standard/catalogs/gate-catalog.json'));
  const schemaCatalog = parseJson(path.join(outputsRoot, 'Schemas_Repository_Standard/catalogs/schema-catalog.json'));
  const commandCatalog = parseJson(path.join(outputsRoot, 'Automation_Commands/config/command-catalog.json'));
  const ruleCatalog = parseJson(path.join(outputsRoot, 'Automation_Commands/config/rule-catalog.json'));
  assert.strictEqual(artifactCatalog.artifact_count, 281);
  assert.strictEqual(gateCatalog.gate_count, 13);
  assert.strictEqual(schemaCatalog.schema_count, 21);
  assert.strictEqual(commandCatalog.command_count, 12);
  assert.strictEqual(ruleCatalog.rule_count, 80);

  const automationTests = runNode(['test/run-tests.js'], path.join(outputsRoot, 'Automation_Commands'));
  const automationAudit = runNode(['test/audit-package.js'], path.join(outputsRoot, 'Automation_Commands'));
  const pilotAudit = runNode(['scripts/audit-pilot.js', '--run-id', 'PILOT-RUN-002'], path.join(outputsRoot, 'Pilot'));

  const rebuilt = await builder.buildCandidate(releaseId);
  assert.ok(rebuilt.manifestBytes.equals(manifestBytes), 'Independent final-audit manifest rebuild differs.');
  assert.ok(rebuilt.archiveBytes.equals(archiveBytes), 'Independent final-audit archive rebuild differs.');
  assert.strictEqual(manifest.source_file_count, 503);
  assert.strictEqual(manifest.entries.length, 503);
  for (let index = 1; index < manifest.entries.length; index += 1) assert.ok(compareUtf8Path(manifest.entries[index - 1].relative_path, manifest.entries[index].relative_path) < 0, `Manifest is not POSIX byte-sorted at ${index}.`);
  for (const record of rebuilt.records) {
    const entry = manifest.entries.find((item) => item.relative_path === record.relative);
    assert.ok(entry, `Missing manifest source ${record.relative}`);
    assert.strictEqual(entry.size_bytes, record.content.length);
    assert.strictEqual(entry.sha256, record.sha256);
  }
  assert.strictEqual(buildReport.release_id, releaseId);
  assert.strictEqual(buildReport.source_file_count, 503);
  assert.strictEqual(buildReport.archive_entry_count, 504);
  assert.strictEqual(buildReport.independent_source_scans, 2);
  assert.strictEqual(buildReport.independent_source_reads, 2);
  assert.strictEqual(buildReport.independent_archive_builds, 2);
  assert.strictEqual(buildReport.independent_builds_byte_identical, true);
  assert.deepStrictEqual(buildReport.external_commands, []);
  assert.strictEqual(buildReport.archive_sha256, sha256(archiveBytes));
  assert.strictEqual(buildReport.manifest_sha256, sha256(manifestBytes));
  assert.strictEqual(buildReport.aggregate_source_identity_sha256, manifest.aggregate_source_identity_sha256);

  const sums = parseSums(fileBytes('SHA256SUMS'));
  const checksumSubjects = new Map([[`${releaseId}.tar.gz`, archiveBytes], ['release-manifest.json', manifestBytes], ['release-build-report.json', buildReportBytes], ['baseline-candidate.json', baselineBytes], ['authority-decision-packet.json', authorityBytes]]);
  assert.strictEqual(sums.size, checksumSubjects.size);
  for (const [name, bytes] of checksumSubjects) assert.strictEqual(sums.get(name), sha256(bytes), `Checksum mismatch: ${name}`);

  validatePacket('baseline-candidate.schema.json', baseline);
  validatePacket('authority-decision-packet.schema.json', authority);
  for (const binding of [baseline.subject_binding, authority.subject_binding]) {
    assertBinding(binding.archive, `${releaseId}.tar.gz`, archiveBytes);
    assertBinding(binding.manifest, 'release-manifest.json', manifestBytes);
    assertBinding(binding.build_report, 'release-build-report.json', buildReportBytes);
    assert.strictEqual(binding.aggregate_source_identity_sha256, manifest.aggregate_source_identity_sha256);
  }
  assertBinding(authority.subject_binding.baseline_candidate, 'baseline-candidate.json', baselineBytes);
  assert.strictEqual(authority.subject_binding.baseline_candidate.candidate_id, baseline.candidate_id);
  assert.strictEqual(baseline.baseline_established, false);
  assert.strictEqual(baseline.authority, null);
  assert.strictEqual(authority.workflow_status, 'PENDING_AUTHORITY_REVIEW');
  assert.strictEqual(authority.decision, null);
  assert.strictEqual(authority.authority, null);
  assert.strictEqual(authority.automation_decision, 'NOT_AUTHORIZED');

  const sourceFiles = builder.collectSourceFiles();
  const jsonFiles = sourceFiles.filter((file) => file.relative.endsWith('.json'));
  for (const file of jsonFiles) parseJson(file.absolute);
  const jsFiles = sourceFiles.filter((file) => file.relative.endsWith('.js'));
  for (const file of jsFiles) runNode(['--check', file.absolute], outputsRoot);
  const markdownFiles = sourceFiles.filter((file) => file.relative.endsWith('.md'));
  const checkedLinks = checkMarkdown(sourceFiles);
  const finalDocs = fs.readdirSync(finalRoot).filter((name) => name.endsWith('.md'));
  assert.strictEqual(finalDocs.length, 12);
  const unfinished = /\b(?:TODO|TBD|FIXME)\b|for brevity|content omitted/i;
  for (const name of finalDocs) assert.ok(!unfinished.test(fs.readFileSync(path.join(finalRoot, name), 'utf8')), `Unfinished marker: ${name}`);
  verifyRc1();

  const results = [];
  const pass = (id, evidence) => results.push(criterion(criteriaCatalog.criteria, id, 'PASS', evidence));
  pass('FAC-001', '17 unique release components with resolvable PASS entry points.');
  pass('FAC-002', 'Twelve lifecycle phase specifications present.');
  pass('FAC-003', 'Artifact catalog remains 281.');
  pass('FAC-004', 'Gate catalog remains 13.');
  pass('FAC-005', 'Core Artifact Contracts retain 281/281 coverage.');
  pass('FAC-006', 'Schema catalog remains 21; Automation package audit passed.');
  pass('FAC-007', 'Command catalog 12 and SRV rule catalog 80.');
  pass('FAC-008', automationTests.split(/\r?\n/).slice(-1)[0]);
  pass('FAC-009', automationAudit.split(/\r?\n/).slice(-1)[0]);
  pass('FAC-010', pilotAudit.split(/\r?\n/).slice(-1)[0]);
  pass('FAC-011', 'PILOT-RUN-001 retained and PILOT-RUN-002 passing evidence remains manifest-bound.');
  pass('FAC-012', `${jsonFiles.length} JSON source files passed duplicate-key-aware parsing.`);
  pass('FAC-013', `${jsFiles.length} JavaScript source files passed Node syntax checking.`);
  pass('FAC-014', `${markdownFiles.length} Markdown files passed fence checks; ${checkedLinks} local links resolved or point to planned rc.2 audit outputs.`);
  pass('FAC-015', 'Twelve Final normative documents contain no unfinished authoring marker.');
  pass('FAC-016', '503 manifest paths independently verified as safe NFC and strictly UTF-8 bytewise POSIX ordered.');
  pass('FAC-017', 'Every manifest digest and size matches an independent current-source read.');
  pass('FAC-018', `Builder completed two independent scans/reads/builds and Final audit independently reproduced archive ${sha256(archiveBytes)} byte-for-byte.`);
  pass('FAC-019', 'All five checksum subjects, build report, manifest, and release identity reconcile.');
  pass('FAC-020', 'Compatibility matrix has 13 explicit surfaces, including the exact rc.2 release toolchain.');
  pass('FAC-021', 'Migration/adoption contract preserves identities, applicability, evidence, authority, rollback, and recovery.');
  pass('FAC-022', 'Operations/support/maintenance/deprecation/incident ownership is specified.');
  pass('FAC-023', 'Limitations, claim boundaries, remaining risks, and additional-pilot decision are explicit.');
  pass('FAC-024', 'Handoff assets, recipients, prohibited actions, and reopen triggers are explicit.');
  pass('FAC-025', 'Candidate makes no fabricated production, certification, or universal-fitness claim.');
  pass('FAC-026', 'Generated baseline candidate validates and binds exact archive, manifest, build-report, and aggregate source digests.');
  pass('FAC-027', 'Generated authority packet validates, binds all exact subjects plus baseline packet digest, and remains unsigned/pending.');
  pass('FAC-028', 'Automation authority is NONE; no approval, risk acceptance, release authorization, or baseline establishment occurred.');
  pass('FAC-029', 'Final framework assets add no logical project artifact IDs; catalog remains 281.');
  results.push(criterion(criteriaCatalog.criteria, 'FAC-030', 'PENDING_AUTHORITY', 'Product OS Authority must decide against the exact release-bound digests after all four audits pass.'));
  assert.strictEqual(results.filter((item) => item.result === 'PASS').length, 29);
  assert.strictEqual(results.filter((item) => item.result === 'PENDING_AUTHORITY').length, 1);

  const report = {
    report_id: 'PRODUCT-OS-V1-FINAL-AUDIT-002', release_id: releaseId, release_version: releaseVersion,
    audited_at: new Date().toISOString(), audit_runtime_node: process.versions.node,
    technical_result: 'PASS_WITH_AUTHORITY_PENDING', source_file_count: 503,
    source_json_count: jsonFiles.length, source_javascript_count: jsFiles.length,
    source_markdown_count: markdownFiles.length, checked_local_link_count: checkedLinks,
    release_archive_sha256: sha256(archiveBytes), release_manifest_sha256: sha256(manifestBytes),
    release_build_report_sha256: sha256(buildReportBytes), baseline_candidate_sha256: sha256(baselineBytes),
    authority_decision_packet_sha256: sha256(authorityBytes), independent_final_rebuild_byte_identical: true,
    rc1_preservation: 'PASS', automation_tests: automationTests, automation_audit: automationAudit,
    pilot_audit: pilotAudit, criterion_count: 30, criteria_passed: 29,
    criteria_pending_authority: 1, criteria_failed: 0, criteria: results,
    product_os_authority_approval: 'NOT_PERFORMED', product_os_baseline: 'NOT_ESTABLISHED',
    next_action: 'RUN_BINARY_ADVERSARIAL_EXPERT_AUDITS_THEN_PRODUCT_OS_AUTHORITY_REVIEW'
  };
  if (writeReport) {
    assert.ok(!fs.existsSync(reportFile), `Audit report will not be overwritten: ${reportFile}`);
    fs.mkdirSync(path.dirname(reportFile), { recursive: true });
    fs.writeFileSync(reportFile, `${JSON.stringify(report, null, 2)}\n`, { flag: 'wx' });
  }
  process.stdout.write(`FINAL AUDIT PASS_WITH_AUTHORITY_PENDING release=${releaseId} source_files=503 criteria_pass=29 pending_authority=1 archive_sha256=${sha256(archiveBytes)} rc1_preserved=true\n`);
}

main().catch((error) => {
  process.stderr.write(`FINAL_AUDIT_ERROR ${error.stack}\n`);
  process.exitCode = 1;
});
