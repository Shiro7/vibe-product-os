#!/usr/bin/env node
'use strict';

const assert = require('assert');
const childProcess = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const format = require('./release-format');
const { SchemaValidator } = require('../../Automation_Commands/lib/schema-validator');

const releaseId = 'Product-OS-v1.0-rc.2';
const finalRoot = path.resolve(__dirname, '..');
const releaseRoot = path.join(finalRoot, 'releases', releaseId);
const reportFile = path.join(finalRoot, 'verification', 'rc.2', 'adversarial-audit-report.json');

function parseArgs(argv) {
  let selected = releaseId;
  let writeReport = false;
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--release-id') { if (!argv[index + 1]) throw new Error('--release-id requires a value.'); selected = argv[index + 1]; index += 1; }
    else if (argv[index] === '--write-report') writeReport = true;
    else if (argv[index] === '--help') { process.stdout.write(`Usage: node scripts/audit-adversarial.js [--release-id ${releaseId}] [--write-report]\n`); process.exit(0); }
    else throw new Error(`Unknown adversarial-audit option ${argv[index]}.`);
  }
  if (selected !== releaseId) throw new Error(`This audit is pinned to ${releaseId}.`);
  return { writeReport };
}

function sha256(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function expectReject(id, action, results) {
  let rejected = false;
  let message = '';
  try { action(); }
  catch (error) { rejected = true; message = error.message; }
  assert.ok(rejected, `${id} was not rejected.`);
  results.push({ test_id: id, result: 'PASS', observed_rejection: message });
}

function expectProcessReject(id, args, results) {
  const child = childProcess.spawnSync(process.execPath, args, { cwd: finalRoot, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
  assert.notStrictEqual(child.status, 0, `${id} process unexpectedly passed.`);
  results.push({ test_id: id, result: 'PASS', observed_rejection: (child.stderr || child.stdout).trim().split(/\r?\n/)[0] });
}

function validate(schema, value) {
  const validator = new SchemaValidator(new Map([[schema.$id, schema]]));
  return validator.validate(schema, value, schema);
}

function main() {
  const { writeReport } = parseArgs(process.argv.slice(2));
  assert.ok(fs.existsSync(releaseRoot), 'rc.2 must exist before adversarial audit.');
  const results = [];

  expectProcessReject('ADV-001-EXISTING-RELEASE-REFUSAL', ['scripts/build-release.js', '--release-id', releaseId], results);
  expectProcessReject('ADV-002-UNPINNED-RELEASE-REFUSAL', ['scripts/build-release.js', '--release-id', 'Product-OS-v1.0-rc.1', '--dry-run'], results);
  expectProcessReject('ADV-003-UNKNOWN-BUILDER-OPTION', ['scripts/build-release.js', '--unexpected'], results);
  expectProcessReject('ADV-004-UNKNOWN-FINAL-AUDIT-OPTION', ['scripts/audit-final.js', '--unexpected'], results);

  for (const [id, unsafe] of [
    ['ADV-005-ABSOLUTE-PATH', '/etc/passwd'],
    ['ADV-006-PARENT-SEGMENT', 'a/../b'],
    ['ADV-007-DOT-SEGMENT', 'a/./b'],
    ['ADV-008-BACKSLASH', 'a\\b'],
    ['ADV-009-CONTROL-CHARACTER', 'a\u0000b'],
    ['ADV-010-NON-NFC', 'cafe\u0301/file']
  ]) expectReject(id, () => format.validateRelativePath(unsafe), results);

  const entry = { path: 'root/file.txt', content: Buffer.from('evidence'), mode: 0o644, mtime: 1786852800 };
  expectReject('ADV-011-DUPLICATE-TAR-PATH', () => format.createUstar([entry, entry]), results);
  const tar = format.createUstar([entry]);
  const badHeader = Buffer.from(tar);
  badHeader[0] ^= 1;
  expectReject('ADV-012-TAR-HEADER-CHECKSUM', () => format.parseUstar(badHeader), results);
  const gzip = format.createCanonicalGzip(tar);
  const badGzipHeader = Buffer.from(gzip);
  badGzipHeader[9] = 3;
  expectReject('ADV-013-GZIP-HEADER', () => format.inspectCanonicalGzip(badGzipHeader), results);
  const badGzipCrc = Buffer.from(gzip);
  badGzipCrc[badGzipCrc.length - 8] ^= 1;
  expectReject('ADV-014-GZIP-CRC', () => format.inspectCanonicalGzip(badGzipCrc), results);
  const badGzipLength = Buffer.from(gzip);
  badGzipLength[badGzipLength.length - 4] ^= 1;
  expectReject('ADV-015-GZIP-ISIZE', () => format.inspectCanonicalGzip(badGzipLength), results);

  const unsorted = ['z/path', 'A/path'];
  expectReject('ADV-016-UNSORTED-MANIFEST', () => {
    for (let index = 1; index < unsorted.length; index += 1) assert.ok(format.compareUtf8Path(unsorted[index - 1], unsorted[index]) < 0, 'Manifest path order is not UTF-8 bytewise.');
  }, results);

  const baselineSchema = JSON.parse(fs.readFileSync(path.join(finalRoot, 'config', 'baseline-candidate.schema.json'), 'utf8'));
  const authoritySchema = JSON.parse(fs.readFileSync(path.join(finalRoot, 'config', 'authority-decision-packet.schema.json'), 'utf8'));
  const baseline = JSON.parse(fs.readFileSync(path.join(releaseRoot, 'baseline-candidate.json'), 'utf8'));
  const authority = JSON.parse(fs.readFileSync(path.join(releaseRoot, 'authority-decision-packet.json'), 'utf8'));
  assert.deepStrictEqual(validate(baselineSchema, baseline), []);
  assert.deepStrictEqual(validate(authoritySchema, authority), []);
  const missingDigest = structuredClone(authority);
  delete missingDigest.subject_binding.archive.sha256;
  assert.ok(validate(authoritySchema, missingDigest).some((error) => error.keyword === 'required'));
  results.push({ test_id: 'ADV-017-MISSING-AUTHORITY-DIGEST', result: 'PASS', observed_rejection: 'Schema required-property failure.' });
  const extraProperty = structuredClone(authority);
  extraProperty.subject_binding.unbound_subject = 'prohibited';
  assert.ok(validate(authoritySchema, extraProperty).some((error) => error.keyword === 'additionalProperties'));
  results.push({ test_id: 'ADV-018-UNDECLARED-AUTHORITY-SUBJECT', result: 'PASS', observed_rejection: 'Schema additional-properties failure.' });
  const falseBaseline = structuredClone(baseline);
  falseBaseline.baseline_established = true;
  assert.ok(validate(baselineSchema, falseBaseline).some((error) => error.keyword === 'const'));
  results.push({ test_id: 'ADV-019-AUTOMATED-BASELINE-ESTABLISHMENT', result: 'PASS', observed_rejection: 'Schema const failure.' });

  const archive = fs.readFileSync(path.join(releaseRoot, `${releaseId}.tar.gz`));
  const tampered = Buffer.from(archive);
  tampered[Math.floor(tampered.length / 2)] ^= 1;
  assert.notStrictEqual(sha256(tampered), authority.subject_binding.archive.sha256);
  results.push({ test_id: 'ADV-020-TAMPERED-SUBJECT-DIGEST', result: 'PASS', observed_rejection: 'Bound SHA-256 mismatch.' });
  assert.strictEqual(results.length, 20);

  const report = {
    report_id: 'PRODUCT-OS-V1-ADVERSARIAL-AUDIT-002', release_id: releaseId, release_version: '1.0.0-rc.2',
    audited_at: new Date().toISOString(), technical_result: 'PASS', test_count: results.length,
    tests_passed: results.length, tests_failed: 0, mutation_scope: 'IN_MEMORY_OR_FAILURE_CLOSED_SUBPROCESS_ONLY',
    source_mutations: 0, release_mutations: 0, tests: results,
    authority_approval: 'NOT_PERFORMED', baseline_state: 'NOT_ESTABLISHED'
  };
  if (writeReport) {
    assert.ok(!fs.existsSync(reportFile), `Audit report will not be overwritten: ${reportFile}`);
    fs.mkdirSync(path.dirname(reportFile), { recursive: true });
    fs.writeFileSync(reportFile, `${JSON.stringify(report, null, 2)}\n`, { flag: 'wx' });
  }
  process.stdout.write(`ADVERSARIAL AUDIT PASS release=${releaseId} tests=${results.length} source_mutations=0 release_mutations=0\n`);
}

try { main(); }
catch (error) { process.stderr.write(`ADVERSARIAL_AUDIT_ERROR ${error.stack}\n`); process.exitCode = 1; }
