# Product OS v1.0 — Security, Access, Retention, and Incident Response

~~~yaml
document_id: PRODUCT-OS-V1-SECURITY-ACCESS-RETENTION-INCIDENT
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
distribution_integrity: SHA_256
external_signing: NOT_CONFIGURED
~~~

# 1. Threat Boundary

Relevant threats include modified distributions, manifest substitution, path traversal, malicious YAML/JSON, unsafe symlinks, leaked evidence, secret-bearing project files, compromised automation runtime, unauthorized authority records, supply-chain tampering, and unreviewed native adapters.

# 2. Distribution Trust

- obtain candidate/release through an authorized channel;
- verify published SHA-256 and authority decision;
- extract to a new root with traversal/device/symlink rejection;
- verify every manifest entry;
- retain immutable archive and manifest;
- do not execute scripts from an unverified distribution;
- external signing/trusted timestamping must be added before claiming cryptographic signer identity.

# 3. Runtime Security

Automation has no third-party runtime dependency, performs local schema resolution, rejects duplicate keys and unsafe YAML features, bounds paths, blocks overwrite, stages migration, archives additively, and emits no approval. Projects still secure Node, filesystem, CI runner, repository, and evidence access.

# 4. Access

Framework source may be broadly readable according to organizational policy. Project instances and pilot/release evidence follow classification and least privilege. Authority packets, accepted risks, incident records, sensitive evidence, and private native locators may require narrower access. Access to read a file does not grant authority to change or approve it.

# 5. Secrets and Personal Data

Do not store credentials in framework/project Markdown, JSON, YAML, logs, reports, examples, or archives. Reference approved secret stores by identity. Lint findings report category/location without value. Personal or regulated evidence follows purpose limitation, minimization, legal basis, access, retention, and disposal policy.

# 6. Retention

Retain approved release archive, manifest, checksum, decision, baseline, compatibility/migration guidance, final audit, pilot passing run, retained failed run, and release notes for the governed framework lifetime plus required historical period. Legal hold overrides normal disposal.

# 7. Vulnerability Response

1. Receive confidential report and preserve evidence.
2. Identify affected release/component/command/project scope.
3. Assess exploitability, authority, data, and distribution impact.
4. Contain compromised channel/runtime/adapter.
5. Prepare compatible patch or breaking remediation.
6. Run impact, regression, final audit, rebuild, and authority release.
7. Communicate affected users without disclosing exploit-sensitive details prematurely.
8. Revoke or mark compromised distributions and verify recovery.

# 8. Incident Response

Incidents involving unauthorized approval, evidence alteration, archive mismatch, unsafe mutation, secret emission, or scope escape are blocking. Preserve exact bytes/logs, stop affected automation/distribution, route through AI/security/change/source-evidence contracts, and reopen affected baselines/gates.

# 9. Current Limitation

This candidate supplies SHA-256 integrity and deterministic local provenance. It does not yet include an external signing identity, transparency log, hardware-backed key, trusted timestamp, or public distribution channel. Final authority must accept this limitation, add a signing process, or condition publication.
