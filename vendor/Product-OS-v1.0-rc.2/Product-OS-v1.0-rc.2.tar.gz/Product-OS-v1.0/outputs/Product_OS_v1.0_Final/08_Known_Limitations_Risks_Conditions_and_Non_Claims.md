# Product OS v1.0 — Known Limitations, Risks, Conditions, and Non-Claims

~~~yaml
document_id: PRODUCT-OS-V1-LIMITATIONS-RISKS-NONCLAIMS
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
known_limitation_count: 11
automatic_risk_acceptance: false
~~~

# 1. Known Limitations

1. Pilot evidence is synthetic and local, not a real multidisciplinary delivery project.
2. Spec Kit, Figma, GitHub, CI, cloud, observability, deployment, and operations adapters are mapped but not installed as live integrations.
3. Enterprise-scale repository/graph performance is not established.
4. Legal, regulatory, security, privacy, accessibility, financial, and industry certification require domain authorities and project evidence.
5. External cryptographic signing and trusted timestamping are not configured.
6. Organizational support owners, service levels, and distribution channel remain authority assignments.
7. Working Draft status remains in historical component documents until final authority promotes the distribution.
8. Project adoption usability and training effectiveness are not proven by synthetic fixtures.
9. Archive restoration and canonical migration cutover are specified and bounded but not exercised against a live project.
10. Conditional profiles beyond the representative P1/P2/P3 synthetic scenarios require project applicability and assurance.
11. Release-build and audit reproducibility is verified on exact Node.js 25.2.1 only; the Automation package's broader declared Node.js range is not represented as release-verified without separate CI evidence.

# 2. Principal Risks

- Users may treat P1 as reduced governance rather than reduced packaging.
- Teams may copy all 281 artifacts as mandatory files.
- Schema validity may be mistaken for truth, compliance, or approval.
- Tool mappings may be mistaken for synchronized live integrations.
- A green command/pilot may be mistaken for gate/release authority.
- Working Draft histories may confuse recipients without the final manifest/baseline record.
- Local SHA-256 may be trusted without authentic channel/signing.
- Projects may reuse synthetic fixture decisions or authorities.
- Unsupported customizations may fork canonical IDs and contracts.
- Finalization pressure may bypass a required real-project pilot.

# 3. Required Controls

Use the Product Constitution, profile/applicability contracts, release manifest, authority decision, project framework lock, validation/reconciliation, training, migration, support, and change processes. Never publish the archive alone without version, digest, compatibility, non-claims, and authority status.

# 4. Conditions for Final Authority

Authority must decide:

- whether synthetic pilot evidence is sufficient;
- whether external signing is required before publication;
- who owns support, security, change, and distribution;
- whether any domain or real-project pilot is mandatory;
- the support/deprecation window;
- accepted residual risks and conditions.

# 5. Non-Claims

Product OS v1.0 does not guarantee product success, correctness of project facts, regulatory compliance, absence of vulnerabilities, accessibility conformance, performance, operational availability, or complete evidence. It provides governed methods, contracts, traceability, evidence, automation, and decision boundaries for projects to establish those outcomes.

# 6. Risk Acceptance Boundary

Listing a limitation does not accept it. Acceptance occurs only through an authorized risk/decision record with scope, rationale, duration, mitigation, monitoring, and reopen conditions.
