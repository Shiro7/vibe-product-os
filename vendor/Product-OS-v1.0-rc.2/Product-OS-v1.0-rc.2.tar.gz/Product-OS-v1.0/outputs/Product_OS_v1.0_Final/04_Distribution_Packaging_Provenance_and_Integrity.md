# Product OS v1.0 — Distribution, Packaging, Provenance, and Integrity

~~~yaml
document_id: PRODUCT-OS-V1-DISTRIBUTION-INTEGRITY
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
archive_format: POSIX_USTAR_GZIP
hash_algorithm: SHA_256
release_manifest_ref: releases/Product-OS-v1.0-rc.2/release-manifest.json
~~~

# 1. Package Contents

The distribution archive contains the complete sorted Product OS source snapshot under `Product-OS-v1.0/outputs/` plus `Product-OS-v1.0/RELEASE-MANIFEST.json`. Generated release and verification directories are excluded from their own source scan to prevent recursion.

# 2. Deterministic Build

The canonical builder is pure Node.js 25.2.1 and declares zero external commands. It uses:

- safe NFC-normalized relative paths ordered by raw UTF-8 bytes in POSIX order;
- original file bytes;
- normalized file modes: 0644, or 0755 for executable scripts;
- uid/gid 0 and empty owner/group names;
- fixed modification time;
- POSIX ustar headers;
- zero padding to 512-byte blocks and two terminal blocks;
- canonical stored-DEFLATE gzip, mtime 0, and OS byte 255;
- identical embedded and external manifest bytes.

The builder performs two fresh directory scans, two fresh source reads, two manifests, and two archive builds. It blocks publication unless both manifests and archives are byte-identical. The Final audit then rebuilds independently from the frozen source.

# 3. Release Manifest

Each source entry records relative path, media role, bytes, normalized mode, and SHA-256. The manifest also records release identity, counts, aggregate source bytes, framework counts, pilot identity, authority/baseline status, and build rules.

# 4. Generated Files

| File | Purpose |
|---|---|
| `Product-OS-v1.0-rc.2.tar.gz` | deterministic distribution candidate |
| `release-manifest.json` | exact source membership and digests |
| `release-build-report.json` | build identity, sizes, archive digest, reproducibility |
| `baseline-candidate.json` | schema-validated release-bound baseline candidate |
| `authority-decision-packet.json` | schema-validated pending authority packet bound to every exact subject |
| `SHA256SUMS` | checksums for all five preceding release subjects |
| `verification/rc.2/final-audit-report.json` | acceptance criteria and independent rebuild evidence |
| `verification/rc.2/binary-audit-report.json` | gzip, ustar, manifest, checksum, and content evidence |
| `verification/rc.2/adversarial-audit-report.json` | failure-closed negative and tamper evidence |
| `verification/rc.2/expert-audit-report.json` | blocker disposition and authority-readiness review |

# 5. Provenance

The build report separates the actual execution time from the fixed reproducible archive timestamp. It records exact Node/runtime platform, builder and toolchain source digests, source aggregate, counts, manifest/archive digests, both independent builds, and the empty external-command list. This local candidate does not claim cross-runtime reproducibility, external signing, trusted timestamping, SLSA level, or remote build provenance.

# 6. Recipient Verification

1. Obtain archive and `SHA256SUMS` through an authorized channel.
2. Verify SHA-256 before extraction.
3. Extract into a new empty directory.
4. Reject absolute paths, `..` traversal, symlinks, and device entries.
5. Verify each extracted file against `RELEASE-MANIFEST.json`.
6. Retain the manifest and authority/baseline record with the installed framework lock.

# 7. Publication Boundary

The candidate archive may be shared for authority evaluation under appropriate access controls. It must not be labeled approved/baselined `1.0.0` until authority binds the exact archive digest.

# 8. Rebuild Rule

If any source changes, discard the prior candidate from promotion, create a new candidate identity, rebuild, rerun FAC-001..029, and seek a decision for the new digest. Never replace bytes behind an existing checksum.
