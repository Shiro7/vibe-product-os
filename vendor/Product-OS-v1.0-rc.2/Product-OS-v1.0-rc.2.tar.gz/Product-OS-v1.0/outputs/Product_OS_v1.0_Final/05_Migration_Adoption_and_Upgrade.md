# Product OS v1.0 — Migration, Adoption, and Upgrade

~~~yaml
document_id: PRODUCT-OS-V1-MIGRATION-ADOPTION-UPGRADE
version: 1.0.0-rc.2
status: RELEASE_CANDIDATE
adoption_modes: [NEW_PROJECT, EXISTING_PRODUCT_OS_DRAFT, BROWNFIELD_OVERLAY, FEDERATED]
canonical_profiles: [P1, P2, P3]
~~~

# 1. Adoption Principle

Adopt one stable Product OS structure and activate only applicable artifacts/modules. Do not copy every framework file into a project or turn P3 into the default. Logical identities remain canonical; physical packaging follows P1/P2/P3 and domain overrides.

# 2. New Project

1. Verify the approved distribution digest.
2. Pin framework release and catalog/schema digests.
3. Run `product-os init` dry-run, then authorized apply.
4. Complete real Phase 00 project identity, ownership, authority, topology, GOV-001, GOV-009, and profile decisions.
5. Activate artifacts through GOV-002 and profile composition.
6. Run validate, reconcile, lint, and strict doctor.
7. Enter G0 authority review; initialization does not pass G0 automatically.

# 3. Existing Product OS Working Draft

- inventory current IDs, versions, local variants, links, decisions, and evidence;
- map legacy L1/L2/L3 to P1/P2/P3;
- preserve accepted project facts and authority records;
- compare catalogs/contracts/schemas and classify changes;
- use digest-pinned staged migration for machine records;
- validate/reconcile/graph before any canonical cutover;
- retain the previous baseline and explicit rollback route.

# 4. Brownfield Overlay

Do not restructure a live product repository on first adoption. Register current repositories/native systems, map existing artifacts to canonical IDs, classify gaps and N/A candidates, select profile/domain overrides, and create an overlay control plane. Migrate physical locations only when ownership, benefit, risk, and rollback justify it.

# 5. Compatibility Assessment

Classify each existing item as compatible, compatible with normalization, requires migration, superseded, duplicate, conflict, proposed N/A, or external native. No item becomes N/A because it lacks a Product OS-shaped file.

# 6. Cutover

Migration commands stage only. Canonical cutover requires:

- complete staged validation;
- source/staged digest comparison;
- trace/change/evidence impact review;
- owners and affected authorities;
- freeze window where required;
- tested rollback;
- updated framework lock/register/index/mappings;
- handoff and acknowledgement;
- post-cutover verification.

# 7. Rollback

Rollback restores the last approved project/framework baseline, not an arbitrary folder copy. Verify digests, restore pointers and native identities, rerun validation/reconciliation/graph, record impact and incident/change evidence, and reopen affected gates.

# 8. Upgrade Policy

Patch upgrades follow compatibility evidence and targeted regression. Minor/major upgrades require change impact, migration plan, project applicability, authority, staging, tests, baseline update, and handoff. Projects may remain pinned during a supported window; silent auto-upgrade is prohibited.

# 9. Pilot-to-Adoption Boundary

Synthetic pilot fixtures are not project templates containing approved business decisions. Projects reuse contracts, schemas, commands, and structure—not synthetic names, authorities, outcomes, requirements, or evidence.
