# Product OS v1.0 — Methodology Specification
## Phase 02: Business Architecture

**Phase ID:** `PHASE-02`  
**Phase Name:** `Business Architecture`  
**Version:** `1.1`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G2 — Business Baseline`  
**Primary Baseline:** `BBL — Business Baseline`  
**Primary Outcome:** تحويل الـvalidated problem model والـdesired outcomes والـapplicable cross-cutting obligations إلى business operating model واضح وقابل للتتبع يحدد القدرات والعمليات والأدوار والقواعد والقرارات والضوابط والمعلومات اللازمة قبل تعريف المنتج أو كتابة المتطلبات النظامية.

**v1.1 Closure Scope:** إضافة standards inheritance وbusiness-level applicability linkage وتحديث G2 بحيث لا تنتقل obligations إلى Phase 03 أو Phase 04 بدون canonical business representation.

---

# 1. Purpose

الغرض من Phase 02 هو الإجابة على السؤال:

> **How must the business or operating domain work in order to achieve the validated outcomes identified in Discovery?**

Phase 01 أثبتت:

```text
WHAT IS WRONG?
WHY DOES IT MATTER?
WHAT OUTCOME IS REQUIRED?
```

Phase 02 تحدد:

```text
WHAT BUSINESS CAPABILITIES ARE NEEDED?
WHO DOES WHAT?
WHAT BUSINESS EVENTS TRIGGER WORK?
WHAT VALUE FLOWS THROUGH THE ORGANIZATION?
WHAT RULES GOVERN THE WORK?
WHAT DECISIONS MUST BE MADE?
WHAT CONTROLS MUST EXIST?
WHAT INFORMATION MUST BE KNOWN?
WHAT PROCESS BOUNDARIES EXIST?
```

Phase 02 لا تصمم الـsoftware.

هي تصمم **business truth and operating logic** التي يجب أن يحترمها أي product أو system لاحقًا.

---

# 2. Position in Product OS

```text
PHASE 01
Discovery & Problem Definition
        │
        ▼
       G1
        │
        ▼
PHASE 02
Business Architecture
        │
        ▼
       G2
        │
   ┌────┴───────────────┐
   ▼                    ▼
Product Definition   Requirements Engineering
   │                    │
   └─────────┬──────────┘
             ▼
      Experience / Architecture
```

Phase 02 هي الطبقة التي تمنع Product Definition من التحول إلى feature brainstorming.

---

# 3. Core Business Architecture Question

Phase 02 تدور حول:

> **What business structure, capability, process, rule, responsibility, decision, information, and control model must exist to deliver the desired outcomes?**

---

# 4. Business Architecture Philosophy

Product OS يعتمد المبادئ التالية.

## BA-01 — Business Before System

لا يتم تعريف:

```text
Screen
API
Database Table
Microservice
```

قبل فهم:

```text
Business Capability
Business Rule
Business Decision
Business Responsibility
Business Information
```

---

## BA-02 — Capability Before Feature

Business Capability هي:

> قدرة business مستقرة نسبيًا يجب أن تملكها المؤسسة أو المنتج.

Feature هي طريقة Product لتنفيذ جزء من هذه القدرة.

مثال:

```text
Capability:
Manage Customer Credit
```

قد تنفذ بواسطة:

```text
Credit Limit Screen
Approval Workflow
API Validation
Alerting
Reports
```

لكن Capability ليست أي واحدة منهم.

---

## BA-03 — Rule Before Workflow Automation

Workflow لا يحدد business rule.

Business Rule هي التي تحكم workflow.

Example:

```text
BR-014:
Orders above the approved customer credit limit require authorized approval.
```

بعد ذلك نقرر كيف ينفذ النظام هذا rule.

---

## BA-04 — Role Before Permission

Business Role يصف responsibility في العمل.

System Permission يصف ما يسمح به النظام.

لا يتم خلطهما.

---

## BA-05 — Business Decision Before UI Choice

إذا business يحتاج Decision:

```text
Approve / Reject / Escalate
```

يجب تعريف:

- decision owner;
- criteria;
- inputs;
- authority;
- exception path.

قبل تصميم button باسم "Approve".

---

## BA-06 — Current State Is Not Target State

Phase 02 لا تنسخ الوضع الحالي كما هو.

هي تحدد:

```text
CURRENT BUSINESS MODEL
vs
TARGET BUSINESS MODEL
```

مع الحفاظ على traceability.

---

## BA-07 — Controls Are First-Class

في الأنظمة المالية، الحكومية، الإدارية، الصناعية، والحوكمة:

```text
Control
```

ليس تفصيلًا يضاف في QA.

هو جزء من Business Architecture.

---

## BA-08 — Exception Is Part of the Process

الـbusiness process لا يعتبر معرفًا إذا عرف happy path فقط بينما exceptions تغير:

- ownership;
- approval;
- financial effect;
- compliance;
- stock;
- customer entitlement.

---

## BA-09 — Business Objects Are Not Database Tables

Concept مثل:

```text
Contract
Invoice
Facility
Employee
Ownership Interest
Work Order
```

هو Business Information Concept.

قاعدة البيانات تأتي لاحقًا.

---

## BA-10 — Business Architecture Must Remain Technology-Neutral

الـbusiness model يجب أن يظل مفهومًا حتى لو تم تغيير:

```text
Cloud
Framework
Database
Vendor
Application
```

---

## BA-11 — Standards Obligations Must Enter at the Business Layer

Product OS Constitution والـUniversal Standards والـactivated Conditional Profiles ليست مراجع مؤجلة للـQA.

عندما ينشئ standard أو profile التزامًا business-facing، يجب أن تمثله Phase 02 كواحد أو أكثر من:

```text
Business Requirement
Business Rule
Business Control
Business Policy
Business Information Obligation
Business Evidence Obligation
```

ولا يجوز أن تبدأ Phase 04 باختراع هذا الالتزام من الصفر.

External source IDs may be retained for lineage، لكن Product OS يستخدم canonical IDs الخاصة به. مثال:

```text
External source: BR-A11Y-001
Product OS canonical object: BREQ-A11Y-001
```

---

# 5. Phase Objectives

بنهاية Phase 02 يجب أن يكون Product OS قادرًا على:

1. تحديد Business Scope.
2. تحديد Target Operating Model بالعمق المناسب.
3. تحديد Business Capabilities.
4. ربط Capabilities بالمشاكل والنتائج.
5. تحديد Value Streams أو major business flows.
6. تحديد Business Actors.
7. تحديد Business Roles.
8. تحديد Responsibilities.
9. تحديد major Business Processes.
10. تحديد Process Events.
11. تحديد Inputs وOutputs.
12. تحديد Business Decisions.
13. تحديد Business Rules.
14. تحديد Controls.
15. تحديد Exceptions.
16. تحديد Business Information Concepts.
17. تحديد business ownership of information.
18. تحديد Dependencies.
19. تحديد Cross-Functional Handoffs.
20. تحديد business-level KPIs.
21. تحديد target-state changes.
22. توثيق assumptions والopen decisions.
23. مراجعة Product OS Constitution والـapplicable standards/profiles من منظور business obligation.
24. تحويل الـapplicable obligations إلى canonical business requirements/rules/controls/policies.
25. تحديث `GOV-009 — Standards & Compliance Applicability Matrix` بالـbusiness linkage.
26. بناء BRD أو Business Architecture Pack المناسب للـprofile.
27. تجهيز handoff للـProduct Definition والـRequirements.
28. تمرير G2.

---

# 6. Phase Inputs

Required logical inputs:

```text
DISC-002 Discovery Findings
DISC-003 Stakeholder Map
DISC-004 Current-State Model
DISC-005 Problem Register
DISC-006 Cause & Hypothesis Register
DISC-007 Outcome & Success Model
DISC-008 Scope Hypothesis
G1 Decision
Risk Register
Assumption Register
Open Question Register
Source Register
Product OS Constitution
Universal Standards Catalog
Conditional Compliance Profile Catalog
GOV-009 Standards & Compliance Applicability Matrix
Phase 00/01 Applicability Triggers and Evidence
```

---

# 7. Entry Condition

Phase 02 تبدأ عندما:

```text
G1 = PASS
```

أو:

```text
G1 = PASS_WITH_CONDITIONS
```

والـconditions لا تمنع business modeling.

---

# 8. What Phase 02 Is Not

Phase 02 ليست:

- UI specification.
- User-story writing.
- API design.
- Database schema design.
- Software architecture.
- Technical NFR definition الكامل.
- Sprint planning.
- Coding.
- Figma.
- Detailed system permission matrix.
- Technology selection.
- Vendor selection.
- Final screen inventory.

قد تظهر implications لهذه الأشياء.

لكن لا يتم تصميمها هنا.

---

# 9. Business Architecture Object Model

Canonical objects:

```text
Business Objective
Business Outcome
Business Scope
Business Capability
Value Stream
Business Actor
Business Role
Responsibility
Business Event
Business Process
Business Activity
Business Decision
Business Rule
Business Control
Business Exception
Business Information Concept
Business KPI
Business Dependency
Business Policy
```

---

# 10. Business Objective

Business Objective يصف:

> ما النتيجة أو التغيير الذي تريد المؤسسة تحقيقه.

IDs:

```text
OBJ-001
OBJ-002
```

Example:

```text
OBJ-004:
Reduce order fulfillment delay while preserving credit and stock controls.
```

---

# 11. Objective Traceability

كل Business Objective يجب أن يرتبط على الأقل بـ:

```text
PRB
or
OUT
or
OPP
```

من Phase 01.

Example:

```text
PRB-004
   ↓
OUT-003
   ↓
OBJ-002
```

---

# 12. Objective vs KPI

Objective:

```text
Improve stock accuracy.
```

KPI:

```text
Inventory accuracy ≥ 99.5%.
```

لا يتم خلط الاثنين.

---

# 13. Business Scope

Business Scope يحدد:

```text
What business domains are being changed?
What business activities are affected?
Which organizational boundaries are involved?
What remains outside the initiative?
```

---

# 14. Business Scope vs Product Scope

```text
Business Scope:
What business capability/process/change is addressed?
```

```text
Product Scope:
What will the product include?
```

Product Scope يأتي في Phase 03.

---

# 15. Business Scope Record

```yaml
business_scope:
  in_scope:
    - "Sales order approval"
    - "Warehouse reservation"
    - "Customer credit control"

  out_of_scope:
    - "Employee payroll"

  adjacent:
    - "Procurement"

  uncertain:
    - "Customer collections automation"
```

---

# 16. Scope Rationale

كل عنصر مهم في Business Scope يحتاج:

```text
Problem
Outcome
Opportunity
Decision
```

كـrationale.

---

# 17. Target Operating Model

Phase 02 تحدد target operating model بالعمق المناسب.

الـTOM قد يغطي:

```text
People
Roles
Processes
Decisions
Controls
Information
Technology Touchpoints
Locations
Partners
Governance
Performance
```

لكن Technology Touchpoints هنا contextual فقط.

---

# 18. Current vs Target Operating Model

Canonical relationship:

```text
CURRENT
  ↓
GAP
  ↓
TARGET
```

لا نقفز مباشرة إلى Target بدون معرفة Gap.

---

# 19. Operating Model Change Types

```text
KEEP
IMPROVE
STANDARDIZE
AUTOMATE
REMOVE
CONSOLIDATE
SEPARATE
INTRODUCE
OUTSOURCE
CENTRALIZE
DECENTRALIZE
UNKNOWN
```

---

# 20. Business Capability

Definition:

> What the business must be able to do, independent of organization structure or technology implementation.

Example:

```text
Manage Customer Credit
Manage Inventory Reservation
Approve Exceptional Orders
Settle Vendor Payments
Govern Ownership Changes
```

---

# 21. Capability IDs

```text
CAP-001
CAP-002
```

---

# 22. Capability Naming Rule

Capability names يفضل أن تكون:

```text
Verb + Business Object
```

مثل:

```text
Manage Contracts
Approve Claims
Allocate Inventory
Monitor Compliance
```

وليس:

```text
Contract Screen
Dashboard
API Integration
```

---

# 23. Capability Hierarchy

يمكن استخدام:

```text
L0 DOMAIN CAPABILITY
L1 CAPABILITY
L2 SUB-CAPABILITY
```

Example:

```text
CAP-100 Order Management
    ├── CAP-110 Capture Orders
    ├── CAP-120 Validate Orders
    ├── CAP-130 Approve Orders
    └── CAP-140 Fulfill Orders
```

---

# 24. Capability Depth Rule

لا يتم تفصيل Capability Map حتى يصبح activity list متخفي.

إذا العنصر يصف خطوة عملية محددة جدًا، غالبًا هو Activity وليس Capability.

---

# 25. Capability Record

```yaml
capability_id: CAP-120

name: "Validate Customer Credit"

purpose:
  "Prevent unauthorized credit exposure."

supports:
  - OBJ-004

related_problems:
  - PRB-008

owner:
  role: FINANCE

maturity:
  current: LOW
  target: HIGH
```

---

# 26. Capability Maturity

Optional scale:

```text
M0 — ABSENT
M1 — AD_HOC
M2 — REPEATABLE
M3 — DEFINED
M4 — MANAGED
M5 — OPTIMIZED
```

لا يتم استخدام maturity scale إلا إذا يفيد decision making.

---

# 27. Capability Heatmap

Capabilities قد تصنف حسب:

```text
Strategic Importance
Current Maturity
Risk
Change Need
```

لكن الـheatmap ليست mandatory لكل مشروع.

---

# 28. Capability-to-Problem Rule

Capability جديدة أو modified يجب أن يكون لها justification.

إذا CAP لا ترتبط بأي:

```text
Problem
Outcome
Opportunity
Policy
Regulatory Need
```

تعتبر:

```text
UNJUSTIFIED_CAPABILITY
```

حتى يثبت العكس.

---

# 29. Value Stream

Value Stream يصف:

> End-to-end progression that creates value for a stakeholder.

Example:

```text
Customer Need
→ Order
→ Fulfillment
→ Delivery
→ Payment
```

---

# 30. Value Stream vs Process

Value Stream:

```text
High-level value progression.
```

Process:

```text
How work is performed.
```

لا يتم خلطهما.

---

# 31. Value Stream IDs

```text
VS-001
VS-002
```

---

# 32. Value Stream Record

```yaml
value_stream_id: VS-003

name: "Order to Fulfillment"

trigger:
  "Confirmed customer demand"

value_recipient:
  "Customer"

stages:
  - Validate Order
  - Reserve Stock
  - Approve
  - Fulfill
  - Deliver
```

---

# 33. Value Stream Stage

Value Stream Stage ليست Process Step بالضرورة.

Stage يصف:

```text
Meaningful value progression
```

---

# 34. Actor

Business Actor هو شخص أو جهة أو system boundary يتفاعل مع business domain.

Examples:

```text
Customer
Supplier
Employee
Regulator
Partner
External Agency
```

---

# 35. Role

Business Role يصف responsibility وليس شخصًا محددًا.

Examples:

```text
Sales Representative
Warehouse Supervisor
Finance Approver
Board Secretary
System Administrator
```

---

# 36. Actor vs Role

```text
Actor:
Who or what participates?
```

```text
Role:
What responsibility is being performed?
```

شخص واحد قد يحمل أكثر من Role.

---

# 37. Role IDs

```text
ROLE-001
ROLE-002
```

---

# 38. Role Record

```yaml
role_id: ROLE-014

name: "Finance Approver"

responsibilities:
  - RESP-021
  - RESP-022

authority:
  - "Approve exceptional credit exposure within delegated limit"

business_domain:
  - CREDIT_CONTROL
```

---

# 39. Responsibility

Responsibility هي obligation واضحة مرتبطة بـRole.

IDs:

```text
RESP-001
```

Example:

```text
RESP-017:
Verify customer credit eligibility before exceptional order approval.
```

---

# 40. Responsibility vs Task

Responsibility:

```text
Ongoing accountability.
```

Task:

```text
Discrete execution work.
```

---

# 41. RACI Usage

RACI يمكن استخدامه عند الحاجة.

لكن Product OS لا يفرض RACI لكل عملية.

إذا استخدم:

```text
R — Responsible
A — Accountable
C — Consulted
I — Informed
```

ويجب ألا يكون هناك أكثر من Accountable بدون rationale واضح.

---

# 42. Authority Model

كل قرار مادي يجب أن يعرف:

```text
Who can propose?
Who can approve?
Who can execute?
Who can override?
Who must be informed?
```

---

# 43. Delegated Authority

Delegation يجب أن تسجل عندما تؤثر على business decision.

Example:

```yaml
authority_id: AUTH-003

decision:
  "Approve customer credit exception"

role:
  "Finance Manager"

limit:
  "Up to 100,000 SAR"

above_limit:
  "CFO approval required"
```

---

# 44. Business Event

Business Event هو شيء يحدث ويبدأ أو يغير business behavior.

Examples:

```text
Order Submitted
Payment Received
Contract Expired
Stock Reached Minimum
Employee Joined
Ownership Transfer Requested
```

IDs:

```text
EVT-001
```

---

# 45. Event Types

```text
EXTERNAL
INTERNAL
TIME_BASED
STATE_CHANGE
EXCEPTION
REGULATORY
```

---

# 46. Event Record

```yaml
event_id: EVT-008

name: "Customer Credit Limit Exceeded"

type: STATE_CHANGE

triggers:
  - PROC-014
  - DEC-006
```

---

# 47. Business Process

Definition:

> A structured set of business activities that transforms input into a business outcome.

IDs:

```text
PROC-001
```

---

# 48. Process Naming

Prefer:

```text
Approve Customer Order
Receive Inventory
Close Payroll Cycle
Resolve Maintenance Request
```

ولا تستخدم screen names.

---

# 49. Process Hierarchy

```text
L0 — End-to-End Process
L1 — Major Process
L2 — Subprocess
L3 — Activity
```

---

# 50. Process Modeling Depth

Depth depends on:

```text
Risk
Complexity
Exception density
Automation need
Cross-functional handoffs
Control requirements
```

---

# 51. Process Contract

Major Process يجب أن يعرف:

```text
Purpose
Trigger
Inputs
Actors/Roles
Activities
Decisions
Rules
Controls
Outputs
Exceptions
KPIs
Dependencies
```

---

# 52. Process Example

```yaml
process_id: PROC-014

name: "Approve Exceptional Customer Order"

trigger:
  EVT-008

inputs:
  - customer_credit_status
  - order_value

roles:
  - ROLE-004
  - ROLE-014

decisions:
  - DEC-006

rules:
  - BR-021
  - BR-022

outputs:
  - APPROVED_ORDER
  - REJECTED_ORDER
  - ESCALATED_ORDER
```

---

# 53. Process State

Target process may be:

```text
CURRENT
TARGET
TRANSITIONAL
```

لا تخلط بينهم.

---

# 54. Current-State Process

يوثق:

```text
How work actually happens now.
```

---

# 55. Target-State Process

يوثق:

```text
How business should operate after change.
```

ولا يجب أن يحتوي تفاصيل UI أو implementation غير الضرورية.

---

# 56. Transitional Process

مهم للمشاريع التي تحتاج migration.

Example:

```text
Old ERP + New Module operate together for 3 months.
```

هذه حالة Business Architecture حقيقية وليست technical detail فقط.

---

# 57. Business Activity

Activity هي خطوة ذات معنى داخل Process.

IDs اختيارية في P1، وأكثر رسمية في P2/P3:

```text
ACT-001
```

---

# 58. Activity Contract

```text
Actor
Input
Action
Output
Rule
Decision
Control
Exception
```

---

# 59. Handoff

Cross-functional handoff يجب اعتباره hotspot.

Example:

```text
Sales → Warehouse
Warehouse → Finance
Finance → Delivery
```

كل handoff قد يحمل:

```text
Information loss
Delay
Ownership ambiguity
Control gap
```

---

# 60. Handoff Record

```yaml
handoff_id: HND-004

from:
  ROLE-003

to:
  ROLE-007

information:
  - ORDER
  - STOCK_REQUEST

acceptance_condition:
  "Order data complete and validated"
```

---

# 61. Business Decision

Definition:

> A business choice that determines what happens next based on information, rules, authority, and context.

IDs:

```text
DEC-001
```

---

# 62. Decision Example

```text
Should this order be approved despite exceeding the customer's credit limit?
```

---

# 63. Decision Contract

كل Decision مهم يجب أن يعرف:

```text
Question
Decision Owner
Inputs
Rules
Possible Outcomes
Authority
Escalation
Evidence
```

---

# 64. Decision Record

```yaml
decision_id: DEC-006

question:
  "Can the order proceed despite exceeded credit?"

owner:
  ROLE-014

inputs:
  - ORDER_VALUE
  - CUSTOMER_CREDIT_LIMIT
  - CUSTOMER_BALANCE

rules:
  - BR-021

outcomes:
  - APPROVE
  - REJECT
  - ESCALATE
```

---

# 65. Decision vs Approval

Approval هو نوع من Decision.

ليس كل Decision approval.

Examples:

```text
Classify
Route
Calculate
Select
Approve
Reject
Escalate
```

---

# 66. Decision Table

عندما Rule logic معقدة، يمكن استخدام Decision Table.

Example:

```text
Credit Exceeded? | Order Value | Authority | Outcome
No               | Any         | System    | Continue
Yes              | <= 100k     | Finance   | Review
Yes              | > 100k      | CFO       | Escalate
```

---

# 67. Business Rule

Definition:

> Declarative statement that constrains, derives, or governs business behavior.

IDs:

```text
BR-001
```

---

# 68. Business Rule Types

```text
CONSTRAINT
DERIVATION
ELIGIBILITY
CALCULATION
AUTHORITY
STATE_TRANSITION
TIMING
VALIDATION
CLASSIFICATION
OBLIGATION
PROHIBITION
```

---

# 69. Rule Example

```text
BR-021:
Orders that exceed the approved customer credit limit must not proceed
without approval from an authority within the applicable delegated limit.
```

---

# 70. Rule Quality Contract

Business Rule يجب أن يكون:

```text
Atomic
Unambiguous
Technology-neutral
Traceable
Testable where practical
Owned
Exception-aware
```

---

# 71. Bad Business Rule

```text
System should show warning and maybe ask manager.
```

هذا UI/implementation wording وغير حاسم.

---

# 72. Better Business Rule

```text
An order exceeding the approved credit threshold requires authorized approval before release.
```

---

# 73. Rule Ownership

كل material rule يجب أن يكون له:

```text
Business Owner
or
Policy Source
or
Regulatory Source
```

---

# 74. Rule Source

Rule source may be:

```text
POLICY
CONTRACT
REGULATION
MANAGEMENT_DECISION
OPERATING_MODEL
ACCOUNTING_RULE
DOMAIN_RULE
```

---

# 75. Rule Status

```text
PROPOSED
IN_REVIEW
APPROVED
REJECTED
DEPRECATED
SUPERSEDED
```

---

# 76. Rule Conflict

إذا Ruleين يتعارضان:

```text
BR-CONFLICT
```

يجب ألا يتم إخفاء التعارض داخل Process diagram.

---

# 77. Rule Exception

كل Business Rule مهم يجب تقييم:

```text
Can it be overridden?
By whom?
Under what conditions?
Is evidence required?
Is override auditable?
```

---

# 78. Exception Rule

Example:

```text
BR-022:
Credit-limit override above 100,000 SAR requires CFO approval and recorded justification.
```

---

# 79. Business Control

Definition:

> Mechanism designed to prevent, detect, correct, or evidence unacceptable business behavior or risk.

IDs:

```text
CTRL-001
```

---

# 80. Control Types

```text
PREVENTIVE
DETECTIVE
CORRECTIVE
APPROVAL
SEGREGATION_OF_DUTIES
RECONCILIATION
LIMIT
MONITORING
AUDIT
EVIDENCE
```

---

# 81. Control Example

```text
CTRL-009:
The person creating a supplier bank-account change may not approve the same change.
```

---

# 82. Control vs Rule

Rule:

```text
What must or must not happen.
```

Control:

```text
How the business reduces the risk that the rule is violated.
```

---

# 83. Segregation of Duties

Critical financial/governance flows يجب تقييم:

```text
Create
Approve
Execute
Reconcile
Audit
```

لتجنب conflict of interest.

---

# 84. Control Evidence

Control may require evidence such as:

```text
Approval record
Audit log
Reconciliation record
Signature
Attachment
System event
Reviewer identity
Timestamp
```

---

# 85. Business Exception

Definition:

> A legitimate or abnormal path that deviates from the standard business flow.

IDs:

```text
EXC-001
```

---

# 86. Exception Categories

```text
EXPECTED
RARE
CRITICAL
MANUAL_OVERRIDE
SYSTEM_FAILURE
POLICY_EXCEPTION
REGULATORY_EXCEPTION
DATA_EXCEPTION
```

---

# 87. Exception Contract

```text
Trigger
Affected Process
Business Impact
Allowed Action
Authority
Evidence
Recovery
Escalation
```

---

# 88. Exception Example

```yaml
exception_id: EXC-006

scenario:
  "Urgent order when credit service is unavailable"

allowed_action:
  "Manual approval path"

authority:
  ROLE-014

evidence_required:
  true
```

---

# 89. Happy-Path Completeness Rule

Process لا يعتبر business-ready إذا critical exceptions غير معروفة.

خصوصًا عندما تؤثر على:

```text
Money
Ownership
Stock
Entitlements
Security
Legal status
Approval
Audit
```

---

# 90. Business Information Concept

Definition:

> Business-level information object used or produced by business operations.

IDs:

```text
INFO-001
```

Examples:

```text
Customer
Contract
Order
Invoice
Employee
Property
Unit
Ownership Interest
Payment
Work Order
```

---

# 91. Information Concept vs Entity

Business Information Concept ليس database entity.

لاحقًا قد يتحول Concept واحد إلى عدة technical entities.

---

# 92. Information Concept Contract

```text
Name
Business Meaning
Owner
Source
Lifecycle
Key Business Attributes
Sensitivity
Related Processes
Related Rules
```

---

# 93. Business Definition

كل important term يحتاج definition.

Example:

```text
Contract:
A legally or operationally recognized agreement establishing obligations between defined parties.
```

ليس:

```text
contracts table.
```

---

# 94. Information Ownership

يجب معرفة:

```text
Who creates it?
Who owns it?
Who may change it?
Who validates it?
Who consumes it?
```

---

# 95. Source of Truth

For critical business information:

```text
AUTHORITATIVE_SOURCE
```

يجب تحديده إن أمكن.

Example:

```text
Employee legal name → HR Master Record
```

---

# 96. Information State

Business Objects قد تمر states.

Example:

```text
DRAFT
PENDING_APPROVAL
ACTIVE
SUSPENDED
CLOSED
CANCELLED
```

---

# 97. Business Lifecycle

إذا Object lifecycle مادي للbusiness، يتم توثيقه هنا.

Example:

```text
Contract:
Draft
→ Reviewed
→ Approved
→ Active
→ Expired / Terminated
```

---

# 98. State Transition Rule

Transitions قد تحكمها BRs.

Example:

```text
BR-044:
A contract cannot become ACTIVE until all mandatory approvals are completed.
```

---

# 99. Business Policy

Policy أعلى مستوى من Rule غالبًا.

Example:

```text
Credit Policy
Leave Policy
Procurement Policy
Governance Policy
```

Policy may produce multiple BRs.

---

# 100. Policy IDs

```text
POL-001
```

---

# 101. Business KPI

Business KPI measures business performance.

IDs:

```text
KPI-001
```

Examples:

```text
Order cycle time
Inventory accuracy
Claims rejection rate
Days sales outstanding
Payroll correction rate
```

---

# 102. KPI Traceability

KPI should link to:

```text
Objective
Outcome
Capability
Process
```

where relevant.

---

# 103. KPI Contract

```yaml
kpi_id: KPI-006

name: "Order Approval Cycle Time"

measures:
  PROC-014

unit:
  minutes

baseline:
  240

target:
  30

status:
  PROPOSED
```

---

# 104. KPI Integrity

AI may propose KPI.

AI must not invent baseline or target.

---

# 105. Business Dependency

Dependencies may include:

```text
Other department
External regulator
Bank
Supplier
Government platform
Partner system
Physical warehouse
Manual authority
External data provider
```

---

# 106. Business Dependency IDs

```text
BDEP-001
```

---

# 107. Dependency Contract

```text
Dependency
Owner
Required Capability
Criticality
Availability
Failure Impact
Fallback
```

---

# 108. External Boundary

Phase 02 يجب أن توضح:

```text
What is inside business control?
What is external?
```

حتى لا يحمل النظام مسؤولية شيء لا تملكه المؤسسة.

---

# 109. Business Architecture Workflow

Canonical workflow:

```text
02.0 Confirm Business Scope
        ↓
02.1 Define Business Objectives
        ↓
02.2 Identify Business Domains
        ↓
02.3 Build Capability Map
        ↓
02.4 Map Value Streams
        ↓
02.5 Define Actors, Roles & Responsibilities
        ↓
02.6 Model Current-to-Target Operating Changes
        ↓
02.7 Model Major Processes
        ↓
02.8 Define Decisions
        ↓
02.9 Define Business Rules
        ↓
02.10 Define Controls
        ↓
02.11 Define Exceptions
        ↓
02.12 Define Business Information
        ↓
02.13 Define KPIs
        ↓
02.14 Resolve Business Conflicts
        ↓
02.15 Produce BRD / Business Architecture Pack
        ↓
02.16 Validate Business Baseline
        ↓
02.17 Evaluate G2
        ↓
02.18 Generate Handoff
```

---

# 110. Step 02.0 — Confirm Business Scope

Discovery Scope Hypothesis تتحول إلى Business Scope proposal.

يتم:

```text
Confirm
Narrow
Expand
Split
Reject
```

مع rationale.

---

# 111. Business Domain

Domain هو coherent area of business responsibility.

Examples:

```text
Sales
Inventory
Payroll
Governance
Property Management
Facility Management
Procurement
Finance
```

IDs:

```text
DOM-001
```

---

# 112. Domain Boundary

Domain Boundary يجب أن يوضح:

```text
Responsibilities
Inputs
Outputs
Owned Information
Dependencies
Adjacent Domains
```

---

# 113. Domain vs Module

Domain ليس software module بالضرورة.

قد يصبح لاحقًا module أو bounded context أو عدة components.

---

# 114. Step 02.1 — Define Business Objectives

Discovery outcomes تتحول إلى explicit objectives.

Objective يجب أن يملك:

```text
Business Owner
Priority
Rationale
Success Link
```

---

# 115. Objective Priority

Suggested:

```text
CRITICAL
HIGH
MEDIUM
LOW
```

أو MoSCoW عند الحاجة.

Product OS لا يفرض scheme واحدة طالما semantics واضحة.

---

# 116. Step 02.2 — Identify Business Domains

نحدد business boundaries قبل توزيع capabilities.

---

# 117. Cross-Domain Capability

Capability قد تعبر أكثر من Domain.

Example:

```text
Approve Financial Exception
```

قد تشمل Sales + Finance.

يجب ألا يتم duplicate capability لكل department إذا هي نفسها.

---

# 118. Step 02.3 — Build Capability Map

Capability Map يجب أن يوضح:

```text
Domain
Capability
Sub-capability
Owner
Importance
Change Need
Related Objective
```

---

# 119. Capability Gap

Possible states:

```text
MISSING
WEAK
FRAGMENTED
MANUAL
DUPLICATED
UNCONTROLLED
ADEQUATE
STRONG
```

---

# 120. Step 02.4 — Map Value Streams

نختار فقط value streams ذات الصلة بالمشكلة.

لا نرسم كل business value stream إذا لا يؤثر.

---

# 121. Step 02.5 — Actors, Roles & Responsibilities

Roles يجب أن تأتي من business responsibility.

ليس من existing system role names وحدها.

Example:

```text
"Admin"
```

غالبًا technical role ضعيف المعنى business-wise.

يحتاج decomposition.

---

# 122. Generic Role Warning

Roles مثل:

```text
Admin
Manager
User
Moderator
```

يجب مراجعتها.

قد تكون صحيحة، لكن غالبًا تخفي responsibility ambiguity.

---

# 123. Step 02.6 — Current-to-Target Change

لكل major area:

```text
CURRENT
PAIN/GAP
TARGET
RATIONALE
```

---

# 124. Change Record

```yaml
change_id: BCHG-004

current:
  "Warehouse receives order screenshots."

target:
  "Warehouse receives validated order request from controlled business flow."

reason:
  PRB-003
```

---

# 125. Step 02.7 — Major Process Modeling

Process modeling يبدأ من:

```text
Trigger
```

وينتهي عند:

```text
Business Outcome
```

---

# 126. Process Boundary Rule

إذا process يبدأ وينتهي في أماكن عشوائية لأن diagram أصبح كبيرًا، boundary غير صحيحة.

---

# 127. Process Exception Coverage

Critical process يجب أن يحدد على الأقل:

```text
Normal Path
Business Rejection
Invalid Input
Authority Exception
Dependency Failure
Cancellation
```

حسب applicability.

---

# 128. Step 02.8 — Business Decisions

Business decisions التي تغير:

```text
Money
Rights
Ownership
Eligibility
Status
Approval
Risk
```

يجب أن تكون explicit.

---

# 129. Decision Authority Gap

Decision بلا owner:

```text
AUTHORITY_GAP
```

ويعتبر defect في Business Architecture.

---

# 130. Step 02.9 — Business Rules

Rules يجب استخراجها من:

```text
Policies
Decisions
Processes
Regulations
Contracts
Domain Knowledge
Exceptions
```

---

# 131. Rule Completeness

لكل rule مادي نسأل:

```text
When does it apply?
When does it not apply?
Who owns it?
Can it be overridden?
What happens if violated?
```

---

# 132. Step 02.10 — Controls

Controls يجب أن تتناسب مع Risk Class.

R3/R4 business flows تحتاج stronger control analysis.

---

# 133. Control Coverage

High-risk decision should not exist without evaluating:

```text
Authorization
Segregation
Evidence
Auditability
Recovery
```

---

# 134. Step 02.11 — Exceptions

Exceptions يتم modelها لأنها غالبًا تكتشف business truth الذي لا يظهر في policy.

---

# 135. Exception Frequency

Suggested:

```text
COMMON
OCCASIONAL
RARE
CRITICAL
UNKNOWN
```

Rare لا يعني unimportant.

---

# 136. Step 02.12 — Business Information

نحدد information اللازمة لاتخاذ decisions وتنفيذ processes.

---

# 137. Information Minimality

لا نعمل data dictionary تقني كامل هنا.

نحدد فقط business concepts والattributes المهمة business-wise.

---

# 138. Business Attribute

Examples:

```text
Contract Effective Date
Customer Credit Limit
Ownership Percentage
Invoice Due Date
Stock Quantity
```

---

# 139. Derived Business Information

إذا معلومة مشتقة:

```text
Available Credit = Credit Limit - Outstanding Exposure
```

يجب ربطها بـBusiness Rule أو calculation definition.

---

# 140. Step 02.13 — KPI Model

KPIs يجب أن تتبع Objectives وليس العكس.

---

# 141. Leading vs Lagging Indicators

يمكن التمييز:

```text
LEADING
LAGGING
```

إذا يفيد business decision.

---

# 142. Step 02.14 — Conflict Resolution

Business conflicts قد تكون:

```text
RULE_CONFLICT
AUTHORITY_CONFLICT
PROCESS_CONFLICT
POLICY_CONFLICT
OWNERSHIP_CONFLICT
SCOPE_CONFLICT
KPI_CONFLICT
CONTROL_CONFLICT
```

---

# 143. Conflict Resolution Record

يجب حفظ:

```text
Conflict
Options
Decision
Authority
Rationale
Affected Artifacts
```

---

# Standards-to-Business Linkage — Mandatory Phase 02 Activity

قبل إنشاء الـBRD baseline، Phase 02 يجب أن تراجع كل entry موجودة في `GOV-009` وتحدد أثرها على الـbusiness architecture.

المراجعة تسأل:

```text
Which constitutional and universal standards create business obligations?
Which conditional profiles are activated, pending, or not applicable?
What business requirement, rule, policy, control, information, or evidence obligation results?
Who owns and approves the business interpretation?
Which product implications must Phase 03 evaluate?
Which system requirements must Phase 04 derive?
```

## Applicability Outcomes

كل standard/profile يحصل على واحدة من:

```text
APPLICABLE
NOT_APPLICABLE
PENDING
```

`NOT_APPLICABLE` لا يعني silent omission. يجب تسجيل:

```text
Reason
Decision Owner
Evidence
Approval Status
Reopen Condition
```

## Business Link Types

```text
BREQ   Business Requirement
BR     Business Rule
CTRL   Business Control
POL    Business Policy
INFO   Business Information Obligation
EVID   Business Evidence Obligation
```

## Accessibility Business Linkage

عندما تكون Digital Accessibility applicable، Phase 02 لا تعيد كتابة الـstandard ولا تنشئ SRS requirements. هي تنشئ business obligations قابلة للتتبع، مثل:

```text
BREQ-A11Y-001 Keyboard-operable critical journeys
BREQ-A11Y-002 Screen-reader-compatible information and actions
BREQ-A11Y-003 Perceivable colour and contrast
BREQ-A11Y-004 Accessible forms, validation, and error recovery
BREQ-A11Y-005 Accessible generated documents where applicable
BREQ-A11Y-006 Accessible third-party journey continuity
```

كل obligation يجب أن تشير إلى source requirement/standard criterion بدل نسخ المصدر كـcanonical truth ثانية.

## Canonical Lineage

```text
STD / PROFILE
      ↓
GOV-009 Applicability Decision
      ↓
BREQ / BR / CTRL / POL / INFO / EVID
      ↓
Phase 03 Product Implication
      ↓
Phase 04 System Requirement
```

---

# 144. Step 02.15 — BRD

BRD في Product OS ليس feature list.

BRD هو formal business baseline.

---

# 145. BRD Purpose

BRD يجيب:

```text
Why does the initiative exist?
What business outcomes are required?
What business scope is affected?
What capabilities are required?
What business processes/rules/roles govern the domain?
What constraints and controls apply?
What business success looks like?
```

---

# 146. BRD Recommended Structure

```text
1. Executive Context
2. Business Problem & Opportunity
3. Business Objectives
4. Business Scope
5. Stakeholders & Authority
6. Business Domains
7. Capability Model
8. Value Streams
9. Target Operating Model
10. Business Processes
11. Roles & Responsibilities
12. Business Decisions
13. Business Rules
14. Controls
15. Standards & Compliance Business Applicability
16. Cross-Cutting Business Requirements
17. Exceptions
18. Business Information
19. Dependencies
20. KPIs / Success Measures
21. Risks & Assumptions
22. Open Business Decisions
23. Traceability
24. Approval / Validation
25. Downstream Handoff
```

---

# 147. BRD Boundary

BRD لا يحتوي عادةً:

```text
API endpoint definitions
Database tables
UI pixel specs
Framework selection
Detailed architecture
Sprint tasks
```

---

# 148. BRD vs SRS

```text
BRD:
Business must...
Business needs...
Business governs...
```

```text
SRS:
System shall...
System must...
```

---

# 149. BRD Traceability

Example:

```text
PRB-004
  ↓
OUT-002
  ↓
OBJ-003
  ↓
CAP-007
  ↓
PROC-011
  ↓
BR-018
```

ثم Phase 04:

```text
BR-018
  ↓
FR-041
```

---

# 150. Business Requirement

Phase 02 قد تنتج Business Requirements مختلفة عن System Requirements.

IDs:

```text
BREQ-001
BREQ-A11Y-001
BREQ-SEC-001
BREQ-PRIV-001
BREQ-AUD-001
```

Example:

```text
BREQ-014:
The organization must maintain an auditable approval record for exceptional credit decisions.
```

لاحقًا يتم derive system requirements.

---

# 151. Business Requirement vs Rule

Business Requirement:

```text
Required business capability/outcome/control.
```

Business Rule:

```text
Constraint or logic governing behavior.
```

---

# 152. Phase 02 Artifact Catalog

## BUS-001 — Business Requirements Document (BRD)

Primary consolidated business baseline.

---

## BUS-002 — Business Capability Map

Domains, capabilities, maturity/change need.

---

## BUS-003 — Value Stream Map

Relevant end-to-end value progression.

---

## BUS-004 — Target Operating Model

People, responsibilities, process, control, information.

---

## BUS-005 — Business Process Catalog

Major processes and subprocesses.

---

## BUS-006 — Business Rules Catalog

All governed business rules.

---

## BUS-007 — Business Decision Catalog

Decisions, criteria, authority, outcomes.

---

## BUS-008 — Roles & Responsibilities Model

Actors, roles, responsibilities, authority.

---

## BUS-009 — Business Control Register

Controls and evidence expectations.

---

## BUS-010 — Business Information Model

Business concepts, ownership, lifecycle.

---

## BUS-011 — KPI & Outcome Measurement Model

KPIs linked to objectives/outcomes.

---

## BUS-012 — Business Architecture Validation Record

Evidence of baseline validation.

---

# 153. Governance Registers Updated

Phase 02 updates:

```text
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-007 Change Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
```

`GOV-009` يبدأ في Phase 00، يتلقى discovery evidence في Phase 01، وتضيف Phase 02 إليه:

```text
Business Applicability Decision
Business Interpretation Owner
Derived Business Object IDs
Product Implications for Phase 03
System-Requirement Derivation Flags for Phase 04
Evidence and Reopen Conditions
```

---

# 154. P1 — Lean Behavior

P1 may use:

```text
BUSINESS ARCHITECTURE PACK
```

يجمع:

```text
Objectives
Scope
Capabilities
Major Processes
Roles
Rules
Controls
Information
KPIs
Applicable standards and cross-cutting business obligations
```

في artifact واحدة أو اثنتين.

---

# 155. P2 — Standard Behavior

Recommended independent artifacts:

```text
BUS-001
BUS-002
BUS-005
BUS-006
BUS-007
BUS-008
BUS-010
GOV-009 business linkage
```

والباقي حسب applicability.

---

# 156. P3 — Comprehensive Behavior

Adds:

```text
Full capability hierarchy
Formal value streams
Formal TOM
Process variants
Decision tables
Rule ownership
Control mapping
Segregation of duties
Business information ownership
Formal validation evidence
Independent approvals
Full traceability
Versioned business baseline
Independent standards applicability decisions
Standard-to-business-object coverage
Formal evidence for conditional-profile activation or exclusion
```

---

# 157. Business Architecture by Product State

Phase 02 تختلف حسب Product State.

---

# 158. S0 — Early Idea

غالبًا lightweight.

Focus:

```text
Business model
Target actors
Core value proposition
Core capabilities
High-level rules
Major assumptions
```

لا نخترع enterprise operating model لشركة غير موجودة.

---

# 159. S1 — New Product

Focus:

```text
Business domains
Target capabilities
Roles
Rules
Business objects
Value streams
Operating assumptions
```

---

# 160. S2 — Business Transformation

هذه أعمق حالة عادة.

Focus:

```text
Current-to-target operations
Departments
Processes
Controls
Responsibilities
Data ownership
Handoffs
Exceptions
```

---

# 161. S3 — Existing Product

Focus:

```text
Business capability gaps
Business rule mismatch
Process-to-product mismatch
Current product support
Missing control
Business information gaps
```

---

# 162. S4 — Implementation in Progress

Focus:

```text
Reconstruct intended business baseline
Compare implementation to business truth
Identify missing/incorrect rules
Authority gaps
Scope drift
```

---

# 163. S5 — Recovery

Focus:

```text
Critical business processes
Controls
Ownership
Decision authority
Business-rule failures
Operational continuity
```

---

# 164. S6 — Evolution

Focus:

```text
Affected business capability
Rule delta
Process delta
Role delta
Control delta
Information delta
```

بدل إعادة بناء Business Architecture بالكامل.

---

# 165. Business Architecture Validation

قبل G2 يجب أن يتم review بواسطة أصحاب authority المناسبين.

---

# 166. Validation Subjects

```text
Objectives
Scope
Capabilities
Processes
Roles
Decisions
Rules
Controls
Information
KPIs
Applicable Standards / Profiles
Cross-Cutting Business Requirements
```

حسب applicability.

---

# 167. Validation Types

```text
BUSINESS_OWNER_CONFIRMATION
DOMAIN_OWNER_CONFIRMATION
POLICY_CONFIRMATION
DOCUMENT_CONFIRMATION
REGULATORY_CONFIRMATION
CROSS_FUNCTIONAL_REVIEW
```

---

# 168. Business Truth Conflict

إذا Finance وOperations مختلفين حول Rule:

لا يتم كتابة wording عام.

يسجل:

```text
BUSINESS_CONFLICT
```

ويحتاج resolution أو explicit open decision.

---

# 169. G2 — Business Baseline Gate

الغرض:

> Determine whether the business model is defined sufficiently to support product and system definition without forcing design or engineering to invent business logic.

---

# 170. G2-01 Business Objectives

Major objectives واضحة ومربوطة بالـDiscovery.

---

# 171. G2-02 Business Scope

Business boundaries واضحة.

---

# 172. G2-03 Capability Coverage

كل objective مهم لديه capability coverage مناسب.

---

# 173. G2-04 Ownership

Major capabilities/processes لديها business ownership معروف.

---

# 174. G2-05 Roles & Responsibilities

Critical responsibilities ليست ambiguous.

---

# 175. G2-06 Process Coverage

Major business flows اللازمة للمرحلة التالية مفهومة.

---

# 176. G2-07 Business Decisions

Material decisions explicit ولها authority route.

---

# 177. G2-08 Business Rules

Critical business logic مسجلة وقابلة للتتبع.

---

# 178. G2-09 Control Coverage

Critical/high-risk flows لديها controls أو explicit control gaps.

---

# 179. G2-10 Exception Coverage

Material exceptions معروفة بدرجة كافية.

---

# 180. G2-11 Business Information

Key business concepts معرفة ومملوكة.

---

# 181. G2-12 Dependencies

Major business dependencies معروفة.

---

# 182. G2-13 KPI Direction

Major objectives لها success measure أو explicit measurement gap.

---

# 183. G2-14 Conflicts

No unresolved blocking business conflict.

---

# 184. G2-15 Open Questions

```text
Blocking Business Architecture Questions = 0
```

---

# 185. G2-16 Risk Review

Risk classification reviewed after business modeling.

---

# 186. G2-17 Downstream Readiness

Product Definition وRequirements يمكنهما العمل بدون inventing material business behavior.

---

# 186A. G2-18 Standards & Compliance Business Linkage

يتحقق G2 من أن:

```text
Applicable universal standards were reviewed.
Conditional profiles have explicit APPLICABLE / NOT_APPLICABLE / PENDING decisions.
Material business obligations have canonical BREQ/BR/CTRL/POL/INFO/EVID IDs.
GOV-009 contains owners, rationale, evidence, and reopen conditions.
Phase 03 product implications are explicit.
Phase 04 derivation obligations are explicit.
No mandatory standard is deferred silently to design, engineering, or QA.
```

`PENDING` قد يسمح بـ`PASS_WITH_CONDITIONS` فقط إذا لم يكن blocking للـProduct Definition أو Requirements Engineering. Otherwise G2 = `HOLD`.

---

# 187. G2 Outcomes

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

---

# 188. G2 PASS

Business baseline كافية للانتقال.

---

# 189. G2 PASS_WITH_CONDITIONS

Example:

```text
Detailed KPI baseline will be established during rollout planning.
```

إذا لا يمنع Product/Requirements definition.

---

# 190. G2 HOLD

Examples:

```text
No agreement on who owns customer credit approval.
```

أو:

```text
Business rule governing refund eligibility remains contradictory.
```

أو:

```text
Target process cannot be defined because policy decision is still open.
```

---

# 191. G2 REJECT

Examples:

```text
Business initiative cancelled.
No viable business operating model approved.
Required policy/regulatory change cannot proceed.
```

---

# 192. G2 Evidence Record

```yaml
gate_id: G2

outcome: PASS_WITH_CONDITIONS

checks:
  objectives: PASS
  scope: PASS
  capabilities: PASS
  roles: PASS
  processes: PASS
  decisions: PASS
  business_rules: PASS
  controls: PASS
  business_information: PASS
  standards_business_linkage: PASS
  blocking_questions: PASS

conditions:
  - "Final KPI baseline to be confirmed before release planning."

evidence:
  - BUS-001
  - BUS-002
  - BUS-005
  - BUS-006
  - BUS-008
  - GOV-009

approved_by:
  - BUSINESS_AUTHORITY
  - PRODUCT_ANALYST
```

---

# 193. Phase Handoff Contract

Phase 02 handoff must provide:

```text
Business Objectives
Business Scope
Domains
Capabilities
Value Streams
Actors
Roles
Responsibilities
Processes
Decisions
Rules
Controls
Exceptions
Business Information
KPIs
Dependencies
Risks
Assumptions
Open Questions
Applicable Universal Standards
Activated / Pending Conditional Profiles
Standards Applicability Decisions
Cross-Cutting Business Requirements
Product Implications
Phase 04 Requirement-Derivation Obligations
G2 Outcome
Downstream Route
```

---

# 194. Machine-Readable Handoff — Conceptual

```yaml
phase_handoff:

  from_phase: PHASE-02

  business_baseline:
    status: APPROVED

  objectives:
    - OBJ-001
    - OBJ-002

  domains:
    - DOM-001
    - DOM-002

  capabilities:
    - CAP-001
    - CAP-004

  value_streams:
    - VS-001

  roles:
    - ROLE-003
    - ROLE-008

  processes:
    - PROC-001
    - PROC-004

  decisions:
    - DEC-006

  business_rules:
    - BR-021
    - BR-022

  controls:
    - CTRL-009

  information:
    - INFO-004
    - INFO-009

  kpis:
    - KPI-002

  open_questions:
    blocking: []
    downstream:
      - OQ-031

  gate:
    id: G2
    outcome: PASS

  next_routes:
    - PHASE-03_PRODUCT_DEFINITION
    - PHASE-04_REQUIREMENTS_ENGINEERING
```

---

# 195. Traceability Graph

Canonical Phase 02 chain:

```text
PRB / OPP
    ↓
OUT
    ↓
OBJ
    ↓
CAP
    ↓
VS / PROC
    ↓
DEC
    ↓
BR
    ↓
CTRL
    ↓
INFO
```

ثم downstream:

```text
CAP / PROC / BR / CTRL / INFO
        ↓
Product Definition
        ↓
System Requirements
```

Cross-cutting standards lineage:

```text
STD / PROFILE
      ↓
GOV-009
      ↓
BREQ / BR / CTRL / POL / INFO / EVID
      ↓
Product Capability / Constraint
      ↓
FR / NFR / SEC / ACC / AUD / DR / INT
```

---

# 196. Mandatory Trace Relationships

Minimum:

```text
OBJ → OUT/PRB/OPP
CAP → OBJ
PROC → CAP
DEC → PROC or CAP
BR → DEC/PROC/CAP
CTRL → BR/RISK/PROC
INFO → PROC/DEC/BR
KPI → OBJ/PROC/CAP
STD/PROFILE → GOV-009
BREQ/BR/CTRL/POL/INFO/EVID → GOV-009 when standards-derived
```

---

# 197. Orphan Capability

Capability بدون rationale:

```text
ORPHAN_CAPABILITY
```

---

# 198. Orphan Rule

Business Rule بدون:

```text
Owner
Source
Process/Decision relevance
```

تحتاج review.

---

# 199. Orphan Process

Process لا يدعم Capability أو Objective:

```text
ORPHAN_PROCESS
```

وقد يكون legacy work لا يجب أتمتته.

---

# 200. Orphan Control

Control لا يرتبط Risk/Rule/Process:

يحتاج justification.

---

# 201. Business Architecture Change Propagation

Example:

```text
BR-021 changes
      ↓
DEC-006 review
      ↓
PROC-014 review
      ↓
CTRL-009 review
      ↓
Product capability review
      ↓
FRs become REVIEW_REQUIRED
      ↓
Tests become REVERIFY_REQUIRED
```

Standards change example:

```text
STD-A11Y baseline changes
      ↓
GOV-009 becomes REVIEW_REQUIRED
      ↓
BREQ-A11Y objects reviewed
      ↓
Affected product capabilities and constraints reviewed
      ↓
Downstream requirements/design/tests become REVIEW_REQUIRED
```

---

# 202. Business Baseline Versioning

Approved baseline:

```text
BUSINESS-BASELINE-1.0
```

Major changes require:

```text
Change Record
Impact Analysis
Reapproval where applicable
New Version
```

---

# 203. Reopening Phase 02

Possible triggers:

```text
Policy change
Regulatory change
Organization standard change
Standards applicability trigger change
Conditional profile activation/deactivation
Business model change
New business owner
Major process redesign
Rule correction
Control failure
Acquisition/merger
Operating-country change
New financial model
```

---

# 204. Reopen States

```text
BUSINESS_REVIEW_REQUIRED
PARTIAL_REARCHITECTURE
FULL_BUSINESS_REBASELINE
```

---

# 205. AI Responsibilities

AI MAY:

- derive candidate capabilities from validated objectives;
- organize business domains;
- identify duplicate capabilities;
- draft process models from evidence;
- extract business rules;
- identify decision points;
- detect missing authority;
- detect control gaps;
- classify rules;
- detect process/rule conflicts;
- propose business information concepts;
- build traceability;
- draft BRD;
- compare current vs target business state;
- identify unsupported scope.
- analyze standards and profile sources as proposals/evidence;
- propose business applicability classifications;
- propose standards-derived business objects;
- detect an applicable standard with no business linkage;
- update candidate traceability and impact relationships.

---

# 206. AI Must Label

AI-generated business conclusions:

```text
PROPOSED
INFERRED
SUPPORTED
VALIDATED
APPROVED
```

Only `APPROVED` when human authority explicitly approves.

---

# 207. AI Prohibitions

AI MUST NOT:

- invent policy;
- invent delegated authority;
- invent financial limits;
- invent regulatory obligations;
- promote current workaround into target process automatically;
- convert technical capability into business capability without rationale;
- define system permission as substitute for business authority;
- invent KPI baselines;
- resolve policy conflicts silently;
- approve business rules;
- assume organizational chart equals actual responsibility model;
- generate product features as if they were capabilities.
- declare a standard or conditional profile `NOT_APPLICABLE` without authorized rationale and evidence;
- convert an external standard into an approved business interpretation silently;
- treat QA verification language as a substitute for a business obligation;
- weaken a constitutional or universal requirement because of delivery profile.

---

# 208. Human Responsibilities

Humans remain responsible for:

```text
Business Objectives
Business Scope
Policy Interpretation
Rule Approval
Authority Assignment
Control Acceptance
Process Ownership
Exception Acceptance
KPI Commitment
Business Baseline Approval
Standards Applicability Approval
Conditional Profile Activation / Exclusion Approval
Business Interpretation of Cross-Cutting Obligations
```

---

# 209. Business Owner Responsibility

Business Owner confirms:

```text
Outcome
Scope
Capability need
Priority
Business rule
Policy intent
Operating model
```

---

# 210. Process Owner Responsibility

Process Owner confirms:

```text
Process reality
Target process
Handoffs
Exceptions
Responsibilities
Operational KPIs
```

---

# 211. Control Owner Responsibility

Control Owner confirms:

```text
Control purpose
Control operation
Evidence
Exception route
Risk acceptance
```

---

# 212. Product Analyst / Business Architect Responsibility

Responsible for:

```text
Model coherence
Traceability
Business-rule quality
Scope discipline
Decision visibility
Conflict visibility
Technology neutrality
Handoff quality
```

---

# 213. Phase 02 Anti-Patterns

## AP-02-01 — Feature Map Disguised as Capability Map

```text
Login
Dashboard
Settings
Reports
```

هذه غالبًا features/screens وليست business capabilities.

---

# 214. AP-02-02 — Organization Chart = Business Architecture

معرفة departments لا تعني فهم operating model.

---

# 215. AP-02-03 — Process Copying

نسخ current process للtarget فقط لأنه موجود.

---

# 216. AP-02-04 — Rule in Developer Head

Critical business rule غير موثق لأنه "واضح".

---

# 217. AP-02-05 — Admin Solves Everything

إعطاء Admin permission لكل exception بدل تعريف authority.

---

# 218. AP-02-06 — Workflow Without Decision Logic

رسم diamond في process diagram باسم:

```text
Approved?
```

بدون criteria أو authority.

---

# 219. AP-02-07 — Business Objects = Tables

البدء من schema بدل business meaning.

---

# 220. AP-02-08 — Automate the Waste

أتمتة process سيئ بدل إعادة تقييمه.

---

# 221. AP-02-09 — Control Removal for UX Convenience

حذف approval/control لأنه "يزود clicks".

---

# 222. AP-02-10 — KPI Theatre

اختراع metrics كثيرة لا يستخدمها أحد في decision making.

---

# 223. AP-02-11 — Exception Blindness

تصميم standard process وتجاهل الحالات التي تغير money أو legal state.

---

# 224. AP-02-12 — Rule Duplication

نفس business logic مكتوبة بصيغ مختلفة في خمس artifacts.

Canonical rule يجب أن يملك ID واحد.

---

# 225. AP-02-13 — Department-Owned Truth

كل department يبني version مختلفة من نفس customer/order/contract.

---

# 226. AP-02-14 — Premature Module Design

تحويل capability map مباشرة إلى software menu.

---

# 227. AP-02-15 — Business Scope Creep

كل process مجاور يدخل المشروع لأنه "مرتبط".

---

## AP-02-16 — Standards Deferred to QA

تسجيل Accessibility أوSecurity أوPrivacy أوAudit كـ"QA concern" بدون business applicability decision أو canonical business obligation.

هذا يقطع lineage ويجبر Phase 04 أوDesign أوEngineering على اختراع intent غير معتمد.

---

# 228. Phase Quality Measures

Future Product OS may track:

```text
Capability-to-Objective Coverage
Process-to-Capability Coverage
Rule Ownership Coverage
Decision Authority Coverage
Control Coverage
Exception Coverage
Business Information Ownership Coverage
Orphan Capability Count
Orphan Process Count
Rule Conflict Count
Business Baseline Reopen Rate
Downstream Requirement Reversal Rate
Standards-to-Business-Object Coverage
Applicable-Standard Orphan Count
Pending-Applicability Age
```

---

# 229. Important Quality Metric

```text
DOWNSTREAM BUSINESS LOGIC INVENTION RATE
```

أي:

> كم مرة اضطر Product/Engineering team لاختراع business behavior لأن Phase 02 لم تحدده؟

إذا الرقم مرتفع، Business Architecture غير مكتملة.

---

# 230. Another Critical Metric

```text
UNTRACED RULE RATE
```

كم Business Rule لا يمكن ربطها بـ:

```text
Source
Owner
Process
Decision
```

---

# 231. Phase Completion Contract

## Required Inputs

```text
G1-approved Discovery baseline
Primary Problems
Desired Outcomes
Stakeholders
Scope Hypothesis
Risk Context
Constraints
Dependencies
Product OS Constitution
Universal Standards Catalog
Conditional Compliance Profile Catalog
GOV-009 and Phase 00/01 Applicability Evidence
```

---

# 232. Required Questions

Phase 02 يجب أن تستطيع الإجابة:

```text
What business objectives are being pursued?

What business domains are affected?

What capabilities must exist?

What value streams matter?

Who participates?

Who owns what?

What major processes must operate?

What decisions determine outcomes?

What rules govern those decisions and processes?

What controls protect the business?

What exceptions are legitimate?

What business information is required?

Who owns that information?

What business dependencies exist?

How will business success be measured?

What business questions remain open?

Which universal standards create business obligations?

Which conditional profiles are applicable, not applicable, or pending?

Which canonical business requirements, rules, policies, controls, information, or evidence obligations represent them?

Who owns and approves each applicability decision and business interpretation?
```

---

# 233. Required Decisions

At minimum:

```text
Business Scope
Business Objectives
Capability Baseline
Major Process Baseline
Role/Responsibility Baseline
Critical Business Rule Baseline
Critical Control Baseline
Business Information Baseline
Risk Reassessment
Standards & Compliance Business Applicability Baseline
Cross-Cutting Business Requirement Baseline
GOV-009 Phase 02 Update
G2 Outcome
Downstream Route
```

---

# 234. Exit Criteria

Phase 02 complete when:

1. Business scope defined.
2. Business objectives approved or sufficiently baselined.
3. Relevant domains identified.
4. Required capabilities mapped.
5. Major value streams/processes understood.
6. Critical roles/responsibilities known.
7. Material decisions explicit.
8. Critical business rules baselined.
9. Critical controls identified.
10. Material exceptions covered.
11. Key business information concepts known.
12. Major dependencies known.
13. KPI direction defined where applicable.
14. Blocking business conflicts resolved.
15. Blocking questions = 0.
16. Risk reassessed.
17. BRD/Business Architecture Pack produced.
18. Universal standards and conditional profiles reviewed for business applicability.
19. Applicable obligations represented by canonical business objects.
20. `GOV-009` updated with decisions, owners, evidence, downstream implications, and reopen conditions.
21. G2 evaluated, including G2-18.
22. Downstream Handoff generated.

---

# 235. Final Transformation

Phase 02 transforms:

```text
VALIDATED PROBLEM MODEL
```

into:

```text
BUSINESS OBJECTIVES
+
BUSINESS SCOPE
+
CAPABILITIES
+
VALUE STREAMS
+
ROLES
+
RESPONSIBILITIES
+
PROCESSES
+
DECISIONS
+
BUSINESS RULES
+
CONTROLS
+
EXCEPTIONS
+
BUSINESS INFORMATION
+
KPIs
+
STANDARDS APPLICABILITY DECISIONS
+
CROSS-CUTTING BUSINESS OBLIGATIONS
```

---

# 236. Final Methodology Principle

```text
Business Architecture must describe how the business must operate
before Product OS decides how software should represent that operation.
```

---

# 237. Phase 02 Output

```text
VALIDATED PROBLEM
       ↓
BUSINESS ARCHITECTURE
       ↓
APPROVED BUSINESS BASELINE
       ↓
STANDARDS-LINKED BUSINESS BASELINE
       ↓
G2 — BUSINESS BASELINE
       ↓
PRODUCT DEFINITION + REQUIREMENTS ENGINEERING
```

**Phase 00 ensured we entered the correct project.**

**Phase 01 ensured we understood the correct problem.**

**Phase 02 ensures the business logic itself is defined before the product and system are allowed to implement it.**
