# Product OS v1.0 — Methodology Specification
## Phase 09: Implementation

**Phase ID:** `PHASE-09`  
**Phase Name:** `Implementation`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G6A — Implementation Baseline`  
**Primary Baseline:** `IBL — Implementation Baseline`  
**Primary Outcome:** تنفيذ الـapproved Engineering Readiness Baseline كـtraceable code, schema, migration, configuration, infrastructure, pipeline, design-system, integration, control, and observability changes مع actual status and evidence، والحفاظ على product/design/architecture intent، وإدارة أي deviation أو blocker أو defect قبل تسليم implementation baseline قابلة للتحقق إلى Phase 10.

---

# 1. Purpose

الغرض من Phase 09 هو الانتقال من:

```text
The implementation scope is ready, mapped, owned,
sequenced, testable, and approved to begin.
```

إلى:

```text
The approved changes exist in canonical source,
integrate safely, satisfy implementation contracts,
produce attributable evidence, and are ready
for independent verification and release workflow.
```

Phase 09 تنشئ **Implementation Baseline** يربط:

```text
Engineering Slice / Work Item
→ Change Set
→ Code / Schema / Config / Infrastructure / Asset
→ Build / Review / Migration / Deployment Evidence
→ Implementation Status
→ Deviation / Defect / Debt Disposition
→ Verification Candidate
→ Phase 10 Handoff
```

---

# 2. Position in Product OS

```text
PHASE 08 — ENGINEERING READINESS
                │
                ▼
       G5B — ENGINEERING READINESS BASELINE
                │
                ▼
PHASE 09 — IMPLEMENTATION
                │
                ▼
       G6A — IMPLEMENTATION BASELINE
                │
                ▼
PHASE 10 — VERIFICATION & RELEASE
                │
                ▼
PHASE 11 — OPERATIONS & EVOLUTION
```

Phase 10 preparation may progress while slices are implemented, but verification and release decisions must use an explicit implementation snapshot.

---

# 3. Core Implementation Question

> **Has each approved slice been implemented in the correct canonical targets, under its contracts and controls, with evidence sufficient for independent verification?**

Then:

> **Are implementation reality, remaining gaps, deviations, defects, migrations, environments, and operational obligations represented truthfully?**

---

# 4. Implementation Philosophy

Product OS Implementation follows these principles.

## IMP-PR-01 — Implement the Baseline, Not Memory

Code and configuration must trace to stable approved IDs and revisions.

Chat, screenshots, and personal recollection do not replace canonical contracts.

---

## IMP-PR-02 — Small, Reviewable, Reversible Changes

Prefer change sets that are understandable, testable, integrable, and reversible or safely forward-fixable.

---

## IMP-PR-03 — Status Follows Evidence

`IMPLEMENTED`, `DEPLOYED`, `VERIFIED`, and `RELEASED` require different evidence.

No status may be inferred from intent or optimism.

---

## IMP-PR-04 — Green Build Is Necessary, Not Sufficient

A build can pass while behavior, runtime startup, deployment identity, migration safety, authorization, accessibility, or production configuration remains wrong.

---

## IMP-PR-05 — Source Identity Is Verified

Before changing or deploying, confirm repository, branch, project, environment, source revision, domain / alias, and configuration identity.

---

## IMP-PR-06 — Design and Architecture Remain Active Contracts

Implementation does not own silent redesign or structural change.

Differences enter the deviation workflow.

---

## IMP-PR-07 — Secure and Accessible by Construction

Security, privacy, accessibility, localization, audit, reliability, and observability are implemented within relevant changes—not appended after functional completion.

---

## IMP-PR-08 — Migrations Are Product Changes

Schema, data, configuration, identity, infrastructure, and client migrations require compatibility, validation, recovery, evidence, and user or operator impact consideration.

---

## IMP-PR-09 — Runtime Behavior Matters

Compile-time and unit evidence do not prove startup, dependency connectivity, request behavior, jobs, migrations, or operational signals.

---

## IMP-PR-10 — Evidence Is Produced with the Work

The change set should produce the commits, reviews, checks, mappings, logs, migration results, and other evidence required for verification.

---

## IMP-PR-11 — Secrets Stay Outside Artifacts

Implementation documents and tool output must not expose credentials, tokens, private keys, or sensitive production data.

---

## IMP-PR-12 — Fail Closed Where Required

Missing security, privacy, data, or environment configuration must not silently activate an unsafe fallback.

---

## IMP-PR-13 — Deviations Are First-Class

When implementation discovers contradiction or constraint, stop the affected decision boundary, record evidence, assess impact, and route approval.

---

## IMP-PR-14 — Implementation Is Not Verification Approval

Phase 09 may run implementation checks and self-verification, but Phase 10 owns independent verification, defect disposition, UAT, and release gates.

---

## IMP-PR-15 — Implemented Does Not Mean Released

Merged, built, deployed to non-production, production-deployed, feature-enabled, verified, and released are separate events.

---

# 5. Phase Objectives

By the end of Phase 09, Product OS must be able to:

1. Consume a valid G5B scope and preserve upstream versions.
2. Implement approved slices and work items in canonical targets.
3. Maintain truthful per-item implementation status.
4. Produce reviewable source changes and durable provenance.
5. Implement design tokens, components, screens, states, content, responsive, RTL, accessibility, and motion contracts.
6. Implement domain rules, APIs, events, jobs, integrations, data models, and migrations.
7. Implement identity, authorization, tenant isolation, security, privacy, and audit controls.
8. Implement reliability, performance, capacity, observability, backup, and recovery mechanisms within scope.
9. Implement environment, configuration, secret, key, infrastructure, and deployment changes safely.
10. Implement CI/CD and software-supply-chain controls.
11. Execute appropriate developer, static, unit, component, contract, integration, migration, and smoke checks.
12. Maintain design and architecture parity mappings.
13. Record and resolve blockers, questions, defects, deviations, and technical debt.
14. Produce implementation evidence and traceability.
15. Update `GOV-009` control implementation status without overstating verification or compliance.
16. Prepare an explicit verification candidate and environment snapshot.
17. Create a versioned Implementation Baseline.
18. Pass `G6A — Implementation Baseline`.

---

# 6. Phase Inputs

Required logical inputs:

```text
ERBL Engineering Readiness Baseline
ENG-001 through ENG-032 as applicable
G5B Decision and conditions

RBL Requirements Baseline
EBL Experience Baseline
DBL Design Baseline
ABL Architecture Baseline

Canonical repositories and branches
Canonical design sources
Schemas and migration sources
Infrastructure and environment sources
API / event / integration contracts
Engineering standards
Definition of Ready / Done
Acceptance and verification allocations
Evidence plans
GOV-009 revision and implementation allocation

Approved toolchain and access
Test data and identity plan
Environment readiness evidence
Dependency and vendor access
Open blockers, risks, deviations, and conditions
```

---

# 7. Entry Condition

Phase 09 starts for a named slice only when:

```text
G5B scope includes the slice
Slice / work item readiness = READY or valid CONDITIONAL
Upstream versions are available
Repository / module and owner are confirmed
Blocking dependencies are resolved
Required contracts are implementation-ready
Required environment / toolchain path exists or approved setup work is first
Security and data constraints are understood
Verification and evidence expectations are visible
```

---

# 8. What Phase 09 Is Not

Phase 09 is not:

- Product or release scope invention.
- Requirements rewriting.
- Unapproved design or architecture change.
- A synonym for coding only.
- A merge-only phase.
- Final independent verification.
- UAT or release approval.
- Production operations.
- Permission to expose secrets for debugging.
- Permission to treat generated code as trusted without review.

---

# 9. Phase Boundaries

## Phase 08 Owns

```text
Ready scope, slices, work contracts, targets, dependencies,
DoR / DoD, verification allocation, and evidence plan
```

## Phase 09 Owns

```text
Actual implementation
Actual implementation status
Change sets and review evidence
Implementation-level checks
Migrations and configuration changes
Implementation deviations and defects
Implementation evidence
Verification candidate and handoff
```

## Phase 10 Owns

```text
Independent verification strategy and execution
Defect acceptance / rejection decisions
Design implementation QA acceptance
Security / accessibility / performance / resilience verification
UAT
Release readiness and release decision
```

## Phase 11 Owns

```text
Production operation, monitoring, support, incidents,
capacity, SLOs, technical debt, and evolution
```

---

# 10. Implementation Scope

Every implementation run identifies:

```text
ERBL ID and revision
Release / milestone
Slice and work-item IDs
Repositories / modules
Target environments
Feature flags / cohorts
Migration scope
Gate conditions
Owners
```

---

# 11. Implementation Status Dimensions

Track separately:

```text
Work status
Review status
Build status
Test status
Migration status
Deployment status
Verification status
Release status
Operational status
```

---

# 12. Work Status

```text
NOT_STARTED
IN_PROGRESS
BLOCKED
IN_REVIEW
CHANGES_REQUESTED
IMPLEMENTED
DEFERRED
CANCELLED
```

---

# 13. Deployment Status

```text
NOT_DEPLOYED
DEPLOYED_LOCAL
DEPLOYED_PREVIEW
DEPLOYED_TEST
DEPLOYED_STAGING
DEPLOYED_PRODUCTION_DISABLED
DEPLOYED_PRODUCTION_ENABLED
ROLLED_BACK
```

---

# 14. Verification Status

```text
NOT_STARTED
DEVELOPER_CHECKED
VERIFICATION_PENDING
PARTIALLY_VERIFIED
VERIFIED
FAILED
BLOCKED
```

Phase 09 normally exits with `VERIFICATION_PENDING` for independent Phase 10 scope.

---

# 15. Source-of-Truth Rule

Implementation truth lives in canonical source, reviewed change sets, migrations, configuration, infrastructure definitions, deployment records, and runtime evidence.

Status documents reference these sources; they do not override them.

---

# 16. Implementation Object Model

Core object families:

```text
IRUN   Implementation Run / Scope
ICHG   Change Set
ICOM   Commit / Revision
IREV   Review Record
IBLD   Build Artifact / Build Record
ITST   Implementation Check
ICODE  Code Object / Module Change
IUI    UI / Design-System Change
IAPI   API / Event / Integration Change
IDAT   Data / Schema Change
IMIG   Migration Execution
ICFG   Configuration Change
ISEC   Secret / Key Change Class
IINF   Infrastructure Change
IPIP   Pipeline Change
IFLG   Feature Flag / Rollout Change
ICTL   Control Implementation
IOBS   Observability Change
IDOC   Technical Documentation / Runbook Change
IDEF   Implementation Defect
IBLK   Implementation Blocker
IDEV   Implementation Deviation
IDBT   Technical Debt
IEVID  Implementation Evidence
ICOV   Implementation Coverage Record
IVCAND Verification Candidate
IHND   Verification Handoff
```

---

# 17. Implementation Run

An `IRUN` groups a named baseline scope and its implementation state.

---

# 18. Implementation Run Contract

```yaml
implementation_run: IRUN-REL-001
engineering_baseline: ERBL-2026-001
release: REL-001
slices:
  - ESL-APR-REVIEW-001
repositories:
  - REPO-APR-API
  - REPO-APR-WEB
target_environments:
  - TEST
  - STAGING
owners:
  engineering: TEAM-APPROVALS
conditions:
  - G5B-COND-001
status: IN_PROGRESS
```

---

# 19. Change Set

An `ICHG` is a coherent group of source, schema, configuration, infrastructure, asset, or documentation changes reviewed together.

---

# 20. Change Set Contract

```text
Change Set ID
Parent work items / slice
Repository and branch
Base and head revisions
Purpose
Files / modules / resources affected
Contracts and baselines referenced
Risk
Migration / rollout / rollback
Checks
Reviewers
Evidence
Status
```

---

# 21. Change Set Boundary

A change set should be small enough to review and validate but complete enough to preserve invariants and avoid half-implemented contracts.

---

# 22. Atomicity of Change

Where practical, a change set should keep source, schema, tests, configuration, documentation, and mappings compatible at each merge or deployment boundary.

---

# 23. Commit and Revision Provenance

Record canonical revision identity for source and generated artifacts.

Avoid claims based only on an uncommitted working tree unless explicitly classified as local evidence.

---

# 24. Review Record

An `IREV` records:

```text
Change Set ID
Reviewers and roles
Review revision
Required checks
Findings
Resolution
Approval / request changes
Date
Evidence link
```

---

# 25. Review Scope

Activate reviewers for applicable:

```text
Product behavior
Design parity
Architecture
Security / privacy
Data / migration
Accessibility
Platform / operations
Verification
```

---

# 26. Generated Code

AI-, schema-, tool-, or template-generated code must have:

```text
Generator source and version
Input source
Review ownership
Regeneration rule
Manual-edit policy
Security / license review
Tests
Provenance
```

Generated does not mean correct or trusted.

---

# 27. Implementation Check

An `ITST` is a check executed during Phase 09 to support implementation confidence and Phase 10 readiness.

---

# 28. Check Types

```text
FORMAT
LINT
TYPE
STATIC_ANALYSIS
UNIT
COMPONENT
CONTRACT
INTEGRATION
MIGRATION
BUILD
STARTUP
SMOKE
SECURITY_SCAN
ACCESSIBILITY_CHECK
DESIGN_PARITY
PERFORMANCE_SANITY
INFRASTRUCTURE_PLAN
CONFIGURATION_VALIDATION
```

---

# 29. Check Record

```text
Check ID
Change Set / Work Item
Command / method
Environment
Revision
Inputs / data
Expected result
Actual result
Status
Evidence
Owner
```

---

# 30. Check Failure

A failed required check blocks implementation completion unless the failure is proven unrelated, formally waived, or the affected scope is removed.

---

# 31. Build Record

An `IBLD` records source revision, toolchain, dependency lock, build configuration, artifact identity, checksums / provenance where applicable, warnings, status, and storage location.

---

# 32. Reproducible Build

Where required, define how equivalent source, dependencies, tools, and configuration produce equivalent or verifiably attributable artifacts.

---

# 33. Dependency Implementation

When adding or changing a dependency, record:

```text
Purpose
Version and source
License
Maintenance / viability
Security status
Runtime / bundle impact
Transitive risk
Update policy
Alternative / removal
```

---

# 34. Lockfile Integrity

Dependency lockfiles are source artifacts and must remain consistent with manifests and supported toolchains.

---

# 35. Code Quality

Implementation quality includes correctness, clarity, maintainability, testability, failure behavior, security, performance, accessibility, and alignment with architecture boundaries.

---

# 36. Code Structure

Code should preserve approved domain, container, component, module, dependency, and ownership boundaries.

Framework conventions do not override architecture intent without a deviation decision.

---

# 37. Error Handling Implementation

Implement:

```text
Stable public errors
Internal diagnostic context
Retryability
Correlation
Unknown-outcome behavior
Sensitive-data protection
User / operator recovery
Metrics and logs
```

---

# 38. Validation Implementation

Implement validation at every untrusted boundary, including schema, type, format, semantic, business, authorization-context, size, rate, and file / content controls as applicable.

---

# 39. Concurrency Implementation

Implement approved controls for lost update, duplicate submission, ordering, race, stale state, concurrent approval, quota, and idempotency.

---

# 40. Feature Flag Implementation

Implement approved default, evaluation point, targeting, telemetry, security boundary, failure behavior, rollout stages, and removal tracking.

---

# 41. Implementation Comments and Documentation

Document non-obvious constraints, invariants, security assumptions, migration limitations, and operational behavior near their source without duplicating full canonical specifications.

---

# 42. UI Implementation Scope

UI implementation realizes approved design and experience contracts in production code across applicable platforms.

---

# 43. Design Source Verification

Before implementation, confirm design file / library, node or object, revision, component source, token source, content source, and approved status.

---

# 44. Token Implementation

Implement semantic tokens with theme, mode, platform, fallback, compatibility, deprecation, and code ownership rules.

Raw values require an approved exception or migration record.

---

# 45. Component Implementation

Implement anatomy, properties, variants, states, behavior, semantics, responsive / RTL behavior, content constraints, tokens, and tests from the approved component contract.

---

# 46. Component Adoption

Track actual product usage separately from component publication.

A component package can be implemented but not yet adopted by any product surface.

---

# 47. Screen and Route Implementation

Implement route / view entry, role / permission context, loading, success, error, denied, conflict, offline, processing, unknown outcome, expiry, interruption, and recovery states as applicable.

---

# 48. Responsive Implementation

Implement approved recomposition, not only CSS or layout shrinkage.

Preserve content, action, context, status, errors, focus, and recovery across supported modes.

---

# 49. RTL and Localization Implementation

Implement locale selection, translation loading, fallback, direction, typography, shaping, mixed-direction content, number / date / currency, ordering, icons, content expansion, and generated outputs.

---

# 50. Accessibility Implementation

Implement applicable semantics, names, roles, values, focus, keyboard, target size, contrast, forms, errors, announcements, reflow, zoom, reduced motion, authentication, and generated-output accessibility.

---

# 51. Motion Implementation

Implement purpose, trigger, state transition, timing, interruption, performance, and reduced-motion behavior from the approved contract.

---

# 52. Content Implementation

Use canonical content IDs and variables where defined.

Implement localization, wrapping, fallback, security constraints, and dynamic-state messages without embedding uncontrolled copies.

---

# 53. Asset Implementation

Use approved sources, formats, dimensions / density, theme and RTL variants, optimization, licensing, accessible alternatives, caching, and versioning.

---

# 54. Generated Output Implementation

Implement template versioning, data snapshot semantics, fonts, shaping, RTL, accessibility tags, authorization, integrity, storage, failure, retry, and evidence.

---

# 55. Design Parity Evidence

Record implemented revision, design source, affected screens / components, comparison method, supported modes, approved differences, findings, and resolution.

---

# 56. API Implementation

Implement approved schema, authentication, authorization, validation, errors, idempotency, concurrency, pagination, limits, versioning, observability, and deprecation behavior.

---

# 57. Contract Compatibility

Run producer / consumer contract and schema compatibility checks appropriate to the interface before integration or release candidate creation.

---

# 58. Event Implementation

Implement event identity, producer, schema, version, timestamps, ordering key, privacy, delivery, deduplication, retention, replay, and consumer failure behavior.

---

# 59. Background Job Implementation

Implement trigger, input snapshot, idempotency, concurrency, timeout, retry, dead-letter, progress, cancellation, result, observability, and manual recovery.

---

# 60. Integration Implementation

Implement authentication, data mapping, validation, timeout, retry, idempotency, quota, failure, reconciliation, observability, support reference, privacy, and contract version.

---

# 61. Webhook Implementation

Implement signature validation, replay protection, secret rotation, response timing, idempotency, ordering, retry, observability, and safe failure.

---

# 62. Real-Time Implementation

Implement authorization, subscription scope, reconnection, missed-message recovery, ordering, backpressure, presence, scale, and telemetry.

---

# 63. Offline and Sync Implementation

Implement local data protection, queued actions, identity lifetime, sync cursor, conflict resolution, staleness, deletion propagation, recovery, and user-visible state.

---

# 64. Data Implementation Scope

Data implementation includes schema, constraints, indexes, ownership, classification, access, lifecycle, migration, quality, lineage, retention, deletion, and evidence.

---

# 65. Schema Change

An `IDAT` records source and target schema, compatibility, affected queries / services, constraints, migration, validation, rollback limits, and evidence.

---

# 66. Schema Migration Safety

Use an approved safe sequence such as expand / migrate / contract where compatibility requires it.

Destructive changes require explicit approval and recovery treatment.

---

# 67. Data Migration Execution

An `IMIG` records:

```text
Migration ID and revision
Environment
Source and target
Prechecks
Backup / checkpoint
Execution start / finish
Counts and validation
Errors / exceptions
Reconciliation
Rollback / forward fix status
Operator
Evidence
```

---

# 68. Data Backfill

Implement batching, checkpointing, idempotency, load control, validation, restart, progress, exception handling, and completion evidence.

---

# 69. Reference and Seed Data

Implement deterministic, versioned, environment-safe reference and seed data with ownership, update, idempotency, security, and verification.

---

# 70. Retention and Deletion Implementation

Implement schedules, triggers, legal holds, deletion / anonymization, vendor propagation, backup expiry, audit, exceptions, and completion evidence.

---

# 71. Data Residency Implementation

Verify actual primary, replica, backup, logging, analytics, vendor, support, and failover locations against the approved architecture.

---

# 72. Search and Index Implementation

Implement authoritative source, indexing, freshness, authorization filtering, tenant isolation, analyzers / locale, deletion propagation, reindex, failure, and telemetry.

---

# 73. Analytics Implementation

Implement metric definitions, lineage, authorization, minimization, aggregation, retention, backfill, correction, privacy, and data-quality checks.

---

# 74. Identity Implementation

Implement identity authority, enrollment, credentials, claims, lifecycle, linking, suspension, termination, recovery, and audit according to architecture.

---

# 75. Authentication Implementation

Implement approved authentication methods, credential handling, MFA / step-up, federation, enumeration protection, rate controls, errors, accessibility, and telemetry.

---

# 76. Session Implementation

Implement issuance, storage, transport, lifetime, rotation, revocation, concurrent sessions, logout propagation, reauthentication, failure, and audit.

---

# 77. Authorization Implementation

Implement policy vocabulary, decision and enforcement points, tenant and resource context, default deny, cache / revocation, failure, audit, and tests.

---

# 78. Tenant Isolation Implementation

Implement tenant context propagation and isolation across UI, API, domain, data, cache, jobs, events, search, analytics, logs, audit, backup, and support access.

---

# 79. Administrative Access Implementation

Implement approval, scope, duration, reason, acting capacity, masking, session controls, user visibility, audit, break-glass, and review as applicable.

---

# 80. Security Control Implementation

An `ICTL` records control objective, enforcement point, code / configuration target, owner, failure behavior, telemetry, implementation evidence, and verification handoff.

---

# 81. Secure Default Implementation

Implement safe defaults for access, exposure, debug, error disclosure, secrets, encryption, logs, exports, administrative actions, and feature activation.

---

# 82. Input and Output Security

Implement validation, canonicalization, encoding, request integrity, content security, file handling, and safe output according to platform and boundary.

---

# 83. Edge and Abuse Controls

Implement applicable WAF, rate limiting, DDoS / bot controls, origin protection, security headers, quotas, anomaly signals, escalation, and audit.

---

# 84. Encryption Implementation

Implement approved transport, storage, field / object, backup, and export encryption with key ownership, access separation, rotation, and evidence.

---

# 85. Secret and Key Implementation

Implement generation, secure storage, scoped access, injection, environment isolation, rotation, revocation, break-glass, and leak response.

Never emit secret values into evidence.

---

# 86. Privacy Control Implementation

Implement minimization, purpose separation, consent, rights, retention, deletion, disclosure, analytics controls, vendor propagation, and evidence.

---

# 87. Audit Implementation

Implement actor, acting capacity, tenant, action, target, timestamp, outcome, reason, safe before / after data, correlation, integrity, retention, access, and monitoring.

---

# 88. Supply Chain Implementation

Implement applicable branch protections, dependency controls, secret scans, static analysis, build identity, artifact provenance, signing, registry access, promotion, and vulnerability response.

---

# 89. Reliability Implementation

Implement approved timeout budgets, retries, jitter, idempotency, circuit breaking, bulkheads, degradation, reconciliation, recovery, and SLO signals.

---

# 90. Unknown Outcome Implementation

Implement durable attempt state, status lookup, duplicate protection, reconciliation, safe retry, user / operator messaging, and audit where outcome may be uncertain.

---

# 91. Performance Implementation

Implement approved budgets, query and index controls, caching, pagination, batching, payload limits, backpressure, client performance, and instrumentation.

---

# 92. Capacity and Resource Controls

Implement quotas, queue bounds, scaling configuration, hot-tenant protection, resource requests / limits, cost labels, and capacity signals as applicable.

---

# 93. Observability Implementation

Implement structured logs, metrics, traces, correlation, health, dashboards, alerts, redaction, retention, access, and diagnostic context.

---

# 94. Logging Safety

Review all new or changed logs for passwords, tokens, keys, sensitive personal data, regulated data, documents, full payloads, and uncontrolled identifiers.

---

# 95. Health and Startup Implementation

Implement and check liveness, readiness, dependency diagnosis, startup configuration validation, migration behavior, graceful shutdown, and failure visibility.

---

# 96. Alert and Runbook Linkage

Every actionable alert implemented in scope should reference owner, severity, impact, threshold, recovery condition, and runbook or response guidance.

---

# 97. Backup and Restore Implementation

Implement backup scope, frequency, retention, encryption, separation, monitoring, access, restore procedure, validation, and evidence according to architecture.

---

# 98. Configuration Implementation

An `ICFG` records name / class, schema, environment scope, source, default, validation, deployment behavior, change authority, audit, rollback, and evidence.

---

# 99. Environment Isolation Implementation

Implement separation of accounts, networks, data stores, credentials, keys, vendor endpoints, logs, domains, and access according to approved environment architecture.

---

# 100. Infrastructure Implementation

An `IINF` change must reference architecture, source location, target environment, plan, dependencies, network, identity, secrets, observability, cost, rollout, rollback, checks, and evidence.

---

# 101. Infrastructure Plan Review

Review declarative infrastructure changes before apply for target identity, replacement / deletion, exposure, permissions, data impact, secrets, cost, drift, and rollback.

---

# 102. Infrastructure Apply Evidence

Record approved plan reference, source revision, target identity, operator / automation identity, result, changed resources, failures, outputs excluding secrets, and post-apply checks.

---

# 103. Configuration Drift

Detect and reconcile differences between canonical configuration, provisioned state, and runtime state.

Manual emergency changes require later source reconciliation.

---

# 104. CI/CD Implementation

An `IPIP` change may implement build, checks, tests, artifact creation, provenance, signing, migration controls, deployment, smoke checks, approvals, rollback, and evidence retention.

---

# 105. Pipeline Identity

Confirm repository, branch / tag, source revision, project / account, environment, artifact, deployment target, and domain / alias for every material deployment path.

---

# 106. Build vs Runtime Evidence

Build success proves artifact creation.

Runtime readiness requires startup, configuration, dependency, request / job, health, and logging evidence in the target environment.

---

# 107. Deployment Record

Record:

```text
Deployment ID
Environment and project identity
Source repository / revision
Build artifact
Configuration revision
Migration revision / status
Feature flag state
Start / finish
Status
Health / smoke results
Domain / alias
Rollback reference
Evidence
```

---

# 108. Deployment Verification Boundary

Phase 09 may verify that the deployed candidate starts and supports implementation smoke paths.

Phase 10 owns full system verification and release approval.

---

# 109. Deployment Failure

On failure, preserve evidence, identify whether build, startup, configuration, dependency, migration, runtime request, network, or platform caused it, and update status truthfully.

---

# 110. Feature Rollout Implementation

Implement cohorts, percentage / tenant targeting, prerequisites, observability, success and abort thresholds, owner, schedule, rollback / disable, and flag removal.

---

# 111. Client Release Candidate

For mobile, desktop, extension, embedded, or store-distributed clients, record source revision, build / signing identity, version, platform target, permissions, compatibility, distribution channel, staged rollout, rollback limitations, and evidence.

---

# 112. Infrastructure and Application Compatibility

Coordinate code, schema, configuration, infrastructure, APIs, events, clients, and feature flags so each deployment boundary remains compatible or intentionally contained.

---

# 113. Implementation Evidence

An `IEVID` is durable proof of an implementation claim.

---

# 114. Evidence Types

```text
SOURCE_REVISION
CHANGE_REVIEW
BUILD
UNIT / COMPONENT / CONTRACT / INTEGRATION CHECK
SCHEMA / MIGRATION
CONFIGURATION
INFRASTRUCTURE
DEPLOYMENT
STARTUP / HEALTH / SMOKE
DESIGN_PARITY
ACCESSIBILITY_IMPLEMENTATION
SECURITY_CONTROL
AUDIT_SAMPLE
OBSERVABILITY
BACKUP / RESTORE
DOCUMENTATION
TRACEABILITY
```

---

# 115. Evidence Contract

```text
Evidence ID
Claim / obligation
Object / work item
Source revision
Environment
Method / producer
Timestamp
Result
Artifact location
Sensitivity / access
Reviewer
Retention
```

---

# 116. Evidence Integrity

Evidence must be attributable, scoped, versioned or dated, tamper-aware where required, protected according to sensitivity, and linked to the exact claim it supports.

---

# 117. Evidence Redaction

Before storing evidence, remove or protect credentials, tokens, private keys, personal data, regulated data, internal-only identifiers, and sensitive configuration not required for the claim.

---

# 118. Screenshot Evidence

A screenshot may support visual or runtime evidence when it includes scope and context, but it cannot prove source revision, internal control, migration integrity, or broad conformance alone.

---

# 119. Log Evidence

Log excerpts must identify environment, revision / version, time range, correlation, query or filter, expected signal, and redaction while remaining within retention and access policy.

---

# 120. Test Evidence

Record revision, command / method, environment, inputs, result summary, failures / skips, artifact output, and owner.

---

# 121. Implementation Coverage

An `ICOV` tracks whether every approved work and upstream obligation has implementation disposition and evidence.

---

# 122. Work Item Disposition

```text
IMPLEMENTED
PARTIALLY_IMPLEMENTED
DEFERRED_WITH_APPROVAL
NOT_APPLICABLE
BLOCKED
CANCELLED
SUPERSEDED
```

---

# 123. Requirement Implementation Coverage

Each in-scope requirement maps to implemented work items, source changes, checks, and evidence.

Phase 10 determines verification status separately.

---

# 124. Design Implementation Coverage

Each in-scope screen, state, component, token, content, responsive / RTL / accessibility rule, motion, asset, and generated output has implemented source or explicit disposition.

---

# 125. Architecture Implementation Coverage

Each in-scope domain, component, interface, data object, control, deployment unit, observability signal, migration, and ADR obligation maps to implemented source or explicit disposition.

---

# 126. Standards Implementation Coverage

Each active `GOV-009` implementation obligation maps to code, configuration, infrastructure, migration, evidence, and verification handoff as applicable.

---

# 127. Orphan Implementation

Orphans include:

```text
Code change without work item or defect source
Schema change without data / architecture source
Infrastructure resource without architecture purpose
Flag without rollout owner
Log / metric without operational consumer
Dependency without approved need
Test without acceptance or control source
Documentation without affected implementation
```

Orphans must be linked, reclassified, or removed from the baseline.

---

# 128. Unimplemented Obligations

Detect approved scope with no implementation evidence, including non-happy states, accessibility, security controls, audit, observability, migrations, generated outputs, and operational work.

---

# 129. Implementation Blocker

An `IBLK` prevents safe completion of named work.

Record cause, evidence, affected items, owner, escalation, temporary containment, due date, unblock condition, and status.

---

# 130. Implementation Defect

An `IDEF` is a deviation from an approved requirement, design, architecture contract, standard, or expected implementation quality found during Phase 09.

---

# 131. Defect Contract

```text
Defect ID
Source / expected behavior
Observed behavior
Environment / revision
Steps / evidence
Severity / impact
Affected objects
Owner
Resolution
Regression check
Status
```

---

# 132. Defect Severity

```text
CRITICAL — unacceptable harm, security, data, or release-blocking failure
HIGH — major functional, control, migration, accessibility, or reliability failure
MEDIUM — contained functional or quality gap
LOW — local issue with limited impact
```

---

# 133. Defect vs Deviation

```text
Defect — implementation fails an approved expectation.
Deviation — implementation proposes or introduces a different expectation or mechanism.
```

A deviation can still produce a defect until approved.

---

# 134. Implementation Deviation

An `IDEV` records a proposed or actual difference from the baselined requirement, experience, design, architecture, engineering contract, or standard.

---

# 135. Deviation Workflow

```text
DISCOVER
→ CONTAIN AFFECTED WORK
→ RECORD EVIDENCE
→ CLASSIFY
→ ASSESS IMPACT
→ ROUTE TO AUTHORITY
→ APPROVE / REJECT / DEFER
→ UPDATE BASELINES AND WORK
→ IMPLEMENT
→ VERIFY RECONCILIATION
```

---

# 136. Deviation Status

```text
DRAFT
IN_REVIEW
APPROVED_LOCAL_EXCEPTION
APPROVED_BASELINE_CHANGE
REJECTED
DEFERRED
TEMPORARY_EMERGENCY
RECONCILED
```

---

# 137. Deviation Impact

Assess:

```text
Product scope / behavior
Requirements / acceptance
Experience / content
Design / components
Architecture / ADRs
Security / privacy / accessibility
Data / integration / migration
Performance / reliability / operations
Verification / release
GOV-009
```

---

# 138. Local Implementation Decision

Engineering may make local, reversible decisions within approved contracts when they do not change material behavior, boundary, data meaning, control, interface, operational obligation, or evidence.

---

# 139. Emergency Change

An emergency change requires narrow scope, incident context, minimum review, risk and security assessment, rollback or forward fix, monitoring, evidence, human approval, and later baseline reconciliation.

---

# 140. Technical Debt

An `IDBT` records an intentional implementation compromise that does not currently violate an unwaived critical obligation.

---

# 141. Debt Contract

```text
Debt ID
Origin and affected objects
Current compromise
Reason
Risk / cost
Temporary controls
Owner
Target horizon
Retirement condition
Evidence / monitoring
```

Debt is not a label for an unresolved critical defect.

---

# 142. Documentation Implementation

Update applicable:

```text
Code / module documentation
API / event contracts
Schema / migration notes
Configuration reference
Deployment procedures
Runbooks
Support diagnostics
Architecture / design mappings
Implementation status
Change history
```

---

# 143. Runbook Readiness

Implementation supplies commands, signals, safe actions, permissions, rollback / recovery, escalation, and evidence required by later operational runbooks.

---

# 144. Implementation Status Register

The register uses stable IDs and links every status to evidence.

Avoid percentage complete without defined object and completion criteria.

---

# 145. Progress Reporting

Report:

```text
Implemented scope
In-review scope
Blocked scope
Failed checks
Open defects / deviations
Migration / deployment status
Evidence produced
Remaining verification candidates
Gate risks
```

---

# 146. Partial Implementation

Partial implementation must identify the exact included behavior, excluded states / controls, compatibility, flag / containment, evidence, and restrictions.

---

# 147. Implementation Snapshot

A snapshot freezes:

```text
Repository revisions
Dependency locks
Schema / migration versions
Configuration revisions excluding values
Infrastructure revision
Build artifacts
Environment / deployment IDs
Feature flag state
Evidence index
Open defects / deviations
```

---

# 148. Verification Candidate

An `IVCAND` is an explicit implementation snapshot submitted for Phase 10 verification.

---

# 149. Verification Candidate Contract

```yaml
candidate_id: IVCAND-REL-001-RC1
implementation_baseline: IBL-2026-001
scope:
  slices: [ESL-APR-REVIEW-001]
source:
  REPO-APR-API: a1b2c3d
  REPO-APR-WEB: d4e5f6a
artifacts:
  api_image: sha256:example
environment:
  id: STAGING-01
  deployment: DEPLOY-2026-0810-014
migrations:
  - MIG-20260810-APR-001
flags:
  approval_review: INTERNAL_COHORT
known_items:
  defects: []
  deviations: [IDEV-APR-003]
evidence_index: IMP-029
status: SUBMITTED
```

---

# 150. Candidate Immutability

If source, artifact, schema, configuration, environment, or flag state changes materially, create or update the candidate revision and assess invalidated evidence.

---

# 151. Phase 09 Workflow Overview

```text
09.0  Confirm G5B scope, conditions, targets, and access
09.1  Verify current repository, environment, and deployment identity
09.2  Establish implementation run and source snapshot
09.3  Implement slices through reviewable change sets
09.4  Implement UI, design system, content, accessibility, and localization
09.5  Implement domain, API, event, job, and integration behavior
09.6  Implement data, schema, lifecycle, and migrations
09.7  Implement identity, authorization, security, privacy, and audit controls
09.8  Implement reliability, performance, and observability mechanisms
09.9  Implement configuration, secrets, infrastructure, and environment changes
09.10 Implement CI/CD, supply-chain, and artifact controls
09.11 Execute developer and integration checks
09.12 Execute migration and deployment rehearsals where required
09.13 Produce design and architecture parity evidence
09.14 Maintain implementation status and traceability
09.15 Detect and resolve defects, blockers, and questions
09.16 Route deviations and update affected baselines
09.17 Record technical debt and operational documentation
09.18 Update GOV-009 implementation status
09.19 Complete implementation coverage and evidence index
09.20 Create implementation snapshot
09.21 Prepare verification candidate
09.22 Run implementation validation review
09.23 Prepare Phase 10 handoff
09.24 Run G6A — Implementation Baseline
```

---

# 152. Step 09.0 — Confirm G5B Scope

Confirm ERBL version, slices, work items, repositories, contracts, owners, conditions, DoR / DoD, verification, evidence, and deviation route.

---

# 153. Step 09.1 — Verify Engineering Identity

Before mutations, verify:

```text
Repository and Git remote
Branch and base revision
Build / package identity
Environment and project / account
Deployment source and target
Domain / alias
Database / schema target
Configuration key identities
```

---

# 154. Step 09.2 — Establish Implementation Run

Create `IRUN`, snapshot source and target state, confirm access, conditions, blockers, and expected evidence.

---

# 155. Step 09.3 — Implement Change Sets

Implement coherent changes, update tests and documentation with code, run required checks, obtain reviews, and retain provenance.

---

# 156. Step 09.4 — Implement Product UI

Implement approved design sources across platforms and states, preserving token, component, content, responsive, RTL, accessibility, motion, and generated-output contracts.

---

# 157. Step 09.5 — Implement Application and Integration Behavior

Implement domain rules, APIs, events, jobs, workflows, integrations, offline / sync, failure, and contract compatibility.

---

# 158. Step 09.6 — Implement Data and Migrations

Implement schema, constraints, indexes, lifecycle, retention, deletion, backfill, validation, reconciliation, and safe transition.

---

# 159. Step 09.7 — Implement Trust Controls

Implement identity, authentication, sessions, recovery, authorization, tenancy, administrative access, security, privacy, audit, encryption, secrets, and abuse controls.

---

# 160. Step 09.8 — Implement Quality and Operability

Implement timeouts, retries, idempotency, degradation, reconciliation, performance budgets, resource controls, logs, metrics, traces, health, alerts, backup, and recovery.

---

# 161. Step 09.9 — Implement Platform Changes

Implement validated configuration, infrastructure, environment isolation, network, secrets / keys, flags, deployment units, and rollback controls.

---

# 162. Step 09.10 — Implement Delivery Pipeline

Implement source checks, builds, tests, scans, artifacts, provenance, signing, promotion, migrations, deployments, health checks, approvals, rollback, and evidence.

---

# 163. Step 09.11 — Execute Implementation Checks

Run applicable format, lint, type, static, unit, component, contract, integration, build, startup, smoke, security, accessibility, and sanity checks against the exact revision.

---

# 164. Step 09.12 — Rehearse High-Risk Changes

Rehearse migration, deployment, rollback / forward fix, restore, vendor integration, client compatibility, or failure behavior where G5B or risk requires it.

---

# 165. Step 09.13 — Produce Parity Evidence

Compare implementation to baselined design and architecture, record approved differences, and route material gaps.

---

# 166. Step 09.14 — Maintain Status and Traceability

Update work, review, build, test, migration, deployment, verification, and release dimensions using linked evidence.

---

# 167. Step 09.15 — Resolve Defects and Blockers

Classify, prioritize, fix, recheck, and retain evidence.

Questions that change baselines route to the accountable upstream owner.

---

# 168. Step 09.16 — Control Deviations

Contain affected scope, record facts, obtain decisions, update contracts and baselines, then implement or revert accordingly.

---

# 169. Step 09.17 — Record Debt and Documentation

Record intentional compromises, update technical documentation, and prepare operational guidance without hiding failed critical obligations as debt.

---

# 170. Step 09.18 — Update GOV-009

Update control implementation location, status, evidence, remaining verification, exception, release restriction, and operational owner.

---

# 171. Step 09.19 — Complete Coverage and Evidence

Run unimplemented-obligation, orphan-change, missing-evidence, version-conflict, and status-overstatement checks.

---

# 172. Step 09.20 — Create Implementation Snapshot

Freeze canonical source revisions, artifacts, schema, migrations, infrastructure, configuration identities, environment, deployment, flags, evidence, and open items.

---

# 173. Step 09.21 — Prepare Verification Candidate

Define the candidate scope, environment, data, identities, versions, known issues, restrictions, and evidence index.

---

# 174. Step 09.22 — Validate Implementation

Review DoD, source and environment identity, parity, controls, checks, migration, deployment, evidence, defects, deviations, coverage, and handoff readiness.

---

# 175. Step 09.23 — Prepare Phase 10 Handoff

Provide immutable candidate references, verification allocations, test data / environment, known items, evidence, and change restrictions.

---

# 176. Step 09.24 — Run G6A

Accountable approvers review the Implementation Baseline and issue one gate outcome.

A merged branch, green build, or staging deployment alone cannot pass G6A.

---

# 177. Phase 09 Artifact Catalog

| Artifact ID | Artifact | Purpose |
|---|---|---|
| `IMP-001` | Implementation Scope and Run Register | Define baselined implementation runs |
| `IMP-002` | Implementation Status Register | Maintain truthful multi-dimensional status |
| `IMP-003` | Change Set, Revision, and Review Register | Preserve source provenance and review |
| `IMP-004` | Build and Implementation Check Record | Record build and developer checks |
| `IMP-005` | UI and Design-System Implementation Record | Track product UI realization |
| `IMP-006` | Design Parity and Adoption Record | Prove design source alignment and actual adoption |
| `IMP-007` | API, Event, Job, and Integration Implementation Record | Track machine-boundary implementation |
| `IMP-008` | Data, Schema, Lifecycle, and Migration Record | Track data implementation and execution |
| `IMP-009` | Identity, Authentication, Session, and Recovery Record | Track identity implementation |
| `IMP-010` | Authorization, Tenancy, and Administrative Access Record | Track permission and isolation implementation |
| `IMP-011` | Security and Privacy Control Implementation Record | Track control mechanisms and evidence |
| `IMP-012` | Audit and Evidence Mechanism Implementation Record | Track trustworthy audit implementation |
| `IMP-013` | Accessibility, Localization, and Generated-Output Record | Track cross-cutting product implementation |
| `IMP-014` | Reliability, Failure, Backup, and Recovery Record | Track resilience implementation |
| `IMP-015` | Performance, Capacity, and Resource-Control Record | Track performance and scaling implementation |
| `IMP-016` | Observability, Logging, Health, and Alert Record | Track operational signals |
| `IMP-017` | Configuration, Secret, Key, and Feature-Flag Record | Track runtime control implementation |
| `IMP-018` | Infrastructure, Environment, and Network Change Record | Track platform changes and evidence |
| `IMP-019` | CI/CD, Supply Chain, Build Artifact, and Provenance Record | Track delivery controls and artifacts |
| `IMP-020` | Deployment, Rollout, and Rollback Record | Track candidate movement across environments |
| `IMP-021` | Dependency, License, and Generated-Code Record | Govern source and supply dependencies |
| `IMP-022` | Developer Check and Test Evidence Index | Index implementation checks |
| `IMP-023` | Implementation Defect, Blocker, and Question Register | Track obstacles and failures |
| `IMP-024` | Implementation Deviation and Exception Register | Control baseline divergence |
| `IMP-025` | Technical Debt and Documentation Record | Record compromises and implementation knowledge |
| `IMP-026` | GOV-009 Control Implementation Matrix | Map standards to actual mechanisms |
| `IMP-027` | Implementation Coverage and Traceability Matrix | Prove complete implemented disposition |
| `IMP-028` | Implementation Evidence Index | Provide durable claim-to-evidence mapping |
| `IMP-029` | Verification Candidate Register | Define immutable Phase 10 candidates |
| `IMP-030` | Implementation Validation Record | Record implementation reviews and findings |
| `IMP-031` | Phase 10 Verification Handoff | Provide candidate, scope, evidence, and conditions |
| `IMP-032` | Implementation Baseline Index | Identify canonical implementation snapshot and G6A evidence |

Artifacts may be consolidated or separated by profile. IDs and obligations remain stable.

---

# 178. IMP-001 — Implementation Scope and Run Register

Minimum content:

```text
Implementation Run ID
ERBL / release / slice scope
Repositories / modules
Owners
Target environments
Dependencies / conditions
Start / target dates where governed
Status
Evidence index
```

---

# 179. IMP-002 — Implementation Status Register

Minimum content:

```text
Object / work item
Work / review / build / test status
Migration / deployment status
Verification / release status
Current revision
Owner
Blocker / defect / deviation
Evidence
Last updated
```

---

# 180. IMP-003 — Change Set, Revision, and Review Register

Minimum content:

```text
Change Set ID
Work and baseline IDs
Repository / branch / base / head
Affected targets
Risk and migration / rollout
Reviewers and outcome
Required checks
Merge / revision evidence
Status
```

---

# 181. IMP-004 — Build and Implementation Check Record

Minimum content:

```text
Revision / artifact
Toolchain and dependency lock
Build configuration
Check inventory
Environment / data
Result / failures / skips
Artifact identity / provenance
Evidence
Owner
```

---

# 182. IMP-005 — UI and Design-System Implementation Record

Minimum content:

```text
Design source / revision
Code repository / component / screen
Tokens / themes / modes
States and variants
Responsive / platform / RTL
Content / assets / motion
Accessibility
Tests / evidence
Implementation status
```

---

# 183. IMP-006 — Design Parity and Adoption Record

Minimum content:

```text
Design object
Code target
Actual product consumers
Comparison method / environment
Modes / states covered
Findings
Approved divergence
Resolution
Evidence
Status
```

---

# 184. IMP-007 — API, Event, Job, and Integration Implementation Record

Minimum content:

```text
Contract and version
Producer / consumer
Code target
Schema / validation / errors
Authentication / authorization
Idempotency / ordering / retry
Compatibility
Observability
Checks and evidence
```

---

# 185. IMP-008 — Data, Schema, Lifecycle, and Migration Record

Minimum content:

```text
Data / schema objects
Source and target revision
Classification / ownership
Constraints / indexes
Migration / backfill / retention / deletion
Precheck / backup / execution
Validation / reconciliation
Rollback / forward fix
Evidence / status
```

---

# 186. IMP-009 — Identity, Authentication, Session, and Recovery Record

Minimum content:

```text
Identity types and authority
Authentication / MFA / federation
Credential and recovery behavior
Session issuance / rotation / revocation
Service identity
Failure and rate controls
Accessibility
Audit / telemetry
Checks and evidence
```

---

# 187. IMP-010 — Authorization, Tenancy, and Administrative Access Record

Minimum content:

```text
Policy source and version
Decision / enforcement points
Action / resource / tenant context
Default deny / cache / revocation
Tenant isolation across layers
Delegation / acting capacity
Support / administrative access
Audit / checks / evidence
```

---

# 188. IMP-011 — Security and Privacy Control Implementation Record

Minimum content:

```text
Control / risk / obligation
Implementation and configuration target
Enforcement point
Safe defaults / failure behavior
Telemetry
Privacy / data effect
Owner
Check / evidence
Remaining verification
Exception
```

---

# 189. IMP-012 — Audit and Evidence Mechanism Implementation Record

Minimum content:

```text
Audit event / mechanism
Actor / capacity / tenant
Action / target / outcome / reason
Correlation
Integrity / retention / access
Monitoring / export
Implementation target
Sample / check / evidence
```

---

# 190. IMP-013 — Accessibility, Localization, and Generated-Output Record

Minimum content:

```text
Platforms / surfaces / outputs
Semantics / focus / keyboard / forms / errors
Reflow / zoom / reduced motion
Locales / RTL / timezone / money
Fonts / shaping / content
Generated-output structure
Implementation targets
Checks / evidence / known limits
```

---

# 191. IMP-014 — Reliability, Failure, Backup, and Recovery Record

Minimum content:

```text
Failure scenarios
Timeout / retry / idempotency
Isolation / degradation / reconciliation
SLO signals
Backup / restore
Disaster / recovery mechanisms
Implementation targets
Checks / evidence
```

---

# 192. IMP-015 — Performance, Capacity, and Resource-Control Record

Minimum content:

```text
Budget / QAS
Code / query / cache / payload controls
Queue / backpressure / quotas
Scaling / resource configuration
Cost labels / signals
Sanity checks
Evidence / remaining load verification
```

---

# 193. IMP-016 — Observability, Logging, Health, and Alert Record

Minimum content:

```text
Signal / schema / owner
Log redaction
Correlation
Metrics / traces
Health / readiness
Dashboard / alert / runbook link
Retention / access
Implementation target
Checks / evidence
```

---

# 194. IMP-017 — Configuration, Secret, Key, and Feature-Flag Record

Minimum content:

```text
Configuration / secret / key / flag ID
Schema / class
Source / environment / owner
Injection / access
Rotation / revocation
Default / failure
Rollout / removal
Audit / evidence
```

---

# 195. IMP-018 — Infrastructure, Environment, and Network Change Record

Minimum content:

```text
Architecture source
Infrastructure source / revision
Target identity
Plan and approvals
Resources / network / access
Data / secret / cost impact
Apply result
Post-change checks
Rollback / drift
Evidence
```

---

# 196. IMP-019 — CI/CD, Supply Chain, Build Artifact, and Provenance Record

Minimum content:

```text
Repository / pipeline / revision
Branch protections / checks / scans
Build identity / dependency lock
Artifact / checksum / provenance / signing
Registry / promotion
Migration / deployment controls
Approvals / rollback
Evidence retention
```

---

# 197. IMP-020 — Deployment, Rollout, and Rollback Record

Minimum content:

```text
Environment / project / domain identity
Source / artifact / configuration / migration
Deployment strategy
Flag / cohort
Health / smoke
Success / abort criteria
Rollback / forward fix
Result / evidence
```

---

# 198. IMP-021 — Dependency, License, and Generated-Code Record

Minimum content:

```text
Dependency / generator
Version / source / lock
Purpose / consumer
License
Security / maintenance
Runtime / bundle impact
Generation input / rule
Review / tests
Update / removal
```

---

# 199. IMP-022 — Developer Check and Test Evidence Index

Minimum content:

```text
Check ID / type
Work / change set / revision
Method / environment / data
Expected / actual
Failures / skips
Artifact / evidence
Owner
Status
```

---

# 200. IMP-023 — Implementation Defect, Blocker, and Question Register

Minimum content:

```text
Item ID / type
Affected work / baselines
Observed issue / question
Environment / revision / evidence
Severity / blocking
Owner / due date / escalation
Resolution / recheck
Status
```

---

# 201. IMP-024 — Implementation Deviation and Exception Register

Minimum content:

```text
Deviation / exception ID
Affected baseline / object
Evidence and reason
Impact assessment
Temporary containment
Authority / decision
Expiry / reopen
Reconciliation changes
Verification / status
```

---

# 202. IMP-025 — Technical Debt and Documentation Record

Minimum content:

```text
Debt / documentation ID
Origin / affected objects
Compromise / knowledge
Risk and temporary controls
Owner / horizon
Retirement / update condition
Source location
Evidence / status
```

---

# 203. IMP-026 — GOV-009 Control Implementation Matrix

Minimum content:

```text
GOV-009 entry / control
Code / configuration / infrastructure / migration target
Implementation status
Evidence
Remaining verification
Release / operational owner
Exception / condition
```

---

# 204. IMP-027 — Implementation Coverage and Traceability Matrix

Minimum relationships:

```text
Requirement → Work → Change → Evidence
Experience / Design → Code / Asset → Parity Evidence
Architecture / ADR → Code / Schema / Config / Infrastructure
Standard / Control → Mechanism → Evidence
Change → Build / Check / Migration / Deployment
Implemented Object → Verification Candidate / Phase 10 Test Scope
```

---

# 205. IMP-028 — Implementation Evidence Index

Minimum content:

```text
Evidence ID / type
Claim / obligation
Object / revision / environment
Producer / time
Result
Location
Sensitivity / access / retention
Reviewer
Candidate / gate consumer
```

---

# 206. IMP-029 — Verification Candidate Register

Minimum content:

```text
Candidate ID / revision
Implementation Baseline
Slice / work scope
Source revisions
Artifacts / schemas / migrations / config identities
Environment / deployment / flags
Test data / identities
Known defects / deviations / restrictions
Evidence index
Status
```

---

# 207. IMP-030 — Implementation Validation Record

Minimum content:

```text
Review ID / method
Scope and revisions
Participants
DoD and check results
Findings / severity
Affected IDs
Owner / resolution / evidence
Residual risk
Status
```

---

# 208. IMP-031 — Phase 10 Verification Handoff

Minimum content:

```text
Implementation Baseline and candidate IDs
Scope and exclusions
Source / artifact / environment / deployment identity
Requirements / design / architecture / standards mappings
Verification allocations and acceptance criteria
Test data / identities / tools
Evidence index
Known defects / deviations / debt / conditions
Change freeze / candidate update rules
Owners and acknowledgement
```

---

# 209. IMP-032 — Implementation Baseline Index

Minimum content:

```text
Baseline ID / version / gate scope
ERBL and upstream revisions
Canonical source / artifact / schema / infrastructure revisions
Environment / deployment / flag snapshot
Artifact status matrix
Coverage metrics
Evidence index
Open items and restrictions
G6A evidence
```

---

# 210. Governance Registers Updated by Phase 09

Phase 09 updates or references:

```text
REG-DEC — Decision Register
REG-RSK — Risk Register
REG-ASM — Assumption Register
REG-DEP — Dependency Register
REG-ISS — Issue Register
REG-CHG — Change Register
REG-TRC — Traceability Register
REG-STD — Standards / GOV-009 Register
REG-VAL — Validation and Evidence Register
REG-IMP — Implementation Status Register
REG-CHS — Change Set Register
REG-DEF — Defect Register
REG-DEV — Deviation Register
REG-DEBT — Technical Debt Register
REG-DEPLOY — Deployment Register
REG-CAND — Verification Candidate Register
```

---

# 211. Implementation Profiles

Product OS uses:

```text
P1 — Lean
P2 — Standard
P3 — Comprehensive
```

Profiles change artifact separation, control depth, and evidence—not implementation truth.

---

# 212. P1 — Lean Implementation

Appropriate for low-risk, narrow-scope changes.

Minimum expectations:

```text
Confirmed scope / repository / environment
Traceable change sets and reviews
Required code / data / config / infrastructure changes
Critical checks
Security / accessibility / reliability / observability obligations
Migration / deployment safety
Status and evidence
Deviation control
Verification candidate and G6A
```

Artifacts may be consolidated into implementation and evidence records.

---

# 213. P2 — Standard Implementation

The default production profile.

Includes complete applicable `IMP-001` through `IMP-032` obligations with independently reviewable records where ownership or risk requires them.

---

# 214. P3 — Comprehensive Implementation

Appropriate for regulated, high-risk, high-scale, multi-team, multi-repository, multi-platform, or complex migration delivery.

Additional depth may include:

```text
Formal provenance and signing
Separation of duties
Independent security / privacy / accessibility implementation review
Controlled infrastructure and migration approvals
Multi-environment evidence
Formal design and architecture parity
Resilience / restore rehearsal
Supply-chain assurance
Candidate immutability and evidence custody
Formal deviation / exception governance
```

---

# 215. Domain-Level Profile Overrides

Example:

```text
Project profile: P2
Payment and ledger changes: P3
Tenant authorization: P3
Internal documentation: P1
Mobile client implementation: P2
Production migration: P3
```

---

# 216. Profile Selection Inputs

Consider user harm, financial impact, data sensitivity, regulation, migration reversibility, source and team count, deployment risk, platform distribution, control criticality, operational impact, and evidence depth.

---

# 217. Behavior by Product Stage

Implementation adapts across:

```text
S0 — Concept
S1 — Prototype
S2 — MVP
S3 — Growth
S4 — Scale
S5 — Enterprise / Regulated
S6 — Legacy Transformation
```

---

# 218. S0 / S1 — Concept and Prototype

Keep prototype source and artifacts clearly separated from production implementation.

Record disposable assumptions, generated code, security limits, unsupported states, and evidence needed before reuse.

---

# 219. S2 — MVP

Implement the minimum coherent production-safe scope with complete critical states, controls, migrations, observability, evidence, and explicit deferral.

MVP is not permission to skip safe defaults or recovery.

---

# 220. S3 / S4 — Growth and Scale

Focus on modular ownership, compatibility, migration, automation, performance, observability, deployment safety, design-system adoption, supply chain, and technical debt control.

---

# 221. S5 — Enterprise or Regulated

Focus on control evidence, audit integrity, data lineage, separation of duties, migration custody, provenance, environment assurance, independent reviews, and exception governance.

---

# 222. S6 — Legacy Transformation

Focus on evidenced current behavior, characterization tests, compatibility, parallel run, incremental migration, drift, data reconciliation, rollback limits, source authority, and safe retirement.

---

# 223. Existing Implementation Assessment

Before changing an existing system, inspect:

```text
Git status / branches / remotes / revisions
Tracked and untracked source
Build and test configuration
Dependency manifests and locks
Schemas and migrations
Runtime and deployment configuration
Provisioned project and domain identity
Environment variables by key identity, not exposed values
CI/CD and artifact registries
Logs / incidents / known defects
Implementation-status claims
```

---

# 224. Dirty Worktree Rule

Existing changes belong to their owner unless proven otherwise.

Preserve unrelated work, isolate intended changes, and do not overwrite or discard unknown modifications.

---

# 225. Current vs Target Implementation

Record:

```text
Confirmed current source / deployment
Approved target
Transition change sets
Compatibility
Migration
Evidence
Retirement condition
```

---

# 226. Implementation Coverage Model

Coverage dimensions:

```text
Slice / work item
Requirement
Experience / state
Design / code
Architecture / ADR
Data / migration
API / integration / event
Security / privacy / audit
Accessibility / localization
Reliability / performance / observability
Environment / deployment
Standards / controls
Evidence / verification candidate
```

---

# 227. Work Completion Coverage

Every G6A-scope work item must be implemented, explicitly deferred, not applicable, cancelled, superseded, or blocked with gate treatment.

---

# 228. Requirement Implementation Coverage

Each in-scope requirement must map to source changes and implementation evidence or an approved disposition.

---

# 229. State Implementation Coverage

Each applicable experience and design state must map to code, content, behavior, checks, and evidence.

---

# 230. Control Implementation Coverage

Each applicable control must map to actual enforcement / configuration targets, telemetry, implementation evidence, and remaining Phase 10 verification.

---

# 231. Migration Execution Coverage

Each planned migration must have source, target, execution status, environment, validation, reconciliation, recovery, and evidence disposition.

---

# 232. Environment and Deployment Coverage

Every verification candidate must have known environment, deployment, artifact, configuration, migration, flag, domain, and health identity.

---

# 233. Evidence Coverage

Every implemented claim requiring evidence must map to a valid `IEVID` record.

---

# 234. Implementation Baseline

The Implementation Baseline is the approved, versioned snapshot of implemented source, artifacts, schemas, migrations, configuration identities, infrastructure, deployments, flags, status, evidence, open items, and verification candidates for a named scope.

---

# 235. Baseline Contents

At minimum:

```text
Scope / profile / ERBL reference
Canonical repositories and revisions
Build artifacts and provenance
Schema / migration versions and results
Configuration / infrastructure revisions
Environment / deployment / domain identity
Feature flag state
Implementation status
Design / architecture / standards parity
Coverage and evidence index
Defects / blockers / deviations / debt
Verification candidate and Phase 10 handoff
G6A decision
```

---

# 236. Implementation Baseline Versioning

```yaml
baseline_id: IBL-2026-001
phase: PHASE-09
gate: G6A
version: 1.0
status: APPROVED
engineering_readiness_baseline: ERBL-2026-001
requirements_baseline: RBL-2026-001
design_baseline: DBL-2026-001
architecture_baseline: ABL-2026-001
gov_009_revision: GOV-009@1.6
candidate: IVCAND-REL-001-RC1
```

---

# 237. G6A — Implementation Baseline

`G6A` answers:

> Does the named scope exist as traceable, reviewed, check-passing, safely migrated and deployable implementation with truthful status, complete evidence, controlled deviations, and a stable Phase 10 verification candidate?

---

# 238. G6A Check 01 — Scope and Baseline Integrity

Confirm valid G5B scope, upstream versions, profile, conditions, and no uncontrolled scope expansion.

---

# 239. G6A Check 02 — Repository, Branch, and Revision Identity

Confirm canonical repositories, remotes, branches, base / head revisions, and intended changes.

---

# 240. G6A Check 03 — Work-Item Implementation Status

Confirm every scoped work item has truthful disposition, owner, source changes, and evidence.

---

# 241. G6A Check 04 — Change Set and Review Integrity

Confirm coherent changes, required reviewers, findings resolved, approvals tied to exact revisions, and no hidden unrelated changes.

---

# 242. G6A Check 05 — Build and Artifact Integrity

Confirm builds, dependency locks, artifacts, provenance / signing where required, warnings, and exact source mapping.

---

# 243. G6A Check 06 — Developer and Integration Checks

Confirm required format, lint, type, static, unit, component, contract, integration, build, startup, and smoke checks pass for the candidate.

---

# 244. G6A Check 07 — UI and Design-System Implementation

Confirm tokens, components, screens, states, content, assets, responsive, platform, RTL, accessibility, motion, and generated outputs are implemented.

---

# 245. G6A Check 08 — Design Parity and Adoption

Confirm design source revisions, actual product adoption, parity evidence, and approved divergences.

---

# 246. G6A Check 09 — Domain and Application Behavior

Confirm domain rules, state transitions, validation, concurrency, error, recovery, and approved behavior are implemented.

---

# 247. G6A Check 10 — API, Event, Job, and Integration Contracts

Confirm schemas, versions, security, errors, idempotency, ordering, retry, compatibility, observability, and checks.

---

# 248. G6A Check 11 — Data and Schema Integrity

Confirm ownership, classification, constraints, indexes, lifecycle, access, and schema compatibility.

---

# 249. G6A Check 12 — Migration and Backfill Execution

Confirm prechecks, backup, execution, validation, reconciliation, recovery, evidence, and exact environment status.

---

# 250. G6A Check 13 — Identity, Authentication, Session, and Recovery

Confirm approved identity trust, credential handling, MFA / federation, sessions, revocation, recovery, failure controls, and evidence.

---

# 251. G6A Check 14 — Authorization, Tenancy, and Administrative Access

Confirm policy enforcement, default deny, tenant propagation / isolation, delegation, support access, audit, and implementation checks.

---

# 252. G6A Check 15 — Security and Privacy Controls

Confirm controls exist in source / configuration / infrastructure with safe failure, telemetry, evidence, and no exposed secret.

---

# 253. G6A Check 16 — Audit and Evidence Mechanisms

Confirm audit coverage, context, outcome, integrity, retention, access, monitoring, and implementation samples.

---

# 254. G6A Check 17 — Accessibility and Localization

Confirm semantics, keyboard, focus, forms, errors, reflow, reduced motion, locale, RTL, timezone, currency, fonts, and generated outputs.

---

# 255. G6A Check 18 — Reliability and Failure Handling

Confirm timeouts, retries, idempotency, isolation, degradation, unknown outcomes, reconciliation, backup, restore, and recovery mechanisms.

---

# 256. G6A Check 19 — Performance, Capacity, and Resource Controls

Confirm budgets, caching, queries, payloads, queues, backpressure, quotas, scaling configuration, instrumentation, and sanity evidence.

---

# 257. G6A Check 20 — Observability, Logging, Health, and Alerts

Confirm safe logs, metrics, traces, correlation, health, dashboards, alerts, redaction, retention, access, and owner.

---

# 258. G6A Check 21 — Configuration, Secrets, Keys, and Flags

Confirm sources, schemas, environment isolation, access, rotation / revocation, defaults, failure, rollout, removal, and evidence.

---

# 259. G6A Check 22 — Infrastructure, Environment, and Network Changes

Confirm plans, approvals, target identity, apply results, access, exposure, cost, post-change checks, drift, and rollback.

---

# 260. G6A Check 23 — CI/CD and Supply Chain

Confirm source protections, checks, scans, build identity, artifacts, registries, promotion, migrations, deployment controls, and evidence retention.

---

# 261. G6A Check 24 — Deployment, Rollout, and Runtime Health

Confirm exact project / environment / domain / artifact / config / migration / flag identity, startup, smoke, health, and rollback path.

---

# 262. G6A Check 25 — Dependencies, Licenses, and Generated Code

Confirm approved purpose, source, version, lock, license, security, provenance, review, tests, update, and removal path.

---

# 263. G6A Check 26 — Defects, Blockers, Deviations, and Debt

Confirm no hidden critical item, approved deviations are reconciled, debt is not a critical failure, and remaining items have Phase 10 / release treatment.

---

# 264. G6A Check 27 — GOV-009 Implementation Status

Confirm every active implementation obligation has mechanism, evidence, remaining verification, exception, and operational owner without overstated compliance.

---

# 265. G6A Check 28 — Coverage and Traceability

Confirm all scoped requirements, states, designs, architecture objects, controls, work items, changes, and evidence form a complete bidirectional chain.

---

# 266. G6A Check 29 — Verification Candidate Integrity

Confirm immutable source, artifact, schema, migration, configuration, environment, deployment, flag, data, known-item, and evidence references.

---

# 267. G6A Check 30 — Phase 10 Handoff

Confirm verification owners acknowledge candidate, scope, environments, data, allocations, evidence, restrictions, candidate-change rules, and open items.

---

# 268. G6A Outcomes

Allowed outcomes:

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

- `PASS` — candidate may enter full Phase 10 verification.
- `PASS_WITH_CONDITIONS` — named verification may proceed under explicit non-blocking limitations.
- `HOLD` — gate awaits named implementation, evidence, environment, or decision.
- `REJECT` — material implementation deficiency requires correction and another gate review.

---

# 269. G6A Blocking Conditions

G6A cannot pass affected scope with a material:

```text
Invalid G5B scope or revision
Unreviewed or untraceable source change
Failed required build / startup / migration / check
Unknown repository / artifact / deployment identity
Missing critical state / control / migration
Unresolved critical or high defect
Unapproved design / architecture / standard deviation
Exposed secret or unsafe configuration
Unknown data migration integrity
Missing runtime health or diagnostic evidence
Incomplete implementation coverage
Mutable or ambiguous verification candidate
No Phase 10 handoff acknowledgement
```

---

# 270. PASS_WITH_CONDITIONS Rules

A condition is permitted only when:

```text
The implementation is safe for the permitted verification boundary
Affected candidate scope is explicit
Risk and limitation are understood
Owner and due date exist
Closure evidence is defined
Prohibited verification / release actions are recorded
Candidate invalidation / G6A reopen trigger exists
```

---

# 271. G6A Evidence Record

```yaml
gate_id: G6A
phase: PHASE-09
baseline_id: IBL-2026-001
candidate_id: IVCAND-REL-001-RC1
decision: PASS_WITH_CONDITIONS
decision_date: 2026-08-10
scope:
  release: REL-001
  slices: [ESL-APR-REVIEW-001]
upstream:
  engineering_readiness_baseline: ERBL-2026-001
  requirements_baseline: RBL-2026-001
  design_baseline: DBL-2026-001
  architecture_baseline: ABL-2026-001
  gov_009_revision: GOV-009@1.6
source:
  REPO-APR-API: a1b2c3d
  REPO-APR-WEB: d4e5f6a
environment:
  id: STAGING-01
  deployment: DEPLOY-2026-0810-014
checks:
  total: 30
  passed: 29
  conditional: 1
  failed: 0
conditions:
  - id: G6A-COND-001
    scope: "Cross-browser visual verification"
    owner: ROLE-QA
    due_date: 2026-08-12
    permitted_work: "Functional, API, security, and accessibility verification"
    prohibited_work: "Design parity sign-off and release approval"
approvals:
  engineering: APPROVED
  architecture: APPROVED
  design: APPROVED_WITH_CONDITION
  security_privacy: APPROVED
  verification: ACKNOWLEDGED
evidence:
  - IMP-027
  - IMP-028
  - IMP-029
  - IMP-030
  - IMP-031
```

---

# 272. Gate Approvers

Typical approvers and acknowledgers:

```text
Engineering Lead
Repository / Module Owners
Solution Architect
Product Design / Experience Owner
Security / Privacy Owner
Data / Migration Owner
Platform / Operations Owner
QA / Verification Lead
Product Owner
Business or regulatory authority where required
```

AI cannot approve G6A.

---

# 273. Phase 10 Handoff

Phase 10 receives:

```text
Implementation Baseline and candidate IDs
Exact source / artifact / schema / config / infrastructure revisions
Environment / deployment / domain / flag identity
Scope and exclusions
Acceptance and verification allocations
Test data / identities / tools
Design / architecture / standards mappings
Implementation checks and evidence
Known defects / deviations / debt / conditions
Candidate invalidation rules
Owners and support contacts
```

---

# 274. Phase 11 Handoff

Phase 11 ultimately receives implemented observability, alerts, runbooks, backup / restore, rotations, capacity controls, support diagnostics, deployment records, and technical debt after Phase 10 release approval.

---

# 275. Canonical Traceability Chain

```text
Goal / Standard
→ Requirement
→ Experience / Design
→ Architecture / ADR
→ Engineering Slice / Work Item
→ Change Set / Revision
→ Code / Schema / Config / Infrastructure / Asset
→ Build / Migration / Deployment Evidence
→ Verification Candidate
→ Verification Evidence
→ Release / Operational Evidence
```

---

# 276. Candidate Change Control

Any material change after candidate submission requires:

```text
New candidate revision
Changed-object inventory
Impact on prior evidence
Required regression scope
Deployment / migration / flag update
Known-item update
Phase 10 acknowledgement
```

---

# 277. Change Control After G6A

Assess impact across requirements, design, architecture, readiness, code, data, controls, environments, evidence, verification, release, operations, and `GOV-009`.

---

# 278. G6A Reopen Triggers

Reopen affected G6A scope when material changes affect:

```text
Source revision or artifact
Schema / migration / data
Configuration / secret / key class
Infrastructure / environment / network
Feature flag / cohort
Critical dependency
Design / architecture parity
Security / privacy / accessibility control
Reliability / performance / observability behavior
Critical defect / deviation
Evidence validity
Candidate scope or gate condition
```

---

# 279. Implementation Roles

Core roles may include:

```text
Engineering Lead
Implementing Engineer
Repository / Module Owner
Code Reviewer
Product Owner
Solution Architect
Product Designer / Experience Architect
Security / Privacy Owner
Data / Migration Owner
Accessibility Specialist
Platform / Operations Owner
QA / Verification Lead
Release / Delivery Owner
```

---

# 280. Engineering Lead Responsibilities

```text
Own Phase 09 coherence
Confirm scope and source identity
Coordinate implementation and dependencies
Enforce reviews and checks
Maintain truthful status
Route deviations
Prepare G6A evidence and Phase 10 handoff
```

---

# 281. Implementing Engineer Responsibilities

```text
Understand work and upstream contracts
Implement safely in canonical targets
Add / update checks and documentation
Protect secrets and data
Produce evidence
Raise blockers, defects, and deviations
Maintain status and traceability
```

---

# 282. Reviewer Responsibilities

Review the exact revision for behavior, correctness, boundaries, controls, data, accessibility, performance, tests, migration, documentation, and evidence within assigned expertise.

---

# 283. Product and Design Responsibilities

```text
Clarify approved intent
Review behavior / content / parity
Assess implementation-driven changes
Approve or reject deviations within authority
Protect critical states and accessibility
```

---

# 284. Architecture Responsibilities

```text
Review boundary and contract conformance
Assess data / integration / migration / deployment changes
Review architecture deviations
Maintain ADR and mapping reconciliation
```

---

# 285. Security, Privacy, and Data Responsibilities

```text
Review critical control implementation
Review sensitive data and migration changes
Validate evidence and safe failure
Approve exceptions / residual risk within authority
Support Phase 10 verification scope
```

---

# 286. Platform and Operations Responsibilities

```text
Implement / review infrastructure, environment, config, secrets, pipeline, deployment, observability, backup, and recovery changes
Confirm target identity and runtime evidence
Prepare operational handoff
```

---

# 287. QA and Verification Responsibilities

```text
Review testability and candidate integrity
Advise on developer checks without taking implementation ownership
Confirm evidence and environment readiness
Acknowledge handoff
Control Phase 10 verification status independently
```

---

# 288. AI Responsibilities in Phase 09

AI may assist with:

```text
Code and configuration drafting
Test and migration drafting
Static review and consistency checks
Traceability updates
Design / architecture mapping checks
Potential defect / threat / failure analysis
Documentation drafting
Evidence indexing
Change impact analysis
```

AI-generated output requires human review and project checks.

---

# 289. AI Prohibitions

AI must not:

```text
Invent approval or status
Expose or reproduce secrets
Assume deployment / environment identity
Overwrite unrelated user changes
Silently change baselines
Treat generated code as trusted or implemented without review
Declare security / accessibility / compliance verified
Accept defects, deviations, debt, or risk
Declare G6A passed
```

---

# 290. Human Accountability

Humans remain accountable for source changes, reviews, deployment authority, data migration, security and privacy decisions, deviation approval, evidence acceptance, and G6A.

---

# 291. Phase 09 Validation Rules

Rules apply unless explicitly `NOT_APPLICABLE` with reason, owner, evidence, and reopen condition.

---

# 292. VAL-IMP-001 — G5B Scope Integrity

Every implementation object must trace to approved G5B scope, defect, debt, or governed emergency change.

---

# 293. VAL-IMP-002 — Canonical Source Identity

Every source change must identify canonical repository, branch, base / head revision, and owner.

---

# 294. VAL-IMP-003 — No Unrelated Overwrite

Implementation must preserve unrelated working-tree and user-owned changes.

---

# 295. VAL-IMP-004 — Review Integrity

Required review and approvals must apply to the exact candidate revision.

---

# 296. VAL-IMP-005 — Required Checks

All required implementation checks must pass or have a valid, scoped waiver before `IMPLEMENTED` status.

---

# 297. VAL-IMP-006 — Build vs Runtime Distinction

Build success cannot be used as runtime, deployment, verification, or release evidence.

---

# 298. VAL-IMP-007 — Design Source Integrity

UI implementation must reference compatible approved design sources and record parity evidence.

---

# 299. VAL-IMP-008 — State Completeness

Applicable success, loading, error, denied, conflict, offline, processing, unknown-outcome, interruption, and recovery states must be implemented.

---

# 300. VAL-IMP-009 — Accessibility Implementation

Applicable accessibility contracts must exist in production code and remain in the Phase 10 verification scope.

---

# 301. VAL-IMP-010 — Contract Compatibility

Critical API, event, integration, schema, and client changes must preserve or govern compatibility.

---

# 302. VAL-IMP-011 — Data Migration Integrity

Migrations require exact environment, precheck, backup / recovery, execution, validation, reconciliation, and evidence.

---

# 303. VAL-IMP-012 — Authorization and Tenant Isolation

Authorization and tenant context must be enforced across all affected layers with safe failure and checks.

---

# 304. VAL-IMP-013 — Security and Privacy Controls

Applicable controls must have actual implementation targets, safe defaults, telemetry, evidence, and remaining verification.

---

# 305. VAL-IMP-014 — Secret Safety

No source, artifact, log, evidence, or documentation may expose actual secrets.

---

# 306. VAL-IMP-015 — Audit Integrity

Critical audit events must preserve actor, context, action, target, outcome, integrity, access, and evidence.

---

# 307. VAL-IMP-016 — Failure and Unknown Outcome

Critical flows must implement approved timeout, retry, idempotency, partial-failure, unknown-outcome, reconciliation, and recovery behavior.

---

# 308. VAL-IMP-017 — Observability

Critical changed behavior must produce safe, useful, owned diagnostic signals.

---

# 309. VAL-IMP-018 — Environment Identity

Every deployment and migration must identify actual project, environment, data target, source revision, artifact, configuration, and domain / alias as applicable.

---

# 310. VAL-IMP-019 — Configuration Truth

Required, configured, provisioned, and runtime-effective configuration states must not be conflated.

---

# 311. VAL-IMP-020 — Infrastructure Plan and Apply

Material infrastructure changes require reviewed plan, exact target, apply result, post-checks, and evidence.

---

# 312. VAL-IMP-021 — Supply Chain

Dependencies, generators, builds, and artifacts must have approved sources, versions, review, license / security disposition, and provenance appropriate to risk.

---

# 313. VAL-IMP-022 — Status Evidence

Every material status claim must link to evidence appropriate to that status dimension.

---

# 314. VAL-IMP-023 — Defect and Blocker Visibility

Critical defects and blockers cannot be hidden, downgraded without authority, or relabeled as technical debt.

---

# 315. VAL-IMP-024 — Deviation Control

Material differences from baselines require approved deviation before becoming canonical implementation direction.

---

# 316. VAL-IMP-025 — GOV-009 Truth

Control implementation status must not be represented as verified compliance without Phase 10 evidence and appropriate authority.

---

# 317. VAL-IMP-026 — Coverage

No critical G6A-scope obligation may lack implementation disposition and evidence.

---

# 318. VAL-IMP-027 — Evidence Integrity

Evidence must identify claim, revision, environment, producer, method, time, result, and protected location.

---

# 319. VAL-IMP-028 — Candidate Integrity

The verification candidate must reference one compatible implementation snapshot and disclose known items and restrictions.

---

# 320. VAL-IMP-029 — Candidate Change

Material candidate changes must update revision and invalidate or reassess affected evidence.

---

# 321. VAL-IMP-030 — Human Approval

G6A requires accountable human approval; automated build or coverage checks cannot issue the gate decision.

---

# 322. Implementation Anti-Patterns

The following patterns weaken or invalidate Phase 09.

---

# 323. Anti-Pattern 01 — Code First, Contract Later

Starting without approved scope, target, dependencies, acceptance, and evidence creates rework and hidden decisions.

---

# 324. Anti-Pattern 02 — Green Build Means Done

A passing build does not prove runtime, migration, design, security, accessibility, integration, or release behavior.

---

# 325. Anti-Pattern 03 — Merge Means Implemented Everywhere

Merged source may not be built, deployed, configured, migrated, enabled, or verified.

---

# 326. Anti-Pattern 04 — Staging Means Production Ready

Staging cannot prove production identity, scale, data, vendor, network, or operational conditions by itself.

---

# 327. Anti-Pattern 05 — Latest Branch as Candidate

An unspecified moving branch makes verification evidence non-reproducible.

---

# 328. Anti-Pattern 06 — Fix Design in Code

Material screen, state, content, component, or accessibility changes require design / experience review and reconciliation.

---

# 329. Anti-Pattern 07 — Fix Architecture in Code

Material boundary, data, interface, control, deployment, or failure changes require architecture review and ADR reconciliation.

---

# 330. Anti-Pattern 08 — Generic Repository Identity

Using `backend`, `frontend`, or `database` instead of confirmed canonical targets breaks provenance and deployment verification.

---

# 331. Anti-Pattern 09 — Full Payload Logging

Blind request, response, document, token, or personal-data logging creates security and privacy risk.

---

# 332. Anti-Pattern 10 — Secrets for Debugging

Printing, pasting, committing, or storing credentials in evidence is prohibited even when troubleshooting is urgent.

---

# 333. Anti-Pattern 11 — Client Validation as Control

Client validation cannot replace server, integration, data, or authorization enforcement.

---

# 334. Anti-Pattern 12 — Authorization Filter by Convention

Relying on developers to remember tenant or role filters without a controlled policy and enforcement design is unsafe.

---

# 335. Anti-Pattern 13 — Migration Without Rehearsal

High-risk data changes without representative dry run, validation, reconciliation, and recovery are not implementation-complete.

---

# 336. Anti-Pattern 14 — Rollback as Git Revert

Reverting code does not automatically reverse schema, data, configuration, infrastructure, external side effects, or client distribution.

---

# 337. Anti-Pattern 15 — Retry Until It Works

Unbounded retries can duplicate effects, overload dependencies, and hide unknown outcomes.

---

# 338. Anti-Pattern 16 — Catch and Ignore

Suppressing exceptions without state, telemetry, recovery, and user / operator outcome creates silent failure.

---

# 339. Anti-Pattern 17 — Feature Flag Without Exit

Flags lacking owner, telemetry, removal condition, and data compatibility become permanent architecture.

---

# 340. Anti-Pattern 18 — Infrastructure Click-Ops as Final Source

Unreconciled manual changes create drift, weak review, and irreproducible environments.

---

# 341. Anti-Pattern 19 — Test Only the New Function

Changes can break integration, migration, permissions, states, performance, accessibility, and operations outside the local unit.

---

# 342. Anti-Pattern 20 — Accessibility After UI Complete

Semantic structure, focus, keyboard, forms, reflow, and reduced motion cannot reliably be patched by a final scan.

---

# 343. Anti-Pattern 21 — Screenshot Equals Parity

One visual state cannot prove all modes, states, behavior, semantics, responsive, RTL, or accessibility contracts.

---

# 344. Anti-Pattern 22 — Generated Code Is Trusted

Generated output still requires source authority, review, security / license treatment, tests, and regeneration rules.

---

# 345. Anti-Pattern 23 — Dependency Update as Chore Only

Dependency changes can alter runtime, security, compatibility, licensing, artifacts, and operational behavior.

---

# 346. Anti-Pattern 24 — Failed Check Marked Unrelated

An assertion without evidence and owner cannot waive a required failure.

---

# 347. Anti-Pattern 25 — Critical Defect as Debt

Technical debt cannot legalize a violated critical requirement or unaccepted safety, security, privacy, data, or accessibility failure.

---

# 348. Anti-Pattern 26 — Deviation After Merge

Recording a material change only after it becomes hard to reverse undermines baseline control.

---

# 349. Anti-Pattern 27 — Percentage Complete

An unsupported percentage hides which behavior, controls, evidence, and environments are actually complete.

---

# 350. Anti-Pattern 28 — Production Deploy Means Released

A production artifact may remain disabled, unverified, restricted, or not accepted.

---

# 351. Anti-Pattern 29 — Evidence Dump

A folder of logs and screenshots without claims, revisions, environment, method, and ownership is not an evidence system.

---

# 352. Anti-Pattern 30 — Self-Approval

The implementing team cannot replace independent Phase 10 verification and accountable release decisions with its own completion claim.

---

# 353. Implementation Quality Model

Evaluate Phase 09 across:

```text
Correctness
Scope integrity
Source provenance
Review quality
Maintainability
Security
Privacy
Accessibility
Data integrity
Reliability
Performance
Operability
Migration safety
Traceability
Evidence quality
Verification readiness
```

---

# 354. Core Implementation Metrics

Recommended measures:

```text
Scoped work disposition
Requirement implementation coverage
State implementation coverage
Design parity coverage
Architecture implementation coverage
Control implementation coverage
Required check pass rate
Migration evidence coverage
Deployment identity coverage
Evidence coverage
Open critical defect count
Deviation reconciliation rate
Candidate evidence freshness
```

---

# 355. Scoped Work Disposition

```text
Scoped Work Disposition =
G6A work items with valid implemented / governed disposition
÷
Total G6A-scoped work items
```

Report partial, deferred, blocked, cancelled, and not applicable separately.

---

# 356. Requirement Implementation Coverage

```text
Requirement Implementation Coverage =
In-scope requirements with source changes and evidence disposition
÷
Total in-scope requirements
```

---

# 357. State Implementation Coverage

```text
State Implementation Coverage =
Applicable experience / design states with code and check disposition
÷
Total applicable states
```

---

# 358. Design Parity Coverage

```text
Design Parity Coverage =
Implementation-relevant design objects with implemented and parity disposition
÷
Total implementation-relevant scoped design objects
```

---

# 359. Architecture Implementation Coverage

```text
Architecture Implementation Coverage =
Implementation-relevant architecture objects with source and evidence disposition
÷
Total implementation-relevant scoped architecture objects
```

---

# 360. Control Implementation Coverage

```text
Control Implementation Coverage =
Applicable controls with implemented mechanism and evidence disposition
÷
Total applicable implementation controls
```

---

# 361. Required Check Pass Rate

```text
Required Check Pass Rate =
Required implementation checks passing for the candidate
÷
Total required implementation checks
```

Waived and skipped checks are reported separately.

---

# 362. Migration Evidence Coverage

```text
Migration Evidence Coverage =
Executed candidate migrations with complete execution and validation evidence
÷
Total executed candidate migrations
```

---

# 363. Deployment Identity Coverage

```text
Deployment Identity Coverage =
Candidate deployment units with exact source, artifact, config, environment, and target identity
÷
Total candidate deployment units
```

---

# 364. Evidence Coverage

```text
Evidence Coverage =
Evidence-bearing implementation claims with valid evidence records
÷
Total evidence-bearing implementation claims
```

---

# 365. Deviation Reconciliation Rate

```text
Deviation Reconciliation Rate =
Approved deviations reflected in affected baselines, work, source, and verification
÷
Total approved deviations due before G6A
```

---

# 366. Machine-Readable Phase 09 Record

```yaml
phase:
  id: PHASE-09
  name: Implementation
  status: BASELINED
  profile: P2
  product_stage: S3

upstream:
  engineering_readiness_baseline: ERBL-2026-001
  requirements_baseline: RBL-2026-001
  design_baseline: DBL-2026-001
  architecture_baseline: ABL-2026-001
  gov_009_revision: GOV-009@1.6

implementation:
  run: IRUN-REL-001
  release: REL-001
  candidate: IVCAND-REL-001-RC1
  source:
    REPO-APR-API: a1b2c3d
    REPO-APR-WEB: d4e5f6a
  environment:
    id: STAGING-01
    deployment: DEPLOY-2026-0810-014

artifacts:
  IMP-001: APPROVED
  IMP-002: APPROVED
  IMP-003: APPROVED
  IMP-004: APPROVED
  IMP-005: APPROVED
  IMP-006: APPROVED
  IMP-007: APPROVED
  IMP-008: APPROVED
  IMP-009: APPROVED
  IMP-010: APPROVED
  IMP-011: APPROVED
  IMP-012: APPROVED
  IMP-013: APPROVED
  IMP-014: APPROVED
  IMP-015: APPROVED
  IMP-016: APPROVED
  IMP-017: APPROVED
  IMP-018: APPROVED
  IMP-019: APPROVED
  IMP-020: APPROVED
  IMP-021: APPROVED
  IMP-022: APPROVED
  IMP-023: APPROVED
  IMP-024: APPROVED
  IMP-025: APPROVED
  IMP-026: APPROVED
  IMP-027: APPROVED
  IMP-028: APPROVED
  IMP-029: APPROVED
  IMP-030: APPROVED
  IMP-031: APPROVED
  IMP-032: APPROVED

coverage:
  scoped_work: 1.0
  requirements: 1.0
  states: 1.0
  design_parity: 0.98
  architecture: 1.0
  controls: 1.0
  required_checks: 1.0
  migration_evidence: 1.0
  deployment_identity: 1.0
  evidence: 1.0
  deviation_reconciliation: 1.0

gate:
  id: G6A
  outcome: PASS_WITH_CONDITIONS
  evidence_record: G6A-EVR-001
```

---

# 367. Machine-Readable Change Set

```yaml
change_set:
  id: ICHG-APR-API-001
  work_items: [EWI-APR-API-001]
  repository: REPO-APR-API
  base_revision: 912ab34
  head_revision: a1b2c3d
  affected_objects:
    - API-APR-DECIDE
    - MOD-APR-DECISIONS
    - AUD-APR-DECISION
  checks:
    unit: PASS
    contract: PASS
    integration: PASS
    build: PASS
    startup: PASS
  review:
    status: APPROVED
    revision: a1b2c3d
  evidence:
    - IEVID-APR-BUILD-001
    - IEVID-APR-CONTRACT-002
  status: IMPLEMENTED
```

---

# 368. Machine-Readable Deployment Record

```yaml
deployment:
  id: DEPLOY-2026-0810-014
  environment: STAGING-01
  project: PROJECT-APR-STAGING
  repository: REPO-APR-API
  revision: a1b2c3d
  artifact: sha256:example
  configuration_revision: CFG-APR-STG-014
  migrations:
    - id: MIG-20260810-APR-001
      status: APPLIED_VALIDATED
  flags:
    approval_review: INTERNAL_COHORT
  health:
    startup: PASS
    readiness: PASS
    smoke: PASS
  status: DEPLOYED_STAGING
```

---

# 369. `NOT_APPLICABLE` Contract

For any artifact, object, check, platform, migration, environment, control, or evidence type marked `NOT_APPLICABLE`, record:

```text
Item ID
Scope
Reason
Decision owner
Supporting evidence
Date / revision
Reopen condition
Downstream implication
```

Absence without this record means `MISSING`.

---

# 370. Minimum Phase 09 Package by Profile

| Obligation | P1 Lean | P2 Standard | P3 Comprehensive |
|---|---|---|---|
| Scope / status | Named scope and truthful status | Full multi-dimensional register | Formal controlled implementation runs |
| Source / review | Critical revisions and reviews | Full change-set provenance | Separation of duties / signed provenance as required |
| UI / design parity | Critical surface parity | Full applicable parity | Formal multi-platform assurance |
| API / data / controls | Critical contracts | Full implementation records | Independent high-assurance review |
| Migration / deployment | Safe critical path | Full evidence and identity | Rehearsed, controlled, custody-grade evidence |
| CI/CD / supply chain | Required checks and artifact | Full applicable controls | Formal provenance / signing / promotion |
| Evidence / traceability | Compact but complete | Full index | Assurance-grade custody and retention |
| Candidate | Exact snapshot | Full immutable candidate | Formal candidate and invalidation control |
| G6A | Required | Required | Required with formal evidence depth |

---

# 371. Phase 09 Completion Contract

Phase 09 is complete only when:

```text
G5B scope and source identities are valid
Scoped work has truthful implementation disposition
Required changes are reviewed and checks pass
UI, application, data, controls, reliability, and operability obligations are implemented
Migrations and deployments have exact identity and evidence
No secret is exposed
Defects, blockers, deviations, and debt are visible and governed
GOV-009 implementation status is updated without overclaim
Coverage and traceability are complete
Implementation evidence is indexed
Verification candidate is stable
Phase 10 acknowledges handoff
G6A has an accountable human decision
```

---

# 372. Phase 09 Exit Criteria

Required exit evidence:

```text
G6A outcome
Implementation Baseline ID / version
Verification Candidate ID / revision
Canonical source / artifact / environment snapshot
Artifact status matrix
Implementation coverage report
Build / check / migration / deployment evidence
Open defects / deviations / debt / conditions
GOV-009 implementation matrix
Phase 10 acknowledgement
Candidate change-control owner
```

---

# 373. Transformation Achieved

At successful completion, Product OS has transformed:

```text
An approved engineering-ready implementation plan
```

into:

```text
A traceable implementation baseline with reviewed source,
safe data and platform changes, implemented controls,
truthful status, durable evidence, controlled deviations,
and an immutable candidate for independent verification.
```

---

# 374. Final Principle

> **Implementation is complete when the approved scope exists in canonical source and runtime artifacts with review, checks, migrations, controls, traceability, and evidence—and when every material difference from the baselines is visible and governed.**

And:

> **G6A approves an exact implementation snapshot ready for independent verification—not a merge, a green build, or an optimistic status report.**

---

# 375. Phase 09 Output

Primary output:

```text
IBL — Implementation Baseline
```

Gate:

```text
G6A — Implementation Baseline
```

Downstream consumers:

```text
Phase 10 — Verification and Release
Phase 11 — Operations and Evolution
Engineering, Design System, Architecture, Security, Data, and Platform Governance
```
