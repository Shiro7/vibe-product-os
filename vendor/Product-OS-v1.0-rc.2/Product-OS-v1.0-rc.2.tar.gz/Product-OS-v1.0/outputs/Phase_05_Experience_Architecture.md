# Product OS v1.0 — Methodology Specification
## Phase 05: Experience Architecture

**Phase ID:** `PHASE-05`  
**Phase Name:** `Experience Architecture`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G4A — Experience Baseline`  
**Primary Baseline:** `EBL — Experience Baseline`  
**Primary Outcome:** تحويل الـapproved Product and Requirements Baselines إلى experience model مترابط وقابل للتتبع يحدد كيف يفهم المستخدم المنتج، وكيف يبدأ ويكمل أهدافه، وكيف ينتقل بين السياقات والـstates، وكيف يتعامل المنتج مع الخطأ والانقطاع والتعافي والـaccessibility والـRTL قبل بدء Product Design التفصيلي.

---

# 1. Purpose

الغرض من Phase 05 هو الانتقال من:

```text
The system SHALL provide behavior X under constraint Y.
```

إلى:

```text
How does a user discover, understand, initiate, complete,
interrupt, resume, fail, recover, and confirm that behavior
across the supported contexts and channels?
```

Phase 05 تبني **Experience Baseline** يربط:

```text
User Goal
→ Scenario
→ Journey
→ Flow
→ Decision / Branch
→ View / Screen / Route
→ UX State
→ Interaction Rule
→ Outcome / Recovery
```

بحيث تستطيع Phase 06 تصميم الواجهة دون اختراع journey أوstate أوnavigation أوerror behavior من عندها.

---

# 2. Position in Product OS

```text
PHASE 03 — PRODUCT DEFINITION
                │
                ▼
       G3A — PRODUCT BASELINE
                │
                ▼
PHASE 04 — REQUIREMENTS ENGINEERING
                │
                ▼
       G3B — REQUIREMENTS BASELINE
                │
                ▼
PHASE 05 — EXPERIENCE ARCHITECTURE
                │
                ▼
       G4A — EXPERIENCE BASELINE
                │
                ▼
PHASE 06 — PRODUCT DESIGN
                │
                ▼
       G4B — DESIGN BASELINE
```

Phase 05 تستقبل system behavior approved.

هي لا تعيد تعريفه، بل تخصص experience responsibility وتكشف أي gap أوconflict يمنع تجربة صحيحة.

---

# 3. Core Experience Architecture Question

> **How must the experience be structured so that each authorized user can understand and complete the approved product outcomes safely, accessibly, and recoverably across the supported contexts?**

ثم:

> **What journey, flow, state, navigation, content, and interaction evidence proves that every applicable requirement has an experience disposition?**

---

# 4. Experience Architecture Philosophy

Product OS Experience Architecture يعتمد على المبادئ التالية.

## XA-01 — Goal Before Screen

لا نبدأ بقائمة screens.

نبدأ بـ:

```text
Actor
Context
Goal
Trigger
Journey
Outcome
```

ثم نستنتج destinations and interaction surfaces.

---

## XA-02 — Journey Includes Failure and Recovery

Journey ليست happy path فقط.

يجب أن تغطي:

```text
Success
Alternative path
Interruption
Failure
Unknown outcome
Recovery
Resume
Exit
```

---

## XA-03 — State Is First-Class

Loading وempty وerror وpermission وconflict وoffline وexpired ليست تفاصيل تصميم لاحقة.

هي جزء من experience contract.

---

## XA-04 — Navigation Preserves Context

المستخدم يجب أن يعرف:

```text
Where am I?
In which tenant/entity/workspace/capacity?
What can I do here?
What changed?
How do I go back or recover?
```

---

## XA-05 — Accessibility Is Architecture

Keyboard path وfocus movement وsemantic relationships وannouncements وreflow وerror recovery وauthentication accessibility تُحسم ضمن experience structure، لا بعد اكتمال visual design.

---

## XA-06 — Security and Usability Must Coexist

Security-sensitive journeys تحتاج وضوحًا وفهمًا وتعافيًا، من غير كشف معلومات حساسة أوإضعاف controls.

---

## XA-07 — Content Is Interaction

Labels وinstructions وstatus وerrors وconfirmations وempty states تؤثر على completion والسلامة.

لذلك لها architecture and ownership، وليست filler text.

---

## XA-08 — One Experience, Multiple Contexts

Web وmobile وdesktop وkiosk وgenerated documents وthird-party transitions قد تحتاج behaviors مختلفة، لكن يجب أن تحافظ على product intent والـcritical journey continuity.

---

## XA-09 — Structure Before Styling

Phase 05 تقرر hierarchy and behavior.

Phase 06 تقرر visual language and component realization.

---

## XA-10 — Traceability Before Polish

كل Journey وView وState وInteraction Rule يجب أن يرجع إلى Goal أوRequirement أوRisk أوStandard obligation.

---

## XA-11 — Progressive Disclosure

التجربة تُظهر ما يحتاجه المستخدم في السياق الحالي، وتحافظ على إمكانية الوصول للمعلومات أوactions المتقدمة دون تحميل الواجهة بكل شيء في وقت واحد.

---

## XA-12 — No Dead Ends

كل state مادية يجب أن توفر outcome أوnext step أوexit أوsupport/recovery route مناسبًا.

---

# 5. Phase Objectives

بنهاية Phase 05 يجب أن يكون Product OS قادرًا على:

1. تحديد Experience Principles الخاصة بالمنتج.
2. تثبيت experience scope والـsupported contexts.
3. ربط actors والroles والgoals والcontexts بالRequirements Baseline.
4. إنشاء Experience Scenario Catalog.
5. إنشاء end-to-end Journey Catalog.
6. تحديد main, alternative, exception, interruption, and recovery flows.
7. تحديد Information Architecture.
8. تحديد Navigation and Context Model.
9. تحديد Workspaces and major destinations.
10. إنشاء View / Screen / Route Inventory.
11. تحديد entry points, deep links, exits, and return behavior.
12. إنشاء UX State Catalog.
13. تحديد loading, empty, partial, error, permission, conflict, offline, unknown-outcome, and success states.
14. تحديد error, safety, recovery, and resume behavior.
15. تحديد form and transaction interaction rules.
16. تحديد sensitive and destructive action patterns.
17. تحديد content and message responsibilities.
18. تحديد responsive and cross-platform behavior.
19. تحديد localization and RTL behavior.
20. اشتقاق Accessibility Experience Specification من `ACC` و`GOV-009`.
21. تحديد security/privacy experience implications.
22. تحديد cross-channel and third-party continuity.
23. تحديد structural wireframe or low-fidelity prototype needs عند الحاجة للتحقق.
24. بناء requirement-to-experience traceability.
25. كشف requirement gaps وscope changes وarchitecture dependencies دون حلها بصمت.
26. إجراء experience validation بالعمق المناسب.
27. تحديث `GOV-009` بالـexperience artifacts and evidence expectations.
28. تجهيز Product Design handoff.
29. إنشاء versioned Experience Baseline.
30. تمرير `G4A — Experience Baseline`.

---

# 6. Phase Inputs

Required logical inputs:

```text
PROD-001 Product Vision & Mission
PROD-002 Product Scope & Boundary
PROD-003 Product Objective Model
PROD-004 Product User & Role Model
PROD-005 Product Capability Map
PROD-006 Product Domain & Module Map
PROD-007 Feature Candidate Catalog
PROD-008 Product State & Lifecycle Model
PROD-009 Product Policy & Constraint Register
PROD-010 Product Integration & Dependency Map
PROD-011 MVP & Release Scope
PROD-013 Product KPI Model
REQ-001 System Requirements Specification
REQ-002 Requirement Catalog and Index
REQ-003 Functional Requirement Catalog
REQ-004 Non-Functional Requirement Catalog
REQ-005 Data Requirement Catalog
REQ-006 Integration Requirement Catalog
REQ-007 Security and Privacy Requirement Catalog
REQ-008 Accessibility Requirement Catalog
REQ-009 Audit and Evidence Requirement Catalog
REQ-010 Acceptance and Verification Matrix
REQ-011 Requirements Traceability Matrix
REQ-014 Requirements Handoff
G3A Decision
G3B Decision
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated Conditional Profiles
Existing Experience Evidence where applicable
```

---

# 7. Entry Condition

Phase 05 تبدأ عندما:

```text
G3B = PASS
```

أو:

```text
G3B = PASS_WITH_CONDITIONS
```

بشرط أن الـconditions لا تجبر Experience Architecture على اختراع system behavior أوauthorization أوdata ownership أوquality obligation.

Minimum entry:

```text
Blocking requirement questions = 0
Blocking requirement decisions = 0
Critical journey requirements are identifiable
Actors/roles and product boundary are usable
Applicable ACC/SEC/DR/INT requirements are available
GOV-009 experience obligations are identifiable
```

---

# 8. What Phase 05 Is Not

Phase 05 ليست:

- Product Strategy.
- Product Scope approval.
- Requirements Engineering.
- Visual identity.
- Brand design.
- High-fidelity UI design.
- Design token definition.
- Component library construction.
- Final component variants.
- Illustration or icon production.
- Detailed visual hierarchy.
- Final motion design.
- Production Figma handoff.
- Solution Architecture.
- API design.
- Database design.
- Engineering task decomposition.
- Final Test Case execution.

Phase 05 قد تستخدم structural wireframes أوflow prototype للتحقق من structure، لكنها لا تحولها إلى visual baseline.

---

# 9. Phase 05 vs Phase 06

## Phase 05 Owns

```text
Goals
Scenarios
Journeys
Flows
Branches
Information Architecture
Navigation
Context
Destinations
Views / Screen Candidates / Routes
States
Interaction Rules
Errors / Recovery
Content Responsibilities
Responsive Behavior Rules
Accessibility Experience Behavior
Localization / RTL Behavior
Structural Validation
```

## Phase 06 Owns

```text
Visual hierarchy
Layout composition
Typography
Color
Spacing
Tokens
Components and variants
Visual states
Detailed responsive layouts
Final content presentation
Visual accessibility realization
Motion specification
High-fidelity prototype
Design System mapping
Figma production artifacts
```

---

# 10. Experience Architecture Object Model

Canonical logical objects:

```text
Experience Principle
Experience Actor
Experience Context
User Goal
Experience Scenario
Journey
Journey Stage
Experience Flow
Flow Step
Decision Point
Entry Point
Exit / Outcome
Workspace
Information Domain
Navigation Context
Destination
View / Screen Candidate
Route
UX State
Interaction Rule
Content / Message Object
Error Pattern
Recovery Pattern
Responsive Rule
Accessibility Experience Rule
Localization / RTL Rule
Cross-Channel Continuity Rule
Experience Validation Evidence
```

Physical artifact packaging depends on P-profile.

---

# 11. Canonical Experience IDs

Recommended:

```text
XPR-001      Experience Principle
XACT-001     Experience Actor
XCTX-001     Experience Context
UGOAL-001    User Goal
SCN-001      Scenario
JRN-001      Journey
JSTG-001     Journey Stage
FLOW-001     Experience Flow
FSTEP-001    Flow Step
XDEC-001     Experience Decision Point
ENTRY-001    Entry Point
XOUT-001     Experience Outcome
WSPC-001     Workspace
IADOM-001    Information Architecture Domain
NAV-001      Navigation Context / Rule
DST-001      Destination
VIEW-001     View / Screen Candidate
ROUTE-001    Route
UXS-001      UX State
IXR-001      Interaction Rule
CNT-001      Content Object
MSG-001      Message
ERR-001      Error Pattern
REC-001      Recovery Pattern
RSP-001      Responsive Rule
AXR-001      Accessibility Experience Rule
L10N-001     Localization / RTL Rule
XCH-001      Cross-Channel Rule
```

`TASK-*` يظل محجوزًا للعمل التنفيذي؛ لذلك Experience task يستخدم `FSTEP` أوJourney step بدل خلطه بالEngineering Task.

## Experience Object Lifecycle

Canonical lifecycle:

```text
CAPTURED
PROPOSED
IN_ANALYSIS
IN_REVIEW
VALIDATED
APPROVED
BASELINED
DEFERRED
REJECTED
SUPERSEDED
RETIRED
```

Validation status and approval status remain separate.

Objects keep stable IDs and version history; superseded objects are not deleted or reused.

---

# 12. Experience Principle

Experience Principle هو product-specific rule يوجه قرارات متعددة.

Example:

```text
XPR-003 — Preserve entered work across recoverable interruptions.
```

لا يستخدم كشعار عام بلا downstream rules.

---

# 13. Experience Principle Sources

```text
Product Vision
Product Policy
Critical User Need
Risk / Control
Requirement Baseline
Accessibility Standard
Localization Context
Operational Reality
```

---

# 14. Experience Actor

Experience Actor يمثل human أوexternal initiator يتفاعل مع journey.

Examples:

```text
Employee
Manager acting as Approver
Customer
Support Agent
Administrator
External Identity Provider
Scheduled System Event
```

Actor لا يساوي Persona دائمًا.

---

# 15. Actor vs Product Role

Product Role يحدد product-level responsibility.

Experience Actor يحدد من يشارك في scenario/journey وبأي acting capacity.

```text
ROLE-MANAGER
    ↓
XACT-APPROVER when acting on an approval journey
```

---

# 16. Persona Boundary

Persona تساعد في فهم behavior/context.

لا تستخدم لتحديد authorization.

```text
Persona preference ≠ Permission
```

---

# 17. Acting Capacity

نفس الشخص قد يعمل كـ:

```text
Self
Manager
Delegate
Administrator
Support Agent
Auditor
Approver
```

Experience يجب أن توضح acting capacity والسياق الحالي عندما يغيران authority أوdata scope أوconsequences.

---

# 18. Experience Context

Context may include:

```text
Goal
Location
Device
Input Mode
Connectivity
Time Pressure
Privacy Level
User Experience Level
Language / Direction
Accessibility Need
Tenant / Entity / Workspace
Acting Capacity
Data State
Journey Entry Source
```

---

# 19. Context Is Not Demographic Decoration

Context يجب أن يغير قرارًا experience-wise.

إذا attribute لا يؤثر على journey أوcontent أوinteraction أوrisk، لا نضيفه لمجرد أن persona template يحتويه.

---

# 20. User Goal

User Goal يصف outcome يريد actor تحقيقه.

```text
UGOAL-008 — Correct an inventory discrepancy with authorized evidence.
```

ليس:

```text
Use the edit inventory screen.
```

---

# 21. Goal Traceability

Each `UGOAL` should link to one or more:

```text
OUT
OBJ / POBJ
PCAP
FR
Business Process
Problem / Need
```

---

# 22. Experience Scenario

Scenario يضع goal داخل context محدد.

```yaml
scenario_id: SCN-014
title: "Manager reviews an above-threshold request on mobile"
actor: XACT-APPROVER
goal: UGOAL-006
context:
  platform: MOBILE
  connectivity: INTERMITTENT
  language: AR
  direction: RTL
  acting_capacity: APPROVER
trigger: "Approval notification opened"
preconditions:
  - "Actor has an active authorized session."
expected_outcome: XOUT-APPROVAL-DECIDED
requirements:
  - FR-APR-014
  - SEC-AUTHZ-003
  - ACC-NAV-001
  - AUD-APR-002
variants:
  - SCN-014-A
  - SCN-014-B
```

---

# 23. Scenario Types

```text
PRIMARY
ALTERNATIVE
EXCEPTION
RECOVERY
SECURITY_SENSITIVE
ACCESSIBILITY
OFFLINE
CROSS_CHANNEL
ADMINISTRATIVE
SUPPORT
MIGRATION / FIRST_USE
```

One scenario may have multiple tags but one primary purpose.

---

# 24. Scenario Preconditions

Preconditions may include:

```text
Authentication state
Authorization/role
Data state
Configuration
Dependency availability
Device capability
Consent/notice state
Previous step completion
```

Precondition لا تخفي missing system behavior.

---

# 25. Scenario Trigger

Trigger may be:

```text
User intent
Notification
Deep link
Scheduled event
State change
External event
Support escalation
Security event
```

---

# 26. Scenario Outcome

Outcome must be observable and linked to user/business value or safe recovery.

```text
SUCCESS
PARTIAL_SUCCESS
SAFE_FAILURE
PENDING_EXTERNAL_OUTCOME
INTERRUPTED_RESUMABLE
CANCELLED
ESCALATED
```

---

# 27. Base Scenario and Variants

To prevent combinatorial explosion:

```text
Base Scenario
  + Platform Variant
  + Role Variant
  + Language/Direction Variant
  + Accessibility Variant
  + Connectivity Variant
  + Market Variant
```

Variant records only material differences.

---

# 28. Scenario Coverage

Critical FRs and ACC/SEC/INT requirements should appear in at least one relevant scenario or carry an approved no-experience-impact rationale.

NFR/DR/AUD may attach to journeys, states, or cross-cutting experience rules.

---

# 29. Journey

Journey is the end-to-end path from meaningful trigger to outcome across one or more interactions, systems, channels, and time periods.

Journey may span multiple sessions.

---

# 30. Journey vs Flow

Journey answers:

```text
What happens across the full user goal and experience?
```

Flow answers:

```text
What sequence, branch, loop, and state transition occurs within a defined interaction scope?
```

One Journey may contain several Flows.

---

# 31. Journey Contract

```yaml
journey_id: JRN-006
title: "Request and receive purchase approval"
goal: UGOAL-006
primary_actor: XACT-REQUESTER
supporting_actors:
  - XACT-APPROVER
entry_points:
  - ENTRY-REQUESTS
stages:
  - JSTG-REQUEST-DRAFT
  - JSTG-REQUEST-SUBMIT
  - JSTG-APPROVAL
  - JSTG-OUTCOME
flows:
  - FLOW-REQ-001
  - FLOW-APR-001
success_outcomes:
  - XOUT-APPROVED
alternative_outcomes:
  - XOUT-REJECTED
recovery_paths:
  - REC-REQUEST-TIMEOUT
requirements:
  - FR-REQ-001
  - FR-APR-014
  - SEC-AUTHZ-003
  - ACC-FORM-001
  - AUD-APR-002
release: RELEASE-1
criticality: HIGH
status: IN_REVIEW
```

---

# 32. Journey Stages

Stage is a meaningful phase of progress.

Examples:

```text
Discover
Prepare
Initiate
Provide Information
Review
Confirm
Wait
Resume
Complete
Recover
Follow Up
```

Stages are not fixed universal funnel labels.

---

# 33. Journey Types

```text
CORE_VALUE
ONBOARDING
AUTHENTICATION
ACCOUNT_RECOVERY
TRANSACTIONAL
APPROVAL
OPERATIONAL
ADMINISTRATIVE
SUPPORT
SECURITY_SENSITIVE
INTERRUPTION_RECOVERY
CROSS_CHANNEL
OFFBOARDING
```

---

# 34. Critical Journey

Criticality may derive from:

```text
Core outcome
High usage
Financial impact
Safety
Security/privacy
Regulation
Irreversible action
High support burden
Accessibility impact
Operational continuity
```

Critical journey requires deeper state, error, recovery, accessibility, and validation coverage.

---

# 35. Journey Entry Point

Entry points may include:

```text
Global navigation
Dashboard/contextual workspace
Notification
Deep link
Search result
External link
QR / physical context
Third-party return
Support handoff
System-generated prompt
```

---

# 36. Journey Exit

Every journey should define:

```text
Success exit
Safe cancellation
Failure exit
Pending/unknown outcome
Support/escalation route
Resume route
Next recommended action where applicable
```

---

# 37. Journey Handoff

If responsibility passes between actors or systems, record:

```text
What is handed off?
To whom?
When?
What context is preserved?
What must be communicated?
How is receipt/completion known?
What happens if handoff fails?
```

---

# 38. Multi-Actor Journey

Multi-actor journey must show:

```text
Actor ownership by stage
Wait states
Notifications
Visibility boundaries
Delegation
Escalation
Handoff evidence
```

---

# 39. Cross-Session Journey

If journey spans sessions:

```text
Progress persistence
Resume point
Expiry
Changed-data handling
Reauthentication
Notification
Abandoned state
Audit
```

---

# 40. Experience Flow

Flow is a controlled representation of:

```text
Steps
Decisions
Branches
Loops
States
Actor/System handoffs
Entry/Exit
Errors/Recovery
```

## Flow Representation

Product OS does not force one notation.

Use the smallest clear representation:

```text
Structured step table
User-flow diagram
State diagram
Sequence/swimlane view
BPMN reference when business-process semantics matter
```

The diagram is a view over canonical IDs and step/decision data, not the only source of truth.

## Diagram Accessibility

Every material diagram needs a readable text/table alternative that preserves actors, steps, branches, outcomes, and relationships.

---

# 41. Flow Step

Every material step identifies:

```text
Actor or System
Intent
Input
Action
Rule/Requirement
State before
State after
Feedback
Possible failure
Next step
```

---

# 42. Decision Point

Decision point must link to:

```text
Business Decision
Business Rule
Product Policy
Requirement
Authorization Rule
User Choice
External Outcome
```

AI or designer must not invent branch logic.

---

# 43. System Decision vs User Decision

System Decision:

```text
Rule determines outcome.
```

User Decision:

```text
Actor selects among permitted options with understandable consequences.
```

Do not present system-enforced outcome as if the user chose it.

---

# 44. Flow Loop

Loop must define:

```text
Entry condition
Exit condition
Maximum or safe bound where relevant
Progress preservation
Cancellation
Error escalation
```

---

# 45. Parallel Flow

When activities happen concurrently, define:

```text
Independent steps
Synchronization point
Conflicting update behavior
Partial completion
Wait/timeout
User visibility
```

---

# 46. Background Work

Long-running or background action needs experience behavior for:

```text
Acknowledgement
Progress/status
Navigation away
Completion notification
Failure
Retry
Cancellation if allowed
Result access
Stale/expired result
```

---

# 47. Information Architecture

Information Architecture answers:

> **How are product concepts, destinations, content, actions, and relationships organized so users can form a correct mental model?**

It is not the database schema.

---

# 48. IA Sources

```text
Product Domains and Modules
Business/Product Terminology
User Goals
Journeys
Information Requirements
Object Lifecycles
Permissions
Frequency and Criticality
Context/Workspace Model
Search and Findability Needs
```

---

# 49. Information Domain

`IADOM` groups user-understandable concepts and destinations.

It may align with Product Domain but is not forced to mirror backend/domain decomposition.

---

# 50. User Mental Model

IA should use concepts users understand while preserving canonical domain language.

Do not expose technical implementation terms like:

```text
Queue
Microservice
Database Record
API Payload
```

unless they are genuinely part of the user's job.

---

# 51. Taxonomy

Taxonomy defines how content/objects are classified and found.

Record:

```text
Canonical term
Aliases
Hierarchy
Facets
Status vocabulary
Market/language variants
Ownership
```

---

# 52. Labeling System

Labels must be:

```text
Consistent
Domain-correct
Actionable where actions
Distinct
Translatable
Understandable without hidden internal terminology
```

Label validation precedes visual styling.

---

# 53. Hierarchy

Hierarchy expresses meaningful parent/child or priority relationships.

Do not create deep navigation because organizational chart is deep.

---

# 54. Findability

Users may reach information through:

```text
Navigation
Search
Filter
Saved View
Recent Item
Notification
Deep Link
Contextual Link
Related Item
```

Findability must respect authorization and context.

---

# 55. Search Architecture

Experience Architecture defines:

```text
Search scope
Entry point
Query context
Filter/sort concepts
Result grouping
Authorization visibility
No-result behavior
Error/recovery
Recent/saved behavior if applicable
```

Search engine technology is not Phase 05.

---

# 56. Workspace

Workspace is a persistent experience context organized around a job, entity, or operational responsibility.

Examples:

```text
Employee Self-Service
Approval Workspace
Customer Account
Warehouse Operations
Tenant Administration
Audit Review
```

Workspace is not merely a sidebar section.

---

# 57. Workspace Contract

```text
Purpose
Eligible actors
Context identity
Primary goals
Primary information
Primary actions
Entry points
Navigation boundary
Cross-workspace transitions
Permission behavior
States
```

---

# 58. Destination

Destination is a meaningful place users navigate to.

May be realized later as:

```text
Page
Screen
Panel
Workspace view
Document
External destination
```

Phase 05 identifies responsibility before visual form.

---

# 59. View / Screen Candidate

`VIEW` represents a distinct experience surface needed to support one or more goals/states.

It includes:

```text
Purpose
Actors
Context
Information
Actions
Requirements
States
Entry/Exit
Route disposition
Responsive implications
Accessibility implications
```

It does not contain final layout.

---

# 60. View vs State

```text
Orders List — VIEW
Orders List / Loading — STATE
Orders List / Empty — STATE
Orders List / Permission Restricted — STATE
Orders List / Dependency Error — STATE
```

Do not inflate every state into a separate screen.

---

# 61. View vs Modal / Drawer

Modal, drawer, popover, or sheet is an interaction form, not automatically a separate `VIEW`.

Create distinct object when it has meaningful lifecycle, deep link, ownership, or state complexity.

---

# 62. Route

Route is an addressable entry/location contract.

It may define:

```text
Path identity
Required context
Allowed roles
Deep-link behavior
Missing/invalid parameter behavior
Reload behavior
Bookmark/share policy
Authentication return
Canonical destination
```

Route syntax itself may be finalized with Architecture/Engineering later.

---

# 63. Route Is Not Permission

Hiding a route or navigation item does not enforce authorization.

Experience behavior must align with `SEC` requirements while solution enforcement remains downstream.

---

# 64. Entry Point

Entry point records:

```text
Source
Destination
Required context
Authentication state
Expected actor intent
Fallback if invalid/expired
Tracking/evidence need where applicable
```

---

# 65. Deep Link

Deep-link design must address:

```text
Authentication
Authorization
Context restoration
Expired/invalid target
Deleted/archived target
Mobile/web handoff
Return path
Privacy of URL content
```

---

# 66. Navigation Model

Navigation may include:

```text
Global
Workspace
Local
Contextual
Task-based
Utility
Related-object
History / Back
Search-based
```

Not every destination belongs in persistent global navigation.

---

# 67. Navigation Priority

Priority derives from:

```text
User goals
Frequency
Criticality
Role relevance
Current context
Lifecycle stage
Risk
```

Stakeholder seniority does not determine menu order.

---

# 68. Context Model

Context may be:

```text
Tenant
Legal Entity
Branch
Facility
Project
Customer
Account
Case
Workspace
Acting Role
Time Period
```

Experience must state where context is selected, visible, changed, and preserved.

---

# 69. Context Switching

Switching context must define:

```text
Who can switch
What changes
What remains
Unsaved work behavior
Permission recalculation
Default destination
Confirmation for high-impact context change
Audit where material
```

---

# 70. Context Persistence

Define persistence across:

```text
Navigation
Reload
New session
Deep link
Cross-device
Cross-channel
Role switch
```

Persistence must not expose unauthorized context.

---

# 71. Back Behavior

Back may mean:

```text
Browser/system back
Return to previous list/context
Cancel current edit
Close transient surface
Step back in wizard
```

These must not be conflated.

---

# 72. Breadcrumb / Entity Trail

Use when hierarchy or context depth needs explanation.

It should represent meaningful location/relationship, not repeat every route segment.

---

# 73. Home / Landing Responsibility

Home/landing destination should have explicit purpose:

```text
Orient
Resume work
Surface priority
Show status
Start common goals
Resolve action-needed items
```

`Dashboard` is not a default requirement.

---

# 74. Dashboard Boundary

Dashboard exists only when users need cross-item status, prioritization, monitoring, or decision support.

It is not a decorative collection of cards.

---

# 75. Screen Inventory

Inventory fields:

```text
View ID
Working Name
Purpose
Workspace / Domain
Actors / Roles
Goals / Journeys / Flows
Requirements
Route / Entry Points
Information Objects
Primary Actions
States
Responsive Modes
Accessibility Rules
Security/Privacy Notes
Design Priority
Status
```

---

# 76. Screen Candidate Status

```text
PROPOSED
SUPPORTED
IN_REVIEW
APPROVED
MERGED
SPLIT
DEFERRED
REJECTED
SUPERSEDED
```

---

# 77. Orphan View

View with no goal, journey, flow, requirement, or authorized operational need:

```text
ORPHAN_VIEW
```

It cannot enter Experience Baseline because it looks useful.

---

# 78. View Consolidation

Multiple candidate screens may become one adaptive view when:

```text
Purpose is coherent
Context remains clear
State complexity is manageable
Accessibility remains strong
Responsive behavior is feasible
```

---

# 79. View Separation

Separate when:

```text
Goals conflict
Information density becomes unsafe
Permissions differ materially
State lifecycles differ
Sensitive action needs focus
Mobile/context constraints demand it
Independent route/history is necessary
```

---

# 80. Navigation Validation Questions

```text
Can each actor find the primary goal?
Is current context always understandable?
Can users return safely?
Are hidden destinations still reachable where needed?
Do deep links recover context?
Does navigation reveal unauthorized information?
Does the model work with keyboard and assistive technology?
Does RTL preserve correct order and direction?
```

---

# 81. UX State

UX State is the observable condition of a view, flow, action, or object from the user's perspective.

State must map to system/product state where relevant without inventing a new business meaning.

---

# 82. UX State vs Product State

Product State:

```text
Order = PENDING_APPROVAL
```

UX States around it may include:

```text
Loading the pending order
Pending order displayed
Approval action unavailable
Approval submission in progress
Approval conflict
Approval outcome unknown
```

---

# 83. Canonical UX State Families

```text
INITIAL
LOADING
PROGRESSIVE_LOADING
READY
EMPTY
PARTIAL
FILTERED_EMPTY
VALIDATION_ERROR
SYSTEM_ERROR
DEPENDENCY_ERROR
PERMISSION_RESTRICTED
NOT_FOUND
CONFLICT
STALE
READ_ONLY
LOCKED
PENDING
PROCESSING
OFFLINE
SYNC_PENDING
SYNC_CONFLICT
UNKNOWN_OUTCOME
EXPIRED
ARCHIVED
DELETED
SUCCESS
PARTIAL_SUCCESS
CANCELLED
INTERRUPTED
```

Project may add domain states with canonical definitions.

---

# 84. State Record Contract

```yaml
state_id: UXS-REQ-ERROR-001
view: VIEW-REQUEST-EDIT
state_family: VALIDATION_ERROR
trigger:
  - "Submission contains invalid or missing required information."
user_goal_effect: BLOCKED_RECOVERABLE
information:
  - "What failed"
  - "Where correction is needed"
  - "What remains preserved"
actions:
  - "Move to first error"
  - "Correct and resubmit"
focus:
  entry: ERROR_SUMMARY
  return: FIRST_INVALID_FIELD
announcement: ASSERTIVE_IF_SUBMISSION_BLOCKED
requirements:
  - FR-REQ-VALID-001
  - ACC-FORM-001
  - SEC-ERR-001
recovery:
  - REC-FORM-CORRECT
```

---

# 85. Initial Loading

Define:

```text
What is loading?
Can structure appear first?
What remains interactive?
What is announced?
When does slow loading become error/status?
Can user leave safely?
```

Spinner alone is not a state contract.

---

# 86. Progressive Loading

Use when parts can become useful independently.

Must avoid:

```text
Layout instability that loses focus
Controls becoming active before required data
Misleading partial totals
Silent late failures
```

---

# 87. Empty State

Differentiate:

```text
No data exists
No results match filter
User lacks visibility
Data is not yet synchronized
Feature is not configured
Dependency returned no result
```

Each may need different action and message.

---

# 88. Empty State Contract

```text
Meaning
Reason users can understand
Primary next action
Alternative action/help
Permission boundary
Accessibility announcement
No misleading success implication
```

---

# 89. Partial State

Partial data or partial completion must identify:

```text
What is available
What is missing
Why
Whether decisions/actions are safe
How to retry or continue
How stale/partial content is marked
```

---

# 90. Validation Error State

Must support:

```text
Clear identification
Field association
Preserved input
Actionable correction
Error summary where useful
Focus movement
Screen-reader announcement
No color-only meaning
```

---

# 91. System Error State

Must:

```text
Protect internal details
Explain user impact honestly
Preserve safe state
Offer retry/recovery/support when valid
Provide correlation reference when required
Remain keyboard and screen-reader understandable
Avoid dead end
```

---

# 92. Dependency Error State

Differentiate when useful:

```text
Temporary unavailable
Timeout
Rejected request
Unknown outcome
Partial external completion
Version/compatibility failure
```

Do not blame external vendor in user-facing content without approved support policy.

---

# 93. Permission-Restricted State

Possible experience dispositions:

```text
Hide destination/action
Show disabled action with explanation
Show read-only state
Show access request route
Show safe unauthorized message
Redirect to valid context
```

Choice depends on requirement, information sensitivity, and user goal.

---

# 94. Hidden vs Disabled vs Read-Only

## Hidden

Use when awareness itself is unnecessary or sensitive.

## Disabled

Use when the action is relevant but temporarily unavailable and an explanation helps.

## Read-Only

Use when viewing is allowed but change is not.

None of these replaces backend authorization.

---

# 95. Not Found State

Must distinguish internally while possibly presenting a safe generic response for:

```text
Invalid identifier
Deleted/archived object
Wrong tenant/entity
No permission
Expired link
```

Security requirements determine disclosure boundary.

---

# 96. Conflict State

Conflict may arise from:

```text
Concurrent edit
State changed elsewhere
Duplicate action
Version mismatch
Offline synchronization
Competing approval
Reservation/availability change
```

Experience must clarify what changed, what is preserved, and safe options.

---

# 97. Stale State

If displayed information may be stale:

```text
Indicate freshness where material
Prevent unsafe actions if required
Offer refresh
Preserve user context
Explain changed outcome
```

---

# 98. Processing State

For non-instant actions:

```text
Acknowledge receipt
Prevent accidental duplicate submission
Show progress/status appropriate to duration
Allow safe navigation if supported
Define cancel eligibility
Define completion/failure notification
```

---

# 99. Unknown Outcome State

Critical for payments, submissions, external approvals, and other non-idempotent actions.

Must not say success or failure before the system knows.

Provide:

```text
Truthful pending/unknown status
Duplicate-action protection
Reconciliation status
Safe next action
Support route
Eventual confirmation
```

---

# 100. Offline State

Define:

```text
What remains available
What is read-only
What can queue locally
What cannot be promised
How pending work is identified
How reconnect/sync works
Conflict behavior
Sensitive local data considerations
```

---

# 101. Sync-Pending State

Users must distinguish:

```text
Saved locally
Sent
Confirmed by authoritative system
Failed
Needs attention
```

Do not represent local save as final business completion.

---

# 102. Sync Conflict

Define:

```text
What versions conflict
Which values are authoritative
What can be preserved
Who may resolve
Whether merge is allowed
Audit/evidence
Recovery after resolution
```

---

# 103. Expired State

May apply to:

```text
Session
Link
Invitation
Approval window
Draft
Quote
Token/code
Reservation
```

Experience must explain impact and valid renewal/restart route without revealing sensitive detail.

---

# 104. Success State

Success should confirm:

```text
What completed
Relevant identifier/status
What happens next
Whether another actor/system must act
How to view/undo/follow up where allowed
```

Celebration is not a substitute for confirmation.

---

# 105. Partial Success

Must identify:

```text
Completed items
Failed/pending items
Impact
Recovery/retry
Whether duplicate action is safe
Audit/support reference
```

---

# 106. State Coverage Matrix

For each critical View/Flow:

| View / Flow | Ready | Loading | Empty | Validation | Error | Permission | Conflict | Offline | Success | Recovery |
|---|---|---|---|---|---|---|---|---|---|---|
| `VIEW-REQ-EDIT` | ✓ | ✓ | N/A | ✓ | ✓ | ✓ | ✓ | Conditional | ✓ | ✓ |

`N/A` requires reviewed rationale, not missing work.

---

# 107. Error Pattern

`ERR` captures reusable error experience behavior.

```text
Classification
User impact
Disclosure boundary
Message responsibility
Preservation
Actions
Focus/announcement
Support/correlation
Recovery link
```

---

# 108. Error Classification

```text
USER_INPUT
BUSINESS_RULE
AUTHENTICATION
AUTHORIZATION
CONFLICT
DEPENDENCY
TIMEOUT
OFFLINE
SYSTEM
UNKNOWN_OUTCOME
DATA_QUALITY
UNSUPPORTED_STATE
```

---

# 109. Actionable Error

Error is actionable when it tells the user what can reasonably happen next.

Do not instruct users to retry if retry may duplicate an irreversible action.

---

# 110. Error Disclosure

Public error content must not expose:

```text
Stack traces
Internal identifiers without purpose
Secrets/tokens
Infrastructure details
Sensitive record existence
Other tenant/entity information
Security rule internals that aid abuse
```

---

# 111. Error Preservation

Recoverable errors should preserve:

```text
Entered data
Selections
Scroll/focus context
Draft state
Uploaded file metadata where safe
Journey progress
```

unless security, privacy, or data integrity requires clearing it.

---

# 112. Error Focus Management

After blocking error:

```text
Move focus only when it helps recovery
Announce error summary/status
Provide path to individual errors
Return focus predictably
Do not trap keyboard or assistive technology
```

---

# 113. Recovery Pattern

`REC` defines how users/system return to a safe usable condition.

Types:

```text
RETRY
RESUME
ROLLBACK
UNDO
REVERSE
RECONCILE
REAUTHENTICATE
RELOAD
REENTER
ESCALATE
SUPPORT_HANDOFF
MANUAL_RECOVERY
```

---

# 114. Retry Rule

Retry must specify:

```text
When safe
What is repeated
Whether idempotency is guaranteed
What remains preserved
Attempt feedback
What happens after repeated failure
```

---

# 115. Resume Rule

Resume defines:

```text
Saved progress
Resume entry point
Staleness check
Reauthentication
Changed data/rules
Expiry
Cross-device/channel behavior
```

---

# 116. Undo vs Reverse

Undo:

```text
Returns a recent reversible experience action within allowed window.
```

Reverse:

```text
Creates a governed compensating business action after original completion.
```

Do not label financial/legal reversal as simple undo.

---

# 117. Support Handoff

When self-recovery is unavailable:

```text
Explain what support can do
Provide safe reference/correlation ID
Preserve relevant context
Avoid exposing secrets
Offer accessible contact route
Clarify expected next state or wait
```

---

# 118. Interruption Model

Interruption sources:

```text
User leaves
Session expires
Device locks
Network drops
Dependency pauses
Approval waits
Context changes
Application closes
Security step interrupts
```

---

# 119. Unsaved Work

Define:

```text
What counts as unsaved
When warning appears
Autosave/draft status
Safe discard
Navigation/context switch behavior
Session expiry behavior
Cross-tab/device conflict
```

---

# 120. Session Expiry Experience

Must cover:

```text
Warning where policy allows
Clear expiry state
Preserve nonsensitive work where allowed
Reauthentication
Return to valid context
Sensitive content removal
Error/accessibility behavior
```

---

# 121. Authentication Journey

Map:

```text
Entry
Identity input
Authentication challenge
MFA/step-up conditions
Success destination
Failure limits
Locked/disabled account
Expired credentials
SSO return
Accessible alternatives
Support/recovery
```

---

# 122. Account Recovery Journey

Must balance:

```text
Identity assurance
User comprehension
Privacy
Accessibility
Rate/attempt limits
Token/code expiry
Alternative route
Notification
Session revocation
Support escalation
```

---

# 123. Reauthentication

For sensitive action, define:

```text
Trigger
Reason communicated
Method responsibility
Failure/cancel behavior
Return to pending action
Expiry
Accessibility
```

---

# 124. Authorization Experience

Experience Architecture maps required access into:

```text
Visible destinations/actions
Read-only states
Unavailable explanations
Delegation/acting capacity
Access request/escalation
Permission change refresh
Deep-link denial
```

Enforcement remains a Security/Architecture responsibility.

---

# 125. Role Switching

If user can change role/capacity:

```text
Current capacity visible
Switch authority
Context reset/preservation
Unsaved work handling
Navigation change
Permission change
Audit
Exit from elevated mode
```

---

# 126. Elevated / Support Access

Must make elevated context unmistakable and define:

```text
Entry reason
Scope
Duration
User/customer notice where applicable
Restricted actions
Exit
Audit
Sensitive data handling
```

---

# 127. Destructive Action

Examples:

```text
Delete
Terminate
Revoke
Cancel irreversible process
Overwrite
Bulk change
Publish externally
Financial capture/refund
```

---

# 128. Destructive Action Experience

Define according to risk:

```text
Consequence preview
Affected scope
Confirmation
Reauthentication
Reason capture
Second approver
Undo/reversal if possible
Progress
Partial failure
Audit
Success confirmation
```

Do not add friction uniformly to low-risk actions.

---

# 129. Confirmation Pattern

Confirmation is justified when:

```text
Action is hard to reverse
Impact is high or broad
User intent may be ambiguous
Data will be disclosed or sent
Money/legal status changes
```

Routine safe actions should not be interrupted by ceremonial confirmations.

---

# 130. Double Submission

Experience behavior must show:

```text
Action received
Processing
Repeat action prevented or safely handled
Outcome
Recovery when response is lost
```

Disabled button alone is not transaction integrity.

---

# 131. Optimistic Interaction

Allowed only when:

```text
Failure can be safely reconciled
Rollback/repair is understandable
User is not misled about irreversible completion
Requirement and architecture support it
```

---

# 132. Form Architecture

Form is modeled as a task, not a stack of fields.

Define:

```text
Goal
Modes
Sections/steps
Information dependencies
Field semantics
Validation
Draft/autosave
Submission
Errors
Review/confirmation
Success/recovery
Accessibility
```

---

# 133. Form Modes

```text
CREATE
EDIT
VIEW
REVIEW
APPROVE
CORRECT
RENEW
IMPORT
```

Mode changes actions, permissions, instructions, and state.

---

# 134. Field Contract

At experience level:

```text
Meaning
Label concept
Input responsibility
Required/optional/conditional
Format/constraint source
Help/instruction need
Default/prefill behavior
Editability
Validation timing
Error association
Privacy/masking
Accessibility semantics
```

Final component selection belongs to Phase 06.

---

# 135. Required Field

Required must derive from requirement/rule/context.

Do not mark fields required for database convenience.

---

# 136. Conditional Field

Define:

```text
Trigger
Visibility
Requirement status
Value preservation/clearing
Validation
Focus/announcement when it appears
Review summary behavior
```

---

# 137. Prefill and Defaults

Must distinguish:

```text
Authoritative value
Suggested default
Previous value
Derived value
Placeholder example
```

Defaults must not create unintended consent, approval, or financial choice.

---

# 138. Validation Timing

Possible:

```text
On input
On blur
On step transition
On submission
Server/business validation after submission
```

Use timing that supports correction without noise or false certainty.

---

# 139. Multi-Step Form

Define:

```text
Step purpose
Progress understanding
Back/forward
Save/resume
Cross-step dependencies
Error location
Review step
Context loss prevention
Accessibility of progress and navigation
```

---

# 140. Review and Confirmation Step

Use when user must verify consequential information before commitment.

Show:

```text
Decision-relevant summary
Editable sections
Consequences
Terms/consent where applicable
Final action label
```

---

# 141. File Upload Experience

Define:

```text
Purpose
Allowed types/size semantics
Multiple/single
Progress
Validation and security outcome
Preview/review
Replace/remove
Failure/retry
Accessibility
Privacy
Retention implication
```

---

# 142. Table / Data-Dense Experience

Define as applicable:

```text
Purpose
Row identity
Primary information
Sort/filter/search
Pagination/loading
Selection
Bulk actions
Inline actions/editing
Empty/error states
Responsive alternative
Keyboard navigation
Screen-reader semantics
Export
```

---

# 143. Bulk Action Experience

Must show:

```text
Selection scope
Count and affected context
Eligibility/ineligible items
Consequence
Progress
Partial success
Error export/details
Retry/recovery
Audit
```

---

# 144. Filter Experience

Define:

```text
Available facets
Default filters
Applied-filter visibility
Clear/reset
Persistence
URL/deep-link behavior
No-results state
Responsive behavior
Accessibility
```

---

# 145. Pagination / Infinite Loading

Selection must consider:

```text
User goal
Result size
Need to return to position
Bulk selection
URL/history
Keyboard/accessibility
Performance constraints
End-state clarity
```

No pattern is universal default.

---

# 146. Sort

Define default sort, available keys, direction, locale semantics, stability, and user visibility.

Do not rely on hidden backend order.

---

# 147. Selection

Selection experience defines:

```text
Single/multiple
Cross-page behavior
Selection persistence
Ineligible items
Count
Clear
Keyboard
Bulk-action relationship
```

---

# 148. Detail View

Detail view should prioritize:

```text
Identity
Current state
Critical context
Primary actions
History/evidence
Related objects
Permissions
Errors/conflicts
```

not mirror database fields.

---

# 149. Timeline / History Experience

Define:

```text
Event meaning
Actor/capacity
Time semantics
Ordering
Grouping
Sensitive data
Filtering
Source/audit distinction
Empty/loading/error
Accessibility
```

---

# 150. Status Communication

Status should answer:

```text
What state is this in?
What does it mean?
Who acts next?
What can the current user do?
What changed?
When did it change?
```

Color-only badge is insufficient.

---

# 151. Notification Experience

Define:

```text
Trigger
Recipient
Purpose
Urgency
Channel responsibility
Content
Action/deep link
Read/dismiss behavior
Preference/consent
Deduplication
Expiry
Accessibility
```

---

# 152. In-Product vs External Notification

External notification should not contain sensitive content beyond approved policy.

Deep link must restore a safe valid context.

In-product notification must not become a second unmanaged task system unless product responsibility requires it.

---

# 153. Toast / Transient Feedback

Transient message is appropriate only when:

```text
Information is noncritical
No action is required
Loss does not block understanding
It is accessible and announced appropriately
```

Critical errors or unknown outcomes need persistent state.

---

# 154. Help and Guidance

Possible layers:

```text
Clear label
Inline instruction
Contextual help
Example
Progressive disclosure
Documentation
Support handoff
```

Help cannot compensate for incoherent workflow.

---

# 155. Onboarding

Onboarding should teach only what is needed to reach first value safely.

Define:

```text
Eligibility
Trigger
Required vs optional
Skip/resume
Progress
Role/context variants
Accessibility
Completion outcome
Reentry/help
```

---

# 156. First-Use State

First use differs from empty data.

It may require:

```text
Orientation
Permission/configuration setup
Sample/example boundary
Initial action
Import/migration
Invite/team setup
```

---

# 157. Content Architecture

Content Architecture defines reusable information responsibilities and message types across journeys/states.

```text
Labels
Instructions
Status text
Errors
Warnings
Confirmations
Empty-state guidance
Notifications
Help
Legal/privacy notices
Support messages
```

---

# 158. Content Object

`CNT` may record:

```text
Purpose
Audience
Context
Source/owner
Required meaning
Tone/safety constraint
Localization
Accessibility
Expiry/version
Design placement responsibility
```

---

# 159. Message ID

Use stable IDs for material messages:

```text
MSG-AUTH-INVALID-001
MSG-PAY-UNKNOWN-001
MSG-FORM-ERROR-SUMMARY-001
```

Exact copy may mature in Phase 06 while meaning remains controlled.

---

# 160. Message Anatomy

Material message may need:

```text
Title/summary
What happened
Impact
What user can do
What remains preserved
Support/reference
Accessibility announcement priority
```

---

# 161. Error Message Boundary

Message must be truthful without exposing technical or security detail.

Avoid:

```text
Something went wrong.
```

when a safe actionable explanation is available.

Avoid fabricated certainty when outcome is unknown.

---

# 162. Action Labels

Action label should describe outcome:

```text
Submit request
Approve refund
Save draft
Send invitation
Delete record
```

Generic `OK`, `Yes`, `Continue` may be insufficient for consequential actions.

---

# 163. Status Vocabulary

Canonical business/product states must have user-understandable labels and definitions.

Do not create multiple labels for the same state without localization or context rationale.

---

# 164. Content Ownership

Possible owners:

```text
Product
Domain/Business
Legal/Compliance
Security
Support
Localization
Content Design
```

AI may draft but not approve regulated or legal meaning.

---

# 165. Content Variants

Variant may depend on:

```text
Role
State
Channel
Language
Market
Risk
Acting capacity
```

Variants must preserve canonical meaning.

---

# 166. Sensitive Content

Experience must define masking and disclosure for:

```text
Personal data
Financial data
Secrets/codes
Health/regulated data
Internal identifiers
Security state
Other entity/tenant information
```

---

# 167. Reveal Pattern

If sensitive data can be revealed:

```text
Who may reveal
Why
Duration
Reauthentication if required
Shoulder-surfing considerations
Copy/export restrictions
Audit
Accessible control and state
```

---

# 168. Consent / Notice Experience

Define:

```text
Purpose
Timing
Required information
Choice/control
Granularity
Withdrawal/change
Version
Evidence
Accessibility
Localization
```

Do not use preselected choice when policy or law prohibits it.

---

# 169. Generated Document Experience

Map:

```text
How user requests/receives it
Status/progress
Format/language
Accessible alternative
Preview/download/share
Sensitive-data warning
Expiry/version
Failure/regeneration
Audit
```

Document visual template belongs to Phase 06.

---

# 170. Content Completeness Review

Each critical journey should have meaningful content responsibility for:

```text
Entry/orientation
Instruction
Action labels
Validation
Error
Pending/unknown outcome
Success
Recovery
Support
```

---

# 171. Responsive Experience Architecture

Responsive behavior is not shrinking a desktop screen.

It defines how goals, information, actions, and context adapt across available space and input modes.

---

# 172. Responsive Rule

`RSP` may define:

```text
Affected view/flow
Priority content
Persistent actions
Reordered content
Collapsed/expanded regions
Alternative navigation
Table/list transformation
Input-mode change
Orientation behavior
Reflow requirement
State continuity
```

Exact breakpoints and layout values belong to Phase 06 unless imposed.

---

# 173. Experience Modes

Use meaningful modes such as:

```text
COMPACT
REGULAR
WIDE
TOUCH_PRIMARY
POINTER_KEYBOARD
KIOSK
HANDHELD_OPERATIONAL
PRINT / DOCUMENT
```

Do not infer device capability from width alone.

---

# 174. Content Priority

When space is limited:

```text
Preserve goal-critical information and actions
Preserve safety/context
Preserve errors and status
Move secondary information through progressive disclosure
Do not hide mandatory controls
```

---

# 175. Responsive Navigation

Navigation may change form but must preserve:

```text
Destination availability
Current location/context
Keyboard and screen-reader access
Back/return behavior
Deep-link consistency
```

---

# 176. Responsive Data-Dense Views

Options may include:

```text
Prioritized columns
Row detail expansion
Card/list alternative
Horizontal scroll with clear context
Saved views
Task-specific compact view
Separate mobile workflow when justified
```

Never drop critical status or action silently.

---

# 177. Orientation

If portrait/landscape matters, define:

```text
Supported orientations
Task-specific benefit
Content/action continuity
Rotation state preservation
Accessibility
```

---

# 178. Input Modes

Experience must consider as applicable:

```text
Keyboard
Pointer
Touch
Stylus
Switch control
Voice control
Screen reader
Physical scanner/device input
```

No critical action may depend exclusively on one unsupported input mode.

---

# 179. Cross-Platform Consistency

Consistency means:

```text
Same product meaning
Same control integrity
Recognizable terminology
Predictable outcomes
Preserved user context where supported
```

It does not mean identical layout or interaction on every platform.

---

# 180. Platform-Specific Convention

Platform convention may refine interaction when it does not conflict with product policy, accessibility, or cross-channel consistency.

Record material differences as variants.

---

# 181. Cross-Channel Journey

Example:

```text
Start on web
Receive notification on mobile
Approve on mobile
Review evidence on web
```

Define:

```text
Identity/session continuity
Context transfer
State freshness
Deep link
Notification
Return
Failure
Privacy
```

---

# 182. Channel Handoff

If handoff requires a code/link/QR:

```text
Expiry
Single-use/replay behavior
Wrong-device behavior
Authentication
Accessible alternative
Sensitive data in link
Recovery
```

---

# 183. Third-Party Experience Continuity

When journey enters third party:

```text
Explain transition where needed
Preserve goal/context safely
Maintain language/accessibility expectations where contracted
Define cancel/return
Handle failure/unknown outcome
Clarify support ownership
Do not imply control the product does not have
```

---

# 184. Localization Experience Architecture

Localization affects:

```text
Language
Direction
Terminology
Date/time
Numbers
Currency
Address
Names
Sorting/search
Content length
Plural/gender rules
Legal/market content
Documents
Notifications
```

---

# 185. Language Selection

Define:

```text
Default source
User choice
Persisted scope
Unauthenticated/authenticated behavior
Fallback
Unsupported content
Cross-device/channel continuity
```

---

# 186. RTL Architecture

RTL is not a full visual mirror.

Phase 05 defines:

```text
Reading/order direction
Navigation order
Flow direction where semantic
Back/forward meaning
Mixed-direction content
Form sequence
Focus order
Tables/timelines
Directional icons
Numbers/codes/identifiers
Charts/maps exceptions
```

Phase 06 realizes layout and visual details.

---

# 187. Mixed-Direction Content

Examples:

```text
Arabic label + English email
RTL sentence + invoice number
Arabic address + Latin code
Phone number
URL
Code/token
```

Experience specification identifies content classes requiring controlled direction and copy behavior.

---

# 188. Locale-Aware Formatting

Map requirements for:

```text
Date
Time
Timezone
Number
Currency
Percentage
Address
Name
Measurement unit
```

Display locale and authoritative stored value are distinct.

---

# 189. Content Expansion

Translated content may expand or contract.

Experience Architecture flags:

```text
Constrained labels
Tables
Tabs
Navigation
Buttons
Status chips
Documents
Notifications
```

Phase 06 validates layout tolerance.

---

# 190. Search and Sort Localization

Define user expectation for:

```text
Diacritics
Alternative spellings
Arabic/Latin digits
Case
Name order
Locale collation
Transliterated values
```

Technical implementation comes later.

---

# 191. Accessibility Experience Architecture

Phase 05 translates approved `ACC` requirements into journey, flow, state, navigation, content, and interaction rules.

It does not replace the source standard or`REQ-008`.

---

# 192. Accessibility Scope Matrix

For each supported platform/channel, identify:

```text
Critical journeys
Views/routes
States
Input modes
Assistive technologies
Documents
Notifications
Third-party segments
Language/direction variants
Verification expectations
```

---

# 193. Keyboard Path

Define for keyboard-applicable journeys:

```text
Entry focus
Logical sequence
Action activation
Modal/panel containment
No trap
Skip/bypass repeated content
Error focus
Focus restoration
Shortcut behavior
Exit
```

---

# 194. Focus Contract

Focus changes must be predictable after:

```text
Navigation
Opening/closing transient surfaces
Validation failure
Dynamic content update
Item deletion
Route change
Step change
Reauthentication
Error/recovery
```

---

# 195. Screen Reader Experience

Define semantic responsibility for:

```text
Page/view title
Heading hierarchy
Landmarks/regions
Control name/role/value
Relationships
Status announcements
Errors
Tables/lists
Progress
State change
Dynamic content
```

Final component semantics are realized in Phase 06/implementation.

---

# 196. Accessible Navigation

Navigation must support:

```text
Keyboard
Programmatic current state
Meaningful labels
Predictable order
Context understanding
Bypass/repeated content strategy
Focus after route change
RTL order consistency
```

---

# 197. Accessible Forms

Experience rules cover:

```text
Labels
Instructions
Required/optional meaning
Grouping
Error association
Summary
Focus
Preserved input
Step/progress semantics
Review and confirmation
Timeout/recovery
```

---

# 198. Accessible Authentication and Recovery

Map accessible alternatives for cognitive tests, gestures, device handoffs, codes, time limits, and security challenges according to approved baseline.

Accessibility must not be resolved by weakening identity assurance.

---

# 199. Status Announcement

Dynamic status may need:

```text
POLITE
ASSERTIVE
FOCUS_CHANGE
PERSISTENT_VISIBLE_STATE
```

Choose based on urgency and user interruption cost.

---

# 200. Time Limits

If a journey has time limit:

```text
Explain duration when relevant
Warn before expiry where allowed
Allow extend/disable/adjust when required
Preserve work safely
Provide recovery
Support assistive technology
```

Security exceptions need explicit rationale.

---

# 201. Gesture and Drag Alternatives

Critical action using gesture, drag, swipe, or spatial movement requires an accessible alternative where the adopted baseline demands it.

---

# 202. Motion and Animation Experience

Phase 05 defines purpose and user control requirements:

```text
Orientation
Feedback
Continuity
Progress
Relationship
```

and constraints:

```text
Reduced motion
No essential information by motion alone
No disorienting route transitions
No unsafe flashing
Pause/stop when required
```

Phase 06 defines detailed motion.

---

# 203. Zoom and Reflow

Experience must preserve:

```text
Reading order
Primary actions
Context
Error messages
Status
Navigation
No two-dimensional scrolling except justified content
```

at applicable zoom/reflow conditions.

---

# 204. Touch and Target Behavior

Experience Architecture identifies dense/high-risk targets, adjacent destructive actions, and touch-only interactions requiring design safeguards.

Exact dimensions come from adopted design/accessibility standard in Phase 06.

---

# 205. Accessible Data-Dense Views

Define alternatives or semantics for:

```text
Tables
Charts
Timelines
Maps
Bulk selection
Inline editing
Complex filters
Status-only visuals
```

---

# 206. Accessible Documents and Notifications

Journey must include how users obtain, understand, and request alternatives for generated documents or notifications.

Document-level structure is designed and verified downstream.

---

# 207. Accessibility Exception

Known limitation must record:

```text
Affected requirement/journey/view/state
User impact
Reason
Alternative/compensating route
Owner
Approval
Expiry/review
Evidence
GOV-009 linkage
```

It is not silently moved to backlog.

---

# 208. Security and Privacy Experience Review

For critical journeys, review:

```text
Authentication
Authorization visibility
Acting capacity
Session/reauthentication
Sensitive data display
Consent/notice
External sharing
Destructive actions
Recovery
Safe errors
Audit/evidence awareness
```

---

# 209. Privacy by Experience

Users should understand where applicable:

```text
What data is requested
Why
Who can see it
What is optional
What will happen next
How to correct/withdraw/delete where supported
```

Avoid dark patterns that pressure disclosure or consent.

---

# 210. Data Minimization in Experience

Do not ask for information before it is needed or because it may be useful later.

Each field/content request must have requirement and purpose linkage.

---

# 211. Sensitive Information Display

Define:

```text
Default masking
Reveal
Copy
Export
Shared-screen context
Notification content
Screenshot/public evidence restrictions
Role/context differences
```

---

# 212. Security-Sensitive Error

Must balance:

```text
Actionable recovery
No account/resource enumeration
No sensitive rule disclosure
Accessible understanding
Support route
```

---

# 213. External Sharing Experience

Before share/export:

```text
Recipient/scope clear
Sensitivity warning
Permission check
Expiry/revocation if supported
Format/accessibility
Audit
Confirmation proportional to risk
```

---

# 214. Experience Measurement Intent

Phase 05 maps experience outcomes to measurable signals without inventing analytics implementation.

Examples:

```text
Journey completion
Time on task
Drop-off
Error/recovery rate
Repeated attempts
Support escalation
Accessibility blocker
Cross-channel handoff success
```

---

# 215. Metric Interpretation

Metric must connect to goal and context.

Fast completion may mean efficiency or confusion/abandonment depending on journey.

Do not optimize one metric without safety and quality guardrails.

---

# 216. Instrumentation Implication

Phase 05 may identify events/outcomes that need measurement.

Phase 07 defines technical instrumentation; Phase 11 uses operational/product metrics.

Privacy and data minimization apply.

---

# 217. Standards Experience Applicability Review

Before Experience Baseline, Phase 05 reviews every applicable `GOV-009` entry with experience impact.

Review asks:

```text
Which journeys, scenarios, flows, views, routes, states, messages, documents, and third-party segments are affected?
Which keyboard/focus/assistive-technology/RTL/reflow/error/recovery rules result?
Which SEC/ACC/DR/INT/AUD requirements require experience disposition?
Which artifacts carry the canonical experience links?
Which validation and evidence methods apply?
Which design obligations must Phase 06 receive?
What change reopens the experience interpretation?
```

---

# 218. GOV-009 Experience Update

Phase 05 adds:

```text
Scenario IDs
Journey IDs
Flow IDs
View / Route IDs
UX State IDs
Interaction Rule IDs
Error / Recovery Pattern IDs
Accessibility Experience Rule IDs
Localization / RTL Rule IDs
Third-Party and Document Experience Links
Experience Validation Methods / Evidence Expectations
Phase 06 Design Derivation Obligations
Experience-Level Reopen Conditions
G4A Status
```

---

# 219. GOV-009 Blocking Rule

Before `G4A = PASS`:

```text
Applicable experience obligation without canonical experience link = 0
Critical ACC/SEC requirement without journey/state/interaction disposition = 0
Blocking third-party/document/accessibility experience gaps = 0
```

---

# 220. Experience Architecture Workflow

```text
05.0 Confirm Entry Baselines
      ↓
05.1 Build Experience Requirement Inventory
      ↓
05.2 Define Principles, Actors, Goals, and Contexts
      ↓
05.3 Build Scenario Catalog
      ↓
05.4 Build Journey Catalog
      ↓
05.5 Model Flows, Decisions, Interruptions, and Recovery
      ↓
05.6 Define Information Architecture
      ↓
05.7 Define Navigation and Context Model
      ↓
05.8 Build View / Screen / Route Inventory
      ↓
05.9 Build UX State and Error / Recovery Catalogs
      ↓
05.10 Define Interaction and Content Rules
      ↓
05.11 Define Responsive / Cross-Platform Behavior
      ↓
05.12 Define Localization / RTL Behavior
      ↓
05.13 Define Accessibility Experience Behavior
      ↓
05.14 Review Security / Privacy Experience
      ↓
05.15 Create Structural Wireframes / Flow Prototype where needed
      ↓
05.16 Validate Experience
      ↓
05.17 Validate Requirements and GOV-009 Coverage
      ↓
05.18 Baseline Experience Architecture
      ↓
05.19 Evaluate G4A
      ↓
05.20 Generate Product Design Handoff
```

---

# 221. Step 05.0 — Confirm Entry Baselines

Confirm:

```text
Product baseline version
Requirements baseline version
Release scope
Actors/roles
Platforms/channels
Markets/languages
Critical journeys indicated upstream
Applicable standards/profiles
G3B conditions
```

---

# 222. Step 05.1 — Experience Requirement Inventory

Every requirement receives experience disposition:

```text
DIRECT_EXPERIENCE_IMPACT
CROSS_CUTTING_EXPERIENCE_RULE
NO_EXPERIENCE_IMPACT with rationale
DESIGN_ONLY_FOLLOW_UP
ARCHITECTURE_DEPENDENCY
PENDING
UPSTREAM_GAP
```

---

# 223. Step 05.2 — Principles, Actors, Goals, Contexts

Create the experience framing before screens or flows.

Resolve identity/context/acting-capacity ambiguity early.

---

# 224. Step 05.3 — Scenario Catalog

Create base and material variants for:

```text
Primary goals
Critical exceptions
Security-sensitive actions
Accessibility contexts
Offline/interruption
Cross-channel
Third-party handoff
Admin/support
```

---

# 225. Step 05.4 — Journey Catalog

Define end-to-end scope, stages, actors, outcomes, handoffs, wait states, and criticality.

---

# 226. Step 05.5 — Flow Modeling

Model steps, decisions, loops, branches, states, failures, recovery, and handoffs at the depth needed to remove design ambiguity.

---

# 227. Step 05.6 — Information Architecture

Organize concepts, destinations, taxonomy, terminology, hierarchy, and findability according to user mental model and product responsibilities.

---

# 228. Step 05.7 — Navigation and Context

Define global/workspace/local/contextual navigation, entry points, deep links, back/return, and context persistence/switching.

---

# 229. Step 05.8 — View / Screen / Route Inventory

Derive destinations and surface candidates from journeys/flows/IA.

Do not create a screen for every requirement or state.

---

# 230. Step 05.9 — State, Error, Recovery

Run state coverage on every critical view/flow and link reusable `ERR`/`REC` patterns.

---

# 231. Step 05.10 — Interaction and Content Rules

Define task behavior, forms, data-dense interactions, messaging, help, notification, and sensitive-action rules.

---

# 232. Step 05.11 — Responsive / Cross-Platform

Define what persists, adapts, reorders, transforms, or requires platform-specific variant.

---

# 233. Step 05.12 — Localization / RTL

Review all critical journeys/views/states for language, direction, mixed content, formatting, search/sort, and content expansion.

---

# 234. Step 05.13 — Accessibility Experience

Translate `ACC` and`GOV-009` into journey, focus, keyboard, semantics, status, error, recovery, responsive, document, and third-party rules.

---

# 235. Step 05.14 — Security / Privacy Experience

Review authentication, authorization visibility, reauthentication, acting capacity, sensitive content, consent, external sharing, error disclosure, and recovery.

---

# 236. Step 05.15 — Structural Wireframes / Flow Prototype

Use only when needed to validate:

```text
Information grouping
Action sequence
Navigation
State transitions
Responsive priority
Error/recovery
Keyboard/focus path
```

Keep styling intentionally neutral.

---

# 237. Structural Wireframe Boundary

Structural wireframe may show:

```text
Regions
Content hierarchy concept
Actions
Navigation
States
Annotations
```

It must not become de facto visual baseline without Phase 06 review and approval.

---

# 238. Prototype Boundary

Prototype in Phase 05 may prove flow and interaction structure.

It does not prove:

```text
Visual design quality
Final component behavior
Production accessibility
Technical feasibility
Performance
Security enforcement
```

---

# 239. Step 05.16 — Experience Validation

Select methods based on risk and uncertainty.

---

# 240. Step 05.17 — Coverage Validation

Check bidirectionally:

```text
Requirement → Experience disposition
Goal → Journey
Journey → Flow
Flow → View/Route/State
View/State → Requirements
ACC/SEC/GOV-009 → Experience rules
Experience object → Phase 06 design obligation
```

---

# 241. Step 05.18 — Baseline

Approve a versioned set of experience artifacts and links.

```text
EXPERIENCE-BASELINE-1.0
```

---

# 242. Step 05.19 — Evaluate G4A

G4A evaluates logical completeness and validation, not visual polish.

---

# 243. Step 05.20 — Product Design Handoff

Handoff identifies exactly what Phase 06 must design, including states, responsive/accessibility variants, content responsibility, and unresolved non-blocking conditions.

---

# 244. Experience Architecture Artifacts

Canonical artifact catalog:

```text
EXP-001 Experience Architecture Blueprint
EXP-002 Experience Principles and Constraints
EXP-003 Experience Actor, Goal, and Context Model
EXP-004 Experience Scenario Catalog
EXP-005 Journey Catalog
EXP-006 Experience Flow Catalog and Diagram Index
EXP-007 Information Architecture
EXP-008 Navigation and Context Model
EXP-009 View, Screen, Route, and Entry-Point Inventory
EXP-010 UX State Catalog
EXP-011 Error, Safety, Interruption, and Recovery Model
EXP-012 Interaction Behavior Specification
EXP-013 Content and Message Model
EXP-014 Responsive and Cross-Platform Experience Model
EXP-015 Accessibility Experience Specification
EXP-016 Localization and RTL Experience Specification
EXP-017 Structural Wireframes and Flow Prototype Specification
EXP-018 Experience Coverage and Traceability Matrix
EXP-019 Experience Validation Record
EXP-020 Product Design Handoff
```

---

# 245. EXP-001 — Experience Architecture Blueprint

Human-readable baseline overview connecting goals, journeys, IA, navigation, views, states, and cross-cutting experience rules.

---

# 246. EXP-002 — Experience Principles and Constraints

Product-specific principles plus inherited platform, accessibility, security, localization, content, and release constraints.

---

# 247. EXP-003 — Actor, Goal, and Context Model

Actors, acting capacities, goals, contexts, environment constraints, and variants.

---

# 248. EXP-004 — Scenario Catalog

Base scenarios and material variants with requirements, contexts, outcomes, and status.

---

# 249. EXP-005 — Journey Catalog

End-to-end journeys, stages, actors, handoffs, outcomes, criticality, and coverage.

---

# 250. EXP-006 — Experience Flow Catalog and Diagram Index

Canonical flow definitions and links to diagrams without making diagram image the only source of truth.

---

# 251. EXP-007 — Information Architecture

Domains, concepts, taxonomy, hierarchy, labeling, destinations, and findability model.

---

# 252. EXP-008 — Navigation and Context Model

Workspaces, navigation layers, context selection/persistence/switching, entry points, deep links, and back/return behavior.

---

# 253. EXP-009 — View, Screen, Route, and Entry-Point Inventory

Purpose, actors, requirements, journeys, information, actions, states, routes, and cross-cutting implications for each destination/surface.

---

# 254. EXP-010 — UX State Catalog

Canonical view/flow state definitions and coverage matrix.

---

# 255. EXP-011 — Error, Safety, Interruption, and Recovery Model

Reusable error/recovery patterns, destructive/sensitive action behavior, session/interruption, unknown outcomes, and support handoffs.

---

# 256. EXP-012 — Interaction Behavior Specification

Forms, tables, search, filters, selection, bulk actions, notifications, status, upload, background work, and other interaction contracts.

---

# 257. EXP-013 — Content and Message Model

Content responsibilities, stable message IDs, meaning, ownership, variants, localization, and accessibility intent.

---

# 258. EXP-014 — Responsive and Cross-Platform Experience Model

Experience modes, content/action priority, cross-platform variants, input modes, orientation, and cross-channel continuity.

---

# 259. EXP-015 — Accessibility Experience Specification

Journey/view/state-specific keyboard, focus, semantics, status, forms, error/recovery, reflow, motion, document, and third-party experience rules.

---

# 260. EXP-016 — Localization and RTL Experience Specification

Language/direction, mixed content, formatting, labels, navigation/focus order, content expansion, search/sort, documents, and market variants.

---

# 261. EXP-017 — Structural Wireframes and Flow Prototype Specification

Optional/risk-driven structural representations, annotations, prototype scope, assumptions, validation questions, and evidence.

---

# 262. EXP-018 — Experience Coverage and Traceability Matrix

Maps Requirements, Goals, Scenarios, Journeys, Flows, Views, Routes, States, Experience Rules, `GOV-009`, and Phase 06 obligations.

---

# 263. EXP-019 — Experience Validation Record

Methods, participants, tasks/scenarios, findings, severity, decisions, conditions, and approval evidence.

---

# 264. EXP-020 — Product Design Handoff

Machine/human-readable design input with priorities, variants, state coverage, content responsibility, and traceability.

---

# 265. Artifact Ownership Rule

Phase 05 artifacts own experience logic.

Phase 06 references and realizes them.

Do not maintain conflicting journey/state/navigation copies inside Figma pages, design tickets, or implementation notes.

---

# 266. Governance Registers Updated

Phase 05 updates:

```text
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-007 Change Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
```

---

# 267. Delivery Profile Principle

The selected Product OS profile controls artifact packaging and depth:

```text
P1 — Lean
P2 — Standard
P3 — Comprehensive
```

All profiles retain critical journey, state, error/recovery, accessibility, traceability, and handoff logic.

---

# 268. P1 — Lean Behavior

P1 may use:

```text
EXP-000 — Experience Pack
```

containing:

```text
Principles and contexts
Primary scenarios and journeys
Core flows
IA/navigation
View/route inventory
Critical states and recovery
Responsive/accessibility/RTL rules
Structural sketches if needed
Coverage
G4A record
Design handoff
```

P1 does not reduce critical state or applicable accessibility coverage.

---

# 269. P2 — Standard Behavior

Recommended independent artifacts:

```text
EXP-001
EXP-003
EXP-004
EXP-005
EXP-006
EXP-007
EXP-008
EXP-009
EXP-010
EXP-011
EXP-012
EXP-013
EXP-014
EXP-015
EXP-016
EXP-018
EXP-019
EXP-020
```

`EXP-017` activated according to validation need.

---

# 270. P3 — Comprehensive Behavior

P3 adds as applicable:

```text
Journey/domain-specific files
Formal variant matrices
Workspace and operational journey catalogs
Security-sensitive journey catalog
Interruption/recovery journey catalog
Complete route and entry-point model
Formal state transition matrices
Detailed content/message catalog
Formal responsive/platform matrices
Clause-level accessibility experience mapping
Independent accessibility/security/content/localization reviews
Formal tree testing/cognitive walkthrough/usability evidence
Versioned diagrams and prototype evidence
Full requirement-to-design traceability
Formal change impact analysis
Independent approval
```

---

# 271. Domain-Level Depth Override

Project may apply higher depth to a domain:

```yaml
default_profile: P1

domain_depth_overrides:
  authentication_recovery: P3
  accessibility: P3
  warehouse_operations: P2
```

This does not rename or replace P1/P2/P3.

---

# 272. Profile Escalation Triggers

```text
Financial or irreversible action
Regulated/sensitive data
Complex permissions or acting capacity
Multi-actor workflow
Cross-channel journey
Offline/sync
High operational density
Generated legal/financial documents
User-facing third party
Accessibility-critical journey
Multi-language/RTL complexity
High support/error cost
Safety or business continuity
Multiple products/teams
```

---

# 273. Experience Behavior by Product State

Phase 05 adapts by `S0–S6` while preserving the same logical contract.

## S0 — Early Idea

Model only the critical hypothesis journey and minimum states needed to learn safely. Assumptions remain explicit.

## S1 — New Product

Build target mental model, journeys, IA, and navigation without inheriting accidental legacy patterns.

## S2 — Business Transformation

Focus on operational roles, handoffs, exceptions, controls, physical context, and transition from manual/existing work.

## S3 — Existing Product

Use:

```text
CURRENT OBSERVED EXPERIENCE
        ↓ compare
APPROVED REQUIREMENTS / TARGET PRODUCT
        ↓
KEEP / CHANGE / ADD / RETIRE / UNKNOWN
```

Existing UI is evidence, not automatic target truth.

## S4 — Implementation in Progress

Reconcile requirements, current Figma/prototype, routes, code behavior, and tests. Record deviation rather than normalizing it silently.

## S5 — Recovery

Prioritize containment, safe states, continuity, critical errors, data/security exposure, and operator/user recovery before broader redesign.

## S6 — Evolution

Use delta journeys, views, states, routes, and interaction rules with explicit regression/impact coverage.

---

# 274. Existing Experience Audit

For S3/S4/S5/S6, inspect as available:

```text
Production product
Screenshots/video
Figma/design files
Routes/navigation
Analytics
Support tickets
User feedback
Accessibility findings
Error logs/incidents
Existing UX documentation
```

---

# 275. Observed vs Intended

Classify current behavior:

```text
INTENDED_AND_SUPPORTED
IMPLEMENTED_BUT_UNDOCUMENTED
CONTRADICTS_REQUIREMENT
LEGACY
DEFECT
UNKNOWN
```

Do not rewrite target baseline to match a defect.

---

# 276. Experience Validation

Validation asks:

> **If Phase 06 designs exactly this experience structure, can target users complete the approved outcomes safely, understandably, accessibly, and recoverably?**

---

# 277. Validation Methods

Depending on profile/risk:

```text
Requirements walkthrough
Scenario walkthrough
Journey walkthrough
Flow inspection
Cognitive walkthrough
Tree test / IA validation
Card sorting where taxonomy uncertainty exists
Structural wireframe review
Low-fidelity usability test
Keyboard path review
Screen-reader/semantic review
RTL/localization walkthrough
Responsive/cross-platform walkthrough
Security/privacy journey review
Operational simulation
Expert review
Stakeholder validation
```

---

# 278. Validation Is Not Approval Theatre

Sending diagrams and asking "looks good?" is not sufficient.

Validation must use explicit goals, scenarios, questions, findings, and dispositions.

---

# 279. Validation Participant Selection

Choose participants based on:

```text
Actual role/context
Journey criticality
Domain knowledge
Accessibility needs
Language/direction
Operational environment
Decision authority
```

Executive approval cannot replace operational/user validation.

---

# 280. Validation Finding

```yaml
finding_id: XVF-014
method: COGNITIVE_WALKTHROUGH
scenario: SCN-014
journey: JRN-006
step: FSTEP-APR-004
finding:
  "Approver cannot determine which legal entity the request belongs to before approval."
severity: HIGH
affected:
  - NAV-CONTEXT-002
  - VIEW-APR-DETAIL
  - SEC-AUTHZ-003
disposition: CHANGE_EXPERIENCE_MODEL
owner: EXPERIENCE_ARCHITECT
status: OPEN
```

---

# 281. Finding Severity

```text
BLOCKER
CRITICAL
HIGH
MEDIUM
LOW
OBSERVATION
```

Drivers:

```text
Goal completion
Safety/security/privacy
Accessibility
Data/financial integrity
Recovery
Frequency
Reach
Irreversibility
```

---

# 282. Validation Disposition

```text
CHANGE_EXPERIENCE_MODEL
CHANGE_CONTENT_RESPONSIBILITY
ADD_STATE_OR_RECOVERY
ADD_VARIANT
REQUIREMENT_GAP
PRODUCT_SCOPE_GAP
ARCHITECTURE_DEPENDENCY
DESIGN_FOLLOW_UP
ACCEPT_RISK
NO_CHANGE with rationale
```

---

# 283. Experience Coverage Model

Coverage dimensions:

```text
Requirement
Goal
Actor/Role
Context
Scenario
Journey
Flow
View/Route
State
Error/Recovery
Responsive/Platform
Accessibility
Localization/RTL
GOV-009
Validation
Phase 06 Design
```

---

# 284. Requirement Experience Disposition

Each requirement gets:

```text
COVERED_DIRECTLY
COVERED_BY_CROSS_CUTTING_RULE
NO_EXPERIENCE_IMPACT
DESIGN_ONLY
ARCHITECTURE_ONLY
PENDING
BLOCKED
```

`NO_EXPERIENCE_IMPACT` requires rationale for FR/ACC or other visibly user-affecting requirements.

---

# 285. Journey Coverage

Every critical User Goal must map to at least one complete Journey or approved non-product/manual disposition.

Every critical Journey must map to:

```text
Scenario
Requirements
Flows
Views/Routes
States
Error/Recovery
Accessibility
Validation
```

---

# 286. Flow Coverage

Every critical Flow covers:

```text
Entry
Steps
Decision branches
Alternative path
Failure
Recovery
Exit/outcome
State transitions
```

---

# 287. View Coverage

Every approved `VIEW` links to:

```text
Goal/Journey/Flow
Requirements
Actors/roles
Information/actions
Route/entry
States
Responsive modes
Accessibility rules
Design obligation
```

---

# 288. State Coverage

Every critical view/flow receives applicability review for:

```text
Loading
Empty
Validation
System/dependency error
Permission
Conflict/stale
Offline/sync
Processing/unknown outcome
Success/partial success
Interruption/recovery
```

---

# 289. Permission Coverage

Every protected action/destination must define experience disposition for:

```text
Authorized
Unauthorized
Read-only
Temporarily unavailable
Delegated/elevated
Context mismatch
Deep-link denial
Permission changed mid-session
```

---

# 290. Accessibility Coverage

Every applicable `ACC` requirement maps to one or more:

```text
Journey
View
Route
State
Interaction Rule
Error/Recovery Pattern
Responsive Rule
Content/Message
Document/Third Party
Phase 06 Design Obligation
Validation Method
```

---

# 291. Content Coverage

Critical states and actions must have message/content responsibility even if final copy is deferred to Phase 06.

---

# 292. Orphan Experience Object

Any `SCN/JRN/FLOW/VIEW/ROUTE/UXS/IXR` without upstream purpose or downstream use is an orphan.

Disposition:

```text
Link source
Merge
Reject
Escalate scope change
```

---

# 293. Unrealized Requirement

User-affecting requirement with no experience disposition:

```text
EXPERIENCE_COVERAGE_GAP
```

It blocks G4A if material.

---

# 294. Journey Without Outcome

Journey that ends at a screen instead of a meaningful success/safe-failure/recovery outcome is incomplete.

---

# 295. State Without Recovery

Recoverable error/permission/conflict/interruption state with no valid next step:

```text
DEAD_END_STATE
```

---

# 296. Navigation Leak

Destination exposed outside authorized/relevant context:

```text
NAVIGATION_SCOPE_LEAK
```

Experience fix does not replace authorization enforcement.

---

# 297. Design Readiness Status

```text
DRAFT
NEEDS_REQUIREMENT
NEEDS_CONTEXT
NEEDS_FLOW
NEEDS_STATE_COVERAGE
NEEDS_ACCESSIBILITY
NEEDS_VALIDATION
READY_FOR_REVIEW
APPROVED
BASELINED
BLOCKED
```

---

# 298. Experience Baseline

Baseline records:

```text
Experience baseline ID/version
Product and Requirements baseline versions
Release scope
Included artifact versions
Supported platforms/markets/languages
Approval authority
Validation evidence
Conditions
Deferred design items
GOV-009 status
```

---

# 299. G4A — Experience Baseline Gate

Purpose:

> Determine whether the experience logic is complete, coherent, accessible, recoverable, traceable, and validated enough for Product Design to proceed without inventing journeys, navigation, states, content meaning, or interaction behavior.

---

# 300. G4A Required Checks

G4A evaluates the following at selected P-profile depth.

---

# 301. G4A-01 Scope and Baselines

Experience scope, release, platforms/channels, markets/languages, and source baseline versions are explicit and consistent with G3A/G3B.

---

# 302. G4A-02 Principles, Actors, Goals, Contexts

Experience principles and material actors/goals/contexts/acting capacities are explicit.

---

# 303. G4A-03 Scenario Coverage

Primary, alternative, security-sensitive, accessibility, interruption, recovery, and cross-channel scenarios exist where applicable.

---

# 304. G4A-04 Journey Completeness

Critical goals have end-to-end journeys with actors, stages, handoffs, outcomes, interruption, and recovery.

---

# 305. G4A-05 Flow Completeness

Critical flows include steps, decisions, branches, exceptions, failures, loops, state transitions, and exits.

---

# 306. G4A-06 Information Architecture

Concepts, taxonomy, hierarchy, labels, destinations, and findability are coherent with product/domain language and user mental models.

---

# 307. G4A-07 Navigation and Context

Workspaces, navigation levels, location/context visibility, switching, persistence, entry/deep links, and return behavior are defined.

---

# 308. G4A-08 View / Screen / Route Inventory

Required destinations/surfaces are identified without orphan screens or state inflation.

---

# 309. G4A-09 UX State Coverage

Critical views/flows cover applicable loading, empty, partial, error, permission, conflict, offline, processing, unknown outcome, success, and interruption states.

---

# 310. G4A-10 Error, Safety, and Recovery

Critical error and sensitive-action behavior protects data/control integrity, avoids dead ends, preserves work appropriately, and provides valid recovery.

---

# 311. G4A-11 Interaction Behavior

Forms, tables, search, filters, bulk actions, notifications, background work, and other critical interactions have behavior contracts.

---

# 312. G4A-12 Content and Messages

Critical labels, instructions, statuses, errors, confirmations, empty states, and recovery messages have meaning and ownership.

---

# 313. G4A-13 Responsive and Cross-Platform

Content/action priority, input modes, responsive transformations, platform variants, and cross-channel continuity are explicit.

---

# 314. G4A-14 Localization and RTL

Critical journeys/views/states cover language selection, direction, mixed content, locale formatting, search/sort, expansion, documents, and notifications.

---

# 315. G4A-15 Accessibility Experience

Applicable `ACC` requirements have keyboard, focus, semantics, forms/errors, status, reflow, motion, input, document, and third-party experience dispositions.

---

# 316. G4A-16 Security and Privacy Experience

Authentication/recovery, authorization visibility, acting capacity, session/reauthentication, sensitive content, consent, safe error, sharing, and recovery implications are covered.

---

# 317. G4A-17 Requirements Traceability

Every material user-affecting requirement has experience disposition and every experience object has upstream purpose.

---

# 318. G4A-18 Validation

Critical journeys, IA/navigation, state/recovery, accessibility, and high-risk interactions have validation evidence at required depth.

---

# 319. G4A-19 Standards / GOV-009 Experience Linkage

G4A verifies:

```text
Applicable GOV-009 entries with experience impact link to canonical EXP objects.
ACC/SEC/DR/INT/AUD experience obligations have journey/state/interaction dispositions.
Supported platforms, markets, languages, documents, and third parties are consistent with applicability decisions.
Experience validation methods and evidence expectations are recorded.
Phase 06 design derivation obligations are explicit.
Experience-level owners and reopen conditions exist.
No applicable obligation is silently deferred to Design or QA.
Blocking experience linkage gaps equal zero.
```

---

# 320. G4A-20 Open Questions and Decisions

```text
Blocking Experience Questions = 0
Blocking Experience Decisions = 0
Blocking Validation Findings = 0
```

---

# 321. G4A-21 Product Design Readiness

Phase 06 can identify every design subject, state, variant, content responsibility, responsive rule, accessibility rule, and traceability obligation without inventing experience behavior.

---

# 322. G4A-22 Change Governance

Experience Baseline version, owners, approval, change route, affected downstream artifacts, and reopen rules are explicit.

---

# 323. G4A Outcomes

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

---

# 324. G4A PASS

Experience Baseline is coherent and ready for Product Design.

---

# 325. G4A PASS_WITH_CONDITIONS

Allowed only when conditions are:

```text
Non-blocking
Explicit
Owned
Time-bound
Limited in design impact
Do not weaken critical security/accessibility/recovery obligations
```

Example:

```text
Future-release analytics workspace IA remains due before its release enters Phase 06; Release 1 experience is unaffected.
```

---

# 326. G4A HOLD

Examples:

```text
Critical goal has no end-to-end journey.
Authorization/context behavior is contradictory.
Payment unknown outcome has no safe state/recovery.
Navigation model cannot preserve tenant/entity context.
Critical forms lack error/focus behavior.
Applicable accessibility requirements have generic wording only.
RTL or mobile behavior changes journey structure but remains undefined.
GOV-009 has blocking experience linkage gaps.
Critical validation blocker remains open.
```

---

# 327. G4A REJECT

Used when:

```text
Product/Requirements baseline is withdrawn or invalidated.
Initiative is cancelled or split.
Experience scope transfers to another product.
Evidence shows the approved delivery channel cannot support the required outcome and upstream rebaseline is required.
```

---

# 328. G4A Evidence Record

```yaml
gate_id: G4A

outcome: PASS_WITH_CONDITIONS

baseline:
  id: EXPERIENCE-BASELINE-1.0
  artifact: EXP-001
  product_baseline: PRODUCT-BASELINE-1.0
  requirements_baseline: REQUIREMENTS-BASELINE-1.0

checks:
  scope_baselines: PASS
  actors_goals_contexts: PASS
  scenarios: PASS
  journeys: PASS
  flows: PASS
  information_architecture: PASS
  navigation_context: PASS
  views_routes: PASS
  ux_states: PASS
  error_recovery: PASS
  interaction_behavior: PASS
  content_messages: PASS
  responsive_cross_platform: PASS
  localization_rtl: PASS
  accessibility: PASS
  security_privacy: PASS
  requirements_traceability: PASS
  validation: PASS
  standards_experience_linkage: PASS
  blocking_questions: PASS
  design_readiness: PASS
  change_governance: PASS

conditions:
  - id: COND-G4A-001
    statement: "Future-release analytics workspace remains outside Release 1 design scope."
    owner: PRODUCT_OWNER
    due_event: BEFORE_FUTURE_RELEASE_ENTERS_PHASE_06

evidence:
  - EXP-001
  - EXP-005
  - EXP-007
  - EXP-008
  - EXP-009
  - EXP-010
  - EXP-015
  - EXP-018
  - EXP-019
  - GOV-008
  - GOV-009

approved_by:
  - PRODUCT_OWNER
  - EXPERIENCE_ARCHITECT
  - REQUIREMENTS_LEAD
  - ACCESSIBILITY_REVIEWER
```

---

# 329. Phase Handoff Contract

Phase 05 handoff must provide:

```text
Experience Baseline ID and Version
Product and Requirements Baseline Versions
Release and Experience Scope
Experience Principles
Actors, Goals, Contexts, and Acting Capacities
Scenario Catalog
Journey Catalog
Flow Catalog / Diagram Index
Information Architecture
Navigation and Context Model
Workspace Model
View / Screen / Route / Entry-Point Inventory
UX State Catalog and Coverage Matrix
Error / Safety / Interruption / Recovery Model
Interaction Behavior Specification
Content / Message Responsibilities and IDs
Responsive / Cross-Platform Rules
Localization / RTL Rules
Accessibility Experience Rules
Security / Privacy Experience Implications
Structural Wireframes / Prototype Scope and Evidence where used
Requirement Experience Dispositions
GOV-009 Experience Links and Phase 06 Obligations
Validation Findings and Evidence
Open Non-Blocking Conditions
Traceability Matrix
Design Priorities
G4A Outcome
Change / Reopen Rules
```

---

# 330. Machine-Readable Handoff — Conceptual

```yaml
phase_handoff:

  from_phase: PHASE-05

  experience_baseline:
    id: EXPERIENCE-BASELINE-1.0
    status: APPROVED
    blueprint: EXP-001
    product_baseline: PRODUCT-BASELINE-1.0
    requirements_baseline: REQUIREMENTS-BASELINE-1.0

  scope:
    release: RELEASE-1
    platforms:
      - WEB
      - MOBILE
    languages:
      - AR
      - EN
    directions:
      - RTL
      - LTR

  models:
    actors_contexts: EXP-003
    scenarios: EXP-004
    journeys: EXP-005
    flows: EXP-006
    information_architecture: EXP-007
    navigation_context: EXP-008
    views_routes: EXP-009
    ux_states: EXP-010
    error_recovery: EXP-011
    interaction_behavior: EXP-012
    content_messages: EXP-013
    responsive_cross_platform: EXP-014
    accessibility: EXP-015
    localization_rtl: EXP-016

  critical_journeys:
    - JRN-AUTH-001
    - JRN-APR-001

  design_subjects:
    views:
      - VIEW-AUTH-SIGNIN
      - VIEW-APR-LIST
      - VIEW-APR-DETAIL
    states:
      - UXS-AUTH-ERROR
      - UXS-APR-UNKNOWN
    interaction_rules:
      - IXR-FORM-001
    content_messages:
      - MSG-AUTH-INVALID-001

  standards:
    applicability_matrix: GOV-009
    experience_linkage: COMPLETE
    accessibility_specification: EXP-015
    localization_rtl_specification: EXP-016
    blocking_gaps: 0

  validation:
    record: EXP-019
    blocking_findings: 0

  traceability:
    matrix: EXP-018
    graph: GOV-008
    requirement_experience_orphans: 0
    experience_object_orphans: 0

  conditions:
    - COND-G4A-001

  open_questions:
    blocking: []
    downstream:
      - OQ-EXP-021

  gate:
    id: G4A
    outcome: PASS_WITH_CONDITIONS

  next_route:
    phase: PHASE-06
    mode: PRODUCT_DESIGN
```

هذا schema conceptual. الـmachine-readable schema النهائي يثبت في schema workstream مع الحفاظ على هذا logical contract.

---

# 331. Canonical Experience Traceability Graph

```text
PRB / OUT / OBJ / POBJ
          ↓
PCAP / PPOL / PSTATE / FEAT / RELEASE
          ↓
FR / NFR / DR / INT / SEC / ACC / AUD
          ↓
UGOAL / SCN / JRN
          ↓
FLOW / FSTEP / XDEC
          ↓
IADOM / NAV / WSPC / DST
          ↓
VIEW / ROUTE / UXS
          ↓
IXR / CNT / MSG / ERR / REC / RSP / AXR / L10N / XCH
          ↓
DESIGN ARTIFACT / COMPONENT / PROTOTYPE
          ↓
IMPLEMENTATION / TEST / EVIDENCE
```

---

# 332. Standards Experience Traceability

```text
STD / PROFILE / CLAUSE
          ↓
        GOV-009
          ↓
BREQ / CTRL / POL / PCAP / PCON / PPOL
          ↓
FR / NFR / DR / INT / SEC / ACC / AUD
          ↓
SCN / JRN / FLOW / VIEW / ROUTE / UXS
          ↓
AXR / IXR / ERR / REC / RSP / L10N / CNT
          ↓
PHASE 06 DESIGN OBLIGATION
          ↓
TEST / EVIDENCE / RELEASE
```

---

# 333. Mandatory Upstream Links

Minimum:

```text
UGOAL → OUT/POBJ/PCAP/FR
SCN → UGOAL + actor/context + requirements
JRN → UGOAL + scenarios + requirements
FLOW → JRN/SCN + requirements/rules/states
VIEW → FLOW/JRN/UGOAL + requirements
ROUTE → VIEW/DST + actor/context requirements
UXS → VIEW/FLOW + requirement/trigger
IXR → requirement + affected flow/view/state
AXR → ACC/GOV-009 + affected objects
ERR/REC → FR/SEC/ACC/INT/NFR as applicable
```

---

# 334. Mandatory Downstream Links

Before Phase 06 completion:

```text
VIEW/UXS → Designed screen/frame/component state
IXR → Interaction/component behavior specification
CNT/MSG → Approved content/design placement
RSP/L10N/AXR → Design variant/evidence
JRN/FLOW → Prototype/test scenario
```

At Phase 05, expected design subject and owner must be explicit.

---

# 335. Bidirectional Traceability

System must answer:

```text
Which requirement created this experience behavior?
Which journey/view/state realizes this requirement?
Which design artifact realizes this experience object?
Which test/evidence proves the journey and requirement?
```

---

# 336. Change Propagation

Example:

```text
FR-APR-014 changes
        ↓
SCN-014 / JRN-006 → REVIEW_REQUIRED
        ↓
FLOW-APR-001 / VIEW-APR-DETAIL / UXS-APR-PENDING → REVIEW_REQUIRED
        ↓
Content / Accessibility / Responsive rules → IMPACT_REVIEW
        ↓
Phase 06 Design / Prototype / Tests → IMPACT_REVIEW
```

---

# 337. Navigation Change Propagation

```text
NAV context rule changes
        ↓
Entry points / Routes / Workspaces reviewed
        ↓
Journeys and deep links reviewed
        ↓
Accessibility focus/order and RTL reviewed
        ↓
Design and implementation reviewed
```

---

# 338. Standards Change Propagation

```text
Standard version or applicability trigger changes
        ↓
GOV-009 → REOPENED
        ↓
Requirements derivation reviewed
        ↓
Experience objects / validation → REVIEW_REQUIRED
        ↓
Design / implementation / test / evidence → IMPACT_REVIEW
```

---

# 339. Experience Change Request

Record:

```text
Requested change
Source/reason
Affected goals/journeys/flows/views/states/rules
Requirements/product impact
Standards/accessibility/security/privacy impact
Responsive/localization impact
Validation impact
Design/implementation/test impact
Release impact
Decision owner
Approval
Baseline version outcome
```

---

# 340. Experience Change Types

```text
EDITORIAL
CONTENT_MEANING
JOURNEY_CHANGE
FLOW_CHANGE
IA_CHANGE
NAVIGATION_CHANGE
CONTEXT_CHANGE
VIEW_ROUTE_CHANGE
STATE_CHANGE
ERROR_RECOVERY_CHANGE
RESPONSIVE_PLATFORM_CHANGE
ACCESSIBILITY_CHANGE
LOCALIZATION_RTL_CHANGE
VALIDATION_FINDING
SCOPE_CHANGE
REQUIREMENT_CHANGE
```

---

# 341. Baseline Impact Rule

After G4A:

```text
No material experience change without GOV-007 record, impact analysis, and version outcome.
```

Experience change cannot silently redefine Product or Requirements Baseline.

---

# 342. Experience Exception

Exception records:

```text
Affected experience object and requirement
Exact scope/context/platform
User impact
Reason
Risk
Alternative/compensating route
Owner/approval
Expiry/review
Evidence
Phase 06/implementation/release visibility
```

---

# 343. Reopening Phase 05

Triggers include:

```text
Requirement change
Product scope/capability/state change
New user/role/acting capacity
New tenant/entity/workspace context
New platform/channel/input mode
New market/language/RTL requirement
New accessibility need or standard version
New generated document
New user-facing third party
New authentication/recovery model
Authorization policy change
Critical navigation/IA change
Offline/sync activation
Error/incident reveals missing recovery
Validation finding invalidates journey/flow
Phase 06 proves structure unworkable
Architecture dependency invalidates experience assumption
Production evidence contradicts baseline
```

---

# 344. Reopen States

```text
EXPERIENCE_REVIEW_REQUIRED
PARTIAL_EXPERIENCE_REBASELINE
FULL_EXPERIENCE_REBASELINE
```

---

# 345. AI Responsibilities

AI MAY:

- analyze Product and Requirements Baselines;
- build requirement experience disposition inventory;
- propose actors, goals, contexts, and scenarios;
- propose journey stages and flows;
- detect missing branches, interruptions, errors, and recovery;
- propose IA/taxonomy/navigation structures;
- derive view/route candidates from flows;
- detect orphan screens and state inflation;
- build UX state coverage;
- propose form/table/search/notification behavior;
- identify ambiguous content responsibility;
- propose message structures and working copy;
- analyze responsive/platform variants;
- analyze localization/RTL implications;
- map ACC requirements to keyboard/focus/semantic/state rules;
- analyze security/privacy experience implications;
- detect dead ends, context loss, and unsafe actions;
- propose structural wireframes and flow prototypes;
- build traceability and coverage matrices;
- analyze `GOV-009` experience obligations;
- propose validation plans and questions;
- draft Experience Baseline and Product Design Handoff.

---

# 346. AI Must Label

AI-generated experience objects use:

```text
PROPOSED
INFERRED
SUPPORTED
VALIDATED
APPROVED
```

AI cannot approve its own proposal or validation interpretation.

---

# 347. AI Prohibitions

AI MUST NOT:

- invent product goal, scope, role, permission, or system behavior;
- invent business rule or state transition;
- promote a screen idea into approved scope;
- use visual trend as experience rationale;
- treat persona as authorization model;
- hide missing behavior behind "standard UX";
- assume happy path is complete journey;
- convert every requirement into a screen;
- convert every state into a separate screen;
- choose navigation because it is common in templates;
- expose sensitive data in error/help/example content;
- weaken security for convenience;
- weaken accessibility because a flow is complex;
- claim accessibility from automated checks alone;
- declare RTL complete by mirroring layout;
- create fake user-research evidence;
- claim validation without participants/method/findings;
- resolve stakeholder conflict silently;
- mark `GOV-009` experience obligations complete without canonical links;
- approve exception/risk;
- choose visual design, tokens, or final component style in Phase 05;
- silently change Product or Requirements Baseline;
- close G4A with blocking gap.

---

# 348. Human Responsibilities

Humans remain responsible for:

```text
User/domain truth
Product intent
Operational context
Journey priority
Experience tradeoffs
Content meaning
Security/privacy interpretation
Accessibility interpretation
Localization/RTL language quality
Risk acceptance
Validation participation and interpretation
Experience approval
G4A approval
```

---

# 349. Experience Architect / UX Lead Responsibility

Responsible for:

```text
Experience model coherence
Actor/goal/context framing
Scenario/journey/flow quality
IA/navigation/context model
View/route/state discipline
Error/recovery completeness
Responsive/cross-platform logic
Accessibility/localization integration
Validation integrity
Traceability
Baseline and handoff
```

---

# 350. Product Owner Responsibility

Confirms:

```text
Goal and journey priority
Product responsibility
Release scope
Experience tradeoffs
Cross-channel responsibility
Design priority
```

---

# 351. Requirements Lead Responsibility

Confirms:

```text
Experience does not change requirement intent
Requirement coverage/disposition
Gaps routed correctly
Acceptance implications preserved
```

---

# 352. Business / Domain Owner Responsibility

Confirms:

```text
Operational reality
Role/acting capacity
Terminology
Process/decision/handoff meaning
Exceptions
Consequences
```

---

# 353. Accessibility Reviewer Responsibility

Confirms:

```text
ACC/GOV-009 coverage
Keyboard and focus paths
Semantic responsibility
Forms/errors/status
Authentication/recovery
Responsive/reflow
Documents/third parties
Validation methods and exceptions
```

---

# 354. Security / Privacy Reviewer Responsibility

Confirms:

```text
Authentication/recovery journey
Authorization visibility
Acting/elevated context
Session/reauthentication
Sensitive data display/share
Consent/notice
Safe errors
Destructive actions
Unknown outcomes
```

---

# 355. Content / Localization Responsibility

Confirms:

```text
Canonical meaning
Action/status/error terminology
Message safety
Translation readiness
RTL/mixed-direction content
Locale formatting
Regulated/legal copy ownership
```

---

# 356. Solution Architect Responsibility

During Phase 05, Architect reviews:

```text
Feasibility-driving journey assumptions
Cross-channel identity/session
Offline/sync
Unknown outcomes
External boundaries
State/concurrency implications
Responsive/platform constraints
Instrumentation implications
```

without replacing experience decisions with technical convenience.

---

# 357. QA / Research Responsibility

Reviews:

```text
Scenario completeness
Observable outcomes
State/error/recovery coverage
Prototype tasks
Validation method
Future testability
Evidence quality
```

---

# 358. Validation Rules

The following apply regardless of P-profile.

---

# 359. VAL-05-001

Every approved Journey must have a user goal, actor, trigger, outcome, and upstream requirement/product linkage.

---

# 360. VAL-05-002

Every critical Journey must cover success, material alternatives, failure/interruption, and recovery.

---

# 361. VAL-05-003

Every critical Flow must include decision/branch sources and must not invent business rules.

---

# 362. VAL-05-004

Every approved View must link to a goal/journey/flow and requirements; orphan views cannot be baselined.

---

# 363. VAL-05-005

A UI state must not create or rename a business/product state without approved source.

---

# 364. VAL-05-006

Every critical view/flow must receive state applicability review; `N/A` requires rationale.

---

# 365. VAL-05-007

Every recoverable error/interruption must provide a safe next step or support/escalation route.

---

# 366. VAL-05-008

Unknown external/transaction outcome must not be represented as success or failure before reconciliation.

---

# 367. VAL-05-009

Experience visibility/hiding/disablement must not be treated as authorization enforcement.

---

# 368. VAL-05-010

Context-changing experience must define visible current context, preservation/reset behavior, permission impact, and unsaved work handling.

---

# 369. VAL-05-011

Every sensitive/destructive action must have risk-proportionate consequence, confirmation/reauthentication/approval, recovery, and audit implications as applicable.

---

# 370. VAL-05-012

Critical form behavior must define modes, required/conditional information, validation timing, errors, preservation, submission, and success/recovery.

---

# 371. VAL-05-013

Content/message responsibility must exist for critical error, pending/unknown, success, and recovery states.

---

# 372. VAL-05-014

Responsive behavior must preserve critical information, actions, context, errors, and accessibility; it cannot silently remove obligations.

---

# 373. VAL-05-015

Platform variants must preserve product meaning and control integrity even when interaction differs.

---

# 374. VAL-05-016

RTL specification must address semantic order, navigation/focus, mixed-direction content, and directional exceptions; mirroring alone is insufficient.

---

# 375. VAL-05-017

Every applicable `ACC` requirement must have experience disposition and Phase 06 design obligation or approved no-design-impact rationale.

---

# 376. VAL-05-018

Keyboard/focus/error/status behavior must be explicit for critical accessible journeys.

---

# 377. VAL-05-019

Third-party user journey must define transition, return, failure/unknown outcome, support, accessibility, and privacy continuity as applicable.

---

# 378. VAL-05-020

Prototype or wireframe is evidence/supporting representation, not authority to change Requirement Baseline.

---

# 379. VAL-05-021

Validation claim must identify method, scope/scenario, participants/reviewers, findings, disposition, and evidence.

---

# 380. VAL-05-022

Every material user-affecting requirement must have experience disposition before G4A.

---

# 381. VAL-05-023

Every `GOV-009` experience obligation must link to canonical EXP objects and Phase 06 derivation obligations.

---

# 382. VAL-05-024

P1 Lean or MVP cannot remove critical error/recovery, security/privacy, accessibility, or control integrity for included journeys.

---

# 383. VAL-05-025

Material experience changes after baseline require change record, impact analysis, and version outcome.

---

# 384. VAL-05-026

G4A cannot pass with blocking experience question, decision, validation finding, requirement gap, or standards linkage gap.

---

# 385. Experience Architecture Anti-Patterns

---

# 386. AP-05-01 — Screen List First

Starting with Login/Dashboard/Profile/Settings before goals, journeys, and flows.

---

# 387. AP-05-02 — Happy-Path Journey

Journey ends at success and ignores interruption, failure, unknown outcome, and recovery.

---

# 388. AP-05-03 — Every Requirement = Screen

Creates screen explosion and destroys task coherence.

---

# 389. AP-05-04 — Every State = Screen

Loading/error/empty become independent screens without lifecycle/context logic.

---

# 390. AP-05-05 — Sitemap = IA

A tree of pages is treated as complete information architecture without taxonomy, mental model, findability, or context.

---

# 391. AP-05-06 — Sidebar by Organization Chart

Navigation mirrors departments instead of user goals and product domains.

---

# 392. AP-05-07 — Dashboard by Default

A dashboard is created because products are expected to have one, with no decision/status need.

---

# 393. AP-05-08 — Modal Everywhere

Complex goals, deep links, or stateful tasks are forced into transient surfaces.

---

# 394. AP-05-09 — Disabled Without Explanation

User sees unavailable action and cannot understand why or how to proceed.

---

# 395. AP-05-10 — Hidden Means Secure

UI concealment is treated as authorization.

---

# 396. AP-05-11 — Generic Error

```text
Something went wrong.
```

with no impact, preservation, or recovery.

---

# 397. AP-05-12 — Retry Everything

Retry is offered for non-idempotent or unknown-outcome action without reconciliation.

---

# 398. AP-05-13 — Confirmation Fatigue

Every small action gets a modal, so users stop reading high-risk confirmations.

---

# 399. AP-05-14 — Admin Bypass Experience

Generic admin path ignores role, acting capacity, control, and audit.

---

# 400. AP-05-15 — Desktop Shrink

Responsive design is reduced to smaller width without prioritizing task, content, navigation, state, or input mode.

---

# 401. AP-05-16 — Identical Cross-Platform UI

Consistency is interpreted as identical interaction despite platform conventions and constraints.

---

# 402. AP-05-17 — RTL Mirror Button

RTL is considered complete after flipping layout while reading order, focus, mixed content, numbers, icons, and charts remain wrong.

---

# 403. AP-05-18 — Accessibility Footer

`Must be accessible` appears at end without journey/view/state/focus/keyboard/error mappings.

---

# 404. AP-05-19 — Automated Accessibility Proof

Automated scan is treated as proof of complete accessible experience.

---

# 405. AP-05-20 — Persona Permission Model

Persona description determines access instead of approved roles/authorization requirements.

---

# 406. AP-05-21 — Prototype Becomes Requirement

Stakeholders approve a click path and unmodeled behavior silently becomes scope.

---

# 407. AP-05-22 — Existing UI Worship

Legacy screen is retained because it exists, despite contradicting requirements or user goals.

---

# 408. AP-05-23 — Copy as Decoration

Critical messages are lorem ipsum until the end, hiding safety, localization, and error logic gaps.

---

# 409. AP-05-24 — Fake Validation

Team walkthrough is labeled user research or usability validation without method and evidence.

---

# 410. AP-05-25 — Design Leakage

Phase 05 spends time selecting colors, shadows, typography, and component aesthetics before journeys/states are stable.

---

# 411. AP-05-26 — Architecture Leakage

Flows assume specific API/database/queue implementation instead of experience outcome.

---

# 412. AP-05-27 — Standards Deferred to Design

GOV-009 obligations have no experience links and the design team is told to "handle accessibility/security later."

---

# 413. Phase Quality Measures

Product OS may track:

```text
Requirement Experience Disposition Coverage
Goal-to-Journey Coverage
Critical Journey Completion Coverage
Journey Error/Recovery Coverage
Flow Branch Coverage
View Orphan Rate
Experience Object Orphan Rate
State Coverage
Dead-End State Count
Permission Experience Coverage
Context-Loss Finding Rate
Responsive Variant Coverage
Localization / RTL Coverage
ACC-to-Experience Coverage
GOV-009 Experience Linkage Coverage
Critical Content/Message Coverage
Validation Coverage
Validation Finding Closure Rate
Design Clarification Rate
Experience Baseline Reopen Rate
Downstream Journey Defect Rate
Accessibility Defect Escape Rate
```

---

# 414. Important Metric — Design Invention Rate

```text
DESIGN INVENTION RATE
```

> How often must Phase 06 invent journey, state, navigation, content meaning, or interaction behavior because Phase 05 did not define it?

---

# 415. Important Metric — Dead-End Rate

```text
DEAD_END EXPERIENCE RATE
```

Number of material error/permission/conflict/offline states without valid next action or support route.

Target before G4A PASS:

```text
0 blocking dead ends
```

---

# 416. Important Metric — Journey Requirement Coverage

```text
CRITICAL USER-AFFECTING REQUIREMENTS WITH JOURNEY/STATE DISPOSITION
÷
TOTAL CRITICAL USER-AFFECTING REQUIREMENTS
```

---

# 417. Important Metric — Experience Accessibility Gap

```text
APPLICABLE ACC OBLIGATION WITHOUT EXPERIENCE + DESIGN DERIVATION CHAIN
```

Target:

```text
0 blocking gaps
```

---

# 418. Experience Completion Contract

Phase 05 is complete only when the following contract is satisfied.

---

# 419. Required Inputs

```text
G3A-approved Product Baseline
G3B-approved Requirements Baseline
Product Scope / Boundary / Roles / Capabilities / States / Platforms / Release
FR / NFR / DR / INT / SEC / ACC / AUD
Acceptance Criteria and Verification Intent
Risks / Assumptions / Decisions / Open Questions
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated Conditional Profiles
Phase 05 Experience Allocations from Requirements Handoff
Existing Experience Evidence where applicable
```

---

# 420. Required Questions

Phase 05 must answer:

```text
Who is trying to achieve what goal, in which context and acting capacity?

What scenarios materially change the experience?

What is the complete journey from trigger to success, safe failure, interruption, or recovery?

Which actors, systems, channels, and handoffs participate?

What flows, decisions, branches, loops, and state transitions occur?

How are product concepts and destinations organized?

How does the user know where they are and which context/entity/role is active?

Which workspaces, views, screen candidates, routes, and entry points exist?

Which loading, empty, partial, error, permission, conflict, offline, processing, unknown-outcome, success, and interruption states apply?

How does each critical error or interruption recover without a dead end?

How do forms, tables, search, filters, bulk actions, notifications, and background work behave?

What content/messages are required, who owns their meaning, and which variants apply?

How does the experience adapt across platforms, widths, orientations, and input modes?

How do language, RTL/LTR, mixed-direction content, locale formatting, search/sort, and content expansion behave?

How do keyboard, focus, semantics, forms/errors/status, reflow, motion, documents, and third parties satisfy applicable accessibility requirements?

How are authentication, authorization visibility, session, reauthentication, sensitive data, consent, destructive actions, and safe errors represented?

Which structural wireframes/prototypes are needed to validate uncertainty?

What validation evidence supports the experience model?

Which requirements have no experience impact and why?

Which `GOV-009` entries map to which EXP objects and Phase 06 obligations?

What changes reopen the Experience Baseline?
```

---

# 421. Required Decisions

At minimum:

```text
Experience Scope and Principles
Actor / Goal / Context Baseline
Scenario Baseline
Journey Baseline
Flow Baseline
Information Architecture Baseline
Navigation and Context Baseline
Workspace / Destination Baseline
View / Screen / Route / Entry-Point Baseline
UX State Baseline
Error / Safety / Interruption / Recovery Baseline
Interaction Behavior Baseline
Content / Message Responsibility Baseline
Responsive / Cross-Platform Baseline
Localization / RTL Baseline
Accessibility Experience Baseline
Security / Privacy Experience Disposition
Structural Validation Scope
Requirement Experience Disposition
GOV-009 Experience Update
Experience Baseline Version
G4A Outcome
Product Design Handoff
```

---

# 422. Exit Criteria

Phase 05 complete when:

1. Experience scope, releases, platforms/channels, markets/languages, and source baselines are explicit.
2. Experience principles, actors, goals, contexts, and acting capacities are defined.
3. Material scenarios and variants are modeled.
4. Critical goals have end-to-end journeys.
5. Critical journeys include success, alternative, failure, interruption, and recovery.
6. Critical flows include decisions, branches, states, and exits.
7. Information Architecture and terminology are coherent.
8. Navigation, workspaces, context switching/persistence, entry/deep links, and return behavior are defined.
9. Required views/screens/routes are inventoried with no blocking orphans.
10. Critical views/flows have applicable UX states.
11. Critical errors, unknown outcomes, sensitive actions, interruptions, and recovery avoid dead ends.
12. Forms/data-dense/search/notification/background interaction rules are defined where applicable.
13. Critical content/message meaning and ownership are explicit.
14. Responsive/cross-platform/input-mode behavior is defined.
15. Localization/RTL/mixed-direction/locale-formatting behavior is defined.
16. Applicable accessibility requirements map to experience rules and Phase 06 obligations.
17. Security/privacy experience implications are covered.
18. Third-party/document/cross-channel continuity is covered where applicable.
19. Material user-affecting requirements have experience disposition.
20. Requirement-to-experience and experience-to-design traceability is operational.
21. Applicable `GOV-009` entries link to canonical EXP objects, validation expectations, and Phase 06 obligations.
22. Critical experience uncertainty has been validated at selected depth.
23. Blocking findings, questions, decisions, requirement gaps, dead ends, and standards linkage gaps = 0.
24. Experience Baseline is versioned and approved.
25. G4A evaluated with all required checks.
26. Product Design Handoff generated.

---

# 423. Final Transformation

Phase 05 transforms:

```text
APPROVED PRODUCT BASELINE
+
APPROVED REQUIREMENTS BASELINE
+
STANDARDS-LINKED EXPERIENCE OBLIGATIONS
```

into:

```text
EXPERIENCE PRINCIPLES
+
ACTORS / GOALS / CONTEXTS / SCENARIOS
+
END-TO-END JOURNEYS
+
FLOWS / DECISIONS / BRANCHES / HANDOFFS
+
INFORMATION ARCHITECTURE
+
NAVIGATION / CONTEXT / WORKSPACES
+
VIEWS / SCREENS / ROUTES / ENTRY POINTS
+
UX STATES
+
ERROR / SAFETY / INTERRUPTION / RECOVERY
+
INTERACTION AND CONTENT RULES
+
RESPONSIVE / CROSS-PLATFORM
+
ACCESSIBILITY / LOCALIZATION / RTL
+
VALIDATION EVIDENCE
+
GOV-009 EXPERIENCE LINKS
+
VERSIONED EXPERIENCE BASELINE
```

---

# 424. Final Methodology Principle

```text
Experience Architecture must decide how users understand,
navigate, complete, fail, recover, and continue their goals
before Product Design decides how the interface will look
and how components will visually realize that behavior.
```

---

# 425. Phase 05 Output

```text
APPROVED REQUIREMENTS BASELINE
        ↓
EXPERIENCE ARCHITECTURE
        ↓
COHERENT JOURNEYS + FLOWS + IA + NAVIGATION + STATES
        ↓
ACCESSIBLE + RESPONSIVE + RECOVERABLE EXPERIENCE BASELINE
        ↓
G4A — EXPERIENCE BASELINE
        ↓
PRODUCT DESIGN
```

**Phase 00 ensured we entered the correct project.**

**Phase 01 ensured we understood the correct problem.**

**Phase 02 ensured the business logic was defined.**

**Phase 03 ensured the product responsibility and scope were defined.**

**Phase 04 ensured system behavior and quality obligations were precise and verifiable.**

**Phase 05 ensures the complete experience logic is coherent, accessible, safe, and ready to be designed without invention.**
