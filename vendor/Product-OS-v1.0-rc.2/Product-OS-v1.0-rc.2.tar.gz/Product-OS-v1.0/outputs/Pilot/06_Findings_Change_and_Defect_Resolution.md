# Product OS v1.0 — Pilot Findings, Change, and Defect Resolution

~~~yaml
document_id: FRAMEWORK-PILOT-FINDINGS-CHANGE
version: 0.1.0
status: WORKING_DRAFT
retained_failed_run: PILOT-RUN-001
passing_rerun: PILOT-RUN-002
pilot_defect_count: 1
open_blocking_defect_count: 0
~~~

# 1. Finding PILOT-FND-001

**Title:** Init existing-target collision returned conformance exit instead of blocked-action exit.

**Detected by:** `NEG-001` in `PILOT-RUN-001`.

**Expected:** exit 4 and structured `ACTION_BLOCKED` error.

**Observed:** exit 1 and normal `FAIL` report with SRV-078.

**Safety outcome:** no overwrite occurred and all nine existing control files remained intact.

# 2. Root Cause

`init` detected existing planned files and added an error finding before apply. The shared command contract and exit catalog classified an attempted apply over governed output as an action blocked by safety preconditions. Implementation safety was correct, but its external failure class was inconsistent with the command contract.

# 3. Materiality

The issue did not cause data loss, overwrite, authority expansion, or secret exposure. It was nevertheless blocking for pilot closure because callers use exit classes to distinguish content conformance from a prohibited mutation. CI/orchestration could route remediation incorrectly.

# 4. Correction

For `--apply`, existing governed init targets now raise `ActionBlockedError`, producing exit 4 and the structured error envelope. A dry-run over an existing target remains a normal conformance report because it performs no mutation and communicates planning conflict.

# 5. Regression

The existing init integration test now asserts that reapply throws `ACTION_BLOCKED` with exit 4. The full Automation suite passed 14/14 after the change.

# 6. Rerun Evidence

`PILOT-RUN-002` reran all 35 cases, not only NEG-001. NEG-001 returned exit 4/ERROR and all other cases retained their expected behavior. Result: 35/35 cases and 20/20 criteria.

# 7. Retention and Status

Run-001 remains immutable evidence of detection. Run-002 is a separate candidate. The finding is `RESOLVED_TECHNICALLY`, not erased. Product OS final review must include the change in compatibility/release notes.

# 8. No Hidden Findings

The Run-001 cold-start observations—approximately 71 seconds for the first process and 16.8 seconds for the first all-scope framework validation—did not reproduce in Run-002, where the maximum case was 59.388 ms. They are classified as local execution-environment observations, not a repeatable command performance defect. Final release should avoid promising a performance SLO from this single environment.
