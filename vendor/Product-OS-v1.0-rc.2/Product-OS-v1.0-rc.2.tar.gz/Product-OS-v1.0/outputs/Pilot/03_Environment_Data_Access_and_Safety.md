# Product OS v1.0 — Pilot Environment, Data, Access, and Safety

~~~yaml
document_id: FRAMEWORK-PILOT-ENVIRONMENT-SAFETY
version: 0.1.0
status: WORKING_DRAFT
environment: LOCAL_ISOLATED_SYNTHETIC
production_access: false
production_data: false
external_network_required: false
~~~

# 1. Environment

The pilot runs inside a local Product OS output workspace using Node.js and the checked-in framework/command sources. Each run receives a new directory under `Pilot/runs/`. Project workspaces, command evidence, and manifests remain inside that run root.

# 2. Data Classification

All scenario, requirement, trace, gate, baseline, handoff, migration, and archive content is synthetic. No personal data, credentials, client names, live repository tokens, regulated records, payment data, or production configuration is used.

Fixture names such as “regulated” test applicability and safety behavior; they do not contain regulated data and do not establish domain compliance.

# 3. Access Model

- Read access: current Product OS outputs and local synthetic run inputs.
- Write access: new pilot run root only, plus the governed Automation fix made after Run-001.
- Network access: not required by command execution.
- Remote/native tools: not connected or mutated.
- Product OS approval authority: absent from execution context.

# 4. Filesystem Safety

- Run IDs match `PILOT-RUN-NNN`.
- Existing run roots are rejected and never overwritten.
- Each synthetic project is initialized in an empty contained directory.
- Migration and archive target new contained roots.
- Negative collision tests verify fail-closed behavior.
- Source preservation is asserted after migration/archive operations.
- Evidence is written once per case and content-manifested.

# 5. Secret and Privacy Controls

Lint cases assert `secret_values_emitted: false`. The runner passes no secrets as options. Evidence retains local path observations because they are necessary to reproduce the run; they remain local internal pilot evidence and are not a public distribution artifact.

# 6. Retention

Run-001 and Run-002 are both retained through Product OS v1.0 final review. Run-001 is required defect evidence. Disposal, publication, or relocation after finalization requires an explicit evidence/retention decision; the pilot runner performs none.

# 7. Prohibited Actions

- production or client-system access;
- external messages or approvals;
- repository pushes, deployments, cloud changes, or database writes;
- source deletion, canonical migration cutover, or archive-based disposal;
- editing prior run evidence;
- treating synthetic authorities as real authorities.

# 8. Incident Rule

If unauthorized data or access is observed, execution stops, the exact affected evidence scope is isolated, exposure is not copied into normal reports, and the incident is routed through the AI/security/evidence governance contracts. No such incident occurred in either retained run.
