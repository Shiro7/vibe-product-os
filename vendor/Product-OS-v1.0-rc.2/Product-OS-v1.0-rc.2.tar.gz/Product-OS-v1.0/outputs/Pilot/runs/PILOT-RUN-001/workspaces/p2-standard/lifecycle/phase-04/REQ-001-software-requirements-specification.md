# P2 Synthetic Requirements

REQ-FR-P2-001 requires a bilingual booking submission with keyboard, screen-reader, RTL, and LTR support.
