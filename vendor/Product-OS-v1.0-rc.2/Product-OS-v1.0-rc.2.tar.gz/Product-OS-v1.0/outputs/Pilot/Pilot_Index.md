# Product OS v1.0 — Pilot Index

~~~yaml
document_id: FRAMEWORK-PILOT-INDEX
version: 0.1.0
status: WORKING_DRAFT
completion_state: SYNTHETIC_REFERENCE_PILOT_COMPLETE
pilot_result: TECHNICAL_PASS
pilot_type: SYNTHETIC_REFERENCE_PILOT
scenario_count: 3
profile_coverage: [P1, P2, P3]
command_count: 12
normative_document_count: 10
machine_catalog_count: 3
script_count: 2
package_file_count: 191
case_count: 35
case_pass_count: 35
negative_case_count: 9
acceptance_criterion_count: 20
acceptance_criterion_pass_count: 20
passing_evidence_manifest_entry_count: 37
passing_run: PILOT-RUN-002
retained_failed_run: PILOT-RUN-001
production_access: false
production_data: false
project_artifact_count_impact: NONE
next_workstream: Product OS v1.0 Final Authority Decision
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-15
~~~

---

# 1. Purpose

This pilot tests whether the completed Product OS framework can be instantiated and operated—not merely read. It executes the public Automation / Commands CLI across P1, P2, and P3 synthetic workspaces, retains full evidence for expected success and expected failure, and checks that automation remains bounded by human authority.

The pilot does not use client, personal, regulated, credential, production, or live native-tool data. Synthetic facts are test vectors and must not be reused as project decisions.

# 2. Pilot Outcome

`PILOT-RUN-002` achieved:

- three scenarios and all three profiles;
- all twelve canonical commands;
- 35 of 35 cases matching expected exit and result;
- 26 positive/expected-warning cases;
- nine negative safety/conformance cases;
- 20 of 20 blocking acceptance criteria;
- 37 SHA-256-manifested evidence objects plus the manifest;
- no Product OS approval, baseline, production access, or authority effect.

`PILOT-RUN-001` is retained because its 34/35 result exposed a real exit-semantics drift in `init`. The implementation was corrected, its 14 integration tests passed, and the pilot was rerun in a new immutable run root.

# 3. Library Map

| No. | Document | Responsibility |
|---:|---|---|
| 00 | [Shared Pilot Contract](00_Shared_Pilot_Contract.md) | Universal pilot invariants, inputs, execution, evidence, change, and closure |
| 01 | [Charter, Scope, Governance, and Authority](01_Pilot_Charter_Scope_Governance_and_Authority.md) | Objective, boundaries, roles, decisions, success, stop, and non-claims |
| 02 | [Scenario Portfolio and Profile Coverage](02_Scenario_Portfolio_and_Profile_Coverage.md) | P1/P2/P3 scenarios, applicability, command allocation, and coverage |
| 03 | [Environment, Data, Access, and Safety](03_Environment_Data_Access_and_Safety.md) | Synthetic environment, isolation, permissions, retention, and prohibited access |
| 04 | [Execution Protocol, Cases, and Runbook](04_Execution_Protocol_Cases_and_Runbook.md) | Reproducible runner, ordering, expected results, rerun, and recovery |
| 05 | [Evidence, Measurement, and Acceptance](05_Evidence_Measurement_and_Acceptance.md) | Evidence anatomy, manifest, metrics, 20 criteria, and authority handling |
| 06 | [Findings, Change, and Defect Resolution](06_Findings_Change_and_Defect_Resolution.md) | Run-001 defect, root cause, fix, regression, and retained evidence |
| 07 | [Adoption, Rollout, and v1 Readiness](07_Adoption_Rollout_and_v1_Readiness.md) | What the pilot proves, remaining organizational validation, and finalization route |
| Closure | [Coverage and Closure Review](Pilot_Coverage_and_Closure_Review.md) | Exact inventories, run evidence, criterion results, limitations, and closure decision |

# 4. Machine and Executable Assets

- [`config/pilot-catalog.json`](config/pilot-catalog.json): three scenario contracts.
- [`config/test-case-catalog.json`](config/test-case-catalog.json): 35 ordered cases and expected outcomes.
- [`config/acceptance-criteria.json`](config/acceptance-criteria.json): 20 blocking acceptance criteria.
- [`scripts/run-pilot.js`](scripts/run-pilot.js): dependency-free black-box pilot runner.
- [`scripts/audit-pilot.js`](scripts/audit-pilot.js): catalogs, evidence, digest, coverage, and closure audit.
- [`runs/PILOT-RUN-001/`](runs/PILOT-RUN-001/): retained technical-fail evidence.
- [`runs/PILOT-RUN-002/`](runs/PILOT-RUN-002/): passing candidate evidence and synthetic workspaces.

# 5. Proven Execution Chain

~~~text
framework + schemas + catalogs + command package
  → P1/P2/P3 init
  → validate / lint / reconcile / doctor
  → graph / impact / gate / baseline / handoff
  → migrate / archive
  → negative controls
  → per-case evidence
  → SHA-256 evidence manifest
  → 20 acceptance criteria
  → technical pilot decision
~~~

# 6. Authority Boundary

The pilot can prove that bounded commands behave as specified for these exact synthetic inputs. It cannot approve Product OS v1.0, establish its baseline, accept residual framework risk, prove organizational adoption, prove all domain profiles, or authorize any project, release, deployment, or production system.

# 7. Next Workstream

The [Product OS v1.0 Final package](../Product_OS_v1.0_Final/Product_OS_v1.0_Final_Index.md) reconciles the Working Draft libraries, retained pilot defect, compatibility, release packaging, baseline candidate, distribution integrity, and authority-decision inputs. The next action is the Product OS authority decision, which may approve, condition, require a real-project pilot, hold, or reject the exact release-candidate bytes.

# 8. Final Principle

> **The pilot proves the Product OS can execute, detect its own contract drift, preserve failed evidence, recover by governed change, and rerun cleanly—without granting itself approval.**
