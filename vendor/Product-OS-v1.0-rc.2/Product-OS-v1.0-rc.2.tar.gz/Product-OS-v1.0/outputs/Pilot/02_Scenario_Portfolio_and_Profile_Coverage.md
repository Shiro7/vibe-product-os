# Product OS v1.0 — Pilot Scenario Portfolio and Profile Coverage

~~~yaml
document_id: FRAMEWORK-PILOT-SCENARIO-PORTFOLIO
version: 0.1.0
status: WORKING_DRAFT
scenario_count: 3
profiles: [P1, P2, P3]
catalog_ref: config/pilot-catalog.json
~~~

# 1. Portfolio Design

The scenarios use one stable Product OS structure with profile-specific physical depth. They do not create different methodologies or artifact IDs.

# 2. P1 — Rapid Status Service

- Low-risk internal web API.
- English-only synthetic context.
- P1 composite critical-chain packaging.
- Commands: init, doctor, validate, reconcile, lint.
- Cases: dry-run, apply, strict readiness, five control files, canonical framework counts, secret-safe lint.
- Success: nine-file operational control plane; no creation of 281 files.

P1 verifies minimum governance without pretending that low risk removes applicable authority or evidence duties.

# 3. P2 — Bilingual Service Booking

- Medium-risk web/mobile/generated-document context.
- Arabic RTL and English LTR applicability.
- WCAG 2.2 AA, mobile, and generated-document triggers.
- P2 modular standard packaging.
- Commands: init, validate, graph, impact, gate, baseline, handoff.
- Positive evidence: resolved trace, one downstream impact candidate, partial gate warning, acknowledged handoff, digest-correct baseline.
- Negative evidence: digest-mismatched baseline fails.

P2 verifies cross-cutting applicability can exist without changing the shared command authority model.

# 4. P3 — Regulated Benefits Administration

- High-risk synthetic enterprise/regulated-data context.
- Web, mobile, admin, API, and generated-document surfaces.
- Audit, accessibility, retention, and recovery triggers.
- P3 independent assurance package treatment.
- Commands: init, validate, reconcile, graph, impact, gate, handoff, doctor, lint, migrate, archive.
- Positive evidence: all 15 G0 check slots, strict diagnostics, staged JSON migration, verified additive archive.
- Negative evidence: existing init/archive target, missing impact start, broken graph endpoint, missing gate evidence, acknowledged blocked handoff, wrong migration digest, duplicate YAML key.

# 5. Command Coverage Matrix

| Command | P1 | P2 | P3 | Negative case |
|---|:---:|:---:|:---:|:---:|
| init | yes | yes | yes | existing governed target |
| validate | yes | yes | yes | duplicate YAML key |
| lint | yes | no | yes | secret non-emission asserted |
| reconcile | yes | no | yes | canonical counts asserted |
| graph | no | yes | yes | missing endpoint |
| impact | no | yes | yes | unresolved start |
| gate | no | partial | complete | positive check without evidence |
| baseline | no | yes | no | wrong digest |
| handoff | no | yes | yes | acknowledged with blocker |
| migrate | no | no | yes | wrong source digest |
| archive | no | no | yes | existing output root |
| doctor | yes | no | yes | strict control count |

# 6. Coverage Limits

This portfolio covers the horizontal operating model and representative risk/profile depth. It does not prove every industry conditional profile, every native integration, every gate, all 281 artifact bodies, or production-scale performance. Final authority may require an additional real-project or regulated-domain pilot.

# 7. Acceptance

Portfolio coverage passes when all three profile manifests declare the requested profiles, the command union is exactly 12, the logical catalog remains 281, and profile differences do not alter status, applicability, authority, or evidence semantics.
