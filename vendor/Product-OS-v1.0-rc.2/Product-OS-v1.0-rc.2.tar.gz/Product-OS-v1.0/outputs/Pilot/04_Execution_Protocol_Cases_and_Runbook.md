# Product OS v1.0 — Pilot Execution Protocol, Cases, and Runbook

~~~yaml
document_id: FRAMEWORK-PILOT-EXECUTION-PROTOCOL
version: 0.1.0
status: WORKING_DRAFT
runner_ref: scripts/run-pilot.js
case_catalog_ref: config/test-case-catalog.json
case_count: 35
~~~

# 1. Preflight

1. Verify Node.js 18 or later.
2. Verify Automation / Commands and Schemas & Repository Standard paths.
3. Run the 14 Automation integration tests.
4. Confirm the intended run root does not exist.
5. Confirm scenario, case, and acceptance catalogs parse and declare 3/35/20.
6. Confirm no production credentials, data, or remote write requirement.

# 2. Invocation

~~~bash
node outputs/Pilot/scripts/run-pilot.js --run-id PILOT-RUN-002
node outputs/Pilot/scripts/audit-pilot.js --run-id PILOT-RUN-002
~~~

The runner rejects an existing run ID. A rerun uses a new ID; it never removes or rewrites the prior run.

# 3. Execution Order

## 3.1 P1

Dry-run init, apply init, strict doctor, project validation, full reconciliation, and lint.

## 3.2 P2

Apply init; create synthetic requirement/graph/gate/handoff/baseline fixtures; validate all; graph; impact; partial gate; handoff; valid baseline; invalid baseline.

## 3.3 P3

Apply init; create graph/gate/handoff/migration/archive fixtures; validate/reconcile; graph/impact; complete gate; handoff; doctor/lint; migration dry-run/apply; archive dry-run/apply; then run nine negative cases.

# 4. Expected Result Semantics

| Kind | Pilot pass condition |
|---|---|
| `POSITIVE` | exit 0 and `PASS` |
| `POSITIVE_DRY_RUN` | exit 0, `PASS`, intended output absent |
| `POSITIVE_APPLY` | exit 0, `PASS`, exact bounded output present |
| `EXPECTED_WARNING` | exit 0 and `PASS_WITH_WARNINGS` for the intended warning |
| `NEGATIVE_CONFORMANCE` | exit 1 and `FAIL` with the intended rule evidence |
| `NEGATIVE_ACTION_BLOCKED` | exit 4 and structured `ERROR` with source/target preserved |

A negative case returning exit 0 is a pilot failure. A negative case failing for an unrelated reason is also a pilot failure.

# 5. Case Evidence

The runner invokes the public `product-os` CLI with `--json`, parses stdout or structured stderr, applies base exit/result assertions plus case-specific assertions, and writes one JSON record under `evidence/commands/<case-id>.json`.

# 6. Mutation Checks

- Init dry-run: no `product-os.yaml`.
- Init apply: exactly nine control files.
- Init collision: exit 4 and existing controls remain.
- Migration dry-run: no staging root.
- Migration apply: exact transformed JSON, manifest, no cutover/delete/overwrite.
- Bad migration digest: exit 1 and no bad staging root.
- Archive dry-run: no archive root.
- Archive apply: two source files retained, manifest and objects present.
- Existing archive output: exit 4 and archive/source remain.

# 7. Failure Procedure

1. Complete the current case evidence when safe.
2. Do not edit the failed evidence or expected result.
3. Mark run summary technical fail.
4. Identify violated contract and owning workstream.
5. Correct specification, implementation, and regression test as required.
6. Run the owning test suite.
7. use a new run ID for the full pilot; do not rerun only the failed case for closure.

# 8. Completion

After all cases, the runner evaluates 20 criteria, writes the run report and acceptance results, builds one SHA-256 evidence manifest excluding only itself, verifies the manifest, and exits nonzero unless the technical result is PASS.
