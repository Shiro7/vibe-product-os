# Product OS v1.0 — Shared Pilot Contract

~~~yaml
contract_id: SHARED-PILOT-CONTRACT
version: 0.1.0
status: WORKING_DRAFT
applies_to: ALL_PRODUCT_OS_PILOT_SCENARIOS_AND_RUNS
pilot_authority_effect: NONE
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
~~~

# 1. Purpose

Every Product OS pilot scenario inherits this contract. A pilot may narrow its scope or add domain-specific controls, but it may not weaken identity, input isolation, expected-result declaration, evidence completeness, negative testing, authority separation, change control, or retained-failure requirements.

# 2. Required Pilot Anatomy

Every pilot defines:

1. immutable pilot and scenario IDs;
2. objective and explicit non-objectives;
3. Product OS/framework/command/schema/catalog versions;
4. profiles and applicability triggers exercised;
5. environment, repositories, data classes, access, and prohibited systems;
6. ordered cases with command, input, expected exit, expected result, and assertions;
7. positive, warning, negative, mutation, authority, and recovery coverage;
8. blocking acceptance and stop criteria;
9. evidence paths, digests, retention, and owner;
10. finding, fix, regression, rerun, closure, and escalation rules.

# 3. Input Contract

- Scenario facts are synthetic or explicitly authorized project facts.
- Every run pins exact framework and command sources.
- Expected results are cataloged before execution.
- Credentials and production data are prohibited unless a later pilot is separately authorized.
- A run uses a new root and cannot overwrite an earlier run.
- Native-tool or operational claims require direct evidence from the owning system; they are not fabricated for this reference pilot.

# 4. Execution Contract

- Public CLI execution is required for end-to-end cases.
- P1/P2/P3 retain identical logical artifact IDs and authority semantics.
- Mutating commands run dry-run before apply where the scenario includes apply.
- Negative cases must fail for the intended rule or safety reason.
- Unexpected success is a pilot failure, not a convenience.
- Unexpected failure is retained and investigated before a new run.
- A corrected implementation is regression-tested before pilot rerun.

# 5. Evidence Contract

Every case evidence record contains scenario/case/command identity, purpose, invocation, start/finish, duration, expected/observed exit, expected/observed result, assertions, pass state, full command payload, and approval claim. Evidence output is JSON, immutable within its retained run, and included in a SHA-256 manifest.

# 6. Success Contract

Technical pilot success requires:

- all cataloged cases match expected behavior;
- all blocking acceptance criteria pass;
- all canonical commands and selected profiles are covered;
- no authority or safety invariant is violated;
- the evidence manifest verifies;
- every discovered defect has a retained failing run, root cause, governed fix, regression result, and passing rerun;
- limitations and remaining organizational validation are explicit.

# 7. Stop Conditions

Stop and retain evidence when:

- production or unauthorized data/access is encountered;
- a command overwrites, deletes, cuts over, or escapes scope;
- a secret value is emitted;
- expected negative behavior succeeds;
- a gate, no-impact, acknowledgement, compliance, release, or baseline authority is falsely claimed;
- evidence cannot be parsed, retained, or verified;
- framework/command identity changes during a run;
- a blocking criterion fails.

# 8. Change and Rerun

A failed run is never rewritten to green. Corrective work uses Change Impact Rules, updates the implementation/specification/test where required, runs the owning regression suite, and creates a new run ID. The earlier run remains an immutable part of pilot evidence.

# 9. Decision Boundary

`TECHNICAL_PASS` means the declared pilot cases and criteria passed. It does not mean Product OS approval, baseline, domain certification, organizational rollout approval, or fitness for every project. Those require their accountable authorities and any additional evidence they require.

# 10. Acceptance

This contract is satisfied when scenarios, cases, criteria, runner, evidence, retained failures, rerun, and closure review all reconcile exactly and the final record states `authority_effect: NONE`.
