# Product OS v1.0 — Pilot Evidence, Measurement, and Acceptance

~~~yaml
document_id: FRAMEWORK-PILOT-EVIDENCE-MEASUREMENT
version: 0.1.0
status: WORKING_DRAFT
acceptance_catalog_ref: config/acceptance-criteria.json
criterion_count: 20
passing_run_manifest_entries: 37
hash_algorithm: sha256
~~~

# 1. Evidence Layers

1. **Definition evidence:** three versioned machine catalogs.
2. **Execution evidence:** one complete JSON record per case.
3. **Workspace evidence:** exact P1/P2/P3 control planes and synthetic inputs/outputs.
4. **Acceptance evidence:** deterministic result for every PAC criterion.
5. **Run evidence:** summary, coverage, duration, technical result, and non-claims.
6. **Integrity evidence:** SHA-256 manifest for every retained evidence object except the manifest itself.
7. **Change evidence:** failed run, defect analysis, implementation/test change, and passing rerun.

# 2. Passing Run Metrics

| Metric | PILOT-RUN-002 |
|---|---:|
| Scenarios | 3 |
| Profiles | 3 |
| Commands | 12 |
| Cases | 35 |
| Case pass | 35 |
| Positive/expected-warning | 26 |
| Negative | 9 |
| Acceptance criteria | 20 |
| Acceptance pass | 20 |
| Command execution duration | 1,361.132 ms |
| Maximum case duration | 59.388 ms |
| Manifested evidence objects | 37 |

Durations cover child CLI executions in Run-002 on the local environment. They are observations, not cross-platform service-level guarantees.

# 3. Acceptance Groups

- PAC-001..004: profile, command, positive, and negative coverage.
- PAC-005..009: authority and mutation safety.
- PAC-010..011: canonical catalog/schema/framework integrity.
- PAC-012..016: graph, impact, gate, baseline, and handoff behavior.
- PAC-017..019: serialization/secret evidence and evidence integrity.
- PAC-020: technical-only closure and pending authority.

All 20 are blocking for this pilot. No weighted score can hide a failed authority or safety criterion.

# 4. Evidence Manifest

The passing manifest covers 35 command records, `acceptance-results.json`, and `pilot-run-report.json`. Each entry records relative path, byte size, and SHA-256. The manifest excludes itself to avoid recursive identity and is independently rehashed by the audit script.

# 5. Freshness and Reuse

Evidence applies only to the recorded Automation, framework, schema/catalog, Node, fixture, and runner inputs. Any semantic command change, schema/catalog change, case/criterion change, profile rule change, or authority-boundary change requires impact review and at least targeted regression; final release may require a full new pilot run.

# 6. Acceptance Authority

The runner deterministically evaluates criteria and may produce `TECHNICAL_PASS`. The Product OS authority reviews whether the evidence is sufficient for v1.0 finalization, whether limitations are acceptable, and whether a real project/domain pilot is required. The evidence does not decide those questions.

# 7. Evidence Quality Rules

- retain full payload, not only a pass label;
- never remove a failed run;
- distinguish expected negative failure from infrastructure failure;
- preserve secret redaction;
- record exact expected and actual values;
- content-hash evidence before closure;
- link correction to its failing evidence;
- keep synthetic decision/authority fixtures visibly non-authoritative.
