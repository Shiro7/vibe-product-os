#!/usr/bin/env node
'use strict';

const assert = require('assert');
const childProcess = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const pilotRoot = path.resolve(__dirname, '..');
const outputsRoot = path.resolve(pilotRoot, '..');
const automationRoot = path.join(outputsRoot, 'Automation_Commands');
const frameworkRoot = path.join(outputsRoot, 'Schemas_Repository_Standard');
const cliFile = path.join(automationRoot, 'bin/product-os.js');
const { parseDocument } = require(path.join(automationRoot, 'lib/serialization'));

const fixedTime = '2026-08-15T12:00:00+08:00';

function loadJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
}

function writeText(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, value, { flag: 'wx' });
}

function sha256File(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function parseArgs(argv) {
  let runId = 'PILOT-RUN-001';
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--run-id') {
      if (!argv[index + 1]) throw new Error('--run-id requires a value.');
      runId = argv[index + 1];
      index += 1;
    } else if (argv[index] === '--help') {
      process.stdout.write('Usage: node scripts/run-pilot.js [--run-id PILOT-RUN-001]\n');
      process.exit(0);
    } else {
      throw new Error(`Unknown pilot option ${argv[index]}.`);
    }
  }
  if (!/^PILOT-RUN-[0-9]{3,}$/.test(runId)) throw new Error('Run ID must match PILOT-RUN-NNN.');
  return { runId };
}

function resultOf(payload) {
  if (!payload) return 'UNPARSEABLE';
  if (payload.summary && payload.summary.result) return payload.summary.result;
  return payload.result || 'UNSPECIFIED';
}

function assertion(name, pass, expected, actual) {
  return { name, pass: Boolean(pass), expected, actual };
}

function countControlFiles(projectRoot) {
  const files = [
    'product-os.yaml',
    '.product-os/framework.lock.yaml',
    '.product-os/repository-index.yaml',
    '.product-os/profile-composition.yaml',
    '.product-os/artifact-register.yaml',
    '.product-os/state/catalogs/schema-catalog.json',
    '.product-os/state/catalogs/artifact-catalog.json',
    '.product-os/state/catalogs/gate-catalog.json',
    '.product-os/state/catalogs/profile-catalog.json'
  ];
  return files.filter((relative) => fs.existsSync(path.join(projectRoot, relative))).length;
}

function traceFixture(projectId, suffix) {
  const source = loadJson(path.join(frameworkRoot, 'examples/records/trace-graph.json'));
  source.graph_id = `TRACE-${suffix}`;
  source.project_id = projectId;
  source.snapshot_at = fixedTime;
  source.owner.actor_id = `${suffix}-TRACE-OWNER`;
  source.nodes.forEach((node) => {
    node.node_id = node.node_id.replace('001', suffix);
    node.subject_id = `${node.subject_id}-${suffix}`;
    node.owner.actor_id = `${suffix}-${node.owner.actor_id}`;
    node.valid_from = fixedTime;
    node.canonical_locator.revision = `${suffix.toLowerCase()}-revision-001`;
  });
  source.edges.forEach((edge) => {
    edge.edge_id = `EDGE-VERIFIES-${suffix}`;
    edge.source_node_id = `NODE-EVD-${suffix}`;
    edge.target_node_id = `NODE-REQ-${suffix}`;
    edge.asserted_by.actor_id = `${suffix}-VERIFICATION-REVIEWER`;
    edge.asserted_at = fixedTime;
    edge.valid_from = fixedTime;
  });
  source.coverage.validated_at = fixedTime;
  return source;
}

function handoffFixture(projectId, suffix) {
  const source = loadJson(path.join(frameworkRoot, 'examples/records/handoff.json'));
  source.handoff_id = `HANDOFF-${suffix}`;
  source.project_id = projectId;
  source.sender.actor_id = `${suffix}-SENDER`;
  source.receiver.actor_id = `${suffix}-RECEIVER`;
  source.owner.actor_id = `${suffix}-OWNER`;
  source.acknowledgement_authority.actor_id = `${suffix}-ACK-AUTHORITY`;
  source.sent_at = fixedTime;
  source.received_at = fixedTime;
  source.acknowledged_at = fixedTime;
  source.environment_considerations = ['Synthetic pilot workspace only; no production access.'];
  source.data_considerations = ['Synthetic non-personal pilot data only.'];
  return source;
}

function partialGateFixture(projectId) {
  const source = loadJson(path.join(frameworkRoot, 'examples/records/gate-decision.json'));
  source.decision_id = 'P2-G3B-PARTIAL-001';
  source.project_id = projectId;
  source.workflow_status = 'IN_REVIEW';
  source.authority.actor_id = 'SYNTHETIC-P2-G3B-AUTHORITY';
  source.decided_at = fixedTime;
  source.valid_from = fixedTime;
  source.checks[0].reviewer.actor_id = 'SYNTHETIC-P2-REVIEWER';
  source.checks[0].evaluated_at = fixedTime;
  return source;
}

function completeGateFixture(projectId) {
  const source = loadJson(path.join(frameworkRoot, 'examples/records/gate-decision.json'));
  source.decision_id = 'P3-G0-STRUCTURAL-FIXTURE-001';
  source.gate_id = 'G0';
  source.project_id = projectId;
  source.scope.summary = 'Synthetic P3 initialization candidate used only to test structural gate readiness.';
  source.candidate_or_baseline_refs = ['P3-ICB-CANDIDATE-001'];
  source.workflow_status = 'DRAFT';
  source.outcome = 'PASS';
  source.authority = { actor_id: 'SYNTHETIC-PILOT-AUTHORITY', actor_type: 'ROLE', authority_ref: null };
  source.decided_at = fixedTime;
  source.valid_from = fixedTime;
  source.handoff_ref = null;
  source.allowed_next_actions = ['Submit the synthetic fixture to structural review.'];
  source.prohibited_actions = ['Treat the fixture outcome as Product OS or project approval.'];
  source.restrictions = ['Synthetic pilot evidence only.'];
  source.reopen_triggers = ['Any fixture, framework, schema, catalog, or command change.'];
  source.evidence_refs = Array.from({ length: 15 }, (_, index) => `P3-G0-EVD-${String(index + 1).padStart(2, '0')}`);
  source.checks = Array.from({ length: 15 }, (_, index) => {
    const ordinal = String(index + 1).padStart(2, '0');
    return {
      check_id: `G0-${ordinal}`,
      criterion: `Synthetic G0 structural criterion ${ordinal}.`,
      scope: { summary: `Synthetic P3 pilot check ${ordinal}.` },
      status: 'PASS',
      subject_refs: [`P3-G0-SUBJECT-${ordinal}`],
      evidence_refs: [`P3-G0-EVD-${ordinal}`],
      method: 'Synthetic fixture inspection through the Product OS gate command.',
      reviewer: { actor_id: 'SYNTHETIC-PILOT-REVIEWER', actor_type: 'ROLE', authority_ref: null },
      authority_ref: 'SYNTHETIC-PILOT-AUTHORITY',
      conditions: [],
      limitations: ['Structural command pilot only.'],
      evaluated_at: fixedTime,
      valid_until: null,
      invalidation_triggers: ['Fixture or governing contract changes.']
    };
  });
  return source;
}

function baselineFixture(projectRoot, projectId, correctDigest) {
  const source = loadJson(path.join(frameworkRoot, 'examples/records/baseline.json'));
  const relative = 'lifecycle/phase-04/REQ-001-software-requirements-specification.md';
  source.baseline_id = correctDigest ? 'P2-RBL-VALID-001' : 'P2-RBL-INVALID-001';
  source.project_id = projectId;
  source.artifact_members[0].instance_ref = `${projectId}-REQ-001`;
  source.artifact_members[0].locator.value = relative;
  source.artifact_members[0].locator.revision = 'pilot-p2-revision-001';
  source.artifact_members[0].digest.value = correctDigest ? sha256File(path.join(projectRoot, relative)) : 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
  source.created_at = fixedTime;
  source.effective_at = fixedTime;
  source.owner.actor_id = 'P2-REQUIREMENTS-OWNER';
  source.authority.actor_id = 'SYNTHETIC-P2-BASELINE-AUTHORITY';
  return source;
}

function prepareP2(projectRoot) {
  const requirement = path.join(projectRoot, 'lifecycle/phase-04/REQ-001-software-requirements-specification.md');
  writeText(requirement, '# P2 Synthetic Requirements\n\nREQ-FR-P2-001 requires a bilingual booking submission with keyboard, screen-reader, RTL, and LTR support.\n');
  writeJson(path.join(projectRoot, 'records/trace-graph.json'), traceFixture('PILOT-P2', 'P2'));
  writeJson(path.join(projectRoot, 'records/gate-partial.json'), partialGateFixture('PILOT-P2'));
  writeJson(path.join(projectRoot, 'records/handoff.json'), handoffFixture('PILOT-P2', 'P2'));
  writeJson(path.join(projectRoot, 'records/baseline-valid.json'), baselineFixture(projectRoot, 'PILOT-P2', true));
  writeJson(path.join(projectRoot, 'records/baseline-invalid.json'), baselineFixture(projectRoot, 'PILOT-P2', false));
}

function prepareP3(projectRoot) {
  const graph = traceFixture('PILOT-P3', 'P3');
  writeJson(path.join(projectRoot, 'records/trace-graph.json'), graph);
  const broken = deepClone(graph);
  broken.graph_id = 'TRACE-P3-BROKEN';
  broken.edges[0].target_node_id = 'NODE-MISSING-P3';
  writeJson(path.join(projectRoot, 'negative/broken-graph.json'), broken);

  const gate = completeGateFixture('PILOT-P3');
  writeJson(path.join(projectRoot, 'records/gate-complete.json'), gate);
  const gateMissingEvidence = deepClone(gate);
  gateMissingEvidence.decision_id = 'P3-G0-MISSING-EVIDENCE-001';
  gateMissingEvidence.checks[0].evidence_refs = [];
  writeJson(path.join(projectRoot, 'negative/gate-missing-evidence.json'), gateMissingEvidence);

  const handoff = handoffFixture('PILOT-P3', 'P3');
  writeJson(path.join(projectRoot, 'records/handoff.json'), handoff);
  const blockedHandoff = deepClone(handoff);
  blockedHandoff.handoff_id = 'HANDOFF-P3-BLOCKED';
  blockedHandoff.blocker_refs = ['P3-BLOCKER-001'];
  writeJson(path.join(projectRoot, 'negative/handoff-blocked.json'), blockedHandoff);

  const migrationSource = path.join(projectRoot, 'migration/source.json');
  writeJson(migrationSource, { schema_version: '0.1.0', record_name: 'synthetic-regulated-benefit', status: 'draft' });
  const plan = {
    plan_id: 'P3-MIGRATION-001',
    plan_version: '0.1.0',
    source_schema_version: '0.1.0',
    target_schema_version: '0.2.0',
    operations: [{
      operation_id: 'P3-MIGRATION-OP-001',
      type: 'TRANSFORM_JSON',
      source: 'migration/source.json',
      target: 'records/benefit.json',
      expected_sha256: sha256File(migrationSource),
      transform: {
        rename: { '/record_name': '/display_name' },
        set: { '/schema_version': '0.2.0', '/migration_state': 'staged' },
        remove: ['/status']
      }
    }],
    rollback_strategy: 'Discard the new staged root because canonical source remains unchanged.',
    verification: ['Validate staged JSON, verify digests, and confirm no canonical cutover.']
  };
  writeJson(path.join(projectRoot, 'migration/plan.json'), plan);
  const badPlan = deepClone(plan);
  badPlan.plan_id = 'P3-MIGRATION-BAD-DIGEST-001';
  badPlan.operations[0].expected_sha256 = '0000000000000000000000000000000000000000000000000000000000000000';
  writeJson(path.join(projectRoot, 'negative/migration-bad-digest.json'), badPlan);

  writeText(path.join(projectRoot, 'archive-source/policy.txt'), 'Synthetic retention policy evidence.\n');
  writeText(path.join(projectRoot, 'archive-source/runbook.txt'), 'Synthetic restoration runbook evidence.\n');
}

function evaluateAcceptance(criteriaCatalog, cases, projects, manifestVerified) {
  const byId = Object.fromEntries(cases.map((item) => [item.case_id, item]));
  const passCases = (...ids) => ids.every((id) => byId[id] && byId[id].passed);
  const commands = new Set(cases.map((item) => item.command));
  const positive = cases.filter((item) => !item.kind.startsWith('NEGATIVE'));
  const negative = cases.filter((item) => item.kind.startsWith('NEGATIVE'));
  const p1 = parseDocument(path.join(projects.P1, 'product-os.yaml'));
  const p2 = parseDocument(path.join(projects.P2, 'product-os.yaml'));
  const p3 = parseDocument(path.join(projects.P3, 'product-os.yaml'));
  const frameworkData = byId['P2-002'].payload.data;
  const reconciliation = byId['P3-003'].payload.data.framework;
  const noApproval = cases.every((item) => {
    if (!item.payload) return true;
    const serialized = JSON.stringify(item.payload);
    return !serialized.includes('"approval_claim":"') || item.payload.approval_claim === 'NONE' || item.payload.result === 'ERROR';
  });
  const values = {
    'PAC-001': p1.default_profile === 'P1' && p2.default_profile === 'P2' && p3.default_profile === 'P3',
    'PAC-002': commands.size === 12,
    'PAC-003': positive.every((item) => item.passed),
    'PAC-004': negative.every((item) => item.passed),
    'PAC-005': noApproval && passCases('P2-004', 'P2-005', 'P2-006', 'P3-005', 'P3-006', 'P3-007'),
    'PAC-006': passCases('P1-001', 'P3-010', 'P3-012'),
    'PAC-007': countControlFiles(projects.P1) === 9 && countControlFiles(projects.P2) === 9 && countControlFiles(projects.P3) === 9,
    'PAC-008': passCases('P3-010', 'P3-011'),
    'PAC-009': passCases('P3-012', 'P3-013', 'NEG-007'),
    'PAC-010': reconciliation.artifacts === 281 && reconciliation.gates === 13 && JSON.stringify(reconciliation.profiles) === JSON.stringify(['P1', 'P2', 'P3']),
    'PAC-011': frameworkData.schema_count === 21 && frameworkData.selected_files === 24 && frameworkData.local_reference_count === 485 && frameworkData.network_reference_fallback === false,
    'PAC-012': passCases('P2-003', 'NEG-003'),
    'PAC-013': passCases('P2-004', 'P3-005', 'NEG-002'),
    'PAC-014': passCases('P2-005', 'P3-006', 'NEG-004'),
    'PAC-015': passCases('P2-007', 'P2-008'),
    'PAC-016': passCases('P2-006', 'P3-007', 'NEG-005'),
    'PAC-017': passCases('P1-006', 'P3-009', 'NEG-008'),
    'PAC-018': cases.length === 35 && cases.every((item) => item.evidence_file && item.assertions.length >= 2),
    'PAC-019': manifestVerified,
    'PAC-020': true
  };
  return criteriaCatalog.criteria.map((criterion) => ({
    ...criterion,
    result: values[criterion.criterion_id] ? 'PASS' : 'FAIL',
    evaluated_by: 'PILOT-RUNNER-DETERMINISTIC',
    authority_effect: 'NONE'
  }));
}

function buildManifest(evidenceRoot) {
  const entries = [];
  const queue = [evidenceRoot];
  while (queue.length) {
    const directory = queue.shift();
    for (const name of fs.readdirSync(directory).sort()) {
      const file = path.join(directory, name);
      const stat = fs.statSync(file);
      if (stat.isDirectory()) queue.push(file);
      else if (name !== 'evidence-manifest.json') entries.push({
        relative_path: path.relative(evidenceRoot, file).split(path.sep).join('/'),
        sha256: sha256File(file),
        size_bytes: stat.size
      });
    }
  }
  return {
    manifest_id: 'PILOT-EVIDENCE-MANIFEST-001',
    version: '0.1.0',
    hash_algorithm: 'sha256',
    entry_count: entries.length,
    entries,
    self_inclusion: false,
    authority_effect: 'NONE'
  };
}

function verifyManifest(manifest, evidenceRoot) {
  return manifest.entry_count === manifest.entries.length && manifest.entries.every((entry) => {
    const file = path.join(evidenceRoot, entry.relative_path);
    return fs.existsSync(file) && fs.statSync(file).size === entry.size_bytes && sha256File(file) === entry.sha256;
  });
}

function main() {
  const { runId } = parseArgs(process.argv.slice(2));
  const runRoot = path.join(pilotRoot, 'runs', runId);
  if (fs.existsSync(runRoot)) throw new Error(`Pilot run root already exists and will not be overwritten: ${runRoot}`);
  fs.mkdirSync(runRoot, { recursive: true });
  const evidenceRoot = path.join(runRoot, 'evidence');
  const commandEvidenceRoot = path.join(evidenceRoot, 'commands');
  fs.mkdirSync(commandEvidenceRoot, { recursive: true });

  const pilotCatalog = loadJson(path.join(pilotRoot, 'config/pilot-catalog.json'));
  const testCatalog = loadJson(path.join(pilotRoot, 'config/test-case-catalog.json'));
  const criteriaCatalog = loadJson(path.join(pilotRoot, 'config/acceptance-criteria.json'));
  assert.strictEqual(pilotCatalog.scenario_count, 3);
  assert.strictEqual(testCatalog.case_count, 35);
  assert.strictEqual(criteriaCatalog.criterion_count, 20);

  const projects = {
    P1: path.join(runRoot, 'workspaces/p1-rapid'),
    P2: path.join(runRoot, 'workspaces/p2-standard'),
    P3: path.join(runRoot, 'workspaces/p3-comprehensive')
  };
  Object.values(projects).forEach((project) => fs.mkdirSync(project, { recursive: true }));

  const catalogById = Object.fromEntries(testCatalog.cases.map((item) => [item.case_id, item]));
  const results = [];

  function runCase(caseId, projectRoot, optionArgs, customAssertions) {
    const definition = catalogById[caseId];
    if (!definition) throw new Error(`Unknown pilot case ${caseId}.`);
    const invocation = [cliFile, definition.command, ...optionArgs, '--project', projectRoot, '--framework', frameworkRoot, '--json'];
    const startedAt = new Date().toISOString();
    const start = process.hrtime.bigint();
    const completed = childProcess.spawnSync(process.execPath, invocation, { encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 });
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    const stdout = completed.stdout.trim();
    const stderr = completed.stderr.trim();
    let payload = null;
    const payloadText = stdout || stderr;
    try { payload = payloadText ? JSON.parse(payloadText) : null; }
    catch (error) { payload = { result: 'UNPARSEABLE', raw_output: payloadText, parse_error: error.message }; }
    const observedResult = resultOf(payload);
    const assertions = [
      assertion('expected_exit', completed.status === definition.expected_exit, definition.expected_exit, completed.status),
      assertion('expected_result', observedResult === definition.expected_result, definition.expected_result, observedResult)
    ];
    for (const item of customAssertions(payload, completed.status)) assertions.push(item);
    const record = {
      case_id: caseId,
      scenario_id: definition.scenario_id,
      command: definition.command,
      kind: definition.kind,
      purpose: definition.purpose,
      started_at: startedAt,
      completed_at: new Date().toISOString(),
      duration_ms: Number(durationMs.toFixed(3)),
      invocation: {
        executable: 'node',
        cli: path.relative(pilotRoot, cliFile).split(path.sep).join('/'),
        options: optionArgs,
        project: path.relative(runRoot, projectRoot).split(path.sep).join('/'),
        framework: path.relative(outputsRoot, frameworkRoot).split(path.sep).join('/')
      },
      expected_exit: definition.expected_exit,
      observed_exit: completed.status,
      expected_result: definition.expected_result,
      observed_result: observedResult,
      assertions,
      passed: assertions.every((item) => item.pass),
      payload,
      stderr_non_json: stderr && !stdout && payload && payload.result === 'UNPARSEABLE' ? stderr : null,
      approval_claim: payload && payload.approval_claim ? payload.approval_claim : 'NONE_OR_NOT_APPLICABLE'
    };
    const evidenceFile = path.join(commandEvidenceRoot, `${caseId}.json`);
    writeJson(evidenceFile, record);
    record.evidence_file = path.relative(evidenceRoot, evidenceFile).split(path.sep).join('/');
    results.push(record);
    process.stdout.write(`${record.passed ? 'PASS' : 'FAIL'} ${caseId} ${definition.command} exit=${completed.status} result=${observedResult} duration_ms=${record.duration_ms}\n`);
    return record;
  }

  runCase('P1-001', projects.P1, ['--project-id', 'PILOT-P1', '--project-name', 'Rapid Status Service', '--profile', 'P1'], (payload) => [
    assertion('dry_run_created_no_manifest', !fs.existsSync(path.join(projects.P1, 'product-os.yaml')), false, fs.existsSync(path.join(projects.P1, 'product-os.yaml'))),
    assertion('planned_nine_files', payload.data.planned_files.length === 9, 9, payload.data.planned_files.length)
  ]);
  runCase('P1-002', projects.P1, ['--project-id', 'PILOT-P1', '--project-name', 'Rapid Status Service', '--profile', 'P1', '--apply'], (payload) => [
    assertion('nine_control_files_created', countControlFiles(projects.P1) === 9, 9, countControlFiles(projects.P1)),
    assertion('mode_applied', payload.data.mode === 'APPLIED', 'APPLIED', payload.data.mode)
  ]);
  runCase('P1-003', projects.P1, ['--strict'], (payload) => [
    assertion('five_core_controls_valid', payload.data.project.core_control_files_valid === 5, 5, payload.data.project.core_control_files_valid)
  ]);
  runCase('P1-004', projects.P1, ['--scope', 'project'], (payload) => [
    assertion('five_project_controls_valid', payload.data.structurally_valid_files === 5, 5, payload.data.structurally_valid_files)
  ]);
  runCase('P1-005', projects.P1, ['--scope', 'all'], (payload) => [
    assertion('artifact_count_281', payload.data.framework.artifacts === 281, 281, payload.data.framework.artifacts),
    assertion('gate_count_13', payload.data.framework.gates === 13, 13, payload.data.framework.gates),
    assertion('profiles_p1_p2_p3', JSON.stringify(payload.data.framework.profiles) === JSON.stringify(['P1', 'P2', 'P3']), ['P1', 'P2', 'P3'], payload.data.framework.profiles)
  ]);
  runCase('P1-006', projects.P1, [], (payload) => [
    assertion('secret_values_not_emitted', payload.data.secret_values_emitted === false, false, payload.data.secret_values_emitted)
  ]);

  runCase('P2-001', projects.P2, ['--project-id', 'PILOT-P2', '--project-name', 'Bilingual Service Booking', '--profile', 'P2', '--apply'], (payload) => [
    assertion('nine_control_files_created', countControlFiles(projects.P2) === 9, 9, countControlFiles(projects.P2)),
    assertion('profile_p2', parseDocument(path.join(projects.P2, 'product-os.yaml')).default_profile === 'P2', 'P2', parseDocument(path.join(projects.P2, 'product-os.yaml')).default_profile)
  ]);
  prepareP2(projects.P2);
  runCase('P2-002', projects.P2, ['--scope', 'all'], (payload) => [
    assertion('all_24_instances_valid', payload.data.selected_files === 24 && payload.data.structurally_valid_files === 24, 24, payload.data.structurally_valid_files),
    assertion('schema_count_21', payload.data.schema_count === 21, 21, payload.data.schema_count),
    assertion('reference_count_485', payload.data.local_reference_count === 485, 485, payload.data.local_reference_count)
  ]);
  runCase('P2-003', projects.P2, ['--file', 'records/trace-graph.json'], (payload) => [
    assertion('graph_two_nodes_one_edge', payload.data.nodes === 2 && payload.data.edges === 1, '2 nodes / 1 edge', `${payload.data.nodes} nodes / ${payload.data.edges} edges`),
    assertion('graph_no_endpoint_gap', payload.data.unresolved_endpoints === 0, 0, payload.data.unresolved_endpoints)
  ]);
  runCase('P2-004', projects.P2, ['--file', 'records/trace-graph.json', '--from', 'NODE-EVD-P2', '--direction', 'downstream', '--max-depth', '4'], (payload) => [
    assertion('one_impact_candidate', payload.data.impact_candidate_count === 1, 1, payload.data.impact_candidate_count),
    assertion('no_impact_not_authorized', payload.data.no_impact_decision === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.no_impact_decision)
  ]);
  runCase('P2-005', projects.P2, ['--file', 'records/gate-partial.json', '--partial'], (payload) => [
    assertion('partial_gate_warning', payload.summary.warnings === 1, 1, payload.summary.warnings),
    assertion('gate_decision_not_authorized', payload.data.automation_gate_decision === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.automation_gate_decision)
  ]);
  runCase('P2-006', projects.P2, ['--file', 'records/handoff.json'], (payload) => [
    assertion('handoff_ack_not_authorized', payload.data.automation_acknowledgement === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.automation_acknowledgement),
    assertion('handoff_has_no_blockers', payload.data.blockers === 0, 0, payload.data.blockers)
  ]);
  runCase('P2-007', projects.P2, ['--file', 'records/baseline-valid.json'], (payload) => [
    assertion('baseline_structural_reproducibility', payload.data.reproducibility_claim === 'STRUCTURALLY_ESTABLISHED', 'STRUCTURALLY_ESTABLISHED', payload.data.reproducibility_claim),
    assertion('one_digest_verified', payload.data.locally_verified_sha256_members === 1, 1, payload.data.locally_verified_sha256_members)
  ]);
  runCase('P2-008', projects.P2, ['--file', 'records/baseline-invalid.json'], (payload) => [
    assertion('baseline_reproducibility_rejected', payload.data.reproducibility_claim === 'NOT_ESTABLISHED', 'NOT_ESTABLISHED', payload.data.reproducibility_claim),
    assertion('baseline_has_error', payload.summary.errors > 0, '>0', payload.summary.errors)
  ]);

  runCase('P3-001', projects.P3, ['--project-id', 'PILOT-P3', '--project-name', 'Regulated Benefits Administration', '--profile', 'P3', '--apply'], (payload) => [
    assertion('nine_control_files_created', countControlFiles(projects.P3) === 9, 9, countControlFiles(projects.P3)),
    assertion('profile_p3', parseDocument(path.join(projects.P3, 'product-os.yaml')).default_profile === 'P3', 'P3', parseDocument(path.join(projects.P3, 'product-os.yaml')).default_profile)
  ]);
  prepareP3(projects.P3);
  runCase('P3-002', projects.P3, ['--scope', 'all'], (payload) => [
    assertion('all_24_instances_valid', payload.data.selected_files === 24 && payload.data.structurally_valid_files === 24, 24, payload.data.structurally_valid_files)
  ]);
  runCase('P3-003', projects.P3, ['--scope', 'all'], (payload) => [
    assertion('canonical_counts_reconciled', payload.data.framework.artifacts === 281 && payload.data.framework.gates === 13, '281 artifacts / 13 gates', `${payload.data.framework.artifacts} artifacts / ${payload.data.framework.gates} gates`)
  ]);
  runCase('P3-004', projects.P3, ['--file', 'records/trace-graph.json'], (payload) => [
    assertion('graph_resolved', payload.data.unresolved_endpoints === 0 && payload.data.orphan_nodes.length === 0, 'resolved with no orphan', payload.data)
  ]);
  runCase('P3-005', projects.P3, ['--file', 'records/trace-graph.json', '--from', 'NODE-REQ-P3', '--direction', 'both', '--max-depth', '6'], (payload) => [
    assertion('both_direction_candidate', payload.data.impact_candidate_count === 1, 1, payload.data.impact_candidate_count),
    assertion('materiality_not_performed', payload.data.materiality_decision === 'NOT_PERFORMED', 'NOT_PERFORMED', payload.data.materiality_decision)
  ]);
  runCase('P3-006', projects.P3, ['--file', 'records/gate-complete.json'], (payload) => [
    assertion('all_g0_checks_present', payload.data.expected_checks === 15 && payload.data.provided_checks === 15, 15, payload.data.provided_checks),
    assertion('gate_approval_not_performed', payload.data.approval_or_risk_acceptance_performed === false, false, payload.data.approval_or_risk_acceptance_performed)
  ]);
  runCase('P3-007', projects.P3, ['--file', 'records/handoff.json'], (payload) => [
    assertion('handoff_ack_not_authorized', payload.data.automation_acknowledgement === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.automation_acknowledgement)
  ]);
  runCase('P3-008', projects.P3, ['--strict'], (payload) => [
    assertion('five_core_controls_valid', payload.data.project.core_control_files_valid === 5, 5, payload.data.project.core_control_files_valid)
  ]);
  runCase('P3-009', projects.P3, [], (payload) => [
    assertion('lint_secret_values_not_emitted', payload.data.secret_values_emitted === false, false, payload.data.secret_values_emitted)
  ]);
  runCase('P3-010', projects.P3, ['--plan', 'migration/plan.json', '--output', 'migration-staged'], (payload) => [
    assertion('migration_dry_run_no_output', !fs.existsSync(path.join(projects.P3, 'migration-staged')), false, fs.existsSync(path.join(projects.P3, 'migration-staged'))),
    assertion('migration_no_cutover', payload.data.canonical_cutover_performed === false, false, payload.data.canonical_cutover_performed)
  ]);
  runCase('P3-011', projects.P3, ['--plan', 'migration/plan.json', '--output', 'migration-staged', '--apply'], (payload) => {
    const staged = loadJson(path.join(projects.P3, 'migration-staged/records/benefit.json'));
    return [
      assertion('migration_staged_output_exists', fs.existsSync(path.join(projects.P3, 'migration-staged/migration-manifest.json')), true, fs.existsSync(path.join(projects.P3, 'migration-staged/migration-manifest.json'))),
      assertion('migration_transform_exact', staged.display_name === 'synthetic-regulated-benefit' && staged.schema_version === '0.2.0' && staged.migration_state === 'staged' && !Object.prototype.hasOwnProperty.call(staged, 'status'), 'exact transformed record', staged),
      assertion('migration_no_destructive_action', payload.data.canonical_cutover_performed === false && payload.data.deletion_performed === false && payload.data.overwrite_performed === false, 'all false', { cutover: payload.data.canonical_cutover_performed, deletion: payload.data.deletion_performed, overwrite: payload.data.overwrite_performed })
    ];
  });
  runCase('P3-012', projects.P3, ['--include', 'archive-source', '--output', 'archive-output'], (payload) => [
    assertion('archive_dry_run_no_output', !fs.existsSync(path.join(projects.P3, 'archive-output')), false, fs.existsSync(path.join(projects.P3, 'archive-output'))),
    assertion('archive_plans_two_files', payload.data.file_count === 2, 2, payload.data.file_count)
  ]);
  runCase('P3-013', projects.P3, ['--include', 'archive-source', '--output', 'archive-output', '--apply'], (payload) => [
    assertion('archive_manifest_exists', fs.existsSync(path.join(projects.P3, 'archive-output/archive-manifest.json')), true, fs.existsSync(path.join(projects.P3, 'archive-output/archive-manifest.json'))),
    assertion('archive_sources_preserved', fs.existsSync(path.join(projects.P3, 'archive-source/policy.txt')) && fs.existsSync(path.join(projects.P3, 'archive-source/runbook.txt')), true, 'source files preserved'),
    assertion('archive_no_deletion', payload.data.source_deletion_performed === false, false, payload.data.source_deletion_performed)
  ]);

  runCase('NEG-001', projects.P3, ['--project-id', 'PILOT-P3', '--project-name', 'Regulated Benefits Administration', '--profile', 'P3', '--apply'], () => [
    assertion('existing_control_preserved', fs.existsSync(path.join(projects.P3, 'product-os.yaml')), true, fs.existsSync(path.join(projects.P3, 'product-os.yaml')))
  ]);
  runCase('NEG-002', projects.P3, ['--file', 'records/trace-graph.json', '--from', 'NODE-NOT-PRESENT', '--direction', 'downstream'], (payload) => [
    assertion('impact_start_failure_recorded', payload.summary.errors > 0, '>0', payload.summary.errors),
    assertion('no_impact_not_authorized', payload.data.no_impact_decision === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.no_impact_decision)
  ]);
  runCase('NEG-003', projects.P3, ['--file', 'negative/broken-graph.json'], (payload) => [
    assertion('unresolved_endpoint_detected', payload.data.unresolved_endpoints === 1, 1, payload.data.unresolved_endpoints)
  ]);
  runCase('NEG-004', projects.P3, ['--file', 'negative/gate-missing-evidence.json'], (payload) => [
    assertion('missing_gate_evidence_detected', payload.summary.errors > 0, '>0', payload.summary.errors),
    assertion('gate_still_not_authorized', payload.data.automation_gate_decision === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.automation_gate_decision)
  ]);
  runCase('NEG-005', projects.P3, ['--file', 'negative/handoff-blocked.json'], (payload) => [
    assertion('acknowledged_blocker_detected', payload.summary.errors > 0 && payload.data.blockers === 1, 'error and one blocker', { errors: payload.summary.errors, blockers: payload.data.blockers }),
    assertion('handoff_ack_not_authorized', payload.data.automation_acknowledgement === 'NOT_AUTHORIZED', 'NOT_AUTHORIZED', payload.data.automation_acknowledgement)
  ]);
  runCase('NEG-006', projects.P3, ['--plan', 'negative/migration-bad-digest.json', '--output', 'bad-migration-staged'], (payload) => [
    assertion('bad_migration_output_absent', !fs.existsSync(path.join(projects.P3, 'bad-migration-staged')), false, fs.existsSync(path.join(projects.P3, 'bad-migration-staged'))),
    assertion('digest_mismatch_detected', payload.summary.errors > 0, '>0', payload.summary.errors)
  ]);
  runCase('NEG-007', projects.P3, ['--include', 'archive-source', '--output', 'archive-output', '--apply'], () => [
    assertion('existing_archive_preserved', fs.existsSync(path.join(projects.P3, 'archive-output/archive-manifest.json')), true, fs.existsSync(path.join(projects.P3, 'archive-output/archive-manifest.json'))),
    assertion('archive_sources_still_present', fs.existsSync(path.join(projects.P3, 'archive-source/policy.txt')), true, fs.existsSync(path.join(projects.P3, 'archive-source/policy.txt')))
  ]);
  writeText(path.join(projects.P3, 'negative/duplicate.yaml'), 'schema_id: "urn:product-os:schema:v1:project-manifest"\nschema_id: "urn:product-os:schema:v1:project-manifest"\n');
  runCase('NEG-008', projects.P3, ['--file', 'negative/duplicate.yaml'], (payload) => [
    assertion('duplicate_yaml_rejected', payload.findings.some((item) => item.rule_id === 'SRV-006'), 'SRV-006 finding', payload.findings.map((item) => item.rule_id))
  ]);

  assert.strictEqual(results.length, testCatalog.case_count);
  assert.deepStrictEqual(results.map((item) => item.case_id), testCatalog.cases.map((item) => item.case_id));

  const manifestBeforeReports = buildManifest(evidenceRoot);
  const manifestVerified = verifyManifest(manifestBeforeReports, evidenceRoot);
  const acceptance = evaluateAcceptance(criteriaCatalog, results, projects, manifestVerified);
  const acceptancePass = acceptance.every((item) => item.result === 'PASS');
  const allCasesPass = results.every((item) => item.passed);
  const commandCoverage = [...new Set(results.map((item) => item.command))].sort();
  const durations = results.map((item) => item.duration_ms);
  const runSummary = {
    run_id: runId,
    pilot_version: '0.1.0',
    pilot_type: pilotCatalog.pilot_type,
    started_at: results[0].started_at,
    completed_at: results[results.length - 1].completed_at,
    scenario_count: pilotCatalog.scenario_count,
    profiles_exercised: ['P1', 'P2', 'P3'],
    command_count: commandCoverage.length,
    commands_exercised: commandCoverage,
    case_count: results.length,
    cases_passed: results.filter((item) => item.passed).length,
    cases_failed: results.filter((item) => !item.passed).length,
    positive_and_warning_cases: results.filter((item) => !item.kind.startsWith('NEGATIVE')).length,
    negative_cases: results.filter((item) => item.kind.startsWith('NEGATIVE')).length,
    acceptance_criteria_count: acceptance.length,
    acceptance_criteria_passed: acceptance.filter((item) => item.result === 'PASS').length,
    duration_ms: Number(durations.reduce((sum, value) => sum + value, 0).toFixed(3)),
    max_case_duration_ms: Number(Math.max(...durations).toFixed(3)),
    result: allCasesPass && acceptancePass ? 'TECHNICAL_PASS' : 'TECHNICAL_FAIL',
    product_os_authority_approval: 'NOT_PERFORMED',
    product_os_baseline: 'NOT_ESTABLISHED',
    production_access: false,
    production_data: false,
    authority_effect: 'NONE'
  };
  writeJson(path.join(evidenceRoot, 'acceptance-results.json'), {
    run_id: runId,
    criterion_count: acceptance.length,
    passed: acceptance.filter((item) => item.result === 'PASS').length,
    failed: acceptance.filter((item) => item.result === 'FAIL').length,
    criteria: acceptance,
    authority_effect: 'NONE'
  });
  writeJson(path.join(evidenceRoot, 'pilot-run-report.json'), runSummary);
  const finalManifest = buildManifest(evidenceRoot);
  writeJson(path.join(evidenceRoot, 'evidence-manifest.json'), finalManifest);
  assert.ok(verifyManifest(finalManifest, evidenceRoot), 'Final evidence manifest verification failed.');

  process.stdout.write(`SUMMARY result=${runSummary.result} scenarios=${runSummary.scenario_count} commands=${runSummary.command_count} cases=${runSummary.case_count} passed=${runSummary.cases_passed} failed=${runSummary.cases_failed} criteria=${runSummary.acceptance_criteria_passed}/${runSummary.acceptance_criteria_count}\n`);
  if (runSummary.result !== 'TECHNICAL_PASS') process.exitCode = 1;
}

try {
  main();
} catch (error) {
  process.stderr.write(`PILOT_RUNNER_ERROR ${error.stack}\n`);
  process.exitCode = 1;
}
