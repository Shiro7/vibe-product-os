#!/usr/bin/env node
'use strict';

const assert = require('assert');
const childProcess = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const pilotRoot = path.resolve(__dirname, '..');
const outputsRoot = path.resolve(pilotRoot, '..');
const automationRoot = path.join(outputsRoot, 'Automation_Commands');
const { JsonReader, parseDocument } = require(path.join(automationRoot, 'lib/serialization'));

function parseArgs(argv) {
  let runId = 'PILOT-RUN-002';
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--run-id') {
      runId = argv[index + 1];
      index += 1;
    } else if (argv[index] === '--help') {
      process.stdout.write('Usage: node scripts/audit-pilot.js [--run-id PILOT-RUN-002]\n');
      process.exit(0);
    } else throw new Error(`Unknown audit option ${argv[index]}.`);
  }
  if (!/^PILOT-RUN-[0-9]{3,}$/.test(runId)) throw new Error('Run ID must match PILOT-RUN-NNN.');
  return { runId };
}

function listFiles(root) {
  const files = [];
  const queue = [root];
  while (queue.length) {
    const directory = queue.shift();
    for (const name of fs.readdirSync(directory).sort()) {
      const target = path.join(directory, name);
      const stat = fs.lstatSync(target);
      if (stat.isDirectory()) queue.push(target);
      else if (stat.isFile()) files.push(target);
      else throw new Error(`Unsupported pilot filesystem object: ${target}`);
    }
  }
  return files.sort();
}

function parseJson(file) {
  return new JsonReader(fs.readFileSync(file, 'utf8'), file).parse();
}

function sha256File(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function controlCount(projectRoot) {
  return [
    'product-os.yaml',
    '.product-os/framework.lock.yaml',
    '.product-os/repository-index.yaml',
    '.product-os/profile-composition.yaml',
    '.product-os/artifact-register.yaml',
    '.product-os/state/catalogs/schema-catalog.json',
    '.product-os/state/catalogs/artifact-catalog.json',
    '.product-os/state/catalogs/gate-catalog.json',
    '.product-os/state/catalogs/profile-catalog.json'
  ].filter((relative) => fs.existsSync(path.join(projectRoot, relative))).length;
}

function main() {
  const { runId } = parseArgs(process.argv.slice(2));
  const files = listFiles(pilotRoot);
  const markdownFiles = files.filter((file) => file.endsWith('.md'));
  const normativeDocuments = markdownFiles.filter((file) => path.dirname(file) === pilotRoot);
  const javascriptFiles = files.filter((file) => file.endsWith('.js'));
  assert.strictEqual(files.length, 191, 'Pilot package file count drifted.');
  assert.strictEqual(markdownFiles.length, 12, 'Pilot total Markdown count must remain 12.');
  assert.strictEqual(normativeDocuments.length, 10, 'Pilot normative document count must remain 10.');
  assert.strictEqual(javascriptFiles.length, 2, 'Pilot runner/audit script count must remain 2.');

  for (const file of javascriptFiles) {
    const checked = childProcess.spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
    assert.strictEqual(checked.status, 0, `JavaScript syntax failure in ${file}: ${checked.stderr}`);
  }

  const pilotCatalog = parseJson(path.join(pilotRoot, 'config/pilot-catalog.json'));
  const caseCatalog = parseJson(path.join(pilotRoot, 'config/test-case-catalog.json'));
  const criteriaCatalog = parseJson(path.join(pilotRoot, 'config/acceptance-criteria.json'));
  assert.strictEqual(pilotCatalog.scenario_count, 3);
  assert.strictEqual(pilotCatalog.scenarios.length, 3);
  assert.deepStrictEqual(pilotCatalog.scenarios.map((item) => item.profile).sort(), ['P1', 'P2', 'P3']);
  assert.strictEqual(new Set(pilotCatalog.scenarios.map((item) => item.scenario_id)).size, 3);
  assert.strictEqual(caseCatalog.case_count, 35);
  assert.strictEqual(caseCatalog.cases.length, 35);
  assert.strictEqual(new Set(caseCatalog.cases.map((item) => item.case_id)).size, 35);
  assert.strictEqual(caseCatalog.cases.filter((item) => item.kind.startsWith('NEGATIVE')).length, 9);
  assert.strictEqual(caseCatalog.cases.filter((item) => !item.kind.startsWith('NEGATIVE')).length, 26);
  assert.strictEqual(new Set(caseCatalog.cases.map((item) => item.command)).size, 12);
  assert.strictEqual(criteriaCatalog.criterion_count, 20);
  assert.strictEqual(criteriaCatalog.criteria.length, 20);
  assert.strictEqual(new Set(criteriaCatalog.criteria.map((item) => item.criterion_id)).size, 20);

  const runRoot = path.join(pilotRoot, 'runs', runId);
  const evidenceRoot = path.join(runRoot, 'evidence');
  const summary = parseJson(path.join(evidenceRoot, 'pilot-run-report.json'));
  const acceptance = parseJson(path.join(evidenceRoot, 'acceptance-results.json'));
  const manifest = parseJson(path.join(evidenceRoot, 'evidence-manifest.json'));
  assert.strictEqual(summary.run_id, runId);
  assert.strictEqual(summary.result, 'TECHNICAL_PASS');
  assert.strictEqual(summary.scenario_count, 3);
  assert.deepStrictEqual(summary.profiles_exercised, ['P1', 'P2', 'P3']);
  assert.strictEqual(summary.command_count, 12);
  assert.strictEqual(summary.case_count, 35);
  assert.strictEqual(summary.cases_passed, 35);
  assert.strictEqual(summary.cases_failed, 0);
  assert.strictEqual(summary.acceptance_criteria_passed, 20);
  assert.strictEqual(summary.product_os_authority_approval, 'NOT_PERFORMED');
  assert.strictEqual(summary.product_os_baseline, 'NOT_ESTABLISHED');
  assert.strictEqual(summary.production_access, false);
  assert.strictEqual(summary.production_data, false);
  assert.strictEqual(acceptance.criterion_count, 20);
  assert.strictEqual(acceptance.passed, 20);
  assert.strictEqual(acceptance.failed, 0);
  assert.ok(acceptance.criteria.every((item) => item.result === 'PASS' && item.authority_effect === 'NONE'));

  const commandFiles = fs.readdirSync(path.join(evidenceRoot, 'commands')).filter((name) => name.endsWith('.json')).sort();
  assert.strictEqual(commandFiles.length, 35);
  assert.deepStrictEqual(commandFiles.map((name) => path.basename(name, '.json')).sort(), caseCatalog.cases.map((item) => item.case_id).sort());
  const cases = commandFiles.map((name) => parseJson(path.join(evidenceRoot, 'commands', name)));
  assert.ok(cases.every((item) => item.passed));
  assert.ok(cases.every((item) => item.observed_exit === item.expected_exit && item.observed_result === item.expected_result));
  assert.ok(cases.every((item) => item.assertions.length >= 2 && item.assertions.every((entry) => entry.pass)));
  assert.strictEqual(new Set(cases.map((item) => item.command)).size, 12);
  assert.ok(cases.every((item) => item.approval_claim === 'NONE' || item.approval_claim === 'NONE_OR_NOT_APPLICABLE'));

  assert.strictEqual(manifest.entry_count, 37);
  assert.strictEqual(manifest.entries.length, 37);
  assert.strictEqual(new Set(manifest.entries.map((item) => item.relative_path)).size, 37);
  for (const entry of manifest.entries) {
    const file = path.join(evidenceRoot, entry.relative_path);
    assert.ok(fs.existsSync(file), `Missing evidence object ${entry.relative_path}.`);
    assert.strictEqual(fs.statSync(file).size, entry.size_bytes, `Evidence byte-size mismatch for ${entry.relative_path}.`);
    assert.strictEqual(sha256File(file), entry.sha256, `Evidence digest mismatch for ${entry.relative_path}.`);
  }

  const projects = {
    P1: path.join(runRoot, 'workspaces/p1-rapid'),
    P2: path.join(runRoot, 'workspaces/p2-standard'),
    P3: path.join(runRoot, 'workspaces/p3-comprehensive')
  };
  for (const [profile, project] of Object.entries(projects)) {
    assert.strictEqual(controlCount(project), 9, `${profile} control count drifted.`);
    assert.strictEqual(parseDocument(path.join(project, 'product-os.yaml')).default_profile, profile);
  }
  const migrationSource = parseJson(path.join(projects.P3, 'migration/source.json'));
  const migrationStaged = parseJson(path.join(projects.P3, 'migration-staged/records/benefit.json'));
  assert.deepStrictEqual(migrationSource, { schema_version: '0.1.0', record_name: 'synthetic-regulated-benefit', status: 'draft' });
  assert.deepStrictEqual(migrationStaged, { schema_version: '0.2.0', display_name: 'synthetic-regulated-benefit', migration_state: 'staged' });
  assert.ok(fs.existsSync(path.join(projects.P3, 'archive-source/policy.txt')));
  assert.ok(fs.existsSync(path.join(projects.P3, 'archive-source/runbook.txt')));
  assert.ok(fs.existsSync(path.join(projects.P3, 'archive-output/archive-manifest.json')));

  const failedRun = path.join(pilotRoot, 'runs/PILOT-RUN-001/evidence');
  const failedSummary = parseJson(path.join(failedRun, 'pilot-run-report.json'));
  const failedCase = parseJson(path.join(failedRun, 'commands/NEG-001.json'));
  assert.strictEqual(failedSummary.result, 'TECHNICAL_FAIL');
  assert.strictEqual(failedSummary.cases_passed, 34);
  assert.strictEqual(failedSummary.cases_failed, 1);
  assert.strictEqual(failedCase.passed, false);
  assert.strictEqual(failedCase.expected_exit, 4);
  assert.strictEqual(failedCase.observed_exit, 1);

  const unfinished = /\b(?:TODO|TBD|FIXME)\b|for brevity|content omitted/i;
  const linkPattern = /\[[^\]\r\n]+\]\(([^)\r\n]+)\)/g;
  let checkedLinks = 0;
  for (const file of markdownFiles) {
    const content = fs.readFileSync(file, 'utf8');
    assert.strictEqual((content.match(/^(?:```|~~~)/gm) || []).length % 2, 0, `Unbalanced fence in ${file}.`);
    assert.ok(!unfinished.test(content), `Unfinished marker in ${file}.`);
    for (const line of content.split(/\r?\n/)) {
      linkPattern.lastIndex = 0;
      let match;
      while ((match = linkPattern.exec(line)) !== null) {
        let target = match[1].trim().replace(/^<|>$/g, '');
        if (target.startsWith('#') || /^[a-z]+:/i.test(target)) continue;
        target = target.split('#')[0];
        if (!target) continue;
        const resolved = path.resolve(path.dirname(file), decodeURIComponent(target));
        assert.ok(fs.existsSync(resolved), `Broken Markdown link ${file} -> ${target}`);
        checkedLinks += 1;
      }
    }
  }

  process.stdout.write(`PILOT AUDIT PASS files=${files.length} normative_docs=${normativeDocuments.length} markdown=${markdownFiles.length} scenarios=3 profiles=3 commands=12 cases=35 criteria=20 evidence=37 links=${checkedLinks} retained_runs=2\n`);
}

try {
  main();
} catch (error) {
  process.stderr.write(`PILOT_AUDIT_ERROR ${error.stack}\n`);
  process.exitCode = 1;
}
