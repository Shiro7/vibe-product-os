# Product OS v1.0 — Artifact Catalog, Register, Instance, and Composite Packaging

~~~yaml
document_id: FRAMEWORK-ARTIFACT-CATALOG-REGISTER-INSTANCE-PACKAGING
version: 0.1.0
status: WORKING_DRAFT
completion_state: ARTIFACT_SCHEMA_PACKAGING_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
artifact_catalog_count: 281
schemas: [artifact-ids, artifact-catalog, artifact-register, artifact-instance, profile-composition]
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification turns the Master Artifact Catalog and Shared Core Artifact Contract into exact machine-readable identities, project registry entries, artifact instances, and physical package memberships.

---

# 2. Artifact ID Schema

`artifact-ids.schema.json` contains an enum of the exact 281 current IDs:

~~~text
GOV-001..009
INIT-001..007
DISC-001..009
BUS-001..012
PROD-001..014
REQ-001..014
EXP-001..020
DES-001..023
ARC-001..033
ENG-001..032
IMP-001..032
VRL-001..038
OPS-001..038
~~~

Composite aliases `INIT-000`, `REQ-000`, and `EXP-000` are package aliases only and are excluded from the 281 enum.

---

# 3. Machine Artifact Catalog

Every entry preserves:

- artifact ID/name/family/owning phase;
- primary data class;
- activation class;
- P1/P2/P3 packaging codes;
- framework contract reference;
- status and version.

The machine catalog is generated/reconciled from the approved Master Artifact Catalog. It does not become a separate authority through JSON format.

Catalog validation requires exactly 281 unique IDs, exact family ranges, registered enums, and no composite alias counted as an artifact.

---

# 4. Artifact Register — GOV-002

Every activated, pending, N/A, stale, superseded, or retired project artifact has exactly one current register entry.

Required entry groups:

1. logical identity: ID/name/family/type/phase/contract;
2. project/profile/activation/applicability;
3. registry/artifact/decision/verification/approval/change-impact statuses;
4. artifact version/baseline/current content digest;
5. owner/contributors/reviewers/approvers/authority;
6. canonical location/role/schema/native refs;
7. dependencies/downstream/GOV-008/GOV-009;
8. sources/evidence/conditions/exceptions;
9. timestamps/review/supersession/access/retention/reopen.

The register does not duplicate full artifact content.

---

# 5. Status Separation

The schema keeps independent enums:

| Dimension | Values |
|---|---|
| Registry lifecycle | `DRAFT`, `ACTIVE`, `SUPERSEDED`, `STALE`, `RETIRED` |
| Artifact status | `NOT_STARTED`, `IN_PROGRESS`, `IN_REVIEW`, `BLOCKED`, `COMPLETE`, `REOPENED`, `DEPRECATED` |
| Applicability | `APPLICABLE`, `NOT_APPLICABLE`, `PENDING` |
| Decision status | `PROPOSED`, `IN_REVIEW`, `APPROVED`, `DEFERRED`, `REJECTED`, `OPEN` |
| Verification status | `NOT_STARTED`, `PARTIAL`, `VERIFIED`, `FAILED`, `BLOCKED` |
| Change impact | `NOT_ASSESSED`, `NO_IMPACT`, `REVIEW_REQUIRED`, `IMPACT_CONFIRMED`, `REMEDIATION_REQUIRED`, `DISPOSITIONED` |
| Approval status | `NOT_REQUIRED`, `PENDING`, `IN_REVIEW`, `APPROVED`, `CONDITIONALLY_APPROVED`, `REJECTED`, `EXPIRED`, `REVOKED` |

No state is inferred from another.

---

# 6. NOT_APPLICABLE Condition

If `applicability = NOT_APPLICABLE`, the register/instance requires:

~~~yaml
not_applicable:
  reason:
  scope:
  decision_owner:
  authority:
  decision_at:
  source_refs: []
  evidence_refs: []
  downstream_implications: []
  review_due:
  reopen_conditions: []
~~~

An N/A entry may remain registry `ACTIVE` as the current governed disposition. Empty files do not prove N/A.

---

# 7. Artifact Instance

The common instance schema requires:

- schema and record identity;
- artifact/project/contract/version/profile metadata;
- exact statuses and owner;
- purpose/scope/applicability;
- confirmed facts, assumptions, decisions, requirements/obligations, open questions, risks/dependencies;
- verification/evidence/exceptions;
- content index and artifact-specific payload;
- exit criteria, downstream handoff, reopen conditions, and change history.

The artifact-specific payload may reference a specialized schema. The common schema cannot replace the 281 Core Artifact Contracts.

---

# 8. Information Object Minimums

## 8.1 Fact

ID, statement, scope, source refs, confidence/reliability, owner, effective/observed time, contradictions, status.

## 8.2 Assumption

ID, statement, rationale, confidence, impact, owner, validation method, due/expiry, affected artifacts, outcome/status.

## 8.3 Decision

ID, question/context/options, decision, rationale, scope, owner, authority, status, conditions, sources/evidence, effective/expiry/supersession/reopen.

## 8.4 Requirement/obligation

ID, normative statement, kind, level/priority, scope, applicability, rationale/source, owner, acceptance/verification refs, status, version, change history.

## 8.5 Open question

ID, question, why/impact, blocking, owner, due event, status, answer source, decision required.

## 8.6 Verification entry

Check/criterion, method, exact subject/candidate, status/result, verifier, evidence refs, time, limitations, invalidation/reopen.

---

# 9. Physical Package Membership

Each current artifact maps to exactly one canonical project representation for each exact content responsibility:

- composite file/section;
- modular file/section;
- independent file;
- shared register entry;
- external native object;
- derived view (never semantic owner);
- governed N/A record.

Semantic validators check no active duplicate/missing membership and that register canonical location matches composition.

---

# 10. Split and Merge

## Split composite to independent

Freeze package/member versions → create new member paths → preserve artifact IDs/content history → update register/composition/links → validate → archive superseded package view.

## Merge independent to composite

Confirm independence no longer required → create addressable sections/keys → preserve member owners/states/evidence → update canonical locations atomically → validate → archive old files.

Split/merge never creates/retires logical artifacts unless catalog governance separately decides it.

---

# 11. Native and Distributed Artifacts

An artifact whose content spans Markdown, Figma, repository source, test/evidence systems, and operational records has one GOV-002 identity and a content-location set with field/role ownership.

The register identifies:

- canonical semantic representation;
- canonical native representation(s);
- governed register/mapping;
- derived views;
- evidence refs;
- availability/access/retention;
- exact versions and synchronization state.

---

# 12. Artifact Validation Boundaries

Schema checks structure and enums. Semantic validation additionally checks:

- all activated/N/A artifacts registered exactly once;
- catalog identity/name/family/phase/class consistency;
- owner/contract/location/version resolvability;
- package membership uniqueness and addressability;
- dependency/trace/source/evidence refs;
- N/A authority and reopen completeness;
- status transition validity;
- baseline/gate membership consistency;
- supersession and history continuity;
- profile/domain override alignment.

---

# 13. Final Artifact Principle

> **The catalog defines what the logical artifacts are, GOV-002 says which project instances exist and where, the artifact schema preserves their operating contract, and composition decides only how they are physically packaged.**

