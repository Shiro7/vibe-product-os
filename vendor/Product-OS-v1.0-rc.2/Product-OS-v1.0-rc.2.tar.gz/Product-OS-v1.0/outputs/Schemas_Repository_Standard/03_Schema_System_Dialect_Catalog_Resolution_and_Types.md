# Product OS v1.0 — Schema System, Dialect, Catalog, Resolution, and Types

~~~yaml
document_id: FRAMEWORK-SCHEMA-SYSTEM-DIALECT-CATALOG-RESOLUTION-TYPES
version: 0.1.0
status: WORKING_DRAFT
completion_state: SCHEMA_SYSTEM_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
json_schema_dialect: https://json-schema.org/draft/2020-12/schema
schema_count: 21
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines the canonical schema dialect, IDs, local resolution, schema catalog, data types, extensibility, and conformance behavior for Product OS machine-readable records.

Official standards basis:

- `https://json-schema.org/draft/2020-12`
- `https://json-schema.org/draft/2020-12/schema`
- `https://yaml.org/spec/1.2.2/`

---

# 2. Canonical Dialect

Every Product OS JSON Schema declares:

~~~json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:product-os:schema:v1:example",
  "title": "Product OS Example Schema",
  "type": "object"
}
~~~

Draft 2020-12 is fixed for this schema-system major version. A later dialect requires compatibility/migration review and a new schema-system version.

---

# 3. Canonical Schema ID

Grammar:

~~~text
urn:product-os:schema:{schema-system-major}:{schema-name}
~~~

Examples:

- `urn:product-os:schema:v1:common`
- `urn:product-os:schema:v1:artifact-register`
- `urn:product-os:schema:v1:gate-decision`

Rules:

1. `$id` is permanent for a compatible schema line.
2. Breaking meaning creates a new major namespace or successor name.
3. Repository paths may change while `$id` remains stable through the schema catalog.
4. `$id` is not a fetch instruction; governed validation resolves it locally.
5. Fragments use JSON Pointer into `$defs` or document nodes.

---

# 4. Schema Version

Each schema contains `x-product-os-schema-version` using semantic versioning:

- MAJOR: instance incompatibility or meaning change requiring migration;
- MINOR: backward-compatible fields/definitions/options where old valid instances remain valid;
- PATCH: clarification or constraint correction that does not intentionally invalidate conforming instances.

If a correction invalidates previously accepted unsafe/incorrect data, classify impact explicitly; do not hide it as PATCH.

---

# 5. Schema Catalog

The schema catalog is the only approved resolver registry for canonical schema IDs in a release.

Each entry records:

~~~yaml
schema_id:
title:
version:
relative_path:
scope: CORE|CATALOG|RECORD|LIFECYCLE|PHYSICAL
status:
sha256_required: true
~~~

Catalog conditions:

- schema IDs and paths are unique;
- paths remain inside the framework distribution root;
- the released framework manifest and project framework lock carry the calculated digest; the Working Draft catalog declares that SHA-256 is required;
- `ACTIVE`, `DEPRECATED`, `SUPERSEDED`, and `RETIRED` are explicit;
- unresolved or network-only `$ref` fails governed validation;
- catalog version is pinned in the project framework lock.

---

# 6. Twenty-One Schemas

| No. | Canonical ID suffix | File | Record family |
|---:|---|---|---|
| 1 | `common` | `schemas/core/common.schema.json` | Shared definitions |
| 2 | `artifact-ids` | `schemas/core/artifact-ids.schema.json` | Exact 281 artifact ID enum |
| 3 | `project-manifest` | `schemas/core/project-manifest.schema.json` | Project root configuration |
| 4 | `framework-lock` | `schemas/core/framework-lock.schema.json` | Framework dependency lock |
| 5 | `repository-index` | `schemas/core/repository-index.schema.json` | Repository/root/module registry |
| 6 | `profile-composition` | `schemas/core/profile-composition.schema.json` | Profile/domain/package resolution |
| 7 | `artifact-catalog` | `schemas/catalog/artifact-catalog.schema.json` | Master artifact catalog instance |
| 8 | `gate-catalog` | `schemas/catalog/gate-catalog.schema.json` | Gate catalog instance |
| 9 | `profile-catalog` | `schemas/catalog/profile-catalog.schema.json` | Profile catalog instance |
| 10 | `schema-catalog` | `schemas/catalog/schema-catalog.schema.json` | Schema catalog instance |
| 11 | `artifact-register` | `schemas/records/artifact-register.schema.json` | GOV-002 project register |
| 12 | `artifact-instance` | `schemas/records/artifact-instance.schema.json` | Common artifact instance |
| 13 | `governance-record` | `schemas/records/governance-record.schema.json` | Decision/risk/assumption/question/change/applicability/exception |
| 14 | `trace-graph` | `schemas/records/trace-graph.schema.json` | GOV-008 nodes/edges/tombstones |
| 15 | `source-evidence` | `schemas/records/source-evidence.schema.json` | Source/claim/evidence and binding |
| 16 | `gate-decision` | `schemas/lifecycle/gate-decision.schema.json` | G0–G8 decision record |
| 17 | `baseline` | `schemas/lifecycle/baseline.schema.json` | ICB–OBL versioned membership |
| 18 | `handoff` | `schemas/lifecycle/handoff.schema.json` | Phase/tool/operational handoff |
| 19 | `tool-mapping` | `schemas/physical/tool-mapping.schema.json` | Product OS to native-tool representation |
| 20 | `ai-run` | `schemas/physical/ai-run.schema.json` | AI task/run/action/tool/evidence record |
| 21 | `exchange-envelope` | `schemas/physical/exchange-envelope.schema.json` | Import/export/migration envelope |

---

# 7. `$ref` Resolution

Resolution algorithm:

1. Parse schema and instance deterministically.
2. Read the instance’s schema ID/version.
3. Resolve schema ID through the project-pinned schema catalog.
4. Verify schema path remains inside locked framework root and digest matches release manifest when available.
5. Preload every referenced canonical ID from the same catalog.
6. Reject duplicate schema IDs, unresolved refs, version incompatibility, reference cycles unsupported by the validator, or network fallback.
7. Validate and return machine-readable error objects with instance path, schema path, keyword, code, message, and severity.

Network retrieval is disabled by default for reproducibility, confidentiality, availability, and supply-chain integrity.

---

# 8. Type Rules

| Concept | Representation |
|---|---|
| Stable identifier/reference | non-empty string with schema-specific pattern/enum |
| Semantic version | string `MAJOR.MINOR.PATCH` with optional prerelease/build |
| Calendar date | quoted string `YYYY-MM-DD` |
| Instant | quoted ISO 8601 string with timezone offset or `Z` |
| Duration/period | explicit object or ISO 8601 duration string when schema defines it |
| Money | object with decimal string amount and ISO currency code; never binary float |
| Percentage/rate | number only when precision/scale are defined; otherwise decimal string |
| Digest | algorithm plus lowercase encoded value |
| URI/locator | string plus locator class and version/immutability metadata where material |
| Status | closed enum from owning contract |
| Unknown | explicit `UNKNOWN`, `PENDING`, `UNASSIGNED`, or allowed `null`; never guessed |
| Set | array with `uniqueItems: true`; semantic uniqueness may require automation key check |
| Ordered sequence | array where order meaning is documented |
| Map | object only for bounded key spaces; use entry arrays when keys need lifecycle/metadata |

---

# 9. Required and Optional Fields

- Identity, schema, project/scope, owner, lifecycle state, provenance, and timestamps are required when the record cannot be interpreted safely without them.
- Optional means conceptually absent or not needed for that record kind, not “work not done”.
- `null` is accepted only where a known-empty/unknown distinction is defined.
- Empty arrays are valid when a required collection has been explicitly evaluated and has zero entries.
- Missing required data fails validation or uses an explicit unresolved record/status if the schema permits.

---

# 10. Closed and Extensible Objects

Default governed record objects use `additionalProperties: false` to detect typos and uncontrolled fields.

Extensibility uses one of:

- `extensions` object whose keys are namespaced URIs/approved prefixes;
- `artifact_specific` object governed by a specialized schema ID;
- cataloged successor schema;
- external/native object reference.

Extensions cannot override required fields, statuses, authority, or canonical semantics. Unknown extensions remain data and may be rejected by profile/policy.

---

# 11. Conditional Rules

JSON Schema conditionals enforce local structural dependencies, including:

- `NOT_APPLICABLE` requires an applicability record;
- gate outcome family matches gate ID;
- governance payload matches record type;
- evidence record requires claim bindings and method/result identity;
- generated records require generator and source provenance;
- superseded/retired state requires successor or disposition where applicable.

Cross-record uniqueness, graph traversal, authority, evidence sufficiency, and repository/native existence require semantic validators in Automation / Commands.

---

# 12. Error Contract

Every validation finding contains:

~~~yaml
finding_id:
validation_layer:
rule_id:
severity:
instance_id:
instance_path:
schema_id:
schema_version:
schema_path:
keyword:
message:
actual_value_digest:
expected_summary:
owner:
blocking_scope:
remediation:
source_refs: []
created_at:
status:
~~~

Sensitive actual values are redacted; the finding stores digest/summary when necessary.

---

# 13. Format Semantics

JSON Schema 2020-12 `format` behavior varies by vocabulary/validator configuration. Product OS schemas pair critical formats with patterns or semantic validation rules and record validator configuration. A `format` annotation alone does not prove a timestamp, URI, email, hostname, or other value is operationally valid or authorized.

---

# 14. Final Schema Principle

> **Use a small set of versioned record-family schemas, exact catalogs, and local resolution to make all 281 artifacts testable without pretending they share one giant content shape.**
