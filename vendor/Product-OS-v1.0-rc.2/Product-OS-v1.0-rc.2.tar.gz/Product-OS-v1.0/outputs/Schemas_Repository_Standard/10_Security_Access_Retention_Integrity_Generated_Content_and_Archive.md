# Product OS v1.0 — Security, Access, Retention, Integrity, Generated Content, and Archive

~~~yaml
document_id: FRAMEWORK-REPOSITORY-SECURITY-ACCESS-RETENTION-INTEGRITY-ARCHIVE
version: 0.1.0
status: WORKING_DRAFT
completion_state: REPOSITORY_SECURITY_ARCHIVE_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification protects schemas, repositories, project records, evidence, generated content, migrations, and archives against unauthorized change, leakage, loss, ambiguity, and unrecoverable tool dependence.

---

# 2. Data Classification

Default classes:

`PUBLIC`, `INTERNAL`, `CONFIDENTIAL`, `RESTRICTED`, `SECRET_REFERENCE_ONLY`.

Projects may map approved classifications, but every record/file inherits or declares a class. `SECRET_REFERENCE_ONLY` allows secret identity/version/owner/rotation metadata, never the secret value.

---

# 3. Access Roles

Separate capabilities:

- read/discover;
- create/edit proposed content;
- change canonical content;
- change control manifests/registers;
- publish framework/schema/catalog;
- approve artifact/decision/gate;
- verify/accept evidence;
- merge/release/deploy;
- administer permissions/integrations;
- export/migrate/archive/delete;
- audit/read protected logs.

Repository role names are mapped to these capabilities; platform admin is not automatic project authority.

---

# 4. Protected Assets

Stronger change control applies to:

- framework releases, schemas, catalogs, migrations, profiles, adapters;
- project manifest, framework lock, repository index, profile composition, artifact register;
- GOV-001/GOV-009, baselines, gate decisions, release authorization;
- evidence manifests/objects and audit records;
- generated-source definitions, CI/workflow/security configuration;
- archive/retention/legal-hold records.

Protection includes review, branch/ruleset equivalent, integrity, least privilege, change evidence, and recovery proportional to profile/risk.

---

# 5. Secret and Sensitive Data Rules

- No credential/private key/token/password/secret value in schemas, examples, manifests, Markdown, issues, Figma, logs, generated output, or evidence indexes.
- Reference secrets by governed secret ID, class, owner, purpose, environment, version, rotation/revocation, and provider locator.
- Use synthetic/minimized example data; no real personal/customer/production data in framework examples.
- Redaction preserves original evidence identity, authorized unredacted custody, transformation method, redactor, time, and redacted digest.
- Generated diagnostics/errors avoid echoing sensitive instance values.

---

# 6. Integrity

Integrity record includes:

~~~yaml
algorithm: sha256
digest:
size_bytes:
media_type:
created_or_collected_at:
source_identity:
source_revision:
transforms: []
signature_or_attestation_ref:
verified_at:
verified_by:
status:
~~~

Digest proves byte identity, not truth, authority, safety, or semantic equivalence.

---

# 7. Generated and Derived Content

Generated/derived files live under declared locations such as `.product-os/derived/` and include generator/schema/source versions and digests.

Rules:

1. never edit generated output as canonical truth;
2. generation is deterministic or records non-deterministic inputs/configuration;
3. generator identity/source is protected and versioned;
4. output declares freshness and failed/partial generation;
5. secrets/restricted fields are excluded/redacted by policy;
6. regeneration does not erase prior baseline/evidence output required for history;
7. generator upgrade enters change/migration review;
8. generated code/content receives human/automated review and verification appropriate to consequence.

---

# 8. Evidence Storage

Evidence may be:

- stored content-addressed in repository;
- stored in a dedicated evidence/object store;
- retained in native tool with immutable/versioned identity;
- archived as integrity-protected export.

The evidence manifest always remains discoverable and records access/retention/expiry. Large/binary/restricted objects are not forced into the control repository.

---

# 9. Retention Record

Every material record/evidence object declares:

- retention class/purpose;
- start event and minimum/maximum period or policy ref;
- legal/contractual hold;
- data subject/privacy deletion constraints;
- active/archive locations;
- owner/reviewer;
- disposition: retain, archive, anonymize, delete, transfer;
- disposition authority/evidence;
- restore/readability requirements;
- next review/expiry.

No universal duration is invented by the framework.

---

# 10. Archive Contract

An archive package includes:

- archive ID/purpose/scope/version;
- original logical/native/repository identities;
- framework/schema/catalog versions required to interpret it;
- files/objects/relationships/tombstones and integrity manifest;
- supersession/retirement/decision/effective time;
- access/encryption/key-reference/retention/hold;
- known omissions/non-exportable tool behavior;
- restore/read-only verification procedure;
- owner/custodian and disposition.

Archive is not an unindexed folder of old files.

---

# 11. Backup and Recovery

Repository hosting/history is not automatically a complete backup. Recovery scope includes framework releases, project control, canonical narrative records, source repositories, native tool exports where needed, evidence objects/manifests, access/configuration, packages, and archives.

Recovery tests verify identity, history, references, permissions, schema validity, native behavior, evidence readability/integrity, and ability to resume governed operation.

---

# 12. Deletion and Destructive Change

Before deletion/overwrite/bulk move:

1. resolve exact target by stable ID and approved root;
2. verify authority, retention, legal hold, dependencies, baseline/evidence use;
3. capture checkpoint/archive/tombstone when required;
4. preview exact scope and protected exclusions;
5. execute recoverably where practical;
6. verify intended deletion and prohibited preservation;
7. update registers, trace, mappings, derived views, and evidence;
8. report recoverability and residual state.

Broad unresolved paths, globs, home/root targets, or uncontrolled symlinks are prohibited.

---

# 13. Supply Chain

Schemas, validators, generators, actions/plugins, packages, templates, and migrations are code/supply-chain inputs. Pin source/version/digest, review provenance/license/security, restrict permissions/network/data, and preserve build/release evidence.

External schema retrieval and executable YAML tags are disabled by default.

---

# 14. Tool Exit Continuity

Critical semantics cannot depend solely on a vendor UI. Maintain schema/catalog/manifest/register/mapping exports, native IDs/versions, evidence integrity, and migration crosswalks sufficient to preserve meaning and history through tool exit.

Known export gaps are risks with compensating archives or re-verification.

---

# 15. Final Security Principle

> **Protect the control plane, minimize sensitive content, preserve integrity and history, and make every archive recoverable without turning the repository into a secret vault or evidence dump.**

