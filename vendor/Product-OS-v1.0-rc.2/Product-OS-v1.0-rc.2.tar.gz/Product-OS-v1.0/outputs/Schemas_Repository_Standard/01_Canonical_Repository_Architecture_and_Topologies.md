# Product OS v1.0 — Canonical Repository Architecture and Topologies

~~~yaml
document_id: FRAMEWORK-CANONICAL-REPOSITORY-ARCHITECTURE-TOPOLOGIES
version: 0.1.0
status: WORKING_DRAFT
completion_state: REPOSITORY_ARCHITECTURE_TOPOLOGIES_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
repository_topology_count: 4
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines stable repository layers and four governed topology choices without forcing every organization, product, or profile into one physical tree.

---

# 2. Repository Layers

| Layer | Owns | Must not contain |
|---|---|---|
| Framework source | Methodology, catalogs, contracts, cross-cutting standards, schemas, profiles, adapters, migrations, templates, assurance | Client/project facts or live approvals |
| Framework distribution | Immutable/versioned published package and integrity manifest | Mutable project state |
| Project control | Manifest, lock, repository index, profile composition, GOV-002 register, mappings, derived/state indexes | Secret values or unclassified binary evidence |
| Project semantic content | Activated governance and Phase 00–11 artifact representations | Competing native code/design truth |
| Native delivery systems | Figma, GitHub/source repos, CI, cloud, databases, observability, ticketing | Product OS gate authority unless explicitly the decision record carrier |
| Evidence store | Claim-bound evidence manifests and original/integrity-protected objects | Unindexed dumps or secrets |
| Archive | Superseded/retired framework/project/tool/evidence material with retention and restore metadata | Active canonical content without an active pointer |

---

# 3. Framework Repository

~~~text
product-os-framework/
├── README.md
├── VERSION.md
├── CHANGELOG.md
├── LICENSES/
├── methodology/
│   ├── phase-00-initialization/
│   ├── phase-01-discovery/
│   ├── phase-02-business-architecture/
│   ├── phase-03-product-definition/
│   ├── phase-04-requirements/
│   ├── phase-05-experience/
│   ├── phase-06-product-design/
│   ├── phase-07-solution-architecture/
│   ├── phase-08-engineering-readiness/
│   ├── phase-09-implementation/
│   ├── phase-10-verification-release/
│   └── phase-11-operations-evolution/
├── catalogs/
├── contracts/
├── cross-cutting/
├── schemas/
├── profiles/
├── adapters/
├── migrations/
├── templates/
└── assurance/
~~~

This is the normative distribution structure. Source-development repositories may add build/test/authoring directories, but published identities resolve to this logical layout.

---

# 4. Project Instance Repository

~~~text
project-root/
├── README.md
├── product-os.yaml
├── .product-os/
│   ├── framework.lock.yaml
│   ├── repository-index.yaml
│   ├── profile-composition.yaml
│   ├── artifact-register.yaml
│   ├── mappings/
│   ├── state/
│   └── derived/
├── governance/
├── lifecycle/
│   ├── phase-00-initialization/
│   ├── phase-01-discovery/
│   ├── phase-02-business-architecture/
│   ├── phase-03-product-definition/
│   ├── phase-04-requirements/
│   ├── phase-05-experience/
│   ├── phase-06-product-design/
│   ├── phase-07-solution-architecture/
│   ├── phase-08-engineering-readiness/
│   ├── phase-09-implementation/
│   ├── phase-10-verification-release/
│   └── phase-11-operations-evolution/
├── tools/
│   ├── spec-kit/
│   ├── figma/
│   └── github/
├── evidence/
│   ├── manifests/
│   └── objects/
└── archive/
~~~

Rules:

- Only activated phase/tool/evidence paths are created.
- `governance/` stores/project-links GOV-001..009 representations according to profile and access boundaries.
- `.product-os/` is the control plane, not a dumping ground for narrative content.
- Native source/design/test/production content remains in native systems/repositories and is indexed.
- `archive/` is not a second active source tree.

---

# 5. Four Repository Topologies

## 5.1 `SINGLE_PROJECT_REPOSITORY`

Product OS control/content and project code live in one repository.

Use when one team/product owns the scope and access/retention boundaries align. Repository index still separates `PRODUCT_OS_CONTROL`, `SPECIFICATION`, `SOURCE`, `EVIDENCE`, and generated roles by path.

## 5.2 `FRAMEWORK_PLUS_PROJECT`

Framework is a versioned external package/repository; project control/specification and code live in one project repository.

This is the default for most projects because framework releases can evolve independently while the project pins an exact lock.

## 5.3 `FEDERATED_MULTI_REPOSITORY`

Project control/specification has a canonical control repository and references several code, infrastructure, data, mobile, web, documentation, test, or operations repositories by their real names.

Use when ownership, build/release lifecycle, access, retention, or technology boundaries are independently governed. The repository index is mandatory and prevents generic alias drift.

## 5.4 `BROWNFIELD_OVERLAY`

A new Product OS control root is introduced without relocating existing source/design/operations assets. Existing repositories and tools are registered as external/native canonical locations.

Use for adoption into a live product. Renaming/moving code, changing branches, or restructuring pipelines is a separate authorized change after inventory and impact review.

---

# 6. Topology Decision Record

~~~yaml
topology_decision_id:
project_id:
selected_topology:
scope:
repositories_and_roots: []
framework_distribution:
drivers: []
alternatives: []
access_and_retention_boundaries: []
build_release_operations_boundaries: []
risks_and_compensating_controls: []
migration_and_exit_implications: []
owner:
authority:
status:
effective_at:
source_refs: []
evidence_refs: []
reopen_triggers: []
~~~

---

# 7. Repository Roles

Each repository/root has one primary role and may have secondary roles:

`FRAMEWORK_SOURCE`, `FRAMEWORK_DISTRIBUTION`, `PRODUCT_OS_CONTROL`, `SPECIFICATION`, `APPLICATION_SOURCE`, `LIBRARY_SOURCE`, `INFRASTRUCTURE_SOURCE`, `DATA_SCHEMA_MIGRATION`, `TEST_AUTOMATION`, `DOCUMENTATION`, `EVIDENCE_STORE`, `OPERATIONS`, `ARCHIVE`, `MIRROR`.

`MIRROR` never becomes canonical because it is newer or easier to reach.

---

# 8. Repository Index Requirements

Every registered repository/root records:

- exact system/organization/repository ID and canonical name;
- primary/secondary roles and product/domain/service/module scope;
- canonical versus mirror/archive state;
- default/protected branches and exact baseline revision;
- module/path ownership and CODEOWNER-equivalent authority;
- schema/migration/configuration/workflow/package/environment locations;
- tool, access, data classification, retention, backup, and exit boundary;
- upstream/downstream repository dependencies;
- rename/transfer/supersession history;
- last reconciliation and evidence.

---

# 9. Workspace and Checkout Boundary

Local workspace paths are not canonical repository identities. A register may record a current checkout for automation, but it also records repository ID, remote/source, revision, worktree/branch, dirty state policy, and scope.

Rules:

- never use a user home directory, filesystem root, or broad workspace as a generated/delete target;
- resolve and validate project root before writes;
- do not follow unregistered symlinks outside approved roots;
- preserve unrelated dirty changes;
- temporary work uses an explicit temporary directory and cleanup record;
- generated paths are allow-listed, not inferred from uncontrolled input.

---

# 10. Monorepo and Multi-Repository Modules

A module is a governed source boundary, not merely a directory. It records:

- stable module ID and canonical project-specific name;
- repository/path/package/service/runtime identity;
- owner/review authority;
- public interfaces and data ownership;
- build/test/deploy and environment scope;
- dependencies and consumers;
- change/release compatibility;
- artifact, architecture, design, requirement, and operational mappings.

Directory movement does not silently change module identity.

---

# 11. Repository Creation Rule

A new repository requires a decision showing an independent ownership, access, lifecycle, build/release, retention, compliance, performance, or reuse reason. “Keeping things tidy” alone is insufficient.

A new directory requires an active content class or control need. Empty future-looking directories are prohibited in project instances.

---

# 12. Final Architecture Principle

> **Choose topology from ownership and lifecycle boundaries; use the repository index to preserve one project map across however many physical repositories actually exist.**

