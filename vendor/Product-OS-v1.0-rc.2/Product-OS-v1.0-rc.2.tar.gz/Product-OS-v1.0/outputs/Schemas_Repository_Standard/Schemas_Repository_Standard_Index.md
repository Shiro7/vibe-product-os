# Product OS v1.0 — Schemas & Repository Standard Index

~~~yaml
document_id: FRAMEWORK-SCHEMAS-REPOSITORY-STANDARD-INDEX
version: 0.1.0
status: WORKING_DRAFT
completion_state: SCHEMAS_REPOSITORY_STANDARD_LIBRARY_COMPLETE
asset_class: PRODUCT_OS_FRAMEWORK_ASSET
project_artifact_count_impact: NONE
logical_artifact_scope: 281
gate_scope_count: 13
normative_document_count: 14
json_schema_count: 21
machine_catalog_count: 4
validated_example_count: 15
reference_layout_count: 2
repository_topology_count: 4
schema_dialect: JSON_SCHEMA_2020_12
yaml_authoring_version: YAML_1_2_2
canonical_view_count: 12
validation_rule_count: 80
anti_pattern_count: 40
shared_contract: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
predecessor: Spec Kit + Figma + GitHub Mapping v0.1.0
next_workstream: Product OS v1.0 Final Authority Decision
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This index is the canonical navigation and coverage register for the Product OS machine-readable schema system and repository standard.

The library answers:

1. How are framework assets separated from project-instance facts, decisions, requirements, designs, code mappings, evidence, and operational truth?
2. Which files and directories are stable, and which are created only by profile, applicability, domain override, or lifecycle event?
3. How do P1, P2, and P3 package the same 281 logical artifacts without changing IDs, owners, statuses, authority, or evidence?
4. Which JSON Schema dialect, identifier, reference, version, compatibility, and migration rules apply?
5. How are YAML, JSON, Markdown front matter, native tool objects, binaries, exports, and generated views represented without competing canonical owners?
6. Which schemas validate project manifests, framework locks, repositories, profiles, artifacts, governance, traceability, evidence, gates, baselines, handoffs, tool mappings, AI runs, and exchange?
7. How are repository naming, paths, canonical locations, symlinks, branches, generated content, evidence objects, archives, access, retention, and brownfield adoption governed?
8. How does the completed Automation / Commands layer consume this standard, and what remains for Pilot?

---

# 2. Governing Position

~~~text
Product OS logical contracts and authority
  → machine-readable schema identities and catalogs
  → framework repository distribution
  → project manifest + framework lock + repository index
  → profile/domain composition
  → activated artifact/register/native-tool/evidence locations
  → derived views and validation results
~~~

Schema validity proves structural conformance only. It does not prove truth, approval, verification, authority, gate passage, release authorization, or live health.

---

# 3. Framework and Project Boundary

The entire package is a Product OS framework asset and adds no project artifact IDs.

- The Master Artifact Catalog remains exactly 281 logical artifacts.
- The 21 schemas govern common record families; they do not create 21 project artifacts.
- The machine artifact catalog preserves all 281 IDs and current classification/profile metadata.
- A project instance pins exact framework, catalog, contract, schema, and mapping versions through its framework lock.
- Project files are activated from GOV-002 and profile composition; an unused artifact is never silently represented by an empty file.
- `NOT_APPLICABLE` is a governed project record with evidence and reopen conditions, not a missing file.
- Native Figma, GitHub, CI, cloud, test, and operational objects remain in their native systems and are registered by exact identity rather than flattened into repository text.

---

# 4. Library Map

| No. | Specification | Canonical responsibility |
|---:|---|---|
| 00 | [Shared Schema and Repository Contract](00_Shared_Schema_and_Repository_Contract.md) | Universal scope, invariants, formats, identity, conformance, authority, records, and change rules |
| 01 | [Canonical Repository Architecture and Topologies](01_Canonical_Repository_Architecture_and_Topologies.md) | Framework/project separation, stable macro-structure, four topology choices, boundaries, and repository registry |
| 02 | [Paths, Naming, IDs, File Anatomy, and Content Placement](02_Paths_Naming_IDs_File_Anatomy_and_Content_Placement.md) | Physical naming, file roles, Markdown/front matter, canonical placement, composites, links, and evidence paths |
| 03 | [Schema System, Dialect, Catalog, Resolution, and Types](03_Schema_System_Dialect_Catalog_Resolution_and_Types.md) | JSON Schema 2020-12, YAML 1.2.2, URN IDs, local resolution, type rules, closed/open objects, and schemas list |
| 04 | [Project Manifest, Framework Lock, Profiles, and Module Activation](04_Project_Manifest_Framework_Lock_Profiles_and_Module_Activation.md) | Project bootstrap, version lock, P1/P2/P3, domain overrides, packages, conditional modules, and lifecycle state |
| 05 | [Artifact Catalog, Register, Instance, and Composite Packaging](05_Artifact_Catalog_Register_Instance_and_Composite_Packaging.md) | 281 ID enum, GOV-002 registry, artifact instance anatomy, physical packages, membership, status, and N/A |
| 06 | [Governance, Trace, Change, Source, and Evidence Schemas](06_Governance_Trace_Change_Source_and_Evidence_Schemas.md) | Governance record variants, GOV-008 graph, sources/claims/evidence, conflicts, temporal state, and integrity |
| 07 | [Gate, Baseline, Handoff, Candidate, Release, and Operations Schemas](07_Gate_Baseline_Handoff_Candidate_Release_and_Operations_Schemas.md) | 13 gate outcomes, baseline membership, handoff contracts, candidate/release/live identity, and lifecycle boundaries |
| 08 | [Tool Mapping, AI Execution, and Exchange Schemas](08_Tool_Mapping_AI_Execution_and_Exchange_Schemas.md) | Spec Kit/Figma/GitHub representations, AI runs/actions, imports/exports, tombstones, digests, and schema exchange |
| 09 | [Versioning, Compatibility, Migration, Deprecation, and Brownfield Adoption](09_Versioning_Compatibility_Migration_Deprecation_and_Brownfield_Adoption.md) | Schema/repository evolution, semantic compatibility, migrations, dual-read/write limits, cutover, and overlay adoption |
| 10 | [Security, Access, Retention, Integrity, Generated Content, and Archive](10_Security_Access_Retention_Integrity_Generated_Content_and_Archive.md) | Least privilege, sensitive data, evidence objects, digests, generated/derived boundaries, retention, archive, and recovery |
| 11 | [Validation, Metrics, and Anti-Patterns](11_Validation_Metrics_and_Anti_Patterns.md) | 80 validation rules, 40 anti-patterns, conformance layers, metrics, and assurance procedure |
| Closure | [Coverage and Closure Review](Schemas_Repository_Standard_Coverage_and_Closure_Review.md) | File/schema/catalog/example counts, 281/gate coverage, syntax/reference/example audit, integration, deferments, and closure |

---

# 5. Machine-Readable Package

## 5.1 Schemas — 21

| Family | Schema files |
|---|---|
| Core | `common`, `artifact-ids`, `project-manifest`, `framework-lock`, `repository-index`, `profile-composition` |
| Catalogs | `artifact-catalog`, `gate-catalog`, `profile-catalog`, `schema-catalog` |
| Project records | `artifact-register`, `artifact-instance`, `governance-record`, `trace-graph`, `source-evidence` |
| Lifecycle | `gate-decision`, `baseline`, `handoff` |
| Physical/operating | `tool-mapping`, `ai-run`, `exchange-envelope` |

All schemas live under [`schemas/`](schemas/) and use canonical `urn:product-os:schema:v1:*` identifiers with catalog-based local resolution.

## 5.2 Catalogs — four

- [`artifact-catalog.json`](catalogs/artifact-catalog.json): all 281 artifacts and exact current classes, activation, phase, and P1/P2/P3 packaging.
- [`gate-catalog.json`](catalogs/gate-catalog.json): G0 through G8, including G3A/G3B/G4A/G4B/G5A/G5B/G6A/G6B.
- [`profile-catalog.json`](catalogs/profile-catalog.json): P1/P2/P3 semantics and physical packaging codes.
- [`schema-catalog.json`](catalogs/schema-catalog.json): canonical schema IDs, versions, paths, roles, and status.

## 5.3 Examples — fifteen

The [`examples/`](examples/) directory contains a coherent P2 example project control set plus one valid example for every project-record schema family. Examples are test vectors, not project decisions or pilot evidence.

## 5.4 Reference layouts — two

The [`reference-layout/`](reference-layout/) directory contains framework-repository and project-instance trees. They define stable allowed locations, not an instruction to instantiate every optional directory or file.

---

# 6. Canonical Formats

| Need | Canonical format | Rule |
|---|---|---|
| Schema definitions | JSON | JSON Schema Draft 2020-12 |
| Human-authored control records | YAML or JSON | YAML 1.2.2 Core-compatible data, normalized to JSON data model before validation |
| Human narrative specifications | Markdown plus governed front matter or sidecar | Content ownership and section contract remain explicit |
| Diagrams/design/code/native records | Native system | Repository stores exact registered identity and versioned export only when required |
| Binary evidence | Original format plus evidence manifest | Content-addressed/integrity-protected where required |
| Derived views | JSON/YAML/Markdown/HTML as declared | Rebuildable; generator/schema/source versions recorded; no manual canonical edits |

---

# 7. Stable Project Macro-Structure

~~~text
project-root/
├── README.md
├── product-os.yaml
├── .product-os/
│   ├── framework.lock.yaml
│   ├── repository-index.yaml
│   ├── profile-composition.yaml
│   ├── artifact-register.yaml
│   ├── mappings/
│   ├── state/
│   └── derived/
├── governance/
├── lifecycle/
│   ├── phase-00-initialization/
│   ├── phase-01-discovery/
│   ├── phase-02-business-architecture/
│   ├── phase-03-product-definition/
│   ├── phase-04-requirements/
│   ├── phase-05-experience/
│   ├── phase-06-product-design/
│   ├── phase-07-solution-architecture/
│   ├── phase-08-engineering-readiness/
│   ├── phase-09-implementation/
│   ├── phase-10-verification-release/
│   └── phase-11-operations-evolution/
├── tools/
├── evidence/
└── archive/
~~~

Only `README.md`, `product-os.yaml`, the four core `.product-os` control files, `governance/`, and the currently active lifecycle/tool/evidence locations are instantiated. Profile composition controls physical depth.

---

# 8. Twelve Canonical Views

1. Framework and schema version-lock view.
2. Repository and canonical-location view.
3. Artifact activation/applicability/register view.
4. Profile/domain/package composition view.
5. Schema conformance and migration view.
6. Trace/source/evidence integrity view.
7. Gate/baseline/handoff membership view.
8. Tool/native-object and repository-path mapping view.
9. Generated/derived freshness and provenance view.
10. Access/retention/archive and evidence continuity view.
11. Broken reference, duplicate identity, drift, and compatibility view.
12. Repository health and assurance dashboard.

---

# 9. Profile Treatment

| Profile | Repository treatment |
|---|---|
| P1 — Lean / Rapid | Composite phase packages and compact shared registers; logical IDs remain addressable through membership/index anchors |
| P2 — Standard | Modular files/sections for independently owned or reviewed artifacts; deterministic manifests, mappings, and validation |
| P3 — Comprehensive | Independent artifacts and evidence packages where lifecycle/authority requires; stronger signing, segregation, migration, retention, and continuous drift assurance |

Profile never changes schema semantics, artifact count, authority, status separation, evidence obligations, or gate meaning.

---

# 10. Current Release State

This library is technically complete at Working Draft level. Product OS authority approval and baseline remain pending. It defines and verifies the static schema/repository assets; it does not install validators, create commands, restructure a live repository, or activate a pilot project.

The Automation library consumes this standard through 12 commands and complete SRV-001..080 treatment. The [Pilot](../Pilot/Pilot_Index.md) validated three generated control planes, all profiles, 24 all-scope instances, and negative serialization/mutation cases. The Product OS v1.0 release candidate is technically finalized; the next action is the Product OS authority decision.

---

# 11. Final Index Principle

> **The repository stores governed representations; schemas make their structure testable; Product OS artifacts and authorities still own their meaning.**
