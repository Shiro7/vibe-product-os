# Product OS v1.0 — Governance, Trace, Change, Source, and Evidence Schemas

~~~yaml
document_id: FRAMEWORK-GOVERNANCE-TRACE-CHANGE-SOURCE-EVIDENCE-SCHEMAS
version: 0.1.0
status: WORKING_DRAFT
completion_state: GOVERNANCE_TRACE_SOURCE_EVIDENCE_SCHEMAS_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
schemas: [governance-record, trace-graph, source-evidence]
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines typed machine records for governance variants, trace graph nodes/edges, material changes, sources, claims, evidence, and their temporal/integrity relationships.

---

# 2. Governance Record Variants

One discriminated schema supports:

1. `DECISION`
2. `RISK`
3. `ASSUMPTION`
4. `OPEN_QUESTION`
5. `CHANGE`
6. `STANDARD_APPLICABILITY`
7. `EXCEPTION`
8. `WAIVER`

Every record shares ID, project/scope, owner, authority, status, sources/evidence, affected artifacts, created/updated/effective/review/expiry, supersession, and reopen conditions. Its `payload` is selected by `record_type`.

---

# 3. Decision Payload

Required: question/context, options considered, decision or explicit unresolved state, rationale, scope, authority, workflow status, lifecycle disposition, conditions, effective/expiry, supersession, and downstream impacts.

Tool approval/comment/check state may be a source; it is not the decision unless the mapped record carries competent authority.

---

# 4. Risk Payload

Required: threat/uncertainty/event, causes, affected objectives/assets/people, likelihood, impact, severity/rating method, controls, owner, treatment, residual risk, acceptance authority, review/trigger, evidence, and linked changes/incidents.

Schema validity cannot accept risk; acceptance remains an authority event.

---

# 5. Assumption and Question Payloads

Assumption requires statement, confidence, rationale, impact, validation method, owner, due/expiry, and validated/rejected outcome.

Open question requires question, why/impact, blocking status, owner, due event, answer source, required decision, and resolution/supersession.

Unanswered data remains explicit and cannot be converted into defaults by serializers.

---

# 6. Change Payload

Required:

- change identity/type/origin/requested outcome;
- exact proposed/current subjects and versions;
- trigger, rationale, materiality candidate;
- graph traversal root and affected-object candidates;
- scope, risk, standards, profile, repository/tool/schema impacts;
- authority/approval, actions, verification, acknowledgements;
- baseline/gate/evidence dispositions;
- execution, rollback/forward-fix, residual risk, closure evidence.

The record preserves proposal, assessment, decision, execution, verification, and closure as separate states.

---

# 7. Standard Applicability, Exception, and Waiver

Applicability records standard/profile/clause, exact scope, status, triggers, reason, authority, evidence, obligations, downstream artifact/gate allocation, review, and reopen.

Exception/waiver records obligation, deviation, scope, rationale, risk, compensating controls, approvers/authority, effective/expiry, monitoring, evidence, and removal/reopen. Expiry never silently renews.

---

# 8. Trace Graph Schema

The graph package contains:

~~~text
graph identity/version/project/snapshot time
node array
edge array
tombstone array
validation/coverage metadata
source/change/provenance
~~~

Node minimum:

- node ID/type/subject ID/version/scope;
- canonical owner/location and lifecycle status;
- artifact/baseline/gate/tool/source/evidence identity as applicable;
- valid/effective time and supersession.

Edge minimum:

- edge ID/type;
- source/target node IDs and versions;
- direction/scope/status/confidence;
- asserted by/at, source/evidence/change refs;
- valid-from/to and supersession.

---

# 9. Trace Semantic Validation

Beyond schema:

- node/edge IDs unique;
- all edge endpoints resolve;
- edge type domain/range/cardinality match Traceability Graph contract;
- no active self-edge where prohibited;
- version/time intervals are coherent;
- required paths and coverage exist;
- tombstones prevent deleted-node resurrection;
- orphan/conflict/gap states are visible;
- derived graph views do not edit canonical nodes/edges.

---

# 10. Source/Evidence Record Variants

One schema supports:

- `SOURCE`: received/native source identity, authority, reliability, provenance, access, retention, extraction;
- `CLAIM`: atomic assertion, subject/scope, information state, confidence, owner, supporting/contradicting evidence;
- `EVIDENCE`: method/result/object identity, candidate/environment/time, integrity/custody, fitness, retention;
- `CLAIM_EVIDENCE_BINDING`: relationship, support/contradict/qualify, strength, scope, reviewer, validity;
- `EVIDENCE_PACK`: purpose/scope, claims, evidence membership, manifest/digests, reviewer, completeness/limitations.

---

# 11. Source Identity

Required as applicable:

- source ID/type/title/owner/provider;
- exact native/repository/file/tool identity and revision;
- received/observed/effective period;
- authority and reliability dimensions;
- extraction/translation/transformation method;
- confidentiality, privacy, license, residency, access, retention;
- digest/signature/custody;
- contradictions, limitations, supersession.

A link alone is not a source identity.

---

# 12. Evidence Identity and Integrity

Evidence records:

- evidence and claim IDs;
- exact subject/candidate/build/design/repository/environment/data/identity scope;
- verification method/tool/version/configuration;
- execution/observation time and actor/verifier;
- raw object locator plus digest/size/media type;
- result and expected criterion;
- provenance/custody/transforms/redactions;
- fitness, sufficiency contribution, admissibility, limitations;
- access/retention/expiry/legal hold;
- invalidation/reuse/supersession.

Screenshots/logs/reports are objects; the evidence record explains what they prove.

---

# 13. Content-Addressed Evidence Layout

Where the repository stores evidence objects:

~~~text
evidence/
├── manifests/
│   └── <evidence-id>.evidence.json
└── objects/
    └── sha256/
        └── <first-two-hex>/
            └── <full-hex-digest>.<extension>
~~~

Original filename, source locator, media type, size, digest, collection method, and chain of custody live in the manifest. Restricted evidence may live externally; the manifest records exact approved location and integrity without exposing content.

---

# 14. Change-to-Evidence Invalidation

On material change:

1. traverse affected claims/evidence;
2. classify each as valid, narrowed, stale, invalidated, superseded, or re-execution required;
3. preserve prior evidence/history;
4. update baseline/gate/candidate/release implications;
5. record authority and rationale;
6. collect replacement evidence before closure where required.

Schema compatibility does not imply evidence reusability.

---

# 15. Final Governance/Evidence Principle

> **Typed records make decisions, risks, changes, sources, claims, and evidence addressable; only authority, provenance, method, and lifecycle make them trustworthy.**

