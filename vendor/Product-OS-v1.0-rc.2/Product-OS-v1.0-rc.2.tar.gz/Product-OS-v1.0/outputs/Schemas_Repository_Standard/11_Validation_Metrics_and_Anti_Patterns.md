# Product OS v1.0 — Schema and Repository Validation, Metrics, and Anti-Patterns

~~~yaml
document_id: FRAMEWORK-SCHEMA-REPOSITORY-VALIDATION-METRICS-ANTI-PATTERNS
version: 0.1.0
status: WORKING_DRAFT
completion_state: EIGHTY_VALIDATIONS_AND_FORTY_ANTI_PATTERNS_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
validation_rule_count: 80
anti_pattern_count: 40
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines deterministic validation and failure patterns for Product OS schemas, catalogs, repositories, project control, artifacts, lifecycle records, tool/AI exchange, migrations, evidence, and archives.

Validation outcomes are `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or governed `NOT_APPLICABLE`. Structural PASS is not Product OS approval.

---

# 2. Validation Rules — 80

## A. Framework, dialect, schemas, and catalogs — SRV-001..010

1. **SRV-001 — Framework/project separation:** framework assets contain no live project/client truth and project instances pin a released framework.
2. **SRV-002 — Dialect declaration:** every schema declares JSON Schema 2020-12 exactly.
3. **SRV-003 — Schema identity:** every schema has one unique canonical `$id` and semantic schema version.
4. **SRV-004 — Catalog resolution:** every canonical schema ID resolves locally through the pinned schema catalog.
5. **SRV-005 — No network fallback:** governed validation performs no uncontrolled remote `$ref` retrieval.
6. **SRV-006 — JSON syntax:** every schema/catalog/JSON example parses as UTF-8 JSON with no duplicate-key acceptance.
7. **SRV-007 — Schema reference integrity:** every `$ref` target/schema fragment resolves and no unapproved schema cycle exists.
8. **SRV-008 — Catalog integrity:** schema, artifact, gate, and profile catalog IDs/versions/entries are unique and internally consistent.
9. **SRV-009 — Artifact catalog cardinality:** machine catalog contains exactly 281 current artifact IDs with no `-000` alias counted.
10. **SRV-010 — Gate/profile cardinality:** gate catalog contains exactly 13 gates and profile catalog exactly P1/P2/P3 with current semantics.

## B. Repository, topology, paths, and file anatomy — SRV-011..020

11. **SRV-011 — Topology decision:** project uses one registered topology with scope, drivers, repositories, owner, authority, and reopen triggers.
12. **SRV-012 — Repository identity:** every repository/root has exact native identity, canonical name, roles, owner, and revision boundary.
13. **SRV-013 — Project-specific names:** canonical repository/module names are preserved instead of generic label drift.
14. **SRV-014 — Root containment:** every governed path resolves under an approved repository/evidence/archive root.
15. **SRV-015 — Path portability:** paths are normalized relative POSIX paths with permitted lowercase ASCII slugs and no case collision.
16. **SRV-016 — Traversal/symlink safety:** no `..`, home/root shorthand, uncontrolled variable, or unregistered symlink escape is accepted.
17. **SRV-017 — File role:** every governed file has one primary role and edit behavior matching that role.
18. **SRV-018 — Markdown anatomy:** artifact Markdown has bounded schema/versioned front matter and required content sections or references.
19. **SRV-019 — Sidecar pair:** sidecar/content identity, version, digest, location, and lifecycle remain coherent through move/change.
20. **SRV-020 — No empty theater:** no project file/directory exists solely for future appearance; activation or framework role is explicit.

## C. Project manifest, lock, profile, modules, and repositories — SRV-021..030

21. **SRV-021 — Bootstrap completeness:** manifest, framework lock, repository index, profile composition, and artifact register exist and cross-reference.
22. **SRV-022 — Project identity:** project ID/name/scope/status/owner are stable and consistent across control files.
23. **SRV-023 — Framework lock completeness:** all governing framework/catalog/schema/profile/adapter versions and immutable revisions/digests are pinned.
24. **SRV-024 — No floating baseline:** branch/latest/mutable URL is not sole framework or project baseline identity.
25. **SRV-025 — Repository index coverage:** all canonical/control/spec/source/evidence/archive roots in scope are registered exactly once by role.
26. **SRV-026 — Default profile:** exactly one P1/P2/P3 default exists and does not act as risk acceptance.
27. **SRV-027 — Domain override:** every override has trigger, reason, authority, evidence, effective scope, and cannot weaken mandatory floor.
28. **SRV-028 — Package composition:** every activated artifact has exactly one current canonical package/native membership for its content responsibility.
29. **SRV-029 — Module activation:** conditional modules have governed applicability, affected artifacts/GOV-009, package impacts, and reopen conditions.
30. **SRV-030 — Lifecycle state:** active phases/modes/gates are explicit but do not claim gate outcomes from manifest status.

## D. Artifact catalog, register, instances, and composites — SRV-031..040

31. **SRV-031 — Catalog identity consistency:** artifact ID/name/family/phase/class/activation/profile codes match the Master Catalog.
32. **SRV-032 — Register completeness:** every activated, pending, governed N/A, stale, superseded, or retired artifact has one current GOV-002 entry.
33. **SRV-033 — Status separation:** registry, artifact, applicability, decision, verification, approval, and change-impact statuses are distinct valid enums.
34. **SRV-034 — Canonical location:** each register entry resolves to an exact real location/native identity or explicit missing state.
35. **SRV-035 — N/A completeness:** `NOT_APPLICABLE` has reason, scope, owner, authority, date, sources/evidence, implications, review, and reopen.
36. **SRV-036 — Artifact anatomy:** every instance has identity/contract/version/owner/scope/content/verification/evidence/handoff/reopen/history.
37. **SRV-037 — Information typing:** facts, assumptions, decisions, requirements, questions, risks, checks, and exceptions preserve typed minimums.
38. **SRV-038 — Composite addressability:** each member ID/version/owner/status/locator is separately addressable in a composite.
39. **SRV-039 — No duplicate ownership:** references/mirrors/views do not create a second current canonical semantic representation.
40. **SRV-040 — Split/merge continuity:** package migration preserves IDs, histories, links, statuses, approvals, evidence, and supersession.

## E. Governance, traceability, sources, claims, and evidence — SRV-041..050

41. **SRV-041 — Governance discriminator:** record type selects the matching decision/risk/assumption/question/change/applicability/exception/waiver payload.
42. **SRV-042 — Governance authority:** every material governance record names owner and competent authority without inference from repository permission.
43. **SRV-043 — Change lifecycle:** proposal, assessment, decision, execution, verification, acknowledgement, and closure remain separate.
44. **SRV-044 — Trace identity:** graph/node/edge/tombstone IDs and versions are unique within exact project/snapshot scope.
45. **SRV-045 — Edge integrity:** every edge endpoint/type/domain/range/cardinality/time/status resolves under Traceability Graph rules.
46. **SRV-046 — Required paths:** required lifecycle/standards/evidence/tool/release/operations paths have complete or explicit gap/N/A state.
47. **SRV-047 — Source identity:** source includes exact native/repository identity/revision, authority/reliability, provenance, access, retention, and limitations.
48. **SRV-048 — Claim atomicity:** each claim has one addressable assertion, subject/scope/state/owner and supporting/contradicting bindings.
49. **SRV-049 — Evidence identity:** evidence binds exact claim/subject/candidate/method/result/time/actor/object/digest and limitations.
50. **SRV-050 — Evidence continuity:** custody, transforms/redactions, fitness, retention/expiry, invalidation, supersession, and archive are complete.

## F. Gates, baselines, handoffs, candidates, releases, and operations — SRV-051..060

51. **SRV-051 — Gate identity:** every gate decision uses one cataloged G0–G8 ID and exact decision artifact/scope/version.
52. **SRV-052 — Outcome family:** G0–G6B, G7, and G8 use only their permitted outcome vocabularies.
53. **SRV-053 — Gate evidence/checks:** every required check has status/evidence or governed N/A and no percentage self-approval.
54. **SRV-054 — Gate authority:** decision workflow/lifecycle/outcome/authority/time/validity/reopen are structurally and semantically separate.
55. **SRV-055 — Condition completeness:** each condition has owner, authority, due event, restriction, evidence, monitoring, consequence, and closure.
56. **SRV-056 — Baseline reproducibility:** artifact/native membership and framework/catalog/schema/register/evidence/gate versions reproduce the baseline.
57. **SRV-057 — Handoff completeness:** sender/receiver/scope/members/obligations/open items/evidence/acceptance/acknowledgement/reopen are explicit.
58. **SRV-058 — Candidate exactness:** source/build/digest/schema/config/environment/data/design/baseline and deviations identify one candidate.
59. **SRV-059 — G7 separation:** release authorization, release object, deployment execution, deviation, and post-release validation are different records.
60. **SRV-060 — Operational continuity:** live identity/evidence/OBL/G8 outcome/change/re-entry routes are linked without rewriting prior baselines.

## G. Tool mappings, AI, exchange, versioning, and migration — SRV-061..070

61. **SRV-061 — Mapping identity:** every tool mapping names exact logical subject, tool system/container/native object/revision, role, status, and owner.
62. **SRV-062 — Sync contract:** synchronization uses an approved mode/direction/field allow-list/protected fields/trigger/automation/conflict policy.
63. **SRV-063 — Immutable evidence locator:** baseline/evidence mappings use immutable/versioned locator or integrity-protected archive.
64. **SRV-064 — AI run identity:** system/model/agent/config/task/run/role/mode/context/authority/actions/tools/results/evidence are exact.
65. **SRV-065 — AI action control:** each consequential action has class, target, expected/prohibited effect, authority, preflight, result, verification, and recovery.
66. **SRV-066 — Exchange envelope:** source/target/schema/catalog/base snapshot/objects/relationships/tombstones/attachments/integrity/exclusions validate.
67. **SRV-067 — Import promotion:** imports remain proposed until identity/provenance/conflict/authority/change/evidence review completes.
68. **SRV-068 — Version compatibility:** syntax/schema/semantic/catalog/reference/behavior/authority/evidence/repository/exchange dimensions are assessed.
69. **SRV-069 — Migration completeness:** inventory/crosswalk/transform/dry-run/checkpoint/cutover/validation/rollback/acknowledgement/evidence exist.
70. **SRV-070 — Brownfield restraint:** initial overlay registers current assets without unauthorized rename/move/rewrite/regeneration.

## H. Security, access, retention, generated content, evidence, and archive — SRV-071..080

71. **SRV-071 — Data classification:** every governed file/record/object inherits or declares approved access classification.
72. **SRV-072 — Least privilege:** human/service/app/bot/AI permissions match purpose, owner, authority, environment, review/expiry, and revocation.
73. **SRV-073 — Secret exclusion:** no secret value appears in schemas, examples, manifests, specs, mappings, logs, outputs, or indexes.
74. **SRV-074 — Generated provenance:** generated/derived content declares generator/schema/source revisions/digest/freshness and `do_not_edit`.
75. **SRV-075 — Evidence object integrity:** manifest/object path/digest/size/media/source/custody/access/retention all agree.
76. **SRV-076 — Retention disposition:** purpose/start/period/hold/privacy/owner/location/disposition/restore/review are governed.
77. **SRV-077 — Archive completeness:** archive preserves identity, interpreting schemas/catalogs, relationships/tombstones, integrity, access, retention, restore route.
78. **SRV-078 — Destructive target safety:** delete/overwrite/move scope is exact, authorized, contained, recoverable, previewed, and verified.
79. **SRV-079 — Supply-chain integrity:** schemas/validators/generators/templates/migrations/dependencies are pinned, reviewed, least-privilege, and evidenced.
80. **SRV-080 — Recovery and exit:** framework/project/source/native/evidence/access/history can be restored/migrated with validated meaning and integrity.

---

# 3. Anti-Patterns — 40

1. **SRA-001 — Schema equals truth:** treating structural validity as factual correctness or approval.
2. **SRA-002 — One giant schema:** forcing all 281 artifacts into one monolithic content object.
3. **SRA-003 — Schema per file explosion:** generating 281 mandatory physical schema/file copies regardless of applicability/profile.
4. **SRA-004 — Floating latest:** pinning framework/schema to branch/latest/mutable URL only.
5. **SRA-005 — Network `$ref`:** governed validation silently downloads unpinned schemas.
6. **SRA-006 — Parser roulette:** YAML custom tags/merge keys/aliases/implicit types produce different data across tools.
7. **SRA-007 — Open typo bucket:** uncontrolled additional properties hide misspelled governed fields.
8. **SRA-008 — Null erases state:** missing/null/unknown/N/A are used interchangeably.
9. **SRA-009 — Path equals ID:** rename/move creates a new logical artifact or loses history.
10. **SRA-010 — Absolute local truth:** a developer workstation path is stored as canonical portable location.
11. **SRA-011 — Traversal/symlink escape:** generated or destructive actions follow unresolved paths outside project root.
12. **SRA-012 — Generic repo drift:** actual repository/module identities become backend/frontend/mobile/database placeholders.
13. **SRA-013 — Empty template forest:** project contains many unused folders/files to look comprehensive.
14. **SRA-014 — Framework polluted by project:** client facts and approvals enter reusable framework source.
15. **SRA-015 — Project copies framework:** every project forks the entire framework and silently diverges.
16. **SRA-016 — Profile changes semantics:** P1 drops IDs, evidence, authority, or lifecycle obligations.
17. **SRA-017 — Composite status collapse:** one package status is assigned to all member artifacts.
18. **SRA-018 — Alias counted as artifact:** `-000` package alias increases the 281 count.
19. **SRA-019 — Missing means N/A:** absent content is treated as an approved applicability decision.
20. **SRA-020 — Duplicate canonical package:** same artifact content has two current owners/locations.
21. **SRA-021 — Front matter is register:** file metadata silently competes with GOV-002 lifecycle truth.
22. **SRA-022 — Markdown table database:** typed/high-fidelity/native data is flattened into fragile tables.
23. **SRA-023 — Copy native truth:** Figma/code/test/cloud/observability content is copied and then treated as current.
24. **SRA-024 — Link-only evidence:** URL/screenshot/file name is considered sufficient evidence identity.
25. **SRA-025 — Digest equals trust:** matching bytes are treated as proof of truth, authority, or safety.
26. **SRA-026 — Gate by schema:** valid gate JSON is treated as an authorized decision.
27. **SRA-027 — Baseline current-main:** mutable current state is used instead of exact membership/revisions.
28. **SRA-028 — Receipt equals acceptance:** handoff file presence or message delivery is treated as acknowledgement.
29. **SRA-029 — Release object equals G7:** tag/release/deployment state replaces authorization.
30. **SRA-030 — AI record grants authority:** complete AI run metadata is treated as permission or approval.
31. **SRA-031 — Import auto-promotes:** schema-valid external content overwrites canonical owners.
32. **SRA-032 — Last write wins:** synchronization resolves governed conflict by timestamp alone.
33. **SRA-033 — Default invents decision:** migration fills missing owner/approval/N/A/risk/evidence values.
34. **SRA-034 — Copy-only migration:** records move without IDs, versions, history, refs, permissions, behavior, or evidence validation.
35. **SRA-035 — Permanent dual write:** old/new schemas or systems remain competing canonical writers.
36. **SRA-036 — Brownfield big bang:** adoption starts by moving/renaming live source and regenerating everything.
37. **SRA-037 — Edit generated output:** derived files are patched instead of their sources/generator.
38. **SRA-038 — Secrets in control plane:** credentials/personal production data enter examples, manifests, logs, or evidence indexes.
39. **SRA-039 — Archive dump:** old files are moved into an unindexed folder without schemas, integrity, retention, or restore route.
40. **SRA-040 — Repository as backup claim:** Git history alone is assumed to preserve native tools, evidence, permissions, packages, and operational state.

---

# 4. Metrics

| Metric | Definition |
|---|---|
| Schema syntax coverage | parseable schema files ÷ 21 |
| Schema ID/reference coverage | unique cataloged schemas with all refs resolved ÷ 21 |
| Catalog reconciliation | expected IDs matching authoritative catalog ÷ expected IDs |
| Project bootstrap conformance | valid current core control files ÷ five required files |
| Artifact register coverage | activated/pending/N/A/stale/superseded/retired obligations registered ÷ expected obligations |
| Canonical membership coverage | current artifacts with one package/native membership ÷ expected current artifacts |
| Exact locator coverage | locations with repository/native ID and revision/digest ÷ applicable locations |
| Cross-record reference health | resolved refs ÷ all active refs |
| Schema migration readiness | active schemas with compatibility/migration disposition ÷ schemas affected by target upgrade |
| Generated freshness | current derived files matching declared source/generator versions ÷ active derived files |
| Evidence continuity | required evidence with valid manifest/integrity/access/retention ÷ required evidence |
| Broken/duplicate/drift rate | unresolved structural/identity/reference/canonical conflicts ÷ active governed objects |
| Retention/archive readiness | due objects with governed disposition and validated restore/exit ÷ due objects |
| Automation-ready rule coverage | SRV rules with deterministic command implementation ÷ 80; measured in next workstream |

Governed N/A remains separately visible and never inflates success.

---

# 5. Assurance Procedure

1. Freeze framework/schema/catalog/project/repository revisions and exact scope.
2. Parse all JSON/YAML/Markdown metadata deterministically.
3. Validate schemas against dialect/meta-schema and resolve local refs.
4. Validate catalogs and test vectors.
5. Validate project control and repository containment.
6. Validate artifact/profile/package/native/evidence relationships.
7. Validate governance/trace/gate/baseline/handoff/tool/AI/exchange semantics.
8. Run security/retention/generated/archive/destructive-scope checks.
9. Classify findings by gate/authority/materiality and assign remediation.
10. Re-run failed/dependent checks and preserve results/evidence.
11. Obtain independent review where profile/risk requires.
12. Publish technical result without claiming Product OS approval.

---

# 6. Final Validation Principle

> **Conformance is a layered proof: parseable, schema-valid, cataloged, resolvable, semantically coherent, authorized, evidenced, and lifecycle-correct.**

