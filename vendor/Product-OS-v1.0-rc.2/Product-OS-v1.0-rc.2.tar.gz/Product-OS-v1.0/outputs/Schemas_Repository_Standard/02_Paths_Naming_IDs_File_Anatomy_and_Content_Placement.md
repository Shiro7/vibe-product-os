# Product OS v1.0 — Paths, Naming, IDs, File Anatomy, and Content Placement

~~~yaml
document_id: FRAMEWORK-PATHS-NAMING-IDS-FILE-ANATOMY-CONTENT-PLACEMENT
version: 0.1.0
status: WORKING_DRAFT
completion_state: PATH_NAMING_FILE_ANATOMY_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines deterministic physical naming and content placement while preserving stable logical IDs and profile-dependent packaging.

---

# 2. Naming Domains

| Subject | Canonical form | Example |
|---|---|---|
| Logical artifact ID | Existing uppercase catalog ID | `REQ-001` |
| Nested governed object ID | Uppercase typed prefix plus stable scope sequence | `REQ-FUNC-042` |
| Project ID | Uppercase stable slug, 3–64 characters | `EXAMPLE-COMMERCE` |
| Schema `$id` | Versioned URN | `urn:product-os:schema:v1:artifact-register` |
| Directory | lowercase kebab-case | `phase-04-requirements` |
| Independent artifact file | lowercase artifact ID + `--` + slug | `req-001--system-requirements-specification.md` |
| Composite package | phase/domain + `--` + pack slug | `phase-04--requirements-pack.md` |
| Control file | fixed lowercase kebab-case | `artifact-register.yaml` |
| Schema file | lowercase kebab-case + `.schema.json` | `gate-decision.schema.json` |
| Evidence object | algorithm/digest path | `objects/sha256/ab/abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789` |
| Migration | ordered version pair + slug | `v1-to-v2--artifact-register.json` |

Names are labels. IDs preserve identity through rename, translation, move, and tool migration.

---

# 3. Path Rules

1. Repository-relative POSIX-style paths are canonical in manifests.
2. Paths are normalized, contain no `.`/`..` traversal segments, backslashes, control characters, unexpanded variables, or home-directory shorthand.
3. Absolute local paths are runtime observations and never portable canonical locations.
4. Case-only collisions are prohibited.
5. Unicode content is supported; physical path slugs use lowercase ASCII letters, digits, and hyphens for cross-platform portability.
6. Reserved OS names, trailing dots/spaces, and ambiguous normalization are prohibited.
7. Symlinks require registry entry, approved target boundary, and loop/escape validation; project content does not rely on unregistered symlinks.
8. A path change updates GOV-002, repository index, mappings, traceability, derived views, and affected evidence locators.
9. File extensions communicate serialization/content; changing extension without content conversion is prohibited.
10. Secret-bearing paths are never indexed with secret value material.

---

# 4. File Role Classification

Every governed file has one primary role:

| Role | Edit behavior |
|---|---|
| `FRAMEWORK_REFERENCE` | Edited only through framework change/release |
| `PROJECT_CONTROL` | Human/automation edits under field ownership and schema |
| `CANONICAL_CONTENT` | Edited by artifact/native owner under contract |
| `NATIVE_REFERENCE` | Contains identity/locator, not copied native truth |
| `DERIVED_VIEW` | Generated only; change inputs/generator instead |
| `EVIDENCE_MANIFEST` | Append/version under evidence/custody rules |
| `EVIDENCE_OBJECT` | Immutable or controlled original; never edited in place |
| `MIGRATION` | Versioned executable/declarative transformation with review |
| `ARCHIVE` | Read-only under retention/restore rules |
| `EXAMPLE_TEST_VECTOR` | Framework example; excluded from project truth |

---

# 5. Markdown Artifact Anatomy

An independently authored Markdown artifact uses:

~~~yaml
---
schema_id: urn:product-os:schema:v1:artifact-instance
schema_version: 1.0.0
record_role: ARTIFACT_CONTENT_PROJECTION
artifact_id: REQ-001
artifact_version: 1.2.0
project_id: EXAMPLE-COMMERCE
contract_id: CONTRACT-REQ-001
contract_version: 0.1.0
canonical_register_ref: .product-os/artifact-register.yaml#REQ-001
profile: P2
artifact_status: IN_REVIEW
applicability: APPLICABLE
decision_status: IN_REVIEW
verification_status: PARTIAL
owner: ROLE-PRODUCT-OWNER
last_updated: 2026-08-12T00:00:00Z
content_digest: null
---
~~~

The body contains or links the Shared Core Contract sections:

`Purpose`, `Scope`, `Applicability`, `Required Inputs`, `Required Questions`, `Required Decisions`, `Required Outputs`, `Confirmed Facts`, `Assumptions`, `Decisions`, `Requirements`, `Open Questions`, `Risks and Dependencies`, `Verification`, `Evidence`, `Exceptions`, `Downstream Handoff`, `Exit Criteria`, `Reopen Conditions`, and `Change History`.

The full GOV-002 register remains canonical for registry lifecycle/location. Front matter is a versioned content projection checked for drift.

---

# 6. YAML/JSON Artifact Anatomy

A typed artifact instance contains:

~~~text
schema identity/version
record identity/role
artifact metadata and status dimensions
purpose/scope/applicability
typed content collections
artifact-specific payload
verification/evidence
exit/handoff/reopen/change history
~~~

If the artifact’s primary native form is Figma, source code, architecture model, test platform, database, or observability system, the repository artifact stores the governed index/mapping/handoff—not a lossy full copy.

---

# 7. Composite Package Contract

A composite file or register is permitted when profile/ownership allow. It has:

- package ID/type/path/version/schema;
- exact member artifact IDs and versions;
- addressable section/key/pointer for each member;
- member owner, applicability, statuses, evidence, and change state;
- package owner responsible only for physical integrity;
- no duplicate current membership in another canonical package;
- split/merge migration and supersession lineage.

Example membership:

~~~yaml
package_id: PKG-PHASE-04-P1
package_type: COMPOSITE
path: lifecycle/phase-04-requirements/phase-04--requirements-pack.md
members:
  - artifact_id: REQ-001
    locator: '#req-001-system-requirements-specification'
  - artifact_id: REQ-010
    locator: '#req-010-acceptance-and-verification-matrix'
  - artifact_id: REQ-014
    locator: '#req-014-requirements-handoff'
~~~

This package does not create `REQ-000` as a 282nd artifact; aliases remain packaging/navigation only.

---

# 8. Sidecar Rules

Use a sidecar when the canonical content format cannot carry reliable metadata.

~~~text
<content-file>.<ext>
<content-file>.<ext>.artifact.yaml
~~~

The sidecar records artifact/native identity, role, version/digest, source/owner, mapping, access, retention, and evidence. It cannot invent content status or approval.

Moving either file requires atomic mapping update or explicit broken-pair state.

---

# 9. Canonical Content Placement

| Content | Default location |
|---|---|
| GOV-001..009 | `governance/` or protected external system registered from there |
| INIT | `lifecycle/phase-00-initialization/` |
| DISC | `lifecycle/phase-01-discovery/` |
| BUS | `lifecycle/phase-02-business-architecture/` |
| PROD | `lifecycle/phase-03-product-definition/` |
| REQ | `lifecycle/phase-04-requirements/` |
| EXP | `lifecycle/phase-05-experience/` |
| DES | `lifecycle/phase-06-product-design/` plus Figma mapping |
| ARC | `lifecycle/phase-07-solution-architecture/` |
| ENG | `lifecycle/phase-08-engineering-readiness/` |
| IMP | `lifecycle/phase-09-implementation/` plus exact source repository mapping |
| VRL | `lifecycle/phase-10-verification-release/` |
| OPS | `lifecycle/phase-11-operations-evolution/` plus operational-system mapping |
| Tool adapters | `tools/<tool>/` or `.product-os/mappings/` by record role |
| Evidence manifests/objects | `evidence/manifests/` and `evidence/objects/` or registered external evidence store |
| Generated state/views | `.product-os/state/` and `.product-os/derived/` |
| Superseded/retired material | `archive/` with active-register pointer and retention |

---

# 10. Cross-File Reference Rules

- Logical references use IDs first; path/locator is secondary.
- Relative links are allowed for navigation but cannot be sole identity.
- JSON/YAML references use stable IDs or JSON Pointer where the target is versioned.
- Markdown anchors used for composite membership are explicit and stable; heading rename provides redirect/migration mapping.
- `$ref` resolves through the schema catalog, never by uncontrolled network retrieval during governed validation.
- External/native references include tool system, container, native ID, revision, role, and access/retention status.
- Broken references are preserved and reported; they are not deleted to make validation green.

---

# 11. Generated and Derived File Header

Every generated file declares:

~~~yaml
generated: true
generator_id:
generator_version:
schema_id:
schema_version:
source_refs: []
source_revisions: []
generated_at:
content_digest:
freshness_status:
do_not_edit: true
~~~

Manual correction occurs in canonical inputs or generator rules, followed by regeneration and verification.

---

# 12. File Creation Decision

Create a separate file only when one or more apply:

- independent owner or approval authority;
- independent lifecycle/status/change rate;
- separate access/retention/classification;
- independent baseline/gate/evidence role;
- native format or tooling requirement;
- size/complexity would make a composite non-operational;
- profile or domain override requires stronger assurance.

Otherwise use an addressable section/register entry and preserve the logical ID.

---

# 13. Final Placement Principle

> **Put content where its owner can maintain its native truth; put identity and lifecycle in the control plane; put proof in evidence; put rebuildable output in derived space.**
