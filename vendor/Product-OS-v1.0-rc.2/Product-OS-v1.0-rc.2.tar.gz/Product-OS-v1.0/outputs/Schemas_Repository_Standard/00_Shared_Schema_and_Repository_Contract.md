# Product OS v1.0 — Shared Schema and Repository Contract

~~~yaml
contract_id: SHARED-SCHEMA-REPOSITORY-CONTRACT
contract_version: 0.1.0
contract_status: WORKING_DRAFT
completion_state: SHARED_SCHEMA_REPOSITORY_CONTRACT_COMPLETE
applies_to: ALL_PRODUCT_OS_FRAMEWORK_PROJECT_SCHEMA_REPOSITORY_AND_EXCHANGE_ASSETS
logical_artifact_scope: 281
gate_scope: [G0, G1, G2, G3A, G3B, G4A, G4B, G5A, G5B, G6A, G6B, G7, G8]
schema_dialect: https://json-schema.org/draft/2020-12/schema
yaml_version: 1.2.2
catalog_source: ../Product_OS_Master_Artifact_Catalog.md
classification_source: ../Classification_Rules.md
mapping_source: ../Spec_Kit_Figma_GitHub_Mapping/Spec_Kit_Figma_GitHub_Mapping_Index.md
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This contract defines obligations inherited by every Product OS schema, catalog, manifest, repository, directory, file, sidecar, front-matter block, generated view, export, migration, archive, and project-instance package.

Specialized files and schemas refine this contract. No lower layer may silently weaken it.

---

# 2. Scope

The contract applies to:

- Product OS framework source and distributed releases;
- project-instance repositories, overlays, workspace roots, and federated repository indexes;
- all 281 artifact identities and their physical representations;
- project, framework lock, repository, profile, artifact, governance, trace, source/evidence, gate, baseline, handoff, mapping, AI, and exchange records;
- JSON, YAML, Markdown, native-tool references, binary evidence, generated views, and archives;
- P1/P2/P3 packaging, domain overrides, conditional modules, brownfield adoption, versioning, migration, and retirement;
- human, AI, import/export, CI, and future command/automation consumers.

---

# 3. Non-Scope

This contract does not:

- approve a project, repository, schema migration, tool, automation, or pilot;
- define project-specific artifact applicability, owners, locations, permissions, or retention;
- make structural validation proof of factual correctness, approval, verification, or release authorization;
- flatten Figma, source code, CI, cloud, database, observability, or other native systems into Markdown;
- implement validator commands, generators, hooks, CI workflows, or synchronization code;
- prescribe one repository topology for every organization;
- require creation of every possible directory/file;
- replace semantic Core Artifact Contracts or tool-native schema/API contracts.

---

# 4. Governing Objects

| Object | Meaning | Minimum identity |
|---|---|---|
| Framework release | Versioned Product OS rules, catalogs, contracts, schemas, profiles, adapters, migrations | release ID/version, source revision, digest, status |
| Schema | Machine-readable structural contract | canonical `$id`, dialect, version, local path, status, digest |
| Schema catalog | Resolver mapping canonical schema IDs to distributable paths | catalog ID/version, entries, integrity |
| Project manifest | Root project identity and active Product OS configuration | project ID, framework lock, profile, lifecycle, control refs |
| Framework lock | Exact versions/digests of framework dependencies | lock ID/version, asset entries, source revision |
| Repository index | All repositories/roots/modules/native ownership in project scope | index ID/version, repository entries, owner |
| Profile composition | P1/P2/P3 and domain physical packaging resolution | composition ID/version, packages, artifact membership |
| Artifact catalog | Framework inventory of the 281 logical artifact contracts | catalog ID/version, 281 entries |
| Artifact register | Project GOV-002 implementation/view | register ID/version, exact project artifact entries |
| Artifact instance | One governed artifact’s metadata/content representation | artifact ID/version, schema, contract, owner, status, location |
| Physical package | File/section/register/view containing one or more separately addressable subjects | package ID/path/type/members/version |
| Evidence object | Original or normalized proof plus manifest | evidence ID, claim binding, digest, source, retention |
| Generated view | Rebuildable output from canonical inputs | view ID, generator/schema/source versions, digest, freshness |
| Archive object | Retired/historical preserved content | archive ID, original identity, retention, integrity, restore route |

---

# 5. Universal Invariants

1. Logical identity precedes physical path.
2. The framework and project instance remain separate even when stored in one monorepo.
3. A project pins exact framework and schema versions; floating “latest” is navigation, not baseline identity.
4. The 281 artifact IDs remain canonical; files, sections, directories, tables, Figma nodes, issues, and database rows are representations.
5. P1/P2/P3 alter physical composition, not logical obligation or authority.
6. Composite files preserve member artifact IDs, owners, applicability, states, version, evidence, and handoff separately.
7. Missing is not `NOT_APPLICABLE`; N/A is an explicit validated record.
8. A schema validates structure, not truth, decision authority, evidence sufficiency, or gate outcome.
9. Schema `$id`, schema version, artifact contract version, artifact version, repository revision, and framework release remain separate.
10. Every schema declares JSON Schema 2020-12 explicitly.
11. YAML inputs use YAML 1.2.2 Core-compatible constructs and normalize to a JSON-compatible object graph before schema validation.
12. Duplicate keys, custom tags, merge keys, cyclic aliases, and parser-dependent implicit types are prohibited in governed YAML.
13. Unknown values are explicit through governed state or `null` where the schema permits; they are not invented or omitted when required.
14. Repository paths use stable naming rules; renames/moves preserve identity and change history.
15. Canonical content has one owner/location per exact field/scope/version; mirrors and projections declare their role.
16. Generated/derived content is isolated, provenance-marked, reproducible, and never manually promoted by editing the output.
17. Evidence files are never renamed as proof of content identity; digest, source, claim, method, candidate, and time remain required.
18. Sensitive data and secrets use minimum necessary storage; secret values do not enter manifests, schemas, examples, logs, or evidence indexes.
19. Local relative references resolve within an approved root and cannot escape through traversal or unregistered symlinks.
20. Historical schemas, catalogs, locks, manifests, mappings, migrations, and superseded records remain reconstructable under retention rules.
21. Brownfield adoption overlays Product OS control without moving or renaming live source until separately authorized.
22. Automation may enforce this contract later; it cannot acquire approval, risk, gate, or release authority.

---

# 6. Conformance Layers

| Layer | Question |
|---|---|
| Syntax | Can JSON/YAML/Markdown metadata be parsed deterministically? |
| Schema | Does the instance conform to the declared schema version? |
| Catalog | Are IDs and vocabularies current and registered? |
| Reference | Do `$ref`, artifact, repository, path, mapping, source, evidence, and gate refs resolve? |
| Semantic | Do cross-field and cross-record invariants hold? |
| Authority | Are owner, reviewer, approver, and action authorities valid? |
| Evidence | Are claims supported by fit, sufficient, admissible evidence? |
| Lifecycle | Are status, baseline, gate, change, migration, retention, and supersession states valid? |

Failure at one layer cannot be hidden by success at another.

---

# 7. Canonical Serialization Contract

## 7.1 JSON

- UTF-8 without byte-order mark.
- Object keys are case-sensitive.
- No duplicate keys.
- Numbers that are identifiers, money, high-precision quantities, or version strings are represented as strings unless a schema explicitly defines safe numeric semantics.
- Dates/times are quoted ISO 8601 strings; instants include offset or `Z`.
- Canonical digest generation uses the later automation-defined normalization profile; raw-file digest remains separately available.

## 7.2 YAML

- YAML 1.2.2 Core-compatible data only.
- UTF-8 and spaces; tabs are prohibited for indentation.
- No custom tags, merge keys, anchors/aliases, duplicate keys, multiple-document streams, or executable/application-specific types.
- Quote ambiguous scalars such as dates, leading-zero identifiers, `yes/no/on/off`, special numeric forms, and values containing structural punctuation.
- Parsed output must be representable as JSON without semantic loss.

## 7.3 Markdown

- UTF-8, one H1, stable headings/anchors where addressable membership depends on them.
- Front matter is a bounded projection of artifact/register metadata and declares its schema/version.
- Tables are human views; typed YAML/JSON/native records remain canonical when machine fidelity matters.
- Embedded examples declare `example` status and never masquerade as live project data.

---

# 8. Minimum Project Bootstrap

Every Product OS project instance has:

~~~text
README.md
product-os.yaml
.product-os/framework.lock.yaml
.product-os/repository-index.yaml
.product-os/profile-composition.yaml
.product-os/artifact-register.yaml
~~~

Directories for content, tools, evidence, derived state, and archive are created only when activated.

---

# 9. Authority Boundary

| Action | Required authority |
|---|---|
| Publish framework/schema release | Product OS framework authority |
| Change artifact catalog/ID meaning | Catalog governance and cross-phase impact review |
| Pin/upgrade framework or schema | Project governance plus affected owners/reviewers |
| Choose repository topology/root | Project architecture/engineering/governance authority |
| Activate/N/A artifact | Artifact applicability authority under contract |
| Move canonical artifact location | Artifact owner plus repository/mapping impact review |
| Change generated output | Change canonical input or generator; do not edit output |
| Migrate schema/repository | Change authority, migration owner, validation, rollback, and acceptance |
| Accept gate/release/operational state | Named gate/release/operational authority only |

Technical write permission is not authority.

---

# 10. Version Dimensions

Every record distinguishes:

- Product OS release version;
- schema-system release version;
- individual schema version and `$id`;
- Master Artifact Catalog version;
- Core Artifact Contract version;
- project manifest version;
- artifact/register/baseline/gate/mapping version;
- repository revision;
- native-tool object revision;
- migration version.

No “version” field is accepted without identifying its subject.

---

# 11. Profile Inheritance

- P1 may combine files but not identities or status records.
- P2 separates independently owned/reviewed content and uses deterministic manifests/mappings.
- P3 strengthens independence, signed/immutable records, segregation, retention, migration proof, and continuous drift checks.
- A domain override raises only affected packages and records.
- Any profile may use an independent artifact when ownership, change rate, access, retention, or evidence requires it.

---

# 12. Change and Migration Boundary

Material changes include schema ID/dialect/type/required/enum changes; artifact catalog changes; path/naming/topology changes; canonical-location moves; profile composition changes; generator behavior; reference resolution; access/retention/digest policy; framework lock updates; and repository/tool migration.

They enter GOV-007 and Change Impact Rules. Breaking changes require a new major schema version or a separately versioned successor schema, explicit migration, compatibility statement, affected-record inventory, rollback/forward-fix, and validation evidence.

---

# 13. Final Shared Principle

> **A file is valid only when its syntax, schema, identity, references, ownership, lifecycle, and evidence role all agree; a green parser alone proves almost nothing.**

