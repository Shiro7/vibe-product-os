# Product OS v1.0 — Project Manifest, Framework Lock, Profiles, and Module Activation

~~~yaml
document_id: FRAMEWORK-PROJECT-MANIFEST-LOCK-PROFILE-MODULES
version: 0.1.0
status: WORKING_DRAFT
completion_state: PROJECT_BOOTSTRAP_PROFILE_MODULE_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
schemas: [project-manifest, framework-lock, repository-index, profile-composition]
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines the four core control files that bootstrap a project and resolve exact Product OS version, repositories, profiles, domain overrides, physical packages, conditional modules, and lifecycle state.

---

# 2. Core Control Files

| File | Canonical responsibility |
|---|---|
| `product-os.yaml` | Project identity, active lifecycle, default profile, top-level authority/configuration, control-file refs |
| `.product-os/framework.lock.yaml` | Exact immutable Product OS framework/catalog/contract/schema/profile/adapter versions and digests |
| `.product-os/repository-index.yaml` | Exact repositories, roots, roles, modules, owners, branches, environments, and canonical locations |
| `.product-os/profile-composition.yaml` | P1/P2/P3 domain resolution, physical packages, artifact membership, conditional modules, and overrides |
| `.product-os/artifact-register.yaml` | GOV-002 project artifact identities/lifecycle; governed separately in Artifact Standard |

The manifest references the four `.product-os` files; it does not duplicate their full contents.

---

# 3. Project Manifest

Minimum decisions:

- project/product identity and names;
- manifest/schema version and Product OS release line;
- exact default profile;
- current product state and lifecycle phases/gates;
- framework lock, repository index, profile composition, artifact register, schema catalog refs;
- accountable owner and project authority model refs;
- data/access classification baseline;
- active tool systems and applicability;
- active modules and standards matrix ref;
- timestamps, status, supersession, and reopen conditions.

The manifest is project control data, not a product brief, SRS, architecture, or release decision.

---

# 4. Framework Lock

The lock makes every validation/reproduction claim exact.

It includes:

~~~text
Product OS framework release/source revision/digest
Master Artifact Catalog version/digest
Shared Core Contract version
Classification Rules version
Gate Specifications version
Traceability Graph version
Change Impact Rules version
Source / Evidence Model version
AI Operating Specification version
Spec Kit + Figma + GitHub Mapping version
Schemas & Repository Standard version
Schema catalog version/digest
Profile catalog version/digest
adapter/template/migration versions used by project
~~~

Rules:

- no floating branch/tag/latest reference as the sole lock identity;
- every entry has asset ID, version, source, revision/digest, status, and compatibility;
- lock update is a governed change with diff and impact;
- a lock file is never hand-edited while an upgrade transaction is partially applied;
- rollback restores both lock and migrated project records or declares forward-only state.

---

# 5. Default Profile

Exactly one project default applies:

| Profile | Intent | Default physical behavior |
|---|---|---|
| P1 | Lean / rapid with full lifecycle integrity | Composite packs/shared registers where safe |
| P2 | Standard production delivery | Modular independently reviewable files/sections |
| P3 | Comprehensive/high assurance | Independent lifecycle records and stronger evidence/segregation |

Default profile is a packaging/assurance choice, not risk acceptance.

---

# 6. Domain Override

An override records:

~~~yaml
domain_id:
base_profile:
effective_profile:
scope:
triggers: []
reason:
source_refs: []
evidence_refs: []
owner:
authority:
status:
effective_at:
review_due:
reopen_triggers: []
~~~

Rules:

- override may strengthen affected domain without changing unrelated domains;
- lowering below a mandatory contract/risk/standard floor is prohibited;
- P3 security with P1 discovery remains valid if dependencies/handoffs are operational;
- override change recalculates physical packages and required assurance but preserves artifact IDs/history.

---

# 7. Physical Package Resolution

For every activated artifact, the composition resolver produces exactly one current canonical package membership:

`COMPOSITE`, `MODULAR`, `INDEPENDENT`, `REGISTER`, `DERIVED`, or `EXTERNAL_NATIVE`.

Package entry fields:

- package ID/type/path/format/schema/version;
- artifact IDs and addressable locators;
- canonical/derived/native role;
- owner, access, retention, generator where applicable;
- profile and domain override source;
- status, supersession, and migration refs.

Two files may reference the same artifact, but only one representation owns current project semantic content for exact field/scope/version.

---

# 8. Conditional Module Activation

A module represents a reusable cross-artifact obligation set, not a new artifact family.

Activation record:

~~~yaml
module_id:
module_version:
scope:
applicability:
triggers: []
decision_owner:
authority:
decision_at:
source_refs: []
evidence_refs: []
activated_artifact_refs: []
gov_009_refs: []
profile_overrides: []
package_impacts: []
reopen_conditions: []
~~~

Modules may include AI, analytics, documents/signatures, financial actions/payments, maps/location, messaging/collaboration, multi-tenancy, notifications, offline/sync, regulated data, or workflow/approvals. The final applicable set comes from GOV-009/project evidence, not from a default folder list.

---

# 9. Artifact Activation and N/A

The profile composition does not decide artifact applicability by itself. It consumes governed activation/N/A decisions from artifact contracts/GOV-002.

For each catalog artifact:

- `ACTIVE`: has a package/native location and register entry;
- `PENDING`: has owner/due evidence and safe temporary route;
- `NOT_APPLICABLE`: has validated N/A record and no empty canonical file;
- `MISSING`: required/active but lacks operational representation; this is a failure.

---

# 10. Lifecycle State

The manifest records current lifecycle mode and active phases/gates as navigation/control state. Gate outcomes remain in gate decision records.

Allowed project lifecycle modes include:

`NEW_PRODUCT`, `BROWNFIELD_ADOPTION`, `DELIVERY_ITERATION`, `RELEASE_CYCLE`, `LIVE_OPERATIONS`, `INCIDENT_REMEDIATION`, `EVOLUTION`, `MIGRATION`, `SUNSET`, `TRANSFER`.

Several phases may be active concurrently; no manifest field grants gate bypass.

---

# 11. Tool Activation

Each tool entry records system ID, role, applicability, owner, data/access boundary, mapping register ref, adapter version, and status.

Spec Kit, Figma, and GitHub recipe defaults come from the completed mapping workstream. CI, test, cloud, deployment, observability, and other systems use the same tool-system/mapping contract when later adapters are added.

---

# 12. Profile Transition

Profile escalation/de-escalation procedure:

1. record trigger and affected scope;
2. assess artifact/package/owner/access/evidence impact;
3. design split/merge/move migration;
4. preserve IDs, versions, links, statuses, approvals, evidence, and history;
5. update composition and artifact register atomically;
6. validate no duplicate/missing canonical membership;
7. update downstream references and acknowledgements;
8. archive superseded package representations;
9. close with evidence.

De-escalation cannot remove still-applicable independence, retention, evidence, or control obligations.

---

# 13. Final Bootstrap Principle

> **The manifest says which project this is; the lock says which Product OS rules it uses; the repository index says where truth lives; composition says how activated obligations are packaged.**

