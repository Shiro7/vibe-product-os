# Product OS v1.0 — Gate, Baseline, Handoff, Candidate, Release, and Operations Schemas

~~~yaml
document_id: FRAMEWORK-GATE-BASELINE-HANDOFF-RELEASE-OPERATIONS-SCHEMAS
version: 0.1.0
status: WORKING_DRAFT
completion_state: LIFECYCLE_SCHEMAS_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
schemas: [gate-catalog, gate-decision, baseline, handoff]
gate_scope_count: 13
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines machine structures for all 13 gate decisions, 12 baseline aliases, lifecycle handoffs, implementation/verification candidates, release authorization/execution, post-release validation, and operational re-entry without collapsing their authority boundaries.

---

# 2. Gate Catalog

The machine gate catalog contains:

| Gate | Decision family | Primary output |
|---|---|---|
| G0 | Baseline gate | ICB |
| G1 | Baseline gate | DSBL |
| G2 | Baseline gate | BBL |
| G3A | Baseline gate | PBL |
| G3B | Baseline gate | RBL |
| G4A | Baseline gate | EBL |
| G4B | Baseline gate | DBL |
| G5A | Baseline gate | ABL |
| G5B | Baseline gate | ERBL |
| G6A | Baseline gate | IBL |
| G6B | Verification baseline gate | VBL |
| G7 | Release authorization gate | Exact authorized release |
| G8 | Recurring operational review | OBL/evolution/remediation/sunset/transfer routes |

Catalog entries include phase owner, decision question, outcome family, baseline alias, canonical decision artifact, validity/reopen contract, and status.

---

# 3. Gate Decision Common Record

Required:

- decision/gate/project/scope identity;
- exact candidate baseline and artifact-register snapshot;
- constitution/catalog/schema/profile/GOV-009 versions;
- check results with status/evidence/N/A authority;
- open risks/exceptions/conditions;
- decision workflow status and lifecycle disposition;
- outcome matching gate family;
- accountable authority and decision time;
- validity/window/restrictions/allowed next actions;
- blocked/prohibited actions;
- downstream handoff and reopen triggers;
- sources/evidence/change/supersession.

Schema validity cannot issue the decision.

---

# 4. Gate Outcome Conditionals

## G0 through G6B

`PASS`, `PASS_WITH_CONDITIONS`, `HOLD`, `REJECT`.

## G7

`AUTHORIZE`, `AUTHORIZE_WITH_CONDITIONS`, `HOLD`, `REJECT`.

## G8

`SUSTAIN`, `SUSTAIN_WITH_ACTIONS`, `REMEDIATE`, `EVOLVE`, `CONSTRAIN`, `SUNSET_REVIEW`, `TRANSFER_REVIEW`, `CRITICAL_ESCALATION`.

G8 may carry partitioned outcomes for different exact live scopes. G8 does not authorize implementation/release.

---

# 5. Gate Check Record

Each check contains:

~~~yaml
check_id:
criterion:
scope:
status: PASS|PASS_WITH_CONDITIONS|FAIL|BLOCKED|NOT_APPLICABLE
subject_refs: []
evidence_refs: []
method:
reviewer:
authority_ref:
conditions: []
limitations: []
evaluated_at:
valid_until:
invalidation_triggers: []
~~~

Gate outcome is not calculated by percentage; automation may summarize but cannot approve.

---

# 6. Condition Record

A condition requires ID, obligation, owner, authority, due date/event, evidence required, exact restriction, allowed/prohibited action, monitoring/escalation, failure consequence, status, closure evidence, and reopen relation.

An unowned or consequence-free condition is invalid.

---

# 7. Baseline Schema

Baseline aliases:

`ICB`, `DSBL`, `BBL`, `PBL`, `RBL`, `EBL`, `DBL`, `ABL`, `ERBL`, `IBL`, `VBL`, `OBL`.

Minimum baseline:

~~~yaml
baseline_id:
baseline_alias:
baseline_version:
project_id:
scope:
status:
profile_and_domain_overrides:
constitution_version:
catalog_and_schema_versions:
artifact_register_snapshot_ref:
artifact_members: []
external_native_members: []
source_baselines: []
gate_decision_ref:
conditions_risks_exceptions: []
evidence_index_ref:
created_at:
effective_at:
valid_until:
owner:
authority:
supersedes:
reopen_triggers: []
~~~

Every member includes exact artifact/native ID, version/revision/digest, canonical location/role, status, and membership reason.

---

# 8. Baseline Snapshot Rule

A baseline is reproducible without mutable “current” assumptions. It pins:

- artifact-register snapshot/version;
- included artifact and native-object revisions;
- relevant framework/catalog/schema/profile versions;
- conditions/risks/exceptions/evidence;
- gate decision and authority.

The baseline may reference immutable repository/tool identities or integrity-protected exports; copying every native object into one bundle is not required.

---

# 9. Handoff Schema

Handoff types:

`PHASE`, `DESIGN_TO_ENGINEERING`, `ARCHITECTURE_TO_ENGINEERING`, `ENGINEERING_TO_IMPLEMENTATION`, `IMPLEMENTATION_TO_VERIFICATION`, `VERIFICATION_TO_RELEASE`, `RELEASE_TO_OPERATIONS`, `TOOL`, `TEAM`, `VENDOR`, `TRANSFER`, `SUNSET`.

Required:

- handoff ID/type/version/project/scope;
- sender/receiver/owners and acknowledgement authority;
- source baseline/candidate and artifact/tool/native revisions;
- included/excluded subjects and reasons;
- obligations, decisions, requirements, constraints, risks, conditions, exceptions;
- open questions/blockers/dependencies;
- acceptance/verification/evidence expectations;
- access/environment/data/retention considerations;
- sent/received/acknowledged/rejected state and times;
- downstream allowed/prohibited action;
- change/reopen/supersession.

Receipt is not acceptance; acknowledgement is explicit.

---

# 10. Candidate Record

Candidate identity may be carried as baseline member or handoff subject and includes:

- candidate ID/version;
- source repository/commit;
- build/package/container/artifact digests;
- schema/migration/configuration/feature-flag state;
- infrastructure/environment/data/identity/platform/device scope;
- design/requirement/architecture/baseline refs;
- generation/provenance;
- known deviations/defects/risks/exceptions;
- verification status/evidence/invalidation triggers.

A material dimension change creates a new candidate version.

---

# 11. Release Authorization and Execution

G7 decision pins exact candidate, target, scope, cohort/region/window, strategy, conditions, monitoring, stop/rollback, authority, and validity.

Release/deployment execution is a separate evidence/handoff/tool record containing actual revision/artifact, target, actor, start/end/result, deviations, rollback/forward-fix, and post-release validation.

Creating a release/tag/deployment object does not populate G7 authority fields automatically.

---

# 12. Post-Release and Operations

Post-release validation records live target identity, exact deployed candidate, smoke/business/control/observability evidence, monitoring window, deviations/incidents, owner, conclusion, and OBL handoff.

Operational baseline includes live services/capabilities, ownership/on-call/access, dependencies, SLO/control state, configurations/releases, known risks/debt/exceptions, evidence period, and G8 decision.

Operational signals route to governance/change/Spec Kit/phase re-entry by stable IDs; they are not retroactively written into prior baselines.

---

# 13. Gate/Schema Boundary

Schemas can enforce gate ID/outcome family, required record fields, references, timestamps, and structural conditions. They cannot judge evidence sufficiency, risk acceptability, human competence, business acceptance, production health, or whether a condition is materially blocking.

---

# 14. Final Lifecycle Principle

> **Pin the exact baseline and candidate, record the human decision, carry conditions into handoff, and preserve the difference between authorization, execution, verification, and live truth.**

