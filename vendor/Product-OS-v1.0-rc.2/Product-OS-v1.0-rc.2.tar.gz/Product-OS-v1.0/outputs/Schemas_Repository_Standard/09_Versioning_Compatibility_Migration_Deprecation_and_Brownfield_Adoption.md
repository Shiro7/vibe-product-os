# Product OS v1.0 — Versioning, Compatibility, Migration, Deprecation, and Brownfield Adoption

~~~yaml
document_id: FRAMEWORK-SCHEMA-REPOSITORY-VERSION-COMPATIBILITY-MIGRATION
version: 0.1.0
status: WORKING_DRAFT
completion_state: VERSIONING_MIGRATION_BROWNFIELD_COMPLETE
inherits: SHARED-SCHEMA-REPOSITORY-CONTRACT@0.1.0
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines how schemas, catalogs, repositories, profiles, records, and physical layouts evolve without losing identity, meaning, compatibility, evidence, or rollback/forward recovery.

---

# 2. Versioned Subjects

Independently version:

- Product OS framework release;
- Master Artifact Catalog;
- Core Artifact Contract Standard and specialized contracts;
- each cross-cutting specification library;
- schema system and individual schemas;
- schema/profile/gate/artifact catalogs;
- adapters/templates/generators/commands;
- project manifest/lock/composition/register;
- artifacts/records/baselines/gates/handoffs/mappings/evidence packs;
- repository/native source revisions;
- migration plans/executions.

One release may pin different subject versions; the framework lock makes the combination explicit.

---

# 3. Compatibility Dimensions

| Dimension | Question |
|---|---|
| Syntactic | Can old/new parsers read the serialization? |
| Schema validation | Do instances validate under old/new schemas? |
| Semantic | Does each field/value retain meaning? |
| Catalog | Are IDs/enums/classifications valid and unchanged in meaning? |
| Reference | Do IDs, `$ref`, paths, locators, and pointers resolve? |
| Behavioral | Do generators/validators/adapters/consumers act consistently? |
| Authority | Are ownership/approval/decision boundaries preserved? |
| Evidence | Does provenance/integrity/admissibility/retention remain valid? |
| Repository | Do locations, permissions, history, builds, and workflows remain operational? |
| Exchange | Can import/export round-trip without material loss? |

A change is compatible only for the declared consumer/scope/direction.

---

# 4. Change Classification

`ADDITIVE_COMPATIBLE`, `CLARIFICATION`, `CONSTRAINT_TIGHTENING`, `ENUM_EXTENSION`, `ENUM_REDEFINITION`, `FIELD_RENAME`, `FIELD_MOVE`, `TYPE_CHANGE`, `REQUIREDNESS_CHANGE`, `ID_CHANGE`, `SEMANTIC_CHANGE`, `PATH_MOVE`, `PACKAGE_SPLIT`, `PACKAGE_MERGE`, `TOPOLOGY_CHANGE`, `DIALECT_CHANGE`, `RETENTION_OR_ACCESS_CHANGE`.

Each class has producer/consumer, read/write, backward/forward compatibility assessment.

---

# 5. Migration Record

~~~yaml
migration_id:
migration_version:
subject_type:
source_version:
target_version:
scope:
change_classes: []
affected_records_and_repositories: []
preconditions: []
transformations: []
defaults_and_information_loss: []
reference_and_path_rewrites: []
access_retention_evidence_impacts: []
validation_plan: []
dry_run_result:
backup_checkpoint:
rollback_or_forward_fix:
owner:
reviewers: []
authority:
execution_window:
execution_result:
reconciliation_evidence: []
residual_gaps: []
status:
~~~

Defaults cannot invent decisions, approvals, owners, evidence, or N/A reasons.

---

# 6. Migration Procedure

1. freeze source versions and inventory exact scope;
2. classify compatibility and data/meaning loss;
3. define target schemas/catalogs/layout and ID/path crosswalk;
4. assess trace/gate/baseline/evidence/tool/access/retention impact;
5. build deterministic transformation and validation vectors;
6. run dry-run in isolated copy/export;
7. review diff, conflicts, unknowns, and rollback limits;
8. authorize cutover and create checkpoint;
9. migrate in bounded batches with logs/idempotency;
10. validate counts, schemas, IDs, references, semantics, permissions, behavior, and evidence;
11. reconcile downstream consumers/acknowledgements;
12. retire/supersede old representation only after acceptance;
13. preserve migration evidence and residual risks.

---

# 7. Dual Read/Write

Dual-read or dual-write is temporary and requires exact period, field ownership, ordering, conflict resolution, reconciliation, monitoring, stop rule, and migration owner.

It is prohibited as an indefinite substitute for migration. Two writers cannot both become canonical by convenience.

---

# 8. Deprecation Lifecycle

`ACTIVE → DEPRECATED → SUPERSEDED → RETIRED`.

Deprecation records:

- subject/version/scope and successor;
- reason/decision authority;
- affected producers/consumers/records/projects;
- compatibility/migration and deadline;
- warning/validation behavior;
- support/security/retention policy;
- adoption and remaining-use evidence;
- retirement criteria and archive disposition.

Removal without a successor is allowed only with approved elimination/disposition and impact evidence.

---

# 9. Repository Path Migration

Path moves preserve logical IDs and record old/new paths, repository revisions, redirects/crosswalks, link updates, ownership/access changes, generated output invalidation, and evidence locator impact.

Case-only renames use a safe two-step migration where filesystems require it. Symlinks are not permanent migration substitutes unless separately approved and registered.

---

# 10. Profile Package Migration

P1/P2/P3 transitions use package split/merge procedures from the Artifact standard. Historical front matter/register versions remain reconstructable; anchor/key mappings preserve inbound links; no member status is inferred from package status.

---

# 11. Brownfield Adoption

Brownfield adoption begins with overlay, not restructure:

~~~text
inventory existing repositories/tools/files/native objects
→ register exact identities and current owners
→ classify canonical/source/derived/evidence roles
→ select framework version/profile/domain overrides
→ create project manifest/lock/repository index/register
→ map current assets to 281 obligations
→ record gaps/conflicts/stale/unknown/N/A
→ activate the minimum operational content
→ validate and baseline through normal authority
→ propose later restructuring only where justified
~~~

Do not rename canonical repositories, move live code, rewrite history, or regenerate documents simply to match the template during initial adoption.

---

# 12. Brownfield Evidence

Existing docs may be stale and tool dashboards may be incomplete. Adoption evidence prioritizes current source, configuration, migrations, deployed state, tests, logs, Figma/native versions, audit records, and accountable owner confirmation.

Conflicts remain visible; “current file” does not win without authority/provenance.

---

# 13. Framework Upgrade

A project upgrade compares:

- lock assets/digests;
- catalog IDs/classes/profiles;
- schema required/enums/types/conditionals;
- contracts/gates/trace/change/evidence/AI/mapping semantics;
- repository layout/naming;
- adapter/template/generator/command behavior;
- project records and native mappings;
- security/access/retention/supply-chain implications.

Upgrade may be partial only if compatibility and mixed-version support are explicitly defined. Otherwise the project remains on its prior supported lock.

---

# 14. Final Migration Principle

> **Migrate identities and meaning together, prove what changed and what survived, and never disguise irreversible information loss as a format upgrade.**

