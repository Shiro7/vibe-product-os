# Product OS v1.0 — Gate Map

**Document ID:** `MASTER-GATE-MAP`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — GATE CONTRACT COMPLETE`  
**Coverage:** `G0 through G8, including A/B split gates`  
**Constitution Link:** `GOV-001 — Product Constitution`  
**Artifact Registry Link:** `GOV-002 — Artifact Register`  
**Implementation Library:** [Gate Specifications v0.1.0](Gate_Specifications/Gate_Specifications_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Traceability Library:** [Traceability Graph v0.1.0](Traceability_Graph/Traceability_Graph_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Change Impact Library:** [Change Impact Rules v0.1.0](Change_Impact_Rules/Change_Impact_Rules_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Source / Evidence Library:** [Source / Evidence Model v0.1.0](Source_Evidence_Model/Source_Evidence_Model_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**AI Operating Library:** [AI Operating Specification v0.1.0](AI_Operating_Specification/AI_Operating_Specification_Index.md) — technical closure PASS; Product OS approval and baseline pending  
**Companion Documents:** `Master_Lifecycle_Index.md`, `Cross_Phase_Traceability.md`, and `Classification_Rules.md`  
**Purpose:** تثبيت gate sequence, decision questions, owning phase, required evidence, outcome vocabulary, condition rules, blockers, validity, reopen triggers, authority, and downstream effect بدون تكرار كل check detail الموجود داخل phase specifications.

---

# 1. Gate Model

A gate is an accountable decision on an exact scope and baseline.

Every gate:

- evaluates the exact scope against the active `GOV-001` constitution version;
- resolves required, provided, missing, NOT_APPLICABLE, STALE, and SUPERSEDED artifacts through a reproducible `GOV-002` register view;
- evaluates project-specific standards applicability and propagated obligations through `GOV-009`;
- binds evidence and impact relationships through `GOV-008`.

It is not:

```text
A calendar milestone
A document completion percentage
A meeting without evidence
A tool-generated status
A substitute for authority
Permission to bypass the next gate
A permanent certificate after material change
```

---

# 2. Gate Sequence

```text
G0
Intake Ready
  ↓
G1
Problem Understood
  ↓
G2
Business Baseline
  ↓
G3A
Product Baseline
  ↓
G3B
Requirements Baseline
  ↓
G4A
Experience Baseline
  ↓
G4B
Design Baseline
  ↓
G5A
Architecture Baseline
  ↓
G5B
Engineering Readiness Baseline
  ↓
G6A
Implementation Baseline
  ↓
G6B
Verification Baseline
  ↓
G7
Release Authorization
  ↓
G8
Operational Sustainability & Evolution Review
  ↺
Re-enter earliest affected gate path
```

---

# 3. Gate Register

| Gate | Owning phase | Decision | Primary object | Checks | Outcome family |
|---|---|---|---|---:|---|
| G0 | Phase 00 | Is intake sufficient to begin the correct route? | ICB | 15 | Baseline outcome |
| G1 | Phase 01 | Is the problem understood? | DSBL | 16 | Baseline outcome |
| G2 | Phase 02 | Is the business model and logic baseline approved? | BBL | 18 | Baseline outcome |
| G3A | Phase 03 | Is product responsibility and scope approved? | PBL | 18 | Baseline outcome |
| G3B | Phase 04 | Are requirements atomic, complete, testable, and traceable? | RBL | 19 | Baseline outcome |
| G4A | Phase 05 | Is experience logic coherent and design-ready? | EBL | 22 | Baseline outcome |
| G4B | Phase 06 | Is design complete, governed, validated, and implementation-ready? | DBL | 25 | Baseline outcome |
| G5A | Phase 07 | Is architecture sufficient, coherent, and governed? | ABL | 30 | Baseline outcome |
| G5B | Phase 08 | Can implementation begin without invention? | ERBL | 30 | Baseline outcome |
| G6A | Phase 09 | Is the exact implementation candidate complete and traceable? | IBL / IVCAND | 30 | Baseline outcome |
| G6B | Phase 10A | Is the exact candidate independently verified? | VBL | 30 | Baseline outcome |
| G7 | Phase 10B | May this verified candidate be released to this target now? | RDEC | 25 | Authorization outcome |
| G8 | Phase 11 | Is live scope sustainable, and what lifecycle route follows? | G8R / OBL / EVP | 30 | Operational routing outcome |

Total detailed gate checks in the current methodology: `308`.

---

# 4. Common Baseline Outcomes

G0 through G6B use:

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

---

# 5. PASS

The exact gate scope is accepted for downstream use with no material blocking deficiency.

PASS does not mean all future-phase work is complete.

---

# 6. PASS_WITH_CONDITIONS

Allowed only when every condition is:

```text
Non-blocking for the gate decision
Explicit and scoped
Owned by an accountable party
Time- or trigger-bounded
Measurable or evidence-backed
Visible to downstream consumers
Compatible with applicable mandatory obligations
Paired with consequence if unmet
```

---

# 7. HOLD

The gate cannot decide yet because required evidence, decision, authority, dependency, environment, or remediation is incomplete but recoverable.

HOLD does not create an approved baseline.

---

# 8. REJECT

Material deficiency makes the proposed scope unacceptable and requires rework, a revised baseline, or a changed route.

REJECT preserves evidence and rationale.

---

# 9. G7 Outcomes

```text
AUTHORIZE
AUTHORIZE_WITH_CONDITIONS
HOLD
REJECT
```

Authorization language is intentional because G7 permits a production exposure, not merely a baseline handoff.

---

# 10. G8 Outcomes

```text
SUSTAIN
SUSTAIN_WITH_ACTIONS
REMEDIATE
EVOLVE
CONSTRAIN
SUNSET_REVIEW
TRANSFER_REVIEW
CRITICAL_ESCALATION
```

G8 may assign different outcomes to different exact live scopes in one review.

---

# 11. Gate Decision Contract

Every gate record includes:

```yaml
gate_id: Gx
decision_id: unique_id
phase: PHASE-XX
scope: exact_scope_reference
baseline_or_candidate: exact_version_reference
source_baselines: []
profile: P1_or_P2_or_P3
domain_overrides: []
checks:
  passed: []
  failed: []
  not_applicable: []
  blocked: []
outcome: null
conditions: []
risks: []
exceptions: []
evidence_index: null
decision_makers: []
decided_at: null
valid_until: null
reopen_triggers: []
downstream_handoff: null
```

---

# 12. Gate Scope

Gate outcome applies only to the recorded:

```text
Product / project
Release or change scope
Baseline version
Platforms, markets, and profiles
Artifacts and candidates
Target or live scope where applicable
Explicit exclusions
```

No gate outcome generalizes silently to another release, target, market, product, or baseline version.

---

# 13. Gate Authority

Each gate defines:

```text
Accountable decision owner
Required reviewers
Required specialist authorities
Quorum or substitutions
Conflict-of-interest handling
Risk-acceptance limit
Escalation route
```

AI, automation, or status tooling cannot accept organizational risk or authorize a gate.

---

# 14. Gate Evidence

Evidence must be:

```text
Relevant to the gate question
Bound to exact scope and version
Source-identified
Reviewable
Current enough for the decision
Protected according to classification
Durable according to retention
Honest about uncertainty and missing data
```

---

# 15. NOT_APPLICABLE at Gates

A gate check may be `NOT_APPLICABLE` only with:

```text
Reason
Scope
Source evidence
Owner
Decision date
Authority where required
Reopen trigger
```

Non-execution without rationale is not `NOT_APPLICABLE`.

---

# 16. Gate Validity

A gate decision remains valid only while its scope, baseline, assumptions, dependencies, standards applicability, evidence, and authority remain materially unchanged.

G7 additionally expires by authorized release window.

G8 is valid for its review period and triggers the next cycle.

---

# 17. Common Reopen Triggers

```text
Material scope change
Source baseline revision
New or invalidated evidence
Critical defect or incident
Standards or applicability change
Expired condition, exception, or approval
Dependency or vendor change
Changed target, environment, or configuration
New user, market, platform, or data scope
Material risk or assumption change
Failed downstream validation
Lifecycle change
```

---

# 18. Gate Dependency Rule

A downstream gate references exact upstream gate decisions and baseline versions.

If an upstream decision reopens, downstream validity is impact-assessed as:

```text
UNAFFECTED
REVIEW_REQUIRED
PARTIALLY_INVALIDATED
FULLY_INVALIDATED
SUPERSEDED
```

---

# 19. G0 — Intake Ready

**Owning phase:** Phase 00.

**Decision question:** Is the project context sufficient and truthful enough to start the correct route?

**Primary object:** ICB.

**15 check domains:**

```text
Project identity
Entry reason
Product state
Source baseline
Authority context
Problem / need
Desired outcome
Current state
Constraints
Critical risk signals
Critical contradictions
Blocking questions
Preliminary classification
Downstream route
Standards applicability trigger capture
```

**Normal handoff:** Phase 01.

**Key boundary:** G0 does not mean the problem is understood or the solution is approved.

---

# 20. G1 — Problem Understood

**Owning phase:** Phase 01.

**Decision question:** Is there enough validated understanding of the current condition, affected people, problems, causes, impacts, outcomes, and constraints?

**Primary object:** DSBL.

**16 check domains:**

```text
Current state
Primary problems
Symptom distinction
Impacts
Cause treatment
Stakeholder coverage
Desired outcomes
Success direction
Constraints
Dependencies
Conflicts
Blocking questions
Scope hypothesis
Risk reassessment
Downstream route
Standards applicability evidence
```

**Normal handoff:** Phase 02.

**Key boundary:** G1 approves problem understanding, not a preferred product solution.

---

# 21. G2 — Business Baseline

**Owning phase:** Phase 02.

**Decision question:** Are objectives, capability, process, role, decision, rule, control, information, ownership, and business applicability sufficiently defined?

**Primary object:** BBL.

**18 check domains:**

```text
Business objectives
Business scope
Capabilities
Ownership
Roles and responsibilities
Processes
Decisions
Rules
Controls
Exceptions
Business information
Dependencies
KPI direction
Conflicts
Open questions
Risk
Downstream readiness
Standards and compliance business linkage
```

**Normal handoff:** Phase 03.

**Key boundary:** G2 does not define system features or architecture.

---

# 22. G3A — Product Baseline

**Owning phase:** Phase 03.

**Decision question:** Is product responsibility, value, audience, boundary, capability, module, state, policy, integration, release, and roadmap direction coherent?

**Primary object:** PBL.

**18 check domains:**

```text
Vision
Product boundary
Product scope
User model
Capability coverage
Product domains
Module coherence
Feature candidates
Product states
Policies
Integrations
Dependencies
MVP / release boundary
Roadmap direction
Risk
Open decisions
Requirements readiness
Standards applicability review
```

**Normal handoff:** Phase 04.

**Key boundary:** Feature candidates are not approved atomic requirements.

---

# 23. G3B — Requirements Baseline

**Owning phase:** Phase 04.

**Decision question:** Are approved obligations represented as atomic, consistent, feasible, testable, traceable requirements with acceptance and change control?

**Primary object:** RBL.

**19 check domains:**

```text
Baseline scope
Upstream derivation
Requirement quality
Functional coverage
Non-functional coverage
Data coverage
Integration coverage
Security and privacy
Accessibility
Audit and evidence
Acceptance and testability
Traceability
Priority and release integrity
Dependencies and feasibility
Conflicts and duplicates
Open questions and decisions
Standards derivation
Downstream readiness
Change governance
```

**Normal handoff:** Phase 05.

**Key boundary:** Requirements specify obligations, not screens or technical mechanisms.

---

# 24. G4A — Experience Baseline

**Owning phase:** Phase 05.

**Decision question:** Are actors, goals, journeys, flows, IA, navigation, states, interaction, content, failure, recovery, accessibility, localization, and cross-platform experience coherent?

**Primary object:** EBL.

**22 check domains:**

```text
Scope and source baselines
Principles, actors, goals, contexts
Scenarios
Journeys
Flows
Information architecture
Navigation and context
View / screen / route inventory
UX states
Error, safety, and recovery
Interaction behavior
Content and messages
Responsive and cross-platform
Localization and RTL
Accessibility
Security and privacy experience
Requirements traceability
Validation
GOV-009 linkage
Open questions and decisions
Product Design readiness
Change governance
```

**Normal handoff:** Phase 06.

**Key boundary:** G4A approves experience logic, not final visual treatment.

---

# 25. G4B — Design Baseline

**Owning phase:** Phase 06.

**Decision question:** Is the complete visual and interaction realization governed, validated, traceable, accessible, localized, and ready for downstream use?

**Primary object:** DBL.

**25 check domains:**

```text
Scope and upstream baselines
Design direction
Foundations and tokens
Layout and density
Typography
Color, theme, and contrast
Iconography and assets
Components
Component adoption and governance
Product patterns
Screens and views
States, feedback, and recovery
Forms and input
Data-dense and visualization design
Content and messages
Responsive and cross-platform
Localization and RTL
Accessibility
Security and privacy
Motion and transitions
Generated outputs, notifications, and third parties
Prototype and validation
Traceability and GOV-009
Source, version, and design-to-code readiness
Open items and engineering readiness
```

**Normal handoff:** Phase 07.

**Key boundary:** G4B does not authorize silent product, requirement, or experience change.

---

# 26. G5A — Architecture Baseline

**Owning phase:** Phase 07.

**Decision question:** Is the solution architecture sufficient to realize approved behavior and quality attributes with explicit decisions, mechanisms, boundaries, tradeoffs, and evolution?

**Primary object:** ABL.

**30 check domains:**

```text
Scope, profile, and baselines
Drivers, constraints, principles, assumptions
Quality attribute scenarios
Current, target, and transition integrity
Context, dependencies, and trust boundaries
Containers, components, and dependencies
Domains and ownership
Data ownership and classification
Data models, integrity, and concurrency
Data lifecycle, retention, deletion, residency, lineage
APIs and contracts
Integrations
Events, jobs, workflows, synchronization
Identity, authentication, sessions, recovery
Authorization, tenancy, delegation, administration
Security and threats
Privacy, consent, and rights
Audit and evidence
Reliability, failure, and reconciliation
Backup, restore, DR, and continuity
Performance, capacity, scale, and cost
Deployment, environments, network, and rollback
Configuration, secrets, keys, and supply chain
Observability and diagnostics
Accessibility, localization, time, money, outputs
Compatibility, migration, rollout, and evolution
ADR completeness
GOV-009 and control mapping
Validation, risks, exceptions, and debt
Traceability and engineering readiness
```

**Normal handoff:** Phase 08.

**Key boundary:** Target architecture is not implemented reality.

---

# 27. G5B — Engineering Readiness Baseline

**Owning phase:** Phase 08.

**Decision question:** Can the exact implementation scope start without inventing product, requirement, design, architecture, target, ownership, dependency, migration, verification, or evidence detail?

**Primary object:** ERBL.

**30 check domains:**

```text
Scope, profile, and source baselines
Delivery strategy and release allocation
Engineering slices
Technical enablers
Work-item quality
Repository, module, and ownership
Toolchain and local development
Environment and deployment
Dependencies and critical path
Sequence and integration
Design-to-code
Screen, route, API, data, and state mapping
Architecture-to-code
API, event, and integration contracts
Data, schema, and migration
Configuration, secrets, keys, and flags
Engineering standards and review
Definition of Ready
Definition of Done contract
Acceptance and verification allocation
Evidence planning
Security, privacy, audit, and standards work
Accessibility, localization, and design QA
Reliability, performance, and observability
Test data, identities, and environments
CI/CD and supply chain
Estimation, capacity, and ownership
Questions, blockers, spikes, risks, deviations
Coverage, traceability, and GOV-009
Phase 09 handoff
```

**Normal handoff:** Phase 09.

**Key boundary:** G5B approves readiness, not schedule certainty or completed work.

---

# 28. G6A — Implementation Baseline

**Owning phase:** Phase 09.

**Decision question:** Does the exact approved scope exist in canonical source and artifacts with truthful status, review, checks, controls, traceability, and a stable verification candidate?

**Primary object:** IBL and IVCAND.

**30 check domains:**

```text
Scope and baseline integrity
Repository, branch, and revision identity
Work-item status
Change set and review
Build and artifact integrity
Developer and integration checks
UI and design-system implementation
Design parity and adoption
Domain and application behavior
API, event, job, and integration contracts
Data and schema integrity
Migration and backfill execution
Identity, authentication, sessions, recovery
Authorization, tenancy, and administration
Security and privacy controls
Audit and evidence mechanisms
Accessibility and localization
Reliability and failure handling
Performance, capacity, and resources
Observability, logging, health, and alerts
Configuration, secrets, keys, and flags
Infrastructure, environments, and network
CI/CD and supply chain
Deployment, rollout, and runtime health
Dependencies, licenses, and generated code
Defects, blockers, deviations, and debt
GOV-009 implementation status
Coverage and traceability
Verification candidate integrity
Phase 10 handoff
```

**Normal handoff:** Phase 10A.

**Key boundary:** Built and check-passing does not mean independently verified.

---

# 29. G6B — Verification Baseline

**Owning phase:** Phase 10A.

**Decision question:** Does the exact candidate satisfy applicable approved obligations with risk-proportionate, trustworthy evidence?

**Primary object:** VBL.

**30 check domains:**

```text
Scope and candidate identity
Strategy and risk
Environment, data, and identity
Functional and business rules
States, failure, and recovery
Concurrency and idempotency
API, contracts, and integrations
Events, jobs, offline, and sync
Design, interaction, and content
Accessibility
Localization and global behavior
Security, authentication, and sessions
Authorization, tenancy, and administration
Privacy
Auditability
Performance and capacity
Resilience and failure modes
Backup, restore, and DR
Migration and data integrity
Deployment, configuration, and supply chain
Observability and operations
Enterprise and conditional profiles
User and business acceptance
Defects, retest, and regression
Waivers and residual risk
Evidence quality
Coverage and traceability
GOV-009 applicability
Candidate stability
Release handoff
```

**Normal handoff:** Phase 10B / G7.

**Key boundary:** G6B verifies the candidate but does not authorize production exposure.

---

# 30. G7 — Release Authorization

**Owning phase:** Phase 10B.

**Decision question:** May the exact G6B-accepted candidate be exposed to the exact production target during the defined window and rollout under accountable authority?

**Primary object:** RDEC, supported by release scope, readiness, rollout, rollback, communication, and operational handoff records.

**25 check domains:**

```text
G6B and candidate integrity
Exact release scope
Production target identity
Artifacts and provenance
Migrations and data
Configuration, secrets, and keys
Infrastructure, network, and regions
Deployment strategy
Rollout, flags, and cohorts
Rollback and forward fix
Runtime health and smoke validation
Observability, dashboards, and alerts
SLO, performance, capacity, and cost
Security, privacy, and audit
Accessibility, localization, and outputs
Backup, restore, and DR
Vendors, integrations, and platform dependencies
Runbooks, on-call, and support
Incident, status, and maintenance communication
Release notes and customer obligations
Defects, waivers, and residual risk
Product, business, and UAT acceptance
Freeze, dependencies, and concurrent change
Phase 11 operational handoff
Authority, no-go, pause, and abort
```

**Normal handoff:** Authorized execution and Phase 11.

**Key boundary:** G7 applies only to the exact candidate, target, scope, strategy, window, and conditions.

---

# 31. G8 — Operational Sustainability & Evolution Review

**Owning phase:** Phase 11.

**Decision question:** Can the exact live scope remain operationally sustainable, and what should be sustained, remediated, evolved, constrained, transferred, or retired?

**Primary objects:** OBL, EVP, G8R, ROUTE, and SUN where applicable.

**30 check domains:**

```text
Live scope and identity
Ownership, access, and on-call
SLI, SLO, and error budget
Product and business outcomes
Telemetry and dashboards
Alerts and response
Incident health
Problem and corrective action
Support and customer impact
Operational communication
Security operations
Privacy and data rights
Auditability
Accessibility and inclusion
Data integrity and lifecycle
Backup, restore, and recovery
DR and continuity
Performance and capacity
Cost and sustainability
Vendors and dependencies
Assets, certificates, secrets, and domains
Maintenance, patches, and drift
Live change health
GOV-009 and control evidence
Risk, exceptions, and debt
Feedback and insight quality
Experiments and learning
Evolution portfolio
Lifecycle, deprecation, and sunset
OBL, decisions, and next cycle
```

**Normal handoff:** Next operating cycle or route to earliest affected phase.

**Key boundary:** G8 does not authorize a specific production release; G7 remains required.

---

# 32. Gate Pair Logic

```text
G3A Product responsibility
  -> G3B System obligation

G4A Experience logic
  -> G4B Detailed design realization

G5A Solution decision
  -> G5B Executable delivery readiness

G6A Built candidate
  -> G6B Independent verification

G6B Verified candidate
  -> G7 Production exposure authority

G7 Released scope
  -> G8 Sustainable operation and evolution direction
```

---

# 33. Conditional Pass Propagation

Downstream handoff of a condition includes:

```text
Originating gate
Exact condition
Affected scope
Owner
Due date or trigger
Restriction
Required evidence
Receiving phase
Closure authority
Consequence if unmet
```

A condition cannot disappear because a later gate is being prepared.

---

# 34. Condition Closure

Close a condition only with accepted evidence and the defined authority.

If a condition changes an approved baseline, reopen the owning gate instead of editing the decision record silently.

---

# 35. Gate Hold Routing

HOLD actions route to the source of the gap:

```text
Missing fact or problem evidence          -> Phase 00 / 01
Business decision or ownership            -> Phase 02
Product boundary                          -> Phase 03
Requirement or acceptance                 -> Phase 04
Journey or state                           -> Phase 05
Design object                              -> Phase 06
Architecture mechanism                    -> Phase 07
Readiness allocation                      -> Phase 08
Implementation or candidate               -> Phase 09
Verification evidence                     -> Phase 10A
Release target or readiness               -> Phase 10B
Operational health or lifecycle decision  -> Phase 11
```

---

# 36. Gate Rejection Routing

REJECT records the earliest material deficiency and names the re-entry phase.

The team does not automatically repeat every preceding phase.

---

# 37. Gate Evidence Index

The gate evidence index maps:

```text
Gate check
Source obligation
Artifact / baseline object
Validation or verification method
Evidence ID and period
Result
Reviewer
Condition / defect / exception
Decision effect
```

---

# 38. Gate Coverage Status

```text
PASS
FAIL
BLOCKED
NOT_REVIEWED
NOT_APPLICABLE
SUPERSEDED
```

Gate coverage status is not the same as the overall gate outcome.

---

# 39. Gate Change Record

When a gate reopens, record:

```text
Previous decision
Trigger
Changed scope or evidence
Affected checks
Invalidated downstream decisions
New review scope
New decision
Historical relationship
```

---

# 40. Emergency Gate Handling

Emergency handling may compress analysis and meeting sequence but preserves:

```text
Exact identity
Minimum decision evidence
Authority
Risk and impact
Containment or rollback
Observability
Decision and execution record
Post-event reconciliation
```

G7 and Phase 11 emergency-change rules still apply.

---

# 41. Gate Automation

Automation may validate IDs, required fields, links, evidence freshness, check status, signatures, artifact digests, conditions, and invalidation.

Automation may not accept product, business, security, privacy, accessibility, release, or operational risk.

---

# 42. Gate Anti-Patterns

```text
Gate by calendar date
Gate by document length
Gate by tool status alone
Approving an unknown scope
Approving without exact baseline version
Silent PASS_WITH_CONDITIONS
Condition without consequence
HOLD used to avoid rejection
REJECT without re-entry route
Reusing stale gate evidence
Treating upstream consumer access as gate bypass
Self-authorizing material risk
Treating G6A as verification
Treating G6B as release permission
Treating G7 as proof of production health
Treating G8 as permanent certification
```

---

# 43. Gate Validation Rules

```text
GM-VAL-01  Every gate binds exact scope and baseline / candidate version.
GM-VAL-02  Every required check has status and evidence or governed N/A.
GM-VAL-03  Every outcome has accountable human authority.
GM-VAL-04  Every condition has owner, evidence, deadline or trigger, restriction, and consequence.
GM-VAL-05  Every HOLD identifies missing input and route.
GM-VAL-06  Every REJECT identifies material deficiency and re-entry phase.
GM-VAL-07  Every gate lists upstream decisions and versions.
GM-VAL-08  Every material source change triggers downstream impact analysis.
GM-VAL-09  Every gate preserves historical decisions.
GM-VAL-10  No gate claims more than its decision question.
GM-VAL-11  G6A cannot mark independent verification complete.
GM-VAL-12  G6B cannot authorize production exposure.
GM-VAL-13  G7 cannot authorize an unequal candidate or ambiguous target.
GM-VAL-14  G8 cannot replace G7 for live change.
GM-VAL-15  Gate evidence and conditions remain traceable to GOV-008 and GOV-009 where applicable.
GM-VAL-16  Every gate identifies the active GOV-001 version and constitution exceptions.
GM-VAL-17  Every gate consumes a reproducible exact-scope GOV-002 artifact-register view.
```

---

# 44. Gate Map Maintenance

Update when a gate question, check set, baseline, outcome vocabulary, authority, validity, or reopen rule changes.

Updating this map does not update the owning phase automatically; both sources must be versioned together.

---

# 45. Final Gate Principle

> **A Product OS gate is trustworthy when an accountable person can state exactly what was decided, for which scope and version, from which evidence, under which conditions, for how long, what becomes allowed next, and what would reopen the decision.**
