# Product OS v1.0 — Governance Artifact Contract
## GOV-009: Standards & Compliance Applicability Matrix

**Artifact ID:** `GOV-009`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — CONTRACT COMPLETE`  
**Lifecycle Scope:** `PHASE-00` through `PHASE-11`  
**Canonical Owner:** Product OS Governance  
**Primary Purpose:** منع تجاهل standards أو إعادة تفسيرها بصورة متعارضة عبر الـBRD والـSRS والتصميم والمعمارية والتنفيذ والاختبار والإطلاق.

---

# 1. Purpose

`GOV-009` هو الـcanonical control artifact الذي يجيب عن:

```text
Which standards and compliance profiles exist?
Which apply to this product?
Why do they apply or not apply?
Who owns and approves the decision?
What business and product obligations result?
What system requirements must be derived?
What design, architecture, implementation, QA, and release work is required?
What evidence proves completion?
What change would reopen the decision?
```

الـmatrix لا تستبدل الـstandard الأصلي، ولا تعيد كتابة متطلباته كنسخة منافسة. هي تحفظ applicability decision والـlineage إلى canonical Product OS objects.

---

# 2. Authority Model

```text
Product OS Constitution
        ↓
Universal Standards
        ↓
Conditional Compliance Profiles
        ↓
GOV-009 Applicability Decisions
        ↓
Project Business / Product / System Obligations
```

Lower layers may strengthen an upstream obligation.

Lower layers must not weaken or exclude it silently.

---

# 3. Classification

## 3.1 Universal Standard

يمثل طريقة المؤسسة الأساسية في بناء production-grade software.

```text
classification: UNIVERSAL_STANDARD
```

الـUniversal Standard يظل applicable افتراضيًا، وقد تكون بعض clauses داخله conditional بسبب platform أوcapability محددة.

## 3.2 Conditional Compliance Profile

يتفعل بسبب:

```text
Product
Customer
Geography
Industry
Contract
Regulation
Data Type
Transaction Type
```

```text
classification: CONDITIONAL_PROFILE
```

## 3.3 Capability Module

مثل payments أوmulti-tenancy أوoffline sync هو Product OS capability module، وليس compliance profile.

```text
classification: CAPABILITY_MODULE
```

Capability modules تملك activation rules مستقلة، وقد تفعّل standards أوprofiles إضافية.

---

# 4. Applicability Status

Canonical values:

```text
APPLICABLE
NOT_APPLICABLE
PENDING
```

## APPLICABLE

يوجد trigger مثبت يفرض standard/profile أوclause محددة.

## NOT_APPLICABLE

لا يوجد trigger حاليًا، مع تسجيل:

```text
Reason
Decision Owner
Evidence
Approval
Reopen Condition
```

## PENDING

المعلومات أوauthority اللازمة للحسم غير متاحة.

`PENDING` يجب أن تحدد:

```text
Blocking: YES / NO
Decision Owner
Required Evidence
Due Gate
```

---

# 5. Decision Status

```text
PROPOSED
IN_REVIEW
APPROVED
DEFERRED
REJECTED
REOPENED
```

Applicability وDecision Status حقول منفصلة.

مثال:

```yaml
applicability: APPLICABLE
decision_status: IN_REVIEW
```

يعني التحليل يرى أنه applicable، لكن authority لم تعتمد القرار بعد.

---

# 6. Canonical Record Contract

```yaml
entry_id: GOV-009-ENTRY-001

source:
  source_id: SRC-STD-001
  source_version: "1.0"
  title: "Digital Accessibility Standard"
  classification: UNIVERSAL_STANDARD
  authority_level: C1_ORGANIZATION

scope:
  product_id: PROJECT-001
  clauses: []
  platforms: []
  markets: []
  data_types: []
  journeys: []
  affected_documents: []
  third_parties: []

applicability:
  status: PENDING
  activation_triggers: []
  rationale: null
  evidence: []
  decision_owner: UNASSIGNED
  decision_status: PROPOSED
  approved_by: []
  approved_at: null
  blocking: true
  due_gate: G2

business_linkage:
  requirements: []
  rules: []
  policies: []
  controls: []
  information_obligations: []
  evidence_obligations: []

product_implications:
  capabilities: []
  constraints: []
  policies: []
  supported_platforms: []
  affected_journeys: []
  affected_documents: []
  third_parties: []

requirements_derivation:
  required: false
  target_types: []
  derived_requirement_ids: []

downstream:
  experience: NOT_EVALUATED
  design: NOT_EVALUATED
  architecture: NOT_EVALUATED
  engineering_readiness: NOT_EVALUATED
  implementation: NOT_EVALUATED
  verification: NOT_EVALUATED
  release_gate: NOT_EVALUATED
  operations: NOT_EVALUATED

verification:
  methods: []
  evidence_ids: []
  status: NOT_STARTED

reopen_conditions: []
affected_artifacts: []
last_reviewed_at: null
last_reviewed_by: null
```

---

# 7. Required Lineage

```text
Source Standard / Profile
          ↓
GOV-009 Entry
          ↓
Business Requirement / Rule / Control / Policy
          ↓
Product Capability / Constraint / Policy
          ↓
System Requirement
          ↓
Experience / Design / Architecture Decision
          ↓
Implementation Task
          ↓
Test Case
          ↓
Release Gate
          ↓
Evidence
```

Canonical abbreviated chain:

```text
STD / PROFILE
→ GOV-009
→ BREQ / BR / CTRL / POL / INFO / EVID
→ PCAP / PCON / PPOL
→ FR / NFR / SEC / ACC / AUD / DR / INT
→ DES / ARCH
→ TASK
→ TC
→ RG
→ EVID
```

---

# 8. Lifecycle Responsibilities

| Phase | Mandatory GOV-009 responsibility |
|---|---|
| Phase 00 — Initialization & Intake | Detect triggers, register sources, create preliminary entries, mark unknowns `PENDING`. |
| Phase 01 — Discovery & Problem Definition | Collect user, market, platform, geography, contract, regulation, accessibility, data, and operational evidence. |
| Phase 02 — Business Architecture | Decide business applicability and create canonical business requirements/rules/controls/policies/information/evidence obligations. |
| Phase 03 — Product Definition | Convert applicable obligations into product capabilities, constraints, policies, platform commitments, journey/document/third-party implications, and Phase 04 derivation obligations. |
| Phase 04 — Requirements Engineering | Derive atomic, implementation-independent and verifiable FR/NFR/SEC/ACC/AUD/DR/INT requirements with acceptance criteria. |
| Phase 05 — Experience Architecture | Map obligations to journeys, states, interaction rules, error/recovery, keyboard, assistive technology, RTL/LTR, and responsive behavior. |
| Phase 06 — Product Design | Apply standards to tokens, components, visual states, content, contrast, focus, touch, reflow, prototypes, and design evidence. |
| Phase 07 — Solution Architecture | Map obligations to identity, data, privacy, logging, audit, reliability, infrastructure, integrations, and ADRs. |
| Phase 08 — Engineering Readiness | Confirm downstream coverage, DoR, traceability, testability, owners, and evidence plans. |
| Phase 09 — Implementation | Implement controls and preserve traceability to tasks, code, configuration, CI/CD, and deviations. |
| Phase 10 — Verification & Release | Execute test matrices, resolve defects/exceptions, retain evidence, and enforce release gates. |
| Phase 11 — Operations & Evolution | Monitor regressions, incidents, audit findings, expiring exceptions, regulatory changes, and reopen conditions. |

---

# 9. Phase 02 Closure Contract

Phase 02 has completed its responsibility when:

1. All known standards/profiles have an entry.
2. All relevant entries have `APPLICABLE`, `NOT_APPLICABLE`, or governed `PENDING` status.
3. Business-facing obligations have canonical Product OS IDs.
4. The BRD references the applicable entries and business obligations.
5. Owners and approval routes are explicit.
6. Product implications are identified for Phase 03.
7. Requirement-derivation flags are identified for Phase 04.
8. G2 includes the standards business-linkage check.
9. No applicable obligation is silently deferred to QA.

---

# 10. Phase 03 Closure Contract

Phase 03 has completed its responsibility when:

1. Applicable universal standards are reflected in the Product Baseline.
2. Activated conditional profiles are reflected in product scope and constraints.
3. Each applicable business obligation maps to a product capability, constraint, policy, supported-platform commitment, journey/document/third-party implication, or an explicit no-product-impact rationale.
4. Phase 04 derivation obligations are explicit by requirement type.
5. Ownership, rationale, and dependencies are recorded.
6. G3A includes a mandatory Standards Applicability Review.
7. No Product Baseline passes G3A with blocking `PENDING` applicability decisions.

---

# 11. Delivery Profile Behavior

The selected Product OS Delivery Profile controls artifact depth, not whether applicable obligations exist.

## P1 — Lean

- May keep the matrix in one composite governance artifact.
- Keeps the complete applicability decision, owner, rationale, downstream obligation, and reopen condition.
- May use grouped downstream links where risk permits.

## P2 — Standard

- Maintains independent entries and explicit business/product/system links.
- Requires structured gate checks and evidence references.
- Uses canonical IDs throughout the critical chain.

## P3 — Comprehensive

- Supports clause-level applicability.
- Requires independent owners/approvers and formal evidence.
- Maintains full traceability to design, architecture, implementation, tests, release, and operations.
- Requires versioned baselines and formal impact analysis.

`P1` must not weaken a constitutional or universal obligation.

---

# 12. Accessibility Example

```yaml
entry_id: GOV-009-ENTRY-A11Y

source:
  source_id: STD-A11Y
  source_version: "WCAG-2.2-AA-baseline"
  title: "Digital Accessibility"
  classification: UNIVERSAL_STANDARD
  authority_level: C1_ORGANIZATION

scope:
  platforms:
    - WEB
    - MOBILE
  journeys:
    - AUTHENTICATION
    - CRITICAL_PRODUCT_JOURNEYS
  affected_documents:
    - GENERATED_PDF
    - GENERATED_REPORTS
  third_parties:
    - INTEGRATED_USER_FACING_COMPONENTS

applicability:
  status: APPLICABLE
  activation_triggers:
    - WEB_APPLICATION
    - MOBILE_APPLICATION
    - GENERATED_DOCUMENTS
    - THIRD_PARTY_USER_JOURNEYS
  rationale: "Digital product surfaces and generated documents are in scope."
  evidence:
    - SRC-PRODUCT-PLATFORMS
    - SRC-A11Y-BRD
  decision_owner: PRODUCT_OWNER
  decision_status: APPROVED
  approved_by:
    - PRODUCT_OWNER
  blocking: true
  due_gate: G2

business_linkage:
  requirements:
    - canonical_id: BREQ-A11Y-001
      source_ref: BR-A11Y-001
      subject: KEYBOARD_ACCESSIBILITY
    - canonical_id: BREQ-A11Y-002
      source_ref: BR-A11Y-002
      subject: SCREEN_READER_COMPATIBILITY
    - canonical_id: BREQ-A11Y-003
      source_ref: BR-A11Y-003
      subject: COLOUR_AND_CONTRAST
    - canonical_id: BREQ-A11Y-004
      source_ref: BR-A11Y-004
      subject: FORMS_AND_ERROR_HANDLING
    - canonical_id: BREQ-A11Y-005
      source_ref: BR-A11Y-010
      subject: ACCESSIBLE_DOCUMENTS
    - canonical_id: BREQ-A11Y-006
      source_ref: BR-A11Y-011
      subject: THIRD_PARTY_CONTINUITY

product_implications:
  capabilities:
    - ACCESSIBLE_AUTHENTICATION
    - ACCESSIBLE_CRITICAL_JOURNEYS
    - ACCESSIBLE_DOCUMENT_OUTPUT
  constraints:
    - WCAG_2_2_AA
    - KEYBOARD_OPERABLE
    - ASSISTIVE_TECHNOLOGY_COMPATIBLE
    - RTL_LTR_ACCESSIBLE
  affected_journeys:
    - SIGN_IN
    - ACCOUNT_RECOVERY
    - CRITICAL_PRODUCT_JOURNEYS
  affected_documents:
    - PDF
    - REPORTS
  third_parties:
    - USER_FACING_COMPONENTS

requirements_derivation:
  required: true
  target_types:
    - ACC
    - NFR
    - SEC
    - DR
    - INT
  derived_requirement_ids: []

downstream:
  experience: REQUIRED
  design: REQUIRED
  architecture: REQUIRED
  engineering_readiness: REQUIRED
  implementation: REQUIRED
  verification: REQUIRED
  release_gate: REQUIRED
  operations: REQUIRED

reopen_conditions:
  - NEW_PLATFORM
  - NEW_CRITICAL_JOURNEY
  - NEW_DOCUMENT_FORMAT
  - NEW_USER_FACING_THIRD_PARTY
  - ACCESSIBILITY_BASELINE_CHANGE
```

The example maps external BRD IDs to Product OS canonical `BREQ-*` IDs because `BR-*` is already reserved for Business Rules inside Product OS.

---

# 13. Conditional Profile Example

```yaml
entry_id: GOV-009-ENTRY-HIPAA

source:
  source_id: PROFILE-HIPAA
  source_version: "current-reviewed-version"
  title: "Healthcare / HIPAA Compliance Profile"
  classification: CONDITIONAL_PROFILE
  authority_level: C1_ORGANIZATION

applicability:
  status: NOT_APPLICABLE
  activation_triggers: []
  rationale: "Product does not process regulated United States healthcare data."
  evidence:
    - SRC-DATA-SCOPE
    - SRC-MARKET-SCOPE
  decision_owner: COMPLIANCE_OWNER
  decision_status: APPROVED
  approved_by:
    - COMPLIANCE_OWNER
  blocking: false
  due_gate: G2

business_linkage:
  requirements: []
  rules: []
  controls: []

reopen_conditions:
  - US_HEALTHCARE_MARKET_ACTIVATED
  - PHI_PROCESSING_INTRODUCED
  - HEALTHCARE_CONTRACT_SIGNED
  - DATA_CLASSIFICATION_CHANGED
```

---

# 14. G2 Integration

G2 must verify:

```text
Known standards and profiles are registered.
Business applicability is explicit.
Material business obligations have canonical IDs.
Owners, approvals, evidence, and reopen conditions exist.
Phase 03 and Phase 04 obligations are explicit.
Blocking pending decisions equal zero.
```

---

# 15. G3A Integration

G3A must verify:

```text
Applicable standards are represented in the Product Baseline.
Conditional profiles are reflected in scope, capability, policy, and constraint decisions.
Supported platforms, countries, languages, documents, third parties, and enterprise capabilities are consistent with GOV-009.
Requirement-derivation obligations for Phase 04 are complete.
Blocking pending applicability decisions equal zero.
```

---

# 16. Change and Reopen Rules

An entry becomes `REOPENED` or `REVIEW_REQUIRED` when any trigger changes:

```text
Platform
Market / Country
Language / Direction
Data Classification
Regulated Data
Payment Capability
Enterprise Customer Requirement
Contract
Industry
Generated Document
Third-Party Component
Authentication / Identity Model
Critical Journey
Standard Version
Product OS Constitution
```

Reopening must identify affected canonical objects and mark downstream approved artifacts:

```text
REVIEW_REQUIRED
```

until impact analysis is complete.

---

# 17. Anti-Patterns

## AP-GOV009-01 — Standards at QA Only

Accessibility/security/privacy/reliability appears for the first time during testing.

## AP-GOV009-02 — Silent Not Applicable

No reason, owner, evidence, or reopen condition exists.

## AP-GOV009-03 — Compliance Profile = Capability Module

Payments or multi-tenancy is treated as a regulatory profile, or HIPAA is treated as a product module.

## AP-GOV009-04 — Copying the Standard Everywhere

The same obligation is rewritten independently in BRD, SRS, design, architecture, and QA instead of referenced through canonical IDs.

## AP-GOV009-05 — Delivery Profile Weakens the Standard

P1 Lean is used as a reason to drop an applicable constitutional or universal obligation.

## AP-GOV009-06 — Approval Invented by AI

AI-generated applicability analysis is marked approved without accountable human authority.

---

# 18. Completion Contract

`GOV-009` is operationally complete for a gate when:

1. Required sources are registered and versioned.
2. Applicability status is explicit.
3. Decision status and authority are explicit.
4. Rationale and evidence are retained.
5. Business linkage is complete for the current lifecycle point.
6. Product and requirement-derivation implications are explicit when required.
7. Downstream responsibilities are assigned.
8. Verification and evidence expectations are defined.
9. Reopen conditions are defined.
10. No blocking `PENDING` entry remains for the gate.

---

# 19. Final Principle

```text
Standards do not sit beside the lifecycle.
They enter through governed applicability decisions,
inherit into canonical business and product intent,
and remain traceable until release evidence and operations.
```
