# Product OS v1.0 — Cross-Tool Validation, Metrics, and Anti-Patterns

~~~yaml
document_id: FRAMEWORK-CROSS-TOOL-VALIDATION-METRICS-ANTI-PATTERNS
version: 0.1.0
status: WORKING_DRAFT
completion_state: SEVENTY_VALIDATIONS_AND_THIRTY_FIVE_ANTI_PATTERNS_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
validation_rule_count: 70
anti_pattern_count: 35
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines deterministic checks and failure patterns for the Product OS mapping to Spec Kit, Figma, and GitHub.

Validation outcomes are `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or governed `NOT_APPLICABLE`. A dashboard green state never overrides a failed gate-critical rule.

---

# 2. Validation Rules — 70

## A. Scope, identity, and registry — V01–V10

1. **V01 — Project boundary:** every mapping names the exact project/product/domain/release scope and contains no cross-project contamination.
2. **V02 — Logical identity:** every representation resolves to a registered stable Product OS subject or bounded composite membership.
3. **V03 — Tool system identity:** every native object names exact tool installation/tenant/organization/workspace.
4. **V04 — Container identity:** Spec Kit root/feature, Figma file/library, and GitHub repository/environment are exact and resolvable.
5. **V05 — Native object identity:** native IDs are present; human names and URLs are not used alone.
6. **V06 — Revision identity:** baselines/evidence use exact version, commit SHA, digest, or approved archive snapshot.
7. **V07 — Mutable locator labeling:** mutable navigation links are identified and never presented as immutable proof.
8. **V08 — Rename/move lineage:** renamed, moved, transferred, copied, forked, replaced, archived, and deleted objects have correct identity disposition.
9. **V09 — Registry lifecycle:** each mapping has one valid eight-state mapping status with dates/owner and supersession where applicable.
10. **V10 — Applicability:** tool/artifact N/A decisions include exact scope, reason, authority, evidence, review, and reopen trigger.

## B. Ownership, role, and authority — V11–V20

11. **V11 — Canonical semantic owner:** every governed field has one competent semantic owner for exact scope/version.
12. **V12 — Native owner:** specialist native objects identify their source tool without absorbing unrelated semantic authority.
13. **V13 — Representation role:** each mapping uses exactly one of the eight roles and its behavior matches that role.
14. **V14 — Field ownership:** multi-system records define field-level writers and protected fields.
15. **V15 — Access versus authority:** technical permission is not used as approval/action authority evidence.
16. **V16 — Approval separation:** authorship, review, approval, verification, release authorization, and execution remain distinguishable.
17. **V17 — Competent actor:** publishers, mergers, verifiers, releasers, deployers, and migration owners have required authority/competence.
18. **V18 — Segregation:** applicable independence and segregation rules are satisfied or formally excepted.
19. **V19 — AI boundary:** AI actions have run/action identity, authority, controls, attribution, and evidence under the AI Operating Specification.
20. **V20 — Protected states:** automation cannot write risk acceptance, approval, verification acceptance, baseline, gate, or G7 state without its separate authorized workflow.

## C. Spec Kit — V21–V30

21. **V21 — Version registration:** exact Spec Kit distribution/tool/template version or commit is registered.
22. **V22 — Constitution source:** constitution projection cites exact GOV-001/GOV-009/AI/engineering source versions.
23. **V23 — Constitution drift:** upstream or template change marks projection/packets stale until reviewed.
24. **V24 — Feature packet identity:** every packet names feature/change kind, upstream baselines, profile, scope, owner, repository base, and status.
25. **V25 — Specification provenance:** copied/summarized/proposed statements are distinguished and trace to canonical requirements/products.
26. **V26 — Information classification:** assumptions, questions, decisions, requirements, sources, evidence, and tasks are not flattened into prose.
27. **V27 — Plan completeness:** technical plan covers all applicable design, architecture, data, security/privacy, quality, operations, deployment, and recovery dimensions.
28. **V28 — Task executability:** each task has stable ID, outcome, scope/paths, dependencies, owner, criteria, evidence, and risk triggers.
29. **V29 — Command preconditions:** clarify/plan/tasks/analyze/checklist/issue/implement operations meet their defined preconditions and authority.
30. **V30 — No self-approval:** packet generation, analysis pass, checklist completion, issue closure, or implement completion does not change Product OS gate/acceptance state automatically.

## D. Figma — V31–V40

31. **V31 — Design source register:** every governed design subject is in DES-020 with file/node/branch/version identity.
32. **V32 — Main/branch clarity:** main file, active branch, archived branch, source checkpoint, review, and merge status are unambiguous.
33. **V33 — Baseline immutability:** G4B membership references exact version/checkpoint and subject set, not current-main alone.
34. **V34 — Logical design IDs:** components/screens/patterns/tokens/assets carry or map to stable Product OS design IDs.
35. **V35 — Coverage dimensions:** required states, viewports/platforms, accessibility, languages/RTL, themes, roles, content, and errors are covered or governed N/A.
36. **V36 — Library lifecycle:** design, review, approval, publication, availability, consumer acceptance, instance use, code adoption, verification, and retirement are separate.
37. **V37 — Component identity:** component/set/key/variant/property and instance/source relationships are resolvable.
38. **V38 — Export provenance:** exported assets/images/prototypes include source file/node/version/parameters/digest/time.
39. **V39 — Handoff completeness:** DES-023 names exact design, upstream obligations, code targets, assets, states, exceptions, owner, and verification criteria.
40. **V40 — Adoption proof:** ENG-009/IMP-005/006 distinguish mapped, defined, actively used, partially adopted, deviated, and verified states.

## E. GitHub — V41–V50

41. **V41 — Repository identity:** every repository mapping includes exact GitHub system, organization/owner, repository ID/name, visibility, canonical role, and default branch.
42. **V42 — Source permalink:** file/code evidence uses repository/path/commit SHA or digest; branch URL is supplementary.
43. **V43 — Ownership/protection:** modules/paths have owners and required branch/tag/environment rules are active and reviewed.
44. **V44 — Issue state separation:** issue/project delivery state never substitutes for artifact, acceptance, defect-verification, or gate state.
45. **V45 — PR trace:** PRs link exact task/change/requirement/design/architecture scope and changed paths.
46. **V46 — Review freshness:** approvals/reviews apply to current material diff; dismissed/stale/bypass/self/bot reviews are visible.
47. **V47 — CI identity:** run evidence includes workflow definition revision, run/attempt, trigger, actor, SHAs, runner, inputs, result, artifacts, and limitations.
48. **V48 — Artifact provenance:** build/package/container has source SHA, workflow/builder, dependency context, digest, retention, and signatures/attestations where required.
49. **V49 — Candidate identity:** IMP-029 fixes source/build/config/schema/flag/environment/data/design identities and known deviations.
50. **V50 — Release separation:** GitHub tag/release/deployment records link to but never replace G6B, G7, execution-deviation, and post-release validation records.

## F. Synchronization, conflict, and change — V51–V60

51. **V51 — Sync mode:** every active synchronization uses one of six modes with direction, allow-list, trigger, owner, and conflict rule.
52. **V52 — Revision precondition:** writes compare expected source/target revisions and detect concurrent changes.
53. **V53 — Idempotency/order:** event integrations handle duplicates, retries, and out-of-order delivery without state regression.
54. **V54 — Partial failure:** exact changed subset, failure, recovery/rollback, and resulting mapping status are recorded.
55. **V55 — Conflict preservation:** both values/revisions/provenance are retained; governed conflicts never use silent last-write-wins.
56. **V56 — Promotion:** proposed tool content has accept/modify/reject/defer decision and resulting canonical version.
57. **V57 — Stale propagation:** upstream change marks affected projections, mappings, reviews, evidence, candidates, or releases stale/invalidated as required.
58. **V58 — Change traversal:** material tool/config/access/vendor changes enter GOV-007 and traverse Product OS/cross-tool dependencies.
59. **V59 — Reopen behavior:** gate/baseline/candidate/release/live-scope reopen follows Change Impact Rules and preserves prior decisions.
60. **V60 — Reconciliation closure:** repaired objects, regenerated views, downstream acknowledgements, evidence, and residual risks are complete before closure.

## G. Evidence, access, resilience, and exit — V61–V70

61. **V61 — Claim binding:** every captured tool result identifies the claim/criterion it supports and exact candidate/scope.
62. **V62 — Evidence fitness:** source authority/reliability, method, result, integrity, freshness, limitations, and admissibility are evaluated.
63. **V63 — Evidence retention:** expiring logs/artifacts/versions are archived or re-executed before required proof is lost.
64. **V64 — Sensitive data:** exports, issues, designs, logs, artifacts, and mappings minimize and protect secrets/personal/restricted data.
65. **V65 — Access register:** human/service/app/bot/AI access has purpose, scopes, authority, owner, review/expiry, and revocation.
66. **V66 — Integration safety:** each automation has least privilege, protected fields, monitoring, kill switch, manual fallback, and recovery.
67. **V67 — Degraded mode:** outages/delays expose freshness and never create false success or decisions from stale state.
68. **V68 — Export integrity:** exchange envelopes contain schema/version, objects, relationships, tombstones, exclusions, digests, access, and validation.
69. **V69 — Migration validation:** identity, counts, content, history, relationships, permissions, automations, native behavior, evidence, and rollback are tested.
70. **V70 — Exit continuity:** Product OS meaning, critical native sources, crosswalks, evidence, access retirement, and operational handoff survive tool exit.

---

# 3. Anti-Patterns — 35

1. **AP01 — Tool equals truth:** declaring Figma, GitHub, or Spec Kit universally canonical without field/scope ownership.
2. **AP02 — URL identity:** storing only a clickable URL or human name.
3. **AP03 — Mutable evidence:** citing a branch/main-current link as immutable baseline proof.
4. **AP04 — Folder ontology:** assuming physical folder/location determines artifact type or authority.
5. **AP05 — Copy transfers ownership:** treating synchronized/generated text as canonical because it exists locally.
6. **AP06 — Access grants authority:** allowing editor/admin/token scope to stand in for approval.
7. **AP07 — Status collapse:** equating issue closed, PR merged, check green, library published, or command complete with acceptance.
8. **AP08 — Approval by comment:** treating resolved comments/review reactions as the decision record.
9. **AP09 — Silent last-write-wins:** overwriting governed fields based on recency.
10. **AP10 — Two canonical writers:** unbounded bidirectional synchronization of the same semantic fields.
11. **AP11 — Unversioned constitution:** Spec Kit constitution has no GOV-001 source/version or drift check.
12. **AP12 — Generated requirement invention:** Spec Kit adds scope/requirements without classification and promotion.
13. **AP13 — Template residue:** unresolved tokens/examples appear as project facts.
14. **AP14 — Task without trace:** a task/issue lacks requirement/design/plan/change origin.
15. **AP15 — Implement bypass:** Spec Kit implementation starts without readiness, authority, exact target, or preflight.
16. **AP16 — Canvas approval:** Figma node/page name such as “Final” is treated as G4B.
17. **AP17 — Published equals adopted:** library publication is counted as consumer or code adoption.
18. **AP18 — Defined equals used:** code/design component existence is counted as active product adoption.
19. **AP19 — Screenshot proof:** screenshot alone is used to prove interaction, semantics, accessibility, responsiveness, or code identity.
20. **AP20 — Node-name mapping:** design-to-code relies on names without stable design/node/version IDs.
21. **AP21 — Current-main handoff:** engineering receives a mutable Figma main link with no version membership.
22. **AP22 — Generic repository drift:** canonical repositories/modules are renamed to generic frontend/backend/mobile/database labels.
23. **AP23 — Issue completion authority:** issue state writes upstream artifact/gate state automatically.
24. **AP24 — PR merge verification:** merge is considered proof of requirement satisfaction or deployment.
25. **AP25 — Green check absolutism:** one check is treated as full coverage without candidate/environment/method scope.
26. **AP26 — Retry erasure:** successful rerun hides failures/flakiness or changes the tested conditions.
27. **AP27 — Release object authorization:** GitHub Release creation substitutes for G7.
28. **AP28 — Deployment success health:** provider success substitutes for post-release/live validation.
29. **AP29 — Evidence without retention:** critical logs/artifacts expire before audit/reuse period.
30. **AP30 — Secret in mapping:** credential values enter specs, Figma, issues, PRs, logs, or evidence packs.
31. **AP31 — Cross-project contamination:** similarly named file/repository/environment/object is linked without tenant/project verification.
32. **AP32 — Orphan automation:** integration has no owner, field allow-list, monitoring, recovery, or kill switch.
33. **AP33 — Broken link deletion:** missing/inaccessible object is removed from the register instead of preserved and repaired.
34. **AP34 — Copy-only migration:** files are copied without IDs, history, relationships, permissions, evidence, behavior, or validation.
35. **AP35 — Tool lock-in as governance:** inability to export/exit is accepted despite loss of Product OS meaning or required evidence.

---

# 4. Metrics

| Metric | Formula/interpretation |
|---|---|
| Explicit mapping coverage | activated artifact/tool relationships with active or governed N/A disposition ÷ expected relationships |
| Exact identity coverage | active mappings with tool/container/native/revision identity ÷ active mappings |
| Immutable evidence coverage | gate/release-critical evidence with immutable/versioned locator or archived digest ÷ required evidence |
| Feature trace coverage | in-scope requirements represented or approved-excluded in Spec Kit ÷ in-scope requirements |
| Design coverage | required design dimensions represented/approved N/A ÷ required dimensions |
| Active code adoption | verified active Figma-to-code uses ÷ applicable design subjects |
| Work trace coverage | issues/PRs with authorized task/change origin ÷ scoped delivery objects |
| Candidate evidence match | accepted evidence matching exact candidate dimensions ÷ accepted evidence |
| Freshness compliance | mappings reconciled within rule ÷ active mappings |
| Broken locator rate | unresolved moved/deleted/access/expiry mappings ÷ active mappings |
| Conflict age | time from detected conflict to competent disposition |
| Sync reliability | successful verified workflow runs ÷ attempted runs, with partial/retry separately visible |
| Unauthorized/bypass rate | unauthorized or bypass events per review period; target zero |
| Migration/exit readiness | critical objects/relationships/evidence with validated portable disposition ÷ critical scope |

No metric converts missing evidence into success through denominator manipulation. Governed N/A is visible separately.

---

# 5. Assurance Procedure

1. Select exact project/domain/release/profile/tool scope.
2. Freeze Product OS catalog/baseline and tool-system versions.
3. Run V01–V70, recording evidence and N/A authority.
4. Prioritize gate-critical identity, ownership, authority, candidate, evidence, release, security/privacy, and broken-link failures.
5. Traverse each failure through Change Impact Rules.
6. Repair canonical records/native objects, then regenerate views.
7. Re-run failed and dependent rules.
8. Obtain independent review where profile/risk requires.
9. Record residual conditions/risks and decision authority.
10. Publish assurance result without claiming Product OS approval or baseline.

---

# 6. Final Validation Principle

> **The mapping passes only when every important tool convenience remains subordinate to exact identity, ownership, authority, version, traceability, evidence, recovery, and exit continuity.**

