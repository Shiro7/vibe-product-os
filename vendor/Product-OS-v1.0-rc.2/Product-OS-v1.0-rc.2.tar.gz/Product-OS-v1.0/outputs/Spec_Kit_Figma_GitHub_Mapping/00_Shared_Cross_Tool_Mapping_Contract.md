# Product OS v1.0 — Shared Cross-Tool Mapping Contract

~~~yaml
contract_id: SHARED-CROSS-TOOL-MAPPING-CONTRACT
contract_version: 0.1.0
contract_status: WORKING_DRAFT
completion_state: SHARED_CROSS_TOOL_MAPPING_CONTRACT_COMPLETE
applies_to: ALL_SPEC_KIT_FIGMA_GITHUB_MAPPINGS_REPRESENTATIONS_AND_SYNCHRONIZATIONS
logical_artifact_scope: 281
gate_scope: [G0, G1, G2, G3A, G3B, G4A, G4B, G5A, G5B, G6A, G6B, G7, G8]
classification_source: ../Classification_Rules.md
traceability_source: ../Traceability_Graph/Traceability_Graph_Index.md
change_source: ../Change_Impact_Rules/Change_Impact_Rules_Index.md
source_evidence_source: ../Source_Evidence_Model/Source_Evidence_Model_Index.md
ai_source: ../AI_Operating_Specification/AI_Operating_Specification_Index.md
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This contract defines the obligations inherited by every Product OS mapping to a Spec Kit file or command, Figma object, GitHub object, synchronization, export, import, integration, migration, or tool-generated event.

Specialized files refine this contract. They may strengthen but cannot silently weaken it.

---

# 2. Scope

The contract applies to:

- framework and project-instance mappings;
- logical artifacts, nested governed objects, claims, decisions, requirements, controls, risks, changes, sources, evidence, baselines, and gates;
- Spec Kit constitutions, feature specifications, research, data models, contracts, plans, tasks, checklists, analysis results, issue projections, and implementation runs;
- Figma teams, projects, files, libraries, pages, sections, frames, components, component sets, instances, variables, styles, prototypes, branches, versions, exports, comments, and Dev Mode references;
- GitHub organizations, repositories, paths, blobs, trees, commits, branches, tags, issues, projects, pull requests, reviews, checks, workflows, runs, artifacts, packages, releases, deployments, environments, and security records;
- human, AI, automation, API, webhook, import, export, migration, and recovery operations.

---

# 3. Non-Scope

This contract does not:

- approve a vendor, subscription, organization, repository, Figma file, integration, credential, bot, app, or AI agent;
- create project-specific source-of-truth assignments;
- grant tool access or action authority;
- define physical JSON/YAML/database schemas or repository directory layout;
- define command implementations, CI configuration, or automation code;
- make a tool status equivalent to a Product OS artifact, verification, baseline, gate, or release decision;
- replace tool-native security, retention, backup, contractual, or regulatory obligations.

---

# 4. Core Object Model

| Object | Meaning | Minimum identity |
|---|---|---|
| Logical subject | Product OS artifact or governed nested object whose meaning is represented | subject type, stable ID, version/scope, canonical owner |
| Tool system | Exact Spec Kit installation/profile, Figma organization/workspace, or GitHub organization/enterprise | system ID, vendor, tenant/org, environment, owner, status |
| Native object | Specialist object whose authoritative form lives in the named tool | object type, tool-native ID, container, locator, revision |
| Representation | Tool-specific expression of a logical subject | representation ID, subject ref, role, tool object, mapping status |
| Mapping | Governed assertion connecting subject and representation | mapping ID/version, scope, role, sync mode, direction, owner |
| Synchronization | Bounded exchange of fields or events | sync ID, source/target, allowed fields, trigger, conflict rule, result |
| Promotion | Review that accepts proposed content into a canonical owner | proposal, target, reviewer/authority, decision, resulting version |
| Evidence capture | Registration of exact observed tool result | claim, evidence identity, revision, collector, integrity, fitness |
| Conflict | Two representations assert incompatible current meaning or state | conflict ID, subjects, versions, difference, authority route |
| Mapping incident | Broken identity, unauthorized write, false status, lost history, leakage, or failed synchronization | incident ID, severity, impact, evidence, containment, owner |

---

# 5. Cross-Tool Invariants

1. Every representation points to one exact logical subject or declares its bounded multi-subject composition.
2. Every logical subject has one canonical semantic owner for each exact scope and version.
3. A native tool may own native structure without owning business meaning, approval, verification, or gate authority.
4. A URL is a locator, not identity by itself; identity includes system, object type, native ID, container, and version semantics.
5. Mutable locators may support navigation but cannot serve as sole baseline or evidence identity.
6. File names, node names, branch names, issue titles, labels, and status text are human-readable attributes, not stable cross-tool IDs.
7. Copying content does not transfer ownership; generated or synchronized copies retain provenance and projection status.
8. Tool permissions prove technical capability, not Product OS authority.
9. Issue closure, task completion, PR merge, check success, Figma publication, Spec Kit implementation, release creation, deployment request, or dashboard green state is not an automatic gate decision.
10. Approval, implementation, verification, release authorization, deployment execution, and live validation remain separate events.
11. Evidence references resolve to the exact tested or observed candidate, revision, environment, and time window.
12. Automated synchronization is limited to approved fields, directions, triggers, identities, service accounts, and failure behavior.
13. Conflicts are preserved; last-write-wins is prohibited for governed meaning, authority, baseline, risk, requirement, design approval, verification, or release state.
14. Renames and moves update locators without changing stable subject identity; replacement, fork, and duplication create explicit lineage.
15. Deleted, inaccessible, or expired tool objects never disappear silently from the register; they become broken/stale with recovery disposition.
16. Tool-derived content remains `PROPOSED`, `WORKING_PROJECTION`, or `DERIVED_VIEW` until the canonical owner promotes it.
17. Sensitive data uses the minimum necessary fields and least-privilege access; secrets are never embedded in mappings or exported evidence packs.
18. Historical mappings, promotions, conflicts, failures, and supersessions remain audit-preserved under retention rules.
19. AI follows the AI Operating Specification; commands and connectors do not amplify its authority.
20. P1/P2/P3 alter packaging, automation, and assurance depth but not ownership, identity, authority, evidence, or reopen obligations.

---

# 6. Mapping Lifecycle

~~~text
UNMAPPED
  → PROPOSED
  → ACTIVE
  → ACTIVE_WITH_GAPS
  → STALE or CONFLICTED
  → ACTIVE after repair/reconciliation
  → SUPERSEDED
  → RETIRED
~~~

Rules:

- `UNMAPPED` means an expected mapping has no governed record.
- `PROPOSED` is reviewed before any authoritative synchronization.
- `ACTIVE` requires resolvable identities, valid scope, owner, role, sync mode, and current reconciliation.
- `ACTIVE_WITH_GAPS` identifies exact missing links without hiding usable coverage.
- `STALE` means the source/target changed, expired, moved without reconciliation, or exceeded review freshness.
- `CONFLICTED` blocks automatic authoritative promotion for affected fields.
- `SUPERSEDED` points to successor and preserves history.
- `RETIRED` closes current use while preserving audit history and migration/retention disposition.

---

# 7. Minimum Mapping Record

~~~yaml
mapping_id:
mapping_version:
logical_subject:
  subject_type:
  subject_id:
  subject_version:
  scope:
canonical_semantic_owner:
tool_system_id:
native_object:
  object_type:
  native_id:
  container_id:
  human_name:
  mutable_locator:
  immutable_or_versioned_locator:
  revision:
representation_role:
mapping_status:
applicability:
synchronization:
  mode:
  direction:
  allowed_fields: []
  trigger:
  automation_identity:
  conflict_policy:
authority_ref:
owner:
reviewer:
source_refs: []
evidence_refs: []
created_at:
last_reconciled_at:
freshness_rule:
access_classification:
retention_class:
supersedes:
superseded_by:
reopen_triggers: []
notes: []
~~~

For `NOT_APPLICABLE`, retain exact scope, reason, decision authority, evidence, review date, and reopen triggers.

---

# 8. Canonical Ownership Resolver

Resolve ownership in this order:

1. identify the exact statement or object in dispute;
2. identify its Product OS data class and artifact owner;
3. identify whether the named tool has a specialist native object for it;
4. separate semantic, native, register, projection, delivery, view, and evidence responsibilities;
5. apply project-specific approved source-of-truth assignment;
6. verify version, scope, authority, and lifecycle state;
7. record the mapping and any field-level exceptions;
8. route uncertainty or conflict to the competent owner; do not infer from recency alone.

Default ownership:

- Product OS artifact layer owns governed semantics, decisions, requirements, gates, and cross-tool mappings.
- Spec Kit owns its generated/maintained feature packet as a working execution projection.
- Figma owns native visual-design structures selected as design source.
- GitHub owns repository-native engineering source and native execution records.
- Evidence ownership remains with the governed evidence record; the generating tool is the evidence source, not the adjudicator of its sufficiency.

---

# 9. Synchronization Safety Contract

Before a synchronization:

- resolve exact source and target identities;
- confirm mapping is `ACTIVE` and not `CONFLICTED`;
- confirm action authority, tool permission, allowed direction, field allow-list, and environment;
- compare source and target revisions;
- detect concurrent edits and protected fields;
- create a recoverable checkpoint where supported;
- avoid secrets, restricted data, and unapproved external disclosure.

After a synchronization:

- record execution identity, timestamp, source/target revisions, fields changed, ignored fields, errors, and resulting status;
- verify intended changes and prohibited non-changes;
- preserve the canonical owner’s approval state;
- update traceability, impact, stale state, and downstream handoff;
- route partial failure to `ACTIVE_WITH_GAPS`, `STALE`, `CONFLICTED`, or incident handling.

---

# 10. Authority and Segregation

| Action | Minimum authority rule |
|---|---|
| Register read-only representation | Mapping owner or delegated operator within data/access policy |
| Create working projection | Artifact owner or bounded contributor; remains proposed |
| Promote projection into canonical artifact | Canonical artifact owner and required reviewer/approver |
| Publish Figma library change | Authorized design-system publisher after required design review |
| Merge protected code branch | Authorized repository actor after required reviews/checks |
| Change requirement, risk, baseline, or gate state | Product OS competent authority; tool state cannot substitute |
| Accept verification | Authorized verifier/acceptance owner independent where required |
| Authorize release | G7 release authority only |
| Deploy | Authorized deployment actor within G7 scope and environment controls |
| Modify cross-tool automation | Integration/configuration authority plus change review and evidence |

The same person may hold several roles where profile, risk, and policy permit; role combination never collapses the distinct decisions.

---

# 11. Profile Inheritance

P1 may combine registers physically, but each mapping remains separately addressable. P2 uses typed registers and automated integrity checks. P3 adds segregation, protected/published baselines, stronger custody, independent review, continuous drift detection, and rehearsed migration/exit.

Any domain override inherits upward without forcing unrelated domains to adopt the same physical depth.

---

# 12. Gate and Baseline Boundary

Every gate view may consume tool data, but the gate decision remains a Product OS decision record.

- G3A/G3B may reference a Spec Kit feature packet but baseline the canonical product/requirement scope.
- G4A/G4B may reference exact Figma versions/nodes but baseline governed experience/design scope.
- G5A/G5B may reference GitHub repository plans/configuration but baseline approved architecture/readiness.
- G6A may reference commits/builds and implementation records but does not verify the candidate.
- G6B uses exact candidate and evidence bindings; a green check alone is insufficient.
- G7 authorizes exact release scope; a GitHub Release object does not self-authorize.
- G8 uses live evidence and may route evolution; it does not replace G7 for a new release.

---

# 13. Change and Incident Boundary

Material mapping changes include:

- canonical owner reassignment;
- tool/tenant/repository/file replacement;
- identity/version semantics change;
- sync direction or field-set change;
- automation identity or permission change;
- branch/protection/release/environment policy change;
- evidence locator or retention change;
- bulk rename/move/delete/import/export/migration;
- vendor behavior or API change that affects meaning or integrity.

They enter GOV-007 and the Change Impact Rules. Unauthorized writes, false approvals, lost history, broken evidence, secret exposure, or cross-project contamination also invoke the AI/security/operational incident route as applicable.

---

# 14. Final Shared Principle

> **A cross-tool mapping is trustworthy only when exact identity, ownership, role, version, direction, authority, change, verification, and evidence survive every representation.**

