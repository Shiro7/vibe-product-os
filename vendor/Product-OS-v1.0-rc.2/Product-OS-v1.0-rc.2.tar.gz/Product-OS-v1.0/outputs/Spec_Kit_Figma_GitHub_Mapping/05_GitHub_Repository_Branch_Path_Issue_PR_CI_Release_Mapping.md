# Product OS v1.0 — GitHub Repository, Branch, Path, Issue, PR, CI, and Release Mapping

~~~yaml
document_id: FRAMEWORK-GITHUB-ENGINEERING-DELIVERY-MAPPING
version: 0.1.0
status: WORKING_DRAFT
completion_state: GITHUB_ENGINEERING_DELIVERY_MAPPING_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
primary_readiness_artifact: ENG-005
primary_implementation_artifact: IMP-001
primary_candidate_artifact: IMP-029
primary_release_authority_artifact: VRL-035
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification maps Product OS scope, requirements, designs, architecture, implementation, verification, release, and operations to exact GitHub engineering and delivery objects.

Official reference basis includes:

- `https://docs.github.com/en/repositories/working-with-files/using-files/getting-permanent-links-to-files`
- `https://docs.github.com/en/pull-requests/committing-changes-to-your-project/creating-and-editing-commits/about-commits`
- `https://docs.github.com/en/issues/tracking-your-work-with-issues/using-issues/linking-a-pull-request-to-an-issue`

Additional GitHub-native objects are mapped by their official API/documentation identity and recorded platform version/behavior where material.

---

# 2. GitHub Role Boundary

GitHub may be `CANONICAL_NATIVE` for:

- repository files at exact revisions: code, configuration, schemas, migrations, tests, workflow definitions, infrastructure definitions, and repository-owned documentation;
- commit and review history;
- workflow/check/run records, build artifacts/packages within retention limits;
- repository-native release/deployment/environment records where configured.

GitHub is normally `DELIVERY_OBJECT`, `WORKING_PROJECTION`, `DERIVED_VIEW`, or `EVIDENCE_REFERENCE` for:

- issues, project boards, milestones, labels, PR descriptions/checklists, generated specifications, gate summaries, release notes, and deployment views.

GitHub does not obtain Product OS requirement, risk, acceptance, gate, or release authority from repository permissions or object state.

---

# 3. Repository and Module Register — ENG-005

Each repository entry includes:

~~~yaml
repository_mapping_id:
product_and_domain_scope:
github_system_id:
organization_or_owner:
repository_id:
repository_name:
visibility:
canonical_or_mirror_or_archive:
default_branch:
branch_and_tag_policy:
protected_rulesets:
codeowners_and_maintainers:
module_service_package_paths: []
language_runtime_build_system:
dependency_and_package_registries: []
secrets_and_environment_boundary_refs: []
workflow_check_and_artifact_refs: []
release_deployment_environment_refs: []
backup_retention_migration_exit_refs: []
source_of_truth_assignments: []
owner:
last_reconciled_at:
~~~

Generic labels such as `backend`, `frontend`, `mobile`, or `database` do not replace the project’s canonical repository/module names.

---

# 4. Repository Source Identity

| Subject | Exact identity |
|---|---|
| Repository | GitHub system + organization/owner + repository ID + owner/name |
| Branch | Repository + full ref name + head SHA at observation time |
| Commit | Repository + full commit SHA |
| File | Repository + path + commit SHA; optional blob SHA |
| Directory/tree | Repository + tree/path + commit/tree SHA |
| Tag | Repository + tag ref/object + target SHA; signed/verified status where required |
| Package/container | Registry/package/version/digest/provenance |
| Generated artifact | Workflow run/attempt + artifact name/ID + digest + retention |

Evidence and baseline references use a commit-SHA permalink or content digest. A mutable branch link may be retained for convenience but cannot stand alone.

---

# 5. Branch and Change Strategy

The project records:

- trunk/branch model and allowed exceptions;
- branch creation base SHA, naming convention, ownership, lifetime, update/rebase/merge policy;
- protected branches/tags and required reviews/checks/statuses;
- merge methods and history/trace preservation;
- force-push/deletion permissions;
- signed commit/tag/provenance requirements;
- emergency/hotfix path and retrospective controls;
- generated-code, dependency, migration, configuration, and infrastructure change rules.

Branch existence does not authorize the change. Merge eligibility and Product OS change approval remain separate.

---

# 6. Issue and Project Mapping

Minimum issue mapping:

~~~yaml
issue_mapping_id:
repository_id:
issue_number:
issue_node_id:
issue_url:
issue_type:
product_os_subject_refs: []
spec_kit_task_refs: []
scope_and_release_refs: []
labels_milestone_project_fields:
owner_assignee:
delivery_state:
product_os_state:
created_closed_reopened_transferred_at:
closure_reason:
verification_and_acceptance_refs: []
~~~

Rules:

- Delivery state and Product OS artifact/verification state are stored separately.
- Labels/project fields are controlled projections, not new canonical vocabularies.
- Closing keywords may close an issue when a PR merges, but do not accept the underlying requirement/defect.
- Duplicate, split, transferred, converted, reopened, deleted, and security-restricted issues preserve lineage and visibility rules.
- Sensitive vulnerabilities use approved private security workflows, not public issue leakage.

---

# 7. Pull Request and Review Mapping

Each PR mapping records:

- repository, PR number/node ID, head/base refs and SHAs;
- linked issues/tasks/requirements/designs/architecture decisions/changes;
- exact changed paths and generated/migration/config/infrastructure effects;
- author, reviewers, code owners, review states, dismissed/stale reviews, and segregation;
- required checks and results at the merge candidate SHA;
- unresolved conversations, exceptions, risk/approval refs, and evidence;
- merge method, merge commit/resulting base SHA, actor, and time;
- post-merge build/deploy/verification linkage.

Review rules:

1. A review attaches to an exact diff/revision; material new commits may stale the review.
2. Approval count does not prove reviewer competence or requirement/design coverage.
3. Self-review/administrative bypass is governed and visible.
4. Bot/AI review is advisory unless approved policy assigns a bounded automated check role; it is not human approval.
5. PR templates/checklists support completeness but checked boxes are claims until supported.

---

# 8. CI, Check, Test, Build, and Artifact Mapping

Minimum run identity:

~~~yaml
ci_evidence_mapping_id:
repository_and_workflow_id:
workflow_file_path_and_commit:
run_id_and_attempt:
trigger_event_and_actor:
head_and_base_sha:
runner_environment_and_image:
inputs_configuration_and_secret_refs:
job_step_check_ids:
test_suite_and_case_refs: []
result_and_conclusion:
started_completed_at:
logs_reports_artifacts: []
artifact_digests_and_retention: []
candidate_environment_data_identity:
claim_and_evidence_refs: []
limitations_flakes_retries_waivers: []
~~~

Rules:

- Check success is scoped to the exact workflow/check definition, revision, inputs, runner, candidate, data, environment, and time.
- Rerun/attempt history is preserved; passing after retry does not erase flakiness or prior failure.
- Logs and artifacts may expire; durable evidence is captured according to retention needs.
- Untrusted code, pull-request contexts, third-party actions, caches, and artifacts receive security controls.
- Build provenance links source SHA, dependencies, workflow, builder, artifact digest, signatures/attestations where required.

---

# 9. Candidate and Verification Mapping

`IMP-029` registers the verification candidate before VRL work:

- repository and source SHA;
- build/package/container identifiers and digests;
- schema/migration/config/feature-flag state;
- target environment and data/identity scope;
- design version and requirement baseline;
- known deviations, open risks, exceptions, and evidence limitations.

Every VRL result binds to that exact candidate. A new material commit/build/config/data/environment change creates a new candidate version and invalidates or narrows prior evidence according to Change Impact Rules.

---

# 10. Release, Deployment, and Environment Mapping

| Event/object | Mapping requirement |
|---|---|
| Tag | Exact tag object/ref, target SHA, protection/signature, creator/time |
| GitHub Release | Release ID/tag/target, assets/digests, notes, draft/prerelease state, actor/time |
| G7 decision | Separate `VRL-035` decision with exact authorized scope/candidate/conditions |
| Deployment request | Source SHA/artifact digest, target environment, actor/authority, provider linkage |
| Environment approval | Exact environment, reviewers, rules, wait/protection result |
| Deployment result | Deployment/provider IDs, revision/artifact, start/end/result, deviations |
| Post-release validation | Live target identity, smoke/business/monitoring evidence, observation window, owner |
| Rollback/roll-forward | Trigger, authority, exact target revision, execution/evidence and resulting state |

Creating a GitHub Release is not G7. A deployment “success” is not `VRL-037` post-release validation.

---

# 11. Environments, Secrets, and Permissions

- Register organization/repository/team/app/bot/service-account roles and least-privilege scopes.
- Protect branch, tag, environment, secret, package, workflow, ruleset, and administrative changes.
- Never store credential values in artifacts, mappings, issues, PRs, logs, releases, or evidence exports.
- Secret identity/version/rotation may be referenced from controlled records without revealing value.
- Fork pull requests and untrusted contexts do not receive privileged secrets.
- Deployment environments use exact canonical names/IDs and provider linkage; “prod” text alone is insufficient.
- Administrative bypass, token/app change, ruleset change, and audit-log gap enter change/incident review.

---

# 12. Repository Documentation and Spec Kit Carrier Boundary

GitHub may physically host Product OS and Spec Kit Markdown. Hosting does not decide the semantic role.

- An approved Product OS artifact stored in a repository remains `CANONICAL_SEMANTIC` because its governance says so.
- A generated Spec Kit feature file in the same repository remains `WORKING_PROJECTION` unless promoted.
- A README rendering is a `DERIVED_VIEW` of the file content.
- A branch copy is a working revision, not current baseline.
- A permanent commit link identifies exact content but does not prove approval.

---

# 13. Operational and Security Evidence

GitHub objects may support:

- dependency, secret, code-scanning, provenance, audit, access, workflow, incident, and change evidence;
- uptime/availability only for GitHub-hosted aspects, not the product’s full live service;
- operational change and defect routing.

External deployment/cloud/observability systems remain native sources for their own state and will be linked through the same mapping contract or later mappings.

---

# 14. GitHub Change Triggers

Assess impact after repository transfer/rename/archive/delete/visibility change; default/protected branch or ruleset change; force push/history rewrite; path/module ownership change; app/token/team permission change; workflow/action/runner/cache/artifact/retention change; tag/release mutation; environment/protection/deployment change; issue/PR field synchronization change; or vendor behavior affecting identity/evidence.

---

# 15. Final GitHub Principle

> **GitHub can prove which engineering object changed, who reviewed it, what ran, and which delivery record exists—only Product OS authority and evidence rules determine what that means for acceptance, baselines, gates, and release.**

