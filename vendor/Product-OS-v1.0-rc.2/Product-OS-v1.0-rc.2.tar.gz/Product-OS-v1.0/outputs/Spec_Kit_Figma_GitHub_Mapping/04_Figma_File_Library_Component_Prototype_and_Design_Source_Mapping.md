# Product OS v1.0 — Figma File, Library, Component, Prototype, and Design Source Mapping

~~~yaml
document_id: FRAMEWORK-FIGMA-DESIGN-SOURCE-MAPPING
version: 0.1.0
status: WORKING_DRAFT
completion_state: FIGMA_DESIGN_SOURCE_MAPPING_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
primary_artifact_register: DES-020
primary_handoff_artifact: DES-023
primary_engineering_mapping: ENG-009
primary_implementation_record: IMP-005
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification maps governed experience and design subjects to exact Figma design sources and downstream code/evidence without making canvas existence, publication, comments, branch merges, or handoff links equivalent to approval, adoption, or verification.

Official reference basis:

- `https://developers.figma.com/docs/rest-api/file-endpoints/`
- `https://developers.figma.com/docs/rest-api/files/`
- `https://help.figma.com/hc/en-us/articles/360041051154-Guide-to-libraries-in-Figma`
- `https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching`
- `https://help.figma.com/hc/en-us/articles/360038006754-View-a-file-s-version-history`

---

# 2. Figma Role Boundary

Figma may be the `CANONICAL_NATIVE` source for:

- visual foundations, variables, styles, tokens, grids, and responsive layout specifications;
- components, component sets, variants, states, properties, instances, and composition;
- frames/screens, detailed flows, annotations, interaction/prototype connections, assets, and design-system documentation;
- branch/version history and published library assets within vendor retention/capability limits.

Figma is normally a `WORKING_PROJECTION`, `DERIVED_VIEW`, or `EVIDENCE_REFERENCE` for:

- business processes, product capability maps, semantic journeys, requirements, policies, architecture diagrams, release scope, and operational views.

Figma does not own:

- business/product/requirement approval;
- the semantic completeness of journeys and system states;
- repository implementation or active code adoption;
- test/verification sufficiency;
- gate or release decisions.

---

# 3. Design Source Register — DES-020

Each design source entry contains:

~~~yaml
design_source_id:
logical_design_subject_ids: []
figma_system_id:
organization_workspace_team_project:
file_key:
file_role:
main_or_branch:
branch_key:
version_id_or_named_checkpoint:
page_id:
section_frame_node_ids: []
component_component_set_keys: []
variable_collection_variable_style_refs: []
prototype_start_and_flow_refs: []
library_publication_ref:
source_status:
approval_status:
adoption_status:
verification_status:
owner:
reviewer:
code_mapping_refs: []
evidence_refs: []
last_reconciled_at:
reopen_triggers: []
~~~

`source_status`, `approval_status`, `adoption_status`, and `verification_status` are independent.

---

# 4. File and Page Roles

| File role | Owns | Required controls |
|---|---|---|
| `FOUNDATIONS_LIBRARY` | Variables, primitives, semantic tokens, styles | Publication authority, naming/aliasing, mode coverage, change impact |
| `COMPONENT_LIBRARY` | Components, sets, variants, properties, documentation | Stable design IDs, publication/version, deprecation and replacement |
| `PRODUCT_DESIGN_SOURCE` | Approved screen/flow realization for a product/domain | Requirement/journey refs, state/responsive/localization coverage, version baseline |
| `EXPLORATION` | Alternatives, concepts, experiments | Clearly non-canonical; promotion required |
| `RESEARCH_PROTOTYPE` | Usability/research stimulus | Study/version/participant/evidence boundary |
| `HANDOFF_SNAPSHOT` | Versioned delivery package | Exact upstream version, code target, acceptance state |
| `ARCHIVE` | Historical preserved design | Read-only/retention, supersession, integrity |
| `EXTERNAL_VENDOR_SOURCE` | Third-party design source | License, access, version, adoption, trust and replacement controls |

Page/section conventions support navigation but stable node/design IDs remain authoritative. Pages must not serve as lifecycle statuses solely through names such as “Approved” or “Ready”.

---

# 5. Logical Design ID Embedding

Where the tool supports descriptions, component documentation, annotations, plugin/shared data, or Dev Mode links, embed or associate stable Product OS IDs:

- `EXP-*` for semantic experience inputs;
- `REQ-*` for governing requirements and acceptance;
- `DES-*` or nested `DES-CMP-*`, `DES-SCR-*`, `DES-TKN-*`, `DES-PAT-*` for design subjects;
- `ENG-*`/`IMP-*` mapping IDs for handoff/adoption;
- change and decision refs where the design differs from baseline.

The mapping register remains canonical if tool metadata cannot preserve all links or is unavailable to every consumer.

---

# 6. Publication, Enablement, Update, and Adoption

These events remain separate:

~~~text
Designed
→ reviewed
→ approved for design scope
→ published to library
→ library enabled in consuming file
→ update available
→ update reviewed/accepted in consuming file
→ instance used in product design
→ mapped to code component/token
→ implemented at exact revision
→ verified in product candidate
→ live adoption observed
~~~

Rules:

- Only main-file publication counts as library publication where Figma requires it.
- Publishing an update does not prove consumers accepted it.
- Instance existence does not prove code implementation.
- Code component existence does not prove active product adoption.
- Deprecation records replacement, migration scope, remaining instances, code impact, and sunset evidence.

---

# 7. Branch and Version Contract

- Main file, branch, and archived/merged branch identities are explicit.
- Branch creation records source main-file version.
- Review records exact branch state; later edits reopen affected review.
- Update-from-main and merge events record conflicts, resolutions, and resulting checkpoint.
- Comments are review inputs; because comments may not propagate with branch merge, material decisions are promoted to governed decision/issue records.
- A G4B design baseline references an exact named/versioned checkpoint plus subject membership, not simply “main current”.
- Library publication version and design baseline version may differ; both are recorded.
- Restoring an older version triggers change impact and does not erase later historical evidence.

---

# 8. Required Design Coverage

For each in-scope journey/screen/component, mapping covers as applicable:

- purpose, user/role, entry/exit, requirement and journey IDs;
- information hierarchy, content, data, permissions, and privacy state;
- default, loading, empty, partial, error, success, disabled, read-only, permission-denied, offline/degraded, timeout, conflict, destructive confirmation, and recovery states;
- focus order, keyboard, assistive technology, contrast, text resizing/reflow, touch targets, motion/reduced motion, errors/instructions, and generated-output accessibility;
- viewport/breakpoint, platform, device/orientation, theme/mode, language, RTL/LTR, plural/format, timezone, currency/money, and localization expansion;
- component variants/properties, token/style/variable bindings, instance overrides, content rules, prototype behavior, assets, and export rules;
- analytics/telemetry and operational feedback needs where visible experience depends on them.

`NOT_APPLICABLE` is recorded for states or dimensions genuinely absent from exact scope.

---

# 9. Design-to-Code Handoff — DES-023

Minimum handoff entry:

~~~yaml
handoff_id:
design_subject_id:
requirement_and_experience_refs: []
figma_file_key:
figma_branch_and_version:
figma_node_ids: []
library_component_variable_style_refs: []
design_status_and_approval_ref:
code_repository:
code_target_paths_or_symbols: []
expected_component_token_asset_mapping: []
state_responsive_accessibility_localization_matrix_ref:
interaction_and_content_rules_ref:
asset_export_refs_and_digests: []
known_gaps_exceptions_decisions: []
implementation_owner:
verification_criteria_and_evidence_plan: []
change_and_reopen_triggers: []
~~~

Handoff is complete only when engineering can identify the exact design revision, affected code targets, applicable states/dimensions, open decisions, and verification obligations.

---

# 10. ENG-009 and IMP-005 Adoption Mapping

Adoption states:

`UNMAPPED`, `PLANNED`, `IMPLEMENTING`, `IMPLEMENTED_UNVERIFIED`, `VERIFIED`, `PARTIALLY_ADOPTED`, `DEVIATED`, `SUPERSEDED`, `RETIRED`.

Each code mapping records:

- exact design subject and Figma version/node;
- repository/path/symbol/package and exact commit/release;
- mapping kind: token, component, pattern, screen, flow, asset, content, interaction;
- supported variants/states/platforms/themes/languages;
- deliberate differences with decision/requirement refs;
- active usage evidence, not only component definition;
- verification result and candidate/environment;
- drift status and last reconciliation.

---

# 11. Review and Evidence

Permitted Figma-derived evidence includes versioned node metadata, exports with source parameters/digests, prototype recording tied to version, branch review/merge history, library publication records, component usage analytics where available, and screenshots tied to exact candidate/context.

Limitations:

- a screenshot cannot prove hidden interaction, semantics, focus order, responsive behavior, or code identity by itself;
- a prototype cannot prove production implementation;
- a comment resolution cannot replace a decision or acceptance record;
- an exported asset without file/node/version/export metadata is weak provenance;
- inaccessible or expired version history requires governed archival evidence.

---

# 12. Access, Privacy, and External Content

- Register link-access class, workspace/project permissions, editors/publishers/reviewers, service accounts, and external guests.
- Store no secret or production-sensitive value in design content or annotations.
- Use synthetic/minimized data unless approved real data is necessary and governed.
- External libraries, plugins, fonts, assets, and kits record source, license, version, security/privacy review, modification, attribution, and replacement plan.
- API/plugin automation follows approved scopes and logs object/revision-level effects.

---

# 13. Figma Change Triggers

Reconcile and assess impact after:

- file/library move, rename, duplicate, transfer, archive, deletion, restoration, or access change;
- node replacement/deletion or Product OS ID reassignment;
- component/variant/property/variable/style/token change;
- library publish/unpublish, asset move, swap, deprecation, or update acceptance;
- branch create/update/review/merge/archive/restore;
- design approval/baseline, requirement change, code mapping/adoption, candidate verification, or operational feedback;
- vendor plan/API/retention behavior affecting identity or evidence.

---

# 14. Final Figma Principle

> **Figma may be the native source of visual design, but trustworthy delivery requires exact Product OS subject, file/node/version, publication and adoption state, code target, decision, and verification to remain connected.**

