# Product OS v1.0 — Identity, Locators, Versions, and Representation Registry

~~~yaml
document_id: FRAMEWORK-CROSS-TOOL-IDENTITY-LOCATOR-VERSION-REGISTRY
version: 0.1.0
status: WORKING_DRAFT
completion_state: CROSS_TOOL_IDENTITY_REGISTRY_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
mapping_status_count: 8
synchronization_mode_count: 6
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification makes a Product OS subject resolvable across human-readable names, mutable navigation links, tool-native IDs, branches, versions, commits, exports, replacements, and migrations.

---

# 2. Identity Layers

| Layer | Purpose | Example |
|---|---|---|
| Logical identity | Stable Product OS meaning | `REQ-FUNC-042`, `DES-CMP-BUTTON-001`, `G7-DEC-003` |
| Tool-system identity | Exact tenant/installation boundary | GitHub organization, Figma organization/workspace, Spec Kit profile/version |
| Container identity | Exact file/repository/feature folder | Figma file key, GitHub repository node ID/name, Spec Kit feature ID/path |
| Native object identity | Tool-specific object | Figma node ID, GitHub PR number scoped to repository, file path |
| Revision identity | Exact state observed or approved | Figma version/branch revision, Git commit SHA, content digest |
| Locator | Human/machine route to the object | URL or repository-relative path |
| Representation identity | Governed cross-tool link | Product OS mapping ID and version |

Names and locators may change; logical, native, and revision identities preserve continuity.

---

# 3. Canonical Identity Grammar

~~~text
mapping_id      = MAP-{PROJECT}-{SUBJECT_ID}-{TOOL}-{SEQUENCE}
system_id       = TOOL-{SPEC_KIT|FIGMA|GITHUB}-{TENANT_OR_INSTALLATION}
representation = {logical_subject}@{subject_version}
                 → {system_id}/{container_type}:{container_id}
                   /{object_type}:{native_id}@{revision}
~~~

IDs use project-approved slug/identifier rules from the later Schemas & Repository Standard. This grammar fixes semantics, not physical character constraints.

---

# 4. Spec Kit Identity

Minimum identity:

~~~yaml
spec_kit_system_id:
distribution: GITHUB_SPEC_KIT
tool_version_or_commit:
project_root_identity:
feature_id:
feature_slug:
feature_directory:
command_or_skill:
artifact_kind:
relative_path:
content_revision_or_digest:
source_product_os_refs: []
status:
~~~

Rules:

- Feature ID is stable and separate from feature title or branch name.
- The `.specify` constitution projection records its Product OS GOV-001 source version.
- Each `spec.md`, `plan.md`, `tasks.md`, checklist, research, model, or contract has its own kind, path, digest/revision, and upstream scope.
- Generated output records the command/skill, tool version, input refs, actor/run, and generation time.
- Regeneration does not silently erase manually promoted decisions or unresolved differences.

---

# 5. Figma Identity

Minimum identity:

~~~yaml
figma_system_id:
organization_or_workspace_id:
team_or_project_id:
file_key:
file_name:
file_role:
branch_key:
branch_name:
version_id:
page_id:
section_or_frame_id:
node_id:
node_type:
component_key_or_style_key:
library_publication_state:
mutable_url:
versioned_url_or_version_ref:
last_reconciled_at:
~~~

Rules:

- File key and node ID form the minimum node locator; node ID is unique within its document context.
- Branch key is distinct from the main file key; branch/main status is explicit.
- A design baseline or evidence reference records a version ID or named version/checkpoint where available, not only the current mutable file URL.
- Component key/style key/variable identity is recorded when downstream instances depend on a published library asset.
- Human names support navigation but do not replace IDs.
- A node replacement records `replaces`/`replaced_by`; reusing a retired Product OS ID for a semantically different node is prohibited.
- Exports record source file, node, version, export parameters, digest, and generated-at time.

---

# 6. GitHub Identity

Minimum identity:

~~~yaml
github_system_id:
enterprise_or_organization:
repository_id:
repository_owner_and_name:
repository_visibility:
default_branch:
object_type:
object_native_id_or_number:
path:
ref_name:
commit_sha:
tag:
workflow_and_run_id:
check_suite_or_check_run_id:
artifact_name_and_digest:
environment:
deployment_id:
mutable_url:
permanent_url:
last_reconciled_at:
~~~

Rules:

- Repository numeric/node identity and owner/name are both registered; transfers/renames retain lineage.
- Issue and PR numbers are repository-scoped, never globally unique.
- Evidence and baselines reference commit SHA or content digest; a default-branch URL is navigation only.
- A file identity combines repository, path, and commit SHA. Rename lineage is explicit.
- A tag/release maps to its target commit/object; moving a mutable tag creates a conflict/incident where immutability is required.
- Workflow/check identity includes workflow file revision, run/attempt, triggering event, actor, head SHA, environment, and result.
- Artifact/package identity includes digest and retention/expiry metadata.
- Deployment identity includes exact repository revision, target environment, deployment/provider record, and post-deployment verification reference.

---

# 7. Representation Registry Record

The project registry contains one row per logical-subject/tool-object relationship.

| Field group | Required contents |
|---|---|
| Registry identity | mapping ID/version/status, project, scope, owner |
| Logical subject | type, stable ID, version, canonical semantic owner |
| Tool system | tool code, tenant/install, container, access classification |
| Native object | type, native ID, name, locator, immutable/versioned locator, revision |
| Semantics | representation role, mapped field set, exclusions, applicability |
| Synchronization | mode, direction, trigger, automation identity, conflict policy |
| Governance | authority, reviewer, approval status, source/evidence refs |
| Lifecycle | created, reconciled, freshness, supersession, retention, reopen triggers |
| Health | resolvability, access, drift, conflicts, missing links, incident refs |

Composite tool objects list every subject ID or point to a separately addressable membership index.

---

# 8. Locator Classes

| Class | Meaning | Permitted use |
|---|---|---|
| `MUTABLE_NAVIGATION` | Opens current object or branch state | Human navigation and operational views |
| `VERSIONED_NAVIGATION` | Opens named/versioned state | Review/baseline navigation when stable for retention period |
| `IMMUTABLE_CONTENT` | Resolves exact content by SHA/digest/version | Evidence, baseline, release lineage |
| `API_IDENTITY` | Native API object identity | Automation and reconciliation |
| `ARCHIVED_EXPORT` | Integrity-protected retained snapshot | Tool exit, legal/audit, expired native retention |

An evidence pack records at least `IMMUTABLE_CONTENT` or an `ARCHIVED_EXPORT` plus integrity metadata when the native system cannot retain an immutable locator.

---

# 9. Rename, Move, Copy, Fork, Replace, Delete

| Event | Identity disposition |
|---|---|
| Rename | Same identity; update human name/locator and preserve history |
| Move within container | Same logical/native identity where the tool preserves it; record old/new locator |
| Repository/file transfer | Preserve native lineage; revalidate tenant, access, automation, and retention |
| Copy/duplicate | New native identity; mapping is `PROPOSED` until intent is classified |
| Fork/branch | New version/work lineage; canonical-main relationship explicit |
| Semantic replacement | New native/logical identity as appropriate; record replaces/replaced-by |
| Soft archive | Preserve identity; set lifecycle state and access/retention rules |
| Delete | Mark broken/retired, preserve tombstone and evidence; recover or migrate as required |

---

# 10. Reconciliation and Freshness

Each mapping defines one freshness rule:

- event-driven after a mapped change;
- before a gate/baseline/release decision;
- per delivery iteration;
- fixed review interval;
- on access, vendor, repository, file, branch, library, workflow, or environment change.

Reconciliation verifies:

1. tool system and container still exist;
2. locator resolves with authorized access;
3. native ID and revision match;
4. logical subject and canonical owner still exist;
5. mapped field values are consistent or differences classified;
6. synchronization configuration and automation identity remain approved;
7. evidence has not expired or lost integrity;
8. supersession, retention, and reopen rules are current.

---

# 11. Integrity and Recovery

- Store digests for exported specifications, design assets, build artifacts, packages, and evidence bundles where material.
- Never treat screenshots as sole identity when native object/version data exists.
- If the native version cannot be preserved for the required retention period, capture an approved export plus metadata and integrity proof.
- Recovery restores the relationship, not merely a similarly named object.
- Reconstructed mappings declare reconstruction source, uncertainty, reviewer, and missing history.
- Access denial is not proof of deletion; classify `UNRESOLVED_ACCESS` within health details and route to the owner.

---

# 12. Final Identity Principle

> **A trustworthy link names the subject, system, container, native object, exact revision, and relationship—not merely the screen a user happened to open.**

