# Product OS v1.0 — Spec Kit Product OS Profile and Feature Workflow Mapping

~~~yaml
document_id: FRAMEWORK-SPEC-KIT-PRODUCT-OS-PROFILE-MAPPING
version: 0.1.0
status: WORKING_DRAFT
completion_state: SPEC_KIT_PRODUCT_OS_MAPPING_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
adapter: GITHUB_SPEC_KIT
adapter_role: FEATURE_LEVEL_WORKING_PROJECTION_AND_EXECUTION_ORCHESTRATION
upstream_authority: PRODUCT_OS
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines the Product OS profile for GitHub Spec Kit. It preserves Spec Kit’s useful spec-driven feature workflow while preventing generated files, commands, AI actions, issues, or repository state from replacing Product OS artifacts, gates, approvals, and evidence.

Official reference basis:

- `https://github.com/github/spec-kit`
- `https://github.github.com/spec-kit/`

Vendor commands, templates, and file layouts are external versioned inputs. The project registers the exact Spec Kit release or commit in use.

---

# 2. Adapter Position

~~~text
Product OS approved scope and controls
  → bounded feature packet projection
      → Spec Kit specification
      → clarification
      → technical plan
      → tasks and optional checklists
      → cross-artifact analysis
      → optional GitHub issue projection
      → governed implementation execution
  → implementation, verification, release, and operational evidence
  → Product OS promotion, gates, and baselines
~~~

Spec Kit is an adapter at feature/slice level. Product OS is the governing lifecycle and cross-project semantic layer.

---

# 3. Product OS to Spec Kit Object Map

| Spec Kit object or operation | Product OS input | Representation role | Product OS output/decision |
|---|---|---|---|
| Constitution | GOV-001 plus applicable GOV-009/AI/engineering rules | `WORKING_PROJECTION` with protected source refs | Reviewed constitution projection and drift record |
| Specify | PROD scope/features, REQ obligations, decisions, risks | `WORKING_PROJECTION` | Feature specification proposal |
| Clarify | REQ open questions, assumptions, conflicts, acceptance gaps | `DELIVERY_OBJECT` and proposed content | Promoted answers in canonical owners; unresolved questions preserved |
| Plan | ARC/ENG constraints, interfaces, data, security, quality, repository identities | `WORKING_PROJECTION` | Technical plan proposal and impact candidates |
| Research | Registered sources/questions | `WORKING_PROJECTION` | Source/claim/evidence entries for review |
| Data model/contracts | REQ/ARC canonical models and interface contracts | `WORKING_PROJECTION` or bounded native engineering draft | Promotion/change proposal into owning artifacts |
| Tasks | ENG readiness, DoR/DoD, plan, acceptance, ownership | `DELIVERY_OBJECT` | Executable work breakdown with trace refs |
| Checklist | Artifact/gate/verification criteria | `DELIVERY_OBJECT` | Review observations; not verification by existence |
| Analyze | Spec/plan/tasks consistency | `DERIVED_VIEW` | Gaps/conflicts routed to canonical owners |
| Task-to-issues | Approved task projection | `DELIVERY_OBJECT` | GitHub issue mappings; no status authority transfer |
| Implement | Authorized tasks, exact repository/design/requirement refs | AI-governed `DELIVERY_OBJECT` | Code/change/evidence records and handoff to IMP/VRL |

---

# 4. Constitution Projection Contract

The Spec Kit constitution is a bounded operational projection, not a second Product Constitution.

Minimum header:

~~~yaml
projection_id:
projection_role: SPEC_KIT_CONSTITUTION_PROJECTION
source_gov_001_id:
source_gov_001_version:
source_gov_009_scope_and_version:
source_ai_operating_spec_version:
project_and_repository_scope:
spec_kit_version_or_commit:
generated_or_reconciled_at:
reviewed_by:
mapping_id:
drift_status:
~~~

Rules:

1. GOV-001 is canonical; the projection cannot silently write upstream.
2. Only rules applicable to the exact project/repository/feature workflow are projected.
3. Local additions identify their Product OS owner or remain proposed.
4. Conflict with GOV-001/GOV-009 blocks automatic regeneration or implementation until resolved.
5. Source version change marks the projection `STALE` until reconciled.
6. Template tokens from vendor files are not project decisions.
7. Human or AI edits are attributed and diff-reviewed.

---

# 5. Feature Packet Identity

Each Spec Kit feature packet represents one bounded Product OS feature, change, release slice, defect remediation, technical enabler, or operational evolution item.

~~~yaml
feature_packet_id:
product_os_subject_refs: []
feature_kind:
project_scope:
domain_scope:
release_scope:
profile: P1|P2|P3
risk_and_domain_overrides: []
canonical_product_baseline_ref:
canonical_requirement_baseline_ref:
canonical_experience_design_refs: []
canonical_architecture_readiness_refs: []
spec_kit_version:
repository_and_base_revision:
packet_files: []
status:
owner:
authority_ref:
created_at:
last_reconciled_at:
change_refs: []
~~~

Packet kinds:

- `PRODUCT_FEATURE`
- `DEFECT_REMEDIATION`
- `TECHNICAL_ENABLER`
- `SECURITY_PRIVACY_COMPLIANCE_CHANGE`
- `DESIGN_SYSTEM_CHANGE`
- `DATA_MIGRATION`
- `RELIABILITY_OPERATIONAL_CHANGE`
- `EXPERIMENT_OR_SPIKE`

An experiment/spike cannot silently become committed implementation scope.

---

# 6. Specification Promotion Rules

The Spec Kit specification may contain:

- copied canonical facts with exact source/version references;
- summarized canonical requirements with IDs;
- feature-local proposed user stories and acceptance statements;
- explicit assumptions, questions, exclusions, risks, and dependencies;
- design, architecture, repository, and evidence locators.

It must not:

- invent scope outside an approved product/change route;
- hide unresolved contradictions in fluent prose;
- renumber or replace canonical requirement IDs;
- turn implementation preference into user/business requirement;
- declare requirement/gate approval from file completion;
- copy restricted source material beyond approved need.

Promotion flow:

~~~text
Spec Kit proposed statement
→ classify as fact / assumption / question / decision / requirement / design / task
→ locate canonical owner
→ review against sources and impact
→ accept, modify, reject, or defer
→ update canonical owner and trace graph
→ regenerate or reconcile projection
~~~

---

# 7. Command and Skill Control Matrix

| Operation | Preconditions | Permitted result | Product OS control |
|---|---|---|---|
| Constitution | GOV-001/GOV-009 versions known; scope resolved | Generate/reconcile bounded projection | Human review for material rule changes |
| Specify | Feature/change authorized for definition; PBL/RBL refs available or gaps declared | Create feature spec proposal | No baseline state update |
| Clarify | Questions classified and owners known | Record proposed resolutions | Promote decisions/requirements only through owners |
| Plan | Architecture/readiness inputs identified; repository target exact | Create technical plan | ARC/ENG changes require impact and approval |
| Tasks | Plan and acceptance criteria sufficiently stable | Create addressable tasks with dependencies/paths | G5B/DoR still governs implementation entry |
| Checklist | Criteria source identified | Create review checklist | Checked box is not evidence by itself |
| Analyze | Packet artifacts exist at exact revisions | Produce consistency/gap report | Findings enter registers; no automatic approval |
| Task-to-issues | Issue target repository/labels/permissions approved | Create mapped GitHub issues | Preserve task IDs and mapping records |
| Implement | G5B/authorized change route, exact task scope, authority, target, and preflight | Execute bounded changes and record results | AI Operating Spec, IMP records, verification handoff |

If the installed Spec Kit version exposes different command names or capabilities, map by operation semantics and record the exact version-specific adapter behavior.

---

# 8. Spec, Plan, and Task Completeness

## 8.1 Specification minimum

- feature identity and purpose;
- upstream artifact/baseline refs;
- actors, journeys, scenarios, and states in scope;
- functional, quality, data, integration, security, privacy, accessibility, audit, localization, and operational obligations applicable to the slice;
- acceptance and verification references;
- exclusions, assumptions, questions, risks, standards, dependencies, release intent, and design needs;
- no unresolved template tokens or ambiguous unowned statements.

## 8.2 Plan minimum

- repository/module/path targets and base revision;
- design source and version where relevant;
- architecture decisions and constraints;
- interfaces, data/schema/migration, identity/access, security/privacy, accessibility/localization, reliability/performance, observability/configuration, deployment/rollback implications;
- test and evidence strategy;
- risk, change-impact, sequencing, ownership, and recovery.

## 8.3 Task minimum

- stable task ID and feature packet ID;
- exact requirement/design/architecture references;
- executable outcome, permitted scope, likely paths, dependencies, parallel-safety, owner/agent boundary;
- acceptance/verification criteria and required evidence;
- prohibited effects, risk/approval triggers, completion and handoff state.

---

# 9. GitHub Issue Projection

When tasks become issues:

- one issue may represent one task or an explicitly indexed group;
- title carries readable intent; body carries stable task and upstream IDs;
- repository, issue number, URL, labels, milestone/project, assignee, state, and timestamps enter the mapping registry;
- issue fields may drive delivery views but cannot update approval, verification, gate, or release fields without a separate governed event;
- reopened, transferred, duplicated, split, or closed issues preserve lineage;
- issue deletion or target-repository migration triggers reconciliation.

---

# 10. Implementation Boundary

Before implementation:

1. confirm feature packet, base revision, target repository, branch/worktree, environment, and design version;
2. confirm G5B or authorized alternative change/emergency route;
3. confirm unresolved questions do not make work unsafe or divergent;
4. classify actions under the AI Operating Specification;
5. verify credentials/permissions are least-privilege and within authority;
6. protect unrelated user work and concurrent changes.

After implementation:

- record exact changed paths, commits, migrations, configuration, tests, failures, deviations, source/design drift, and evidence;
- update IMP artifacts and traceability;
- create verification candidate only for exact revision/package/environment;
- never mark VRL acceptance, G6B, G7, deployment success, or live health from command completion.

---

# 11. Profile Mapping

| Profile | Spec Kit treatment |
|---|---|
| P1 | Compact packet may combine spec/plan/tasks physically; headings and stable object IDs preserve separability; analysis/checklist used when risk or uncertainty triggers them |
| P2 | Separate spec, plan, tasks, supporting research/model/contracts/checklists; deterministic cross-reference and issue mapping; analyze before implementation and material changes |
| P3 | Protected templates and constitution projection, independent plan/security/data/design reviews, signed or integrity-protected packet baseline, segregation, controlled generators, comprehensive analysis/checklists, immutable evidence |

Domain overrides apply to the affected packet sections and tasks.

---

# 12. Drift, Regeneration, and Upgrade

- Compare upstream Product OS versions, Spec Kit tool/template version, packet digest, repository base, and mapped issues before regeneration.
- Preserve user-authored and promoted decisions; do not overwrite by template regeneration.
- Route incompatible changes through three-way reconciliation: old projection, new canonical input, current edited projection.
- A Spec Kit upgrade is a governed tool/configuration change with template diff, command behavior review, data/access review, migration test, and rollback.
- Vendor workflow changes cannot redefine Product OS profiles, gates, approvals, evidence, or artifact count.

---

# 13. Spec Kit Validation Outcomes

`PASS` means the feature packet is internally valid for its declared operation and profile. `PASS_WITH_CONDITIONS` identifies owned conditions. `FAIL` blocks the affected operation. `NOT_APPLICABLE` applies to an optional operation only with reason.

No Spec Kit validation outcome is itself a Product OS gate outcome.

---

# 14. Final Spec Kit Principle

> **Spec Kit turns approved Product OS intent into a disciplined feature execution packet; it may propose upstream changes, but it cannot approve its own scope, implementation, verification, or release.**

