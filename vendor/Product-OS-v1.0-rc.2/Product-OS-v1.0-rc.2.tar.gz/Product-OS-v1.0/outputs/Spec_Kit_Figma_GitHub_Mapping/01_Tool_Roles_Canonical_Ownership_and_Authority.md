# Product OS v1.0 — Tool Roles, Canonical Ownership, and Authority

~~~yaml
document_id: FRAMEWORK-CROSS-TOOL-ROLES-OWNERSHIP-AUTHORITY
version: 0.1.0
status: WORKING_DRAFT
completion_state: TOOL_ROLE_OWNERSHIP_AUTHORITY_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
named_tools: [SPEC_KIT, FIGMA, GITHUB]
representation_role_count: 8
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification allocates responsibility among Product OS, Spec Kit, Figma, and GitHub without confusing physical storage, native object ownership, semantic truth, work state, evidence, and authority.

---

# 2. Responsibility Matrix

| Responsibility | Product OS | Spec Kit | Figma | GitHub |
|---|---|---|---|---|
| Lifecycle, artifact, baseline, and gate semantics | Canonical | Projection only | Reference only | Reference/evidence only |
| Governance, decisions, risks, applicability, change | Canonical | Bounded projection | Annotation/reference | Work/evidence representation |
| Product and requirement meaning | Canonical | Feature-level working projection | Design annotations only | Issue/PR/file references |
| Feature specification workflow | Governs promotion and scope | Native working workflow | Input/realization reference | Hosts files and issue projection where selected |
| Experience semantics | Canonical in EXP | Input projection | Visual/interactive realization | Implementation reference |
| Visual design source | Registers/approves scope | References | Canonical native where selected | Export/code reference |
| Component/library publication and adoption | Governs policy/evidence | References | Native publication source | Code adoption evidence |
| Architecture meaning | Canonical in ARC | Plan projection | Diagram projection where used | ADR/code/config source references |
| Code, schema, migration, test, workflow source | Governs requirements/acceptance | Plan/task projection | Handoff source | Canonical native |
| Work item and review mechanics | Governs state meaning | Task projection | Comments/review input | Native delivery objects |
| Build/check/run output | Registers claims/evidence | References | Not primary | Native evidence source |
| Verification and acceptance decision | Canonical governed record | Checklist may assist | Review/prototype evidence | Test/check/evidence objects assist |
| Release authorization | G7 decision authority | No | No | Release object may represent only |
| Deployment execution/live state | Governed record and evidence | No | No | Native record if GitHub controls it; external system may own actual state |
| Cross-tool mapping and conflict disposition | Canonical register | Participant | Participant | Participant |

---

# 3. Eight Representation Roles

## 3.1 `CANONICAL_SEMANTIC`

Owns the approved meaning and lifecycle state for exact scope. A project may physically store that artifact in Git, but the role belongs to the governed Product OS artifact, not to “GitHub” as a vendor status.

## 3.2 `CANONICAL_NATIVE`

Owns specialist structure that cannot be reduced safely to another representation, such as a Figma component set with variants and variables or a repository tree at an exact commit.

## 3.3 `GOVERNED_REGISTER`

Owns controlled inventory and relationships: artifact register, design-source index, repository register, mapping registry, applicability matrix, evidence index, or release target identity.

## 3.4 `WORKING_PROJECTION`

Editable expression used for analysis or execution. Its content may be promoted only through the canonical owner’s review path.

## 3.5 `DERIVED_VIEW`

Rebuildable rendering or dashboard. Loss is operationally inconvenient but must not erase canonical meaning or history.

## 3.6 `DELIVERY_OBJECT`

Issue, task, pull request, review request, checklist, package, release object, or deployment request used to move work. Its state is not automatically artifact/gate state.

## 3.7 `EVIDENCE_REFERENCE`

Exact pointer and metadata for an observed execution or result. Fitness, sufficiency, admissibility, and acceptance remain governed by the Source / Evidence Model.

## 3.8 `NOT_APPLICABLE`

Explicit non-use for exact scope. It contains reason, evidence, authority, date, and reopen trigger. It never means that the underlying lifecycle obligation disappeared.

---

# 4. Field-Level Ownership

A representation may combine fields with different owners. The mapping record identifies each authoritative field set.

Example:

| Feature field | Owner | Permitted downstream use |
|---|---|---|
| Feature ID, approved scope, priority, release inclusion | PROD/REQ canonical artifact | Project into Spec Kit and GitHub |
| User story wording drafted during clarification | Spec Kit working projection | Manual promotion to REQ |
| Frame/node/component IDs and visual properties | Figma native design source | Reference from DES/ENG/IMP |
| Repository path and implementation revision | GitHub native source | Register in ENG/IMP/VRL |
| Issue assignee and delivery state | GitHub delivery object | Derived operational view |
| Acceptance result | Authorized VRL record | May update GitHub label/check summary after decision |
| Gate result | Gate decision record | Publish read-only representation to tools |

---

# 5. Ownership Decision Rules

1. Business intent, policy, requirement, risk, approval, gate, and acceptance meaning remain with the named Product OS owner.
2. Visual geometry, component structure, variable binding, prototype connection, and native library publication live in Figma when Figma is the approved design source.
3. Repository contents, commit graph, code review record, workflow run, and repository-hosted artifact live in GitHub when GitHub is the approved host.
4. Spec Kit owns its workflow files as a coherent working feature packet, not the upstream organization-wide Product Constitution, full Master Artifact Catalog, or final gate authority.
5. If a native object embeds a Product OS ID, the ID creates linkage; it does not transfer semantic ownership.
6. If two tools can edit the same semantic field, designate one canonical writer or use a field-bounded `CONTROLLED_BIDIRECTIONAL` rule with conflict detection.
7. If no competent owner can be resolved, set the mapping `CONFLICTED` or `ACTIVE_WITH_GAPS`; do not select the newest edit automatically.

---

# 6. Tool-Specific Non-Authority Events

| Event | What it proves | What it does not prove |
|---|---|---|
| Spec Kit specification generated | A working feature specification exists | Scope approval or requirement baseline |
| Spec Kit analysis passes | Its configured cross-artifact consistency checks passed | Full Product OS validation, verification, or gate passage |
| Spec Kit implementation finishes | An execution workflow reported completion | Correctness, verification, release authorization, or live health |
| Figma node exists | A native design object exists at a locator | Approved design, complete states, engineering adoption, or verification |
| Figma library update published | Native design assets were published | Downstream files accepted them or code adopted them |
| Figma branch merged | Branch changes entered the main file | Product OS design baseline or requirement approval |
| GitHub issue closed | Issue workflow reached closed state | Requirement accepted, defect verified, or artifact complete |
| Pull request merged | Change entered its target branch | Correct deployment, acceptance, or release authorization |
| Check is green | Defined check passed for identified revision/environment | Coverage sufficiency or all release obligations |
| GitHub Release created | A release object/tag/assets were published | G7 authorization, deployment success, or post-release validation |
| Deployment reports success | Provider workflow reported deployment success | Correct target identity, user-visible health, or business acceptance |

---

# 7. Approval and Verification Separation

The mapping model preserves five separate questions:

1. **Authorship:** who created or changed the object?
2. **Review:** who examined it and against which criteria?
3. **Approval:** who accepted its governed meaning or scope?
4. **Verification:** who produced and accepted evidence that the exact candidate satisfies criteria?
5. **Authorization/execution:** who authorized and who performed release/deployment or another consequential action?

One tool event may contribute to several questions, but cannot collapse them.

---

# 8. Default Tool Assignment by Lifecycle Region

| Lifecycle region | Product OS | Spec Kit | Figma | GitHub |
|---|---|---|---|---|
| GOV–BUS | Semantic/control owner | Reference or compact projection | Optional diagram projection | Host/work/evidence reference |
| PROD–REQ | Semantic/baseline owner | Primary feature packet projection | Requirement annotations and design inputs | File/issue/work representation |
| EXP–DES | Semantic experience/design governance | Feature context | Primary native visual source | Handoff/code-target reference |
| ARC–ENG | Semantic architecture/readiness owner | Plan/task projection | Diagram/handoff reference | Primary native repository/readiness source |
| IMP | Governed implementation record | Execution task projection | Design source reference | Primary code/review/CI source |
| VRL | Verification/release decision owner | Checklist/reference | Visual/accessibility evidence source | Test/check/release/deployment evidence source |
| OPS | Operational/evolution decision owner | New feature/change projection | Design evolution input | Incident/change/code/release evidence source |

---

# 9. Authority Failure Rules

The action stops or narrows when:

- tool access exists but task authority is absent;
- an object belongs to another project, tenant, repository, file, environment, or release scope;
- a requested change would overwrite a canonical owner from a projection;
- the expected approver/verifier/releaser is unclear or conflicts with segregation requirements;
- the source revision changed after review;
- automation would update protected approval, risk, acceptance, baseline, or gate fields;
- a required review, check, evidence item, or condition is missing;
- a tool’s native status cannot express the required Product OS state without loss.

---

# 10. Final Ownership Principle

> **Assign each fact to the system best able to preserve its native form, and each decision to the authority competent to own its consequences; never confuse the two.**

