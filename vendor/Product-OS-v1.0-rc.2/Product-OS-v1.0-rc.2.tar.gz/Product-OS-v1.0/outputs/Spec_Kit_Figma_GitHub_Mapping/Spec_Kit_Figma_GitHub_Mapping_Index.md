# Product OS v1.0 — Spec Kit + Figma + GitHub Mapping Index

~~~yaml
document_id: FRAMEWORK-SPEC-KIT-FIGMA-GITHUB-MAPPING-INDEX
version: 0.1.0
status: WORKING_DRAFT
completion_state: CROSS_TOOL_MAPPING_LIBRARY_COMPLETE
asset_class: PRODUCT_OS_FRAMEWORK_ASSET
project_artifact_count_impact: NONE
logical_artifact_scope: 281
gate_scope_count: 13
named_tool_count: 3
representation_role_count: 8
mapping_status_count: 8
synchronization_mode_count: 6
workflow_count: 12
canonical_view_count: 14
validation_rule_count: 70
anti_pattern_count: 35
shared_contract: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
predecessor: AI Operating Specification v0.1.0
next_workstream: Product OS v1.0 Final Authority Decision
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This index is the canonical navigation, vocabulary, and coverage register for mapping Product OS into GitHub Spec Kit, Figma, and GitHub without transferring Product OS authority to any tool.

The library answers:

1. Which logical subject is being represented, and which Product OS artifact owns its meaning?
2. Which system is the canonical semantic owner, canonical native owner, working projection, delivery surface, or evidence source?
3. How are Spec Kit feature specifications, plans, tasks, and checklists governed by the 281-artifact lifecycle?
4. How are Figma files, pages, sections, nodes, components, variables, libraries, branches, versions, prototypes, and exports identified?
5. How are GitHub organizations, repositories, paths, commits, branches, tags, issues, pull requests, checks, artifacts, releases, deployments, and environments identified?
6. How do requirements, journeys, designs, code, work items, verification, gate decisions, releases, and operational evidence connect across tools?
7. What may synchronize automatically, what requires controlled promotion, and what remains reference-only?
8. How are stale links, conflicts, missing access, renamed or deleted objects, vendor migration, and tool exit handled?

---

# 2. Governing Position

~~~text
Product OS
  owns lifecycle semantics, authority, artifact identity, classification,
  applicability, traceability, change impact, evidence rules, and gates
       │
       ├── Spec Kit
       │     feature-level specification and execution projection
       ├── Figma
       │     native visual-design realization and design-source identity
       └── GitHub
             native engineering source, work/review, CI, release, and deployment records
~~~

The named tools provide valuable native objects. They do not acquire decision authority merely because work is stored, linked, generated, merged, published, deployed, or marked complete inside them.

---

# 3. Framework and Project Boundary

The files in this directory are framework assets and do not add artifact IDs to the Master Artifact Catalog.

- The catalog remains exactly 281 logical project artifacts.
- Project instances activate mappings only for applicable tools, repositories, Figma files, products, domains, and release scopes.
- A physical file may carry several logical artifact references without merging their owners, states, approvals, or change histories.
- A logical artifact may have several representations while retaining one canonical semantic owner.
- If a named tool is not used, its mapping is `NOT_APPLICABLE` with reason, owner, and reopen condition; the underlying Product OS obligation remains.
- P1/P2/P3 change packaging and assurance depth, not semantic ownership or authority.

---

# 4. Library Map

| No. | Specification | Canonical responsibility |
|---:|---|---|
| 00 | [Shared Cross-Tool Mapping Contract](00_Shared_Cross_Tool_Mapping_Contract.md) | Universal invariants, object model, lifecycle, authority, records, profiles, and change control |
| 01 | [Tool Roles, Canonical Ownership, and Authority](01_Tool_Roles_Canonical_Ownership_and_Authority.md) | Tool boundaries, eight representation roles, ownership resolver, approval separation, and native-object authority |
| 02 | [Identity, Locators, Versions, and Representation Registry](02_Identity_Locators_Versions_and_Representation_Registry.md) | Stable cross-tool identity, locator/version rules, status lifecycle, registry record, integrity, and recovery |
| 03 | [Spec Kit Product OS Profile and Feature Workflow Mapping](03_Spec_Kit_Product_OS_Profile_and_Feature_Workflow_Mapping.md) | Constitution projection, specify/clarify/plan/tasks/analyze/checklist/implement controls, feature packet, and Product OS promotion |
| 04 | [Figma Design Source Mapping](04_Figma_File_Library_Component_Prototype_and_Design_Source_Mapping.md) | File/library/page/node/branch/version identity, design-source ownership, publication/adoption, handoff, and evidence |
| 05 | [GitHub Engineering and Delivery Mapping](05_GitHub_Repository_Branch_Path_Issue_PR_CI_Release_Mapping.md) | Repository/path/revision, issue/PR/check/build/release/deployment mapping, protection, evidence, and environment identity |
| 06 | [Artifact Family and 281-Artifact Coverage Map](06_Artifact_Family_and_281_Artifact_Coverage_Map.md) | Explicit tool disposition for every catalog artifact and family-resolution rules |
| 07 | [Cross-Tool Workflows, Synchronization, Conflict, and Change Propagation](07_Cross_Tool_Workflows_Synchronization_Conflict_and_Change_Propagation.md) | Twelve workflows, six synchronization modes, promotion, drift/conflict handling, and impact routing |
| 08 | [Design-to-Code, Requirements-to-Work, and Evidence Traceability](08_Design_to_Code_Requirements_to_Work_and_Evidence_Traceability.md) | Required paths, handoff packets, state separation, coverage, release lineage, and traversal rules |
| 09 | [Records, Views, Exchange, Access, Migration, and Tool Exit](09_Records_Views_Exchange_Access_Migration_and_Tool_Exit.md) | Minimum records, 14 views, logical exchange, permissions, outage, migration, retention, and exit continuity |
| 10 | [Validation, Metrics, and Anti-Patterns](10_Validation_Metrics_and_Anti_Patterns.md) | 70 validation rules, 35 anti-patterns, review procedure, metrics, and assurance thresholds |
| Closure | [Coverage and Closure Review](Spec_Kit_Figma_GitHub_Mapping_Coverage_and_Closure_Review.md) | Physical, semantic, artifact, gate, workflow, vocabulary, link, conflict, and deferred-work closure |

---

# 5. Controlled Vocabularies

## 5.1 Representation roles — eight

| Code | Meaning |
|---|---|
| `CANONICAL_SEMANTIC` | Owns governed meaning, decision state, or lifecycle semantics |
| `CANONICAL_NATIVE` | Owns the authoritative native object in its specialist system |
| `GOVERNED_REGISTER` | Owns the governed inventory, mapping, applicability, or control record |
| `WORKING_PROJECTION` | Editable tool-specific expression derived from or proposed to a canonical owner |
| `DERIVED_VIEW` | Rebuildable view, report, rendering, index, or dashboard |
| `DELIVERY_OBJECT` | Work, review, packaging, or delivery object that advances execution but is not approval itself |
| `EVIDENCE_REFERENCE` | Exact reference to execution, observation, verification, or preserved proof |
| `NOT_APPLICABLE` | Governed non-use for exact scope with reason and reopen rule |

## 5.2 Mapping statuses — eight

`UNMAPPED`, `PROPOSED`, `ACTIVE`, `ACTIVE_WITH_GAPS`, `STALE`, `CONFLICTED`, `SUPERSEDED`, `RETIRED`.

Applicability is separate: a valid `NOT_APPLICABLE` record is not an `UNMAPPED` failure.

## 5.3 Synchronization modes — six

| Mode | Use |
|---|---|
| `REFERENCE_ONLY` | Stable reference; content is not copied or synchronized |
| `CANONICAL_TO_PROJECTION` | Canonical owner publishes a bounded projection downstream |
| `MANUAL_PROMOTION` | Proposed tool content is reviewed and promoted into the canonical owner |
| `CONTROLLED_BIDIRECTIONAL` | Two governed native objects exchange a defined field subset with conflict controls |
| `EVENT_LINK` | A state-changing event creates or updates a linked record without copying authority |
| `EVIDENCE_CAPTURE` | Immutable or integrity-protected execution/verification evidence is registered |

---

# 6. Twelve Cross-Tool Workflows

| ID | Workflow |
|---|---|
| `XWF-01` | Source intake and external-object registration |
| `XWF-02` | Product Constitution to Spec Kit constitution projection |
| `XWF-03` | Product baseline and requirements to feature specification |
| `XWF-04` | Experience requirements to Figma design realization |
| `XWF-05` | Figma design to engineering handoff and code mapping |
| `XWF-06` | Spec Kit tasks to GitHub work items |
| `XWF-07` | Code change, pull-request review, and requirement/design reconciliation |
| `XWF-08` | CI/test execution and evidence capture |
| `XWF-09` | Verification candidate, defect, and acceptance flow |
| `XWF-10` | Gate G6B/G7 decision, release object, deployment, and post-release validation |
| `XWF-11` | Operational feedback, incident, telemetry, and evolution routing |
| `XWF-12` | Change impact, drift/conflict resolution, baseline reopen, and resynchronization |

---

# 7. Canonical Views — fourteen

1. Artifact-to-tool ownership view.
2. Spec Kit feature packet view.
3. Figma design-source and library view.
4. GitHub repository and code-ownership view.
5. Requirement-to-design view.
6. Design-to-code adoption view.
7. Requirement-to-work-item view.
8. Change/PR-to-verification view.
9. Gate/release/deployment lineage view.
10. Mapping gap and `NOT_APPLICABLE` view.
11. Stale, missing, moved, or deleted locator view.
12. Conflict and pending-promotion view.
13. Access, retention, migration, and tool-exit readiness view.
14. Cross-tool health and assurance dashboard.

---

# 8. Vendor Reference Basis

The mapping uses these external systems as implementation references, while Product OS semantics remain vendor-independent:

- GitHub Spec Kit official repository and documentation for its constitution, specification, planning, tasking, analysis, checklist, issue-conversion, and implementation workflow.
- Figma official REST API and help documentation for file keys, node IDs, versions, branches, libraries, components, variables, styles, publication, and version history.
- GitHub official documentation for repositories, permanent links, commits, issues, pull requests, checks, releases, deployments, and environments.

Vendor behavior is versioned external source material. A vendor change enters `XWF-12`; it never silently changes this contract.

---

# 9. Profile Treatment

| Profile | Physical treatment | Minimum cross-tool obligation |
|---|---|---|
| P1 — Lean / Rapid | One compact mapping register and feature packet; links may be embedded in the owning artifact | Preserve exact subject, canonical owner, tool object, immutable version where evidence matters, status, authority, verification, and reopen triggers |
| P2 — Standard | Separate tool registers, feature folders, design/source indexes, work/evidence links, automated locator checks | Typed roles/statuses/sync modes, deterministic mappings, impact links, review queues, and release lineage |
| P3 — Comprehensive | Independent registers, protected publishing/merge/release paths, signed or integrity-protected evidence, segregation, continuous drift monitoring | Strong identity, immutable baselines, branch/environment controls, independent verification, custody, migration rehearsal, and audit-ready exports |

Domain overrides raise only the affected domain. Compact packaging never removes required identities, decisions, or evidence.

---

# 10. Current Release State

This library is technically complete at Working Draft level. Product OS authority approval and baseline remain pending. It does not configure a live Spec Kit project, modify a Figma file, or alter a GitHub repository.

The Automation library provides bounded execution over these mappings, and the [Pilot](../Pilot/Pilot_Index.md) exercised the repository-side identities and handoffs without live native-system writes. The Product OS v1.0 release candidate is technically finalized; the next action is the Product OS authority decision.

---

# 11. Final Index Principle

> **Tools may own native objects and accelerate delivery; Product OS retains the governed meaning, authority, lineage, and evidence boundary that makes those objects trustworthy.**
