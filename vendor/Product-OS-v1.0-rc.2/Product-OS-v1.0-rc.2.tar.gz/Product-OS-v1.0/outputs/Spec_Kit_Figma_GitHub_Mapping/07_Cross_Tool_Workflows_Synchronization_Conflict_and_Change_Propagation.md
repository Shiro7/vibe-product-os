# Product OS v1.0 — Cross-Tool Workflows, Synchronization, Conflict, and Change Propagation

~~~yaml
document_id: FRAMEWORK-CROSS-TOOL-WORKFLOW-SYNC-CONFLICT-CHANGE
version: 0.1.0
status: WORKING_DRAFT
completion_state: TWELVE_CROSS_TOOL_WORKFLOWS_COMPLETE
inherits: SHARED-CROSS-TOOL-MAPPING-CONTRACT@0.1.0
workflow_count: 12
synchronization_mode_count: 6
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This specification defines how governed information moves among Product OS, Spec Kit, Figma, and GitHub; how proposals return to their owners; and how drift, conflict, partial failure, and material change are detected and resolved.

---

# 2. Workflow Record

Every workflow run records:

~~~yaml
workflow_run_id:
workflow_type:
trigger:
project_domain_release_scope:
source_subjects_and_versions: []
source_tool_objects_and_revisions: []
target_tool_objects_and_expected_revisions: []
synchronization_mode:
allowed_fields: []
protected_fields: []
actor_or_automation_identity:
authority_ref:
preflight_result:
change_ref:
started_completed_at:
result:
changed_objects: []
conflicts_and_gaps: []
verification_and_evidence_refs: []
rollback_or_recovery:
downstream_handoff:
~~~

---

# 3. Six Synchronization Modes

## 3.1 `REFERENCE_ONLY`

Store exact locator, identity, role, and revision metadata; do not copy or write content. Reconcile resolvability and version drift.

## 3.2 `CANONICAL_TO_PROJECTION`

Publish an allow-listed subset from the canonical owner. Target edits outside declared local fields are either rejected or preserved as proposals; they never overwrite canonical fields silently.

## 3.3 `MANUAL_PROMOTION`

Tool content remains proposed until a reviewer classifies it, selects the canonical owner, assesses impact, and records accept/modify/reject/defer plus resulting version.

## 3.4 `CONTROLLED_BIDIRECTIONAL`

Used only when both sides legitimately own different fields of one relationship. Field ownership, direction, revision checks, merge policy, and conflict queue are explicit. It is prohibited for gate decisions, risk acceptance, approval, verification acceptance, release authorization, and canonical requirement meaning.

## 3.5 `EVENT_LINK`

A tool event creates/updates a linked delivery record, such as task-to-issue, issue-to-PR, merge-to-build, defect-to-retest, incident-to-change. Event mapping does not copy authority or equate statuses.

## 3.6 `EVIDENCE_CAPTURE`

Register exact source, candidate, revision, environment, time, method, result, logs/artifacts/digest, collector, retention, and claim bindings. Tool success text is a claim until the evidence record is evaluated.

---

# 4. XWF-01 — Source Intake and External-Object Registration

**Trigger:** a repository, design file/library, Spec Kit project/packet, link, export, issue, PR, build, release, or other tool object enters scope.

**Flow:**

~~~text
input received
→ verify project/tool/container identity and access boundary
→ register source and native object
→ classify content as data, instruction, evidence, representation, or delivery object
→ extract facts/assumptions/questions/decisions/requirements without promotion
→ map to canonical owners
→ record conflicts, risks, privacy/license/retention, and freshness
→ route downstream or mark governed N/A
~~~

**Controls:** untrusted content remains data; cross-project links are not adopted; credentials are excluded; inaccessible links remain unresolved rather than guessed.

---

# 5. XWF-02 — Product Constitution to Spec Kit Projection

**Trigger:** initial setup; GOV-001/GOV-009/AI/engineering rule change; Spec Kit template/tool upgrade.

**Flow:** resolve exact upstream versions → select applicable repository/feature rules → generate/diff projection → preserve local proposals → human review of material changes → publish projection → register digest/version → mark feature packets stale if affected.

**Conflict rule:** upstream Product OS wins only within its approved authority/scope; stricter runtime/vendor controls remain; incompatible local rules enter GOV-003/GOV-007, not silent deletion.

---

# 6. XWF-03 — Product and Requirements to Feature Specification

**Trigger:** approved feature/change route, PBL/RBL update, defect/evolution authorization.

**Flow:** select exact PROD/REQ scope → create packet → project canonical statements with IDs → clarify unknowns → classify new proposals → promote accepted changes upstream → reconcile spec → run consistency analysis → hand off to design/plan.

**Gate boundary:** feature spec readiness cannot create G3A/G3B; it consumes their baselines or declares an authorized change route.

---

# 7. XWF-04 — Experience Requirements to Figma Realization

**Trigger:** EXP/DES work authorized; requirement/journey change; new platform/language/state/profile.

**Flow:** bind REQ/EXP IDs → select design source/file/branch/version → realize required states, responsive/platform, accessibility/localization, content, interaction → review → promote design decisions to canonical owners → validate coverage → create G4B candidate membership.

**Conflict rule:** visual convenience cannot override requirement/experience semantics; deliberate divergence needs decision/change record.

---

# 8. XWF-05 — Figma to Engineering Handoff and Code Mapping

**Trigger:** design reaches governed handoff state or material design update.

**Flow:** freeze exact Figma version/membership → create DES-023 packet → bind nodes/components/variables/assets to repositories/paths/symbols → classify gaps → engineering acknowledgement → build ENG-009 mapping → implement → update IMP-005/006 → verify active adoption.

**Controls:** published is not adopted; code definition is not active usage; screenshot is not full parity proof; later Figma edit marks affected mappings stale.

---

# 9. XWF-06 — Spec Kit Tasks to GitHub Work Items

**Trigger:** plan/tasks approved for delivery and target repository resolved.

**Flow:** validate task IDs/dependencies/DoR → create or link issue/project item → write stable upstream IDs and scope → register issue mapping → route ownership and scheduling → synchronize only allowed delivery fields → preserve split/duplicate/transfer/reopen lineage.

**Status mapping:** GitHub issue state may update a delivery view; Product OS completion/verification changes only through governed records.

---

# 10. XWF-07 — Code Change, PR Review, and Reconciliation

**Trigger:** implementation task starts, PR opens/updates/merges/closes, or design/requirement changes during implementation.

**Flow:** resolve task/base SHA/target paths/design version → implement bounded change → link PR → run reviews/checks → classify deviations and new discoveries → promote canonical changes where accepted → merge exact approved revision → update implementation record and candidate eligibility.

**Controls:** later commits may stale reviews/evidence; administrative bypass and force push are visible; merge is not verification or release.

---

# 11. XWF-08 — CI/Test Execution and Evidence Capture

**Trigger:** push/PR/manual/scheduled/release event or verification request.

**Flow:** identify workflow definition/revision/trigger/candidate/environment/data → execute → preserve attempts/results/logs/reports/artifacts/digests → bind claims/cases/requirements → assess fitness/sufficiency → route failures/flakes/waivers → update evidence index and coverage.

**Controls:** expired artifacts are archived when retention requires; retry success does not erase earlier failure; untrusted workflows do not receive privileged secrets.

---

# 12. XWF-09 — Verification Candidate, Defect, and Acceptance

**Trigger:** IMP-029 candidate handoff or a candidate-changing event.

**Flow:** freeze candidate identity → allocate VRL cases → collect GitHub/Figma/external evidence → identify defects/gaps → create mapped work items → fix and generate new candidate as materiality requires → retest/regression → authorized acceptance → G6B decision.

**Controls:** evidence cannot migrate to a new candidate without impact analysis; issue closure is not defect verification; UAT/business acceptance is separate from technical check success.

---

# 13. XWF-10 — Release, Deployment, and Post-Release Validation

**Trigger:** G6B pass/conditional path and release preparation.

**Flow:** assemble exact release scope/target/plan/rollback → evaluate G7 → if authorized, create/confirm tag/release/deployment object within scope → execute deployment → record deviation → verify live target identity and health → hand off operational baseline.

**Controls:** release object creation follows G7; deployment revision and environment must match authorization; successful provider status requires post-release validation; deviation may stop/rollback/reopen.

---

# 14. XWF-11 — Operational Feedback and Evolution Routing

**Trigger:** incident, support signal, metric/SLO result, accessibility/content issue, vulnerability, dependency update, drift, debt, opportunity, experiment, lifecycle review.

**Flow:** register live identity and evidence → classify signal/problem/risk/change → link GitHub operational work and Figma experience/design input as relevant → decide corrective/evolution route → identify earliest affected baseline → create Product OS/Spec Kit packet → preserve operational outcome.

**Controls:** telemetry correlation is not causation; emergency work retains minimum identity/authority/evidence and retrospective review.

---

# 15. XWF-12 — Change, Drift, Conflict, Reopen, and Resynchronization

**Trigger:** any mapped source/target/version/field/owner/tool/configuration/permission/vendor behavior changes, or reconciliation detects difference.

**Flow:**

~~~text
detect event or drift
→ freeze source/target revisions and capture diff
→ create/update GOV-007 change and mapping health record
→ classify materiality and affected objects
→ traverse Product OS and cross-tool links
→ mark stale/conflicted/invalidated representations and evidence
→ decide no-impact, update, re-review, re-verify, reopen, rollback, or migrate
→ execute authorized repairs/promotions
→ verify exact intended state
→ resynchronize derived projections/views
→ obtain downstream acknowledgements
→ close only with evidence and residual risk disposition
~~~

---

# 16. Conflict Taxonomy

| Code | Conflict |
|---|---|
| `XCF-01` | Canonical owner ambiguity |
| `XCF-02` | Same subject mapped to incompatible native objects |
| `XCF-03` | Same native object claims incompatible subject/scope |
| `XCF-04` | Revision mismatch or concurrent edit |
| `XCF-05` | Protected field changed from a projection |
| `XCF-06` | Requirement–design disagreement |
| `XCF-07` | Design–code drift or partial adoption |
| `XCF-08` | Task/issue/PR status disagreement |
| `XCF-09` | Candidate/evidence/release revision mismatch |
| `XCF-10` | Permission, retention, deletion, migration, or access conflict |
| `XCF-11` | Tool/template/vendor semantic drift |
| `XCF-12` | Cross-project, tenant, repository, file, or environment contamination |

---

# 17. Conflict Resolution Procedure

1. Stop automatic writes for affected fields.
2. Capture both/all values, identities, revisions, authors, times, and provenance.
3. Determine whether difference is rename, intended local override, stale projection, parallel valid scope, or semantic conflict.
4. Resolve the canonical owner and competent authority.
5. Assess downstream artifact, gate, candidate, evidence, release, and live impact.
6. Choose accept source, accept target, merge fields, split scope/identity, supersede, rollback, or defer/block.
7. Record decision/rationale and preserve rejected/superseded history.
8. Apply and verify repair.
9. Regenerate/reconcile dependent projections and evidence views.
10. Obtain required acknowledgements and close the conflict record.

Last-write-wins is allowed only for explicitly disposable, non-governed derived fields with no material consequence.

---

# 18. Partial Failure and Recovery

| Failure | Required disposition |
|---|---|
| Source read fails | No target write; record access/error and retry/escalation rule |
| Target write partially succeeds | Capture exact changed subset; stop further writes; recover/roll back or reconcile |
| Webhook/event duplicated | Idempotency key prevents duplicate semantic event |
| Event arrives out of order | Compare versions/timestamps; do not regress state |
| Automation identity revoked | Stop safely; preserve queue and ownership escalation |
| Object moved/deleted | Preserve tombstone; resolve replacement/recovery/migration |
| Evidence expires | Mark sufficiency impact; restore archive or re-execute verification |
| Tool unavailable | Use read-only cached/exported state within freshness rules; queue changes; reconcile before promotion |

---

# 19. Final Workflow Principle

> **Move references automatically, move proposals through review, move evidence with exact identity, and never move authority by synchronization.**

