# Product OS v1.0 — Gate, Baseline, Reopen, and Proportional Review

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-05
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
gate_scope: G0_THROUGH_G8_INCLUDING_SPLIT_GATES
gate_count: 13
governed_project_artifact: GOV-007
~~~

---

# 1. Purpose

This specification determines whether an approved baseline or gate decision remains valid after change, which exact scope reopens, how downstream decisions are reviewed proportionally, and how historical approvals are preserved.

The gate authority owns the decision. Change Impact Rules supplies the required assessment and routing contract.

---

# 2. Core Reopen Rule

Reopen the earliest gate whose accepted meaning, evidence, authority, conditions, or exact scope is materially affected.

Then assess every downstream gate that relied on the changed truth:

~~~text
earliest affected gate
→ exact baseline scope re-entry
→ downstream dependency assessment
→ preserve unaffected decisions
→ re-review partly affected decisions
→ invalidate decisions that cannot still support their scope
→ issue new decisions with new identities and validity
~~~

Neither “restart everything” nor “patch only the final artifact” is acceptable by default.

---

# 3. Common Reopen Triggers

The Gate Specifications vocabulary is retained:

~~~text
MATERIAL_SCOPE_CHANGE
UPSTREAM_BASELINE_REVISION
NEW_OR_INVALIDATED_EVIDENCE
CRITICAL_DEFECT_OR_INCIDENT
STANDARDS_OR_APPLICABILITY_CHANGE
EXPIRED_CONDITION_EXCEPTION_WAIVER_OR_APPROVAL
DEPENDENCY_OR_VENDOR_CHANGE
TARGET_ENVIRONMENT_OR_CONFIGURATION_CHANGE
NEW_USER_MARKET_PLATFORM_REGION_LANGUAGE_OR_DATA_SCOPE
MATERIAL_RISK_OR_ASSUMPTION_CHANGE
FAILED_DOWNSTREAM_VALIDATION
LIFECYCLE_MODE_CHANGE
AUTHORITY_CHANGE
~~~

Each gate adds its local triggers. A trigger initiates assessment; it does not automatically decide invalidation.

---

# 4. Canonical Gate Impact Dispositions

~~~text
UNAFFECTED
REVIEW_REQUIRED
PARTIALLY_INVALIDATED
FULLY_INVALIDATED
SUPERSEDED
~~~

| Disposition | Meaning | Required action |
|---|---|---|
| UNAFFECTED | Positive assessment proves the prior gate decision remains valid for exact scope | Preserve decision and evidence; record rationale and reopen trigger |
| REVIEW_REQUIRED | Plausible material reliance exists and gate authority has not completed review | Restrict progression for affected scope and schedule decision |
| PARTIALLY_INVALIDATED | Exact partitions of the prior decision no longer hold | Preserve unaffected partitions; create re-entry and new decision for affected partitions |
| FULLY_INVALIDATED | The prior decision cannot support any current included scope | Stop reliance; reopen gate and downstream dependents |
| SUPERSEDED | A later valid gate decision replaces the prior decision | Preserve old decision and link new identity, scope, and effective time |

These are impact dispositions. They do not replace gate check status, gate outcome, decision workflow status, or lifecycle disposition.

---

# 5. Gate Decision Immutability

Never edit a historical gate decision to appear as if it originally covered changed scope or evidence.

A reopened cycle records:

~~~yaml
gate_reentry_id:
gate_id:
prior_gate_decision_ref:
change_ref:
impact_assessment_ref:
affected_scope:
unaffected_scope:
gate_impact_disposition:
reentry_reason:
required_checks: []
preserved_checks: []
invalidated_evidence: []
new_evidence_required: []
conditions_under_review: []
decision_authority:
reentry_status:
new_gate_decision_ref:
opened_at:
closed_at:
~~~

The prior decision keeps its original outcome, evidence pack, authority, and date. Its lifecycle records reopened/superseded effect for current scope.

---

# 6. Proportional Review Algorithm

~~~text
1. Bind the prior gate decision, baseline version, scope, checks, evidence, conditions, and validity.
2. Overlay the assessed changed scope and affected-object dispositions.
3. Identify which gate claims and detailed checks relied on changed truth.
4. Preserve a check only when its claim, source, evidence, scope, version, and condition remain valid.
5. Mark affected checks for re-review and invalid evidence for replacement.
6. Determine gate impact disposition for each scope partition.
7. Route affected upstream truth to its canonical owner before gate re-decision.
8. Re-run required checks and independent reviews for affected scope.
9. Assess every downstream gate that relied on the prior decision.
10. Issue new gate decision and baseline identity; acknowledge downstream handoff.
~~~

Proportionality reduces redundant review. It never lowers required quality, authority, segregation, or evidence.

---

# 7. Preservation Test for a Prior Check

A gate check may be preserved only if all are true:

1. its exact decision claim is unchanged;
2. the source and canonical artifact versions remain valid;
3. evidence still covers the same candidate, scope, environment, population, and period;
4. no condition, exception, waiver, risk, standard, authority, or dependency invalidates it;
5. relevant trace paths remain confirmed and current;
6. the check’s owner and gate authority accept preservation;
7. preservation is recorded in the new re-entry pack.

File or test reuse without this test is not proportional review.

---

# 8. Thirteen-Gate Reopen Map

| Gate | Reopen when changed meaning affects | Minimum re-entry evidence |
|---|---|---|
| G0 — Intake Ready | Project/product identity, engagement, source intake, route, preliminary profile, authority, or immediate risk | Corrected intake, route, profile/override, source and governance records |
| G1 — Problem Understood | User/problem scope, current state, cause, stakeholder, outcome, assumption, question, or discovery evidence | Updated discovery baseline, sources, uncertainty, and receiving acknowledgement |
| G2 — Business Baseline | Business capability, process, rule, control, information, ownership, risk, priority, or standards-derived business obligation | Revised BBL objects, authority, control/risk treatment, and trace paths |
| G3A — Product Baseline | Product boundary, capability, module, policy, platform, market, journey responsibility, state, or release scope | Revised product baseline, applicability review, dependencies, and product decision |
| G3B — Requirements Baseline | Requirement, acceptance, quality, data, integration, security, privacy, accessibility, audit, priority, or traceability | Updated SRS/RBL, atomic obligations, acceptance, verification method, and coverage |
| G4A — Experience Baseline | Journey, actor, state, IA, navigation, flow, interaction, content, recovery, language, or accessibility | Updated EBL, journey/state coverage, rules, evidence, and requirement alignment |
| G4B — Design Baseline | Screen, component, token, design state, platform output, responsive behavior, localization, asset, or handoff | Updated DBL, design-system coverage, accessibility evidence, and implementation handoff |
| G5A — Architecture Baseline | Driver, constraint, decision, boundary, service, data, trust, integration, deployment, resilience, recovery, or observability | Revised ABL/ADRs, risk/control analysis, compatibility/migration/rollback, and requirement coverage |
| G5B — Engineering Readiness | Work scope, dependency, environment, migration, control, allocation, test/evidence plan, or readiness | Revised ERBL, executable plan, owners, dependencies, environments, and acceptance/evidence plan |
| G6A — Implementation Baseline | Built candidate, code, configuration, infrastructure, migration, deviation, dependency, environment, or implementation evidence | New candidate and digest, baseline comparison, deviations, build/migration evidence, and exact configuration |
| G6B — Verification Baseline | Candidate identity, verification method/result, coverage, defect, exception, residual gap, or evidence | New candidate-bound VBL, rerun results, defect/exception disposition, and independent verification |
| G7 — Release Authorization | Candidate, target, rollout, cohort, window, condition, rollback, communication, monitoring, or production validation plan | Current G6B, release scope, risk/condition status, rollout/rollback, target identity, and authority |
| G8 — Operational Sustainability and Evolution | Live scope, SLO, incident, support, control, outcome, vendor, lifecycle, evolution, transfer, sunset, or retirement | Current operational evidence, control/incident/outcome assessment, obligations, and lifecycle route |

---

# 9. Upstream Reopen and Downstream Assessment

When an upstream gate reopens:

1. downstream decisions become `REVIEW_REQUIRED` only where their reliance is plausible or confirmed;
2. graph paths identify candidate reliance;
3. downstream authority assigns the final gate impact disposition;
4. a downstream decision may remain `UNAFFECTED` only with positive scope/version/evidence rationale;
5. changed upstream truth cannot be hidden by downstream remediation;
6. invalidated downstream evidence is replaced before a new favorable decision;
7. unaffected parallel release/live scopes may continue only when safely partitioned and authorized.

---

# 10. Baseline Actions

| Baseline situation | Required action |
|---|---|
| Meaning unchanged | Preserve baseline identity and link no-impact assessment where material candidate existed |
| Exact partition affected | Create revised baseline partition or new version; preserve unaffected partition mapping |
| Baseline stale pending decision | Mark GOV-002 lifecycle `STALE`; prohibit unqualified downstream reliance |
| Baseline invalid | Create re-entry; invalidate dependent gate evidence for scope |
| Replacement approved | Create new baseline identity/version and explicit supersession |
| Change rejected/deferred | Preserve current baseline; record decision, conditions, and future trigger |
| Rollback restores prior technical state | Reverify that business/product/evidence/live truth is also restored before reinstating reliance |

A rollback does not automatically restore a prior baseline’s validity; intervening data, users, evidence, incidents, or dependencies may have changed.

---

# 11. Gate Conditions, Exceptions, and Waivers

Review every condition, exception, waiver, and accepted risk whose scope overlaps the change.

For each:

~~~yaml
governance_item_ref:
prior_scope:
change_overlap:
authority_still_valid:
evidence_still_valid:
expiry_or_event:
impact_disposition:
required_action:
owner:
decision_ref:
~~~

Change cannot silently widen an exception or reset expiry. New scope requires new authority.

---

# 12. In-Flight Work

Before re-entry decision, affected in-flight work is classified:

~~~text
CONTINUE_UNAFFECTED_SCOPE
CONTINUE_AT_RISK_WITH_AUTHORITY
PAUSE_PENDING_REVIEW
STOP_AND_REPLAN
REWORK_REQUIRED
DISCARD_INVALID_OUTPUT
CONTAIN_OR_ROLLBACK
~~~

The action binds exact scope, owner, authority, evidence, and expiry. “Continue at risk” is a governed risk decision, not a project-management convenience.

---

# 13. Re-Entry Completion

Gate re-entry is complete when:

1. affected scope and prior decision resolve;
2. earliest owning truth is updated and approved where required;
3. required checks are rerun and preserved checks pass the preservation test;
4. invalidated evidence is replaced;
5. conditions, risks, exceptions, and waivers are current;
6. downstream gate impact decisions are issued;
7. new baseline/gate decision identities and history are registered;
8. receiving owners acknowledge conditions and prohibited actions;
9. implementation, release, and live scope match the new decision;
10. reopen triggers and validity period are explicit.

---

# 14. Final Gate Principle

> **Reopen the earliest truth that became materially unreliable, re-review only the scope that depended on it, preserve every unaffected decision with positive evidence, and never let proportionality become a shortcut around an invalid upstream baseline.**
