# Product OS v1.0 — Validation, Metrics, and Anti-Patterns

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-10
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
validation_rule_count: 60
anti_pattern_count: 30
governed_project_artifact: GOV-007
~~~

---

# 1. Purpose

This specification defines the technical and semantic validation rules, assurance cadence, operational metrics, and prohibited anti-patterns used to judge whether change impact is complete and trustworthy.

Automation reports deterministic conformance. Human or accountable authority retains semantic decisions.

---

# 2. Validation Result

~~~text
PASS
FAIL
BLOCKED
NOT_REVIEWED
NOT_APPLICABLE
SUPERSEDED
~~~

Every validation result records rule ID, exact subject/scope/version, observed value, expected rule, evidence, validator, time, and remediation owner when not PASS.

---

# 3. Identity and Intake Rules

~~~text
CIR-VAL-001  Every governed change has one stable change_id and canonical GOV-007 locator.
CIR-VAL-002  Every change binds exact current and proposed object identities, versions, and effective scope or an explicit blocking unknown.
CIR-VAL-003  Source event, change request, decision, action, implementation, verification, release, outcome, and closure identities remain separate.
CIR-VAL-004  Primary change class is exactly one of CIR-CC-01 through CIR-CC-22, primary intent is one of the eight controlled intents, and secondary values use their respective vocabularies.
CIR-VAL-005  Change revisions preserve stable identity and immutable prior history.
CIR-VAL-006  Duplicate, parent/child, dependency, conflict, coordination, and supersession relationships preserve independent scope and authority.
CIR-VAL-007  Included, excluded, uncertain, and inaccessible scope partitions are explicit.
CIR-VAL-008  Urgency has rationale; emergency or critical containment also has bounded authority and retrospective due event.
CIR-VAL-009  M0 classification passes every non-semantic edit test.
CIR-VAL-010  Intake handoff identifies owner, required assessors, sources, evidence, compatibility, reversibility, gaps, and readiness.
~~~

---

# 4. Traversal and Assessment Rules

~~~text
CIR-VAL-011  Every material candidate references a reproducible GOV-008 impact discovery with graph revision, valid time, scope, policy, and path evidence.
CIR-VAL-012  Required direct, transitive, dependency, governance, evidence, gate, release, live, and lifecycle traversal policies run where applicable.
CIR-VAL-013  Candidate, assessed, added, excluded, unresolved, affected, and unaffected sets reconcile arithmetically.
CIR-VAL-014  Every graph candidate has an assessment result or explicit unresolved state.
CIR-VAL-015  Every assessor-added object creates or updates the required GOV-008 relationship or gap.
CIR-VAL-016  Missing, conflicted, inaccessible, and truncated branches remain explicit and cannot prove no impact.
CIR-VAL-017  Every authorized candidate exclusion binds scope, rationale, evidence, assessor, authority, date, and reopen trigger.
CIR-VAL-018  Scope intersection uses complete changed, relationship, dependent, profile, time, and release/live scope where applicable.
CIR-VAL-019  Earliest affected phase and gate preserve graph candidates, competing paths, owner rationale, and authority.
CIR-VAL-020  Re-traversal occurs when delta, scope, graph, applicability, evidence, remediation, candidate, release, or live truth changes materially.
~~~

---

# 5. Materiality and Disposition Rules

~~~text
CIR-VAL-021  Every completed assessment selects one materiality level M0 through M5 for exact scope and revision.
CIR-VAL-022  The strongest supported materiality dimension sets the minimum routing level.
CIR-VAL-023  Uncertainty cannot lower materiality below a plausible unexcluded consequence.
CIR-VAL-024  M3, M4, and M5 changes route required gate, baseline, release, live, risk, control, or critical authorities.
CIR-VAL-025  NO_IMPACT passes all twelve positive decision tests and has valid authority.
CIR-VAL-026  A confirmed governed effect prevents whole-assessment NO_IMPACT.
CIR-VAL-027  Every assessed object uses exactly one current CIR-OD-01 through CIR-OD-10 disposition per scope partition.
CIR-VAL-028  PARTIALLY_AFFECTED has explicit affected and unaffected extents.
CIR-VAL-029  UNAFFECTED and NOT_APPLICABLE_WITH_EVIDENCE have positive rationale, evidence, authority where required, and reopen triggers.
CIR-VAL-030  STALE, INVALIDATED, SUPERSEDED, NEWLY_REQUIRED, CURRENT_WITH_CONDITIONS, and REMEDIATION_REQUIRED trigger their mandated registry, graph, evidence, verification, action, and receiver consequences.
~~~

---

# 6. Registry, Evidence, and Gate Rules

~~~text
CIR-VAL-031  An artifact whose approved meaning may no longer be relied upon is marked STALE in GOV-002 for affected scope.
CIR-VAL-032  Changed relationships create versioned GOV-008 history; confirmed history is never rewritten in place.
CIR-VAL-033  Applicable trigger changes initiate GOV-009 reevaluation and preserve the applicability authority decision.
CIR-VAL-034  Every invalidated verification result binds claim, candidate, configuration, environment, scope, reason, owner, and replacement requirement.
CIR-VAL-035  Every invalidated evidence item binds supported claim, affected scope/period, reason, dependents, retention, owner, and replacement action.
CIR-VAL-036  Evidence or verification remains current for unaffected partitions only when partitioning and equivalence are proven.
CIR-VAL-037  Every impacted gate uses UNAFFECTED, REVIEW_REQUIRED, PARTIALLY_INVALIDATED, FULLY_INVALIDATED, or SUPERSEDED separately from gate outcome.
CIR-VAL-038  Gate adjacency or graph reachability never causes automatic invalidation without scope and meaning assessment.
CIR-VAL-039  Reopened gates preserve prior decisions and create new re-entry and decision identities.
CIR-VAL-040  Every preserved gate check passes the claim, source, version, evidence, scope, condition, trace, owner, and authority preservation test.
~~~

---

# 7. Action, Acknowledgement, and Closure Rules

~~~text
CIR-VAL-041  Every confirmed impact has an authorized disposition and required action or bounded no-action rationale.
CIR-VAL-042  Every mandatory action has exact scope, target versions, one accountable owner, due event, dependencies, authority, verification, and failure route.
CIR-VAL-043  Action IMPLEMENTED, VERIFIED, and CLOSED states remain distinct and evidenced.
CIR-VAL-044  Implementation identity matches approved scope, candidate, configuration, environment, migration, and target or records a governed deviation.
CIR-VAL-045  Verification covers intended effect and prohibited collateral effect for material scope.
CIR-VAL-046  Every handoff includes versions, included/excluded scope, conditions, dependencies, prohibited actions, evidence, due events, and reopen triggers.
CIR-VAL-047  Required receivers acknowledge, challenge, reject wrong ownership, or expose access blockers explicitly.
CIR-VAL-048  Residual obligations have owner, due event, evidence, monitoring, accepting authority, breach action, and closure effect.
CIR-VAL-049  Closure passes all fifteen shared closure checks and has valid closure authority.
CIR-VAL-050  Reopen preserves prior closure and creates a new assessment and traversal revision.
~~~

---

# 8. Profile, Exceptional, and Automation Rules

~~~text
CIR-VAL-051  P1, P2, and P3 packaging preserve all universal logical obligations.
CIR-VAL-052  Activated domain overrides record trigger, scope, stronger treatment, evidence, segregation, authority, exit, and reopen rules.
CIR-VAL-053  Authority is valid for exact decision type, scope, profile, domain, time, delegation, and segregation requirement.
CIR-VAL-054  AI recommendations remain attributed proposals and cannot become approval, no-impact, risk acceptance, gate, release, or closure decisions automatically.
CIR-VAL-055  Deterministic automation records rule/input versions and never manufactures semantic authority.
CIR-VAL-056  Tool outage fallback preserves identities, gaps, manual authority, evidence, restrictions, and later reconciliation.
CIR-VAL-057  Emergency action binds declaration/necessity, exact target, actor, time, safeguards, evidence, temporary expiry, and retrospective review.
CIR-VAL-058  Brownfield assessment never converts missing history to approval, verification, or NOT_APPLICABLE.
CIR-VAL-059  Concurrent changes record relationship, shared scope, version order, interference, combined verification, release/live plan, and rollback interaction.
CIR-VAL-060  Every exported or federated record preserves controlled semantics, identity, authority, scope, time, history, redaction, and referential integrity.
~~~

---

# 9. Validation Modes

| Mode | Use | Typical execution |
|---|---|---|
| PRE_INTAKE | Before traversal begins | Identity, delta, class, scope, owner, urgency, and readiness rules |
| ASSESSMENT | During impact judgment | Traversal, set reconciliation, materiality, authority, and disposition rules |
| PRE_APPROVAL | Before change/gate/risk decision | Evidence, conditions, invalidation, migration, rollback, and segregation rules |
| PRE_EXECUTION | Before implementation or containment | Approved scope, dependencies, target identity, safeguards, and rollback rules |
| PRE_VERIFICATION | Before claiming verified response | Candidate/configuration/environment, method, evidence, and independence rules |
| PRE_RELEASE_OR_LIVE | Before release, rollout, or operational change | G6B/G7/G8, target, cohort, monitoring, communication, and rollback rules |
| PRE_CLOSURE | Before closing GOV-007 | Actions, evidence, registry/graph/profile/gate updates, acknowledgements, residuals, and closure rules |
| CONTINUOUS | After closure and in live operation | Expiry, drift, incident, evidence invalidation, residual obligation, and reopen triggers |

---

# 10. Severity

~~~text
BLOCKER
MAJOR
MINOR
ADVISORY
~~~

- `BLOCKER`: progression would violate mandatory authority, scope, evidence, gate, safety/control, or closure truth;
- `MAJOR`: material integrity or coverage is incomplete and must be resolved before affected decision;
- `MINOR`: bounded defect that does not currently defeat decision validity but needs correction;
- `ADVISORY`: improvement without present conformance failure.

Severity is determined by consequence and gate effect, not remediation effort.

---

# 11. Metrics

Measure at exact scope and period:

| Metric | Definition | Guardrail |
|---|---|---|
| Intake-to-triage time | Time from source event/change creation to completed triage | Exclude neither emergencies nor rejected changes; segment them |
| Triage-to-assessment time | Time until authorized materiality and impact assessment | Report blockers separately |
| Candidate assessment coverage | Assessed candidates / all candidates | Exclusions and unresolved remain visible |
| Candidate-set expansion rate | Assessor-added objects / graph candidate objects | High rate may indicate graph gaps, not assessor productivity |
| Unresolved-impact age | Age of unresolved candidate branches | Segment access, authority, conflict, and missing-path causes |
| No-impact reversal rate | `NO_IMPACT` decisions later reopened with confirmed impact / all no-impact decisions | High rate indicates weak scope/evidence/authority |
| Earliest-phase correction rate | Final earliest phase differs from graph candidate | Use to improve graph, not eliminate human judgment |
| Gate reopen rate | Gate decisions reopened due to material change / active decisions | Interpret with change volume and product maturity |
| Proportional preservation rate | Preserved valid checks / checks considered in re-entry | Never optimize by lowering review |
| Evidence invalidation propagation time | Time from evidence invalidation to dependent disposition | Critical scopes require shorter thresholds |
| Owner assignment completeness | Mandatory actions with valid owner / mandatory actions | Team label alone may be insufficient |
| Due-event breach rate | Mandatory actions missing due events or breaching them / active actions | Segment approved deferrals |
| Acknowledgement latency | Time from handoff to valid receiver response | Delivery is not acknowledgement |
| Change failure/rollback rate | Changes causing failed verification, rollback, incident, or critical correction / executed changes | Segment cause and materiality |
| Closure escape rate | Closed changes reopened for obligation known or discoverable at closure / closed changes | Distinguish genuinely new events |
| Residual obligation breach rate | Residual obligations breaching bounds / accepted residual obligations | Acceptance cannot hide breach |
| Emergency retrospective timeliness | Emergency changes reviewed within required window / emergency changes | Missing record counts as failure |
| Brownfield uncertainty burn-down | Resolved critical unknowns / planned critical unknowns | Do not convert unknown to N/A |
| Automation override rate | Human decisions differing from automated recommendation / reviewed recommendations | Investigate rule/model drift, not reviewer obedience |
| Validation conformance | Applicable CIR-VAL PASS / reviewed applicable rules | Report blocked/not-reviewed separately |

Metrics are signals for governance improvement. They must not reward hiding, splitting, relabeling, premature closure, or avoidance of registration.

---

# 12. Assurance Cadence

Review change-impact controls:

- before every affected gate or baseline decision;
- before implementation of material approved scope;
- before G6B, G7, and relevant G8 decisions;
- after emergency action, rollback, failed migration, failed verification, incident, or evidence invalidation;
- when conditions, exceptions, waivers, approvals, or evidence expire;
- during periodic GOV-002/GOV-008/GOV-009 reconciliation;
- before lifecycle transfer, sunset, or retirement;
- after framework contract, schema, repository, or tool migration;
- at profile/domain-specific audit cadence.

---

# 13. Anti-Patterns

~~~text
CIR-AP-01  Treating a change request as approval.
CIR-AP-02  Calling a change minor because the diff or effort is small.
CIR-AP-03  Treating refactor, documentation, configuration, dependency, or emergency labels as proof of no behavior change.
CIR-AP-04  Using absence of a graph edge as proof of no impact.
CIR-AP-05  Treating every graph-reachable object as automatically invalidated.
CIR-AP-06  Omitting uncertain, conflicted, inaccessible, or truncated branches from the assessment denominator.
CIR-AP-07  Recording PARTIAL without exact affected and unaffected scope.
CIR-AP-08  Using one status for change lifecycle, impact, artifact, verification, gate, and closure.
CIR-AP-09  Marking an artifact NOT_APPLICABLE because work is inconvenient or evidence is missing.
CIR-AP-10  Keeping a changed artifact CURRENT in GOV-002 while approved meaning may no longer be relied upon.
CIR-AP-11  Rewriting old graph edges, approvals, gate decisions, tests, or evidence to match new truth.
CIR-AP-12  Reusing test evidence after candidate, configuration, environment, data, or scope changes without equivalence proof.
CIR-AP-13  Patching downstream implementation while leaving invalid upstream requirement or decision unchanged.
CIR-AP-14  Restarting every phase and gate without scope analysis.
CIR-AP-15  Preserving gate checks solely because files or tests still exist.
CIR-AP-16  Letting the requester or implementer self-approve critical impact without required segregation.
CIR-AP-17  Treating handoff delivery as acknowledgement or acknowledgement as action completion.
CIR-AP-18  Assigning actions to an unresolvable team, backlog, or future phase without accountable owner and due event.
CIR-AP-19  Closing a parent change while mandatory child actions remain open or hidden.
CIR-AP-20  Using residual risk or debt to bypass a mandatory standard, control, evidence, or gate requirement.
CIR-AP-21  Declaring rollback complete without verifying restored data, configuration, users, integrations, and live state.
CIR-AP-22  Allowing emergency containment to become a permanent unreviewed state.
CIR-AP-23  Fabricating retrospective approval or evidence for a brownfield system.
CIR-AP-24  Verifying concurrent changes separately without testing their combined behavior and rollback interaction.
CIR-AP-25  Letting a freeze exception silently widen beyond exact scope and expiry.
CIR-AP-26  Allowing AI to approve materiality, no impact, risk, gate, release, or closure.
CIR-AP-27  Treating a dashboard, ticket, commit, deployment, or tool status as canonical authority by itself.
CIR-AP-28  Backdating decisions or deleting rejected, failed, rolled-back, superseded, or reopened history.
CIR-AP-29  Optimizing metrics by avoiding registration, splitting scope artificially, or closing early.
CIR-AP-30  Assuming technical closure of this framework baselines Product OS or approves any project change.
~~~

---

# 14. Technical Closure Criteria

A Change Impact Rules implementation is technically complete when:

1. all 60 validation rules are represented and testable through human, automated, or hybrid review;
2. all 30 anti-patterns are detectable or reviewable;
3. controlled vocabularies round-trip across records and tools;
4. all 281 artifacts and 13 gates can participate without new project artifact IDs;
5. graph candidate and assessed sets reconcile;
6. approval, baseline, release, live, and closure authority remain external to technical existence;
7. Source / Evidence Model hooks remain explicit.

---

# 15. Final Validation Principle

> **Good change metrics reveal uncertainty, delay, invalidation, and escape; good validation blocks false certainty; neither is allowed to reward missing registration, shallow review, or premature closure.**
