# Product OS v1.0 — Change Intake and Identity

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-01
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
change_class_count: 22
change_intent_count: 8
governed_project_artifact: GOV-007
~~~

---

# 1. Purpose

This specification defines when a change enters governance, how its identity is established, how exact current and proposed states are bound, and how triage routes the event without pretending that classification is approval.

---

# 2. Intake Triggers

Create or update `GOV-007` when any of the following occurs:

1. a governed object or relationship changes meaning, identity, version, scope, status, applicability, owner, or authority;
2. a source or evidence item is corrected, contradicted, withdrawn, expires, loses authority, or becomes inaccessible;
3. an assumption fails, a question is answered materially, a decision changes, or risk/control conditions change;
4. a standard, law, contract, platform, vendor, integration, environment, configuration, or dependency changes;
5. implementation differs from approved scope or a new candidate is built;
6. verification, release, incident, control, support, outcome, or evolution evidence contradicts approved meaning;
7. a gate, baseline, condition, exception, waiver, approval, or evidence period expires;
8. an artifact, module, contract, methodology, vocabulary, schema, repository mapping, automation, or tool binding is split, merged, renamed, retired, or materially revised;
9. materiality is uncertain.

Pure observation may open a source event before a proposed change exists. The source event and change request receive separate IDs and are linked.

---

# 3. Canonical Change Classes

| ID | `change_class` | Activates when | Mandatory first review |
|---|---|---|---|
| CIR-CC-01 | SOURCE_CORRECTION | Authoritative input is corrected, contradicted, withdrawn, expired, or replaced | Claims, decisions, evidence, applicability, and downstream reliance |
| CIR-CC-02 | ASSUMPTION_INVALIDATION | An assumption changes confidence or becomes false | Decisions, risks, requirements, outcomes, and earliest owning phase |
| CIR-CC-03 | DECISION_CHANGE | A proposed, approved, rejected, deferred, expired, reopened, or superseded decision changes meaning | Authority, conditions, baselines, gates, and dependents |
| CIR-CC-04 | SCOPE_BOUNDARY_CHANGE | User, market, region, language, platform, tenant, capability, release, or exclusion scope changes | GOV-009, requirements, profiles, evidence, and gates |
| CIR-CC-05 | STANDARD_APPLICABILITY_CHANGE | Standard/profile trigger or compliance applicability changes | GOV-001, GOV-009 propagation, controls, verification, and release evidence |
| CIR-CC-06 | REQUIREMENT_CHANGE | Functional, quality, data, integration, security, privacy, accessibility, audit, or acceptance obligation changes | Product truth, experience, design, architecture, implementation, and verification |
| CIR-CC-07 | EXPERIENCE_CHANGE | Journey, IA, state, interaction, content, recovery, channel, or localization behavior changes | Requirements, design, implementation, accessibility, and verification |
| CIR-CC-08 | DESIGN_CHANGE | Component, token, screen, specification, asset, responsive behavior, or design state changes | Experience, implementation, generated output, and verification |
| CIR-CC-09 | ARCHITECTURE_CHANGE | Decision, boundary, service, data, integration, trust, deployment, resilience, or technology structure changes | Requirements, readiness, implementation, migration, and operations |
| CIR-CC-10 | READINESS_PLAN_CHANGE | Work allocation, dependency, environment, migration, control, or execution plan changes | G5B, implementation scope, verification strategy, and ownership |
| CIR-CC-11 | IMPLEMENTATION_CHANGE | Code, infrastructure, policy-as-code, content, model, feature, or built behavior changes | Candidate identity, approved scope, verification, release, and operations |
| CIR-CC-12 | CONFIGURATION_ENVIRONMENT_CHANGE | Runtime configuration, secret identity, flag, target, region, network, or environment changes | Candidate equivalence, security, verification, release, and live identity |
| CIR-CC-13 | DATA_SCHEMA_MIGRATION_CHANGE | Schema, data contract, classification, retention, migration, backfill, or transformation changes | Data owners, compatibility, privacy, integrity, rollback, and evidence |
| CIR-CC-14 | DEPENDENCY_VENDOR_CHANGE | Library, API, service, supplier, license, support, SLA, or vendor lifecycle changes | Architecture, controls, compatibility, release, and continuity |
| CIR-CC-15 | EVIDENCE_INVALIDATION | Evidence no longer supports its claim, scope, version, period, or environment | Claim validity, verification, gates, release, and live assurance |
| CIR-CC-16 | VERIFICATION_FINDING_CHANGE | Test result, review finding, defect, coverage, exception, or residual gap changes | Requirement/design/architecture ownership, candidate, and G6B/G7 |
| CIR-CC-17 | RELEASE_ROLLOUT_CHANGE | Candidate, package, rollout, cohort, target, window, rollback, or authorization changes | G6B, G7, communications, monitoring, and live scope |
| CIR-CC-18 | LIVE_INCIDENT_CONTROL_CHANGE | Incident, problem, control failure, SLO breach, security event, or operational correction occurs | Containment, evidence, release/live state, risk, and earlier baselines |
| CIR-CC-19 | OUTCOME_EVOLUTION_CHANGE | Outcome, adoption, cost, quality, benefit, insight, evolution, or optimization decision changes | Assumptions, product strategy, lifecycle route, and G8 |
| CIR-CC-20 | OWNERSHIP_AUTHORITY_CHANGE | Owner, approver, segregation, delegation, access, or decision authority changes | Open approvals, evidence custody, acknowledgements, and continuity |
| CIR-CC-21 | LIFECYCLE_RETIREMENT_TRANSFER_CHANGE | Deprecation, sunset, archive, legal hold, transfer, or retirement state changes | Users, data, contracts, operations, evidence, successor, and G8 |
| CIR-CC-22 | FRAMEWORK_CONTRACT_SCHEMA_CHANGE | Product OS artifact IDs, contracts, vocabularies, methodologies, schemas, mappings, automation, or commands change | Catalog, contracts, gates, traceability, repositories, tools, and pilot |

A change may have one primary class and multiple secondary classes. The primary class identifies the earliest trigger; secondary classes preserve multi-domain consequences.

---

# 4. Change Intent

Intent answers why the delta is being made; class answers which governed truth changed. Preserve both.

~~~text
EDITORIAL
CORRECTIVE
ADAPTIVE
PREVENTIVE
EVOLUTIONARY
EMERGENCY
DEPRECATION
RETIREMENT
~~~

| Intent | Meaning |
|---|---|
| EDITORIAL | Improves presentation or expression without intended semantic change; must still pass the non-semantic test |
| CORRECTIVE | Removes a known defect, contradiction, nonconformance, or error |
| ADAPTIVE | Responds to a changed environment, dependency, market, platform, standard, contract, or operating context |
| PREVENTIVE | Reduces plausible future failure, risk, debt, or control weakness before harm occurs |
| EVOLUTIONARY | Adds, improves, optimizes, or materially changes intended capability or outcome |
| EMERGENCY | Contains or corrects active/imminent harm under the exceptional authority route |
| DEPRECATION | Announces and governs reduced future support before retirement or replacement |
| RETIREMENT | Removes, sunsets, transfers, archives, or terminates an object, capability, service, data, or obligation |

One primary intent is required. Secondary intents may be recorded when the response combines purposes. `EDITORIAL` does not imply M0; `EMERGENCY` does not imply approval; `RETIREMENT` does not erase data, evidence, contract, user, or successor obligations.

---

# 5. Change Identity

`change_id` is stable from initial registration through closure, rollback, supersession, and reopen.

~~~yaml
change_id:
change_revision:
title:
primary_change_class:
secondary_change_classes: []
primary_change_intent:
secondary_change_intents: []
source_event_refs: []
parent_change_ref:
related_change_refs: []
supersedes_change_ref:
duplicate_of_change_ref:
created_at:
created_by:
canonical_register_locator:
~~~

Identity rules:

1. one requested outcome with one independently decidable scope normally has one `change_id`;
2. separately approvable, deployable, reversible, or accountable scopes receive child changes;
3. revisions of the same request retain `change_id` and increment `change_revision`;
4. a materially different intended outcome creates a new change linked by supersession or relationship;
5. duplicate intake records are linked and consolidated without deleting history;
6. emergency and retrospective records share the same change identity where they describe the same event and response.

---

# 6. Exact Delta Contract

Every intake binds:

~~~yaml
changed_objects:
  - object_ref:
    current_version_ref:
    proposed_version_ref:
    current_state_digest:
    proposed_state_digest:
    delta_summary:
    effective_scope:
    intended_effective_at:
    compatibility_claim:
    reversibility_claim:
~~~

If a proposed object does not exist yet, use an explicit candidate identity. If current truth is unknown, record `UNKNOWN_CURRENT_STATE` and block approval until authority resolves or explicitly controls the uncertainty.

Labels such as “minor”, “refactor”, “documentation”, “configuration only”, “no behavior change”, and “routine” are claims requiring assessment; they do not lower materiality by themselves.

---

# 7. Compatibility and Reversibility

Compatibility classification:

~~~text
BACKWARD_COMPATIBLE
FORWARD_COMPATIBLE
CONDITIONALLY_COMPATIBLE
BREAKING
MIGRATION_REQUIRED
UNKNOWN
NOT_APPLICABLE
~~~

Reversibility classification:

~~~text
FULLY_REVERSIBLE
REVERSIBLE_WITH_REPAIR
FORWARD_RECOVERY_ONLY
IRREVERSIBLE
UNKNOWN
NOT_APPLICABLE
~~~

Both are assessed claims, not requester labels. They bind affected consumers, versions, data, configuration, environments, rollout state, time window, evidence, and authority. `UNKNOWN` raises review; `NOT_APPLICABLE` requires a positive reason.

---

# 8. Scope Intake

The requester records:

- included and excluded project/product scope;
- affected and deliberately unaffected populations;
- capability, journey, component, service, data, control, environment, target, release, and live partitions;
- geographic, jurisdictional, linguistic, accessibility, platform, contractual, and profile bounds;
- effective time, migration window, rollback window, and evidence period;
- unknown or inaccessible partitions.

Excluded scope requires rationale. A blanket “all” or “none” is invalid unless it is exact and reviewable.

---

# 9. Source Event Contract

~~~yaml
source_event_id:
event_type:
observed_at:
observed_by:
source_refs: []
evidence_refs: []
affected_claims: []
severity_or_urgency_signal:
known_scope:
uncertain_scope: []
immediate_safeguards: []
change_refs: []
~~~

A source event may create zero, one, or many changes. Closing a change does not erase the event or other required responses.

---

# 10. Urgency

~~~text
NORMAL
EXPEDITED
EMERGENCY
CRITICAL_CONTAINMENT
~~~

| Urgency | Meaning | Governance effect |
|---|---|---|
| NORMAL | Ordinary review and scheduling can protect the objective | Full normal route |
| EXPEDITED | Delay increases material cost or risk, but ordinary authority remains available | Shortened timebox; no semantic obligation removed |
| EMERGENCY | Immediate action is necessary to limit active harm or restore critical service | Pre-authorized emergency route plus retrospective assessment |
| CRITICAL_CONTAINMENT | Active severe harm requires the narrowest immediate containment | Containment before full remediation; enhanced logging, authority, review, and rollback |

Urgency changes sequence and timing, not the need for identity, history, evidence, authority, or retrospective closure.

---

# 11. Initial Triage

Triage determines:

1. whether the event is a duplicate, child, dependency, conflict, or new change;
2. primary/secondary change classes and intents;
3. current/proposed identity completeness;
4. immediate safety, security, privacy, accessibility, legal, contractual, financial, data, availability, or user-harm concerns;
5. preliminary affected domains, profiles, gates, releases, and live scopes;
6. urgency and containment route;
7. change owner and required impact owners;
8. whether GOV-008 traversal can start;
9. whether GOV-009 re-evaluation is immediately required;
10. which missing inputs block meaningful assessment.

Triage may not issue final materiality, no-impact, remediation, gate, risk, or closure decisions.

---

# 12. Non-Semantic Edit Test

An edit may be classified `M0_NON_SEMANTIC` only when all are true:

1. no governed claim, obligation, decision, rule, scope, authority, status, applicability, identity, dependency, acceptance, behavior, configuration, data, evidence, or lifecycle meaning changes;
2. stable IDs, anchors, parsing, links, generated outputs, schemas, signatures, and automation behavior remain valid;
3. no approved baseline, candidate, release, or live state is altered;
4. no receiver could reasonably act differently because of the edit;
5. an authorized reviewer can compare exact versions and evidence the conclusion.

Examples that may qualify after verification:

- spelling correction that does not change a defined term;
- formatting or whitespace normalization with identical rendered and parsed meaning;
- locator correction that restores the intended existing target without changing identity or authority.

If any test fails or is unknown, continue materiality assessment.

---

# 13. Intake Completeness States

~~~text
READY_FOR_TRAVERSAL
READY_WITH_DECLARED_GAPS
CONTAINMENT_ONLY
BLOCKED_IDENTITY
BLOCKED_SCOPE
BLOCKED_AUTHORITY
BLOCKED_ACCESS
DUPLICATE_LINKED
CANCELLED_BEFORE_ASSESSMENT
~~~

These are intake readiness states, not change lifecycle, materiality, or approval outcomes.

---

# 14. Deduplication and Relationship Rules

| Relationship | Use when | Required consequence |
|---|---|---|
| DUPLICATE_OF | Same delta and intended outcome already exist | Preserve intake history; route work to canonical change |
| PARENT_OF / CHILD_OF | One program change has independently governed scopes | Each child preserves scope, owner, decisions, evidence, and closure |
| DEPENDS_ON | One change cannot complete safely before another state exists | Record dependency condition and propagation on failure or delay |
| CONFLICTS_WITH | Two changes propose incompatible states or sequencing | Freeze conflicting approval/execution scope until authority resolves |
| SUPERSEDES | A new change replaces the intended outcome of an earlier one | Preserve old record and dispose remaining actions explicitly |
| COORDINATED_WITH | Changes share release, migration, verification, or communication needs | Maintain separate authority while coordinating execution |

---

# 15. Intake Handoff

The handoff to traversal and materiality includes:

~~~yaml
change_ref:
exact_delta_refs: []
effective_scope:
excluded_scope: []
primary_change_class:
secondary_change_classes: []
primary_change_intent:
secondary_change_intents: []
urgency:
compatibility_classification:
reversibility_classification:
source_refs: []
evidence_refs: []
known_risks: []
known_profiles: []
known_gates: []
known_releases_or_live_scopes: []
unknowns: []
access_constraints: []
change_owner:
required_impact_owners: []
intake_readiness:
~~~

The receiving assessor acknowledges receipt and records any missing condition. Receipt does not approve the change.

---

# 16. Intake Validation Rules

1. Every change has one stable ID and a canonical register locator.
2. Primary change class is one of CIR-CC-01 through CIR-CC-22 and primary intent is one of the eight controlled intents.
3. Current and proposed objects and versions resolve or carry an explicit blocking unknown.
4. Scope includes time and relevant product/project partitions.
5. Request, source event, and decision identities remain separate.
6. Urgency has rationale and authority where it activates an exceptional route.
7. Duplicate and related changes preserve history and independent scope.
8. Non-semantic classification passes every test in Section 12.
9. AI-generated intake content remains proposed and attributed.
10. Handoff exposes compatibility, reversibility, all gaps, access restrictions, and required owners.

---

# 17. Final Intake Principle

> **A change cannot be governed until the system knows exactly which truth is proposed to move, from which identity and scope to which new identity and scope, why it moved, who owns the response, and which uncertainty must travel with it into assessment.**
