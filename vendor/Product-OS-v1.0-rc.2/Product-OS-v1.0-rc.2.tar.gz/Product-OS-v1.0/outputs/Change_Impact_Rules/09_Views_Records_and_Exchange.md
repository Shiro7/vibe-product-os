# Product OS v1.0 — Views, Records, and Exchange

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-09
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
canonical_view_count: 12
governed_project_artifact: GOV-007
~~~

---

# 1. Purpose

This specification defines the logical record families, immutable event history, canonical operational views, exchange envelope, and portability rules needed to operate change impact across repositories and tools without creating competing truth.

---

# 2. Logical Record Families

| Record family | Canonical responsibility |
|---|---|
| Change record | Stable GOV-007 identity, request, class, lifecycle, owner, and final disposition |
| Source event | Observation, trigger, evidence, and relationship to one or more changes |
| Delta record | Exact current/proposed objects, versions, digests, scope, and compatibility/reversibility claims |
| Impact discovery | GOV-008 graph revision, candidate sets, paths, gaps, conflicts, blockers, and truncation |
| Impact assessment | Materiality, assessed sets, earliest phase, and authorized scope decisions |
| Object disposition | Per-object/claim/profile/evidence/baseline/release/live consequence and action |
| Gate re-entry | Prior decision, affected scope/checks/evidence, new review, and new decision identity |
| Action record | Objective, owner, due event, approved scope, execution, verification, and completion |
| Handoff/acknowledgement | Sender, receiver, scope, conditions, actions, challenge, and receipt |
| Closure decision | Reconciled final state, evidence, authority, residual obligations, and reopen triggers |

Physical systems may store these separately or together. Logical identifiers and relationships remain resolvable.

---

# 3. Event History

Every material transition emits an append-only event:

~~~yaml
change_event_id:
change_ref:
event_type:
object_or_record_ref:
prior_state:
new_state:
effective_scope:
actor:
actor_role:
authority_ref:
reason:
source_refs: []
evidence_refs: []
occurred_at:
recorded_at:
system_or_tool_ref:
correlation_ref:
supersedes_event_ref:
~~~

Event types include intake, triage, assessment, decision, approval, rejection, deferment, action assignment, execution, deviation, verification, failure, gate re-entry, release/live action, acknowledgement, closure, rollback, supersession, and reopen.

Events do not replace the current canonical projection; they make it reconstructable.

---

# 4. Revision and Time

Records preserve:

- change revision;
- impact-assessment revision;
- graph revision;
- artifact, candidate, configuration, release, and live versions;
- valid/effective time;
- recorded/system time;
- supersession and correction links.

A correction to recorded metadata preserves the erroneous history and creates a correcting event. Backdating a decision to conceal late approval is prohibited.

---

# 5. Canonical Views

## CIR-VIEW-01 — Change Portfolio

Shows active and historical changes by class, materiality, lifecycle, owner, profile, domain override, scope, gate, release/live effect, urgency, and age.

## CIR-VIEW-02 — Change Detail

Shows exact delta, source events, candidate and assessed sets, materiality, object dispositions, decisions, actions, evidence, gates, acknowledgements, closure, and history.

## CIR-VIEW-03 — Impact Coverage

Shows candidate, assessed, added, excluded, unresolved, affected, unaffected, stale, invalidated, superseded, newly required, and action-required sets with reconciliation totals.

## CIR-VIEW-04 — Artifact and Family Impact

Shows all changes affecting each GOV/INIT/DISC/BUS/PROD/REQ/EXP/DES/ARC/ENG/IMP/VRL/OPS artifact family, canonical owners, versions, dispositions, and pending work.

## CIR-VIEW-05 — Gate and Baseline Re-entry

Shows thirteen gates, prior decisions, impact dispositions, reopened scopes, preserved/failed checks, invalid evidence, new decisions, conditions, and downstream effects.

## CIR-VIEW-06 — Evidence and Verification Invalidation

Shows evidence/verification identity, supported claim, invalidated scope, reason, dependents, replacement owner, due event, and current fitness/status.

## CIR-VIEW-07 — Action and Ownership Queue

Shows actions by owner, status, dependency, due event, priority, blockers, gate/release effect, evidence expectation, and escalation.

## CIR-VIEW-08 — Handoff and Acknowledgement Queue

Shows sender/receiver, exact scope, conditions, actions, due events, pending/challenged/blocked acknowledgements, and newly discovered impact.

## CIR-VIEW-09 — Release and Live Change

Shows candidate, configuration, target, rollout cohort, authorized scope, deployed/live identity, containment, rollback, monitoring, production validation, incident, and outcome.

## CIR-VIEW-10 — Emergency and Exception

Shows active emergency/critical containment, authority, temporary expiry, actions, evidence, retrospective review, freeze exceptions, and lasting-change route.

## CIR-VIEW-11 — Closure and Residual Obligations

Shows closure readiness, failed checks, closure decision, residual obligations, owner, due event, condition/risk authority, evidence, breach action, and reopen trigger.

## CIR-VIEW-12 — Change History and Reopen

Shows immutable revisions, events, prior closures, reopen triggers, supersession, rollback, corrected metadata, and current canonical state.

All views are derived projections. They may filter by access but cannot silently change semantic results.

---

# 6. View Query Contract

Every reproducible view/query records:

~~~yaml
view_or_query_id:
view_type:
as_of_system_time:
as_of_valid_time:
change_scope:
profile_and_domain_filters: []
artifact_phase_gate_filters: []
release_live_filters: []
status_filters: []
access_context:
source_record_revisions: []
generated_at:
generated_by:
result_integrity_ref:
~~~

Different access contexts may redact content, but the view states that results are redacted or incomplete.

---

# 7. Exchange Envelope

~~~yaml
change_impact_exchange:
  specification: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
  exchange_id:
  exported_at:
  exported_by:
  source_system:
  source_revision:
  scope:
  access_classification:
  redactions: []
  change_records: []
  source_events: []
  delta_records: []
  impact_discovery_refs: []
  impact_assessments: []
  object_dispositions: []
  gate_reentries: []
  actions: []
  acknowledgements: []
  closure_decisions: []
  events: []
  referenced_artifacts: []
  referenced_evidence: []
  integrity:
    algorithm:
    digest:
  validation_result_ref:
~~~

The logical envelope may use JSON, YAML, relational tables, graph structures, or APIs. Controlled values, IDs, scope, time, and links round-trip without semantic loss.

---

# 8. Import Rules

An importer must:

1. validate specification version and compatibility;
2. verify envelope integrity where supplied;
3. preserve source identity, timestamps, authority, and history;
4. resolve or quarantine duplicate/conflicting IDs;
5. map controlled vocabularies explicitly;
6. reject unknown mandatory values or store them as quarantined extensions;
7. preserve redaction and access constraints;
8. validate references before making records active;
9. never convert imported proposal to approval;
10. emit an import reconciliation report.

---

# 9. Export Rules

An exporter must:

- state exact scope and omitted/redacted content;
- include referenced record identities or stable locators;
- preserve lifecycle and decision-state separation;
- include current state plus sufficient events to reconstruct required history;
- preserve invalidated, rejected, rolled-back, superseded, and reopened records;
- avoid exporting secrets or restricted evidence content outside authority;
- identify stale snapshots and source revision.

---

# 10. Tool Mapping Boundary

Typical physical homes may include:

| Logical content | Possible physical representation |
|---|---|
| GOV-007 record | Governed Markdown/YAML, database, work-management object, or change platform |
| Delta | Git diff/commit, design version, schema migration, configuration revision, document version, or decision revision |
| Candidate impact | Graph service, normalized trace matrix, or governed traversal export |
| Actions | Repository issues, work items, runbooks, migration jobs, or operational tasks |
| Evidence | Test/CI system, review record, signed report, observability store, controlled repository, or evidence platform |
| Approval | Decision system, signed record, protected workflow, or governed artifact |
| Release/live identity | Build registry, deployment platform, configuration service, runtime inventory, or release record |

Tool mappings are locators and implementations. Canonical ownership and authority come from Product OS governance.

---

# 11. Federated Operation

When records span systems:

- one canonical locator exists for each logical record;
- correlation IDs link the same change across tools;
- version synchronization and failure handling are explicit;
- derived caches state freshness and source revision;
- deletions use governed retirement/tombstones where history must remain;
- access-control differences cannot create silent semantic forks;
- periodic reconciliation detects orphan tasks, approvals, evidence, candidates, and deployments.

---

# 12. Notification Contract

A notification includes:

~~~yaml
notification_id:
change_ref:
event_ref:
recipient:
reason:
required_action:
due_event:
scope:
conditions_or_restrictions: []
canonical_record_locator:
sent_at:
delivery_status:
acknowledgement_required:
~~~

Notification delivery is not acknowledgement, and acknowledgement is not action completion.

---

# 13. Retention and Deletion

Preserve records according to GOV-001, applicable law/contract/standards, audit, incident, security, privacy, evidence, and lifecycle obligations.

Deletion or redaction must not destroy required proof of:

- who requested, decided, acted, verified, released, acknowledged, or closed;
- which scope and version were involved;
- why a prior truth was invalidated, superseded, rejected, rolled back, or reopened;
- which residual obligations remain.

Where personal or sensitive data must be removed, retain minimal governed pseudonymous identity and decision integrity where lawful.

---

# 14. Final Views and Exchange Principle

> **A change may live across many tools, but it has one reconstructable logical history: every view is a versioned projection, every exchange preserves identity and authority, and no import, export, dashboard, or notification may turn proposal into approval or absence into closure.**
