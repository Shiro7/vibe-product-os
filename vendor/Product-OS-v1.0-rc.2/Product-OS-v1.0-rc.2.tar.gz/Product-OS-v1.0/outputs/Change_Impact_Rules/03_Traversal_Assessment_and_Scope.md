# Product OS v1.0 — Traversal Assessment and Scope

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-03
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
consumes: TRACEABILITY-GRAPH-IMPACT-DISCOVERY
artifact_family_count: 13
gate_count: 13
~~~

---

# 1. Purpose

This specification defines how authorized assessors consume a reproducible `GOV-008` candidate impact set, test every candidate and uncertainty branch, add missing governed relationships, determine actual affected scope, and select the earliest affected lifecycle point.

The graph discovers possible consequence. This assessment decides consequence within valid authority.

---

# 2. Required Traversal Input

The assessment consumes the record defined by the Traceability Graph:

~~~yaml
impact_discovery_id:
trigger_ref:
change_ref:
old_node_or_trace_refs: []
new_node_or_trace_refs: []
graph_revision:
evaluated_scope:
as_of_valid_time:
traversal_policy:
confirmed_candidate_nodes: []
uncertain_candidate_nodes: []
candidate_trace_refs: []
candidate_artifacts: []
candidate_phases: []
candidate_baselines: []
candidate_gates: []
candidate_evidence: []
candidate_conditions_exceptions_risks: []
candidate_releases_targets: []
candidate_live_scope: []
candidate_earliest_phase:
gap_refs: []
conflict_refs: []
access_blockers: []
truncated_branches: []
path_refs: []
generated_by:
generated_at:
review_required:
change_impact_handoff_ref:
~~~

The assessor rejects or supplements an input whose graph revision, scope, valid time, traversal policy, changed identity, or path evidence cannot be reproduced.

---

# 3. Required Traversal Policies

Select every policy relevant to the change:

- direct downstream realization;
- transitive downstream realization;
- upstream origin and authority;
- dependency and inverse-dependency components;
- governance, standards, applicability, condition, exception, waiver, and risk;
- evidence and verification reliance;
- baseline and gate inclusion;
- candidate, configuration, migration, environment, target, release, and live deployment;
- incident, control, measure, outcome, evolution, transfer, sunset, and retirement;
- supersession, invalidation, and historical comparison;
- conflict, gap, orphan, access, and unknown relationship review.

One traversal query may implement several policies, but the record states which semantic policies were covered.

---

# 4. Candidate-to-Assessed Set Algorithm

~~~text
1. Verify changed identities, versions, scope, valid time, and graph revision.
2. Reproduce or independently review every required traversal policy.
3. Partition confirmed and uncertain candidates by family, phase, profile, baseline, gate, release, target, live scope, and evidence claim.
4. Assign a competent impact owner to every partition.
5. Evaluate each candidate’s path, changed meaning, scope intersection, authority, evidence, and temporal validity.
6. Record an affected-object disposition or explicit unresolved state.
7. Review gaps, conflicts, access blockers, and truncated branches against mandatory relationship obligations.
8. Add assessor-discovered objects and create or update GOV-008 relationships/gaps.
9. Re-run traversal when graph corrections can change the candidate set.
10. Determine actual earliest affected owning phase, baseline, and gate.
11. Reconcile candidate set, assessed set, added set, excluded set, and unresolved set.
12. Hand off exact dispositions to registry, evidence, gate, action, and closure processes.
~~~

---

# 5. Candidate Assessment Record

~~~yaml
candidate_assessment_id:
impact_assessment_ref:
candidate_object_ref:
candidate_object_version:
candidate_status:
supporting_path_refs: []
scope_intersection:
changed_meaning_dependency:
source_refs: []
evidence_refs: []
assessor:
assessor_authority:
assessment_result:
object_disposition:
extent:
rationale:
required_actions: []
registry_action_ref:
evidence_actions: []
gate_or_baseline_actions: []
receiver_refs: []
reviewed_at:
reopen_triggers: []
~~~

`candidate_status` preserves graph discovery semantics. `object_disposition` records the authorized change assessment. They must not share one field.

---

# 6. Set Reconciliation

Every assessment publishes:

~~~yaml
candidate_set_refs: []
assessed_candidate_set: []
assessor_added_set: []
authorized_excluded_set: []
unresolved_set: []
affected_set: []
unaffected_set: []
invalidated_set: []
stale_set: []
superseded_set: []
newly_required_set: []
action_required_set: []
~~~

Rules:

1. `candidate = assessed + authorized_excluded + unresolved` for exact input revision;
2. assessor-added objects are not hidden inside candidate counts;
3. exclusions require rationale, evidence, authority, and scope;
4. unresolved candidates block `NO_IMPACT` and may block approval, gate, release, or closure;
5. graph gaps discovered by assessment are returned to GOV-008 with owners and due events.

---

# 7. Scope Intersection

Impact exists only for the valid intersection of changed scope and dependent scope, but uncertainty about scope is preserved.

~~~text
assessed_extent =
  changed_object_scope
  ∩ relationship_scope
  ∩ dependent_object_scope
  ∩ active_profile_scope
  ∩ valid_time
  ∩ release_or_live_scope where applicable
~~~

An empty verified intersection may support `UNAFFECTED` for the object. A missing or ambiguous scope field does not create an empty intersection.

---

# 8. Artifact-Family Partition

| Family | Primary impact questions |
|---|---|
| GOV | Constitution, registry, decision, risk, assumption, question, change, graph, or standards applicability truth affected? |
| INIT | Project identity, intake, profile, routing, engagement, source, initial governance, or G0 readiness affected? |
| DISC | Problem, stakeholder, research, current state, cause, outcome, assumption, or G1 truth affected? |
| BUS | Business capability, process, rule, control, information, ownership, risk, priority, or G2 truth affected? |
| PROD | Product boundary, capability, module, policy, state, platform, market, journey responsibility, release scope, or G3A truth affected? |
| REQ | Requirement, acceptance, quality, data, integration, security, privacy, accessibility, audit, or G3B truth affected? |
| EXP | Journey, IA, navigation, flow, state, interaction, content, recovery, language, accessibility, or G4A truth affected? |
| DES | Component, token, screen, pattern, asset, responsive state, localization, generated output, or G4B truth affected? |
| ARC | Driver, decision, boundary, service, data, trust, integration, deployment, resilience, observability, or G5A truth affected? |
| ENG | Work allocation, readiness, dependency, environment, migration, control, verification plan, evidence plan, or G5B truth affected? |
| IMP | Built behavior, candidate, code, infrastructure, configuration, data migration, deviation, implementation evidence, or G6A truth affected? |
| VRL | Verification target/result, defect, exception, coverage, candidate evidence, release decision, rollout, production validation, or G6B/G7 truth affected? |
| OPS | Live identity, SLO, incident, problem, support, control health, measure, outcome, evolution, transfer, sunset, retirement, or G8 truth affected? |

Every activated family has an owner and an explicit partition result; family omission requires evidence.

---

# 9. Gate Candidate Partition

| Gate | Candidate impact boundary |
|---|---|
| G0 | Intake identity, route, preliminary profile, sources, immediate risk, and initialization controls |
| G1 | Problem, users, current state, causes, outcomes, discovery evidence, assumptions, and questions |
| G2 | Business capabilities, rules, controls, information, ownership, risks, priorities, and obligations |
| G3A | Product boundary, capability, modules, policy, platforms, markets, and release scope |
| G3B | Atomic requirements, acceptance, quality, data, integration, controls, and traceability |
| G4A | Journeys, states, IA, flows, interaction rules, content, recovery, accessibility, and localization |
| G4B | Design system, screens, components, tokens, states, assets, responsive behavior, and handoff |
| G5A | Architecture decisions, data, trust, integration, deployment, resilience, recovery, and observability |
| G5B | Executable work, dependencies, environments, migrations, controls, test/evidence plans, and readiness |
| G6A | Exact implementation candidate, configuration, migrations, evidence, deviations, and baseline identity |
| G6B | Candidate-bound verification, coverage, defects, exceptions, residual gaps, and VBL |
| G7 | Release candidate, scope, authorization, conditions, targets, rollout, rollback, and communication |
| G8 | Live scope, sustainability, incidents, controls, outcomes, evolution, transfer, sunset, and retirement |

Adjacency produces a candidate for review, not automatic gate invalidation.

---

# 10. Earliest Affected Lifecycle Point

Determine the earliest actual affected point by:

1. identifying each affected object’s canonical owning artifact and phase;
2. distinguishing current approved meaning from historical or out-of-scope paths;
3. locating the earliest owning decision whose meaning or evidence is materially changed;
4. retaining competing candidates while conflict or uncertainty exists;
5. selecting the earliest point authorized owners confirm as affected;
6. recording why earlier candidate phases remain unaffected;
7. routing the minimum required gate re-entry without skipping downstream consequences.

The graph’s `candidate_earliest_phase` is evidence, not the final decision.

---

# 11. Gap and Missing-Path Assessment

For each gap, record:

~~~yaml
gap_ref:
required_relationship_obligation:
unknown_dependency_scope:
plausible_affected_family_or_gate:
reason_missing:
owner:
due_event:
temporary_restriction:
resolution_action:
no_impact_prohibited: true
~~~

A manual domain assessment may bound a gap only when its scope, source, evidence, competence, authority, and reopen trigger are explicit. The graph must still record the missing relationship.

---

# 12. Conflict and Dissent

When candidate paths or assessors conflict:

1. preserve every assertion and source;
2. identify canonical content and decision owners;
3. test scope and version differences before treating views as true disagreement;
4. route authority or expert resolution;
5. apply the more protective temporary restriction where harm is plausible;
6. prohibit closure until the conflict is resolved or formally dispositioned by valid authority;
7. update GOV-008 status and evidence without overwriting history.

Majority vote does not replace defined authority.

---

# 13. Re-Traversal Triggers

Re-run discovery when:

- changed identity, version, or scope changes;
- the graph is corrected or a gap/conflict resolves;
- an affected owner adds an object or relationship;
- GOV-009 applicability changes;
- a gate, baseline, candidate, release, deployment, incident, or live scope changes;
- evidence becomes invalid or a new source appears;
- remediation changes the proposed solution materially;
- assessment exceeds its validity period.

The new result receives a new `impact_discovery_id` and is reconciled to prior sets.

---

# 14. Traversal Assessment Exit Criteria

Traversal assessment is complete only when:

1. required policies ran on exact graph revision and scope;
2. every candidate has a result or explicit unresolved state;
3. every added object and graph gap is registered;
4. family, phase, profile, baseline, gate, release, live, evidence, and registry partitions reconcile;
5. earliest affected phase has authority and rationale;
6. no omission relies on absence of a discovered edge;
7. required receivers and action owners are identified;
8. result can be reproduced from stored paths and evidence.

---

# 15. Final Traversal Assessment Principle

> **The candidate graph set becomes an impact decision only after every path, scope intersection, gap, conflict, and added dependency has an accountable assessment—without letting graph silence masquerade as safety or graph adjacency masquerade as invalidation.**
