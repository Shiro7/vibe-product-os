# Product OS v1.0 — Shared Change Impact Contract

~~~yaml
contract_id: SHARED-CHANGE-IMPACT-CONTRACT
contract_version: 0.1.0
contract_status: WORKING_DRAFT
asset_class: PRODUCT_OS_FRAMEWORK_ASSET
governed_project_artifact: GOV-007
inherits: CORE-ARTIFACT-STANDARD@0.2.0
consumes: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
applies_to: ALL_MATERIAL_PROJECT_AND_FRAMEWORK_CHANGES
profiles: [P1, P2, P3]
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
~~~

---

# 1. Purpose

This contract defines the common rules inherited by every Product OS change-impact assessment. It governs the transition from a detected or proposed delta to an authorized, verified, acknowledged, historically preserved response.

It specializes the project-level [GOV-007 Change Register contract](../Core_Artifact_Contracts/governance-family/07_GOV-007_Change_Register.md) without replacing it.

---

# 2. Scope

The contract activates when a change may alter:

- governing rules or authority;
- source truth or evidence fitness;
- scope, boundary, users, markets, platforms, languages, regions, or data;
- standards applicability, risk, control, privacy, security, accessibility, or audit meaning;
- business, product, requirement, experience, design, architecture, readiness, implementation, verification, release, operation, evolution, or lifecycle truth;
- a registered artifact’s meaning, identity, version, dependencies, status, or disposition;
- a baseline, gate decision, condition, exception, waiver, target, configuration, candidate, or live scope;
- Product OS framework vocabulary, contract, schema, repository, automation, mapping, or methodology.

Purely non-semantic edits may stay in native version history only after the non-semantic test in this library is satisfied. Uncertainty activates registration and assessment.

---

# 3. Normative Terms

`MUST`, `MUST NOT`, `REQUIRED`, `SHALL`, and `SHALL NOT` are mandatory.

`SHOULD` describes the normal operating rule. Deviation requires rationale and authority proportionate to risk.

`MAY` is optional within the stated boundary.

---

# 4. Ownership and Decision Rights

| Role | Required responsibility | Prohibited substitution |
|---|---|---|
| Register owner | Preserve GOV-007 identity, lifecycle, integrity, history, and closure routing | Cannot silently decide domain impact for every owner |
| Requester / source owner | State trigger, reason, current state, proposed state, intended outcome, and sources | Cannot treat request submission as approval |
| Change owner | Coordinate triage, traversal, assessment, actions, verification, acknowledgement, and closure | Cannot self-approve outside assigned authority |
| Impact assessor | Decide impact for assigned scope from paths, sources, evidence, and expertise | Cannot claim no impact for unassessed or inaccessible scope |
| Artifact / domain owner | Decide object disposition and required correction within owned authority | Cannot overrule gate or release authority |
| Gate / baseline authority | Decide validity, reopen, re-entry, conditions, and new gate outcome | Cannot rewrite historical decisions in place |
| Risk / exception authority | Accept, reject, constrain, or expire risk and exception treatment | Cannot substitute for implementation or verification evidence |
| Implementer | Execute only authorized scope and record exact implementation identity | Cannot self-attest independent verification where segregation is required |
| Verifier | Verify exact response, target, version, and evidence expectations | Cannot expand approved change scope silently |
| Receiving owner | Acknowledge receipt, understood constraints, actions, and due events | Acknowledgement is not approval of upstream quality |
| Closure authority | Confirm all mandatory dimensions are dispositioned | Cannot close missing impact, actions, evidence, or acknowledgements |
| AI / automation | Detect, compare, traverse, cluster, draft, validate deterministic rules, and surface gaps | Cannot approve materiality, `NO_IMPACT`, risk, gate reopen, release, or closure |

---

# 5. Canonical Change Lifecycle

The GOV-007 lifecycle is retained:

~~~text
PROPOSED
TRIAGED
IMPACT_ASSESSED
APPROVED
REJECTED
DEFERRED
IN_PROGRESS
IMPLEMENTED
VERIFIED
CLOSED
ROLLED_BACK
SUPERSEDED
~~~

`REOPENED` is recorded as a lifecycle event against a previously closed or dispositioned record. The record then returns to the earliest valid workflow state required by the trigger, normally `TRIAGED`, `IN_PROGRESS`, or `IMPACT_ASSESSED` with a new assessment revision.

Rules:

1. lifecycle transitions record actor, authority, time, reason, evidence, and from/to state;
2. rejected, deferred, rolled-back, and superseded records remain discoverable;
3. execution and verification may use parallel sub-statuses, but they do not erase the canonical lifecycle;
4. an emergency action may begin before ordinary approval only under the emergency contract;
5. `CLOSED` is impossible while mandatory actions or acknowledgements remain open.

---

# 6. Change-Impact Status

The shared Core Artifact vocabulary is authoritative:

~~~text
NOT_ASSESSED
NO_IMPACT
REVIEW_REQUIRED
IMPACT_CONFIRMED
REMEDIATION_REQUIRED
DISPOSITIONED
~~~

| Status | Meaning |
|---|---|
| NOT_ASSESSED | A trigger exists but authorized assessment has not started or is not sufficient |
| REVIEW_REQUIRED | One or more exact scopes require human or authorized domain review |
| IMPACT_CONFIRMED | Material effect exists and its assessed scope is explicit |
| REMEDIATION_REQUIRED | Confirmed effect requires one or more controlled actions before acceptable disposition |
| DISPOSITIONED | Every required assessed scope has an authorized outcome, including residual obligations |
| NO_IMPACT | Authorized assessment proves that the evaluated material candidate causes no governed downstream effect for exact scope and versions |

`NO_IMPACT` and `DISPOSITIONED` are not synonyms. `NO_IMPACT` proves absence of governed effect within an exact assessed boundary. `DISPOSITIONED` may include confirmed impact that was corrected, accepted by proper authority, rejected, deferred, rolled back, or superseded.

---

# 7. Status Separation

The following remain independent fields:

~~~yaml
change_lifecycle_status:
materiality_level:
change_impact_status:
object_dispositions: []
registry_lifecycle_actions: []
graph_edge_actions: []
gate_impact_dispositions: []
gate_decision_outcomes: []
verification_status:
evidence_fitness_results: []
closure_status:
~~~

No aggregate status may hide a blocking child state.

---

# 8. Canonical Assessment Identity

Each material assessment is immutable by revision identity:

~~~yaml
impact_assessment_id:
change_id:
assessment_revision:
assessment_status:
assessment_scope:
changed_object_refs: []
from_version_refs: []
to_version_refs: []
graph_revision:
impact_discovery_refs: []
assessed_at:
assessors: []
decision_authority:
supersedes_assessment_ref:
~~~

A reassessment creates a new revision and preserves the old assessment, rationale, evidence, actions, and decisions.

---

# 9. Minimum Integrated Change-Impact Record

~~~yaml
change_id:
title:
change_class:
change_intent:
source_event_refs: []
reason:
current_state_refs: []
proposed_state_refs: []
intended_outcome:
effective_scope:
excluded_scope: []
urgency:
compatibility_classification:
reversibility_classification:
requester:
change_owner:
source_refs: []
evidence_refs: []
risk_refs: []
decision_refs: []
gov_001_rules: []
gov_002_entries: []
gov_008_impact_discovery_refs: []
gov_009_entries: []
materiality_level:
materiality_rationale:
assessment_status:
assessed_candidate_objects: []
affected_object_dispositions: []
affected_profiles: []
affected_phases: []
earliest_affected_phase:
affected_baselines: []
affected_gates: []
affected_releases: []
affected_live_scopes: []
registry_lifecycle_actions: []
graph_actions: []
verification_invalidated: []
evidence_invalidated: []
compatibility_plan_ref:
migration_plan_ref:
rollback_plan_ref:
required_actions: []
owners: []
due_events: []
decision_authority:
decision_status:
approved_scope:
conditions: []
implementation_refs: []
verification_refs: []
release_refs: []
outcome_refs: []
downstream_acknowledgements: []
residual_obligations: []
final_disposition:
closure_evidence: []
reopen_triggers: []
created_at:
updated_at:
closed_at:
~~~

Physical schemas may split this logical record across governed systems. Stable IDs, one canonical logical view, and referential integrity remain mandatory.

---

# 10. Assessment Invariants

1. The changed object, old version, new or proposed version, and effective scope resolve.
2. Every candidate object is assessed or explicitly retained as unresolved.
3. Every omitted graph candidate has an authorized exclusion reason and evidence.
4. Additional objects discovered by assessors are added to GOV-008 or recorded as graph gaps.
5. Every `UNAFFECTED` or whole-assessment `NO_IMPACT` decision has positive rationale and evidence.
6. Unavailable or restricted evidence produces uncertainty, not an unaffected decision.
7. Every confirmed impact receives an owner, action or authorized disposition, and due event.
8. Invalidated verification and evidence are identified by exact identity and claim/scope.
9. Gate and baseline decisions are made by their defined authorities.
10. Closure requires receiving acknowledgement where downstream reliance exists.

---

# 11. Scope Contract

Every assessment scope binds as applicable:

- project, product, tenant, legal entity, or organization;
- user, role, population, market, region, jurisdiction, language, and channel;
- capability, module, journey, feature, requirement, component, service, API, data set, and control;
- environment, platform, configuration, candidate, release, rollout cohort, and live instance;
- effective time, evidence period, and historical range;
- applicable profile and domain override;
- included, excluded, inaccessible, uncertain, and deferred partitions.

An empty or global scope is prohibited unless the object is genuinely global and authority confirms it.

---

# 12. `NO_IMPACT` Contract

`NO_IMPACT` requires:

1. exact changed identity and versions;
2. exact assessed scope and time;
3. completed candidate traversal for all required policies;
4. explicit treatment of missing, uncertain, conflicted, inaccessible, and truncated branches;
5. object-by-object rationale for all plausible governed dependents;
6. current sources and evidence sufficient for the claim;
7. named assessor and valid decision authority;
8. assessment timestamp and graph revision;
9. no unresolved mandatory review;
10. reopen triggers.

The following can never independently prove `NO_IMPACT`:

- no ticket was filed;
- no edge was discovered;
- the diff is small;
- tests passed;
- a release succeeded;
- an AI found nothing;
- the same owner changed and reviewed the object;
- the change is labeled refactor, documentation, configuration, or emergency.

---

# 13. Reopen Contract

Reopen the assessment when:

- the change, target, or effective scope differs from what was assessed;
- a source is corrected, contradicted, withdrawn, expires, or changes authority;
- a graph gap closes or a new dependency appears;
- an impact owner disagrees or cannot acknowledge the handoff;
- verification fails or required evidence becomes invalid;
- migration, rollback, rollout, or production behavior differs materially;
- a gate, baseline, standard applicability, risk, condition, exception, waiver, vendor, control, or live state changes;
- a residual obligation expires or breaches its bound;
- an incident or outcome contradicts closure assumptions;
- the governing contract version changes materially.

Reopen preserves prior history and creates a new assessment revision.

---

# 14. Evidence Boundary

This contract requires evidence identity, supported claim, scope, version, producer, time, integrity reference where required, review status, and invalidation result.

The [Source / Evidence Model](../Source_Evidence_Model/Source_Evidence_Model_Index.md) owns detailed evidence type, authority, fitness, custody, authenticity, retention, confidentiality, redaction, and sufficiency rules. No implementation may weaken those semantics or treat file existence as proof.

---

# 15. Gate Boundary

This library may recommend and route gate review, but only the gate authority may:

- preserve prior validity for exact unaffected scope;
- mark a gate `REVIEW_REQUIRED`, `PARTIALLY_INVALIDATED`, `FULLY_INVALIDATED`, or `SUPERSEDED`;
- issue a new PASS, authorization, or G8 outcome;
- accept conditions or determine re-entry completeness.

Historical gate decisions are immutable. Reopen creates a new decision cycle linked to the prior decision.

---

# 16. AI and Automation Boundary

The complete governing semantics are defined by the [AI Operating Specification](../AI_Operating_Specification/AI_Operating_Specification_Index.md). This section retains the change-impact-specific decision boundary.

Automation may:

- detect deltas and bind versions;
- invoke graph traversal;
- validate record completeness and allowed transitions;
- calculate deterministic scope intersection;
- compare candidate and assessed sets;
- detect missing owners, due events, acknowledgements, invalidation links, and stale evidence;
- generate queues, views, metrics, and alerts.

AI may also summarize paths, cluster similar objects, propose materiality, draft rationales, recommend actions, and explain conflicts when proposed content remains visibly unapproved.

Neither AI nor deterministic automation may decide materiality, `NO_IMPACT`, residual risk acceptance, standards applicability, exception, gate reopen, release, lifecycle disposition, or closure where human or accountable authority is required.

---

# 17. Profile and Domain Override

P1, P2, and P3 change packaging, assurance depth, independence, custody, and automation—not the semantic obligations.

Security, privacy, accessibility, safety, financial, regulated-data, high-availability, contractual, or jurisdictional triggers may raise affected scope to a stronger domain override. The override records reason, authority, exact scope, added checks, evidence, and exit/reopen conditions.

---

# 18. Confidentiality and Access

Restricted source or evidence does not remove impact obligations.

The record may expose a redacted locator and authorized-access route, while preserving:

- existence and identity of the restricted item;
- classification and access owner;
- supported or affected claim;
- review status;
- whether inaccessible content blocks assessment or closure.

Access denial yields `UNRESOLVED_ACCESS`, never automatic `UNAFFECTED`.

---

# 19. Tool Boundary

No tool becomes authoritative merely because it stores a change ticket, code diff, graph, approval, test, deployment, incident, or dashboard.

Physical mappings must preserve:

- stable identity and version;
- canonical owner;
- authority and signature/approval references where required;
- state separation;
- immutable history;
- evidence and graph references;
- scope and time;
- round-trip-safe controlled vocabularies.

---

# 20. Contract Change Control

Changing this shared contract requires:

1. proposed version and rationale;
2. affected rule and vocabulary IDs;
3. compatibility classification;
4. impact on all 281 artifact contracts and the 13 gates;
5. impact on GOV-002, GOV-007, GOV-008, GOV-009, methodologies, schemas, repositories, automation, commands, mappings, and pilot;
6. migration and rollback instructions;
7. Product OS approving authority;
8. changelog and baseline decision.

---

# 21. Final Shared Principle

> **A change-impact record is valid only when it separates discovery from judgment, judgment from authority, authority from execution, execution from verification, and verification from closure—while binding every step to exact scope, versions, evidence, ownership, and preserved history.**
