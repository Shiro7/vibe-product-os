# Product OS v1.0 — Materiality and Impact Classification

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-02
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
materiality_level_count: 6
governed_project_artifact: GOV-007
~~~

---

# 1. Purpose

This specification determines whether changed meaning is material, how far governance must extend, how uncertainty affects the decision, and what evidence is required for `NO_IMPACT` or confirmed impact.

Materiality measures governed consequence, not edit size, implementation effort, perceived simplicity, or requester seniority.

---

# 2. Materiality Dimensions

Assess every plausible change against:

| Dimension | Decision question |
|---|---|
| Semantic meaning | Can a reasonable consumer interpret or act on the object differently? |
| Scope | Does included/excluded user, market, platform, region, language, data, environment, release, or time change? |
| Authority | Does owner, approver, delegation, segregation, policy, standard, contract, or exception authority change? |
| Dependency | Does an upstream/downstream object need review, update, re-verification, or new evidence? |
| Baseline and gate validity | Could an approved decision or its evidence no longer support the exact scope? |
| Candidate and release identity | Does built, verified, authorized, deployed, or live identity change? |
| User and operational outcome | Can behavior, access, safety, security, privacy, accessibility, reliability, cost, support, or outcome change? |
| Compatibility and migration | Does an existing consumer, dataset, integration, configuration, or workflow need adaptation? |
| Evidence fitness | Does evidence stop proving the same claim, version, environment, population, or period? |
| Reversibility and blast radius | Is rollback difficult, incomplete, delayed, or unable to restore prior truth? |
| Uncertainty | Are paths, sources, access, scope, or consequences missing, conflicted, or truncated? |

The strongest applicable dimension sets the minimum materiality level. Authorized domain rules may raise it.

---

# 3. Canonical Materiality Levels

| Level | Name | Definition | Minimum governance response |
|---|---|---|---|
| M0 | NON_SEMANTIC | Exact versions differ but governed meaning, identity, scope, authority, behavior, evidence, automation, baseline, candidate, and live state do not | Evidence the comparison; native history may suffice unless a GOV-007 record already exists or policy requires registration |
| M1 | LOCAL_SEMANTIC | Meaning changes within one owned object and exact local scope, with no confirmed external dependent, baseline, gate, release, or live effect | Register, assess graph candidates, update/review the object, verify locally, and obtain owner disposition |
| M2 | CROSS_ARTIFACT | Meaning affects or may affect multiple artifacts, domains, profiles, evidence items, controls, implementations, or receivers without yet invalidating a gate/baseline | Full GOV-007 assessment, named impact owners, affected-object actions, evidence review, and acknowledgements |
| M3 | BASELINE_OR_GATE | An approved baseline, gate decision, condition, exception, waiver, authority, or gate-critical evidence may no longer be relied upon | Gate/baseline impact decision, exact re-entry, proportional downstream review, re-verification, and new decision cycle where required |
| M4 | RELEASE_OR_LIVE | Verified candidate, release authorization, rollout, production configuration, deployed scope, live service, operational control, user population, or outcome is affected | G6B/G7/G8 and live authority involvement, containment/rollback/migration/monitoring, and production evidence |
| M5 | CRITICAL_OR_MANDATORY | Active or imminent severe harm, mandatory legal/contractual/standards breach, critical security/privacy/safety/control failure, irreversible data harm, or Product OS-wide incompatible framework change exists | Immediate escalation or containment, strongest applicable authority and segregation, formal assurance, retrospective completion, and executive/regulatory route where applicable |

Levels are not effort estimates. A one-line permission change can be M5; a large generated formatting diff can be M0.

---

# 4. Level Selection Rules

1. Begin at M0 and test upward; do not begin from requester labels.
2. Select the highest level supported by any included or unresolved material branch.
3. Uncertainty that could conceal a higher-level consequence prevents assignment below that level until resolved or controlled by valid authority.
4. Domain overrides may raise treatment without changing the semantic level; when the distinction matters, record both `materiality_level` and `assurance_treatment`.
5. Partitioned scope may contain different levels. The whole-change routing level is the maximum; each partition retains its own assessment.
6. A change may fall after assessment when evidence disproves a plausible consequence, but the decision and evidence remain in history.
7. Materiality changes create a new assessment revision.

---

# 5. Mandatory Escalation Triggers

At least M3 applies when:

- an approved baseline’s meaning, authority, conditions, or evidence changes;
- a gate-critical artifact becomes stale or invalidated;
- standards applicability adds or removes a mandatory obligation;
- an accepted exception, waiver, risk, or condition changes scope or expires;
- segregation or decision authority changes for an active approval;
- the implementation candidate no longer matches the approved baseline.

At least M4 applies when:

- G6B evidence, G7 scope, deployment target, rollout population, production configuration, or live control changes materially;
- rollback, migration, data integrity, availability, support, or user communication must change;
- a production incident or outcome contradicts release assumptions.

M5 applies when a critical or mandatory trigger in its definition is substantiated or cannot safely be excluded within the required response time.

---

# 6. Assessment Workflow

~~~text
1. Bind exact delta, scope, source event, and authority.
2. Retrieve the GOV-008 candidate impact set and path evidence.
3. Test semantic meaning and every materiality dimension.
4. Partition scope where consequences differ.
5. Record confirmed, plausible, uncertain, excluded, and inaccessible branches.
6. Select provisional materiality level and required reviewers.
7. Obtain domain assessments and resolve contradictions.
8. Decide final materiality for exact assessment revision.
9. Route affected-object, evidence, gate, action, and closure work.
10. Reassess if execution or new evidence differs from assessed assumptions.
~~~

---

# 7. Assessment Evidence

Minimum evidence includes:

- exact old/new comparison and version identities;
- graph revision, traversal policy, candidate nodes, paths, gaps, conflicts, access blockers, and truncation;
- authoritative source and decision references;
- scope intersection analysis;
- domain-owner rationale;
- evidence and verification dependency review;
- baseline, gate, release, and live identity review where plausible;
- compatibility, migration, rollback, reversibility, and monitoring analysis where applicable;
- dissent, unresolved uncertainty, conditions, and expiry/reopen triggers.

Passing tests support a conclusion only for their exact candidate, environment, scope, data, and time.

---

# 8. Whole-Assessment Impact Outcome

The canonical `change_impact_status` remains the workflow/outcome field:

~~~text
NOT_ASSESSED
REVIEW_REQUIRED
IMPACT_CONFIRMED
REMEDIATION_REQUIRED
DISPOSITIONED
NO_IMPACT
~~~

Decision rules:

- use `NOT_ASSESSED` before sufficient authorized review;
- use `REVIEW_REQUIRED` while any plausible material scope awaits review;
- use `IMPACT_CONFIRMED` once one or more governed effects are established;
- use `REMEDIATION_REQUIRED` when confirmed impact needs controlled action;
- use `DISPOSITIONED` after all confirmed and uncertain branches have authorized outcomes;
- use `NO_IMPACT` only when all criteria in Section 9 pass.

An assessment with both unaffected and affected objects is not `NO_IMPACT`; it is confirmed impact with per-object dispositions.

---

# 9. `NO_IMPACT` Decision Test

An authorized `NO_IMPACT` decision must answer `YES` to all:

| Test | Required proof |
|---|---|
| Delta identity | Exact old/new objects and versions resolve |
| Assessed boundary | Included/excluded scope, profiles, time, environments, releases, and live partitions are explicit |
| Traversal completeness | Required traversal policies ran on an identified graph revision |
| Candidate treatment | Every candidate object and plausible family was assessed |
| Gap treatment | Missing relationships were resolved or positively bounded by authority and evidence |
| Conflict treatment | Conflicting paths or claims were resolved; unresolved conflict is not hidden |
| Access treatment | No required inaccessible branch remains capable of material effect |
| Evidence fitness | Evidence is current and supports the exact no-impact claim |
| Domain authority | Required artifact, control, evidence, gate, release, and live owners participated |
| Receiver reliance | No receiver must change action, or affected receivers confirm exact non-effect where required |
| Residual uncertainty | None exceeds authorized tolerance, and tolerance is not used to bypass mandatory rules |
| Reopen conditions | Future triggers that invalidate the conclusion are explicit |

The decision record includes assessor, authority, date, graph revision, evidence, rationale, exact scope, and expiry/reopen triggers.

---

# 10. Uncertainty Treatment

| Uncertainty state | Meaning | Allowed result |
|---|---|---|
| MISSING_PATH | A required relationship is absent | Add graph gap and review plausible downstream family; no automatic no-impact |
| CONFLICTED | Sources, edges, owners, or conclusions disagree | Escalate to canonical authority; preserve competing claims |
| UNRESOLVED_ACCESS | Required object/evidence cannot be inspected | Restrict progression or obtain authorized independent attestation |
| TRUNCATED | Traversal stopped by depth/resource/system limit | Continue or justify a bounded manual assessment; no silent omission |
| UNKNOWN_SCOPE | Affected partition cannot be bounded | Treat plausible maximum scope until resolved or safely contained |
| UNKNOWN_AUTHORITY | Decision right is unclear | Block final disposition and route authority clarification |
| UNKNOWN_EVIDENCE_FITNESS | Evidence relevance or validity is not established | Mark evidence review required; do not claim verification or no impact |

Risk acceptance may control residual uncertainty only through valid risk/exception authority. It does not convert unknown truth to unaffected truth.

---

# 11. Materiality Decision Record

~~~yaml
materiality_decision_id:
impact_assessment_ref:
assessment_scope:
dimension_results:
  semantic_meaning:
  scope:
  authority:
  dependency:
  baseline_gate:
  release_live:
  compatibility_migration:
  evidence_fitness:
  reversibility_blast_radius:
  uncertainty:
provisional_level:
domain_overrides: []
final_level:
rationale:
source_refs: []
evidence_refs: []
assessors: []
decision_authority:
decision_status:
decided_at:
valid_until_or_event:
reopen_triggers: []
~~~

---

# 12. Representative Examples

| Change | Likely starting level | Why it remains subject to assessment |
|---|---|---|
| Typographic correction in non-normative prose | M0 | Link, parser, definition, generated output, and interpretation must remain unchanged |
| Local error-message wording changes recovery behavior | M1 or M2 | User action, accessibility, translation, design, implementation, and tests may change |
| Permission requirement changes | M3 or higher | Product policy, security, journeys, APIs, tests, audit, and gate validity are plausible |
| Dependency patch with identical governed behavior | M1 or M2 | Security, license, runtime, build, evidence, and release equivalence require proof |
| Production feature flag changes user exposure | M4 | Live population and release authorization scope change even if code does not |
| Exposed secret or active authorization bypass | M5 | Immediate containment and mandatory security response apply |
| Contract schema changes for all 281 artifacts | M5 framework scope | Incompatible Product OS-wide propagation and migration are plausible |

---

# 13. Decision Authority

Minimum authority increases with level:

| Level | Minimum decision participation |
|---|---|
| M0 | Object owner or delegated reviewer able to verify non-semantic equivalence |
| M1 | Object owner plus affected verifier where behavior/evidence is involved |
| M2 | Change owner and all material domain/receiver owners |
| M3 | Owning baseline/gate authority plus affected domains and evidence/verifier roles |
| M4 | Release/live authority plus gate, operations, risk/control, and affected domain owners |
| M5 | Predefined critical authority route with required independent, executive, legal/regulatory, security/privacy/safety, or Product OS authority participation |

Project GOV-001 may require stronger authority.

---

# 14. Materiality Validation

1. One of M0–M5 is selected for every completed assessment.
2. The strongest material dimension determines the minimum level.
3. All scope partitions and domain overrides are explicit.
4. M0 passes the complete non-semantic test.
5. M3–M5 route required gate/baseline/release/live authorities.
6. Unknown paths never lower the level automatically.
7. `NO_IMPACT` passes all twelve tests.
8. Confirmed effect prevents whole-assessment `NO_IMPACT`.
9. Decision evidence binds exact versions and graph revision.
10. Level changes create a new assessment revision and impact review.

---

# 15. Final Materiality Principle

> **Materiality is the strongest governed consequence that the exact delta can cause within its plausible scope; uncertainty raises the need for review, and only positive evidence—not silence, adjacency, labels, or optimism—can support no impact.**
