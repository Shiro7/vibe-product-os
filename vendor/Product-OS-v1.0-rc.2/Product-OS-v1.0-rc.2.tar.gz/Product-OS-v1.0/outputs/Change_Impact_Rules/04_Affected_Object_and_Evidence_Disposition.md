# Product OS v1.0 — Affected Object and Evidence Disposition

~~~yaml
document_id: FRAMEWORK-CHANGE-IMPACT-04
version: 0.1.0
status: WORKING_DRAFT
inherits: SHARED-CHANGE-IMPACT-CONTRACT@0.1.0
affected_object_disposition_count: 10
governed_project_artifact: GOV-007
~~~

---

# 1. Purpose

This specification defines the authorized disposition of every assessed object and the resulting actions for artifacts, GOV-002 registry entries, graph relationships, profiles, verification, and evidence.

Object disposition is separate from whole-change status, gate validity, verification result, evidence fitness, and registry lifecycle.

---

# 2. Canonical Affected-Object Dispositions

| ID | Disposition | Meaning | Required consequence |
|---|---|---|---|
| CIR-OD-01 | UNAFFECTED | Positive assessment proves changed meaning does not alter this object for exact scope/version | Preserve current state; store rationale, evidence, assessor, date, and reopen trigger |
| CIR-OD-02 | REVIEW_REQUIRED | Plausible effect exists but authorized review is incomplete | Assign reviewer and due event; restrict reliance proportionately |
| CIR-OD-03 | PARTIALLY_AFFECTED | Exact partitions are affected while others remain valid | Split extent; apply independent dispositions and actions per partition |
| CIR-OD-04 | INVALIDATED | Object or claim can no longer be relied upon for affected scope | Mark invalid for scope; invalidate dependent evidence/verification; replace or remediate |
| CIR-OD-05 | STALE | Approved meaning may no longer be current, but final validity decision is pending | Mark corresponding GOV-002 entry `STALE`; prohibit unqualified reliance |
| CIR-OD-06 | SUPERSEDED | A new governed object/version replaces the old meaning | Preserve history; link successor; migrate dependents; prevent new use of old scope |
| CIR-OD-07 | NEWLY_REQUIRED | Change activates a previously unnecessary artifact, control, evidence item, relationship, or review | Create/register owner, due event, verification, evidence, and gate contribution |
| CIR-OD-08 | NOT_APPLICABLE_WITH_EVIDENCE | Object is demonstrably not required for exact changed scope | Record reason, authority, evidence, downstream effect, and reopen conditions |
| CIR-OD-09 | CURRENT_WITH_CONDITIONS | Object remains usable only under explicit bounded conditions | Record condition owner, expiry/event, monitoring, evidence, and breach action |
| CIR-OD-10 | REMEDIATION_REQUIRED | Object remains in governed scope but must be corrected, replaced, reverified, migrated, constrained, or retired | Create authorized action set and restrict progression until completion criteria pass |

Historical normalization:

- `PARTIAL` → `PARTIALLY_AFFECTED`;
- `INVALID` → `INVALIDATED`;
- legacy `PARTIALLY_INVALIDATED` and `FULLY_INVALIDATED` remain gate-impact states, not generic object dispositions;
- `NOT_APPLICABLE_WITH_EVIDENCE` is an impact disposition; it does not overwrite the artifact’s canonical applicability field without the owning applicability decision.

---

# 3. Disposition Record

~~~yaml
object_disposition_id:
impact_assessment_ref:
object_ref:
object_version:
object_class:
owning_artifact_ref:
effective_scope:
disposition:
affected_extent:
unaffected_extent:
rationale:
source_refs: []
evidence_refs: []
supporting_path_refs: []
assessor:
decision_authority:
decided_at:
valid_until_or_event:
registry_actions: []
graph_actions: []
verification_actions: []
evidence_actions: []
required_action_refs: []
receiver_refs: []
reopen_triggers: []
~~~

---

# 4. Partition Rule

Use `PARTIALLY_AFFECTED` only with computable partitions.

Valid partitions may use:

- user or role;
- market, jurisdiction, tenant, organization, or contract;
- platform, device, channel, browser, or language;
- capability, journey, feature, component, API, data set, control, or evidence claim;
- environment, configuration, candidate, release, target, cohort, or live instance;
- valid-time range or evidence period.

“Partially” without explicit affected and unaffected extent is `REVIEW_REQUIRED`.

---

# 5. GOV-002 Registry Actions

| Situation | Required GOV-002 action |
|---|---|
| Approved meaning may no longer be relied upon | Mark affected artifact lifecycle entry `STALE` for exact scope and link change |
| New version replaces prior meaning | Register new version; link `SUPERSEDES`; preserve prior lifecycle and locators |
| New artifact becomes required | Create/activate entry with owner, status, profile treatment, dependencies, and approval route |
| Artifact becomes N/A for changed scope | Record governed N/A decision, evidence, authority, downstream implications, and reopen trigger |
| Artifact is deprecated or retired | Preserve identity; record lifecycle, successor/transfer, retention, and remaining obligations |
| Ownership or authority changes | Update effective-dated owner/authority metadata; reassess open approvals and acknowledgements |
| Artifact remains current under conditions | Link conditions, expiry/event, owner, monitoring, and change record |

Registry status never substitutes for content correction, approval, verification, or gate decision.

---

# 6. GOV-008 Graph Actions

For affected relationships:

- create a new versioned edge when meaning changes;
- invalidate an edge when prior support no longer holds;
- supersede an edge when a replacement relationship exists;
- update exact scope, confidence, authority, evidence, and valid time through new history;
- add missing required edges discovered by assessment;
- preserve conflicted or uncertain assertions until resolved;
- link `REOPENS`, `INVALIDATES`, `SUPERSEDES`, and other controlled edges where their exact semantics apply;
- never rewrite confirmed history in place.

Graph actions describe relationship truth. They do not close the change response.

---

# 7. GOV-009 Profile and Applicability Actions

Reevaluate GOV-009 when triggers change for:

- market, jurisdiction, language, platform, channel, data, payment, identity, accessibility, generated output, third party, enterprise, regulated sector, or contract;
- standards version, authority, target level, exception, equivalence, or evidence expectation;
- conditional Product OS profile or domain override.

For each profile record:

~~~yaml
profile_or_standard_ref:
previous_applicability:
proposed_applicability:
effective_scope:
trigger_change:
propagation_targets: []
evidence_impact: []
decision_authority:
decision_ref:
reopen_triggers: []
~~~

Change Impact Rules routes re-evaluation; GOV-009 owns the applicability decision.

---

# 8. Verification Invalidation

Verification becomes invalid for affected scope when:

- the verified candidate, configuration, target, environment, data, dependency, requirement, design, architecture, or control changes materially;
- the method no longer tests the same claim;
- evidence identity, integrity, period, population, or authority no longer matches;
- an exception, waiver, condition, or acceptance criterion changes;
- a defect, incident, or contradictory observation defeats the result;
- coverage relied on an invalidated or superseded relationship.

~~~yaml
verification_invalidation_id:
verification_ref:
verified_claim_ref:
previous_candidate_or_scope:
affected_scope:
change_ref:
invalidation_reason:
status_before:
status_after:
replacement_verification_required:
required_method_or_independence:
owner:
due_event:
authority:
recorded_at:
~~~

Unaffected partitions may retain verification only when partitioning and equivalence are proven.

---

# 9. Evidence Invalidation and Replacement

Evidence actions are:

~~~text
RETAIN_CURRENT
REVIEW_FITNESS
INVALIDATE_FOR_SCOPE
SUPERSEDE_WITH_NEW_EVIDENCE
REGENERATE
EXTEND_PERIOD
REVERIFY_INTEGRITY
RESTRICT_ACCESS
PRESERVE_LEGAL_OR_AUDIT_HISTORY
NEW_EVIDENCE_REQUIRED
~~~

Each action binds:

- evidence identity and supported claim;
- old and new object/candidate/environment/scope;
- producer and authority;
- relevant period;
- invalidation or limitation reason;
- dependent gate, decision, release, live, or compliance claim;
- replacement owner and due event;
- retention and access treatment;
- acknowledgement by evidence consumers where required.

Evidence invalidation never deletes historical proof. It marks the limits of current reliance.

---

# 10. Claim-Level Disposition

An artifact may contain many claims with different outcomes. Do not invalidate the entire artifact when exact claim/scope partitioning is safe, and do not preserve the entire artifact when a material claim is invalid.

~~~yaml
artifact_ref:
claim_ref:
claim_version:
affected_scope:
object_disposition:
evidence_fitness_result:
dependent_claim_refs: []
replacement_claim_ref:
~~~

P1 may store this compactly; logical claim-level traceability remains required for gate-critical or disputed scope.

---

# 11. Decision and Assumption Disposition

For a changed decision:

- preserve workflow status and lifecycle disposition separately;
- reopen to `OPEN` or `IN_REVIEW` when current meaning needs re-decision;
- mark prior decision `SUPERSEDED` only when a valid replacement exists;
- preserve conditions, authority, date, rationale, and historical effects.

For a changed assumption:

- update confidence and validation state;
- identify every decision or plan that relied on it;
- mark affected dependents `REVIEW_REQUIRED` or stronger;
- route evidence collection, mitigation, or product/business re-entry.

---

# 12. Release and Live Disposition

For release/live objects, possible actions include:

- preserve unaffected cohort or target;
- constrain rollout;
- pause progression;
- stop deployment;
- rollback exact scope;
- roll forward with authorized correction;
- isolate environment or tenant;
- revoke configuration, key, permission, artifact, or candidate;
- notify affected users/owners;
- increase monitoring and evidence collection;
- route G6B, G7, or G8 review.

The action requires release/live authority and does not arise automatically from an object disposition label.

---

# 13. Condition Contract

`CURRENT_WITH_CONDITIONS` contains:

~~~yaml
condition_id:
object_ref:
effective_scope:
required_behavior_or_limit:
owner:
evidence_expectation:
monitoring_ref:
valid_from:
expires_at_or_event:
breach_action:
gate_or_release_effect:
acknowledgers: []
reopen_trigger:
~~~

An expired, breached, ownerless, unmonitored, or unevidenced condition invalidates conditional reliance.

---

# 14. Disposition Completion

An object disposition is complete when:

1. object, version, claim, and exact scope resolve;
2. rationale, source, evidence, path, assessor, and authority are recorded;
3. registry and graph actions are complete or assigned;
4. verification and evidence consequences are explicit;
5. dependent gates, releases, live scopes, profiles, and receivers are routed;
6. required remediation has owner and due event;
7. successor, condition, retention, or N/A rules exist where applicable;
8. receiving acknowledgement and reopen triggers exist.

---

# 15. Final Disposition Principle

> **Every affected object must state exactly what remains valid, what becomes stale or invalid, what replaces it, which evidence can still be relied upon, and who must act—at claim and scope resolution precise enough to preserve unaffected truth without hiding material damage.**
