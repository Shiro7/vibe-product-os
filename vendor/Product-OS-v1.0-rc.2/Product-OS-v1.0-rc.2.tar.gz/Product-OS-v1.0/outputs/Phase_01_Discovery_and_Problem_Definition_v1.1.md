# Product OS v1.0 — Methodology Specification
## Phase 01: Discovery & Problem Definition

**Phase ID:** `PHASE-01`  
**Phase Name:** `Discovery & Problem Definition`  
**Version:** `1.1`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G1 — Problem Understood`  
**Primary Baseline:** `DSBL — Discovery Baseline`  
**Primary Outcome:** إنشاء validated understanding للمشكلة والسياق والأطراف والنتائج المطلوبة، وإثراء evidence الخاص بـ`GOV-009`، قبل تحويلها إلى Business Architecture أو Product Scope أو Requirements.

**v1.1 Closure Scope:** Housekeeping محدود لربط Discovery بـ`GOV-009`: Phase 01 تؤكد أو تتحدى activation triggers، تجمع evidence وتظهر الـunknowns، ثم تسلمها إلى Phase 02 لاتخاذ business applicability decisions.

---

# 1. Purpose

الغرض من Phase 01 هو الانتقال من:

```text
"We need a system."
```

إلى فهم قابل للدفاع عنه يوضح:

```text
What is happening?
Why is it a problem?
Who is affected?
How much does it matter?
What may be causing it?
What outcome is actually required?
What remains uncertain?
```

Phase 01 لا تفترض أن الحل Software.

ولا تفترض أن الحل الذي طلبه Stakeholder هو الحل الصحيح.

ولا تفترض أن وصف Stakeholder للمشكلة يمثل Root Cause.

الهدف هو بناء:

```text
Validated Problem Model
```

وليس:

```text
Feature Wishlist
```

---

# 2. Position in Product OS

```text
PHASE 00
Initialization & Intake
       │
       ▼
      G0
       │
       ▼
PHASE 01
Discovery & Problem Definition
       │
       ▼
      G1
       │
       ├───────────────┐
       ▼               ▼
Business Architecture Product Definition
       │               │
       └───────┬───────┘
               ▼
       Requirements Engineering
```

لكن المسار الفعلي يعتمد على Product State.

---

# 3. Core Discovery Question

Phase 01 كلها تدور حول سؤال رئيسي:

> **What condition exists today that creates enough business, operational, user, technical, regulatory, or strategic impact to justify change?**

ثم:

> **What evidence supports that conclusion?**

---

# 4. Discovery Philosophy

Product OS Discovery يعتمد على خمسة مبادئ.

## D-01 — Problem Before Solution

لا نبدأ بما سنبنيه.

نبدأ بما يجب تغييره.

---

## D-02 — Evidence Before Confidence

قوة التشخيص تعتمد على evidence وليس على جودة صياغة Stakeholder.

---

## D-03 — Multiple Perspectives

المشكلة الواحدة قد تبدو مختلفة بالنسبة إلى:

- Executive.
- Operations.
- Finance.
- Customer.
- Employee.
- IT.
- Compliance.
- Support.

لا يتم اعتبار أحد perspectives الحقيقة المطلقة تلقائيًا.

---

## D-04 — Cause Must Be Earned

Root Cause ليس label يمنحه AI لأن تفسيرًا ما يبدو منطقيًا.

الـcause يمر بمراحل:

```text
OBSERVED
↓
HYPOTHESIZED
↓
SUPPORTED
↓
VALIDATED
```

---

## D-05 — Discovery Has a Stop Condition

Discovery لا تستمر حتى "نعرف كل شيء".

تنتهي عندما تكون المعلومات كافية للانتقال للمرحلة التالية بدرجة مخاطرة مقبولة.

---

# 5. Phase Objectives

بنهاية Phase 01 يجب أن يكون Product OS قادرًا على:

1. وصف Current State.
2. تحديد Symptoms.
3. تحديد Problems.
4. فصل Problems عن Causes.
5. إنشاء Cause Hypotheses.
6. تقييم Evidence.
7. فهم stakeholder impacts.
8. فهم user impacts.
9. تحديد business/operational impacts.
10. تحديد constraints.
11. تحديد dependencies.
12. تحديد existing processes.
13. تحديد known workarounds.
14. تحديد previous attempts.
15. فهم desired outcomes.
16. وضع measurable success signals.
17. تحديد opportunities.
18. تحديد discovery risks.
19. تحديد major unknowns.
20. بناء scope hypothesis أولية.
21. تحديد ما يدخل المرحلة التالية.
22. تمرير G1.
23. مراجعة activation triggers الواردة من Phase 00 واكتشاف ما يظهر أثناء Discovery.
24. إثراء `GOV-009` بالـevidence والowners والأسئلة والحالات `PENDING`.
25. تسليم applicability evidence إلى Phase 02 بدون اختراع business obligations أو requirements.

---

# 6. Phase Inputs

Phase 01 تستقبل مخرجات Phase 00.

Required logical inputs:

```text
Project Context
Product State
Source Register
Atomic Item Register
Authority Context
Initial Problem
Initial Outcomes
Initial Constraints
Existing Assets
Open Questions
Risk Signals
G0 Decision
Standards & Compliance Activation Triggers
Preliminary GOV-009 Entries
```

Product OS Constitution والـstandards/profile catalog يستخدمان كـframework references عند مراجعة `GOV-009`.

---

# 7. Additional Discovery Inputs

يمكن إضافة مصادر جديدة أثناء Discovery.

مثل:

```text
Stakeholder Interviews
Process Walkthroughs
Operational Reports
Existing Screens
System Logs
Support Tickets
User Feedback
Analytics
Financial Reports
Policies
Contracts
Accessibility Research or Audit Evidence
Standards / Profile Sources
Market, Regulatory, or Contractual Applicability Evidence
Incident Records
Existing Requirements
Market Research
Competitor Research
Field Observation
```

أي Source جديد يجب تسجيله عبر Source Model الموجود في Phase 00.

---

# 8. Discovery Entry Condition

Phase 01 تبدأ فقط إذا:

```text
G0 = PASS
```

أو:

```text
G0 = PASS_WITH_CONDITIONS
```

والـconditions لا تمنع Discovery.

---

# 9. What Phase 01 Is Not

Phase 01 ليست:

- Feature definition.
- Detailed SRS.
- UI design.
- Architecture design.
- Vendor selection.
- Database design.
- Full BPMN modeling.
- Sprint planning.
- Estimation workshop.
- Technical implementation planning.
- Commercial proposal.
- Final MVP definition.
- Solution approval.

قد تظهر أفكار Solution أثناء Discovery.

يتم تسجيلها.

لا يتم اعتمادها.

---

# 10. Discovery Object Model

Phase 01 تتعامل مع مجموعة مفاهيم يجب الفصل بينها.

```text
Current State
Symptom
Problem
Impact
Cause Hypothesis
Validated Cause
Constraint
Opportunity
Desired Outcome
Success Measure
Solution Idea
```

خلط هذه المفاهيم يعتبر Discovery defect.

---

# 11. Current State

تعريف:

> وصف ما يحدث فعليًا الآن قبل التغيير المقترح.

Current State يمكن أن يشمل:

- people;
- processes;
- systems;
- data;
- tools;
- approvals;
- timing;
- workarounds;
- pain points;
- responsibilities;
- handoffs.

Example:

```text
Sales orders arrive by WhatsApp.

The sales employee manually enters the order into Excel.

Warehouse receives a screenshot.

Inventory is updated manually at the end of the day.
```

هذا Current State.

ليس Requirement.

---

# 12. Current State vs Policy State

Product OS يفرق بين:

```text
HOW WORK IS SUPPOSED TO HAPPEN
```

و:

```text
HOW WORK ACTUALLY HAPPENS
```

يمكن تسجيل:

```text
POLICY_STATE
ACTUAL_STATE
```

Example:

Policy:

```text
Warehouse issue must require supervisor approval.
```

Actual:

```text
Urgent orders are often released without approval.
```

الفرق نفسه Discovery Finding مهم.

---

# 13. Symptom

تعريف:

> Observable indication that something is wrong.

Examples:

```text
Reports are delayed.
Customers complain.
Inventory quantities are incorrect.
Users maintain duplicate spreadsheets.
Approvals take several days.
```

Symptom لا يساوي Problem.

---

# 14. Problem

تعريف:

> A condition that causes material negative impact or prevents a desired outcome.

Example:

```text
Inventory information is fragmented across multiple uncontrolled records,
preventing operations from maintaining a trusted current stock position.
```

ده Problem.

---

# 15. Impact

كل Problem يحتاج Impact واضح.

Impact categories:

```text
FINANCIAL
OPERATIONAL
CUSTOMER
EMPLOYEE
COMPLIANCE
SECURITY
QUALITY
TIME
DATA
STRATEGIC
REPUTATIONAL
SAFETY
```

---

# 16. Impact Model

Example:

```yaml
problem_id: PRB-004

impact:
  operational:
    statement: "Warehouse staff spend time reconciling stock."
  financial:
    statement: "Incorrect availability creates missed sales."
  management:
    statement: "Management reports are one day behind."
```

---

# 17. Impact Magnitude

إذا كانت البيانات متاحة:

```text
LOW
MEDIUM
HIGH
CRITICAL
```

ويفضل evidence.

Example:

```text
Average stock reconciliation:
3 hours/day
```

أفضل من:

```text
A lot of time is wasted.
```

لكن غياب metric لا يمنع Discovery.

---

# 18. Cause Hypothesis

تعريف:

> تفسير محتمل للمشكلة يحتاج Evidence.

Example:

```text
Cause Hypothesis:
Manual stock updates may be responsible for stock discrepancies.
```

Status:

```text
HYPOTHESIZED
```

وليس:

```text
CONFIRMED
```

---

# 19. Cause Lifecycle

Canonical lifecycle:

```text
IDENTIFIED
↓
HYPOTHESIZED
↓
SUPPORTED
↓
VALIDATED
```

Additional outcomes:

```text
REJECTED
UNRESOLVED
```

---

# 20. Cause Evidence

Cause يمكن دعمه بواسطة:

```text
Observation
System data
Process walkthrough
Repeated stakeholder evidence
Logs
Transaction history
Testing
Audit reports
Incident records
```

---

# 21. Root Cause

Label:

```text
ROOT_CAUSE
```

لا يستخدم إلا عندما يوجد Evidence كافٍ.

في معظم Product Discovery يكفي:

```text
PRIMARY_SUPPORTED_CAUSE
```

لأن استخدام كلمة Root Cause بشكل متسرع يخلق false certainty.

---

# 22. Problem Hierarchy

قد توجد مشاكل مرتبطة.

Example:

```text
PRB-001
Inventory data is unreliable
    │
    ├── PRB-002
    │   Stock updates are delayed
    │
    └── PRB-003
        Duplicate records exist
```

Product OS يسمح:

```text
PARENT_PROBLEM
CHILD_PROBLEM
RELATED_PROBLEM
```

---

# 23. Problem Statement Contract

Problem Statement جيد يجب أن يجيب:

```text
WHO / WHAT IS AFFECTED?
WHAT CONDITION EXISTS?
WHAT IMPACT DOES IT CREATE?
WHAT EVIDENCE SUPPORTS IT?
```

ويجب ألا يحتوي الحل.

---

# 24. Bad Problem Statement

```text
We don't have an ERP.
```

هذا absence of solution.

ليس Problem.

---

# 25. Better Problem Statement

```text
Purchasing, warehouse, sales, and finance maintain independent records,
causing inconsistent stock and cost information and forcing management
to manually reconcile operational reports.
```

---

# 26. Solution Contamination Test

إذا كان Problem Statement يحتوي:

```text
Need
Build
Implement
Use
Develop
Integrate
AI
ERP
Mobile App
Blockchain
Microservices
```

يجب مراجعة هل تم وصف Solution بدل Problem.

ليس ممنوعًا وجود هذه الكلمات.

لكنها Warning Signal.

---

# 27. Discovery Workflow

Canonical workflow:

```text
01.0 Confirm Discovery Scope
        ↓
01.1 Map Stakeholders
        ↓
01.2 Capture Current State
        ↓
01.3 Identify Symptoms
        ↓
01.4 Define Problems
        ↓
01.5 Assess Impacts
        ↓
01.6 Investigate Causes
        ↓
01.7 Understand Existing Processes
        ↓
01.8 Identify Workarounds & Previous Attempts
        ↓
01.9 Capture Constraints & Dependencies
        ↓
01.10 Define Desired Outcomes
        ↓
01.11 Define Success Signals
        ↓
01.12 Identify Opportunities
        ↓
01.13 Reconcile Conflicts
        ↓
01.14 Build Scope Hypothesis
        ↓
01.15 Validate Findings
        ↓
01.16 Evaluate G1
        ↓
01.17 Generate Handoff
```

---

# 28. Step 01.0 — Discovery Scope

Discovery نفسها تحتاج Scope.

ليس Product Scope النهائي.

يسمى:

```text
DISCOVERY_SCOPE
```

يحدد:

```text
Domains to investigate
Stakeholders required
Existing systems to inspect
Processes to examine
Known exclusions
Time constraints
Evidence needed
```

---

# 29. Discovery Scope vs Product Scope

فرق إلزامي:

```text
Discovery Scope:
What must we investigate?
```

```text
Product Scope:
What will the product eventually include?
```

الأول يتحدد هنا.

الثاني لاحقًا.

---

# 30. Discovery Breadth

Discovery قد تكون:

```text
FOCUSED
STANDARD
CROSS_FUNCTIONAL
ENTERPRISE
```

وده يختلف عن P1/P2/P3.

مثلاً P3 project قد يحتوي focused discovery لFeature محددة.

---

# 31. Step 01.1 — Stakeholder Mapping

Stakeholder ليس كل شخص يعرف أن المشروع موجود.

Stakeholder هو من:

- يؤثر في المشكلة؛
- يتأثر بالمشكلة؛
- يملك قرارًا؛
- يملك معرفة مهمة؛
- يملك dependency؛
- يملك approval؛
- يملك risk.

---

# 32. Stakeholder Categories

```text
SPONSOR
DECISION_MAKER
DOMAIN_OWNER
PROCESS_OWNER
USER
CUSTOMER
OPERATOR
APPROVER
COMPLIANCE
LEGAL
FINANCE
IT
SECURITY
DATA_OWNER
VENDOR
EXTERNAL_PARTY
OTHER
```

---

# 33. Stakeholder Record

```yaml
stakeholder_id: STK-008

role: "Warehouse Supervisor"

stakeholder_type:
  - PROCESS_OWNER
  - USER

knowledge_domains:
  - STOCK_RECEIPT
  - STOCK_ISSUE

authority_domains:
  - WAREHOUSE_OPERATIONS

influence: HIGH

impact: HIGH
```

---

# 34. Stakeholder Coverage

Product OS يجب أن يتأكد أن Discovery لم تعتمد فقط على:

```text
EXECUTIVE VIEW
```

إذا المشكلة تشغيلية.

ولا فقط:

```text
USER VIEW
```

إذا هناك regulatory أو financial controls.

---

# 35. Stakeholder Conflict

Stakeholders قد يختلفون.

مثال:

Sales:

```text
Warehouse is slow.
```

Warehouse:

```text
Sales sends incomplete orders.
```

لا يتم اختيار side.

يتم تحليل الـworkflow.

---

# 36. Step 01.2 — Current-State Discovery

Current State يجب أن يغطي فقط العمق اللازم لفهم المشكلة.

Potential dimensions:

```text
PEOPLE
PROCESS
SYSTEM
DATA
DECISION
HANDOFF
CONTROL
EXCEPTION
TIME
VOLUME
```

---

# 37. Current-State Unit

يمكن توثيق:

```text
CURRENT-001
```

Example:

```yaml
current_state_id: CURRENT-001

activity:
  "Sales order creation"

actor:
  "Sales Representative"

tool:
  "Excel"

trigger:
  "Customer confirmation"

output:
  "Order spreadsheet"

next_handoff:
  "Warehouse"
```

---

# 38. Process Discovery Level

Phase 01 لا تحتاج دائمًا full process modeling.

Levels:

```text
L0 — Context
L1 — Major Workflow
L2 — Activity Detail
L3 — Exception Detail
```

اختيار العمق يعتمد على المشكلة.

---

# 39. L0 Context

Example:

```text
Lead → Sale → Fulfillment → Payment
```

---

# 40. L1 Workflow

Example:

```text
Order Received
↓
Validated
↓
Stock Checked
↓
Approved
↓
Released
```

---

# 41. L2 Activity

يدخل:

```text
Actor
Input
Action
Output
System
Decision
```

---

# 42. L3 Exception

يدخل:

```text
Failure
Exception
Escalation
Rework
Override
```

Phase 01 لا تدخل L3 لكل Workflow إلا عند الحاجة.

---

# 43. Process Evidence

يجب التمييز بين:

```text
DOCUMENTED_PROCESS
OBSERVED_PROCESS
REPORTED_PROCESS
```

يمكن أن تختلف.

---

# 44. Step 01.3 — Symptom Register

كل Symptom يحصل ID:

```text
SYM-001
SYM-002
```

Example:

```yaml
symptom_id: SYM-006

statement:
  "Inventory reports are usually one day late."

observed_by:
  - STK-003

evidence:
  - SRC-009

frequency:
  DAILY
```

---

# 45. Symptom Frequency

إذا معروف:

```text
CONTINUOUS
FREQUENT
OCCASIONAL
RARE
UNKNOWN
```

---

# 46. Step 01.4 — Problem Definition

Problems تحصل IDs:

```text
PRB-001
PRB-002
```

Required fields:

```text
Statement
Affected Area
Affected Stakeholders
Impact
Evidence
Related Symptoms
Cause Status
Priority
```

---

# 47. Problem Priority

Problem Priority لا تعتمد فقط على Stakeholder loudness.

Factors:

```text
Impact
Frequency
Risk
Strategic Importance
Dependency
Urgency
Affected Population
Cost
```

---

# 48. Priority Status

Preliminary:

```text
CRITICAL
HIGH
MEDIUM
LOW
UNASSESSED
```

---

# 49. Step 01.5 — Impact Analysis

Discovery يحاول قياس:

```text
Current Cost
Current Delay
Current Error Rate
Current Risk
Current Effort
Current Volume
Current Revenue Effect
Current User Effect
```

حيثما تكون البيانات معقولة ومتاحة.

---

# 50. Quantitative Evidence

مثال:

```text
1,200 invoices/month
7% require manual correction
Average correction time = 18 min
```

أقوى من:

```text
Invoice errors happen frequently.
```

لكن qualitative findings تظل صالحة عندما البيانات غير متاحة.

---

# 51. Qualitative Evidence

Examples:

```text
User interviews
Repeated complaints
Observed workarounds
Escalation patterns
Audit findings
Operational friction
```

---

# 52. Evidence Strength

Suggested:

```text
E0 — NONE
E1 — SINGLE_SOURCE
E2 — MULTIPLE_CONSISTENT_SOURCES
E3 — DOCUMENTED_OR_OBSERVED
E4 — MEASURED
```

هذا ليس Truth Score.

هو قوة الـsupport الحالي.

---

# 53. Step 01.6 — Cause Investigation

Product OS لا يفرض technique واحدة.

يمكن استخدام:

```text
5 Whys
Fishbone
Fault Tree
Process Analysis
Data Analysis
Constraint Analysis
System Analysis
Value Stream Analysis
Incident Analysis
```

Technique يتم اختيارها حسب نوع المشكلة.

---

# 54. Cause Categories

```text
PEOPLE
PROCESS
POLICY
SYSTEM
DATA
INTEGRATION
CONTROL
GOVERNANCE
TRAINING
CAPACITY
COMMUNICATION
VENDOR
REGULATORY
PHYSICAL_ENVIRONMENT
OTHER
```

---

# 55. Multi-Causal Problems

مشكلة واحدة قد يكون لها عدة Causes.

```text
PRB-004
 ├── CAUSE-001
 ├── CAUSE-002
 └── CAUSE-003
```

لا يجب إجبار كل Problem على Root Cause واحدة.

---

# 56. Cause Confidence

```text
LOW
MEDIUM
HIGH
```

مع Evidence.

---

# 57. Correlation Warning

إذا حدث شيئان معًا:

```text
A
and
B
```

لا يعني:

```text
A caused B
```

AI يجب أن يسجل:

```text
POSSIBLE_RELATIONSHIP
```

حتى يوجد support كافٍ.

---

# 58. Step 01.7 — Existing Process Analysis

هدف Phase 01:

> فهم كيف تساهم العمليات الحالية في المشكلة.

ليس:

> توثيق الشركة بأكملها.

---

# 59. Process Friction Types

```text
MANUAL_DUPLICATION
WAITING
REWORK
HANDOFF
APPROVAL_DELAY
DATA_REENTRY
CONTROL_GAP
UNCONTROLLED_OVERRIDE
MISSING_VISIBILITY
SYSTEM_SWITCHING
BOTTLENECK
DEPENDENCY
ERROR_PRONE_STEP
```

---

# 60. Process Value Classification

Activities قد تكون:

```text
VALUE_ADDING
REQUIRED_CONTROL
NON_VALUE_ADDING
UNKNOWN
```

لكن لا يتم حذف Control فقط لأنه لا يضيف قيمة مباشرة.

مثلاً Audit Approval قد يكون required.

---

# 61. Step 01.8 — Workarounds

Workaround مهم جدًا لأنه يكشف:

```text
Unmet Need
Missing Capability
Broken Process
User Adaptation
```

Examples:

```text
Personal Excel sheets
WhatsApp approvals
Manual duplicate records
Paper notes
Shared passwords
Offline calculations
```

---

# 62. Workaround Record

```yaml
workaround_id: WRK-003

used_for:
  "Emergency purchase approval"

reason:
  "ERP workflow takes too long"

risk:
  HIGH
```

---

# 63. Previous Attempts

يجب التقاط:

```text
What was tried?
Why?
What happened?
Why did it fail?
What was learned?
```

حتى لا نعيد نفس التجربة بثقة أعلى وشعار جديد.

---

# 64. Previous Attempt Status

```text
FAILED
PARTIAL_SUCCESS
ABANDONED
REPLACED
ONGOING
UNKNOWN
```

---

# 65. Step 01.9 — Constraints

Phase 00 سجل initial constraints.

Phase 01:

```text
Confirms
Expands
Challenges
Reclassifies
```

مثال:

Phase 00:

```text
"Must use Oracle."
```

Discovery تكشف:

```text
It is actually a preference from one technical stakeholder.
```

فيتم:

```text
HARD → PREFERENCE
```

---

# 66. Constraint Impact

كل Constraint مهم يجب ربطه بـ:

```text
Business
Product
UX
Technical
Delivery
Security
Compliance
```

## GOV-009 Evidence Enrichment — Mandatory Phase 01 Activity

Discovery تراجع كل material trigger الوارد من Phase 00 أو المكتشف أثناء البحث، ثم:

```text
Confirms or challenges the trigger
Links sources and discovery evidence
Identifies affected users, journeys, operations, data, documents, and third parties
Records contradictions and open questions
Assigns evidence owner or next investigation route
Updates GOV-009 while unresolved applicability remains PENDING
```

Phase 01 لا تتخذ قرار business applicability النهائي، ولا تحول standard أو research finding مباشرة إلى business requirement أو product requirement.

---

# 67. Dependency Discovery

Dependencies الجديدة قد تظهر خلال analysis.

Example:

```text
Payroll accuracy depends on approved attendance data.
```

هذا downstream architecture information مهم جدًا.

---

# 68. Step 01.10 — Desired Outcomes

Outcome هو:

> حالة أفضل نريد الوصول إليها.

وليس:

> Feature نريد بناؤها.

---

# 69. Outcome Types

```text
BUSINESS
OPERATIONAL
USER
FINANCIAL
RISK
COMPLIANCE
QUALITY
STRATEGIC
TECHNICAL
```

---

# 70. Outcome Record

```yaml
outcome_id: OUT-004

statement:
  "Management can view current warehouse availability without manual reconciliation."

affected_problem:
  PRB-002

priority:
  HIGH
```

---

# 71. Outcome vs Solution

Bad:

```text
Implement dashboard.
```

Better:

```text
Management can access current operational performance without waiting for manually prepared reports.
```

Dashboard قد يكون solution لاحقًا.

---

# 72. Step 01.11 — Success Signals

كل major outcome يجب أن يكون له success signal إن أمكن.

Example:

```text
Outcome:
Reduce order processing delay.

Success Signal:
90% of standard orders released within 30 minutes.
```

---

# 73. Success Metric Maturity

```text
M0 UNKNOWN
M1 QUALITATIVE
M2 DIRECTIONAL
M3 MEASURABLE
M4 BASELINED
```

Phase 01 لا تفرض M4 على كل شيء.

لكن high-value outcomes يفضل أن تصل M3/M4.

---

# 74. Baseline Metric

إذا Goal هو improvement، نحتاج قدر الإمكان Current Baseline.

Example:

```text
Current:
3 days

Target:
< 1 day
```

بدون Current Baseline يصعب قياس improvement.

---

# 75. Metric Integrity Rule

لا يتم اختراع KPI لأن Business لم يحدده.

AI يستطيع اقتراح:

```text
PROPOSED_SUCCESS_MEASURE
```

لكن لا يسجله كapproved.

---

# 76. Opportunity

Opportunity ليست Problem.

Problem:

```text
Existing negative condition.
```

Opportunity:

```text
Potential improvement/value even if no severe problem exists.
```

Example:

```text
Current sales process works,
but customer self-service may reduce operational cost.
```

---

# 77. Opportunity IDs

```text
OPP-001
OPP-002
```

---

# 78. Opportunity Status

```text
IDENTIFIED
SUPPORTED
PRIORITIZED
DEFERRED
REJECTED
```

---

# 79. Requested Solution Handling

أي solution idea تظهر:

```text
IDEA-001
```

وتحتوي:

```text
Source
Problem it claims to address
Status
Assumptions
```

مثال:

```yaml
idea_id: IDEA-004

statement:
  "Use AI to predict stock."

source:
  SRC-011

related_problem:
  PRB-008

status:
  UNEVALUATED
```

---

# 80. Solution-Problem Trace Rule

أي Solution Idea لا تستطيع الإشارة إلى Problem أو Opportunity تصبح:

```text
UNJUSTIFIED_IDEA
```

ولا تدخل Scope تلقائيًا.

---

# 81. Step 01.12 — Opportunity Framing

بعد Problems وOutcomes يمكن تحديد:

```text
Business Opportunity
Product Opportunity
Automation Opportunity
Data Opportunity
Experience Opportunity
Control Opportunity
Integration Opportunity
```

ولكنها لا تصبح Requirements بعد.

---

# 82. Step 01.13 — Conflict Reconciliation

Phase 01 توسع conflict handling من Phase 00.

Conflict Types:

```text
FACT_CONFLICT
PROCESS_CONFLICT
GOAL_CONFLICT
PRIORITY_CONFLICT
POLICY_CONFLICT
AUTHORITY_CONFLICT
SCOPE_CONFLICT
TERMINOLOGY_CONFLICT
```

---

# 83. Conflict Resolution

Possible outcomes:

```text
RESOLVED
RESOLVED_WITH_SCOPE_SPLIT
DEFERRED
ESCALATED
UNRESOLVED_NONBLOCKING
```

---

# 84. Conflict Evidence

لا يكفي:

```text
We agreed.
```

يجب تسجيل:

```text
What was decided
Who had authority
Why
What was superseded
```

---

# 85. Step 01.14 — Scope Hypothesis

هذه ليست Product Scope النهائية.

اسمها:

```text
SCOPE_HYPOTHESIS
```

تجيب:

> أين يبدو أن التدخل يجب أن يركز؟

---

# 86. Scope Hypothesis Structure

```yaml
scope_hypothesis:

  likely_in_scope:
    - "Warehouse inventory control"
    - "Order-to-stock handoff"

  likely_out_of_scope:
    - "HR payroll"

  uncertain:
    - "Procurement"

  rationale:
    - PRB-002
    - PRB-004
```

---

# 87. Scope Hypothesis Rule

أي Scope Item يحتاج علاقة بـ:

```text
Problem
Outcome
Opportunity
Constraint
```

---

# 88. Scope Expansion Warning

إذا Discovery بدأت تنتقل إلى:

```text
"طالما بنعمل warehouse نعمل HR كمان."
```

يتم تسجيل:

```text
SCOPE_EXPANSION_CANDIDATE
```

ولا يضاف تلقائيًا.

---

# 89. Discovery Boundary

Phase 01 لا تقرر:

```text
Exact Modules
Exact Screens
Exact Features
Final MVP
```

بل تنتج Evidence يسمح للمرحلة التالية باتخاذ هذه القرارات.

---

# 90. Step 01.15 — Discovery Validation

قبل G1 يجب عرض findings الرئيسية على أصحاب المعرفة أو القرار المناسبين.

Validation يشمل:

```text
Current State
Primary Problems
Impacts
Supported Causes
Desired Outcomes
Major Constraints
Open Unknowns
```

---

# 91. Validation Types

```text
STAKEHOLDER_CONFIRMATION
DOCUMENT_CONFIRMATION
OBSERVATION
DATA_CONFIRMATION
CROSS_SOURCE_CONFIRMATION
```

---

# 92. Validation Does Not Mean Consensus

أحيانًا stakeholders لن يتفقوا.

Product OS يحتاج:

```text
Clear disagreement
+
Decision route
```

وليس fake consensus.

---

# 93. Discovery Confidence

كل major finding قد يحصل:

```text
HIGH
MEDIUM
LOW
```

مع rationale.

---

# 94. Discovery Depth Profiles

## P1 Lean

يستخدم:

```text
DISCOVERY PACK
```

يجمع:

- context;
- stakeholders;
- problems;
- outcomes;
- constraints;
- scope hypothesis;
- questions.
- complete logical `GOV-009` trigger/evidence coverage حتى لو كان داخل Discovery Pack.

Process mapping يكون lightweight.

---

# 95. P2 Standard

يستخدم artifacts مستقلة.

يشمل:

- stakeholder map;
- current-state model;
- problem register;
- outcome model;
- risk/assumption linkage;
- scope hypothesis;
- validation evidence.
- explicit `GOV-009` evidence links and pending-item ownership.

---

# 96. P3 Comprehensive

يضيف:

- multi-stakeholder validation;
- deeper source authority;
- quantitative impact where possible;
- process variants;
- evidence register;
- formal conflict management;
- full problem hierarchy;
- formal discovery approval;
- audit trail;
- domain-by-domain coverage.
- clause/profile-level evidence detail عندما يبرره risk أو regulation أو contract.

---

# 97. Discovery Modes by Product State

Phase 01 ليست نفسها لكل Product State.

---

# 98. S0 — Early Idea Discovery

Focus:

```text
Problem existence
Target user
Context
Needs
Assumptions
Market/context uncertainty
Desired value
```

Avoid:

```text
Detailed process analysis
```

إذا لا يوجد process أصلًا.

---

# 99. S1 — New Product Discovery

Focus:

```text
User need
Business opportunity
Target context
Problem validation
Existing alternatives
Desired outcomes
Constraints
```

---

# 100. S2 — Business Transformation Discovery

Focus قوي على:

```text
Current Operations
Processes
Roles
Manual Work
Controls
Systems
Data
Handoffs
Exceptions
Bottlenecks
```

---

# 101. S3 — Existing Product Discovery

Focus:

```text
Current Product Behavior
User Feedback
Analytics
Known Defects
Architecture Constraints
Support Issues
Usability
Product Gaps
Business Fit
```

---

# 102. S4 — Implementation in Progress Discovery

Focus:

```text
Original Intent
Current Scope
Requirements Quality
Design State
Implementation State
Delivery Gaps
Stakeholder Expectations
Deviation
```

---

# 103. S5 — Recovery Discovery

Focus:

```text
Failure Modes
Immediate Exposure
What Changed
What Is Broken
Business Consequence
Technical Consequence
Ownership
Previous Decisions
Recovery Constraints
```

Recovery Discovery قد يبدأ بعد containment.

---

# 104. S6 — Evolution Discovery

Focus:

```text
Change Intent
Existing Capability
Observed Limitation
Requested Improvement
Affected Users
Impact
Dependencies
Regression Risk
```

---

# 105. External Research Branch

Discovery قد يحتاج external research.

Examples:

```text
Market
Regulation
Industry practices
Competitor behavior
Technology feasibility
Standards
```

أي External Research يجب أن يسجل كSource.

عندما يرتبط research بـactivation trigger، يجب ربط الـSource والنتيجة بالـentry المقابلة في `GOV-009`.

---

# 106. Research Classification

```text
PRIMARY
SECONDARY
REFERENCE
UNVERIFIED
```

Research لا يتحول تلقائيًا إلى Requirement.

---

# 107. Competitive Research Boundary

Competitor لديه Feature لا يعني:

```text
We need the feature.
```

يصبح:

```text
MARKET_OBSERVATION
```

ثم يتم تقييم relevance.

---

# 108. User Research Boundary

مستخدم واحد يقول:

```text
I want dark mode.
```

لا يصبح:

```text
USER NEED = DARK MODE
```

قد يكون preference.

Discovery تبحث عن الحاجة الأساسية.

---

# 109. Need vs Preference

```text
NEED
```

ضروري لتحقيق Outcome.

```text
PREFERENCE
```

طريقة مرغوبة لتحقيقه.

---

# 110. Stakeholder Need Record

```yaml
need_id: NEED-013

stakeholder:
  STK-009

statement:
  "Needs immediate confirmation that stock was reserved."

type:
  OPERATIONAL_NEED

evidence:
  - SRC-022
```

---

# 111. Problem vs Requirement

Problem:

```text
Orders can be released without stock validation.
```

Requirement لاحقًا قد يكون:

```text
System MUST validate stock availability before release.
```

لا يجب إنشاء الثاني تلقائيًا أثناء Discovery.

---

# 112. Problem-to-Outcome Chain

Canonical chain:

```text
SYMPTOM
   ↓
PROBLEM
   ↓
IMPACT
   ↓
CAUSE
   ↓
DESIRED OUTCOME
```

ثم لاحقًا:

```text
OUTCOME
   ↓
CAPABILITY
   ↓
REQUIREMENT
```

---

# 113. Discovery Traceability Graph

```text
SOURCE
  ↓
FACT
  ↓
CURRENT STATE
  ↓
SYMPTOM
  ↓
PROBLEM
  ↓
IMPACT
  ↓
CAUSE
  ↓
OUTCOME
  ↓
SCOPE HYPOTHESIS
```

---

# 114. Mandatory Trace Relationships

Minimum:

```text
PRB → SOURCE
PRB → IMPACT
OUT → PRB or OPP
CAUSE → PRB
SCOPE-HYPOTHESIS → PRB/OUT/OPP
```

---

# 115. Orphan Problem

Problem بدون Evidence أو Source:

```text
ORPHAN_PROBLEM
```

ويحتاج review.

---

# 116. Orphan Outcome

Outcome لا يرتبط بأي Problem أو Opportunity:

```text
ORPHAN_OUTCOME
```

ويحتاج justification.

---

# 117. Question Engine in Discovery

Phase 01 تستخدم نفس adaptive philosophy.

لكن Questions أعمق.

Priority:

```text
Root uncertainty
Impact uncertainty
Process ambiguity
Authority conflict
Outcome ambiguity
Constraint ambiguity
Solution detail
```

---

# 118. Discovery Question Types

```text
CONTEXT
CURRENT_STATE
PROBLEM
CAUSE
IMPACT
OUTCOME
PROCESS
EXCEPTION
CONSTRAINT
AUTHORITY
DATA
EVIDENCE
PRIORITY
```

---

# 119. Good Discovery Question

```text
What happens after an order is submitted if the requested stock is not available?
```

أفضل من:

```text
Do you want back-order functionality?
```

الأول يكتشف الواقع.

الثاني يقترح feature.

---

# 120. Another Good Question

```text
Who currently decides whether an order may proceed when the credit limit is exceeded?
```

أفضل من:

```text
Should the ERP have a credit approval workflow?
```

---

# 121. Question Economy

AI يجب أن يفضل السؤال الذي يحل عدة uncertainties مترابطة.

لكن لا يجمع عشرة موضوعات مستقلة في سؤال واحد.

---

# 122. Discovery Interviews

Interview يمكن أن يكون:

```text
EXECUTIVE
DOMAIN
USER
PROCESS
TECHNICAL
CONTROL
```

كل واحد له هدف مختلف.

---

# 123. Interview Rule

لا تسأل كل stakeholder نفس questionnaire.

CEO ليس الشخص المناسب لشرح:

```text
كيف الموظف يعدل stock line عند وجود damaged quantity؟
```

وموظف warehouse ليس الشخص المناسب لتحديد strategic investment priority.

---

# 124. Observation

في operational environments، observation قد تكون أقوى من interview.

مثال:

Stakeholder:

```text
We always follow approval workflow.
```

Observation:

```text
Three urgent orders bypassed it.
```

كلاهما يتم حفظه.

---

# 125. Discovery Risk Signals

Phase 01 قد ترفع Risk Class إذا ظهرت:

```text
Financial controls
Personal/sensitive data
Legal obligations
Ownership/governance
Safety implications
Critical infrastructure
Irreversible actions
Privileged access
Cross-border data
Regulated workflow
```

---

# 126. Risk Escalation

إذا ظهرت معلومة جديدة:

```text
P2 / R2
```

قد تصبح:

```text
P2 / R3
```

بدون تغيير Delivery Profile بالضرورة.

---

# 127. Profile Reassessment

Phase 01 يجوز لها اقتراح:

```text
P1 → P2
P2 → P3
```

أو العكس.

لكن يتطلب:

```text
RATIONALE
```

---

# 128. Commercial Impact Separation

إذا Discovery كشفت scope أكبر من Engagement contract:

Product OS يسجل:

```text
METHODOLOGY_NEED
```

و:

```text
COMMERCIAL_SCOPE
```

بشكل منفصل.

لا يتم إخفاء حاجة المشروع لأن العقد أصغر.

ولا يتم تنفيذ scope إضافي تلقائيًا.

---

# 129. Phase 01 Artifact Catalog

## DISC-001 — Discovery Plan

Defines:

```text
Objectives
Scope
Stakeholders
Sources
Methods
Expected Outputs
```

---

## DISC-002 — Discovery Findings

Consolidated findings.

---

## DISC-003 — Stakeholder Map

Stakeholders + authority + impact.

---

## DISC-004 — Current-State Model

Current operational/product context.

---

## DISC-005 — Problem Register

Symptoms, problems, impacts, evidence.

---

## DISC-006 — Cause & Hypothesis Register

Cause lifecycle and evidence.

---

## DISC-007 — Outcome & Success Model

Desired outcomes and success signals.

---

## DISC-008 — Scope Hypothesis

Preliminary focus boundary.

---

## DISC-009 — Discovery Validation Record

Evidence that findings were reviewed.

---

# 130. Governance Registers Updated

Phase 01 updates:

```text
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-007 Change Register
GOV-009 Standards & Compliance Applicability Matrix
```

Phase 01 لا تنشئ نسخة ثانية من `GOV-009`؛ تضيف evidence وtrigger validation وowners وopen questions وdownstream route إلى نفس الـregister الذي بدأ في Phase 00.

---

# 131. Product Brief Handling

`INIT-001 Product / Project Brief`

يبقى immutable baseline نسبيًا.

Discovery لا تعيد كتابته بالكامل.

إذا اتغير فهمنا جذريًا:

```text
INIT-001 → STALE / UPDATED
```

مع Change History.

---

# 132. Discovery Findings Structure

Suggested:

```text
Executive Discovery Summary

Current State

Stakeholders

Symptoms

Problems

Impacts

Supported Causes

Assumptions

Constraints

Dependencies

Previous Attempts

Workarounds

Desired Outcomes

Success Signals

Opportunities

Scope Hypothesis

Risks

Open Questions

Validation

Downstream Handoff
```

---

# 133. G1 — Problem Understood Gate

الغرض:

> التأكد أن Product OS يفهم المشكلة والنتيجة المطلوبة بدرجة كافية تسمح بتحويلها إلى Business/Product definition بدون بناء حل لمشكلة غير مفهومة.

---

# 134. G1-01 Current State Understood

Current State موثق بالعمق المناسب.

ليس مطلوبًا Full Organization Model.

---

# 135. G1-02 Primary Problems Defined

المشاكل الأساسية:

```text
Explicit
Evidence-backed
Separated from solutions
```

---

# 136. G1-03 Symptoms Distinguished

Symptoms لا يتم تقديمها كRoot Causes.

---

# 137. G1-04 Impacts Understood

كل Critical/High Problem يحتاج material impact.

---

# 138. G1-05 Causes Handled

على الأقل:

```text
Supported Cause
```

أو:

```text
Cause Unresolved and explicitly recorded
```

لا يسمح بـFalse Root Cause.

---

# 139. G1-06 Stakeholder Coverage

الأطراف الضرورية تم تمثيلها بدرجة كافية.

---

# 140. G1-07 Desired Outcomes Defined

يجب معرفة:

> ما الذي يجب أن يتحسن؟

وليس فقط:

> ماذا يريد العميل أن نبني؟

---

# 141. G1-08 Success Direction Defined

Major outcomes لها success signal على الأقل.

---

# 142. G1-09 Constraints Validated

Critical constraints تم تأكيدها أو تصنيفها كuncertain.

---

# 143. G1-10 Major Dependencies Known

dependencies التي تؤثر على المرحلة التالية معروفة.

---

# 144. G1-11 Critical Conflicts Resolved

لا يوجد conflict مفتوح يمنع بناء Business/Product definition.

---

# 145. G1-12 Discovery Blocking Questions

```text
Blocking Discovery Questions = 0
```

---

# 146. G1-13 Scope Hypothesis Exists

يوجد preliminary boundary للعمل التالي.

---

# 147. G1-14 Risk Reassessed

Risk Class تمت إعادة مراجعته بناءً على Discovery.

---

# 148. G1-15 Downstream Route Known

يعرف النظام ما إذا كانت المرحلة التالية:

```text
Business Architecture
Product Definition
Existing-System Gap Analysis
Recovery Planning
Feature Delta Definition
```

---

# 148A. G1-16 Standards Applicability Evidence Coverage

كل material activation trigger معروف تم التحقيق فيه بالعمق المناسب. كل entry غير محسومة في `GOV-009` تحمل `PENDING` مع evidence need وowner أو next-phase route. قرار business applicability النهائي ليس شرطًا لمرور G1 إلا إذا كان غيابه يمنع تحديد المشكلة أو المسار التالي بأمان.

---

# 149. G1 Outcomes

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

---

# 150. G1 PASS

المعلومات كافية للانتقال.

---

# 151. G1 PASS_WITH_CONDITIONS

يوجد unknown غير blocking.

Example:

```text
Exact yearly transaction volume is not yet confirmed.
```

إذا لا يمنع Business/Product Architecture.

---

# 152. G1 HOLD

Examples:

```text
No agreement on what problem is being solved.
```

أو:

```text
Critical stakeholders provide contradictory current-state descriptions.
```

أو:

```text
Primary business owner has not been identified and scope authority is impossible to establish.
```

---

# 153. G1 REJECT

يستخدم عندما:

- need disappeared;
- project cancelled;
- issue is outside Product OS scope;
- evidence shows no meaningful problem/opportunity;
- another non-product intervention is explicitly selected.

مثال:

Discovery قد تكشف أن:

```text
Problem = Missing employee training
```

ولا يحتاج software change.

ده نجاح للDiscovery وليس failure.

---

# 154. Non-Software Outcome

Product OS يجب أن يسمح بنتيجة:

```text
NO_PRODUCT_CHANGE_RECOMMENDED
```

إذا Evidence يشير أن الحل الأفضل:

- process change;
- policy change;
- training;
- organizational change;
- vendor contract change.

---

# 155. Discovery Stop Rule

Discovery تنتهي عندما:

```text
Decision Risk of Continuing
<
Cost of Additional Discovery
```

مفاهيميًا.

ليس مطلوب حساب رقمي.

المعنى:

إذا مزيد من discovery لن يغير الاتجاه بشكل material، نتحرك.

---

# 156. Discovery Overrun Signal

علامات over-discovery:

```text
Questions no longer affect decisions
Same findings repeated
No new high-value uncertainty closed
Stakeholders are discussing implementation detail
Requirements are being written prematurely
```

---

# 157. G1 Evidence Record

```yaml
gate_id: G1

outcome: PASS_WITH_CONDITIONS

checks:
  current_state: PASS
  primary_problem: PASS
  impact: PASS
  cause_analysis: PASS
  stakeholder_coverage: PASS
  outcomes: PASS
  scope_hypothesis: PASS
  standards_applicability_evidence: PASS
  blocking_questions: PASS

conditions:
  - "Detailed financial baseline to be confirmed during Business Architecture."

evidence:
  - DISC-002
  - DISC-003
  - DISC-004
  - DISC-005
  - DISC-007
  - GOV-009

approved_by:
  - PRODUCT_ANALYST
  - BUSINESS_AUTHORITY
```

---

# 158. Phase Handoff Contract

Phase 01 handoff must provide:

```text
Validated Current State
Primary Stakeholders
Primary Problems
Problem Priority
Impacts
Cause Status
Constraints
Dependencies
Desired Outcomes
Success Signals
Opportunities
Scope Hypothesis
Risks
Standards / Compliance Triggers and Evidence
GOV-009 Evidence and Pending Decisions
Open Questions
Decision Gaps
G1 Result
Next Route
```

---

# 159. Machine-Readable Handoff

Conceptual:

```yaml
phase_handoff:

  from_phase: PHASE-01

  discovery:
    status: COMPLETE

  current_state:
    - CURRENT-001
    - CURRENT-002

  stakeholders:
    - STK-001
    - STK-004

  symptoms:
    - SYM-001

  problems:
    - PRB-001
    - PRB-003

  causes:
    - cause_id: CAUSE-001
      status: SUPPORTED

  outcomes:
    - OUT-001
    - OUT-002

  opportunities:
    - OPP-001

  constraints:
    - CON-003

  dependencies:
    - DEP-005

  scope_hypothesis:
    artifact: DISC-008

  risks:
    class:
      value: R3
      status: REVIEWED

  standards_applicability:
    register: GOV-009
    evidence_reviewed:
      - GOV-009-ENTRY-001
    pending_business_decisions:
      - GOV-009-ENTRY-002

  open_questions:
    blocking: []
    downstream:
      - OQ-019

  gate:
    id: G1
    outcome: PASS

  next_route:
    phase: PHASE-02
    mode: BUSINESS_ARCHITECTURE
```

---

# 160. Validation Rules

## VAL-01-001

Problem Statement يجب ألا يكون مجرد absence of solution.

---

## VAL-01-002

كل Problem يحتاج Source أو Evidence.

---

## VAL-01-003

كل Problem يحتاج Impact.

---

## VAL-01-004

كل Root Cause يحتاج Evidence Status كافٍ.

---

## VAL-01-005

Cause Hypothesis لا يصنف كvalidated cause تلقائيًا.

---

## VAL-01-006

كل Outcome يجب أن يرتبط Problem أو Opportunity.

---

## VAL-01-007

كل Scope Hypothesis item يحتاج rationale.

---

## VAL-01-008

Solution Idea لا تصبح Scope تلقائيًا.

---

## VAL-01-009

Stakeholder preference لا تصبح business need تلقائيًا.

---

## VAL-01-010

Competitor feature لا تصبح Requirement.

---

## VAL-01-011

Documented process لا يعتبر Actual Process بدون تقييم.

---

## VAL-01-012

Conflicting stakeholder claims لا يتم دمجها في statement غامض يخفي الاختلاف.

---

## VAL-01-013

Unknown Cause لا يمنع G1 دائمًا إذا المشكلة والنتيجة معروفتان ويمكن التحرك بأمان.

---

## VAL-01-014

Major Outcome يجب ألا يكون مجرد Feature.

---

## VAL-01-015

Discovery لا تنتج Formal Functional Requirements.

---

## VAL-01-016

G1 لا يمر مع Discovery-level blocker مفتوح.

---

## VAL-01-017

P/R classifications يجب إعادة تقييمها قبل G1.

---

## VAL-01-018

Non-software resolution يجب أن يبقى خيارًا صالحًا.

---

## VAL-01-019

Standard أو profile أو external research finding لا يصبح requirement أو approved applicability decision تلقائيًا؛ missing evidence يجب أن يبقى ظاهرًا في `GOV-009`.

---

# 161. AI Responsibilities

AI MAY:

- analyze source material;
- identify possible symptoms;
- propose problem statements;
- identify cause hypotheses;
- map stakeholder views;
- identify contradictions;
- identify workarounds;
- identify process friction;
- calculate simple quantitative impacts from provided data;
- suggest discovery questions;
- build traceability;
- suggest outcomes;
- suggest possible success measures;
- detect solution contamination;
- identify unsupported scope;
- validate and enrich standards/compliance activation triggers;
- update `GOV-009` evidence, ownership, and pending status;
- generate Discovery Handoff.

---

# 162. AI Must Label

أي AI-generated analytical conclusion يجب أن يكون واحدًا من:

```text
PROPOSED
INFERRED
SUPPORTED
VALIDATED
```

حسب الحالة.

---

# 163. AI Prohibitions

AI MUST NOT:

- invent Root Cause;
- invent metrics;
- invent stakeholder consensus;
- promote one stakeholder opinion above another without authority/evidence;
- convert feature request into need;
- convert solution idea into requirement;
- assume correlation means causation;
- hide unresolved conflicts;
- claim validation without evidence;
- declare project viable commercially;
- choose architecture;
- approve final business applicability;
- convert standards research directly into a requirement;
- close `GOV-009` pending entries without evidence and authority;
- define final MVP;
- close G1 without required evidence.

---

# 164. Human Responsibilities

Humans remain responsible for:

```text
Business truth
Domain interpretation
Authority decisions
Problem priority
Outcome priority
Scope decisions
Risk acceptance
Standards/compliance business applicability decisions in the owning phase
Conflict resolution
Discovery approval
```

---

# 165. Product Analyst Responsibility

Product Analyst / Consultant is responsible for the integrity of:

```text
Problem framing
Evidence quality
Discovery completeness
Question quality
Traceability
False certainty avoidance
```

---

# 166. Business Authority Responsibility

Business Authority confirms:

```text
Business relevance
Problem significance
Desired outcomes
Priority
Material policy interpretation
```

---

# 167. Domain Owner Responsibility

Domain Owner confirms:

```text
Actual process
Exceptions
Operational reality
Terminology
Constraints
```

---

# 168. Technical Stakeholder Role

Technical stakeholders contribute:

```text
Existing system reality
Technical limitations
Integration constraints
Data limitations
Operational incidents
```

لكن لا يحولون technology preference إلى business need.

---

# 169. Discovery Anti-Patterns

## AP-01 — The Client Said It

```text
Client said X
therefore X is true.
```

مرفوض.

---

## AP-02 — Solution-Led Discovery

السؤال كله:

```text
What features should the ERP contain?
```

هذا requirements collection رديء، وليس Discovery.

---

## AP-03 — CEO-Only Discovery

تحديد operational workflow من management interviews فقط.

---

## AP-04 — User-Only Discovery

تجاهل finance/security/governance لأن المستخدمين لا يتعاملون معهم مباشرة.

---

## AP-05 — Root-Cause Theatre

تشغيل 5 Whys مرة واحدة ثم كتابة:

```text
ROOT CAUSE IDENTIFIED
```

بثقة مسرحية.

---

## AP-06 — Process Documentation Addiction

رسم 200 process فقط لأن BPMN جميل.

---

## AP-07 — Metric Fabrication

تحويل:

```text
Reports are slow.
```

إلى:

```text
Reports take 4.2 hours.
```

بدون Source.

---

## AP-08 — Feature Inflation

كل stakeholder interview يضيف 20 feature.

---

## AP-09 — Competitor Cloning

```text
Competitor has feature
→ We need feature
```

---

## AP-10 — Consensus Washing

تحويل الخلاف إلى wording عام حتى يبدو الجميع متفقًا.

---

## AP-11 — Problem = Missing Software

```text
We don't have CRM.
```

ليس تشخيصًا.

---

## AP-12 — Happy-Path Discovery

فهم Standard Process فقط وتجاهل exceptions التي تستهلك 60% من العمل.

---

## AP-13 — Discovery Forever

لا توجد Stop Rule.

---

## AP-14 — Early Architecture

Discussion يتحول إلى:

```text
PostgreSQL vs MongoDB
```

قبل أن نعرف لماذا النظام موجود أصلًا.

---

## AP-15 — Standards Research Promotion

تحويل Standard أو regulation أو accessibility finding مباشرة إلى approved requirement، أو تجاهل trigger لأنه لم يتحول بعد إلى requirement.

---

# 170. Discovery Quality Measures

Future Product OS can track:

```text
Problem Evidence Coverage
Stakeholder Coverage
Cause Validation Rate
Orphan Outcome Count
Unsupported Scope Count
Question Efficiency
Conflict Closure Rate
Discovery Reopen Rate
Downstream Requirement Reversal Rate
Problem-to-Requirement Traceability
Standards Trigger Evidence Coverage
Pending GOV-009 Ownership Coverage
```

---

# 171. Important Quality Metric

واحد من أهم Metrics:

```text
Downstream Invalid Requirement Rate
```

أي:

> كم Requirement تم إلغاؤه لاحقًا لأن Discovery الأصلية فهمت المشكلة غلط؟

إذا الرقم مرتفع، المشكلة ليست في Requirements team.

المشكلة بدأت هنا.

---

# 172. Discovery Reopening

Phase 01 تعاد جزئيًا إذا:

```text
New evidence contradicts primary problem
Major stakeholder appears late
Primary process changes
Business objective changes
Risk changes materially
Scope changes materially
Underlying assumption is invalidated
New evidence changes a material `GOV-009` trigger or invalidates its evidence basis
```

---

# 173. Reopen States

```text
DISCOVERY_REVIEW_REQUIRED
PARTIAL_REDISCOVERY
FULL_REDISCOVERY
```

---

# 174. Change Propagation

Example:

```text
PRB-004 changes materially
        ↓
OUT-003 review
        ↓
SCOPE-HYP-002 stale
        ↓
Business Architecture review
        ↓
Capabilities affected
        ↓
Requirements potentially stale
```

Standards-related change propagation:

```text
SOURCE / DISCOVERY EVIDENCE changes
        ↓
GOV-009 entry becomes REVIEW_REQUIRED
        ↓
Phase 02 business applicability and downstream implications reviewed
```

---

# 175. Discovery Versioning

Approved Discovery baseline receives version:

```text
DISCOVERY-BASELINE-1.0
```

Changes after G1 require:

```text
Change Record
Impact Analysis
New Version
```

---

# 176. Discovery Completion Contract

## Required Inputs

```text
G0-approved Intake Context
Sources
Authority Context
Initial Problem
Initial Outcomes
Initial Constraints
Phase 00 Activation Triggers and Preliminary GOV-009 Entries
```

---

## Required Questions

Phase 01 must be able to answer:

```text
What is happening now?

Who is affected?

What symptoms are observed?

What are the actual problems?

What impact do those problems create?

What evidence supports them?

What may be causing them?

What causes are actually supported?

What has already been tried?

What workarounds exist?

What outcome is desired?

How could success be recognized?

What constraints matter?

What dependencies matter?

Which standards/compliance activation triggers are supported, contradicted, or still pending?

What remains unknown?

What area should the next phase focus on?
```

---

# 177. Required Decisions

At minimum:

```text
Primary Problem Set
Problem Priority
Desired Outcome Set
Discovery Scope Completion
Scope Hypothesis
Risk Reassessment
GOV-009 Evidence Readiness for Phase 02
Next Route
G1 Outcome
```

---

# 178. Exit Criteria

Phase 01 complete when:

1. Current State understood sufficiently.
2. Primary stakeholders covered.
3. Primary symptoms captured.
4. Problems explicitly defined.
5. Material impacts understood.
6. Cause status explicit.
7. Key constraints validated.
8. Key dependencies identified.
9. Desired outcomes defined.
10. Success direction defined.
11. Major conflicts resolved.
12. Scope Hypothesis created.
13. Blocking questions = 0.
14. Risk reassessed.
15. Material triggers investigated and `GOV-009` updated with evidence, owners, and pending decisions.
16. G1 evaluated, including G1-16.
17. Downstream Handoff generated.

---

# 179. Phase 01 Final Transformation

Phase 01 transforms:

```text
"We need a system because things are messy."
```

into:

```text
CURRENT STATE
+
EVIDENCE
+
STAKEHOLDERS
+
SYMPTOMS
+
PROBLEMS
+
IMPACTS
+
SUPPORTED CAUSES
+
OUTCOMES
+
SUCCESS SIGNALS
+
CONSTRAINTS
+
STANDARDS / COMPLIANCE APPLICABILITY EVIDENCE
+
GOV-009 PENDING DECISION HANDOFF
+
SCOPE HYPOTHESIS
```

---

# 180. Final Methodology Principle

```text
Discovery must not tell us what the stakeholder wants built.

Discovery must tell us what condition needs to change,
why changing it matters,
what evidence supports that conclusion,
and what outcome deserves investment.
```

Only after that does Product OS earn the right to start defining the business and the product.

---

# 181. Phase 01 Output

```text
UNSTRUCTURED NEED
       ↓
DISCOVERY
       ↓
VALIDATED PROBLEM MODEL
       ↓
STANDARDS-ENRICHED DISCOVERY BASELINE
       ↓
G1 — PROBLEM UNDERSTOOD
       ↓
BUSINESS / PRODUCT DEFINITION
```

**Phase 00 ensured we entered the correct project.**

**Phase 01 ensures we are solving the correct problem.**
