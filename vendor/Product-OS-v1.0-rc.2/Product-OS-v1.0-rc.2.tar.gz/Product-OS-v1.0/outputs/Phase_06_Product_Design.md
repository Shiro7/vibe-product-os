# Product OS v1.0 — Methodology Specification
## Phase 06: Product Design

**Phase ID:** `PHASE-06`  
**Phase Name:** `Product Design`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G4B — Design Baseline`  
**Primary Baseline:** `DBL — Design Baseline`  
**Primary Outcome:** تحويل الـapproved Experience Baseline إلى visual and interaction design system متكامل وقابل للتنفيذ والتحقق، يغطي الـfoundations والـtokens والـcomponents والـscreens والـstates والـresponsive والـaccessibility والـlocalization/RTL والـmotion والـprototype والـdesign-to-code handoff بدون تغيير product أو requirements أو experience logic بصمت.

---

# 1. Purpose

الغرض من Phase 06 هو الانتقال من:

```text
The experience must provide this journey, flow, state,
interaction, content responsibility, and recovery behavior.
```

إلى:

```text
How will that approved experience be visually structured,
expressed through reusable components and tokens,
adapted across platforms, languages, directions, and states,
and handed to implementation without ambiguity?
```

Phase 06 تنشئ **Design Baseline** يربط:

```text
Experience Object
→ Design Subject
→ Foundation / Token
→ Component / Pattern
→ Screen / State / Variant
→ Prototype
→ Design Specification
→ Code Mapping / Verification Expectation
```

---

# 2. Position in Product OS

```text
PHASE 04 — REQUIREMENTS ENGINEERING
                │
                ▼
       G3B — REQUIREMENTS BASELINE
                │
                ▼
PHASE 05 — EXPERIENCE ARCHITECTURE
                │
                ▼
       G4A — EXPERIENCE BASELINE
                │
                ▼
PHASE 06 — PRODUCT DESIGN
                │
                ▼
       G4B — DESIGN BASELINE
                │
       ┌────────┴────────┐
       ▼                 ▼
PHASE 07             PHASE 08
SOLUTION             ENGINEERING
ARCHITECTURE         READINESS
       └────────┬────────┘
                ▼
        IMPLEMENTATION
```

Phase 06 لا تعمل بمعزل عن Solution Architecture، لكن كل phase تحافظ على ownership الخاص بها.

---

# 3. Core Product Design Question

> **How must the approved experience be visually and interactively realized so that every supported user, state, platform, language, and requirement is clear, consistent, accessible, and implementation-ready?**

ثم:

> **What design evidence and source mapping prove that nothing material was omitted or invented?**

---

# 4. Product Design Philosophy

Product OS Product Design يعتمد على المبادئ التالية.

## PDES-01 — Design Realizes, It Does Not Redefine

Phase 06 لا تغير journey أو flow أو state أو requirement داخل screen.

أي gap يعود إلى phase المالكة.

---

## PDES-02 — Systems Before Screens

Foundations, semantic tokens, components, patterns, and state rules تسبق تكاثر screens.

---

## PDES-03 — Screens Prove the System

Design System غير مستخدم داخل actual product screens ليس product adoption.

Screens تكشف هل الـcomponents والـtokens والـpatterns صالحة فعليًا.

---

## PDES-04 — Every State Is Designed

Happy-path frame لا يمثل product design كاملًا.

Loading, empty, error, permission, conflict, offline, processing, unknown outcome, success, interruption, and recovery تحتاج تصميمًا أو rule مثبتة.

---

## PDES-05 — Accessibility Is Visual and Behavioral

Contrast وحده لا يكفي.

Focus, semantics, target size, reflow, zoom, motion, forms, errors, content order, and assistive-technology behavior جزء من design contract.

---

## PDES-06 — Responsive Means Recomposition

Responsive design يعيد ترتيب الأولويات والعلاقات عند الحاجة.

لا يكتفي بتصغير desktop frame.

---

## PDES-07 — RTL Is a Native Mode

Arabic/RTL ليست mirror pass نهائية.

يجب أن تؤثر منذ tokens, components, icons, grids, focus order, mixed content, and screen composition.

---

## PDES-08 — Semantic Tokens Over Raw Values

```text
color.action.primary
```

أفضل من نشر:

```text
#276EF1
```

داخل عشرات components.

---

## PDES-09 — Reuse Without Forced Uniformity

Reusable system يحافظ على consistency، لكنه يسمح product-specific patterns عندما توجد حاجة مثبتة.

---

## PDES-10 — Content Is Designed

Final labels, messages, truncation, wrapping, dynamic values, and localization are designed—not pasted later.

---

## PDES-11 — Source of Truth Must Be Explicit

Team must know:

```text
Which file/library/component is canonical?
Which instances are adopted?
Which variants are approved?
Which designs are obsolete?
Which version implementation follows?
```

---

## PDES-12 — Prototype Is Evidence, Not Production

Prototype proves design/journey hypotheses at selected fidelity.

It does not prove architecture, security enforcement, performance, or implementation quality.

---

# 5. Phase Objectives

بنهاية Phase 06 يجب أن يكون Product OS قادرًا على:

1. تحديد Product Design Direction المتسقة مع brand/product context.
2. تثبيت Design Principles and visual constraints.
3. إنشاء Design Foundations.
4. إنشاء semantic Design Token model.
5. تحديد typography system للغات/scripts المدعومة.
6. تحديد color and theme system مع contrast evidence.
7. تحديد spacing, grid, layout, density, radius, border, elevation, and layering rules.
8. تحديد iconography and product asset system.
9. إنشاء reusable Component System.
10. تحديد component variants, sizes, states, content, responsiveness, and accessibility.
11. إنشاء Product Pattern Catalog.
12. تصميم جميع views/screens المطلوبة في Experience Baseline.
13. تصميم جميع material UX states.
14. تصميم forms, data-dense views, navigation, search, filters, bulk actions, notifications, and sensitive actions.
15. تثبيت final content/message presentation and dynamic-content rules.
16. تصميم responsive and cross-platform variants.
17. تصميم localization and RTL modes.
18. تحقيق Accessibility Experience Specification بصريًا وسلوكيًا.
19. تحديد motion and transition specification.
20. تصميم generated documents, email/notification surfaces, and third-party continuity where applicable.
21. إنشاء high-fidelity prototype بالـcoverage المناسب.
22. التحقق من usability, accessibility, RTL, responsive behavior, and design coherence.
23. إدارة design source, library, version, adoption, and deprecation.
24. بناء design traceability إلى `REQ` و`EXP` و`GOV-009`.
25. تحديث `GOV-009` بالـdesign objects and evidence expectations.
26. إنشاء design-to-code mapping and handoff.
27. إنشاء versioned Design Baseline.
28. تمرير `G4B — Design Baseline`.

---

# 6. Phase Inputs

Required logical inputs:

```text
Product Brand / Identity Sources where applicable
PROD-001 Product Vision & Mission
PROD-002 Product Scope & Boundary
PROD-004 Product User & Role Model
PROD-005 Product Capability Map
PROD-006 Product Domain & Module Map
PROD-008 Product State & Lifecycle Model
PROD-009 Product Policy & Constraint Register
PROD-011 MVP & Release Scope
REQ-001 System Requirements Specification
REQ-002 Requirement Catalog and Index
REQ-007 Security and Privacy Requirements
REQ-008 Accessibility Requirements
REQ-010 Acceptance and Verification Matrix
REQ-011 Requirements Traceability Matrix
EXP-001 Experience Architecture Blueprint
EXP-002 Experience Principles and Constraints
EXP-003 Experience Actor, Goal, and Context Model
EXP-004 Experience Scenario Catalog
EXP-005 Journey Catalog
EXP-006 Experience Flow Catalog
EXP-007 Information Architecture
EXP-008 Navigation and Context Model
EXP-009 View, Screen, Route, and Entry-Point Inventory
EXP-010 UX State Catalog
EXP-011 Error, Safety, Interruption, and Recovery Model
EXP-012 Interaction Behavior Specification
EXP-013 Content and Message Model
EXP-014 Responsive and Cross-Platform Experience Model
EXP-015 Accessibility Experience Specification
EXP-016 Localization and RTL Experience Specification
EXP-017 Structural Wireframes / Flow Prototype where used
EXP-018 Experience Coverage and Traceability Matrix
EXP-019 Experience Validation Record
EXP-020 Product Design Handoff
G4A Decision
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated Conditional Profiles
Existing Design System / Product UI / Design Evidence where applicable
```

---

# 7. Entry Condition

Phase 06 تبدأ عندما:

```text
G4A = PASS
```

أو:

```text
G4A = PASS_WITH_CONDITIONS
```

بشرط أن الـconditions لا تجبر Product Design على اختراع journey أو state أو content meaning أو authorization behavior.

Minimum entry:

```text
Blocking Experience Questions = 0
Blocking Experience Decisions = 0
Blocking Validation Findings = 0
View/Screen/Route inventory is usable
State and variant expectations are identifiable
Accessibility/RTL/responsive obligations are identifiable
GOV-009 Phase 06 obligations are explicit
```

---

# 8. What Phase 06 Is Not

Phase 06 ليست:

- Product Strategy.
- Product Scope Definition.
- Requirements Engineering.
- Experience Architecture.
- Business Process redesign.
- Authorization policy creation.
- Solution Architecture.
- API specification.
- Database design.
- Frontend code implementation.
- Production component implementation.
- Marketing website design unless in product scope.
- Corporate rebrand unless explicitly activated.
- Engineering task planning.
- Final production accessibility verification.
- Release approval.

Phase 06 قد تكشف gaps upstream أو technical feasibility concerns، لكنها لا تحلها بتغيير المعنى بصمت.

---

# 9. Phase 05 vs Phase 06

## Phase 05 Decides

```text
Goal
Journey
Flow
IA
Navigation
Context
View / Route
State responsibility
Interaction behavior
Content meaning
Error / Recovery
Responsive priority
Accessibility behavior
Localization / RTL behavior
```

## Phase 06 Decides

```text
Visual direction
Layout and hierarchy
Tokens
Typography
Color and theme
Spacing and grid
Components and variants
Patterns
Detailed state presentation
Content presentation
Responsive composition
RTL visual realization
Focus visual treatment
Motion
High-fidelity prototype
Design annotations and handoff
```

---

# 10. Phase 06 vs Design System Workstream

Product Design may create or update a Design System.

But it must distinguish:

```text
Foundational system work
Reusable library source
Product-specific extensions
Product adoption in actual screens
Experimental candidates
Deprecated assets
```

Library existence does not prove product adoption.

---

# 11. Product Design Object Model

Canonical logical objects:

```text
Design Principle
Design Direction
Design Foundation
Primitive Token
Semantic Token
Component Token
Theme / Mode
Typography Role
Color Role
Layout / Grid Rule
Density Rule
Icon / Asset
Component
Component Property
Component Variant
Component State
Component Slot
Product Pattern
Screen / View Design
Screen State Design
Responsive Variant
Localization / RTL Variant
Content Design Object
Motion Rule
Document / Notification Design
Prototype
Design Annotation
Design Decision
Design Source Reference
Design Validation Evidence
Design-to-Code Mapping
```

---

# 12. Canonical Design IDs

Recommended:

```text
DPR-001      Design Principle
DDIR-001     Design Direction
DFND-001     Design Foundation
TOK-001      Design Token
THEME-001    Theme / Mode
TYP-001      Typography Role
CLR-001      Color Role
LAY-001      Layout / Grid Rule
DNS-001      Density Rule
AST-001      Icon / Asset
CMP-001      Component
CPROP-001    Component Property
CVR-001      Component Variant
CST-001      Component State
CSLOT-001    Component Slot
PAT-001      Product Pattern
DSCR-001     Screen / View Design
DSTATE-001   Screen State Design
DRESP-001    Responsive Design Variant
DRTL-001     Localization / RTL Design Variant
DCNT-001     Content Design Object
MOT-001      Motion Rule
DDOC-001     Document / Notification Design
PROTO-001    Prototype
DANN-001     Design Annotation
DDEC-001     Design Decision
DSRC-001     Design Source Reference
DVAL-001     Design Validation Evidence
D2C-001      Design-to-Code Mapping
```

IDs remain stable across design-tool renaming when the logical object remains the same.

---

# 13. Design Object Lifecycle

Canonical lifecycle:

```text
CAPTURED
PROPOSED
EXPLORING
IN_REVIEW
VALIDATED
APPROVED
PUBLISHED
ADOPTED
BASELINED
DEPRECATED
SUPERSEDED
RETIRED
REJECTED
```

`PUBLISHED` and`ADOPTED` are distinct.

---

# 14. Published vs Adopted

```text
PUBLISHED
→ Available in the design library.

ADOPTED
→ Used by approved product designs within baseline scope.
```

A component may be published butnot adopted anywhere.

---

# 15. Design Approval Status

```text
NOT_REQUIRED
PENDING
APPROVED
APPROVED_WITH_CONDITIONS
REJECTED
```

Approval is separate from lifecycle and verification status.

---

# 16. Design Verification Status

```text
NOT_REVIEWED
PARTIAL
VISUALLY_REVIEWED
ACCESSIBILITY_REVIEWED
RESPONSIVE_REVIEWED
RTL_REVIEWED
PROTOTYPE_VALIDATED
HANDOFF_VERIFIED
```

These do not claim production implementation conformance.

---

# 17. Design Principle

Design Principle guides repeated decisions.

Example:

```text
DPR-004 — Make current operational context more prominent than secondary navigation.
```

It must link to experience/product rationale.

---

# 18. Design Direction

Design Direction defines the intended product visual character and decision boundaries.

May include:

```text
Brand relationship
Tone
Information density
Visual hierarchy
Surface model
Use of color
Typography character
Icon/illustration approach
Motion character
Platform alignment
Accessibility constraints
```

---

# 19. Design Direction Sources

```text
Brand identity
Product vision
Target context
User environment
Platform
Content density
Trust/safety needs
Accessibility
Localization/scripts
Competitive/market evidence
Existing product system
```

Visual trend alone is not source authority.

---

# 20. Direction Exploration

Phase 06 may compare multiple visual directions before approval.

Each direction should expose:

```text
Rationale
Tradeoffs
Representative components
Representative screen/state
Arabic/Latin behavior where applicable
Accessibility risks
Scalability into system
```

Moodboard alone cannot approve product design direction.

---

# 21. Brand Inheritance

Product Design should identify:

```text
Canonical brand assets
Protected brand rules
Product-specific freedom
Digital accessibility adjustments
Co-brand/white-label needs
Theme/market variants
Asset licensing/source
```

---

# 22. Brand vs Product UI

Brand establishes identity and expression.

Product UI must also satisfy:

```text
Task clarity
Density
States
Accessibility
Responsiveness
Localization
System consistency
Engineering feasibility
```

Brand aesthetics cannot override these obligations.

---

# 23. Design Foundation

Foundation includes reusable design rules beneath components:

```text
Color
Typography
Spacing
Sizing
Grid
Breakpoints / layout modes
Radius
Borders
Elevation / layering
Opacity
Iconography
Motion
Focus
Density
```

---

# 24. Design Token

Token is a named design decision intended for consistent reuse and technical mapping.

```yaml
token_id: TOK-COLOR-ACTION-PRIMARY
name: color.action.primary
level: SEMANTIC
value_by_mode:
  light: "{color.blue.600}"
  dark: "{color.blue.300}"
purpose: "Primary interactive action"
applies_to:
  - CMP-BUTTON
  - CMP-LINK
contrast_requirements:
  - ACC-CONTRAST-001
status: APPROVED
```

---

# 25. Token Layers

Recommended:

```text
PRIMITIVE
   ↓
SEMANTIC
   ↓
COMPONENT
```

Example:

```text
color.blue.600
→ color.action.primary
→ button.primary.background.default
```

---

# 26. Primitive Token

Primitive expresses raw scale/value:

```text
color.blue.600
space.400
radius.200
font.size.300
```

Product screens should prefer semantic/component tokens.

---

# 27. Semantic Token

Semantic token expresses purpose:

```text
color.text.primary
color.surface.critical
space.layout.section
focus.ring.color
```

It supports theme and future change.

---

# 28. Component Token

Use when a component needs controlled specialization not expressed safely by global semantic token.

Avoid creating component token for every pixel without reuse/change rationale.

---

# 29. Token Naming

Names should be:

```text
Purpose-based
Stable
Platform-neutral where possible
Hierarchical
Mode-aware
Readable in design and code
```

Avoid:

```text
blueButton
leftPadding
desktopOnlyGrey
```

when semantics may change.

---

# 30. Token Governance

Each token needs:

```text
Owner
Purpose
Level
Value/modes
Consumers
Accessibility constraints
Code mapping
Lifecycle
Change impact
```

---

# 31. Token Change

Changing semantic token may affect many screens/components.

Impact analysis must identify:

```text
Components
Themes
Contrast
States
Documents
Code variables
Visual regression scope
```

---

# 32. Token Anti-Explosion Rule

Create token when it represents reusable intent or controlled variability.

Do not tokenize arbitrary one-off values simply to reach a token count.

---

# 33. Theme / Mode

Theme may represent:

```text
Light / Dark
High Contrast
Brand / Tenant
Market
Platform
Density
```

Only activate themes supported by Product/Requirements/Experience Baseline.

---

# 34. Theme Contract

```text
Purpose
Activation
User/system selection
Persistence
Token overrides
Component coverage
Asset variants
Contrast evidence
Transition behavior
Unsupported-state fallback
```

---

# 35. Dark Mode Boundary

Dark mode is not automatic product completeness.

If activated, every component/state/chart/document-like surface must be reviewed, not globally inverted.

---

# 36. Density Mode

Density may support:

```text
Touch-first
Comfortable
Compact operational/data-dense
```

Density must preserve target size, readability, error visibility, and accessibility.

---

# 37. Spacing System

Define scale and semantic usage:

```text
Inline
Control internal
Control gap
Group
Section
Page
Responsive variant
```

Spacing communicates relationship, not decoration.

---

# 38. Sizing System

Sizing tokens may cover:

```text
Controls
Icons
Avatars
Containers
Panels
Modals
Navigation
Touch targets
```

Fixed sizes must not break zoom/reflow or content expansion.

---

# 39. Radius and Border

Define semantic use for:

```text
Controls
Surfaces
Selection
Focus
Validation
Separation
Interactive boundaries
```

Avoid decorative inconsistency that hides state or hierarchy.

---

# 40. Elevation and Layering

Define:

```text
Layer order
Surface relationships
Transient layers
Sticky content
Modal/sheet/dropdown stacking
Focus visibility
High contrast fallback
```

Shadow is not the only way to communicate elevation.

---

# 41. Z-Order Contract

Prevent arbitrary `z-index` escalation by defining semantic layers:

```text
Base
Sticky
Overlay
Dropdown
Modal
Notification
Critical system interruption
```

Architecture/code values are mapped downstream.

---

# 42. Layout System

Layout system defines:

```text
Page regions
Container rules
Grid
Columns
Gutters
Alignment
Max/min widths
Content priority
Responsive transformations
Safe areas
Scrollable regions
```

---

# 43. Grid

Grid is a tool, not a mandatory fixed-column doctrine.

Different workspaces may use:

```text
Reading layout
Form layout
Operational split view
Data-dense workspace
Dashboard/monitoring grid
Mobile stack
```

while sharing foundations.

---

# 44. Container Rule

Define when content is:

```text
Fluid
Max-width constrained
Full-bleed
Centered
Split
Nested
Scrollable
Sticky
```

---

# 45. Layout Hierarchy

Visual hierarchy must reflect:

```text
Current context
Task priority
Object identity/state
Primary action
Supporting information
Warnings/errors
Secondary actions
Audit/history
```

---

# 46. Scroll Model

Define intentionally:

```text
Page scroll
Panel scroll
Table region scroll
Sticky header/action
Focus on route/state change
Scroll restoration
Keyboard access
Mobile safe area
```

Nested scrolling should be justified.

---

# 47. Sticky Content

Sticky headers/actions must not obscure:

```text
Focused controls
Anchor targets
Error messages
Zoomed content
Mobile viewport
On-screen keyboard
```

---

# 48. Typography System

Typography establishes readable hierarchy across supported scripts and platforms.

---

# 49. Typography Roles

Examples:

```text
Display
Page title
Section heading
Subheading
Body
Label
Supporting text
Caption
Data / Tabular number
Code / Identifier
Button / Action
```

Roles should be semantic, not tied to HTML tag or pixel size.

---

# 50. Typography Contract

Each role defines:

```text
Font family by script/platform
Size
Line height
Weight
Letter spacing where appropriate
Case transformation policy
Max line length guidance
Responsive behavior
Contrast role
Truncation/wrapping
Code mapping
```

---

# 51. Arabic and Latin Typography

When both are supported, validate:

```text
Visual balance
Perceived size
Weight equivalence
Line height
Baseline alignment
Numerals
Punctuation
Mixed-script content
Diacritics
Shaping
Fallback
```

One numeric font size does not guarantee visual equivalence.

---

# 52. Font Source and Licensing

Record:

```text
Source
License
Allowed platforms
Web/app embedding
Weights/styles
Fallback
Loading behavior
Privacy/external request implications
```

---

# 53. Readability

Review:

```text
Line length
Line height
Paragraph spacing
Contrast
Text alignment
All-caps usage
Dense data
Long translated content
Zoom/reflow
```

---

# 54. Truncation

Truncation requires:

```text
Allowed content types
Minimum visible meaning
Full-value access
Keyboard/touch access
Screen-reader behavior
RTL/mixed-direction behavior
Tooltip/popover boundary
```

Never truncate critical unique identity without recovery.

---

# 55. Text Scaling

Design must tolerate supported text scaling/zoom without losing information, actions, status, or reading order.

---

# 56. Color System

Color system should separate:

```text
Primitive palette
Semantic roles
Component roles
Data visualization roles
Brand accents
Status roles
Focus/selection roles
```

---

# 57. Semantic Color Roles

```text
Text primary/secondary/disabled/inverse
Surface base/raised/subtle
Border default/strong
Action primary/secondary/destructive
Status success/warning/critical/info
Focus
Selection
Link
Overlay
```

---

# 58. Color Contrast

Every applicable text, icon, control boundary, state, and focus indicator must be measured against the adopted accessibility baseline across all themes/modes.

Visual inspection alone is not evidence.

---

# 59. Color Independence

Meaning must not depend on color alone.

Use appropriate combination of:

```text
Text
Icon
Shape
Pattern
Position
Programmatic state
```

---

# 60. Status Color

Status colors must map to canonical status meaning.

Do not reuse the same color role for incompatible states or create a unique color for every status without hierarchy.

---

# 61. Data Visualization Color

Define:

```text
Categorical sequence
Sequential/diverging scales
Contrast
Color-vision deficiency behavior
Non-color differentiation
Theme variants
Legend/label relationship
Print/document behavior
```

---

# 62. High Contrast / Forced Colors

When applicable, design must preserve:

```text
Control boundaries
Focus
Selected/current state
Icons
Disabled/read-only distinction
Charts/status
Error/success
```

without relying on removed custom backgrounds.

---

# 63. Focus Design

Focus style needs:

```text
Visibility
Contrast
Shape/offset
Theme support
High-contrast support
No clipping
No overlap by sticky content
Component-state compatibility
```

---

# 64. Iconography System

Define:

```text
Source
Grid
Size
Stroke/fill
Optical alignment
Semantic categories
Label relationship
RTL mirroring
State/color
Accessibility
Custom icon process
```

---

# 65. Functional Icon

Icon-only control requires:

```text
Unambiguous common meaning or visible support
Accessible name
Target size
Focus/hover/pressed/disabled states
Tooltip/help where appropriate
RTL decision
```

---

# 66. Decorative Icon

Decorative icon should not create duplicate assistive-technology output or imply state/action.

---

# 67. Directional Icon

Each directional icon gets:

```text
MIRROR_IN_RTL
DO_NOT_MIRROR
CONTEXTUAL
```

Examples must be reviewed by meaning, not geometry alone.

---

# 68. Product Assets

Assets may include:

```text
Logos
Illustrations
Empty-state graphics
Avatars
Thumbnails
Maps
Document marks
App icons
Brand partner logos
```

Each asset needs source, license, variants, alt-text responsibility, localization, and optimization notes.

---

# 69. Illustration Boundary

Illustration supports orientation, explanation, emotion, or brand expression.

It must not hide missing information architecture or replace essential text.

---

# 70. Image Content

Design must define:

```text
Aspect ratio
Crop/focal point
Fallback
Loading/error
Alt-text responsibility
Sensitive content
User-generated content
Localization
Performance implication
```

---

# 71. Component

Component is a reusable UI unit with explicit anatomy, behavior, properties, states, accessibility, and code mapping expectations.

---

# 72. Component Contract

```yaml
component_id: CMP-BUTTON
name: Button
purpose: "Initiates an explicit user action."
anatomy:
  - LABEL
  - LEADING_ICON_OPTIONAL
  - TRAILING_ICON_OPTIONAL
properties:
  hierarchy:
    - PRIMARY
    - SECONDARY
    - TERTIARY
    - DESTRUCTIVE
  size:
    - COMPACT
    - REGULAR
  width:
    - CONTENT
    - FULL
states:
  - DEFAULT
  - HOVER
  - FOCUS
  - PRESSED
  - LOADING
  - DISABLED
tokens:
  - button.primary.background.default
  - button.primary.text.default
accessibility:
  role: BUTTON
  name_source: LABEL
  focus_rule: AXR-FOCUS-001
  target_rule: ACC-TARGET-001
responsive:
  - DRESP-BUTTON-001
rtl:
  - DRTL-BUTTON-001
code_mapping:
  - D2C-BUTTON-001
status: APPROVED
```

---

# 73. Component Anatomy

Anatomy defines meaningful internal parts and slots.

It should not expose implementation wrappers with no design/content role.

---

# 74. Component Property

Property represents controlled variability:

```text
Hierarchy
Size
State
Content
Icon placement
Selection
Density
Orientation
Theme
Platform
```

Avoid property for arbitrary cosmetic override.

---

# 75. Component Variant

Variant is a supported combination with distinct design/behavior.

Not every combinatorial property mix needs a separate published variant.

---

# 76. Variant Explosion Control

Before adding variant ask:

```text
Is the difference meaningful?
Is it reused?
Does it change behavior/semantics?
Can composition solve it?
Will code mapping remain manageable?
Does it create inaccessible combinations?
```

---

# 77. Component State

Common states:

```text
DEFAULT
HOVER
FOCUS
ACTIVE / PRESSED
SELECTED
CHECKED
EXPANDED
COLLAPSED
LOADING
DISABLED
READ_ONLY
INVALID
WARNING
SUCCESS
DRAGGING
DROP_TARGET
```

Only applicable states should exist.

---

# 78. Disabled State

Must remain distinguishable and readable while meeting applicable contrast rules.

Disabled cannot be the only explanation for unavailable action.

---

# 79. Read-Only State

Read-only must remain perceivable and distinguishable from disabled and editable.

Content may still need selection/copy/navigation.

---

# 80. Loading State at Component Level

Define:

```text
Content preservation
Size stability
Action lock
Accessible status/name
Repeated activation prevention
Completion/failure transition
```

---

# 81. Invalid State

Invalid design includes:

```text
Visible error association
Non-color signal
Focus behavior
Message placement
Persistent value
Theme/RTL/responsive variants
```

---

# 82. Component Slot

Slot defines allowed content/composition.

```text
Content type
Required/optional
Multiplicity
Order
Sizing
Truncation/wrapping
Accessibility relationship
```

---

# 83. Component Composition

Prefer composition when building meaningful product patterns from stable primitives.

Avoid a single mega-component with dozens of unrelated modes.

---

# 84. Component Dependency

Record dependencies on:

```text
Tokens
Foundations
Other components
Patterns
Content rules
Accessibility rules
Platform capability
Code component
```

---

# 85. Component Source of Truth

Each component identifies:

```text
Canonical design source
Library/package
Component ID
Published version
Product adoption status
Code mapping
Owner
Deprecation path
```

---

# 86. Component Candidate

New component starts:

```text
CANDIDATE
```

before publication.

It must prove reuse, distinct semantics, accessibility, responsive behavior, and code feasibility.

---

# 87. Product-Specific Component

Create when product/domain semantics cannot be expressed safely through existing components/patterns.

Document why it is not generic library behavior.

---

# 88. Component vs Pattern

Component:

```text
Reusable UI unit.
```

Pattern:

```text
Reusable arrangement and behavior across components to solve a product task/state.
```

Example:

```text
Button = component
Destructive action confirmation = pattern
```

---

# 89. Product Pattern

Pattern contract:

```text
Purpose
Trigger/context
Applicable journeys/views/states
Composition
Sequence
Variants
Content rules
Responsive behavior
Accessibility
Security/privacy
Examples
Anti-use cases
Code mapping
```

---

# 90. Pattern Categories

```text
Navigation
Context switching
Forms
Search/filter
Table/list
Bulk action
Selection
Upload
Progress
Empty/error/recovery
Notification
Confirmation
Destructive action
Authentication/recovery
Permission/read-only
Wizard/stepper
Detail/history
Cross-channel handoff
```

---

# 91. Component Coverage Matrix

For each component:

```text
Properties
States
Themes
Responsive modes
RTL/LTR
Keyboard
Screen-reader semantics
Touch
Content stress
Code mapping
Product adoption
```

---

# 92. Component Adoption

Adoption must be proven by references from approved `DSCR` screen designs or published product templates.

Documentation examples alone are not active adoption.

---

# 93. Component Deprecation

Deprecation record:

```text
Reason
Replacement
Affected screens/products
Migration guidance
Code mapping impact
Deadline/release
Owner
Removal status
```

Do not detach instances to avoid migration.

---

# 94. Component Override

Local override requires rationale.

If repeated, evaluate:

```text
Missing variant
Missing token
Wrong component
Product-specific extension
Design debt
```

---

# 95. Screen / View Design

`DSCR` is the approved visual realization of one or more `VIEW`, `DST`, and `ROUTE` objects from `EXP-009`, within defined context and variants.

---

# 96. Screen Design Contract

```yaml
design_id: DSCR-APR-DETAIL
experience_view: VIEW-APR-DETAIL
route: ROUTE-APR-DETAIL
purpose: "Review and decide an approval request."
actors:
  - XACT-APPROVER
requirements:
  - FR-APR-014
  - SEC-AUTHZ-003
  - ACC-NAV-001
  - AUD-APR-002
states:
  - DSTATE-APR-READY
  - DSTATE-APR-LOADING
  - DSTATE-APR-PERMISSION
  - DSTATE-APR-CONFLICT
  - DSTATE-APR-UNKNOWN
responsive_variants:
  - DRESP-APR-COMPACT
  - DRESP-APR-WIDE
direction_variants:
  - DRTL-APR-LTR
  - DRTL-APR-RTL
components:
  - CMP-PAGE-HEADER
  - CMP-STATUS
  - CMP-ACTION-BAR
patterns:
  - PAT-APPROVAL-DECISION
prototype:
  - PROTO-APR-001
source:
  - DSRC-FIGMA-APR-DETAIL
status: APPROVED
```

---

# 97. Screen Is Not Requirement

A screen can realize several requirements.

A requirement may span several screens/states.

Do not infer system scope from frame count.

---

# 98. Screen Is Not Route

One route may support multiple screen states or adaptive modes.

One logical screen may appear in multiple route/context variants.

---

# 99. Screen State Design

Each `DSTATE` maps to `UXS` and defines complete visual/content/component realization.

---

# 100. State Design Families

```text
READY
LOADING
PROGRESSIVE_LOADING
EMPTY
FILTERED_EMPTY
PARTIAL
VALIDATION_ERROR
SYSTEM_ERROR
DEPENDENCY_ERROR
PERMISSION_RESTRICTED
NOT_FOUND
CONFLICT
STALE
READ_ONLY
LOCKED
PENDING
PROCESSING
OFFLINE
SYNC_PENDING
SYNC_CONFLICT
UNKNOWN_OUTCOME
EXPIRED
SUCCESS
PARTIAL_SUCCESS
INTERRUPTED
```

---

# 101. State Design Contract

```text
State ID / UX State source
Trigger
Visual hierarchy
Message/content
Preserved information
Actions
Component states
Focus target
Screen-reader announcement annotation
Responsive variants
RTL variants
Security/privacy constraints
Recovery link
```

---

# 102. Loading Design

Choose pattern based on duration, information structure, and progress semantics:

```text
Skeleton
Progress indicator
Inline loading
Button loading
Background status
Determinate progress
Indeterminate progress
```

Avoid misleading skeletons or layout shift.

---

# 103. Empty-State Design

Must represent the exact empty meaning:

```text
No data
No results
Not configured
No permission
Not synchronized
First use
```

Illustration is optional; next action and meaning are primary.

---

# 104. Error-State Design

Must show:

```text
Impact
Preserved work
Safe action
Recovery/support
Persistent vs transient treatment
Focus/announcement
No sensitive disclosure
```

---

# 105. Permission-State Design

Design must clearly distinguish:

```text
No access
Read-only
Temporarily unavailable
Wrong context
Needs approval/request
Elevated access ended
```

---

# 106. Unknown-Outcome Design

Must avoid visual success or failure cues until known.

Provide persistent pending/reconciliation state, duplicate-action protection, and safe next action.

---

# 107. Success Design

Success design prioritizes confirmation and next-state clarity.

Celebration level should be proportional to user goal and context.

---

# 108. Partial-Success Design

Must visually separate:

```text
Completed
Failed
Pending
Needs attention
Retry-safe
```

---

# 109. Screen Variant Matrix

Potential dimensions:

```text
State
Role / Permission
Tenant / Entity Context
Platform
Responsive Mode
Language / Direction
Theme
Density
Market
Data Volume
Content Length
Accessibility Mode
```

Not every combination needs a separate frame; every material combination needs design disposition.

---

# 110. Variant Coverage Strategy

Use:

```text
Representative frame
Component/state contract
Variant matrix
Annotations
Focused stress-test frame
Prototype path
```

to avoid thousands of redundant frames while preserving coverage.

---

# 111. Screen Naming

Recommended:

```text
<DOMAIN>/<VIEW>/<STATE>/<MODE>/<DIRECTION>
```

Example:

```text
Approvals/Detail/Conflict/Compact/RTL
```

Human-readable names remain linked to stable IDs.

---

# 112. Design Annotation

Annotation explains non-obvious behavior or implementation obligation.

```text
Source ID
Subject
Rule
State/trigger
Measurement/token/component
Accessibility semantics
Responsive/RTL behavior
Engineering/QA note
```

Annotation does not replace canonical upstream artifact.

---

# 113. Screen Specification

Screen specification may include:

```text
Purpose and context
Grid/layout
Regions
Components/instances
Tokens
Content/message IDs
Actions
States
Responsive behavior
RTL/localization
Accessibility annotations
Motion
Prototype link
Requirements/EXP links
Code mapping
Open conditions
```

---

# 114. Navigation Design

Realizes `EXP-008` through:

```text
Global/workspace/local navigation
Current destination
Context visibility
Collapsed/expanded modes
Keyboard/focus behavior
Responsive form
RTL order/icon behavior
Overflow
Deep-link states
```

---

# 115. Context Design

Current tenant/entity/workspace/acting capacity must be visible at the level required by risk and user task.

Context switch design includes consequences and unsaved-work treatment.

---

# 116. Breadcrumb / Entity Trail Design

Must show meaningful hierarchy/context, support keyboard/focus, and handle truncation/RTL without becoming a decorative path dump.

---

# 117. Page Header

May contain:

```text
Identity/title
Context
Status
Primary action
Secondary actions
Metadata
Tabs/local navigation
```

Component/pattern must handle long titles, actions overflow, states, compact mode, and RTL.

---

# 118. Action Hierarchy

Design must reflect:

```text
Primary task
Secondary actions
Destructive action
Rare/overflow action
Disabled/unavailable explanation
```

Avoid multiple visually equal primary actions without rationale.

---

# 119. Destructive Action Design

Realizes consequence, scope, confirmation, reauthentication, reason, second approval, reversal, progress, partial failure, and audit obligations as applicable.

---

# 120. Dialog

Use when attention must be temporarily constrained.

Contract:

```text
Trigger
Purpose
Focus entry/trap/return
Title/description
Actions
Escape/cancel
Destructive consequence
Responsive/mobile form
RTL
Screen-reader semantics
```

Do not put long multi-step journeys into dialogs by convenience.

---

# 121. Drawer / Sheet

Use when preserving underlying context is valuable and task scope fits.

Define routing/history, focus, scroll, responsive transformation, and dismissal safety.

---

# 122. Popover / Tooltip

Must support applicable input modes and not contain essential inaccessible interaction.

Tooltip cannot be the only source of critical instruction/error.

---

# 123. Notification Design

Design across:

```text
In-product center/list
Banner
Persistent alert
Toast/transient status
Email
Push
SMS where applicable
```

with channel-specific privacy, content, action, and accessibility constraints.

---

# 124. Toast Boundary

Use only when loss does not block understanding or recovery.

Must be perceivable without stealing focus unnecessarily.

---

# 125. Banner / Alert

Define severity, persistence, dismissibility, scope, action, semantics, and responsive behavior.

---

# 126. Form Design System

Includes:

```text
Label
Input/control
Description/help
Required/optional marker
Prefix/suffix
Validation
Error
Success
Character/count constraint
Privacy/reveal
Group
Actions
```

---

# 127. Label Design

Labels remain visible and programmatically associated.

Placeholder is not a label.

---

# 128. Required / Optional Design

Use one consistent strategy that remains understandable without color and supports screen readers.

---

# 129. Input Sizing

Should reflect content and task while preserving touch target, zoom, translation expansion, and platform conventions.

---

# 130. Input Types

Choose component/input pattern based on information semantics and platform capability:

```text
Text
Number
Currency
Date/time
Phone
Email
Address
Search
Selection
Multi-selection
File
Rich text
Code/identifier
```

---

# 131. Validation Design

Must support:

```text
Inline message
Error summary
Focus order
Non-color indication
Persistent value
Correction guidance
Server/business error
Cross-field error
Step-level error
```

---

# 132. Error Summary Design

Includes linked errors, meaningful labels, focus entry, correction path, and responsive/RTL behavior.

---

# 133. Conditional Fields

Appearance/disappearance must preserve focus and user understanding.

Design must show trigger, transition, value preservation/clearing, and error behavior.

---

# 134. Prefill and Default Design

Visually distinguish suggested/default, authoritative, derived, and user-entered values where material.

Do not create dark-pattern defaults for consent or high-impact choices.

---

# 135. Multi-Step Form Design

Cover:

```text
Progress
Step labels
Back/next
Save/resume
Review
Errors across steps
Mobile/compact
Keyboard/focus
RTL
Long content
```

---

# 136. Review / Confirmation Design

Make consequential information scannable, editable, and understandable before commitment.

Final action label describes outcome.

---

# 137. File Upload Design

Cover:

```text
Drop/select alternatives
File list
Progress
Validation/security failure
Replace/remove
Preview
Retry
Keyboard/touch
Screen-reader status
RTL/localization
```

---

# 138. Search Design

Realizes:

```text
Scope
Query input
Suggestions/recent
Clear
Submit
Loading
No results
Error
Filter relationship
Result highlighting
Keyboard
Localization
```

---

# 139. Filter Design

Cover:

```text
Facets
Applied state
Count
Clear/reset
Save
Responsive mode
Drawer/sheet behavior
Keyboard/focus
Long values
RTL
No-result feedback
```

---

# 140. Table Design

Contract includes:

```text
Header
Rows/cells
Sorting
Filtering
Selection
Actions
Pagination/loading
Empty/error
Sticky behavior
Density
Responsive alternative
Keyboard
Screen-reader semantics
Column customization
```

---

# 141. Table Responsive Design

Possible dispositions:

```text
Priority columns
Horizontal scroll
Row-detail expansion
List/card transformation
Task-specific compact view
Separate mobile flow
```

No critical status/action is dropped silently.

---

# 142. Table Accessibility

Define:

```text
Caption/title relationship
Header semantics
Sort state
Row selection
Cell/row actions
Keyboard strategy
Focus visibility
Responsive semantic preservation
```

---

# 143. Bulk Action Design

Display selection scope, count, eligibility, consequence, progress, partial success, error details, and recovery.

---

# 144. Pagination Design

Define current position, total/unknown total, navigation, page size, keyboard, responsive form, and return-to-position behavior.

---

# 145. Infinite Loading Design

Must preserve findability, end-state clarity, keyboard access, footer access, history/return position, and loading/error recovery.

---

# 146. Card Design

Card is appropriate when content forms a coherent actionable object/group.

Avoid nested card layers and decorative cardification of every region.

---

# 147. Detail Design

Prioritize object identity, state, context, primary actions, critical information, history/evidence, related objects, and permissions.

---

# 148. Timeline / History Design

Cover event hierarchy, actor/capacity, timestamp, grouping, filters, sensitive data, loading/empty/error, responsive behavior, and accessibility.

---

# 149. Status Design

Status uses text/semantic state plus supporting visual treatment.

Badge alone must not carry full meaning.

---

# 150. Progress Design

Differentiate:

```text
Task progress
Background processing
Upload/download
Journey step progress
Unknown duration
Queued state
```

---

# 151. Data Visualization

Design must communicate:

```text
Question answered
Metric definition
Comparison
Scale/unit
Source/freshness
Uncertainty
Interaction
Alternative table/text
Color accessibility
Responsive behavior
```

---

# 152. Chart Selection

Choose based on relationship:

```text
Trend
Comparison
Distribution
Composition
Correlation
Flow
Geography
```

not visual novelty.

---

# 153. Chart Accessibility

Provide as applicable:

```text
Title/summary
Data table
Labels
Non-color differentiation
Keyboard/focus
Screen-reader information
High contrast/theme variants
Zoom/reflow strategy
```

---

# 154. Dashboard Design

Dashboard must support explicit monitoring/prioritization/decision tasks.

Define hierarchy, freshness, actionability, empty/error, personalization, responsive behavior, and accessibility.

---

# 155. Content Design

Phase 06 finalizes presentation and copy within `EXP-013` meaning/ownership constraints.

---

# 156. Content Design Object

`DCNT` defines:

```text
Message ID/source
Final or approved draft copy
Context
Visual treatment
Variables
Length constraints
Wrapping/truncation
Localization notes
Accessibility announcement
Legal/security owner
Version
```

---

# 157. Dynamic Content Variables

Specify:

```text
Variable meaning
Format
Fallback
Maximum/expected length
Sensitive-data handling
Plural/gender behavior
RTL isolation
Missing-value behavior
```

---

# 158. Action Copy

Action labels describe outcome and remain clear in confirmation, disabled, loading, and mobile contexts.

---

# 159. Error Copy

Must be:

```text
Truthful
Safe
Specific enough
Actionable
Consistent with preserved state
Translatable
Accessible
```

---

# 160. Unknown-Outcome Copy

Avoid success/failure language.

Explain pending/reconciliation and safe next step.

---

# 161. Empty-State Copy

Explains exact empty meaning and next action without blaming user or overselling feature.

---

# 162. Confirmation Copy

Consequential confirmation states:

```text
What will happen
Affected scope
Irreversibility/reversal
Primary action
Safe cancel
```

---

# 163. Content Stress Testing

Test designs with:

```text
Long names
Long translations
Empty value
Large number
Multiple currencies
Long error
Multiple status labels
Mixed Arabic/Latin
Long file name
Unbroken identifiers/URLs
```

---

# 164. Placeholder Content

Placeholder may be used during exploration only when it cannot hide layout, localization, safety, or content-meaning decisions.

Critical baseline screens use realistic representative content.

---

# 165. Responsive Design

Phase 06 converts `EXP-014` behavior into complete compositions and component variants.

---

# 166. Responsive Mode

Define modes by available space/input/task, not device marketing names only.

Example:

```text
COMPACT
REGULAR
WIDE
TOUCH_PRIMARY
DATA_DENSE
KIOSK
PRINT
```

---

# 167. Breakpoints

Breakpoints should occur when content/layout needs change.

Record:

```text
Trigger rationale
Affected layouts/components
Token/code mapping
Zoom/reflow interaction
```

---

# 168. Responsive Recomposition

May include:

```text
Reorder
Stack
Collapse
Move to sheet/drawer
Change navigation form
Change table representation
Prioritize content/actions
Preserve context/status/errors
```

---

# 169. Small-Screen Design

Must account for:

```text
On-screen keyboard
Safe areas
Thumb/touch reach only where useful
Long translations
Sticky actions
Dialogs/sheets
Tables
Focus/scroll
Orientation
```

---

# 170. Large-Screen Design

Use extra space to improve task/context—not stretch lines and controls indefinitely.

Possible patterns:

```text
Split view
Persistent context
Comparison
Data density
Multi-panel operational layout
```

---

# 171. Cross-Platform Design

Cross-platform consistency means preserving the same product intent while respecting the conventions, capabilities, and constraints of each supported platform.

Record per platform:

```text
Shared capability and journey
Native or product-specific pattern
Navigation model
Input modes
Window and viewport behavior
System UI interaction
Permissions and interruptions
Offline and background behavior
Accessibility services
Known divergence and rationale
```

---

# 172. Input Modes

Design must define behavior for every applicable input mode:

```text
Pointer
Keyboard
Touch
Stylus
Remote / directional input
Voice
Switch control
Assistive technology
Scanner or specialized hardware
```

An input mode may be marked `NOT_APPLICABLE` only with reason and reopen condition.

---

# 173. Orientation and Window States

Where applicable, design covers:

```text
Portrait
Landscape
Resizable window
Split screen
Folded / unfolded posture
Picture-in-picture
Full screen
Kiosk or fixed display
Print / export viewport
```

Loss of orientation or window space must not hide a required action, message, error, or recovery path.

---

# 174. Accessibility Design Scope

Accessibility is applied to foundations, tokens, components, patterns, screens, content, motion, prototypes, generated outputs, and third-party surfaces.

The target conformance level is inherited from `GOV-009` and the approved requirements baseline. If no stricter target applies, the default Product OS target is WCAG 2.2 AA for applicable digital interfaces.

---

# 175. Accessibility Applicability Matrix

For every supported surface, record:

```text
Surface / platform
Applicable standards and profiles
User and assistive-technology needs
Required design controls
Required annotations
Validation method
Evidence owner
Exceptions / accepted constraints
Reopen trigger
```

---

# 176. Perceivable Design

Design must define, where applicable:

```text
Text alternatives responsibility
Caption / transcript placement
Color-independent meaning
Contrast requirements
Text resize and zoom
Reflow behavior
Content reading order
Adaptable layout
High-contrast behavior
Non-text contrast
```

---

# 177. Color Contrast

Contrast validation must use final semantic token combinations and actual component states.

Test at minimum:

```text
Default text
Secondary text
Links
Icons carrying meaning
Borders and controls
Focus indicators
Disabled presentation where meaning remains required
Error / warning / success states
Charts and status visualization
Light, dark, and high-contrast themes
```

A token passing in isolation does not prove every composed component passes.

---

# 178. Focus Design

Every interactive component requires a visible focus treatment that:

```text
Is distinguishable from hover and selection
Has sufficient contrast
Is not clipped by containers
Works on all themes and surfaces
Follows the logical interaction order
Remains visible during validation and recovery
```

Focus appearance and focus order are different obligations; both must be specified.

---

# 179. Keyboard and Sequential Navigation

Design annotations must identify:

```text
Entry focus
Traversal order
Skip or bypass routes
Composite-widget behavior
Keyboard shortcuts
Modal focus containment
Focus restoration
Escape and cancel behavior
Unavailable-action treatment
```

The design must not require pointer-only discovery or operation.

---

# 180. Target Size and Touch Design

Interactive targets must meet the active accessibility and platform requirements.

Design records:

```text
Visual size
Interactive hit area
Spacing from adjacent targets
Gesture alternative
Reach constraints where relevant
Accidental activation risk
```

---

# 181. Semantic and Assistive-Technology Annotations

Visual appearance cannot communicate semantics to implementation by itself.

Annotate when not obvious:

```text
Role
Accessible name source
Description source
State and value
Heading level
Landmark / region
Live announcement
Relationship to label, help, and error
Decorative asset treatment
Reading order
Grouping
```

---

# 182. Accessible Forms

Each form design must show:

```text
Persistent label
Required / optional status
Format and constraints
Help relationship
Error location and message
Error summary when applicable
Focus after validation
Progress and save state
Timeout or session-expiry handling
Review before consequential submission
```

Placeholder text is not a label.

---

# 183. Status, Error, and Live Feedback Accessibility

Status changes must not depend only on color, position, animation, or a transient toast.

Specify:

```text
Visible message
Programmatic announcement expectation
Persistence / dismissal
Relationship to affected content
Focus behavior
Recovery action
Duplicate-announcement prevention
```

---

# 184. Zoom and Reflow

Design validates applicable screens and components under required text resizing, browser zoom, display scaling, and narrow-width reflow conditions.

No required content or action may become:

```text
Clipped
Overlapped
Unreachable
Hidden behind fixed content
Dependent on two-dimensional scrolling without an approved exception
Separated from its context or error
```

---

# 185. Reduced Motion and Sensory Safety

For every non-trivial motion, define:

```text
Purpose
User benefit
Trigger
Duration
Interruptibility
Reduced-motion alternative
No-motion fallback
Flashing / vestibular risk
```

Decorative motion must never block task completion.

---

# 186. Accessible Authentication and Security Journeys

Authentication, recovery, challenge, consent, and session-management surfaces must avoid unnecessary cognitive or motor barriers.

Design must cover:

```text
Password manager support
Paste and autofill behavior
Alternative challenge paths
Clear timeout warnings
Recovery from failed challenge
Accessible CAPTCHA alternative where used
Reauthentication context
Non-destructive retry
```

---

# 187. Generated Output Accessibility

Where the product generates documents, reports, emails, or notifications, their design contract includes applicable:

```text
Reading order
Heading structure
Table structure
Alternative text
Link purpose
Contrast
Language and direction
Metadata and title
Tagged export expectation
Plain-text or alternate representation
```

---

# 188. Third-Party Accessibility

Embedded widgets, SDK surfaces, payment pages, maps, charts, support tools, and identity providers remain in product scope when they are part of a required journey.

Record:

```text
Owner / vendor
Known accessibility behavior
Design constraints
Fallback or alternate path
Evidence source
Unresolved risk
Replacement trigger
```

---

# 189. Localization Design Scope

Localization design covers more than translated strings.

It includes:

```text
Language
Writing direction
Typography and shaping
Content expansion
Line breaking
Numbers, dates, time, and currency
Names, addresses, and phone formats
Plural and grammatical variation
Locale-specific sorting and grouping
Images and cultural meaning
Legal / market content
```

---

# 190. RTL as a Native Design Mode

RTL must be designed and validated as a first-class mode, not generated through whole-screen mirroring.

For each applicable screen and component, decide:

```text
What follows reading direction
What follows chronological direction
What follows spatial / physical direction
What remains invariant
What requires locale-specific content order
```

---

# 191. RTL Layout and Reading Order

Validate:

```text
Page and section flow
Navigation position and order
Primary / secondary action order
Breadcrumbs and steppers
Tabs and segmented controls
Tables and frozen columns
Forms and label alignment
Focus and reading order
Drawers, panels, and contextual controls
```

Visual order, DOM or semantic order, and keyboard order must remain intentionally aligned.

---

# 192. RTL Iconography

Icons are classified as:

```text
DIRECTIONAL — may mirror
SEMANTIC — mirror only if meaning changes with direction
BRAND — never mirror unless brand guidance requires it
PHYSICAL — follows real-world orientation
TEXTUAL — localize or replace
INVARIANT — remains unchanged
```

The classification belongs to the asset or component contract.

---

# 193. Arabic and Complex-Script Typography

Design must validate:

```text
Correct shaping and joining
Font language coverage
Weight equivalence
Line-height and diacritics
Numeral strategy
Ligatures where applicable
Fallback stack
Clipping in controls
Mixed-script baseline alignment
PDF / email / export rendering
```

Visual approval using broken or unshaped Arabic is invalid.

---

# 194. Mixed-Direction Content

Mixed Arabic/Latin text, identifiers, URLs, email addresses, codes, dates, and numbers require explicit examples.

Design and annotations must prevent:

```text
Reordered identifiers
Detached punctuation
Ambiguous action labels
Wrong alignment
Broken copy/paste
Misread status or amount
```

---

# 195. Localization Stress Testing

Test representative designs with:

```text
Short and long labels
At least one high-expansion locale where applicable
RTL content
Long names and addresses
Large and negative numbers
Plural variants
Missing translations
Mixed-script identifiers
Translated error and confirmation messages
```

Truncation must not remove required meaning or distinguishability.

---

# 196. Motion Design

Motion is a controlled product behavior, not decoration added after approval.

Each motion object records:

```text
Motion ID
Trigger
Start and end states
Purpose
Affected element
Duration and easing token
Interruption behavior
Completion state
Reduced-motion behavior
Performance constraint
```

---

# 197. Transition Categories

Useful categories include:

```text
Navigation transition
State change
Feedback
Loading / progress
Spatial continuity
Attention cue
Reveal / disclosure
Reordering
Drag / gesture response
Celebration
```

Every category must have restrained defaults and an accessibility fallback.

---

# 198. Loading and Progress Motion

Design distinguishes:

```text
Unknown-duration loading
Known progress
Background processing
Queued work
Optimistic update
Long-running job
Paused or failed work
Unknown outcome
```

Animation cannot replace textual status or recovery information.

---

# 199. Email, Notification, and Message Design

When in scope, design specifies:

```text
Channel
Purpose and trigger
Subject / title
Message hierarchy
Primary and secondary actions
Deep-link destination
Sender identity
Brand and trust cues
Localization / RTL
Accessibility
Dark-mode behavior
Fallback and plain-text representation
Sensitive-data exposure rules
```

---

# 200. Generated Document and Print Design

Document and print design covers:

```text
Page size and margins
Header / footer
Pagination
Repeated table headers
Page breaks
Long values
Print contrast
Language and direction
Accessible structure
Signature / verification area
Confidentiality marking
Export-state messaging
```

---

# 201. Security and Privacy Design

Product Design realizes approved security and privacy requirements through visible, understandable, and safe interaction patterns.

It does not invent policy or weaken controls for visual convenience.

---

# 202. Sensitive Data Presentation

Define:

```text
Masking and reveal
Copy restrictions where required
Shoulder-surfing risk
Screenshot / print behavior where controlled
Redaction
Role-based visibility
Audit-sensitive actions
Data retention cues
Export warning
```

---

# 203. Consent and Permission Design

Consent and permission surfaces must show:

```text
Purpose
Data or capability requested
Consequences of accept / decline
Granularity
Persistence and withdrawal
System-permission relationship
Just-in-time context
Alternative route where required
```

Dark patterns, disguised consent, and forced visual hierarchy are prohibited.

---

# 204. Destructive and Consequential Actions

Design must make consequence proportional to risk.

Controls may include:

```text
Clear action naming
Impact summary
Scope and affected objects
Confirmation
Typed confirmation for exceptional risk
Reauthentication
Undo / grace period
Progress
Receipt / audit reference
Recovery or support route
```

---

# 205. Session and Reauthentication Design

Specify:

```text
Session-expiry warning
Save / preserve behavior
Reauthentication reason
Return destination
Failure and recovery
Multi-device or conflict messaging
Sensitive-screen timeout
```

---

# 206. Safe Error Disclosure

Error design must balance user recovery with security and privacy.

Do not expose:

```text
Internal stack details
Secrets or tokens
Existence of protected accounts or records
Authorization internals
Sensitive identifiers without need
```

Provide enough information for a safe next action and support reference where applicable.

---

# 207. Standards Design Applicability Review

At the start of Phase 06, the team reviews the active `GOV-009` profiles and downstream obligations against the approved design scope.

The review asks:

```text
Which standards change foundations or tokens?
Which change components or patterns?
Which change screen states or content?
Which require annotations or evidence?
Which surfaces, exports, or vendors are conditional?
What remains unresolved or blocked?
```

---

# 208. GOV-009 Update from Product Design

Phase 06 updates `GOV-009` with references to:

```text
Applicable tokens
Components and variants
Screen / state coverage
Contrast and focus evidence
Touch and input evidence
Zoom / reflow evidence
Localization / RTL evidence
Motion alternatives
Generated-output design
Third-party design constraints
Prototype and validation evidence
Phase 07 / 08 obligations
```

No standard may be marked `DESIGN_COMPLETE` without traceable evidence.

---

# 209. Standards Conflict and Exception Handling

When a design rule, platform convention, brand rule, accessibility need, contractual obligation, or regulation conflicts:

```text
Record the conflict
Identify authoritative sources
Assess affected users and flows
Escalate to accountable owners
Document the decision
Apply compensating controls where approved
Set expiry / review trigger
Update GOV-009 and impacted baselines
```

Phase 06 cannot silently resolve governance conflicts through visual compromise.

---

# 210. Phase 06 Workflow Overview

```text
06.0  Confirm entry and freeze references
06.1  Review design scope and applicability
06.2  Audit existing design sources and product UI
06.3  Establish design direction and principles
06.4  Define foundations, tokens, themes, and density
06.5  Define layout, typography, color, and assets
06.6  Build or reconcile the component system
06.7  Define reusable product patterns
06.8  Design screens, states, and variants
06.9  Design responsive and cross-platform behavior
06.10 Design accessibility realization
06.11 Design localization and RTL realization
06.12 Design content, messages, and generated outputs
06.13 Define motion and transitions
06.14 Build the high-fidelity prototype
06.15 Validate with users, experts, and stakeholders
06.16 Resolve findings and control upstream change
06.17 Complete coverage and traceability
06.18 Prepare design-to-code handoff
06.19 Baseline design sources and evidence
06.20 Run G4B — Design Baseline
```

---

# 211. Step 06.0 — Confirm Entry and Freeze References

Confirm:

```text
G3B Requirements Baseline reference
G4A Experience Baseline reference
Approved product scope
Active GOV-009 revision
Open conditions and waivers
Design profile and domain overrides
Canonical source locations
Owners and approvers
```

`Freeze` means reference and version control, not a prohibition on governed change.

---

# 212. Step 06.1 — Review Design Scope and Applicability

Produce a Design Scope Map covering:

```text
Products / modules
Platforms and surfaces
Journeys and flows
Screens and states
Languages and directions
Themes and density modes
Roles / permissions
Generated outputs
Third-party surfaces
Standards profiles
Prototype and validation depth
```

---

# 213. Step 06.2 — Audit Existing Design Sources and Product UI

For an existing product or design system, inspect:

```text
Design files and libraries
Published components
Product screen usage
Code components and tokens
Screenshots and running product
Documentation
Known defects and research evidence
Deprecated and duplicate assets
```

Classify each relevant object as:

```text
RETAIN
REVISE
REPLACE
DEPRECATE
MIGRATE
UNKNOWN
NOT_APPLICABLE
```

Library existence is not adoption evidence; actual product usage must be inspected separately.

---

# 214. Step 06.3 — Establish Design Direction

Define and approve:

```text
Product design principles
Visual hierarchy
Brand relationship
Information density
Interaction character
Content tone
Accessibility posture
Platform posture
Deliberate constraints
Rejected directions and rationale
```

Direction work must demonstrate application to representative product states, not only moodboards.

---

# 215. Step 06.4 — Define Foundations, Tokens, Themes, and Density

Create or reconcile semantic foundations and token architecture.

Validate:

```text
Naming
Levels and inheritance
Themes
Modes
Contrast
Component consumption
Code mapping
Ownership
Versioning
Deprecation
```

---

# 216. Step 06.5 — Define Layout, Typography, Color, and Assets

Complete applicable foundation specifications and prove them in representative compositions.

Avoid approving isolated palette or type specimens without product context.

---

# 217. Step 06.6 — Build or Reconcile the Component System

For each component family:

```text
Confirm product need
Define contract and anatomy
Define properties and variants
Define states
Apply tokens
Define behavior and semantics
Validate responsive / RTL / accessibility
Map source and code counterpart
Record adoption and migration
```

---

# 218. Step 06.7 — Define Product Patterns

Define repeatable compositions for recurring product tasks and state transitions.

Patterns must reference approved components and experience behavior.

---

# 219. Step 06.8 — Design Screens, States, and Variants

Design from the Screen and State Coverage Matrix.

For each subject:

```text
Apply the correct pattern and components
Use approved content responsibilities
Cover state and role variants
Show permissions and unavailable states
Annotate non-visible behavior
Trace to experience and requirements
```

---

# 220. Step 06.9 — Design Responsive and Cross-Platform Behavior

Validate recomposition across approved modes, platforms, orientations, input methods, and window states.

Document intentional divergence rather than forcing pixel identity.

---

# 221. Step 06.10 — Design Accessibility Realization

Apply the Accessibility Design Specification to tokens, components, patterns, screens, content, motion, and prototypes.

Produce evidence at both system and representative-screen level.

---

# 222. Step 06.11 — Design Localization and RTL Realization

Use real or production-representative localized content to validate typography, shaping, ordering, expansion, and bidirectional behavior.

---

# 223. Step 06.12 — Design Content, Messages, and Generated Outputs

Complete critical copy, state messages, dynamic-variable rules, notification templates, and generated-output design where applicable.

Copy ownership and localization status must be visible.

---

# 224. Step 06.13 — Define Motion and Transitions

Create motion specifications only where motion improves orientation, feedback, continuity, or comprehension.

Always define interruption and reduced-motion behavior.

---

# 225. Step 06.14 — Build the High-Fidelity Prototype

Prototype representative critical journeys, alternate states, recovery, and applicable responsive or localized modes.

A prototype is evidence for behavior and validation; it is not the canonical source for requirements or a substitute for specifications.

---

# 226. Step 06.15 — Validate the Design

Use the methods required by risk and profile:

```text
Design critique
Heuristic review
Accessibility review
Content review
Localization / RTL review
Prototype usability test
Technical feasibility review
Security / privacy review
Stakeholder validation
Cross-platform review
```

Record participants, scope, findings, severity, decisions, and evidence.

---

# 227. Step 06.16 — Resolve Findings and Control Upstream Change

Classify each finding as:

```text
DESIGN_FIX
EXPERIENCE_GAP
REQUIREMENT_GAP
PRODUCT_SCOPE_GAP
STANDARD_GAP
ARCHITECTURE_CONSTRAINT
CONTENT_GAP
IMPLEMENTATION_QUESTION
```

Only `DESIGN_FIX` is resolved entirely inside Phase 06.

Other classifications require return to the accountable owner and controlled baseline update.

---

# 228. Step 06.17 — Complete Coverage and Traceability

Run coverage checks for:

```text
Experience subjects
Requirements
Screens
States
Components
Responsive modes
Platforms
Roles
Accessibility
Localization / RTL
Standards
Validation findings
```

---

# 229. Step 06.18 — Prepare Design-to-Code Handoff

Prepare the implementation contract:

```text
Canonical source and revision
Tokens and code mapping
Component mapping
Screen / route mapping
Assets
Responsive rules
Behavior annotations
Accessibility semantics
Content source
Motion specs
Known constraints
Verification expectations
Change channel
```

---

# 230. Step 06.19 — Baseline Design Sources and Evidence

Before gate review:

```text
Resolve duplicate sources
Name canonical files / libraries
Record versions and publication state
Archive or mark deprecated sources
Freeze gate evidence
Record unresolved conditions
Link every artifact and register
```

---

# 231. Step 06.20 — Run G4B

The accountable approvers review the complete Design Baseline and issue one gate outcome.

No single screenshot, prototype presentation, or design-file approval constitutes G4B.

---

# 232. Phase 06 Artifact Catalog

| Artifact ID | Artifact | Purpose |
|---|---|---|
| `DES-001` | Product Design Direction | Establish visual and interaction direction |
| `DES-002` | Foundations and Token Specification | Define semantic design foundations |
| `DES-003` | Layout, Grid, Spacing, and Density Specification | Control composition and density |
| `DES-004` | Typography Specification | Define legible multilingual typography |
| `DES-005` | Color, Theme, and Contrast Specification | Define semantic color and theme behavior |
| `DES-006` | Iconography and Asset Specification | Govern icons, imagery, and assets |
| `DES-007` | Component System Specification | Define reusable component contracts |
| `DES-008` | Product Pattern Catalog | Define recurring product compositions |
| `DES-009` | Screen and View Design Catalog | Hold screen-level visual realization |
| `DES-010` | State and Feedback Design Catalog | Cover non-happy-path states and feedback |
| `DES-011` | Form and Input Design Specification | Define form and validation design |
| `DES-012` | Data-Dense and Visualization Design | Define tables, dashboards, and charts |
| `DES-013` | Content and Message Design Catalog | Define interface content and messages |
| `DES-014` | Responsive and Cross-Platform Design | Define recomposition and platform variants |
| `DES-015` | Accessibility Design Specification | Realize accessibility controls in design |
| `DES-016` | Localization and RTL Design Specification | Define localized and bidirectional behavior |
| `DES-017` | Motion and Transition Specification | Define purposeful, safe motion |
| `DES-018` | Generated Output and Notification Design | Define documents, print, email, and notifications |
| `DES-019` | High-Fidelity Prototype | Validate representative journeys and states |
| `DES-020` | Design Source and Library Index | Identify canonical design sources and versions |
| `DES-021` | Design Coverage and Traceability Matrix | Prove completeness and lineage |
| `DES-022` | Design Validation Record | Record validation evidence and resolution |
| `DES-023` | Design-to-Code and Engineering Handoff | Provide an implementation-ready contract |

Artifacts may be composed into fewer files or split across tools. The IDs and obligations remain stable.

---

# 233. DES-001 — Product Design Direction

Minimum content:

```text
Product and audience context
Design principles
Visual hierarchy
Brand relationship
Interaction character
Density posture
Accessibility and localization posture
Representative compositions
Constraints
Approved and rejected directions
Decision owners
```

---

# 234. DES-002 — Foundations and Token Specification

Minimum content:

```text
Token hierarchy
Naming grammar
Primitive / semantic / component levels
Modes and themes
Token values and aliases
Usage guidance
Contrast relationships
Code mapping
Ownership and version
Deprecation policy
```

---

# 235. DES-003 — Layout, Grid, Spacing, and Density Specification

Minimum content:

```text
Spacing scale
Grid and container rules
Alignment
Page templates
Elevation / layering
Density modes
Breakpoints and triggers
Safe areas
Overflow and scroll
Print constraints
```

---

# 236. DES-004 — Typography Specification

Minimum content:

```text
Font families and fallbacks
Supported scripts
Type roles and tokens
Weights and emphasis
Line height and spacing
Numerals and tabular data
Links and inline states
Responsive behavior
Arabic and complex-script validation
Export / email fallback
```

---

# 237. DES-005 — Color, Theme, and Contrast Specification

Minimum content:

```text
Semantic color roles
Surface and text pairs
Action and status colors
Light / dark / high-contrast modes
Interactive states
Non-text contrast
Data visualization palette
Contrast evidence
Platform exceptions
```

---

# 238. DES-006 — Iconography and Asset Specification

Minimum content:

```text
Icon system and grid
Size and stroke rules
Semantic naming
RTL classification
Accessible naming responsibility
Illustration / image guidance
Asset formats and export
Licensing / attribution
Optimization
Deprecation and replacement
```

---

# 239. DES-007 — Component System Specification

Minimum content:

```text
Component registry
Contract and anatomy
Properties / variants / states
Tokens
Behavior
Accessibility semantics
Responsive / RTL behavior
Content constraints
Source component
Code component mapping
Adoption and deprecation status
```

---

# 240. DES-008 — Product Pattern Catalog

Minimum content:

```text
Pattern purpose
Applicable experience objects
Composition
Behavior and states
Component dependencies
Responsive / RTL behavior
Accessibility
Content guidance
Examples and anti-examples
```

---

# 241. DES-009 — Screen and View Design Catalog

Minimum content per design subject:

```text
Design subject ID
Screen / view ID
Journey / flow / state references
Role and permission context
Layout and component instances
Content reference
Responsive / platform variants
Localization / RTL variants
Accessibility annotations
Prototype link
Source revision
Status and owner
```

---

# 242. DES-010 — State and Feedback Design Catalog

Minimum state coverage:

```text
Initial
Loading
Partial loading
Empty
No results
Error
Permission denied
Unavailable
Offline
Conflict
Processing
Success
Unknown outcome
Interrupted
Expired
Recovery
```

Use only states applicable to the subject; mark omitted states with reason.

---

# 243. DES-011 — Form and Input Design Specification

Minimum content:

```text
Field families
Labels and help
Required / optional behavior
Input formatting
Validation timing
Inline and summary errors
Keyboard and autofill
Sensitive data
Save / submit / retry
Multi-step forms
Accessibility and localization
```

---

# 244. DES-012 — Data-Dense and Visualization Design

Minimum content:

```text
Tables and lists
Sorting / filtering / search
Selection and bulk actions
Pagination / virtualization
Sticky and frozen regions
Charts and dashboards
Alternative data representation
Responsive transformation
RTL and localization
Accessibility
Loading, empty, stale, and error states
```

---

# 245. DES-013 — Content and Message Design Catalog

Minimum content:

```text
Content ID
Surface and trigger
Source / owner
Final or controlled draft text
Dynamic variables
Length and wrapping constraints
Localization status
Tone
Accessibility considerations
Security / privacy constraints
Fallback
```

---

# 246. DES-014 — Responsive and Cross-Platform Design

Minimum content:

```text
Supported modes and platforms
Breakpoint rationale
Recomposition rules
Input-mode differences
Orientation / window states
Platform divergence
Safe areas and system UI
Responsive screen examples
Test expectations
```

---

# 247. DES-015 — Accessibility Design Specification

Minimum content:

```text
Applicability and target
Token and contrast controls
Focus and keyboard behavior
Target sizes
Semantic annotations
Forms and errors
Status announcements
Zoom / reflow
Reduced motion
Authentication
Generated outputs
Third-party constraints
Evidence and exceptions
```

---

# 248. DES-016 — Localization and RTL Design Specification

Minimum content:

```text
Locales and directions
Typography and fallback
Layout / order rules
Icon classification
Mixed-direction handling
Number / date / currency behavior
Content expansion
Missing-translation behavior
Localized screen evidence
Export / notification behavior
```

---

# 249. DES-017 — Motion and Transition Specification

Minimum content:

```text
Motion objects and tokens
Triggers and states
Purpose
Duration and easing
Interruption
Reduced-motion behavior
Loading and progress
Performance constraints
Prototype examples
```

---

# 250. DES-018 — Generated Output and Notification Design

Minimum content:

```text
Output / channel inventory
Template and hierarchy
Content variables
Responsive / email-client behavior
Print / pagination
Accessibility
Localization / RTL
Sensitive-data rules
Failure and retry messages
Source and ownership
```

---

# 251. DES-019 — High-Fidelity Prototype

Minimum coverage:

```text
Critical journeys
Key role variants
Success path
High-risk errors and recovery
Loading / processing / unknown outcome
Responsive or platform variant
Localization / RTL where applicable
Keyboard and focus behavior where the tool supports it
Reduced-motion representation where applicable
Validation tasks
Prototype limitations
```

A prototype limitation must be documented if the tool cannot faithfully represent required semantics or behavior.

---

# 252. DES-020 — Design Source and Library Index

This artifact identifies source-of-truth locations, whether Figma or an equivalent design environment.

Minimum content:

```text
Source ID
File / library / page / section
URL or repository path
Owner
Purpose
Canonical status
Version / publication status
Dependencies
Consumers
Deprecated replacement
Access and export notes
```

---

# 253. DES-021 — Design Coverage and Traceability Matrix

Minimum relationships:

```text
Requirement → Experience Object
Experience Object → Design Subject
Design Subject → Screen / State
Screen / State → Component / Pattern
Component / Pattern → Token
Design Object → Standard / Control
Design Object → Validation Evidence
Design Object → Code Mapping / Verification Expectation
```

---

# 254. DES-022 — Design Validation Record

Minimum content:

```text
Validation ID
Method
Date and participants
Scope and environment
Tasks / checks
Evidence
Finding and severity
Affected IDs
Decision
Owner and due date
Resolution evidence
Residual risk
Status
```

---

# 255. DES-023 — Design-to-Code and Engineering Handoff

Minimum content:

```text
Baseline ID and source revisions
Implementation scope
Token and theme contract
Component and pattern mappings
Screen / route mappings
Assets and export rules
Responsive / platform behavior
Accessibility semantics and checks
Localization / RTL rules
Content and messages
Motion details
Generated outputs
Open constraints and assumptions
Expected tests and evidence
Change-control route
Owners and acknowledgement
```

---

# 256. Governance Registers Updated by Phase 06

Phase 06 updates or creates references in:

```text
REG-DEC — Decision Register
REG-RSK — Risk Register
REG-ASM — Assumption Register
REG-DEP — Dependency Register
REG-ISS — Issue Register
REG-CHG — Change Register
REG-TRC — Traceability Register
REG-STD — Standards / GOV-009 Register
REG-VAL — Validation Evidence Register
REG-DSR — Design Source Register
REG-CMP — Component and Adoption Register
REG-CON — Content Register
```

The exact storage form may vary, but ownership and traceability must not disappear.

---

# 257. Product Design Profiles

Product OS uses three execution profiles:

```text
P1 — Lean
P2 — Standard
P3 — Comprehensive
```

Profiles change depth and evidence, not the meaning of completion.

---

# 258. P1 — Lean Product Design

Appropriate for low-risk, narrow-scope work.

Minimum expectations:

```text
Explicit design direction
Small semantic token set
Required component contracts
Critical screens and all applicable critical states
Responsive behavior for supported surfaces
Accessibility and localization controls
Representative prototype or equivalent walkthrough
Traceability to requirements and experience
Named source of truth
Engineering handoff
G4B evidence
```

Artifacts may be consolidated, but required content may not be omitted.

---

# 259. P2 — Standard Product Design

The default profile for production software.

Includes the complete artifact set at the depth appropriate to product scope, with:

```text
Reusable foundations and components
Screen and state coverage
Responsive and cross-platform rules
Accessibility and localization evidence
Content and motion specifications
Prototype validation
Design-to-code mapping
Formal G4B review
```

---

# 260. P3 — Comprehensive Product Design

Appropriate for high-risk, regulated, enterprise, multi-brand, multi-platform, safety-relevant, or large-scale systems.

Additional depth may include:

```text
Multiple brands / themes / products
Formal token governance
Platform-specific libraries
Extensive component conformance matrices
Multiple languages and assistive technologies
Independent accessibility review
Design assurance evidence
Generated-document validation
Third-party fallback designs
Migration and adoption program
Measured usability and accessibility benchmarks
Formal exception and waiver review
```

---

# 261. Domain-Level Profile Overrides

A project may use a base profile with stricter treatment for selected domains.

Example:

```text
Project profile: P2
Payments and consent: P3
Internal low-risk administration: P1
Accessibility: P3
Generated reports: P2
```

Overrides must be documented in the Design Scope Map and `GOV-009`.

---

# 262. Profile Selection Inputs

Consider:

```text
User harm
Financial consequence
Regulation
Accessibility impact
Data sensitivity
Workflow criticality
Platform count
Locale count
Design-system maturity
Change scale
Reuse breadth
Third-party dependence
Migration complexity
```

Profile selection cannot be based only on schedule pressure.

---

# 263. Behavior by Product Stage

Product Design adapts to the product stage while preserving traceability and applicable controls.

```text
S0 — Concept
S1 — Prototype
S2 — MVP
S3 — Growth
S4 — Scale
S5 — Enterprise / Regulated
S6 — Legacy Transformation
```

---

# 264. S0 / S1 — Concept and Prototype

Focus on:

```text
Direction alternatives
Core flow realization
Critical assumptions
Representative states
Early accessibility and localization feasibility
Prototype learning
Reusable foundations only where useful
```

Exploratory work must remain visually distinct from a baselined production specification.

---

# 265. S2 — MVP

Focus on:

```text
Minimum coherent system
Complete states for in-scope journeys
Production-ready accessibility controls
Responsive behavior for supported surfaces
Real content constraints
Handoff clarity
Intentional deferral with reopen conditions
```

`MVP` is not permission to omit failure, accessibility, security, or recovery design.

---

# 266. S3 / S4 — Growth and Scale

Focus on:

```text
System consolidation
Adoption measurement
Variant control
Cross-product consistency
Theme / mode scalability
Performance-aware assets and motion
Content and localization scale
Migration and deprecation
Design-code parity
```

---

# 267. S5 — Enterprise or Regulated

Focus on:

```text
Formal controls and evidence
Role / permission complexity
Dense operational workflows
Audit and receipt patterns
Accessibility assurance
Generated documents
Data handling and privacy
Exception governance
Independent review
```

---

# 268. S6 — Legacy Transformation

Focus on:

```text
Current-state inventory
Canonical-source resolution
Component duplication
Usage and adoption evidence
Incremental migration
Compatibility constraints
Parallel old / new states
Deprecation and rollback
User relearning risk
```

---

# 269. Existing Design-System Assessment

Assess each candidate source against:

```text
Authority
Currency
Completeness
Product adoption
Code adoption
Accessibility
Localization / RTL
Responsive behavior
Documentation
Ownership
Versioning
Deprecation
```

Do not assume the most polished file is canonical.

---

# 270. Current-State vs Target-State Design

Maintain explicit relationships:

```text
Current source / object
Current product usage
Target source / object
Migration action
Compatibility need
Owner
Target release
Validation
Retirement condition
```

---

# 271. Published vs Adopted

Product OS distinguishes:

```text
DRAFT — exists but is not approved
APPROVED — approved as a design object
PUBLISHED — available from a shared source
ADOPTED — used in a real product surface
CODE_MAPPED — mapped to implementation
VERIFIED — implementation parity evidenced
DEPRECATED — replacement identified
RETIRED — no approved active use remains
```

These statuses are not interchangeable.

---

# 272. Design Source Authority

Authority must be explicit per object family:

```text
Requirements source
Experience source
Design source
Content source
Token source
Component source
Asset source
Code source
Test / evidence source
```

Where sources disagree, a decision is required; silent selection is prohibited.

---

# 273. Validation Strategy

Validation depth is based on risk, novelty, uncertainty, and profile.

Combine methods rather than relying on a single review.

---

# 274. Design Critique

Critique tests:

```text
Hierarchy
Clarity
Consistency
Affordance
Composition
State communication
Reuse
Content
Responsiveness
Fit to design direction
```

Preference alone is not a finding; critique should reference a principle, user need, requirement, pattern, or risk.

---

# 275. Heuristic Review

Review applicable heuristics such as:

```text
System status visibility
Match to user language and mental model
User control and freedom
Consistency
Error prevention
Recognition over recall
Efficiency
Recovery
Help and guidance
```

---

# 276. Accessibility Design Review

Use both design inspection and representative interactive validation.

At minimum, review:

```text
Contrast
Focus visibility
Keyboard sequence
Target size
Semantics annotations
Forms and errors
Reading order
Zoom / reflow
Reduced motion
Authentication
Localization / RTL interaction
Generated outputs
```

Automated contrast checks alone are insufficient.

---

# 277. Prototype Usability Validation

Define:

```text
Research question
Target participant
Task
Success signal
Failure / confusion signal
Critical state or recovery
Prototype limitation
Evidence capture
Decision threshold
```

Do not convert participant preference directly into scope without analysis.

---

# 278. Technical Feasibility Review

Engineering and architecture review:

```text
Component feasibility
Platform constraints
Performance
Data availability
State availability
Security and privacy
Accessibility implementation
Localization
Third-party constraints
Generated outputs
Migration
```

A feasibility constraint becomes a recorded decision or upstream change—not an undocumented implementation deviation.

---

# 279. Content and Localization Review

Validate:

```text
Meaning and action clarity
Terminology
Dynamic variables
Length and wrapping
Pluralization
Locale formats
Arabic shaping
RTL order
Error and recovery content
Legal / market content
```

---

# 280. Design Evidence

Acceptable evidence may include:

```text
Versioned design source
Component property export
Screen and state matrix
Annotated design
Prototype recording
Validation report
Contrast and reflow report
Localized / RTL specimen
Design-code mapping
Decision record
Review acknowledgement
```

Evidence must be attributable, dated or versioned, and linked to affected IDs.

---

# 281. Coverage Model

Product Design completeness is measured through intersecting coverage dimensions:

```text
Scope coverage
Journey / flow coverage
Screen coverage
State coverage
Role / permission coverage
Component coverage
Token coverage
Responsive / platform coverage
Localization / RTL coverage
Accessibility coverage
Standard coverage
Validation coverage
Handoff coverage
```

---

# 282. Screen Coverage

Each in-scope screen or view from the Experience Baseline must be:

```text
DESIGNED
COVERED_BY_PATTERN
DEFERRED_WITH_APPROVAL
NOT_APPLICABLE
BLOCKED
```

Every status other than `DESIGNED` requires a reason, owner, and reopen condition where relevant.

---

# 283. State Coverage

For every design subject, compare required experience states to designed states.

Track:

```text
Required state
Design reference
Content reference
Component / pattern reference
Responsive / RTL variant
Accessibility behavior
Validation status
```

---

# 284. Component Coverage

For each component need:

```text
Need source
Canonical component
Required properties
Required states
Design source
Product adoption
Code mapping
Gap / migration status
```

One-off screen elements must be justified if a reusable component need exists.

---

# 285. Token Coverage

Check that every baselined component and pattern consumes approved semantic tokens for applicable design properties.

Raw values require a documented exception or migration status.

---

# 286. Standards Coverage

Each active `GOV-009` design obligation must map to:

```text
Design control
Affected source objects
Evidence
Owner
Status
Exception if any
Downstream verification obligation
```

---

# 287. Orphan Design Objects

An orphan may be:

```text
Screen without experience source
State without trigger or outcome
Component without product need
Token without consumer
Pattern without approved use
Content without surface or owner
Motion without purpose
Prototype branch without specification
Design obligation without evidence
```

Orphans must be linked, reclassified as exploration, deprecated, or removed from the baseline.

---

# 288. Detached Instances and Local Overrides

Detached instances and uncontrolled local overrides create design-system drift.

For each material case:

```text
Identify the source component
Explain the override need
Decide whether to improve the component or allow an exception
Record affected screens
Define migration / verification
```

---

# 289. Prototype Coverage Limits

The prototype may intentionally omit expensive or tool-limited behavior, but the omission must be listed with:

```text
Affected behavior
Reason
Specification source
Validation alternative
Implementation risk
Owner
```

---

# 290. Design Baseline

The Design Baseline is the approved, versioned set of Phase 06 artifacts and evidence that defines the implementation-ready visual and interaction realization of the approved product experience.

It includes source references, not merely exported screenshots.

---

# 291. Baseline Contents

At minimum:

```text
Design scope and profile
Upstream baseline references
GOV-009 revision
DES-001 through DES-023 or approved equivalents
Canonical design-source revisions
Coverage and traceability
Validation evidence
Decisions, exceptions, and residual risks
Implementation handoff
Gate evidence and approval
```

---

# 292. Baseline Versioning

Use a stable baseline identifier.

Example:

```text
baseline_id: DBL-2026-001
phase: PHASE-06
gate: G4B
version: 1.0
status: APPROVED
requirements_baseline: RBL-2026-001
experience_baseline: EBL-2026-001
gov_009_revision: GOV-009@1.3
design_source_revision: DSR-2026-004
```

---

# 293. G4B — Design Baseline

`G4B` answers:

> Is the approved experience now represented by a coherent, complete, accessible, traceable, validated, and implementation-ready design system and product design baseline?

---

# 294. G4B Check 01 — Scope and Upstream Baselines

Confirm:

```text
G3B and G4A references are valid
Design scope is explicit
Profiles and overrides are recorded
Open upstream conditions are addressed
No material scope was invented
```

---

# 295. G4B Check 02 — Design Direction

Confirm the approved direction is coherent, product-specific, usable, and proven in representative product compositions.

---

# 296. G4B Check 03 — Foundations and Tokens

Confirm semantic foundations, token hierarchy, themes, modes, ownership, and code-mapping strategy are complete for the approved scope.

---

# 297. G4B Check 04 — Layout and Density

Confirm grid, spacing, composition, layering, density, overflow, and page-template rules are usable across required screens and surfaces.

---

# 298. G4B Check 05 — Typography

Confirm readability, hierarchy, supported scripts, fallbacks, scaling, data presentation, and Arabic or complex-script quality where applicable.

---

# 299. G4B Check 06 — Color, Theme, and Contrast

Confirm semantic color use, theme coverage, interactive states, non-text contrast, data visualization, and recorded contrast evidence.

---

# 300. G4B Check 07 — Iconography and Assets

Confirm semantic clarity, consistency, RTL behavior, accessibility responsibility, licensing, formats, optimization, and ownership.

---

# 301. G4B Check 08 — Component Completeness

Confirm required component contracts, properties, variants, states, behavior, semantics, responsive rules, RTL rules, and content constraints are complete.

---

# 302. G4B Check 09 — Component Adoption and Governance

Confirm canonical sources, actual product adoption, local overrides, code mappings, duplicate handling, ownership, and deprecation plans.

---

# 303. G4B Check 10 — Product Patterns

Confirm recurring tasks use documented patterns that preserve approved experience behavior and required states.

---

# 304. G4B Check 11 — Screen and View Coverage

Confirm every in-scope design subject is designed, covered by an approved pattern, or explicitly classified with reason and owner.

---

# 305. G4B Check 12 — State, Feedback, and Recovery Coverage

Confirm applicable loading, empty, error, denied, unavailable, offline, conflict, processing, success, unknown-outcome, interruption, expiry, and recovery states are represented.

---

# 306. G4B Check 13 — Forms and Input

Confirm form structure, labels, validation, errors, help, sensitive fields, save or submit behavior, keyboard behavior, and recovery.

---

# 307. G4B Check 14 — Data-Dense and Visualization Design

Confirm applicable tables, search, filters, bulk actions, pagination, dashboards, charts, alternate representations, and states are complete.

---

# 308. G4B Check 15 — Content and Messages

Confirm critical labels, actions, errors, confirmations, dynamic variables, ownership, localization status, and security constraints.

---

# 309. G4B Check 16 — Responsive and Cross-Platform Design

Confirm all supported modes, viewports, platforms, orientations, input methods, and intentional divergences are specified and evidenced.

---

# 310. G4B Check 17 — Localization and RTL

Confirm locale formats, expansion, typography, shaping, mixed-direction content, ordering, icon behavior, and localized design evidence.

---

# 311. G4B Check 18 — Accessibility

Confirm applicable standards and requirements are realized through tokens, components, screens, states, semantics, content, motion, prototypes, and generated outputs with evidence.

---

# 312. G4B Check 19 — Security and Privacy

Confirm masking, consent, permissions, consequential actions, sessions, reauthentication, safe errors, and sensitive-output treatment.

---

# 313. G4B Check 20 — Motion and Transitions

Confirm motion has a purpose, controlled timing, interruption behavior, reduced-motion alternative, and implementation-ready specification.

---

# 314. G4B Check 21 — Generated Outputs, Notifications, and Third Parties

Confirm applicable documents, print, emails, notifications, embedded services, and alternate or fallback paths are designed.

---

# 315. G4B Check 22 — Prototype and Validation

Confirm representative critical journeys and risks were validated, limitations are visible, findings are resolved or accepted, and evidence is linked.

---

# 316. G4B Check 23 — Traceability and GOV-009

Confirm bidirectional traceability, standards-control mapping, evidence references, exceptions, and downstream obligations.

---

# 317. G4B Check 24 — Source, Version, and Design-to-Code Readiness

Confirm canonical files and libraries, versions, publication state, assets, token and component mappings, annotations, and verification expectations.

---

# 318. G4B Check 25 — Open Items and Engineering Readiness

Confirm:

```text
No unresolved blocker is hidden
Questions have owners and due dates
Residual risks are accepted by the right authority
Upstream changes are baselined
Phase 07 and Phase 08 obligations are explicit
Engineering can implement without inventing material design behavior
```

---

# 319. G4B Outcomes

Allowed outcomes:

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

Definitions:

- `PASS` — complete and approved for downstream consumption.
- `PASS_WITH_CONDITIONS` — no blocking deficiency; named conditions, owners, due dates, and downstream restrictions exist.
- `HOLD` — review paused until specified evidence or decisions are available.
- `REJECT` — material incompleteness or inconsistency requires rework and another gate review.

---

# 320. G4B Blocking Conditions

G4B cannot pass when any of the following is material to the approved scope:

```text
Invalid G3B or G4A reference
Uncontrolled scope or experience change
Missing critical screen or state
Unresolved accessibility blocker
Unresolved security / privacy design blocker
Unknown canonical source
Prototype-only behavior without specification
Missing responsive or RTL realization
Missing component contract for implementation
No design-to-code handoff
No traceability or evidence
Unowned high-severity finding
```

---

# 321. PASS_WITH_CONDITIONS Rules

A condition is permitted only when:

```text
The remaining item is non-blocking
Affected scope is explicit
Risk is understood and accepted
Owner and due date exist
Verification evidence is defined
Downstream use restrictions are recorded
Automatic reopen trigger exists
```

`PASS_WITH_CONDITIONS` is not a container for an incomplete critical design.

---

# 322. G4B Evidence Record

Example:

```yaml
gate_id: G4B
phase: PHASE-06
baseline_id: DBL-2026-001
decision: PASS_WITH_CONDITIONS
decision_date: 2026-08-10
upstream:
  requirements_baseline: RBL-2026-001
  experience_baseline: EBL-2026-001
  gov_009_revision: GOV-009@1.3
design_sources:
  - source_id: DSRC-001
    revision: "42"
    status: CANONICAL
checks:
  total: 25
  passed: 24
  conditional: 1
  failed: 0
conditions:
  - id: G4B-COND-001
    scope: "Generated report RTL pagination"
    owner: ROLE-DESIGN-SYSTEM
    due_date: 2026-08-17
    downstream_restriction: "Do not implement Arabic PDF export until closed"
approvals:
  product_design: APPROVED
  experience_architecture: APPROVED
  product: APPROVED
  engineering: ACKNOWLEDGED
  accessibility: APPROVED_WITH_CONDITION
evidence:
  - DES-021
  - DES-022
  - DES-023
```

---

# 323. Gate Approvers

Required roles are selected by profile and risk.

Typical approvers and acknowledgers:

```text
Product Design Lead
Product Owner
Experience Architect / UX Lead
Design System Owner
Accessibility Owner
Content / Localization Owner
Engineering Lead
Solution Architect
Security / Privacy Owner
QA / Verification Lead
Business or regulatory authority where required
```

Approval responsibility cannot be assigned to an AI system.

---

# 324. Phase 07 Handoff

Phase 07 receives design constraints that affect solution architecture, including:

```text
Platform and surface assumptions
Theme / token architecture needs
Component and rendering constraints
State and data requirements exposed by design
Localization / RTL infrastructure needs
Accessibility implementation obligations
Asset delivery and content needs
Motion / performance constraints
Generated-output requirements
Third-party UI constraints
Security / privacy presentation requirements
```

Phase 07 does not redesign the experience; it confirms how the solution can realize it.

---

# 325. Phase 08 Handoff

Phase 08 receives:

```text
Baselined design scope
Canonical sources and revisions
Component / token / code mappings
Screen / route mappings
Annotations and assets
Content source
Responsive and platform rules
Accessibility and RTL rules
Test and evidence expectations
Open conditions and risks
Change-control rules
```

---

# 326. Canonical Traceability Chain

```text
Business Requirement / Goal
→ Product Capability
→ Requirement
→ Experience Journey / Flow / State
→ Design Subject
→ Screen / State / Pattern
→ Component / Token / Content / Motion
→ Design Evidence
→ Architecture Decision
→ Engineering Work Item
→ Code / Configuration
→ Verification Evidence
```

Traceability must support movement both upstream and downstream.

---

# 327. Design-to-Code Contract

The contract defines meaning and mapping, not pixel copying.

It includes:

```text
Design object ID
Design source revision
Code package / component / token target
Properties and states
Semantic behavior
Responsive / RTL behavior
Accessibility contract
Content contract
Motion contract
Assets
Verification criteria
Known divergence
Owner
```

---

# 328. Token-to-Code Mapping

Example:

```yaml
token_id: TOK-COLOR-ACTION-PRIMARY
design_name: color.action.primary
code_name: --color-action-primary
mobile_name: ColorTokens.actionPrimary
mode_support:
  - light
  - dark
  - high_contrast
status: MAPPED
verification:
  - visual_regression
  - contrast_check
```

---

# 329. Component-to-Code Mapping

Example:

```yaml
component_id: CMP-BUTTON
design_source: DSRC-LIB-001
code_target: "@product/ui/Button"
properties:
  emphasis: [primary, secondary, quiet, danger]
  size: [compact, regular, large]
states:
  - default
  - hover
  - focus
  - pressed
  - disabled
  - loading
accessibility_contract:
  role: button
  name_source: visible_label
  focus_visible: required
status: CODE_MAPPED
```

---

# 330. Screen-to-Route Mapping

Where software uses routes or view identifiers, map:

```text
Design subject ID
Screen / view ID
Route / view target
Entry conditions
Role and permission
Primary states
Responsive modes
Feature flag
Owner
Verification reference
```

---

# 331. Asset Handoff

Each production asset records:

```text
Asset ID
Purpose
Source
Format
Dimensions / density
Color / theme variants
RTL variant
Alternative text responsibility
Optimization
License
Destination
Version
```

Screenshots of assets are not production exports.

---

# 332. Annotation Rules

Annotate behavior that cannot be safely inferred from static appearance.

Annotations must:

```text
Use stable IDs
Reference the owning requirement or experience object
Describe trigger, behavior, state, and outcome
Avoid duplicating canonical text that can drift
Identify platform or mode scope
Name unresolved questions
Remain versioned with the design source
```

---

# 333. Design QA Expectations

Phase 06 defines what later implementation verification should inspect:

```text
Token parity
Component state parity
Layout and responsive behavior
Typography and content
Theme behavior
RTL and localization
Accessibility semantics and keyboard
Motion and reduced motion
Asset correctness
Generated outputs
Design-approved intentional divergences
```

It does not replace Phase 10 verification planning and execution.

---

# 334. Change Control After G4B

Any material change after G4B requires impact analysis across:

```text
Requirements
Experience
Design system
Screens and states
Content
Accessibility
Localization / RTL
Standards
Architecture
Engineering work
Verification evidence
Release scope
```

---

# 335. Design Change Classification

```text
PATCH — correction with no material behavior or contract change
MINOR — compatible extension or additional state / variant
MAJOR — breaking design, behavior, source, or mapping change
UPSTREAM — requires change to requirement, scope, or experience baseline
EMERGENCY — urgent safety, security, accessibility, or production correction
```

Classification must consider consumers, not only visual difference.

---

# 336. G4B Reopen Triggers

Reopen G4B when a baselined change materially affects:

```text
Critical journey or state
Design direction
Token semantics
Component contract
Canonical design source
Accessibility conformance
Localization / RTL
Supported platform or viewport
Security / privacy interaction
Generated output
Design-to-code contract
Open gate condition
```

---

# 337. Emergency Design Changes

Emergency changes may use an accelerated review only when:

```text
Urgency and impact are recorded
Minimum safe design and accessibility review occurs
Affected source and code objects are identified
Rollback or correction path exists
Post-change baseline reconciliation is scheduled
Accountable human approval exists
```

---

# 338. Phase 06 Roles

Core roles may include:

```text
Product Design Lead
Product Designer
UX / Experience Architect
Design System Owner
Product Owner
Requirements Lead
Content Designer
Localization / RTL Specialist
Accessibility Specialist
Solution Architect
Engineering Lead
Security / Privacy Specialist
QA / Verification Lead
Researcher
```

One person may hold multiple roles in P1 or P2, but responsibilities remain explicit.

---

# 339. Product Design Lead Responsibilities

```text
Own Phase 06 coherence
Confirm scope and profile
Approve direction and design quality
Ensure coverage and traceability
Control design decisions and changes
Prepare G4B evidence
Own downstream design handoff
```

---

# 340. Experience Architect Responsibilities

```text
Protect the G4A baseline
Clarify journeys, flows, states, and behavior
Identify upstream experience changes
Validate that visual realization preserves approved intent
Approve experience-affecting design decisions
```

---

# 341. Design System Owner Responsibilities

```text
Own foundations, tokens, and component source
Control naming, versioning, publication, and deprecation
Review variants and local overrides
Maintain adoption and code mappings
Coordinate migration
Protect accessibility and localization contracts
```

---

# 342. Product Owner Responsibilities

```text
Confirm product scope and priority
Resolve product tradeoffs
Approve consequential content and outcomes
Accept residual product risk within authority
Prevent design from silently expanding or reducing scope
```

---

# 343. Requirements Lead Responsibilities

```text
Clarify requirement intent
Confirm acceptance criteria and constraints
Route requirement gaps
Maintain traceability
Control G3B changes caused by design findings
```

---

# 344. Accessibility Owner Responsibilities

```text
Confirm applicable accessibility requirements
Review system and screen realization
Define evidence depth
Review exceptions and alternatives
Approve or block accessibility gate checks within authority
Handoff verification obligations
```

---

# 345. Content and Localization Responsibilities

```text
Own terminology and message quality
Manage dynamic-content rules
Validate translation readiness
Validate locale formats and RTL
Protect legal and market-specific content
Define content source and change path
```

---

# 346. Engineering and Architecture Responsibilities

```text
Review feasibility without redesigning silently
Confirm code mapping strategy
Identify performance and platform constraints
Confirm architecture obligations
Estimate migration implications
Define implementation evidence
Acknowledge handoff readiness
```

---

# 347. QA and Verification Responsibilities

```text
Review testability
Confirm observable states and acceptance evidence
Identify ambiguous design behavior
Prepare design-parity and accessibility verification needs
Trace later defects to baselined design objects
```

---

# 348. AI Responsibilities in Phase 06

AI may assist with:

```text
Source inventory and classification
Traceability gap detection
State and variant enumeration
Token and component consistency analysis
Content stress-test generation
Localization / RTL edge-case generation
Accessibility checklist support
Design-source metadata extraction
Artifact drafting
Coverage reporting
Change impact analysis
```

AI output remains draft until reviewed by the accountable human owner.

---

# 349. AI Prohibitions

AI must not:

```text
Invent approval
Change requirements or experience silently
Declare accessibility conformance from appearance alone
Assume a library object is adopted in product
Replace user research with synthetic preference
Use placeholder content as final content
Select a canonical source without evidence
Hide unsupported states or platforms
Generate deceptive consent or dark patterns
Declare G4B passed
```

---

# 350. Human Accountability

Humans remain accountable for:

```text
Product decisions
User and business tradeoffs
Design quality
Accessibility and compliance decisions
Research interpretation
Security and privacy decisions
Risk acceptance
Source authority
Gate approval
```

---

# 351. Phase 06 Validation Rules

The following rules are mandatory unless explicitly marked `NOT_APPLICABLE` with reason and reopen condition.

---

# 352. VAL-DES-001 — Upstream Integrity

Every baselined design subject must trace to an approved experience object and requirement or to an approved exploratory classification.

---

# 353. VAL-DES-002 — No Silent Scope Change

A design that introduces or removes a material user outcome, permission, state, data need, or journey step must trigger upstream review.

---

# 354. VAL-DES-003 — Canonical Source

Every baselined object family must have one named canonical source or a controlled composition of sources.

---

# 355. VAL-DES-004 — System Before Repetition

Repeated visual or behavioral needs must use an approved component or pattern, or carry a recorded exception.

---

# 356. VAL-DES-005 — State Completeness

Every required experience state must have a design reference, pattern coverage, or explicit classification.

---

# 357. VAL-DES-006 — Semantic Tokens

Baselined components must use approved semantic tokens for applicable properties; uncontrolled raw values fail validation.

---

# 358. VAL-DES-007 — Component Contract

A component is not baseline-ready without defined anatomy, properties, states, behavior, semantics, responsive behavior, and ownership.

---

# 359. VAL-DES-008 — Adoption Evidence

Published components and patterns may be marked `ADOPTED` only when evidenced in a real approved product surface.

---

# 360. VAL-DES-009 — Accessibility Realization

Accessibility requirements must be visible in the design contract and evidence, not deferred as a generic engineering responsibility.

---

# 361. VAL-DES-010 — Contrast Evidence

Applicable final token combinations and component states must have contrast evidence.

---

# 362. VAL-DES-011 — Focus and Keyboard

Interactive patterns must define visible focus, logical sequence, containment, restoration, and keyboard operation expectations.

---

# 363. VAL-DES-012 — Responsive Recomposition

Every supported responsive mode must preserve required content, action, status, context, and recovery.

---

# 364. VAL-DES-013 — Localization and RTL

Applicable screens and components must be validated with representative localized and RTL content, including complex-script rendering.

---

# 365. VAL-DES-014 — Content Ownership

Critical interface content and messages must have a source, owner, variables, and localization status.

---

# 366. VAL-DES-015 — Motion Safety

Non-trivial motion must have purpose, interruption behavior, and a reduced-motion or no-motion alternative.

---

# 367. VAL-DES-016 — Generated Outputs

Applicable generated documents and notifications must be designed and traced, including accessibility, localization, and sensitive-data controls.

---

# 368. VAL-DES-017 — Third-Party Surfaces

Required third-party journey surfaces must have known constraints, fallback treatment, and evidence ownership.

---

# 369. VAL-DES-018 — Prototype Limits

Prototype behavior that differs from the design contract must be explicitly documented.

---

# 370. VAL-DES-019 — Validation Resolution

High-severity validation findings must be resolved or formally accepted by the correct authority before G4B.

---

# 371. VAL-DES-020 — Design-to-Code Mapping

Implementation-relevant tokens, components, assets, screens, and behaviors must have named targets or an owned mapping action.

---

# 372. VAL-DES-021 — Traceability

Traceability must be navigable both from requirement to design and from design object to its upstream source and downstream expectation.

---

# 373. VAL-DES-022 — GOV-009 Evidence

Every active Product Design obligation in `GOV-009` must have design evidence or an approved exception.

---

# 374. VAL-DES-023 — Version Integrity

Gate evidence, design sources, libraries, prototype, and handoff must reference compatible revisions.

---

# 375. VAL-DES-024 — No Hidden Blocker

Unknown ownership, missing critical states, unresolved upstream contradictions, and accessibility blockers cannot be relabeled as downstream tasks.

---

# 376. VAL-DES-025 — Human Approval

G4B requires accountable human approval; automated completeness checks cannot issue the gate decision.

---

# 377. Product Design Anti-Patterns

The following patterns invalidate or weaken Phase 06.

---

# 378. Anti-Pattern 01 — UI Kit Before Product Understanding

Creating a library before confirming journeys, states, content, and product need produces decorative inventory rather than a product system.

---

# 379. Anti-Pattern 02 — Happy-Path Gallery

A set of ideal-state screens without loading, error, permission, conflict, and recovery is incomplete.

---

# 380. Anti-Pattern 03 — Screen Factory

Producing many frames without reusable rules, components, or traceability creates drift and implementation ambiguity.

---

# 381. Anti-Pattern 04 — Generic Trend Direction

Copying a visual trend, template, or mood without product-specific rationale weakens clarity and longevity.

---

# 382. Anti-Pattern 05 — Raw-Value Design

Scattered colors, spacing, radius, shadows, and type values without semantic tokens prevent controlled change.

---

# 383. Anti-Pattern 06 — Token Explosion

Creating a new token for every isolated value without semantic reuse makes the system harder to understand and govern.

---

# 384. Anti-Pattern 07 — Giant Universal Component

One component with unrelated responsibilities and dozens of conditional properties is not meaningful reuse.

---

# 385. Anti-Pattern 08 — Variant Explosion

Encoding every screen difference as a component variant creates combinatorial complexity and hides product patterns.

---

# 386. Anti-Pattern 09 — Detached-Instance Workflow

Routine detachment or local rebuilding bypasses component governance and destroys adoption visibility.

---

# 387. Anti-Pattern 10 — Library-Only Adoption

Publishing a component or showing it in documentation does not prove it is used in an active product screen.

---

# 388. Anti-Pattern 11 — Static Canvas as Specification

A static frame cannot fully specify focus, keyboard behavior, timing, interruption, semantics, state transitions, or recovery.

---

# 389. Anti-Pattern 12 — Screenshot Handoff

Screenshots without sources, IDs, components, tokens, states, and behavior annotations are not an engineering contract.

---

# 390. Anti-Pattern 13 — Screen Copy as Content Source

Unowned text copied across frames drifts, cannot be localized reliably, and hides dynamic-variable constraints.

---

# 391. Anti-Pattern 14 — Placeholder Content Approval

Lorem ipsum, short fake names, and idealized numbers conceal layout, comprehension, localization, and privacy problems.

---

# 392. Anti-Pattern 15 — Desktop Shrink

Scaling a desktop composition down without task-based recomposition is not responsive design.

---

# 393. Anti-Pattern 16 — Dark-Mode Inversion

Automatically inverting colors without semantic surface, elevation, asset, contrast, and status review does not create a valid dark theme.

---

# 394. Anti-Pattern 17 — Whole-Screen RTL Mirroring

Mirroring everything breaks semantic, physical, chronological, brand, chart, and mixed-direction meaning.

---

# 395. Anti-Pattern 18 — Accessibility Annotation Dump

Adding generic accessibility notes after visual approval does not repair inaccessible structure, contrast, order, states, or content.

---

# 396. Anti-Pattern 19 — Contrast by Assumption

Using familiar colors or a brand palette without testing final combinations and states is not evidence.

---

# 397. Anti-Pattern 20 — Prototype Theatre

A polished clickable demo can conceal missing states, fake data, unsupported behavior, and absent engineering constraints.

---

# 398. Anti-Pattern 21 — Motion as Delay

Animation that slows access to information or action without orientation or feedback benefit harms usability.

---

# 399. Anti-Pattern 22 — High Fidelity Hides Logic Gaps

Visual polish must not be used to avoid unresolved product, requirement, state, or data decisions.

---

# 400. Anti-Pattern 23 — Silent Design-Code Divergence

Implementation changes that are not reconciled with the design baseline create two conflicting products.

---

# 401. Anti-Pattern 24 — Invisible Deprecation

Replacing a component without identifying consumers, migration status, and retirement conditions leaves hidden design debt.

---

# 402. Anti-Pattern 25 — Architecture by Mockup

Product Design may expose needs and constraints, but it must not encode unapproved architecture, data availability, or technical guarantees as visual fact.

---

# 403. Anti-Pattern 26 — Framework Vocabulary Leakage

Design names should express product and semantic meaning rather than being controlled by the current UI framework or code library.

---

# 404. Anti-Pattern 27 — Device-Name Breakpoints

Selecting breakpoints only because they match named devices ignores content, zoom, window resizing, and future form factors.

---

# 405. Anti-Pattern 28 — Error Toast Everywhere

Transient notifications are not a universal replacement for contextual error, recovery, status, and unknown-outcome design.

---

# 406. Anti-Pattern 29 — Disabled Without Explanation

A disabled action with no reason or route to resolution creates ambiguity and may hide permission or validation rules.

---

# 407. Anti-Pattern 30 — Compliance by Checklist Alone

A completed checklist without applied design controls, evidence, and representative validation does not demonstrate compliance.

---

# 408. Product Design Quality Model

Evaluate Phase 06 across:

```text
Correctness
Completeness
Coherence
Clarity
Consistency
Accessibility
Responsiveness
Localization readiness
Reuse
Traceability
Testability
Implementation readiness
Governance
Evidence quality
```

---

# 409. Core Quality Metrics

Recommended measures:

```text
Design subject coverage
Critical state coverage
Component adoption coverage
Semantic token coverage
Accessibility evidence coverage
Responsive mode coverage
Localization / RTL coverage
Traceability coverage
Validation finding closure
Design-to-code mapping coverage
Open condition age
Design-code parity after implementation
```

Metrics support judgment; they do not replace gate accountability.

---

# 410. Design Subject Coverage

```text
Design Subject Coverage =
Baselined in-scope design subjects with valid design status
÷
Total in-scope design subjects
```

Report `BLOCKED`, `DEFERRED_WITH_APPROVAL`, and `NOT_APPLICABLE` separately.

---

# 411. Critical State Coverage

```text
Critical State Coverage =
Critical required states with a valid design reference and content behavior
÷
Total critical required states
```

Never hide missing critical states inside an average across low-risk screens.

---

# 412. Component Adoption Coverage

```text
Component Adoption Coverage =
Approved reusable needs implemented through adopted canonical components
÷
Total approved reusable component needs
```

Report source publication and product adoption independently.

---

# 413. Semantic Token Coverage

```text
Semantic Token Coverage =
Baselined component properties using approved semantic tokens
÷
Total token-eligible baselined component properties
```

---

# 414. Accessibility Evidence Coverage

```text
Accessibility Evidence Coverage =
Applicable design accessibility obligations with accepted evidence
÷
Total applicable design accessibility obligations
```

The denominator comes from `GOV-009`, requirements, and surface applicability—not from available evidence.

---

# 415. Localization and RTL Coverage

```text
Localization / RTL Coverage =
Applicable critical design subjects validated in required locale / direction modes
÷
Total applicable critical design subjects and modes
```

---

# 416. Traceability Coverage

```text
Traceability Coverage =
Baselined design objects with valid upstream and downstream links
÷
Total baselined design objects requiring traceability
```

---

# 417. Validation Finding Closure

```text
Finding Closure =
Validation findings resolved or formally accepted
÷
Total validation findings due before G4B
```

High-severity findings must also be reported separately.

---

# 418. Design-to-Code Mapping Coverage

```text
Design-to-Code Mapping Coverage =
Implementation-relevant design objects with valid code targets or owned mapping actions
÷
Total implementation-relevant baselined design objects
```

---

# 419. Machine-Readable Phase 06 Record

Recommended structure:

```yaml
phase:
  id: PHASE-06
  name: Product Design
  status: BASELINED
  profile: P2
  product_stage: S3

upstream:
  requirements_baseline: RBL-2026-001
  experience_baseline: EBL-2026-001
  gov_009_revision: GOV-009@1.3

scope:
  platforms: [web, ios, android]
  locales: [en, ar]
  directions: [ltr, rtl]
  themes: [light, dark]
  domain_overrides:
    accessibility: P3

artifacts:
  DES-001: APPROVED
  DES-002: APPROVED
  DES-003: APPROVED
  DES-004: APPROVED
  DES-005: APPROVED
  DES-006: APPROVED
  DES-007: APPROVED
  DES-008: APPROVED
  DES-009: APPROVED
  DES-010: APPROVED
  DES-011: APPROVED
  DES-012: APPROVED
  DES-013: APPROVED
  DES-014: APPROVED
  DES-015: APPROVED
  DES-016: APPROVED
  DES-017: APPROVED
  DES-018: NOT_APPLICABLE
  DES-019: APPROVED
  DES-020: APPROVED
  DES-021: APPROVED
  DES-022: APPROVED
  DES-023: APPROVED

coverage:
  design_subjects: 1.0
  critical_states: 1.0
  component_adoption: 0.94
  semantic_tokens: 0.98
  accessibility_evidence: 1.0
  localization_rtl: 1.0
  traceability: 1.0
  design_to_code: 0.97

gate:
  id: G4B
  outcome: PASS_WITH_CONDITIONS
  evidence_record: G4B-EVR-001
```

---

# 420. Machine-Readable Design Object

Example:

```yaml
design_subject:
  id: DSCR-ACCOUNT-DETAIL
  title: Account Detail
  status: BASELINED
  source:
    source_id: DSRC-PRODUCT-001
    node_or_object: "Account Detail / Default"
    revision: "42"
  upstream:
    requirements: [FR-ACC-014, ACC-ACC-003]
    journey: JRN-ACC-002
    flow: FLOW-ACC-DETAIL
    states: [XST-DEFAULT, XST-LOADING, XST-ERROR, XST-DENIED]
  components:
    - CMP-PAGE-HEADER
    - CMP-STATUS-BADGE
    - CMP-DATA-LIST
  modes:
    responsive: [compact, regular, wide]
    direction: [ltr, rtl]
    theme: [light, dark]
  evidence:
    accessibility: DVAL-A11Y-018
    usability: DVAL-USAB-007
  downstream:
    route: /accounts/:accountId
    engineering_epic: ENG-ACC-020
    verification: [VFY-DES-044, VFY-A11Y-011]
```

---

# 421. `NOT_APPLICABLE` Contract

For any Phase 06 module, artifact, object, state, platform, standard, or evidence type marked `NOT_APPLICABLE`, record:

```text
Item ID
Scope
Reason
Decision owner
Evidence supporting non-applicability
Date / revision
Reopen condition
Downstream implication
```

Absence without this record means `MISSING`, not `NOT_APPLICABLE`.

---

# 422. Minimum Phase 06 Package by Profile

| Obligation | P1 Lean | P2 Standard | P3 Comprehensive |
|---|---|---|---|
| Design direction | Concise | Full | Multi-context / formally reviewed |
| Foundations and tokens | Minimum semantic set | Full applicable system | Governed multi-product / multi-mode system |
| Components and patterns | Critical scope | Full scope | Full scope plus conformance and migration |
| Screens and states | Critical complete | In-scope complete | In-scope complete with formal evidence |
| Responsive / platform | Supported critical modes | Full applicable modes | Multi-platform conformance |
| Accessibility | All applicable critical controls | Full applicable controls and evidence | Independent / formal assurance as needed |
| Localization / RTL | If applicable, critical coverage | Full applicable coverage | Multi-locale assurance and stress testing |
| Prototype | Critical journey | Representative complete flows | Multi-role / multi-mode validation |
| Traceability | Compact but complete | Full matrix | Tool-supported or formal matrix |
| Design-to-code | Direct mapping | Full handoff | Governed mapping, migration, and parity |
| G4B | Required | Required | Required with formal evidence depth |

---

# 423. Phase 06 Completion Contract

Phase 06 is complete only when:

```text
Entry baselines and scope are valid
Applicable DES artifacts are complete
Design sources and versions are canonical
Screens and states are covered
Tokens, components, and patterns are coherent
Accessibility and standards are realized with evidence
Responsive, platform, localization, and RTL needs are covered
Content, motion, and generated outputs are addressed
Validation findings are resolved or accepted
Traceability is complete
Design-to-code handoff is acknowledged
GOV-009 is updated
G4B has an accountable human decision
```

---

# 424. Phase 06 Exit Criteria

Required exit evidence:

```text
G4B outcome
Design Baseline ID and revision
Canonical source index
Artifact status matrix
Coverage report
Validation record
Open conditions and residual risks
Phase 07 obligations
Phase 08 handoff acknowledgement
Change-control owner
```

---

# 425. Transformation Achieved

At successful completion, Product OS has transformed:

```text
Approved experience architecture
```

into:

```text
A coherent design system and product design baseline
that expresses every applicable screen, state, component,
content responsibility, responsive mode, accessibility control,
localization rule, motion behavior, and implementation contract
with traceable sources and evidence.
```

---

# 426. Final Principle

> **Product Design is complete when the team can implement and verify the approved experience without guessing what it should look like, how it should behave, what happens in every material state, or which design source has authority.**

And:

> **G4B approves a design system in use and a product design baseline with evidence—not a collection of polished frames.**

---

# 427. Phase 06 Output

Primary output:

```text
DBL — Design Baseline
```

Gate:

```text
G4B — Design Baseline
```

Downstream consumers:

```text
Phase 07 — Solution Architecture
Phase 08 — Engineering Readiness
Phase 09 — Implementation
Phase 10 — Verification and Release
Product Operations and Design System Governance
```
