# Product OS v1.0 — Methodology Specification
## Phase 03: Product Definition

**Phase ID:** `PHASE-03`  
**Phase Name:** `Product Definition`  
**Version:** `1.1`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G3A — Product Baseline`  
**Primary Baseline:** `PBL — Product Baseline`  
**Primary Outcome:** تحويل الـapproved business baseline والـapplicable standards-derived business obligations إلى تعريف واضح ومحدود للمنتج يحدد ما هو المنتج، لمن، لماذا، ما القدرات التي يجب أن يوفرها، ما حدوده، ما وحداته المنطقية، وما الذي يدخل في كل Release قبل الانتقال إلى formal Requirements Engineering.

**v1.1 Closure Scope:** إضافة mandatory Standards Applicability Review وربط `GOV-009` بالـProduct Baseline وG3A وPhase 04 requirement-derivation handoff.

---

# 1. Purpose

الغرض من Phase 03 هو الانتقال من:

```text
BUSINESS MUST BE ABLE TO DO X
```

إلى:

```text
THE PRODUCT WILL ENABLE Y
FOR Z USERS
WITHIN THESE BOUNDARIES
IN THESE RELEASES
```

Phase 02 عرّفت:

```text
Business Objectives
Business Capabilities
Processes
Roles
Rules
Controls
Business Information
Cross-Cutting Business Requirements
Standards Applicability Decisions
```

Phase 03 تحدد:

```text
Product Vision
Product Boundary
Product Users
Product Capabilities
Product Domains / Modules
Feature Candidates
Product States
Product Policies
Release Scope
MVP
Roadmap
Product Dependencies
Standards-Derived Product Capabilities / Constraints / Policies
Phase 04 Requirement-Derivation Obligations
```

لكنها لا تكتب الـSRS النهائي.

---

# 2. Position in Product OS

```text
PHASE 02
Business Architecture
      │
      ▼
     G2
      │
      ▼
PHASE 03
Product Definition
      │
      ▼
   G3A
      │
      ▼
PHASE 04
Requirements Engineering
      │
      ▼
   G3B
```

Phase 03 هي الحد الفاصل بين:

```text
WHAT THE BUSINESS NEEDS
```

و:

```text
WHAT THE PRODUCT IS RESPONSIBLE FOR
```

---

# 3. Core Product Definition Question

Phase 03 تدور حول:

> **What product should exist, what responsibilities should it own, for whom, and in what release boundaries, in order to support the approved business model?**

---

# 4. Product Definition Philosophy

## PD-01 — Product Is Not the Business

المنتج لا يجب أن يمثل كل شيء موجود في المؤسسة.

بعض الأشياء تبقى:

```text
Manual
Policy
External
Human Judgment
Other System
Out of Scope
```

---

## PD-02 — Product Boundary Is Explicit

كل Product يجب أن يحدد:

```text
WHAT IT OWNS
WHAT IT SUPPORTS
WHAT IT INTEGRATES WITH
WHAT IT DOES NOT OWN
```

---

## PD-03 — Business Capability ≠ Product Capability

Business Capability:

```text
Manage Customer Credit
```

Product Capability قد تكون:

```text
Evaluate Credit Status
Route Credit Exception
Record Credit Decision
```

المنتج يدعم Business Capability، لكنه لا يساويها دائمًا.

---

## PD-04 — Product Capability ≠ Feature

Product Capability:

```text
Manage Contract Lifecycle
```

Features قد تكون:

```text
Create Contract
Submit for Review
Approve Contract
Terminate Contract
View History
```

---

## PD-05 — Feature ≠ Screen

Feature:

```text
Approve Contract
```

قد تحتاج:

```text
Inbox
Contract Details
Approval Modal
Notification
Audit Trail
API
```

---

## PD-06 — Requirement Comes Later

Phase 03 يمكن أن تنتج:

```text
FEATURE CANDIDATE
PRODUCT POLICY
PRODUCT CONSTRAINT
PRODUCT DECISION
```

لكن formal:

```text
FR
NFR
DR
INT
SEC
ACC
```

تثبت في Phase 04.

---

## PD-07 — MVP Is a Learning / Value Boundary

MVP ليس:

```text
Everything but smaller.
```

ولا:

```text
All requested features minus reports.
```

MVP يجب أن يحقق:

```text
Coherent Value
Testable Assumption
Operational Usability
Acceptable Risk
```

---

## PD-08 — Release Scope Must Preserve Business Integrity

لا يجوز تقطيع Release بطريقة تكسر business rule أو control.

مثال:

```text
Release contract creation
```

بدون:

```text
required approval / audit control
```

إذا كان business لا يسمح بذلك.

---

## PD-09 — Product Modules Are Logical Boundaries

Module ليس menu section فقط.

Module يمثل coherent product responsibility.

---

## PD-10 — Product Definition Must Remain Implementation-Neutral

لا نحدد:

```text
NestJS
PostgreSQL
React
AWS
```

إلا إذا كان constraint معتمدًا مسبقًا ويؤثر على product boundary.

---

## PD-11 — Standards Applicability Must Become Product Responsibility

Phase 03 لا تعيد تفسير الـstandard ولا تكتب SRS requirements.

هي تقرر كيف يؤثر كل applicable standard/profile وbusiness obligation على:

```text
Product Scope
Product Boundary
Product Capability
Product Constraint
Product Policy
Supported Platform / Channel
Country / Market Variation
Critical Journey
Generated Document
Third-Party Dependency
Enterprise Capability
Release Boundary
Phase 04 Requirement Derivation
```

لا يجوز تمرير G3A إذا كانت responsibility أو product implication اللازمة غير محددة، أو إذا تم تأجيل mandatory standard بصمت إلى Design أو Engineering أو QA.

---

# 5. Phase Objectives

بنهاية Phase 03 يجب أن يكون Product OS قادرًا على:

1. تعريف Product Vision.
2. تحديد Product Mission.
3. تحديد target users.
4. تحديد product-level roles.
5. تحديد product boundary.
6. تحديد in-scope / out-of-scope.
7. تحديد product responsibilities.
8. تحديد external responsibilities.
9. mapping Business Capabilities إلى Product Capabilities.
10. تحديد Product Domains.
11. تحديد Modules.
12. تحديد Feature Candidates.
13. تحديد Product States/Lifecycles.
14. تحديد product-level policies.
15. تحديد product-level constraints.
16. تحديد cross-module dependencies.
17. تحديد product integrations contextually.
18. تحديد MVP.
19. تحديد release slices.
20. تحديد prioritization rationale.
21. تحديد roadmap.
22. تحديد product success measures.
23. تحديد product assumptions.
24. تحديد product risks.
25. تحديد unresolved product decisions.
26. مراجعة `GOV-009` والـapplicable universal standards والـactivated/pending conditional profiles.
27. تحويل الـstandards-derived business obligations إلى product capabilities/constraints/policies/platform and journey implications.
28. تحديد Phase 04 requirement-derivation obligations حسب النوع.
29. تحديث `GOV-009` بالـProduct Definition linkage والـreopen conditions.
30. تجهيز Requirements Engineering handoff.
31. تمرير G3A.

---

# 6. Phase Inputs

Required logical inputs:

```text
BUS-001 BRD
BUS-002 Business Capability Map
BUS-003 Value Stream Map
BUS-004 Target Operating Model
BUS-005 Business Process Catalog
BUS-006 Business Rules Catalog
BUS-007 Business Decision Catalog
BUS-008 Roles & Responsibilities
BUS-009 Business Control Register
BUS-010 Business Information Model
BUS-011 KPI Model
G2 Decision
Risk Register
Assumption Register
Open Question Register
Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated / Pending Conditional Profiles
Standards-Derived BREQ / BR / CTRL / POL / INFO / EVID Objects
G2-18 Standards & Compliance Business Linkage Result
```

---

# 7. Entry Condition

Phase 03 تبدأ عندما:

```text
G2 = PASS
```

أو:

```text
G2 = PASS_WITH_CONDITIONS
```

والـconditions لا تمنع تحديد المنتج.

---

# 8. What Phase 03 Is Not

Phase 03 ليست:

- SRS.
- Detailed user stories.
- Acceptance criteria specification.
- API design.
- Database design.
- UI design.
- Wireframing.
- High-fidelity Figma.
- Detailed architecture.
- Sprint backlog.
- Engineering task breakdown.
- Test-case design.

---

# 9. Product Definition Object Model

Canonical objects:

```text
Product Vision
Product Mission
Product Objective
Product Boundary
Product User
Product Role
Product Capability
Product Domain
Product Module
Feature Candidate
Product Policy
Product State
Product Lifecycle
Product Dependency
Product Integration
Product Constraint
Product Assumption
Release
MVP
Roadmap Item
Product KPI
Product Decision
```

---

# 10. Product Vision

Product Vision يجيب:

> What future state does this product make possible?

Example:

```text
Provide a trusted operational platform that unifies property,
contract, payment, and maintenance operations across agencies.
```

---

# 11. Product Mission

Mission أكثر تنفيذية.

Example:

```text
Enable authorized teams to manage property lifecycle operations
through controlled, traceable, role-aware workflows.
```

---

# 12. Vision vs Mission

```text
Vision:
Future value/state.
```

```text
Mission:
What the product exists to do.
```

---

# 13. Product Objective

Product Objectives هي outcomes على مستوى المنتج.

IDs:

```text
POBJ-001
```

Example:

```text
POBJ-004:
Enable managers to make operational decisions using current,
trusted inventory information.
```

---

# 14. Product Objective Traceability

كل Product Objective يجب أن يرتبط بـ:

```text
OBJ
OUT
or
CAP
```

من Business Architecture.

---

# 15. Product Boundary

Product Boundary يحدد:

```text
Product Responsibility
External Responsibility
Human Responsibility
Other-System Responsibility
Policy Responsibility
```

---

# 16. Boundary Example

```text
Product owns:
- Contract workflow
- Approval routing
- Contract state
- Audit trail

External accounting system owns:
- General ledger posting

Human/legal function owns:
- Legal interpretation
```

---

# 17. Boundary Types

```text
OWNED
SUPPORTED
INTEGRATED
OBSERVED
MANUAL
EXTERNAL
OUT_OF_SCOPE
```

---

# 18. Boundary Rule

أي capability أو process يجب أن يعرف:

> Does the product own this, support it, integrate with it, or leave it external?

---

# 19. Product Scope

Product Scope يحدد what the product includes.

Structure:

```text
IN_SCOPE
OUT_OF_SCOPE
FUTURE_SCOPE
CONDITIONAL_SCOPE
DEPENDENT_SCOPE
```

---

# 20. Business Scope vs Product Scope

Business Scope:

```text
What business area is being transformed?
```

Product Scope:

```text
Which parts will this product actually handle?
```

---

# 21. Scope Justification

كل major Product Scope item يجب أن يرتبط بـ:

```text
Business Capability
Product Objective
Problem
Outcome
Policy / Regulation
```

---

# 22. Product User

Product User هو actor يتفاعل مباشرة أو indirectly مع المنتج.

IDs:

```text
USR-001
```

---

# 23. User Types

```text
PRIMARY
SECONDARY
ADMINISTRATIVE
APPROVER
OPERATOR
EXTERNAL
READ_ONLY
SERVICE_ACCOUNT
SYSTEM_ACTOR
```

---

# 24. Product User vs Stakeholder

Stakeholder قد لا يستخدم المنتج.

Example:

```text
Board Member = stakeholder + user
Regulator = stakeholder but maybe not user
Customer = user or external actor
CFO = stakeholder, approver, maybe occasional user
```

---

# 25. Product User Record

```yaml
user_id: USR-008

name: "Warehouse Supervisor"

business_roles:
  - ROLE-014

product_context:
  - OPERATE
  - APPROVE

goals:
  - "Maintain accurate stock movement"
```

---

# 26. Product Role

Product Role يصف responsibility داخل المنتج.

IDs:

```text
PROLE-001
```

---

# 27. Business Role vs Product Role

Business Role:

```text
Finance Manager
```

Product Role قد تكون:

```text
Credit Approver
```

شخص واحد قد يحمل الاثنين.

---

# 28. Product Role ≠ Permission

Product Role لا يزال conceptual.

Permission matrix تأتي في Requirements / Security.

---

# 29. Product Capability

Definition:

> A coherent ability the product must provide to support one or more approved business capabilities or product objectives.

IDs:

```text
PCAP-001
```

---

# 30. Product Capability Example

Business:

```text
CAP-120 Manage Customer Credit
```

Product:

```text
PCAP-021 Evaluate Credit Exposure
PCAP-022 Route Credit Exceptions
PCAP-023 Record Credit Decisions
```

---

# 31. Product Capability Contract

```text
Purpose
Business Capability Link
Product Users
Inputs
Outputs
Policies
Dependencies
Release Priority
```

---

# 32. Product Capability Record

```yaml
product_capability_id: PCAP-022

name: "Route Credit Exception"

supports:
  - CAP-120

users:
  - USR-004
  - USR-009

depends_on:
  - PCAP-021

priority:
  HIGH
```

---

# 33. Capability Coverage

كل Critical Business Capability يجب أن يكون:

```text
SUPPORTED_BY_PRODUCT
EXTERNAL
MANUAL
NOT_IN_SCOPE
```

ولا يبقى undefined.

---

# 34. Capability Gap

Business Capability بدون responsible product/external route:

```text
PRODUCT_RESPONSIBILITY_GAP
```

---

# 35. Product Domain

Product Domain هو coherent area of product responsibility.

IDs:

```text
PDOM-001
```

Examples:

```text
Identity
Contracts
Inventory
Payroll
Payments
Governance
Maintenance
```

---

# 36. Business Domain vs Product Domain

قد يتطابقان.

وقد لا يتطابقان.

Example:

```text
Business Domain:
Sales
Finance
Operations
```

Product Domain:

```text
Order Management
Customer Account
Settlement
```

---

# 37. Domain Boundary

Product Domain يجب أن يوضح:

```text
Owned Capabilities
Owned Product Information
Dependencies
Users
External Interfaces
```

---

# 38. Product Module

Module يمثل deliverable logical unit داخل المنتج.

IDs:

```text
MOD-001
```

---

# 39. Module Contract

```text
Name
Purpose
Product Domain
Capabilities
Users
Dependencies
Release
```

---

# 40. Module Example

```yaml
module_id: MOD-004

name: "Contract Management"

domain:
  PDOM-CONTRACTS

capabilities:
  - PCAP-031
  - PCAP-032
  - PCAP-033
```

---

# 41. Module vs Menu

Module لا يتحدد بناءً على:

```text
Sidebar
Tabs
Navigation
```

UI يأتي لاحقًا.

---

# 42. Module Cohesion Rule

Module جيد يجب أن يحتوي responsibilities مترابطة.

إذا module اسمه:

```text
Miscellaneous
General
Others
```

غالبًا boundary ضعيفة.

---

# 43. Module Size Rule

Module ضخم يحتوي 70% من المنتج:

```text
Core Module
```

يحتاج مراجعة.

---

# 44. Feature Candidate

Definition:

> A potential user-visible or operational product behavior that may realize part of a Product Capability.

IDs:

```text
FEAT-001
```

---

# 45. Candidate Status

```text
IDENTIFIED
PROPOSED
VALIDATED
PRIORITIZED
DEFERRED
REJECTED
RELEASED
```

---

# 46. Feature Candidate Example

```yaml
feature_id: FEAT-041

name:
  "Approve Contract"

supports:
  - PCAP-032

users:
  - USR-009

status:
  PROPOSED
```

---

# 47. Feature Candidate Is Not Requirement

Feature:

```text
Approve Contract
```

Requirement later:

```text
FR-084:
The system shall allow authorized contract approvers to approve
a contract that is in PENDING_APPROVAL state.
```

---

# 48. Feature Source

كل feature candidate يجب أن يعرف مصدر rationale:

```text
PCAP
BR
PROC
OUT
OPP
REGULATION
```

---

# 49. Unsupported Feature

Feature لا ترتبط بأي approved rationale:

```text
UNJUSTIFIED_FEATURE
```

---

# 50. Feature Duplication

Features بأسماء مختلفة تؤدي نفس responsibility يجب detectها.

---

# 51. Feature vs Workflow

Feature may trigger or support workflow.

Workflow itself may cross multiple features/modules.

---

# 52. Product Policy

Product Policy هو product-level invariant أو rule about product behavior.

IDs:

```text
PPOL-001
```

---

# 53. Product Policy Example

```text
PPOL-012:
Historical approved ownership records must never be silently overwritten.
```

---

# 54. Business Rule vs Product Policy

Business Rule:

```text
Business logic.
```

Product Policy:

```text
Product-level behavioral invariant.
```

Product Policy may derive from one or more BRs.

---

# 55. Product Constraint

Product Constraint يحدد boundary يؤثر على product design.

IDs:

```text
PCON-001
```

Categories:

```text
MARKET
PLATFORM
LANGUAGE
REGULATORY
DATA
SECURITY
ACCESSIBILITY
DEPLOYMENT
INTEGRATION
COMMERCIAL
OPERATIONAL
```

---

# 56. Hard vs Soft Product Constraints

Use:

```text
HARD
SOFT
PREFERENCE
UNKNOWN
```

---

# 57. Product Assumption

IDs:

```text
PASM-001
```

Example:

```text
PASM-004:
Initial release assumes all agencies operate within one country.
```

---

# 58. Assumption Risk

Each material assumption:

```text
Impact if wrong
Validation plan
Owner
Target validation point
```

---

# 59. Product Decision

IDs:

```text
PDEC-001
```

Examples:

```text
Will the product support multiple legal entities in Release 1?
Will offline mode be included in MVP?
Is guest access required?
```

---

# 60. Product Decision Contract

```text
Question
Options
Decision Owner
Rationale
Affected Scope
Status
```

---

# 61. Product State

Product State is a meaningful condition of a product object or product process.

Do not confuse with Project State S0-S6.

IDs:

```text
PSTATE-001
```

---

# 62. Product Object Lifecycle

Example:

```text
Contract:
DRAFT
→ IN_REVIEW
→ PENDING_APPROVAL
→ ACTIVE
→ EXPIRED / TERMINATED
```

---

# 63. Business State vs Product State

Business lifecycle may require states.

Product defines representation and supported transitions.

---

# 64. State Transition

IDs optional:

```text
PTRANS-001
```

Each transition should know:

```text
From
To
Trigger
Allowed Role
Business Rule
Product Policy
```

---

# 65. Invalid Transition

Product Definition should identify clearly impossible transitions.

Example:

```text
TERMINATED → ACTIVE
```

unless specific business rule permits reactivation.

---

# 66. Product Lifecycle

At product level, lifecycle can also refer to:

```text
Create
Operate
Change
Suspend
Archive
Delete
Restore
```

for managed objects.

---

# 67. Data Retention Implication

Deletion/archival expectations are product decisions before technical storage design.

---

# 68. Product Information Object

Phase 03 may map Business Information to Product-managed information.

IDs:

```text
PINFO-001
```

---

# 69. Information Responsibility

For each important information concept:

```text
CREATE
READ
UPDATE
APPROVE
ARCHIVE
REFERENCE
SYNC
```

product responsibility must be known.

---

# 70. Product Information vs Database Entity

Still not database design.

---

# 71. Product Integration Context

Integration is identified conceptually.

IDs:

```text
PINT-001
```

---

# 72. Integration Context Record

```yaml
integration_id: PINT-004

external_system:
  "Payment Gateway"

purpose:
  "Collect tenant payment"

direction:
  BIDIRECTIONAL

criticality:
  HIGH
```

---

# 73. Integration ≠ API Contract

Detailed API contract comes later.

---

# 74. Integration Ownership

Must know:

```text
Product side owner
External owner
Business dependency
Failure impact
```

---

# 75. Product Dependency

IDs:

```text
PDEP-001
```

Can be:

```text
Capability
Module
External System
Data Source
Business Decision
Regulation
Release
```

---

# 76. Dependency Criticality

```text
BLOCKING
HIGH
MEDIUM
LOW
```

---

# 77. Dependency Graph

Example:

```text
PCAP-021 Credit Evaluation
      ↓
PCAP-022 Exception Routing
      ↓
PCAP-023 Approval Record
```

---

# 78. Product Value Proposition

For external/commercial products, Phase 03 may define:

```text
Target Customer
Problem
Value
Differentiation
Evidence
```

---

# 79. Internal Product Exception

Internal systems do not need marketing-style value proposition.

They still need:

```text
Operational Value Proposition
```

---

# 80. Target Segment

If relevant:

```text
SEG-001
```

Examples:

```text
SME
Enterprise
Government
Agency
Factory
Internal Department
```

---

# 81. Persona Boundary

Detailed UX personas belong mainly in Experience Architecture.

Phase 03 only needs product-relevant user groups and goals.

---

# 82. Product Workflow Candidate

Phase 03 can identify high-level product workflows:

```text
PWF-001
```

Example:

```text
Create Contract → Review → Approve → Activate
```

Detailed interaction flow comes later.

---

# 83. Product Workflow vs Business Process

Business Process may include manual and external steps.

Product Workflow contains product-supported path.

---

# 84. Workflow Boundary

Must know:

```text
Product starts here
Product ends here
External/manual handoff here
```

---

# 85. Feature Group

Feature Groups may organize related features.

IDs:

```text
FGRP-001
```

But they should not replace modules/capabilities.

---

# 86. Product Hierarchy

Recommended:

```text
Product
  ↓
Product Domain
  ↓
Module
  ↓
Product Capability
  ↓
Feature Candidate
```

Relationships may be many-to-many.

---

# 87. Hierarchy Flexibility

Not every feature belongs exclusively to one module.

Cross-cutting features may include:

```text
Search
Notifications
Audit
Documents
Identity
Reporting
```

---

# 88. Cross-Cutting Product Capability

IDs same `PCAP`.

Examples:

```text
Audit Activity
Manage Notifications
Search Product Data
Manage Documents
```

---

# 89. Cross-Cutting Governance

Cross-cutting capability needs explicit ownership to avoid duplication.

---

# 90. Product Definition Workflow

Canonical workflow:

```text
03.0 Confirm Product Intent
      ↓
03.1 Define Product Vision & Mission
      ↓
03.2 Define Product Objectives
      ↓
03.3 Define Product Boundary
      ↓
03.4 Define Product Users & Roles
      ↓
03.5 Map Business Capabilities to Product Responsibilities
      ↓
03.6 Define Product Domains
      ↓
03.7 Define Modules
      ↓
03.8 Define Product Capabilities
      ↓
03.9 Identify Feature Candidates
      ↓
03.10 Define Product States & Lifecycles
      ↓
03.11 Define Product Policies & Constraints
      ↓
03.12 Identify Integrations & Dependencies
      ↓
03.13 Define Prioritization Model
      ↓
03.14 Define MVP / Release Slices
      ↓
03.15 Build Roadmap
      ↓
03.16 Perform Standards Applicability Review
      ↓
03.17 Validate Product Coherence
      ↓
03.18 Evaluate G3A
      ↓
03.19 Generate Handoff
```

---

# 91. Step 03.0 — Confirm Product Intent

Before defining scope, confirm:

```text
Is this one product?
Multiple products?
Platform?
Internal system?
Suite?
Mobile companion?
Portal?
Shared service?
```

---

# 92. Product vs Platform

Product:

```text
Delivers coherent value to a defined user/problem space.
```

Platform:

```text
Provides reusable capabilities for multiple products/consumers.
```

Do not call everything platform.

---

# 93. Product Ecosystem

Some initiatives require:

```text
Admin Web
Customer App
Field App
Public Portal
Device Interface
```

These may be:

```text
Channels
Applications
Products
```

must be explicitly classified.

---

# 94. Application vs Product

One product may have multiple applications.

Example:

```text
Real Estate OS
  ├── Admin Web
  ├── Agent Mobile
  └── Tenant Portal
```

---

# 95. Step 03.1 — Vision & Mission

Vision and Mission must reflect approved business outcomes, not technology hype.

---

# 96. Bad Vision

```text
Build the most advanced AI-powered cloud-native platform.
```

No business meaning.

---

# 97. Better Vision

```text
Enable organizations to operate ownership and governance decisions
through a trusted, traceable, and controlled digital environment.
```

---

# 98. Step 03.2 — Product Objectives

Product objectives translate business outcomes into product responsibility.

---

# 99. Objective Coverage

Every critical business objective should be either:

```text
SUPPORTED_BY_PRODUCT
EXTERNAL
MANUAL
OUT_OF_SCOPE
```

---

# 100. Step 03.3 — Product Boundary

Create boundary map:

```text
Inside Product
Adjacent Systems
Human Decision
External Actor
Manual Process
```

---

# 101. Boundary Conflict

If two products both claim ownership of same master data/workflow:

```text
OWNERSHIP_CONFLICT
```

---

# 102. Step 03.4 — Users & Roles

Map:

```text
Business Role → Product Role → Product Goal
```

---

# 103. User Goal

Each primary user group should have clear goal.

Example:

```text
Warehouse Operator:
Record stock movement accurately with minimal duplicate entry.
```

---

# 104. User Need vs Feature

Need:

```text
Know whether stock is reserved.
```

Feature:

```text
Reservation status indicator.
```

---

# 105. Step 03.5 — Capability Responsibility Mapping

For each Business Capability:

```text
PRODUCT_OWNED
PRODUCT_SUPPORTED
EXTERNAL
MANUAL
NOT_IN_RELEASE
OUT_OF_SCOPE
```

---

# 106. Capability Responsibility Matrix

Example:

```text
Business Capability          Responsibility
Manage Customer Credit       Product Supported
Perform Legal Review         Human / External
Post GL Entries              Integrated External System
```

---

# 107. Step 03.6 — Product Domains

Product domains should be stable enough to structure product thinking.

---

# 108. Domain Naming

Prefer business/product responsibility names.

Avoid purely UI labels.

---

# 109. Domain Dependency

Cross-domain dependencies must be explicit.

---

# 110. Step 03.7 — Modules

Modules should be created only when they add structural value.

---

# 111. Module Justification

Each module should answer:

```text
Why is this a separate coherent product responsibility?
```

---

# 112. Module Dependency

Module dependencies should avoid circular ownership.

Circular data/control dependency signals weak boundaries.

---

# 113. Step 03.8 — Product Capabilities

Product capability should be meaningful regardless of exact UI.

---

# 114. Product Capability Completeness

Critical business capability should not rely on random scattered features with no parent product capability.

---

# 115. Step 03.9 — Feature Candidates

Feature discovery sources:

```text
Product Capability
Business Rule
Business Process
Product Policy
User Need
Opportunity
Integration
Control
```

---

# 116. Feature Candidate Minimal Contract

```text
Name
Purpose
Users
Parent Capability
Business Rationale
Dependencies
Priority Status
Release Candidate
```

---

# 117. Feature Candidate Granularity

Too large:

```text
Manage HR
```

Too small:

```text
Change button color
```

Good:

```text
Submit Leave Request
Approve Leave Request
Configure Leave Policy
```

---

# 118. CRUD Warning

Do not automatically create:

```text
Create
Read
Update
Delete
```

for every object.

Business lifecycle defines meaningful behaviors.

---

# 119. Delete Warning

Delete may not be legitimate for:

```text
Financial record
Audit record
Ownership record
Approved contract
```

Phase 03 should flag lifecycle expectation.

---

# 120. Reporting Features

Reports should derive from decision/user need.

Not:

```text
Add reports module.
```

---

# 121. Dashboard Features

Dashboard is not automatically a capability.

Ask:

```text
Who needs what decision visibility?
```

---

# 122. Search

Search may be cross-cutting capability if product scale requires it.

---

# 123. Notifications

Notification is often supporting behavior.

Define:

```text
Trigger
Recipient
Purpose
Criticality
```

at product level; detailed requirements later.

---

# 124. Document Handling

If product requires documents:

```text
Upload
Generate
Review
Approve
Version
Archive
Sign
```

must be product-scoped intentionally.

---

# 125. Auditability

Audit may be cross-cutting Product Capability for R3/R4.

---

# 126. Product State Modeling

Critical product objects should have lifecycle.

---

# 127. State Coverage

For each critical object:

```text
Initial State
Active States
Terminal States
Suspended States
Invalid States
```

---

# 128. State Ownership

Transition may be:

```text
User-triggered
System-triggered
Time-triggered
External-triggered
```

---

# 129. State vs Status Label

Do not create dozens of arbitrary statuses because UI needs colored badges.

States should represent meaningful domain conditions.

---

# 130. Step 03.11 — Product Policies

Product Policies include:

```text
Immutability
Auditability
Visibility
Deletion
Versioning
Ownership
Access posture
Default behavior
```

---

# 131. Product Policy Example

```text
PPOL-021:
Approved financial records remain historically accessible even after reversal.
```

---

# 132. Default Policy

Defaults should be explicit for high-risk behavior.

Example:

```text
Default access = denied
```

or whatever approved model later defines.

---

# 133. Step 03.12 — Integration Context

Identify which product capabilities depend on integrations.

---

# 134. Integration Dependency Failure

At product definition, ask:

```text
What product behavior is expected if external dependency is unavailable?
```

Detailed resilience requirement later.

---

# 135. Product Dependency Types

```text
INTERNAL_CAPABILITY
MODULE
EXTERNAL_SYSTEM
DATA
BUSINESS_DECISION
REGULATION
HARDWARE
SERVICE
RELEASE
```

---

# 136. Prioritization

Product OS requires explicit prioritization rationale.

Not stakeholder volume.

---

# 137. Prioritization Inputs

Possible factors:

```text
Business Value
User Value
Risk Reduction
Regulatory Need
Dependency
Learning Value
Revenue
Operational Impact
Cost
Complexity
Urgency
Strategic Fit
```

---

# 138. Prioritization Schemes

Allowed:

```text
MoSCoW
RICE
WSJF
Weighted Scoring
Custom
```

No single method mandatory.

---

# 139. Prioritization Consistency

One project/release should use consistent semantics.

---

# 140. Must-Have Rule

`MUST` should mean:

```text
Release cannot achieve intended coherent outcome without it
```

not:

```text
Stakeholder strongly likes it
```

---

# 141. Product Criticality

Feature can be critical because of:

```text
Business
Risk
Compliance
Dependency
Control
```

not only user frequency.

---

# 142. MVP Definition

MVP must define:

```text
Target User
Target Problem
Core Outcome
Minimum Capabilities
Critical Controls
Validation Goal
Excluded Scope
Success Signal
```

---

# 143. MVP Anti-Definition

MVP is not:

```text
Version with half the screens.
```

---

# 144. MVP Coherence

MVP must support one complete valuable workflow or use case end-to-end where practical.

---

# 145. MVP Safety Rule

MVP cannot remove required:

```text
Security
Compliance
Audit
Financial Control
Accessibility baseline
Data integrity
```

just to ship faster.

---

# 146. MVP Learning Hypothesis

For uncertain products:

```text
What must this release teach us?
```

should be explicit.

---

# 147. Release

IDs:

```text
REL-CAND-001
```

---

# 148. Release Scope

Release contains:

```text
Objectives
Capabilities
Features
Users
Dependencies
Constraints
Exit Criteria
```

---

# 149. Release Types

```text
MVP
PILOT
BETA
GA
INCREMENTAL
REGULATORY
MIGRATION
RECOVERY
```

---

# 150. Release Boundary

Release should not be defined only by calendar date.

It needs coherent scope.

---

# 151. Release Dependency

If Feature A requires B, release plan must reflect it.

---

# 152. Release Integrity

Avoid:

```text
Release 1:
Create records

Release 2:
Validate them
```

if validation is essential to business integrity.

---

# 153. Release Slice

A good slice may be:

```text
By user journey
By capability
By market
By customer segment
By geography
By risk
By workflow
```

---

# 154. Horizontal vs Vertical Slicing

Horizontal:

```text
All database work first.
```

Usually not product release.

Vertical:

```text
End-to-end usable capability.
```

Preferred for value delivery.

---

# 155. Pilot

Pilot release may intentionally limit:

```text
Users
Locations
Transactions
Features
```

but must keep controls appropriate.

---

# 156. Roadmap

Roadmap communicates product evolution.

Not engineering schedule.

---

# 157. Roadmap IDs

```text
RM-001
```

---

# 158. Roadmap Horizons

Example:

```text
NOW
NEXT
LATER
```

or:

```text
R1
R2
R3
```

---

# 159. Roadmap Content

Roadmap item should reflect:

```text
Outcome
Capability
Release
Dependency
Rationale
```

not dozens of engineering tasks.

---

# 160. Roadmap Uncertainty

Far-future roadmap should have lower commitment.

---

# 161. Roadmap Status

```text
COMMITTED
PLANNED
CANDIDATE
EXPLORATORY
DEFERRED
```

---

# 162. Product Success Model

Product Success should link:

```text
Business KPI
Product KPI
Adoption
Completion
Quality
Risk
```

---

# 163. Product KPI

IDs:

```text
PKPI-001
```

---

# 164. Product KPI Examples

```text
Active users
Task completion rate
Approval cycle time
Self-service adoption
Failed transaction rate
```

---

# 165. Vanity Metric Warning

Downloads/page views are not automatically meaningful.

---

# 166. Product KPI Traceability

Each KPI should support:

```text
POBJ
OUT
or
Capability
```

---

# 167. Product Constraint Review

Before G3A, revisit:

```text
Platform
Language
Accessibility
Market
Deployment
Regulatory
Security
Integration
```

---

# Mandatory Standards Applicability Review — Step 03.16

قبل Product Coherence validation وG3A، Phase 03 تراجع كل entry في `GOV-009`.

المراجعة تسأل:

```text
Which universal standards are applicable to this product?
Which conditional profiles are activated, not applicable, or pending?
Which standards-derived business obligations were handed off by Phase 02?
What product capability, constraint, policy, platform, channel, journey, document, third-party, enterprise, or release implication results?
Which requirement types must Phase 04 derive?
What product change would reopen the applicability decision?
```

## Product Implication Outcomes

كل applicable business obligation يجب أن يرتبط بواحد أو أكثر من:

```text
PCAP   Product Capability
PCON   Product Constraint
PPOL   Product Policy
PROD-002 Product Scope / Boundary
PROD-009 Product Policy & Constraint Register
PROD-010 Product Integration & Dependency Map
PROD-011 MVP & Release Scope
PLATFORM / CHANNEL COMMITMENT
CRITICAL JOURNEY IMPLICATION
GENERATED DOCUMENT IMPLICATION
THIRD-PARTY IMPLICATION
ENTERPRISE CAPABILITY IMPLICATION
```

إذا لم يوجد product impact، يجب تسجيل explicit rationale مع owner وapproval status. لا يسمح بـsilent omission.

## Phase 04 Derivation Contract

لكل applicable entry، Phase 03 تحدد types التي يجب على Phase 04 اشتقاقها:

```text
FR
NFR
DR
INT
SEC
ACC
AUD
```

Phase 03 لا تكتب المتطلبات التفصيلية؛ هي تمنع Requirements Engineering من اختراع product responsibility أو نسيان obligation.

## Blocking Rule

```text
Blocking GOV-009 applicability decisions = 0 before G3A PASS
Blocking standards-derived product responsibility gaps = 0 before G3A PASS
```

`PENDING` قد ينتج `PASS_WITH_CONDITIONS` فقط إذا كان non-blocking، له owner وdue gate، ولا يهدد صحة Product Baseline أو Phase 04 derivation.

---

# 168. Accessibility Product Baseline

عندما تكون Digital Accessibility applicable، Product Definition يجب أن يسجلها من خلال `GOV-009`، وليس كجملة عامة فقط.

على الأقل يجب تحديد:

```text
Target baseline, including WCAG 2.2 AA where adopted
Supported platforms and relevant non-web guidance
Accessible authentication and account recovery
Keyboard-operable critical journeys
Assistive-technology-compatible information and actions
Colour, contrast, zoom, reflow, and input implications
RTL/LTR and language implications
Generated-document responsibilities
Third-party journey continuity
High-impact and sensitive action implications
Phase 04 ACC/NFR/SEC/DR/INT derivation flags
```

Detailed atomic requirements and acceptance criteria remain Phase 04 responsibility.

---

# 169. Localization

At product level define:

```text
Supported languages
RTL/LTR expectation
Market terminology
Country variation
```

if applicable.

---

# 170. Multi-Tenant Product Decision

If SaaS/multi-org:

```text
Single Tenant
Multi-Tenant
Hybrid
```

is major product decision before detailed architecture.

---

# 171. Multi-Entity Support

Distinguish:

```text
Tenant
Organization
Company
Branch
Legal Entity
Workspace
```

before requirements.

---

# 172. Country / Market Variation

Product must define whether behavior varies by:

```text
Country
Regulation
Currency
Language
Tax
Calendar
```

---

# 173. Platform Definition

At product level:

```text
Web
Mobile
Desktop
Public Portal
Kiosk
Device
API Product
```

must be defined where relevant.

---

# 174. Platform Responsibility

Same feature may not exist on every platform.

---

# 175. Channel Matrix

Example:

```text
Capability          Web   Mobile   Portal
Approve Contract    Yes   Yes      No
Configure Policy    Yes   No       No
View Status         Yes   Yes      Yes
```

This is product scope, not UI design.

---

# 176. Product Dependency Matrix

Recommended for P2/P3.

---

# 177. Cross-Module Rule

If multiple modules depend on same business rule, reference canonical BR ID.

Do not copy rule text.

---

# 178. Product Decision Log

Product-specific decisions stored in:

```text
PDEC
```

and linked to GOV decision log.

---

# 179. Product Assumption Register

Material product assumptions should not hide in roadmap notes.

---

# 180. Product Risk

Product-level risk examples:

```text
Adoption risk
Scope risk
Dependency risk
Product-market risk
Operational risk
Data risk
Regulatory risk
Migration risk
```

---

# 181. Product Risk vs Project Risk

Product Risk:

```text
Risk inherent to product outcome/behavior.
```

Project Risk:

```text
Risk to delivery execution.
```

Both matter.

---

# 182. Product Definition by Project State

Phase 03 varies by S0-S6.

---

# 183. S0 — Early Idea

Focus:

```text
Vision
Target User
Core Problem
Core Value
Product Boundary
Core Capability
MVP hypothesis
```

Avoid over-modularization.

---

# 184. S1 — New Product

Full product definition normally applies.

---

# 185. S2 — Business Transformation

Focus strongly on mapping business capability to system/product responsibility.

---

# 186. S3 — Existing Product

Focus:

```text
Current Product Baseline
Capability Gaps
Scope Delta
Module Gaps
Feature Delta
Target Product Model
```

---

# 187. S4 — Implementation in Progress

Focus:

```text
Reconstruct intended product
Compare planned vs built
Identify scope drift
Define authoritative target baseline
```

---

# 188. S5 — Recovery

Focus:

```text
Critical Product Responsibilities
Minimum Safe Product
Broken Scope
Missing Controls
Recovery Releases
```

---

# 189. S6 — Evolution

Only affected product areas are redefined.

Use delta model.

---

# 190. Delta Product Definition

For existing product:

```text
CURRENT
CHANGE
TARGET
```

for:

```text
Capabilities
Features
States
Policies
Integrations
Releases
```

---

# 191. Product Definition Artifacts

## PROD-001 — Product Vision & Mission

---

# 192. PROD-002 — Product Scope & Boundary

Includes:

```text
In / Out / Future / External / Manual
```

---

# 193. PROD-003 — Product Objective Model

---

# 194. PROD-004 — Product User & Role Model

---

# 195. PROD-005 — Product Capability Map

---

# 196. PROD-006 — Product Domain & Module Map

---

# 197. PROD-007 — Feature Candidate Catalog

---

# 198. PROD-008 — Product State & Lifecycle Model

---

# 199. PROD-009 — Product Policy & Constraint Register

---

# 200. PROD-010 — Product Integration & Dependency Map

---

# 201. PROD-011 — MVP & Release Scope

---

# 202. PROD-012 — Product Roadmap

---

# 203. PROD-013 — Product KPI Model

---

# 204. PROD-014 — Product Definition Validation Record

---

## Standards Integration Across Product Artifacts

Phase 03 لا ينشئ نسخة ثانية من `GOV-009`.

Product implications are owned by the relevant canonical product artifacts and referenced from `GOV-009`:

```text
Product scope / boundary        → PROD-002
Product capabilities            → PROD-005
Product domains / modules       → PROD-006
Feature candidates              → PROD-007
Product policies / constraints  → PROD-009
Integrations / dependencies     → PROD-010
MVP / release implications      → PROD-011
Standards applicability lineage → GOV-009
```

---

# 205. Governance Registers Updated

Phase 03 updates:

```text
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-007 Change Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
```

Phase 03 adds to `GOV-009`:

```text
Product Capability Links
Product Constraint Links
Product Policy Links
Product Scope / Boundary Links
Platform / Channel Commitments
Critical Journey Implications
Generated Document Implications
Third-Party Implications
Enterprise Capability Implications
Release Implications
Phase 04 Requirement-Derivation Types
Product-Level Reopen Conditions
```

---

# 206. P1 — Lean Behavior

P1 may combine into:

```text
PRODUCT DEFINITION PACK
```

containing:

```text
Vision
Scope
Users
Core Capabilities
Modules
Feature Candidates
MVP
Roadmap
Applicable Standards / Profiles
Standards-Derived Product Implications
Phase 04 Derivation Obligations
```

P1 may combine artifacts، لكنه لا يسقط applicable constitutional/universal obligations أو الـowner/rationale/reopen/derivation linkage المطلوبة.

---

# 207. P2 — Standard Behavior

Independent recommended artifacts:

```text
PROD-001
PROD-002
PROD-004
PROD-005
PROD-006
PROD-007
PROD-011
PROD-012
GOV-009 product linkage
```

Others as applicable.

P2 requires explicit canonical links between `GOV-009`, business obligations, product artifacts, and Phase 04 derivation types.

---

# 208. P3 — Comprehensive Behavior

Adds:

```text
Full boundary model
Full capability mapping
Cross-product/channel model
Formal product policies
State/lifecycle models
Release governance
Dependency graph
Formal product validation
Independent approval
Full traceability
Versioned product baseline
Clause-level or obligation-level standards mapping where risk requires
Independent applicability/product-implication approvals
Formal evidence for product-level exclusions and exceptions
```

---

# 209. Product Definition Validation

Before G3A, review with:

```text
Business Owner
Product Owner
Product Analyst
Domain Owner
Solution Architect
UX Lead
Security/Compliance if relevant
```

---

# 210. Validation Subjects

```text
Vision
Objectives
Scope
Boundary
Users
Capabilities
Modules
Feature candidates
Policies
States
Dependencies
MVP
Roadmap
Applicable Standards / Profiles
Standards-Derived Product Capabilities / Constraints / Policies
Platforms / Channels / Journeys / Documents / Third Parties
Phase 04 Requirement-Derivation Obligations
```

---

# 211. Validation Rule

Architecture/UX may challenge product definition.

They must not silently rewrite it.

---

# 212. Product Coherence Check

Ask:

```text
Does every module serve the product mission?
Does every feature support a capability?
Does every capability support a product/business objective?
Does the MVP produce complete value?
```

---

# 213. G3A — Product Baseline Gate

Purpose:

> Determine whether the product is defined sufficiently for Requirements Engineering, UX Architecture, and Solution Architecture to proceed without inventing product scope or responsibilities.

---

# 214. G3A-01 Vision

Product purpose is explicit.

---

# 215. G3A-02 Product Boundary

Ownership vs external/manual responsibility is clear.

---

# 216. G3A-03 Product Scope

In/out/future boundaries explicit.

---

# 217. G3A-04 User Model

Primary product users and roles known.

---

# 218. G3A-05 Capability Coverage

Critical business capabilities have product responsibility disposition.

---

# 219. G3A-06 Product Domains

Major product responsibility areas identified.

---

# 220. G3A-07 Module Coherence

Modules are coherent and not arbitrary UI buckets.

---

# 221. G3A-08 Feature Candidate Coverage

Enough feature candidates exist to explain how capabilities may be realized.

Not final requirements.

---

# 222. G3A-09 Product States

Critical object/workflow states modeled where material.

---

# 223. G3A-10 Product Policies

Critical product invariants known.

---

# 224. G3A-11 Integrations

Major external interactions identified.

---

# 225. G3A-12 Dependencies

Blocking product dependencies known.

---

# 226. G3A-13 MVP / Release Boundary

Initial delivery slice defined where applicable.

---

# 227. G3A-14 Roadmap Direction

Near-term sequencing is understood.

---

# 228. G3A-15 Risk Review

Product risk and classification reviewed.

---

# 229. G3A-16 Open Decisions

No blocking product decision remains unresolved.

---

# 230. G3A-17 Requirements Readiness

Requirements team can derive formal requirements without inventing product scope.

---

# 230A. G3A-18 Standards Applicability Review

G3A verifies:

```text
Applicable universal standards are reflected in the Product Baseline.
Conditional profiles have explicit APPLICABLE / NOT_APPLICABLE / governed PENDING decisions.
Standards-derived business obligations map to canonical product implications or an approved no-product-impact rationale.
Supported platforms, countries, languages, documents, third parties, and enterprise capabilities are consistent with GOV-009.
Phase 04 requirement-derivation types and source links are explicit.
Owners, approvals, evidence, and product-level reopen conditions are present.
No mandatory standard is silently deferred to UX, Design, Architecture, Engineering, QA, or Release.
Blocking GOV-009 decisions and product-responsibility gaps equal zero.
```

---

# 231. G3A Outcomes

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

---

# 232. PASS

Product baseline is coherent enough to proceed.

---

# 233. PASS_WITH_CONDITIONS

Example:

```text
R2 release scope confirmed; detailed reporting scope deferred to Phase 04.
```

if non-blocking.

---

# 234. HOLD

Examples:

```text
No agreement on whether payments are owned by product or external platform.
```

```text
MVP includes capabilities that depend on unresolved regulatory decision.
```

```text
Product boundaries conflict across stakeholders.
```

---

# 235. REJECT

Examples:

```text
Product concept abandoned.
Business decided on non-product solution.
Initiative split into separate products requiring new baselines.
```

---

# 236. G3A Evidence Record

```yaml
gate_id: G3A

outcome: PASS_WITH_CONDITIONS

checks:
  vision: PASS
  boundary: PASS
  scope: PASS
  users: PASS
  capabilities: PASS
  modules: PASS
  product_states: PASS
  integrations: PASS
  release_scope: PASS
  standards_applicability: PASS
  standards_product_linkage: PASS
  phase_04_derivation_readiness: PASS
  blocking_decisions: PASS

conditions:
  - "Detailed reporting feature set to be finalized during requirements engineering."

evidence:
  - PROD-001
  - PROD-002
  - PROD-004
  - PROD-005
  - PROD-006
  - PROD-011
  - PROD-009
  - GOV-009

approved_by:
  - PRODUCT_OWNER
  - BUSINESS_AUTHORITY
```

---

# 237. Phase Handoff Contract

Phase 03 handoff must provide:

```text
Product Vision
Product Mission
Product Objectives
Product Scope
Product Boundary
Users
Product Roles
Product Domains
Modules
Product Capabilities
Feature Candidates
Product States
Product Policies
Product Constraints
Integrations
Dependencies
MVP
Release Scope
Roadmap
Product KPIs
Risks
Assumptions
Open Questions
Applicable Universal Standards
Activated / Pending Conditional Profiles
Standards-Derived Business Obligations
Product Capability / Constraint / Policy Links
Platform / Channel / Journey / Document / Third-Party Implications
Phase 04 Requirement-Derivation Types and Source Links
GOV-009 Status
G3A Outcome
```

---

# 238. Machine-Readable Handoff — Conceptual

```yaml
phase_handoff:

  from_phase: PHASE-03

  product_baseline:
    status: APPROVED

  product:
    vision: PROD-001
    scope: PROD-002

  objectives:
    - POBJ-001

  users:
    - USR-001
    - USR-004

  domains:
    - PDOM-001
    - PDOM-002

  modules:
    - MOD-001
    - MOD-004

  capabilities:
    - PCAP-001
    - PCAP-008

  features:
    - FEAT-001
    - FEAT-006

  policies:
    - PPOL-001

  integrations:
    - PINT-001

  dependencies:
    - PDEP-003

  standards:
    applicability_matrix: GOV-009
    applicable_universal:
      - STD-A11Y
    conditional_profiles:
      applicable: []
      not_applicable:
        - PROFILE-HIPAA
      pending: []
    product_implications:
      capabilities:
        - PCAP-A11Y-001
      constraints:
        - PCON-A11Y-001
      policies: []
    requirements_derivation:
      required_types:
        - ACC
        - NFR
        - SEC
        - DR
        - INT
      source_entries:
        - GOV-009-ENTRY-A11Y

  releases:
    mvp:
      artifact: PROD-011

  roadmap:
    artifact: PROD-012

  open_questions:
    blocking: []
    downstream:
      - OQ-041

  gate:
    id: G3A
    outcome: PASS

  next_route:
    phase: PHASE-04
    mode: REQUIREMENTS_ENGINEERING
```

---

# 239. Traceability Graph

Canonical Phase 03 chain:

```text
PRB / OUT
    ↓
OBJ
    ↓
CAP
    ↓
POBJ
    ↓
PCAP
    ↓
PDOM / MOD
    ↓
FEAT
    ↓
RELEASE
```

Then:

```text
FEAT / PCAP / PPOL / PSTATE
          ↓
Requirements
```

Standards inheritance chain:

```text
STD / PROFILE
      ↓
GOV-009 Applicability Decision
      ↓
BREQ / BR / CTRL / POL / INFO / EVID
      ↓
PROD-002 / PCAP / PCON / PPOL / PINT / RELEASE
      ↓
FR / NFR / DR / INT / SEC / ACC / AUD
```

---

# 240. Mandatory Trace Relationships

Minimum:

```text
POBJ → OBJ/OUT
PCAP → CAP/POBJ
MOD → PCAP
FEAT → PCAP
PPOL → BR/CTRL/RISK where relevant
PSTATE → Business lifecycle/rule where relevant
RELEASE → PCAP/FEAT
PKPI → POBJ
STD/PROFILE → GOV-009 source and applicability decision
PCAP/PCON/PPOL/PROD/PINT/RELEASE → GOV-009 when standards-derived
Phase 04 derivation obligation → GOV-009 + canonical product implication
```

---

# 241. Orphan Feature

Feature without capability/rationale:

```text
ORPHAN_FEATURE
```

---

# 242. Orphan Module

Module without coherent capabilities:

```text
ORPHAN_MODULE
```

---

# 243. Orphan Product Capability

PCAP not linked to business/product objective:

```text
ORPHAN_PRODUCT_CAPABILITY
```

---

# 244. Scope Leakage

Feature outside Product Scope:

```text
SCOPE_LEAK
```

---

# 245. Product Definition Change Propagation

Example:

```text
PCAP-021 removed
      ↓
FEAT-041 / FEAT-042 review
      ↓
MOD-004 review
      ↓
MVP scope review
      ↓
FRs become REVIEW_REQUIRED
      ↓
UX / Architecture scope review
```

Standards change example:

```text
STD-A11Y baseline or applicability trigger changes
      ↓
GOV-009 becomes REVIEW_REQUIRED
      ↓
BREQ-A11Y and product implications reviewed
      ↓
Product scope/capability/constraint/policy/release reviewed
      ↓
Phase 04 requirements become REVIEW_REQUIRED
      ↓
UX / Design / Architecture / Tests become REVIEW_REQUIRED
```

---

# 246. Product Baseline Versioning

Approved baseline:

```text
PRODUCT-BASELINE-1.0
```

Changes after G3A require:

```text
Change Record
Impact Analysis
Version Update
Reapproval where material
```

---

# 247. Reopening Phase 03

Triggers:

```text
Business capability change
Product ownership change
New market
New major user type
Major regulation
Organization standard change
Standards applicability trigger change
Conditional profile activation/deactivation
Platform change
MVP change
Product split/merge
Critical integration change
Business model change
Generated-document responsibility change
User-facing third-party change
Enterprise customer obligation change
```

---

# 248. Reopen States

```text
PRODUCT_REVIEW_REQUIRED
PARTIAL_PRODUCT_REBASELINE
FULL_PRODUCT_REBASELINE
```

---

# 249. AI Responsibilities

AI MAY:

- map business capabilities to product capabilities;
- propose product boundaries;
- detect scope overlap;
- identify feature candidates;
- group coherent modules;
- detect orphan features;
- identify state models;
- propose release slices;
- compare MVP to objectives;
- detect missing dependency;
- build traceability;
- draft product roadmap;
- identify product-policy candidates;
- detect cross-module duplication.
- analyze `GOV-009` entries and Phase 02 standards-derived business obligations;
- propose product capabilities, constraints, policies, platform/channel commitments, and downstream implications;
- propose Phase 04 requirement-derivation types;
- detect applicable standards without canonical product linkage;
- detect product scope, release, platform, document, or third-party decisions that contradict applicability evidence;
- propose product-level reopen conditions and impact relationships.

---

# 250. AI Must Label

AI-generated product definitions:

```text
PROPOSED
INFERRED
SUPPORTED
VALIDATED
APPROVED
```

Only human-authorized decisions become `APPROVED`.

---

# 251. AI Prohibitions

AI MUST NOT:

- invent product scope;
- invent target market;
- convert every business capability into a module;
- convert every module into navigation;
- treat requested features as approved;
- define formal system requirements in Phase 03;
- invent MVP deadline;
- remove controls to reduce MVP scope;
- invent user roles;
- invent product policy;
- choose technical architecture;
- merge products silently;
- hide unresolved ownership conflict.
- declare a standard or conditional profile `NOT_APPLICABLE` without authorized rationale and evidence;
- approve a standards-derived product interpretation;
- weaken constitutional or universal obligations because of P1 Lean or MVP scope;
- treat a generic accessibility/security/compliance statement as sufficient product linkage;
- defer applicable product obligations silently to Phase 04, UX, Architecture, Engineering, or QA;
- invent legal or regulatory interpretation.

---

# 252. Human Responsibilities

Humans remain responsible for:

```text
Product Vision
Product Scope
Product Boundary
Prioritization
MVP
Release Commitment
Product Policy Approval
Product Ownership
Roadmap Commitment
Standards Applicability Approval
Product Interpretation of Cross-Cutting Obligations
Conditional Profile Activation / Exclusion Approval
Standards-Derived Product Exception Acceptance
```

---

# 253. Product Owner Responsibility

Confirms:

```text
Vision
Scope
Priority
Release
User value
Product decision
Standards-derived product responsibilities
Phase 04 derivation readiness
```

---

# 254. Business Authority Responsibility

Confirms:

```text
Alignment with business baseline
Business integrity
Business capability coverage
Business policy implications
Standards-derived business obligation continuity
```

---

# 255. Product Analyst Responsibility

Responsible for:

```text
Product model coherence
Capability mapping
Feature discipline
Traceability
Scope clarity
Release logic
Decision visibility
Standards-to-product traceability
GOV-009 product linkage quality
```

---

# 256. UX Lead Responsibility

At this stage, UX Lead reviews:

```text
User model
Workflow plausibility
Platform/channel implications
Experience risk
Accessibility and cross-cutting experience implications
```

without designing detailed UI.

---

# 257. Solution Architect Responsibility

At this stage, architect reviews:

```text
Major feasibility implications
Integration boundaries
Product decomposition risk
Platform constraints
Standards-derived architecture implications
```

without replacing product decisions with technical convenience.

---

# 258. Phase 03 Anti-Patterns

## AP-03-01 — Menu-Driven Product Design

Defining product by sidebar items.

---

# 259. AP-03-02 — Every Business Capability = Module

Leads to artificial decomposition.

---

# 260. AP-03-03 — Every Requested Idea = Feature

No validation.

---

# 261. AP-03-04 — Feature = Requirement

Collapsing levels of abstraction.

---

# 262. AP-03-05 — MVP = Cheap Version

Removing controls/quality instead of scope.

---

# 263. AP-03-06 — Platform First

Choosing mobile/web before understanding user context.

---

# 264. AP-03-07 — Admin Everywhere

One generic admin role hides real product roles.

---

# 265. AP-03-08 — Scope by Stakeholder Seniority

Most senior person requests something, so it enters MVP.

---

# 266. AP-03-09 — Roadmap as Deadline List

Dates without outcome/capability rationale.

---

# 267. AP-03-10 — Product = Current Process Automation

Copying current inefficiencies into digital form.

---

# 268. AP-03-11 — CRUD Product Modeling

Every business object becomes Create/Edit/Delete pages.

---

# 269. AP-03-12 — Module Explosion

Dozens of tiny modules with no meaningful ownership.

---

# 270. AP-03-13 — God Module

One module owns almost everything.

---

# 271. AP-03-14 — Undefined External Ownership

Product assumes another system handles something, but no source of truth exists.

---

# 272. AP-03-15 — Roadmap Inflation

Placing every possible idea into future roadmap.

---

# 273. AP-03-16 — Product State by Badge

Creating statuses for visual convenience rather than business meaning.

---

# 274. AP-03-17 — Architecture Leakage

Choosing microservices, DB, cloud inside product definition.

---

## AP-03-18 — Standards as a Generic Footer

كتابة:

```text
Product must be accessible, secure, and compliant.
```

بدون `GOV-009` applicability decision أو canonical product capability/constraint/policy/platform/journey/document/third-party/release implication.

هذا لا يجهز Phase 04، ويؤجل product responsibility إلى downstream teams.

---

# 275. Phase Quality Measures

Future Product OS may track:

```text
Business-to-Product Capability Coverage
Orphan Feature Count
Orphan Module Count
Scope Leak Count
Feature-to-Capability Coverage
Release Coherence
MVP Objective Coverage
Unresolved Product Decision Count
Cross-Module Dependency Count
Product Baseline Reopen Rate
Requirement Reversal Due to Product Ambiguity
Standards-to-Product-Implication Coverage
Applicable-Standard Product-Orphan Count
Phase 04 Standards-Derivation Readiness
Pending-Applicability Age at G3A
```

---

# 276. Important Quality Metric

```text
REQUIREMENT INVENTION RATE
```

أي:

> كم Requirement اضطر فريق Phase 04 لاختراعه لأن Product Definition لم تحدد responsibility أو scope؟

---

# 277. Another Important Metric

```text
FEATURE WITHOUT BUSINESS RATIONALE RATE
```

كلما زاد، product scope يتحول إلى wishlist.

---

# 278. Phase Completion Contract

## Required Inputs

```text
G2-approved Business Baseline
Business Objectives
Business Capabilities
Business Processes
Business Rules
Business Roles
Business Controls
Business Information
Risk Context
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated / Pending Conditional Profiles
Standards-Derived Business Requirements / Rules / Controls / Policies / Information / Evidence Obligations
G2-18 Result
```

---

# 279. Required Questions

Phase 03 must answer:

```text
What exactly is the product?

Why does it exist?

Who uses it?

What does it own?

What remains manual or external?

What business capabilities does it support?

What product capabilities are required?

How is the product logically organized?

What feature candidates realize those capabilities?

What states/lifecycles matter?

What product policies must hold?

What integrations matter?

What dependencies exist?

What is the MVP?

What belongs to later releases?

How will product success be measured?

What product decisions remain open?

Which universal standards and conditional profiles apply?

What product capabilities, constraints, policies, platforms, channels, journeys, documents, third parties, enterprise capabilities, or release boundaries result?

Which Phase 04 requirement types must be derived from each applicable entry?

Who owns and approves each product interpretation, exclusion, and exception?

What product changes reopen each applicability decision?
```

---

# 280. Required Decisions

At minimum:

```text
Product Vision
Product Boundary
Product Scope
Product User Model
Product Capability Baseline
Product Domain/Module Baseline
Initial Feature Candidate Baseline
Product State Baseline where applicable
Product Policy Baseline
MVP / Initial Release Scope
Roadmap Direction
Risk Reassessment
Standards Applicability Product Baseline
Standards-Derived Product Capability / Constraint / Policy Baseline
Phase 04 Standards-Derivation Contract
GOV-009 Phase 03 Update
G3A Outcome
```

---

# 281. Exit Criteria

Phase 03 complete when:

1. Product vision and mission defined.
2. Product scope approved or sufficiently baselined.
3. Product boundary explicit.
4. Primary users and product roles known.
5. Business capability responsibility mapped.
6. Product capabilities defined.
7. Product domains/modules coherent.
8. Feature candidates mapped to capabilities.
9. Critical product states modeled.
10. Critical product policies known.
11. Major integrations identified.
12. Major dependencies known.
13. MVP/release scope defined where applicable.
14. Roadmap direction established.
15. Product success direction known.
16. Blocking product conflicts resolved.
17. Blocking product questions = 0.
18. Product risks reassessed.
19. Universal standards and conditional profiles reviewed through `GOV-009`.
20. Applicable business obligations mapped to canonical product implications or approved no-product-impact rationale.
21. Supported platforms, countries, languages, documents, third parties, enterprise capabilities, and release boundaries are consistent with applicability decisions.
22. Phase 04 requirement-derivation types and source links are explicit.
23. Blocking `GOV-009` decisions and standards-derived product responsibility gaps = 0.
24. `GOV-009` updated with product links, owners, evidence, and reopen conditions.
25. G3A evaluated, including G3A-18.
26. Requirements handoff generated.

---

# 282. Final Transformation

Phase 03 transforms:

```text
APPROVED BUSINESS BASELINE
```

into:

```text
PRODUCT VISION
+
PRODUCT BOUNDARY
+
PRODUCT SCOPE
+
USERS
+
PRODUCT ROLES
+
PRODUCT CAPABILITIES
+
PRODUCT DOMAINS
+
MODULES
+
FEATURE CANDIDATES
+
PRODUCT STATES
+
PRODUCT POLICIES
+
INTEGRATIONS
+
DEPENDENCIES
+
MVP
+
RELEASES
+
ROADMAP
+
STANDARDS-LINKED PRODUCT CAPABILITIES / CONSTRAINTS / POLICIES
+
PHASE 04 REQUIREMENT-DERIVATION OBLIGATIONS
```

---

# 283. Final Methodology Principle

```text
Product Definition must decide what the product is responsible for
before Requirements Engineering specifies how the system must behave.
```

---

# 284. Phase 03 Output

```text
APPROVED BUSINESS BASELINE
        ↓
PRODUCT DEFINITION
        ↓
APPROVED PRODUCT BASELINE
        ↓
STANDARDS-LINKED PRODUCT BASELINE
        ↓
G3A — PRODUCT BASELINE
        ↓
REQUIREMENTS ENGINEERING
```

**Phase 00 ensured we entered the correct project.**

**Phase 01 ensured we understood the correct problem.**

**Phase 02 ensured the business logic was defined.**

**Phase 03 ensures we define the correct product boundary and value before specifying the system in detail.**
