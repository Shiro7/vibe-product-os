# Product OS v1.0 — Methodology Specification
## Phase 04: Requirements Engineering

**Phase ID:** `PHASE-04`  
**Phase Name:** `Requirements Engineering`  
**Version:** `1.0`  
**Status:** `BASELINE DRAFT — PHASE CONTRACT COMPLETE`  
**Primary Gate:** `G3B — Requirements Baseline`  
**Primary Baseline:** `RBL — Requirements Baseline`  
**Primary Outcome:** تحويل الـapproved Business Baseline والـProduct Baseline والـstandards-derived obligations إلى مجموعة system requirements ذرية، متسقة، مستقلة عن الحل، قابلة للتحقق، ومتصلة بالمصدر والقبول والـdownstream ownership.

---

# 1. Purpose

الغرض من Phase 04 هو الانتقال من:

```text
The business needs capability X.
The product owns responsibility Y.
```

إلى:

```text
What exactly shall the system do?
Under which conditions?
For whom?
With which data, controls, integrations, and quality constraints?
How will we prove that the requirement is satisfied?
```

Phase 04 تنشئ **Requirements Baseline** يمكن أن تعتمد عليه Experience Architecture وProduct Design وSolution Architecture وEngineering وVerification بدون اختراع behavior أو scope أو quality obligations.

---

# 2. Position in Product OS

```text
PHASE 02 — BUSINESS ARCHITECTURE
                │
                ▼
       APPROVED BUSINESS BASELINE
                │
                ▼
PHASE 03 — PRODUCT DEFINITION
                │
                ▼
       G3A — PRODUCT BASELINE
                │
                ▼
PHASE 04 — REQUIREMENTS ENGINEERING
                │
                ▼
       G3B — REQUIREMENTS BASELINE
                │
       ┌────────┼────────┐
       ▼        ▼        ▼
 Experience  Design   Architecture
   Phase 05  Phase 06   Phase 07
       └────────┼────────┘
                ▼
       ENGINEERING READINESS
```

Phase 04 تأتي بعد أن تم تحديد:

```text
Why the business needs change
What the product owns
Who uses the product
Which capabilities, policies, states, platforms, releases, and boundaries apply
```

هي لا تعيد فتح هذه القرارات إلا عند اكتشاف gap أو conflict يمنع requirement صحيحًا.

---

# 3. Core Requirements Question

> **What observable behavior or measurable quality must the system provide so that the approved business and product responsibilities are satisfied?**

ثم:

> **What evidence will prove that each requirement has been met?**

---

# 4. Requirements Engineering Philosophy

Product OS Requirements Engineering يعتمد على المبادئ التالية.

## RE-01 — Derivation Before Invention

كل Requirement يجب أن تشتق من source معتمد أو obligation ظاهر.

```text
Business / Product / Standard / Risk / Decision
                         ↓
                    Requirement
```

إذا احتاج فريق Phase 04 لاختراع product responsibility، فالمشكلة upstream وليست فرصة لملء SRS.

---

## RE-02 — Observable Behavior

Requirement تصف behavior أوquality أوconstraint يمكن ملاحظته أو قياسه.

```text
The system SHALL...
```

وليست aspiration مثل:

```text
The system should be user-friendly.
```

---

## RE-03 — Atomicity

كل Requirement تمثل obligation واحدة قابلة للمراجعة والتغيير والتحقق بصورة مستقلة.

---

## RE-04 — Implementation Independence

Phase 04 تحدد **what** و**under which constraints**.

لا تختار **how** إلا إذا كان implementation constraint معتمدًا من Source authoritative.

---

## RE-05 — Acceptance Is Part of the Requirement

Requirement بدون measurable acceptance criteria ليست ready للـbaseline.

---

## RE-06 — Traceability Is Structural

Traceability ليست spreadsheet يملأ في النهاية.

كل Requirement تولد بروابط upstream وdownstream متوقعة منذ لحظة إنشائها.

---

## RE-07 — Quality Is Explicit

Security وAccessibility وReliability وAudit وData وIntegration ليست assumptions عامة ولا شغل QA لاحقًا.

هي requirement families مستقلة عندما تكون applicable.

---

## RE-08 — Unknown Must Remain Visible

`TBD` و`TBC` و`PENDING` لا تختفي داخل wording غامض.

كل unknown يحتاج owner وimpact وdue gate.

---

## RE-09 — One Canonical Requirement

الـobligation الواحدة لا تنسخ في عدة catalogs بصيغ متعارضة.

Requirement لها primary type واحد، ويمكن إضافة tags وروابط cross-cutting.

---

## RE-10 — Standards Must Become Verifiable Requirements

كل applicable `GOV-009` derivation obligation يجب أن ينتج requirement IDs أو explicit approved no-requirement rationale.

---

# 5. Phase Objectives

بنهاية Phase 04 يجب أن يكون Product OS قادرًا على:

1. إنشاء System Requirements Specification واضحة ومحدودة.
2. اشتقاق requirements من الـBusiness Baseline والـProduct Baseline.
3. تحويل Feature Candidates إلى requirements دون اعتبارها requirements تلقائيًا.
4. تحديد Functional Requirements.
5. تحديد Non-Functional Requirements.
6. تحديد Data Requirements.
7. تحديد Integration Requirements.
8. تحديد Security and Privacy Requirements.
9. تحديد Accessibility Requirements.
10. تحديد Audit and Evidence Requirements.
11. تغطية states وtransitions وexceptions وerror/recovery behavior.
12. تحديد acceptance criteria قابلة للتحقق.
13. تحديد verification method لكل Requirement.
14. فصل requirement statement عن design أوarchitecture أوtest implementation.
15. إزالة ambiguity والتكرار والتعارض.
16. تحديد priority وcriticality وrelease allocation.
17. تحديد requirement dependencies.
18. إجراء feasibility review بدون اختيار solution.
19. بناء bidirectional traceability.
20. كشف orphan requirements وupstream coverage gaps.
21. مراجعة `GOV-009` واشتقاق `FR/NFR/DR/INT/SEC/ACC/AUD` المطلوبة.
22. تحديث `GOV-009` بالـderived requirement IDs والـverification expectations.
23. إنشاء downstream handoff لـExperience وDesign وArchitecture وQA.
24. إنشاء versioned Requirements Baseline.
25. تمرير `G3B — Requirements Baseline`.

---

# 6. Phase Inputs

Required logical inputs:

```text
BUS-001 BRD
BUS-002 Business Capability Map
BUS-005 Business Process Catalog
BUS-006 Business Rules Catalog
BUS-007 Business Decision Catalog
BUS-008 Roles & Responsibilities
BUS-009 Business Control Register
BUS-010 Business Information Model
Business Exceptions and Evidence Obligations
PROD-002 Product Scope & Boundary
PROD-003 Product Objective Model
PROD-004 Product User & Role Model
PROD-005 Product Capability Map
PROD-006 Product Domain & Module Map
PROD-007 Feature Candidate Catalog
PROD-008 Product State & Lifecycle Model
PROD-009 Product Policy & Constraint Register
PROD-010 Product Integration & Dependency Map
PROD-011 MVP & Release Scope
PROD-013 Product KPI Model
G2 Decision
G3A Decision
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated Conditional Profiles
Standards-Derived Business and Product Obligations
Phase 04 Requirement-Derivation Types and Source Links
```

---

# 7. Entry Condition

Phase 04 تبدأ عندما:

```text
G3A = PASS
```

أو:

```text
G3A = PASS_WITH_CONDITIONS
```

بشرط أن الـconditions لا تجبر Phase 04 على اختراع product scope أوresponsibility.

Minimum entry conditions:

```text
Blocking product decisions = 0
Blocking GOV-009 applicability decisions = 0
Product scope and boundary are usable
Required derivation sources are identifiable
```

---

# 8. What Phase 04 Is Not

Phase 04 ليست:

- Business Discovery.
- Product Strategy.
- Product Definition.
- UX journey design.
- Information Architecture.
- Wireframing.
- UI screen specification.
- Visual Design.
- Design System creation.
- Solution Architecture.
- API contract design.
- Physical database schema design.
- Infrastructure design.
- Sprint planning.
- Engineering task breakdown.
- Test-case authoring.
- UAT execution.
- Compliance certification.

قد تسجل Phase 04 implications لهذه الأعمال، لكنها لا تنفذها.

---

# 9. Requirement Abstraction Ladder

```text
Problem / Outcome
      ↓
Business Requirement / Rule / Control
      ↓
Product Capability / Policy / Constraint / State
      ↓
System Requirement
      ↓
Experience / Design / Architecture Specification
      ↓
Engineering Task
      ↓
Test Case and Evidence
```

كل مستوى يجيب سؤالًا مختلفًا.

---

# 10. Business Requirement vs System Requirement

Business Requirement:

```text
The organization must ensure that only authorized managers approve refunds above the threshold.
```

System Requirements مشتقة قد تكون:

```text
FR-AUTH-014
The system SHALL require an approval by a user holding the authorized refund-approver role before a refund above the active threshold can be completed.

AUD-REF-006
The system SHALL retain the requester, approver, threshold version, decision, timestamp, and refund identifier for every above-threshold refund decision.
```

---

# 11. Product Capability vs Requirement

Product Capability:

```text
PCAP-014 — Managed Refund Approval
```

Requirement:

```text
FR-REF-001 — Initiate a refund request.
FR-REF-002 — Route above-threshold refunds for approval.
FR-REF-003 — Prevent completion before approval.
FR-REF-004 — Notify requester of the decision.
AUD-REF-001 — Record the decision trail.
```

Capability واحدة تنتج عدة Requirements.

---

# 12. Feature Candidate vs Requirement

`FEAT-*` يمثل possible product behavior أوfeature grouping.

لا يصبح approved requirement إلا بعد:

```text
Scope confirmation
Source linkage
Behavior decomposition
Acceptance definition
Conflict review
Priority and release allocation
```

---

# 13. User Story vs Requirement

User Story يمكن أن تكون view مفيدة:

```text
As a warehouse supervisor,
I want to approve a stock adjustment,
so that inventory corrections are controlled.
```

لكنها لا تكفي كcanonical requirement لأنها قد لا تحدد:

```text
Authorization
Preconditions
State transition
Threshold rules
Exceptions
Audit
Failure behavior
Acceptance criteria
```

User Story قد ترتبط بواحدة أو أكثر من `FR-*`، لكنها لا تستبدلها.

## Use Case and Scenario Views

Use Case أوScenario يمكن أن يجمع عدة requirements حول goal واحد ويوضح actor، trigger، main flow، alternatives، exceptions، and outcome.

لكنه supporting analysis view. Canonical obligations تظل IDs الذرية، ويرتبط الـscenario بها بدل أن يصبح نصًا موازيًا غير مضبوط.

---

# 14. Requirement Families

Canonical Phase 04 primary types:

```text
FR    Functional Requirement
NFR   Non-Functional Requirement
DR    Data Requirement
INT   Integration Requirement
SEC   Security and Privacy Requirement
ACC   Accessibility Requirement
AUD   Audit and Evidence Requirement
```

`DR` في Phase 04 يعني **Data Requirement**.

Disaster Recovery يعبر عنه داخل `NFR-BCDR-*` لتجنب ambiguity.

---

# 15. Primary Type and Cross-Cutting Tags

كل Requirement لها primary type واحد.

يمكن إضافة tags مثل:

```text
PRIVACY
LOCALIZATION
RTL
PERFORMANCE
RELIABILITY
GENERATED_DOCUMENT
THIRD_PARTY
PAYMENTS
MULTI_TENANCY
REGULATED_DATA
```

إذا behavior واحدة تحقق security وaudit معًا، نقرر primary obligation ونربط requirement ثانية فقط إذا كان هناك obligation مستقلة قابلة للتحقق.

---

# 16. Requirement ID Scheme

Recommended canonical format:

```text
<TYPE>-<DOMAIN>-<SEQUENCE>
```

Examples:

```text
FR-AUTH-001
NFR-PERF-004
DR-EMP-012
INT-PAY-003
SEC-SESS-006
ACC-FORM-008
AUD-APR-002
```

Small projects may omit domain code:

```text
FR-001
NFR-001
```

IDs لا يعاد استخدامها بعد الحذف أوsupersession.

---

# 17. Requirement Title

Title مختصر للبحث والفهرسة.

```text
FR-AUTH-001 — Sign in with an active account
```

Title لا تستبدل statement.

---

# 18. Normative Language

Product OS canonical requirement statements تستخدم:

```text
SHALL
SHALL NOT
```

لمنع الخلط بين obligation وpreference.

`should`, `may`, `ideally`, `where possible` لا تستخدم داخل approved normative statement إلا عندما يكون معناها formal ومحددًا.

Priority لا تعبر عنها قوة الفعل. Requirement إما obligation أو ليست في الـbaseline.

---

# 19. Canonical Requirement Syntax

Recommended form:

```text
[Subject] SHALL [observable behavior]
[when/while/after condition]
[for actor/object/scope]
[within measurable constraint where applicable].
```

Example:

```text
The system SHALL prevent submission of a purchase request when no active cost center is associated with the requester.
```

---

# 20. Negative Requirement Syntax

```text
The system SHALL NOT expose a user's recovery token in logs, user-visible URLs, or analytics events.
```

Negative requirements تستخدم عندما prohibition نفسها obligation قابلة للتحقق.

لا تستخدم لصياغة behavior طبيعي بصورة ملتوية.

---

# 21. Requirement Record Contract

```yaml
requirement_id: FR-APR-014
title: "Approve above-threshold request"
type: FR
domain: APPROVALS

statement:
  "The system SHALL require approval from an authorized approver before completing a request whose value exceeds the active approval threshold."

origin:
  mode: DERIVED
  sources:
    - BREQ-014
    - BR-022
    - PCAP-009
    - PPOL-004

rationale:
  "Preserves the approved financial control."

scope:
  actors:
    - ROLE-APPROVER
  product_areas:
    - MOD-REQUESTS
  platforms:
    - WEB
    - MOBILE
  releases:
    - RELEASE-1

conditions:
  preconditions:
    - "Request is otherwise valid."
  trigger:
    - "Requested value exceeds the active threshold."

related_rules:
  - BR-022

related_states:
  from: SUBMITTED
  to: PENDING_APPROVAL

acceptance_criteria:
  - AC-FR-APR-014-01
  - AC-FR-APR-014-02

verification:
  method:
    - TEST
    - INSPECTION
  level:
    - SYSTEM

priority:
  business: MUST
  release: RELEASE-1
  criticality: HIGH

dependencies:
  requirements:
    - SEC-AUTHZ-003
    - AUD-APR-002

status:
  lifecycle: IN_REVIEW
  approval: PENDING

ownership:
  requirement_owner: PRODUCT_OWNER
  validation_owner: BUSINESS_AUTHORITY

traceability:
  upstream:
    - BREQ-014
    - PCAP-009
  downstream_expected:
    - EXPERIENCE
    - ARCHITECTURE
    - TEST

change:
  baseline_version: null
  supersedes: null
```

---

# 22. Minimum Mandatory Fields

كل approved Requirement تحتاج على الأقل:

```text
ID
Title
Primary Type
Normative Statement
Source / Derivation Link
Rationale where not obvious
Scope
Acceptance Criteria
Verification Method
Priority / Release Disposition
Lifecycle Status
Owner
Upstream Traceability
```

Fields الإضافية تتفعل حسب applicability.

---

# 23. Requirement Origin

Canonical origin modes:

```text
DERIVED       From approved business/product objects
IMPOSED       From standard, regulation, contract, or organization policy
ALLOCATED     Assigned to this product/system from a wider system
CAPTURED      Explicitly stated by an authorized source, pending derivation review
INFERRED      Proposed by analysis and not yet accepted
```

`INFERRED` لا تدخل baseline قبل validation وsource disposition.

---

# 24. Requirement Source Hierarchy

Possible sources:

```text
BREQ
BR
BD
CTRL
POL
INFO
EVID
OBJ / KPI
PCAP
PPOL
PCON
PSTATE
PINT / PDEP
FEAT
RELEASE
GOV-009
Risk
Decision
Contract / Standard / Regulation Source
```

Source hierarchy لا يعني أن lower-level source يستطيع تغيير higher-authority baseline.

---

# 25. New Information Discovered in Phase 04

إذا ظهر requirement candidate جديد:

```text
Clarifies approved scope without changing responsibility
    → derive and validate normally

Changes product scope, boundary, capability, policy, or release
    → SCOPE_CHANGE_CANDIDATE and Phase 03 review

Changes business rule, control, policy, or obligation
    → BUSINESS_BASELINE_GAP and Phase 02 review

Changes standards applicability
    → GOV-009 REVIEW_REQUIRED
```

Phase 04 لا تستخدم كلمة "تفصيل" لإخفاء scope expansion.

---

# 26. Requirement Quality Model

كل Requirement يجب أن تكون:

```text
Necessary
Correct
Atomic
Unambiguous
Complete enough
Consistent
Feasible
Verifiable
Implementation-independent
Traceable
Prioritized
Owned
```

---

# 27. Necessary

Requirement ضرورية إذا كان لها upstream source أوrisk/control/standard rationale معتمد.

Requirement بلا سبب واضح تصبح:

```text
ORPHAN_REQUIREMENT
```

---

# 28. Correct

Requirement يجب أن تمثل source intent بدون توسيع أوإضعاف أوتغيير المعنى.

Correctness يعتمدها subject-matter authority، وليس الصياغة وحدها.

---

# 29. Atomic

علامات requirement غير الذرية:

```text
and
or
including but not limited to
multiple unrelated acceptance outcomes
several independently changeable behaviors
```

Example bad:

```text
The system SHALL create, approve, export, email, archive, and delete reports.
```

يجب تفكيكها.

---

# 30. Unambiguous

كل stakeholder وdesigner وengineer وtester يجب أن يفهم نفس obligation الأساسية.

الغموض لا يحل بإضافة كلمات أكثر؛ يحل بتحديد subject وcondition وbehavior وmeasure.

---

# 31. Ambiguity Blacklist

كلمات تحتاج replacement أوdefinition:

```text
fast
easy
simple
intuitive
secure
robust
scalable
seamless
modern
user-friendly
real-time
soon
appropriate
adequate
as needed
where possible
etc.
```

مثال:

```text
The report shall load quickly.
```

يستبدل بmeasure محددة وload condition واضحة.

---

# 32. Complete Enough

Requirement ليست مطالبة بوصف solution كلها.

لكن يجب ألا تترك جزءًا يغير القبول materially مثل:

```text
Actor
Trigger
Precondition
Expected behavior
Failure behavior
State effect
Data or policy constraint
Measure
```

---

# 33. Consistent

Requirement لا تتعارض مع:

```text
Business Rule
Product Policy
Product State
Another Requirement
Release Boundary
GOV-009 Decision
```

Conflict لا يحل باختيار AI لأحد النصين.

---

# 34. Feasible

Feasibility review يسأل:

```text
Can this behavior be implemented within known constraints?
Can it be verified?
Does a required dependency exist?
Is the requested measure technically and operationally plausible?
```

لا يتحول review إلى اختيار architecture.

---

# 35. Verifiable

يجب وجود طريقة معقولة لإثبات satisfaction.

Canonical verification methods:

```text
TEST
INSPECTION
ANALYSIS
DEMONSTRATION
REVIEW
MEASUREMENT
AUDIT
```

---

# 36. Implementation-Independent

Bad:

```text
The system SHALL use Redis to cache sessions.
```

Better requirement:

```text
The system SHALL make a revoked session unusable across all supported application instances within 30 seconds.
```

Redis may later be an architecture decision.

---

# 37. Traceable

كل Requirement يجب أن تعرف:

```text
Why it exists
What upstream object it satisfies
Which downstream artifacts must realize it
Which tests/evidence will verify it
What changes could invalidate it
```

---

# 38. Requirement Scope

Scope dimensions may include:

```text
Product / System
Domain / Module
Actor / Role
Tenant / Entity
Platform / Channel
Country / Market
Language / Direction
Journey / Process
Data Classification
Document Type
Third Party
Release
```

لا تستخدم `ALL` بدون إثبات أن obligation فعلًا global.

---

# 39. Applicability

Requirement applicability uses:

```text
APPLICABLE
NOT_APPLICABLE
CONDITIONAL
PENDING
```

هذا يخص requirement داخل scope محدد.

لا يغير canonical applicability values الخاصة بـ`GOV-009`.

`NOT_APPLICABLE` يحتاج rationale وscope وreopen condition عند وجود expectation upstream.

---

# 40. Conditional Requirement

Conditional requirement يجب أن تذكر trigger صراحة.

```text
When offline operation is enabled for a field user, the system SHALL identify locally stored records that have not yet synchronized.
```

لا تكتب:

```text
If applicable, support offline records.
```

---

# 41. Preconditions

Precondition تصف ما يجب أن يكون صحيحًا قبل behavior.

لا تستخدم precondition لإخفاء authorization أوvalidation obligation.

---

# 42. Trigger

Trigger قد يكون:

```text
User action
State change
Time event
External event
Threshold crossing
Scheduled event
Administrative decision
```

---

# 43. Postcondition

Postcondition تصف observable resulting state أوoutput.

```text
After approval, the request state SHALL be APPROVED and the approval record SHALL reference the approving actor and active rule version.
```

---

# 44. Invariant

Invariant يجب أن يظل صحيحًا عبر عدة behaviors.

Example:

```text
SEC-TEN-001
The system SHALL prevent a user from accessing records owned exclusively by another tenant.
```

يمكن ربط عدة FRs بنفس invariant بدل نسخ العبارة داخل كل FR.

---

# 45. Business Rule Application

Requirement لا تعيد تعريف Business Rule.

هي توضح أين وكيف يجب أن يطبق النظام الـrule:

```text
BR-014 defines the threshold.
FR-APR-006 applies the active BR-014 threshold during submission.
AUD-APR-004 records the rule version used.
```

---

# 46. Requirement Rationale

Rationale مطلوب عندما:

```text
The requirement is non-obvious
It derives from risk or standard
It constrains solution choices materially
It resolves a conflict
It is allocated to a specific platform or release
```

Rationale لا يدخل normative statement.

---

# 47. Requirement Notes

Notes قد تحتوي explanation أوexample.

Notes ليست normative ما لم يتم تحويلها إلى requirement أوacceptance criterion.

---

# 48. Examples Are Not Scope

```text
For example: PDF and CSV.
```

لا يحدد إن كانت الصيغتان exhaustive.

استخدم:

```text
Supported formats: PDF, CSV.
```

أو:

```text
At minimum: PDF, CSV.
```

مع توضيح ownership لباقي الصيغ.

---

# 49. Requirement Assumptions

Requirement قد تعتمد على assumption.

```text
FR-042 depends_on ASM-008
```

إذا assumption invalidated:

```text
Requirement → REVIEW_REQUIRED
```

Assumption لا تدمج داخل statement كأنها fact.

---

# 50. Requirement Dependencies

Dependency types:

```text
REQUIRES
PRECEDES
CONFLICTS_WITH
REFINES
COMPLEMENTS
SUPERSEDES
ALLOCATED_WITH
VERIFIED_BY
```

Circular dependency تحتاج review.

---

# 51. Requirement Group

Requirements يمكن تجميعها بواسطة:

```text
Domain
Capability
Journey
Process
State Model
Release
Requirement Type
Standard / Profile
Risk / Control
```

Group لا تصبح canonical parent إلا إذا لها ID وعلاقة واضحة.

---

# 52. Parent and Child Requirements

Parent requirement تستخدم فقط إذا كانت umbrella obligation مفيدة.

```text
NFR-A11Y-001 — Product accessibility baseline
    ↓ refined_by
ACC-NAV-001
ACC-FORM-001
ACC-DOC-001
```

Parent لا تعتبر verified لمجرد نجاح child واحدة.

---

# 53. Requirement Variants

إذا behavior تختلف حسب market/platform/role:

```text
Common requirement
    +
Explicit variant requirements
```

لا تكتب عدة behaviors متضاربة في statement واحدة.

---

# 54. Product-State Requirements

كل critical Product State يحتاج review لـ:

```text
Entry conditions
Allowed transitions
Forbidden transitions
Authorized actors
Side effects
Notifications
Audit
Recovery
Terminal behavior
```

---

# 55. Transition Requirement

Example:

```text
FR-ORD-021
The system SHALL allow an order to transition from PACKED to SHIPPED only when a carrier reference has been recorded.
```

---

# 56. Invalid Transition

يجب تحديد behavior عند محاولة transition غير مسموحة:

```text
Prevent transition
Preserve prior state
Return actionable error
Record security/audit event when material
```

---

# 57. Exception Requirement

Happy path وحده لا يكفي.

Exceptions include:

```text
Invalid input
Missing dependency
Rejected decision
Expired state
Duplicate request
Conflict
Partial completion
Timeout
Unauthorized attempt
Unavailable third party
```

---

# 58. Error Requirement

Error requirement تحدد:

```text
Detection
Safe state
User/system feedback
Retry or recovery eligibility
Audit/observability need
Data integrity expectation
```

لا تحدد final microcopy أوvisual presentation في Phase 04.

---

# 59. Recovery Requirement

Recovery behavior يجب ألا يكون implied.

Example:

```text
When a payment authorization result is unknown, the system SHALL prevent duplicate capture and SHALL reconcile the transaction before allowing another capture attempt.
```

إذا الجملة تحمل obligationين مستقلتين في verification، تقسم إلى Requirementين مرتبطتين.

---

# 60. Time and Date Semantics

Requirements التي تعتمد على الوقت يجب أن تحدد business semantics مثل:

```text
Business timezone
User display timezone
Cut-off definition
Calendar type
Daylight-saving behavior where applicable
Effective-from / effective-to rules
Timestamp precision
```

لا تختار storage implementation.

---

# 61. Money and Numeric Semantics

Requirements المالية تحدد عند الحاجة:

```text
Currency
Precision
Rounding rule source
Exchange-rate source and effective time
Tax inclusion/exclusion
Threshold comparison behavior
Negative/zero handling
```

---

# 62. Localization Semantics

Requirements localization قد تحدد:

```text
Supported languages
RTL / LTR behavior responsibility
Locale-sensitive formatting
Translation ownership
Fallback behavior
User-entered multilingual content
Search/sort implications
Generated-document language
```

---

# 63. Generated Documents

كل generated document يحتاج requirements تغطي حسب applicability:

```text
Purpose and audience
Trigger
Required information
Authoritative source
Language and direction
Format
Accessibility
Security and privacy
Version / template identity
Retention
Audit
Delivery channel
Failure and regeneration behavior
```

Document layout التفصيلي يأتي لاحقًا في Design.

---

# 64. Notification Requirements

Notification requirement تحدد:

```text
Business event
Recipient eligibility
Required information
Channel policy
Timing expectation
Preference/consent constraints
Failure handling
Deduplication
Audit where material
```

لا تفترض email أوSMS إلا إذا channel معتمد.

---

# 65. Search Requirements

Search requirement يجب أن تحدد:

```text
Searchable business fields
Authorization filtering
Matching semantics where material
Sorting/filtering expectations
Empty/no-result behavior
Performance measure
Localization considerations
Sensitive-data exposure limits
```

Search engine technology ليست Phase 04 decision.

---

# 66. Functional Requirements

`FR` تصف behavior يؤديه النظام أو يمنعه استجابةً لمستخدم أوevent أوstate أوschedule.

FR may cover:

```text
Capture
Validate
Calculate
Decide using approved rule
Route
Approve / Reject
Transition state
Notify
Generate
Search / Retrieve
Import / Export
Reconcile
Administer approved configuration
Recover
```

---

# 67. Functional Requirement Derivation

Primary derivation sources:

```text
Business Process Step
Business Decision
Business Rule
Business Control
Product Capability
Feature Candidate
Product Policy
Product State
Product Workflow Candidate
Exception
```

---

# 68. Functional Decomposition

For each capability or journey, ask:

```text
Who initiates it?
What is the trigger?
What input is required?
What validation applies?
What decision/rule applies?
What state changes?
What output is produced?
Who is notified?
What may fail?
How is recovery handled?
What must be audited?
```

---

# 69. CRUD Warning

```text
Create / Read / Update / Delete
```

ليست requirement model كافية.

Business meaning قد يحتاج:

```text
Draft
Submit
Approve
Suspend
Reactivate
Expire
Archive
Correct
Reverse
```

`Delete` قد يكون ممنوعًا أصلًا بسبب retention أوaudit.

---

# 70. Configuration Requirements

Configurable behavior يجب أن يحدد:

```text
What can be configured
Who may configure it
Allowed ranges/options
Effective time
Versioning
Validation
Impact on in-flight records
Audit
Rollback or correction behavior
```

لا تستخدم كلمة `configurable` كبديل لهذه القرارات.

---

# 71. Bulk Operation Requirements

Bulk behavior يحتاج تحديد:

```text
Eligibility
Maximum or capacity expectation
Partial success policy
Atomicity expectation
Progress visibility
Cancellation
Error reporting
Retry
Authorization
Audit
```

---

# 72. Administrative Requirements

Admin behavior ليس shortcut لتجاوز business controls.

كل administrative action material يحتاج:

```text
Authorized role
Purpose
Constraint
Dual control if applicable
Audit
Notification
Reversal or correction path
```

---

# 73. Non-Functional Requirements

`NFR` تحدد measurable quality أوoperational constraint يطبق على behavior أوsystem boundary.

Canonical quality domains:

```text
Performance
Capacity and Scalability
Availability
Reliability
Resilience
Business Continuity and Disaster Recovery
Usability quality constraints
Compatibility
Portability
Maintainability
Supportability
Observability
Operability
Localization quality
Interoperability quality
Legal / Regulatory quality constraints
```

Security وAccessibility وData وIntegration وAudit لها families مستقلة عند الحاجة.

---

# 74. NFR Scope Rule

كل NFR تحدد scope القياس:

```text
Which transaction or workload?
Which environment?
Which user population?
Which data volume?
Which percentile or window?
Which exclusions?
```

`System shall respond in 2 seconds` غير كافية.

---

# 75. Performance Requirement

Example:

```text
NFR-PERF-004
For the approved search workload and reference dataset, the system SHALL return the first page of results within 2 seconds at the 95th percentile during the defined normal operating load.
```

يجب تعريف reference workload والdataset والenvironment في linked verification profile.

---

# 76. Capacity Requirement

Capacity may include:

```text
Concurrent active users
Requests per unit time
Records
File size
Events per second
Tenants / entities
Retention volume
Batch size
Peak factor
Growth horizon
```

Numbers تحتاج source وrationale.

---

# 77. Scalability Requirement

لا تكتب:

```text
The system shall be scalable.
```

حدد growth scenario وservice objective الذي يجب الحفاظ عليه.

---

# 78. Availability Requirement

Availability requirement تحدد:

```text
Service boundary
Measurement window
Operating schedule
Allowed exclusions
Target
Critical journeys
Dependency assumptions
```

Availability percentage بلا measurement contract ليست verifiable.

---

# 79. Reliability Requirement

Reliability may address:

```text
Successful transaction rate
Data integrity
Duplicate prevention
Ordering
Exactly-once business outcome where required
Long-running process completion
Error budget
```

---

# 80. Resilience Requirement

Resilience تحدد behavior تحت failure:

```text
Dependency outage
Network interruption
Partial service loss
Retryable failure
Degraded mode
Recovery
User communication
Reconciliation
```

---

# 81. Business Continuity and Disaster Recovery

Use IDs such as:

```text
NFR-BCDR-001
```

May define:

```text
RTO
RPO
Critical service priority
Backup restoration outcome
Failover expectation
Data reconciliation
Recovery verification frequency
Manual continuity need
```

Architecture تحدد mechanism لاحقًا.

---

# 82. Maintainability Requirement

Maintainability must remain verifiable.

Possible subjects:

```text
Configuration change without code change
Supported upgrade path
Backward compatibility window
Diagnostic information
Modular change boundary
Documentation obligation
Automated verification expectation
```

لا تفرض framework أوpattern بدون approved constraint.

---

# 83. Supportability Requirement

Supportability may define:

```text
Issue correlation identifier
User-visible support reference
Diagnostic export
Safe impersonation prohibition or controlled support access
Operational runbook need
Status visibility
```

---

# 84. Observability Requirement

Observability requirement تحدد information and outcomes:

```text
What operational condition must be detectable?
Within what time?
With which correlation context?
Who receives the signal?
What privacy restrictions apply?
```

Tool selection is Architecture.

---

# 85. Compatibility Requirement

Compatibility scope may include:

```text
Browser families and supported versions
Operating systems
Assistive technologies
Device classes
Document readers
External protocol versions
Backward compatibility
```

Support matrix must have owner and update policy.

---

# 86. Data Requirements

`DR` تحدد business/system obligations المتعلقة بالمعلومات بدون تصميم physical schema.

DR may cover:

```text
Data meaning
Required attributes
Validation
Ownership
Source of truth
Classification
Quality
Lineage
Lifecycle
Retention
Deletion
Archival
Residency
Migration
Import/export semantics
Masking
Consent or lawful-use constraints
```

---

# 87. Data Requirement vs Data Model

Requirement:

```text
DR-CUS-004
The system SHALL retain the source and effective timestamp of every customer risk classification used in an approval decision.
```

Architecture/Data Design decides tables, columns, indexes, and storage technology.

---

# 88. Data Definition

كل critical data concept يحتاج canonical meaning.

Definition may link to:

```text
BUS-010 Business Information Model
Project Terminology
Business Rule
Product Information Object
```

Phase 04 لا تنشئ synonym مختلفًا لنفس concept بلا decision.

---

# 89. Required Data Attributes

Required attribute must have business/system rationale.

Avoid collecting data because:

```text
It may be useful later.
```

Data minimality is a requirement concern, especially for personal or regulated data.

---

# 90. Data Validation

Validation requirements may define:

```text
Presence
Format semantics
Range
Cross-field consistency
Reference validity
Uniqueness at business level
Effective-date validity
Source authority
Duplicate detection
```

UI presentation comes later.

---

# 91. Data Ownership and Source of Truth

For material data, identify:

```text
Business owner
System of record
Authoritative source
Allowed editor
Synchronization direction
Conflict authority
Correction route
```

---

# 92. Data Classification

Canonical project classification must be reused.

Examples:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
PERSONAL
SENSITIVE_PERSONAL
REGULATED
FINANCIAL
```

Actual allowed values come from Product OS policy/catalog.

---

# 93. Data Quality

Data quality requirements may address:

```text
Accuracy
Completeness
Timeliness
Consistency
Uniqueness
Validity
Lineage
Reconciliation
```

Each measure needs scope and owner.

---

# 94. Data Lifecycle

Lifecycle may include:

```text
Create
Activate
Correct
Supersede
Archive
Anonymize
Delete
Restore
Legal hold
```

Logical removal وphysical deletion لا يفترضان أنهما نفس الشيء.

---

# 95. Retention Requirement

Retention must identify:

```text
Record/data class
Start event
Retention duration or governing policy
Exceptions / legal hold
End-of-retention action
Owner
Evidence
```

`Retain according to law` وحدها غير قابلة للتنفيذ أوالتحقق.

---

# 96. Deletion Requirement

Deletion behavior may need:

```text
Eligibility
Authorization
Dependency checks
Soft/hard/anonymization disposition
Backup implications
Audit evidence
User notification
Exception handling
```

Mechanism التفصيلي يأتي في Architecture.

---

# 97. Data Residency

Data residency requirement تحدد:

```text
Applicable data classes
Allowed/prohibited geography
Processing vs storage distinction
Backup/replica scope
Third-party scope
Transfer approval/evidence
```

Cloud region selection يأتي لاحقًا.

---

# 98. Data Migration

Migration requirements may define:

```text
Source population
In-scope history
Mapping rules
Data cleansing authority
Reconciliation target
Rejected-record handling
Cutover constraints
Audit evidence
Rollback outcome
```

Migration tool and scripts are downstream.

---

# 99. Integration Requirements

`INT` تصف observable contract needs بين المنتج ونظام أوparty خارجي بدون اختيار implementation design.

INT may cover:

```text
Purpose
Participants
Direction
Trigger
Business information exchanged
Source of truth
Timing
Security obligation
Idempotency outcome
Ordering
Error handling
Retry eligibility
Reconciliation
Availability dependency
Version compatibility
Observability
Audit
```

---

# 100. Integration Context vs Integration Requirement

Phase 03:

```text
PINT-003 — Payment provider interaction
```

Phase 04:

```text
INT-PAY-001 — Submit an authorization request with the approved transaction identity.
INT-PAY-002 — Process confirmed, declined, and unknown authorization outcomes distinctly.
INT-PAY-003 — Reconcile transactions whose outcome remains unknown.
```

API paths and payload schemas come later.

---

# 101. Integration Boundary

Each integration must identify:

```text
Owning system
External party
Responsibility boundary
Authoritative data owner
Initiating side
Completion definition
Failure ownership
Support owner
```

---

# 102. Integration Timing

Use defined semantics:

```text
SYNCHRONOUS_OUTCOME_REQUIRED
ASYNCHRONOUS
BATCH
SCHEDULED
EVENT_DRIVEN
ON_DEMAND
NEAR_REAL_TIME with measure
```

`real-time` بدون measure ممنوعة.

---

# 103. Integration Idempotency

Requirement تحدد business outcome:

```text
Repeated delivery of the same approved transaction identifier SHALL NOT create more than one business transaction.
```

Architecture تحدد التقنية.

---

# 104. Integration Error Handling

Cover:

```text
Validation rejection
Authorization failure
Timeout
Rate limit
Partial response
Duplicate
Out-of-order event
Unavailable dependency
Unknown outcome
Schema/version incompatibility
```

كل error class يحتاج safe business disposition.

---

# 105. Integration Reconciliation

Material transaction integrations تحتاج تحديد:

```text
Reconciliation trigger
Compared identifiers and amounts/states
Mismatch handling
Authority for correction
Audit trail
Completion evidence
```

---

# 106. Third-Party User Journey

إذا المستخدم ينتقل إلى third party أوembedded component:

Requirements يجب أن تغطي حسب applicability:

```text
Responsibility continuity
Authentication/session boundary
Accessibility continuity
Language/direction continuity
Privacy notice/consent
Return and cancellation behavior
Failure/recovery
Support ownership
Audit/correlation
```

---

# 107. Security and Privacy Requirements

`SEC` تحدد security/privacy behavior والconstraints القابلة للتحقق.

Domains may include:

```text
Identity
Authentication
Authorization
Session
Credential and secret handling
Tenant/entity isolation
Sensitive-data protection
Privacy and consent
Abuse prevention
Security event handling
Secure recovery
Administrative access
Cryptographic outcome requirements
```

---

# 108. Security Requirement Sources

Sources include:

```text
Business Control
Risk Register
Product Policy
Data Classification
GOV-009
Organization Security Standard
Contract / Regulation
Threat or abuse analysis
```

Threat analysis may propose requirements but human authority approves risk treatment.

---

# 109. Authentication Requirements

May define:

```text
Eligible identities
Authentication strength
MFA activation conditions
Failed-attempt behavior
Account state behavior
Recovery
Reauthentication for sensitive action
Federation obligation
Accessible authentication
Audit
```

Protocol/provider choice is Architecture unless imposed.

---

# 110. Authorization Requirements

Authorization must derive from Business/Product roles and policies.

Define:

```text
Protected action/data
Required role/attribute/relationship
Scope boundary
Default-deny expectation
Delegation
Temporary access
Conflict/separation of duties
Revocation effect
Audit
```

UI hiding is not authorization.

---

# 111. Tenant and Entity Isolation

Multi-tenant/entity products need requirements for:

```text
Data access
Search
Export
Reporting
Configuration
Administration
Background processing
Integrations
Caching outcome
Logs/audit exposure
Support access
```

---

# 112. Session Requirements

May define:

```text
Idle timeout
Absolute lifetime
Revocation effect
Concurrent session policy
Sensitive-action reauthentication
Device/session visibility
Sign-out behavior
Compromise response
```

Values need risk/policy source.

---

# 113. Credential and Secret Handling

Requirements may prohibit:

```text
Plaintext storage
Exposure in logs
Exposure in URLs
Uncontrolled export
Reuse beyond policy
Long-lived embedded credentials
```

Secret-management product selection is Architecture.

---

# 114. Sensitive Data Protection

May specify:

```text
Protection in transit
Protection at rest
Masking in views
Export restrictions
Purpose limitation
Least-privilege access
Redaction in logs
Copy/download restrictions where justified
Retention/deletion linkage
```

Cryptographic algorithms may be imposed by standard but otherwise belong to Architecture.

---

# 115. Privacy Requirements

Privacy-related `SEC` or`DR` requirements may cover:

```text
Notice
Consent where applicable
Purpose
Data minimization
Access/correction request
Deletion request
Portability/export
Retention
Processing restriction
Third-party disclosure
Evidence of lawful action
```

Legal interpretation requires authorized privacy/compliance owner.

---

# 116. Abuse and Misuse Requirements

For high-risk journeys, consider:

```text
Enumeration resistance
Automated abuse controls
Transaction limits
Replay prevention
Duplicate action prevention
Escalation
User notification
Investigation evidence
```

Controls must be proportional and traceable to risk.

---

# 117. Secure Recovery

Account or transaction recovery requirements must prevent recovery path from weakening normal controls.

Cover:

```text
Identity verification outcome
Token/code lifetime
Single-use behavior
Attempt limits
Session revocation
Notification
Audit
Accessible completion
```

---

# 118. Security Logging Boundary

Security requirement may require events.

`AUD` requirement specifies audit record content and lifecycle when that is a distinct obligation.

Logs must not expose secrets or unnecessary sensitive data.

---

# 119. Accessibility Requirements

`ACC` تحول applicable accessibility obligations إلى atomic, testable system requirements.

Primary sources:

```text
GOV-009
Digital Accessibility Standard
WCAG baseline where adopted
Business accessibility requirements
Product accessibility capabilities and constraints
Platform/channel commitments
Critical journeys
Generated-document responsibilities
Third-party implications
```

---

# 120. Accessibility Scope

Coverage may include:

```text
Web
Mobile
Desktop
Kiosk
Generated documents
Emails/notifications
Authentication and recovery
Critical journeys
User-facing third parties
Admin experiences
Error/recovery states
RTL/LTR variants
```

---

# 121. Accessibility Requirement Derivation

Do not copy the entire standard into the SRS.

Create product-specific requirements linked to source criteria:

```text
STD criterion
    ↓
GOV-009 entry
    ↓
BREQ / PCAP / PCON
    ↓
ACC requirement
```

---

# 122. Keyboard Requirements

For keyboard-applicable surfaces, requirements may cover:

```text
Operability
Logical focus order
Visible focus
No keyboard trap
Activation behavior
Modal/focus containment
Escape/cancel behavior
Shortcut conflict
```

Exact component design comes later.

---

# 123. Assistive Technology Requirements

May cover:

```text
Programmatic name/role/value
State and status announcement
Relationship semantics
Heading/landmark structure responsibility
Table/list semantics
Dynamic update notification
Accessible help
```

---

# 124. Forms and Error Accessibility

Requirements may define:

```text
Programmatic labels
Instructions
Required-field identification
Error identification
Error association
Correction support
Preserved user input
Summary and focus behavior for critical forms
Status announcement
```

---

# 125. Visual Accessibility

May include measurable obligations for:

```text
Colour contrast
Non-colour identification
Text resizing
Zoom
Reflow
Spacing
Focus visibility
Motion reduction
Flashing limits
Touch target where platform guidance applies
```

Tokens and visual implementation belong to Phase 06.

---

# 126. Accessible Authentication

Authentication and recovery must not rely on inaccessible cognitive, sensory, or motor interaction without an accessible alternative consistent with the adopted baseline.

Security and accessibility requirements must be reviewed together; neither silently weakens the other.

---

# 127. Accessible Generated Documents

Document requirements may cover:

```text
Tagged structure
Reading order
Language metadata
Headings
Tables
Alternative text
Form fields
Colour/contrast
RTL/LTR
Accessible delivery alternative
Verification method
```

Applies only to in-scope document formats recorded in `GOV-009` and Product Baseline.

---

# 128. Third-Party Accessibility

Third-party component لا يعفي المنتج من responsibility.

Requirement must define:

```text
Applicable accessibility baseline
Evaluation evidence
Fallback or alternative
Known exception route
User support
Reopen condition on version/vendor change
```

---

# 129. Accessibility Acceptance

ACC verification may combine:

```text
Automated test
Keyboard inspection
Screen-reader test
Zoom/reflow inspection
Contrast measurement
Document inspection
User validation where risk requires
```

Automated testing وحده لا يثبت accessibility conformance.

---

# 130. Audit and Evidence Requirements

`AUD` تحدد ما يجب أن يثبت أن action أوdecision أوcontrol حدث بصورة موثوقة.

May cover:

```text
Business audit trail
Security events
Approval evidence
Configuration changes
Data lifecycle events
Administrative actions
Consent/notice evidence
Integration/reconciliation evidence
Release/operational evidence references
```

---

# 131. Audit Event Contract

Material audit event may require:

```text
Event identity
Actor identity and acting capacity
Timestamp and timezone semantics
Action
Target entity
Outcome
Reason where required
Policy/rule/version used
Before/after or changed fields where justified
Correlation identifier
Source channel/system
```

Avoid capturing sensitive values unnecessarily.

---

# 132. Actor and Acting Capacity

Audit must distinguish where relevant:

```text
Human user
Service identity
Delegated actor
Impersonated/support session
Automated job
External system
```

`Admin` alone may be insufficient.

---

# 133. Audit Integrity

Requirements may define outcomes such as:

```text
Unauthorized modification prevention
Deletion restriction
Completeness check
Ordering/time integrity
Access control
Export integrity
Retention
Tamper evidence
```

Storage mechanism belongs to Architecture.

---

# 134. Audit Access

Define:

```text
Eligible roles
Scope boundaries
Search/filter needs
Export constraints
Sensitive-data redaction
Purpose limitation
Audit of audit access where required
```

---

# 135. Evidence Obligation

Business `EVID-*` may derive into `AUD-*` or other requirement types.

Example:

```text
EVID-004 requires proof of consent version.
AUD-CONS-002 requires the system to retain consent version, subject, action, timestamp, channel, and withdrawal status.
```

---

# 136. Audit vs Operational Logs

Audit record:

```text
Supports accountability, control, investigation, or compliance evidence.
```

Operational log:

```text
Supports diagnosis and operation.
```

قد يتقاطعان، لكن لا يفترض أنهما نفس artifact أوretention/access policy.

---

# 137. Reporting Requirements

Reporting may create multiple requirement types:

```text
FR    Generate/view/filter/export behavior
DR    Information semantics and source
SEC   Access and privacy
ACC   Accessible output
AUD   Generation/export evidence
NFR   Performance/capacity
```

لا تجمع كلها في sentence واحدة.

---

# 138. Analytics Requirements

Define:

```text
Decision or outcome supported
Metric definition
Event/data source
Population and exclusions
Aggregation period
Freshness
Authorization
Privacy
Quality/reconciliation
```

Analytics tool is downstream.

---

# 139. AI-Enabled Product Requirements

If product includes AI behavior, requirements may need:

```text
User-visible purpose
Input boundaries
Human review or override
Confidence/uncertainty communication
Prohibited use
Fallback behavior
Data/privacy constraints
Auditability
Evaluation criteria
Bias/fairness obligations where applicable
Model or provider change reopen condition
```

"Use AI" ليست requirement.

---

# 140. Cross-Cutting Requirement Review

For every critical FR, review whether it needs linked:

```text
NFR
DR
INT
SEC
ACC
AUD
```

Not every FR needs all types.

لكن omission يجب أن يكون نتيجة review، لا نتيجة أن الفريق نسيها.

---

# 141. Acceptance Criteria

Acceptance Criteria تحدد observable conditions التي تثبت أن Requirement satisfied.

هي جزء من requirement contract وليست بعدthought للـQA.

---

# 142. Acceptance Criterion ID

Recommended:

```text
AC-<REQUIREMENT-ID>-<SEQUENCE>
```

Example:

```text
AC-FR-APR-014-01
```

---

# 143. Acceptance Criteria Quality

Acceptance criterion يجب أن تكون:

```text
Specific
Observable
Measurable where relevant
Traceable to one requirement
Free from hidden design assumptions
Inclusive of relevant failure/edge behavior
```

---

# 144. Given / When / Then

Useful for behavioral criteria:

```text
GIVEN a submitted request exceeds the active approval threshold
AND no authorized approval exists
WHEN completion is attempted
THEN the system prevents completion
AND preserves the request in PENDING_APPROVAL state.
```

ليست الصيغة الوحيدة المقبولة.

---

# 145. Rule-Based Acceptance

For tables, calculations, or state transitions, decision table or state matrix may be clearer than repeated Given/When/Then.

Criterion can reference a baselined rule table:

```text
AC-FR-APR-014-02 SHALL satisfy DT-APR-001 rows 1–8.
```

---

# 146. NFR Acceptance

NFR acceptance must define measurement contract:

```text
Metric
Target
Workload
Dataset
Environment class
Measurement window
Percentile/statistic
Allowed exclusions
Evidence
```

---

# 147. Security Acceptance

May use:

```text
Positive authorization tests
Negative authorization tests
Abuse-case tests
Configuration inspection
Security analysis
Penetration test where risk requires
Audit evidence inspection
```

Security acceptance لا تضع exploit details داخل public artifacts إذا كانت sensitive.

---

# 148. Accessibility Acceptance

May combine automated and manual methods according to platform and criterion.

Acceptance must identify adopted baseline, scope, assistive technologies or inspection method where applicable, and evidence owner.

---

# 149. Acceptance Criteria vs Test Case

Acceptance Criterion:

```text
Defines what outcome proves acceptance.
```

Test Case:

```text
Defines exact setup, steps, data, execution, and expected result.
```

Phase 04 defines criteria and verification intent. Detailed Test Cases belong to Verification workstream.

## Requirements Validation vs Solution Verification

```text
Requirement Validation
→ Did we specify the right obligation correctly?

Solution Verification
→ Did the implemented solution satisfy the baselined obligation?
```

Phase 04 owns requirement validation and verification intent.

Downstream verification planning/execution owns Test Cases andEvidence.

---

# 150. Verification Method

Each requirement selects one or more:

```text
TEST
INSPECTION
ANALYSIS
DEMONSTRATION
REVIEW
MEASUREMENT
AUDIT
```

Method must fit the requirement type and risk.

---

# 151. Verification Level

Possible levels:

```text
UNIT
COMPONENT
INTEGRATION
SYSTEM
END_TO_END
DOCUMENT
PROCESS
OPERATIONAL
UAT
INDEPENDENT_ASSESSMENT
```

Phase 04 identifies expected level; Phase 10 finalizes and executes the test strategy.

---

# 152. Evidence Expectation

Requirement may specify evidence class:

```text
Automated test result
Manual test record
Accessibility inspection
Security assessment
Performance report
Audit export
Configuration evidence
Architecture review
Approval record
User validation
```

Actual evidence IDs are added downstream.

---

# 153. Requirement Lifecycle

Canonical lifecycle:

```text
CAPTURED
PROPOSED
IN_ANALYSIS
IN_REVIEW
APPROVED
BASELINED
DEFERRED
REJECTED
SUPERSEDED
RETIRED
```

---

# 154. Lifecycle Transitions

```text
CAPTURED
   ↓
PROPOSED
   ↓
IN_ANALYSIS
   ↓
IN_REVIEW
   ↓
APPROVED
   ↓
BASELINED
```

Alternative dispositions:

```text
DEFERRED
REJECTED
SUPERSEDED
RETIRED
```

---

# 155. Approval Status vs Lifecycle

Approval may use:

```text
NOT_REQUIRED
PENDING
APPROVED
APPROVED_WITH_CONDITIONS
REJECTED
```

Lifecycle وapproval status منفصلان.

---

# 156. Verification Status

Verification status belongs downstream:

```text
NOT_PLANNED
PLANNED
READY
PASSED
FAILED
BLOCKED
WAIVED
```

Requirement قد تكون `BASELINED` وverification `NOT_PLANNED` في Phase 04.

---

# 157. Requirement Baseline

Baseline is a controlled set of approved requirements for a defined scope/release.

```text
REQUIREMENTS-BASELINE-1.0
```

Baseline records:

```text
Included requirement IDs and versions
Applicable product/release scope
Approval authority
Gate outcome
Conditions
Known deferred items
Source baseline versions
```

---

# 158. Requirement Version

Requirement content changes use explicit version history.

Minor editorial correction may not require full reapproval if meaning is unchanged, but history is retained.

Material change includes:

```text
Behavior
Scope
Measure
Acceptance
Priority/release commitment
Security/control strength
Applicability
```

---

# 159. Supersession

Old requirement remains visible:

```yaml
requirement_id: FR-014
status: SUPERSEDED
superseded_by:
  - FR-041
  - FR-042
```

Never recycle `FR-014` for unrelated behavior.

---

# 160. Deferred Requirement

Deferred means approved obligation not allocated to current baseline/release.

It needs:

```text
Reason
Authority
Target review/release
Risk impact
Dependencies
Standards/control impact
Reopen condition
```

Mandatory standard/control لا يؤجل بصمت بسبب MVP.

---

# 161. Rejected Requirement Candidate

Record:

```text
Candidate statement
Source
Reason rejected
Authority
Affected upstream objects
Whether product/business baseline needs review
```

Deletion hides decision history.

---

# 162. TBD and TBC

```text
TBD — Value/decision not yet determined
TBC — Candidate value requires confirmation
```

Every marker needs:

```text
ID
Owner
Impact
Blocking YES/NO
Due gate/date/event
Resolution route
```

Free-text `TBD` is invalid.

---

# 163. Requirement Priority

Priority dimensions are separated:

```text
Business Priority
Release Allocation
Criticality
Risk Priority
Dependency Order
```

One score must not hide all dimensions.

---

# 164. Business Priority

Product OS may use:

```text
MUST
SHOULD
COULD
WONT_NOW
```

`MUST` here is a prioritization value, while normative statements continue to use `SHALL`.

---

# 165. Must-Have Rule

A `MUST` requirement needs at least one:

```text
Critical business outcome
Mandatory product capability
Business rule/control
Security/privacy obligation
Applicable standard/profile
Legal/contractual obligation
Release integrity dependency
Unacceptable risk if absent
```

Stakeholder insistence alone is not rationale.

---

# 166. Criticality

Suggested:

```text
CRITICAL
HIGH
MEDIUM
LOW
```

Criticality drivers:

```text
Safety
Financial integrity
Security/privacy
Compliance
Core journey completion
Data integrity
Operational continuity
Irreversibility
```

---

# 167. Release Allocation

Requirement may be:

```text
RELEASE-1
RELEASE-2
FUTURE
UNALLOCATED
```

`UNALLOCATED` must be visible and owned before baseline.

---

# 168. MVP Integrity

MVP may reduce scope.

MVP must not remove quality/control obligations necessary for the included journeys.

Example:

```text
Remove advanced reporting scope       → possible
Remove authorization from included flow → not acceptable
```

---

# 169. Prioritization Conflict

If high priority conflicts with release capacity:

```text
Do not weaken the requirement silently.
Escalate scope/release decision.
Record risk and authority.
Update Product Baseline if needed.
```

---

# 170. Requirement Review Types

```text
CONTENT REVIEW
DOMAIN REVIEW
PRODUCT REVIEW
QUALITY REVIEW
FEASIBILITY REVIEW
SECURITY / PRIVACY REVIEW
ACCESSIBILITY REVIEW
DATA REVIEW
INTEGRATION REVIEW
TESTABILITY REVIEW
STANDARDS TRACEABILITY REVIEW
```

Not all requirements need every reviewer.

---

# 171. Content Review

Checks:

```text
Correct source interpretation
Clear behavior
Correct scope
No hidden assumption
Complete acceptance
No contradiction
```

---

# 172. Feasibility Review Boundary

Architects and engineers may state:

```text
Feasible
Feasible with constraint
Needs spike/evidence
Not feasible under current constraint
Creates material cost/risk
```

They may not rewrite product intent unilaterally.

---

# 173. Testability Review

QA/verification reviewer checks:

```text
Observable outcome
Acceptance coverage
Required fixtures/data
Environment dependency
Negative/edge conditions
Evidence method
Automation suitability
```

Test design feedback may reveal ambiguous requirement, but test case does not become canonical behavior source.

---

# 174. Review Disposition

```text
ACCEPT
ACCEPT_WITH_EDITS
NEEDS_CLARIFICATION
CONFLICT
UPSTREAM_GAP
SCOPE_CHANGE_CANDIDATE
REJECT
DEFER
```

---

# 175. Requirement Conflict

Conflict record needs:

```text
Requirements/sources involved
Conflict type
Impact
Options
Decision owner
Decision
Rationale
Affected artifacts
```

---

# 176. Conflict Types

```text
BEHAVIOR_CONFLICT
RULE_CONFLICT
SCOPE_CONFLICT
ROLE_CONFLICT
STATE_CONFLICT
DATA_CONFLICT
INTEGRATION_CONFLICT
QUALITY_CONFLICT
SECURITY_CONFLICT
ACCESSIBILITY_CONFLICT
PRIORITY_CONFLICT
STANDARD_CONFLICT
```

---

# 177. Duplicate Requirement

Duplicates may be:

```text
EXACT_DUPLICATE
SEMANTIC_DUPLICATE
OVERLAP
VALID_VARIANT
REFINEMENT
```

Merge preserves all source links and history.

---

# 178. Contradictory Standards

If two standards/profiles appear conflicting:

```text
Do not choose silently.
Link both GOV-009 entries.
Escalate to authorized standards/compliance owners.
Record interpretation/exception decision.
Mark affected requirements IN_REVIEW or BLOCKED.
```

---

# 179. SRS Purpose

`SRS` is the approved system requirements baseline view.

It answers:

```text
What system is in scope?
Which users and external actors interact with it?
What behavior must it provide?
What data/integration/security/accessibility/audit obligations apply?
What quality levels must it meet?
How is every requirement accepted and traced?
```

---

# 180. SRS Recommended Structure

```text
1. Document Control and Baseline
2. Purpose and Scope
3. Product/System Context
4. References and Source Baselines
5. Definitions and Terminology
6. Actors, Roles, Platforms, and Boundaries
7. Assumptions, Dependencies, and Constraints
8. Functional Requirements by Domain/Capability
9. State, Exception, and Recovery Requirements
10. Data Requirements
11. Integration Requirements
12. Non-Functional Requirements
13. Security and Privacy Requirements
14. Accessibility Requirements
15. Audit and Evidence Requirements
16. Localization and Generated-Document Requirements
17. Acceptance and Verification Matrix
18. Priority and Release Allocation
19. Standards and GOV-009 Derivation Coverage
20. Traceability Matrix
21. Open Issues and Approved Conditions
22. Approval and Change History
```

---

# 181. SRS Is a View over Canonical Objects

SRS may be one Markdown file or generated view.

Canonical requirement IDs remain stable whether content is stored in:

```text
One SRS
Type-specific catalogs
Domain files
Structured YAML/JSON
Requirements management tool
```

Packaging does not change semantics.

---

# 182. Requirements Engineering Workflow

```text
04.0 Confirm Entry Baselines
      ↓
04.1 Build Derivation Inventory
      ↓
04.2 Establish Requirement Structure and IDs
      ↓
04.3 Derive Functional Requirements
      ↓
04.4 Derive State / Exception / Recovery Requirements
      ↓
04.5 Derive Data Requirements
      ↓
04.6 Derive Integration Requirements
      ↓
04.7 Derive NFRs
      ↓
04.8 Derive Security / Privacy Requirements
      ↓
04.9 Derive Accessibility Requirements
      ↓
04.10 Derive Audit / Evidence Requirements
      ↓
04.11 Define Acceptance and Verification Intent
      ↓
04.12 Prioritize and Allocate Releases
      ↓
04.13 Resolve Conflicts / Gaps / Duplicates
      ↓
04.14 Validate Coverage and Traceability
      ↓
04.15 Review GOV-009 Derivation
      ↓
04.16 Baseline SRS
      ↓
04.17 Evaluate G3B
      ↓
04.18 Generate Downstream Handoff
```

---

# 183. Step 04.0 — Confirm Entry Baselines

Verify:

```text
G2 and G3A outcomes
Business/Product baseline versions
Scope and release boundary
Blocking decisions/questions
Standards applicability
Required source access
```

If sources conflict, do not begin mass requirement generation.

---

# 184. Step 04.1 — Derivation Inventory

Create inventory of upstream objects requiring disposition:

```text
BREQ
BR / BD / CTRL / POL
INFO / EVID
PCAP / PPOL / PCON / PSTATE
PINT / PDEP
FEAT
RELEASE
GOV-009 derivation obligation
Risk / Decision
```

Each receives:

```text
DERIVED
NO_SYSTEM_REQUIREMENT_NEEDED with rationale
PENDING
UPSTREAM_GAP
OUT_OF_SCOPE
```

## Requirements Clarification Methods

Phase 04 may use adaptive methods حسب uncertainty ونوع الـrequirement:

```text
Source and baseline analysis
Requirement workshop
Scenario walkthrough
Process and journey walkthrough
State-transition analysis
Decision table analysis
Exception and recovery analysis
Data/event analysis
Integration boundary workshop
NFR quantification workshop
Risk, threat, and abuse-case review
Accessibility requirement review
Prototype or existing-product observation
```

Prototype أوexisting behavior يعتبر evidence/input. لا يصبح canonical requirement لمجرد أنه مرسوم أوimplemented.

---

# 185. Step 04.2 — Requirement Structure

Decide:

```text
ID pattern
Domain grouping
Catalog packaging
Versioning
Owner model
Priority model
Traceability storage
Review routing
```

Project-specific structure must remain compatible with canonical types.

---

# 186. Step 04.3 — Functional Derivation

Start with capabilities/processes/states, not stakeholder feature lists.

For each capability:

```text
Happy path
Alternative paths
Exceptions
Rules
Controls
Data
Integrations
Notifications
Audit
Quality needs
```

---

# 187. Step 04.4 — State and Recovery Derivation

Review every critical state model for:

```text
Allowed transitions
Forbidden transitions
Transition authority
Side effects
Concurrency/conflict
Timeout/expiry
Correction/reversal
Recovery
Audit
```

---

# 188. Step 04.5 — Data Derivation

Derive from business information, product information objects, processes, controls, privacy/security obligations, integrations, reporting, and retention.

Do not begin with database tables.

---

# 189. Step 04.6 — Integration Derivation

For every `PINT`/external dependency, specify observable exchange and failure/reconciliation obligations.

Do not create endpoint or schema contracts yet.

---

# 190. Step 04.7 — NFR Derivation

Use:

```text
Critical journeys
Usage/capacity evidence
Business operating windows
Risk class
Platform commitments
Integration constraints
Recovery expectations
Support model
Applicable standards
```

Do not copy generic production NFR lists with invented numbers.

---

# 191. Step 04.8 — Security and Privacy Derivation

Review every critical actor/action/data/journey/integration against security controls, risks, data classifications, and `GOV-009`.

Security review is mandatory when applicability or risk indicates it, regardless of P-profile.

---

# 192. Step 04.9 — Accessibility Derivation

Translate the approved accessibility product baseline into requirements by platform, journey, state, document, and third party.

Do not defer atomic accessibility requirements to Design orQA.

---

# 193. Step 04.10 — Audit and Evidence Derivation

Map:

```text
Business Controls
Business Evidence Obligations
Approvals/Decisions
Security Events
Sensitive Data Actions
Configuration Changes
Integration/Reconciliation
Standards Evidence Needs
```

to `AUD-*` and linked requirements.

---

# 194. Step 04.11 — Acceptance and Verification

For every candidate baseline requirement:

```text
Define acceptance criteria
Select verification method
Identify verification level
Identify evidence expectation
Check edge/negative conditions
Confirm measurable parameters and sources
```

---

# 195. Step 04.12 — Priority and Release

Confirm alignment with `PROD-011`.

If requirement is necessary for integrity of an included capability but release excludes it:

```text
RELEASE_INTEGRITY_CONFLICT
```

must be resolved before baseline.

---

# 196. Step 04.13 — Conflict and Gap Resolution

Resolve or route:

```text
Contradictory sources
Duplicate requirements
Missing business rule
Missing product responsibility
Undefined data ownership
Undefined external ownership
Unmeasurable NFR
Unverifiable standard obligation
Unknown release allocation
```

---

# 197. Step 04.14 — Coverage and Traceability

Run bidirectional checks:

```text
Every upstream obligation has disposition.
Every requirement has upstream justification.
Every requirement has acceptance and downstream verification expectation.
Every critical journey/capability/state has requirement coverage.
Every applicable GOV-009 derivation obligation has requirement IDs.
```

---

# 198. Step 04.15 — GOV-009 Requirements Derivation Review

For each applicable entry:

```text
Confirm required types from Phase 03.
Create or link atomic requirements.
Preserve source criterion/clause references.
Confirm scope by platform/market/language/journey/document/third party.
Define acceptance and verification expectations.
Record derived requirement IDs in GOV-009.
Record approved no-requirement rationale if relevant.
Confirm downstream owners and reopen conditions.
```

---

# 199. Standards Derivation Blocking Rule

Before `G3B = PASS`:

```text
Blocking GOV-009 requirement-derivation gaps = 0
Applicable obligation without requirement or approved rationale = 0
Standards-derived requirement without source lineage = 0
```

`PENDING` may produce `PASS_WITH_CONDITIONS` only when non-blocking, owned, time-bound, and safe for downstream work.

---

# 200. Step 04.16 — Baseline SRS

Baseline only requirements that are:

```text
Approved
Atomic enough
Traceable
Testable
Prioritized/allocated
Free of blocking conflict
Consistent with Product Baseline and GOV-009
```

---

# 201. Step 04.17 — Evaluate G3B

G3B is evaluated against logical completeness, not document length.

---

# 202. Step 04.18 — Downstream Handoff

Handoff identifies what each downstream phase receives and must decide.

Requirements remain canonical; downstream artifacts refine them without silently changing intent.

---

# 203. Requirements Engineering Artifacts

Canonical artifact catalog:

```text
REQ-001 System Requirements Specification
REQ-002 Requirement Catalog and Index
REQ-003 Functional Requirement Catalog
REQ-004 Non-Functional Requirement Catalog
REQ-005 Data Requirement Catalog
REQ-006 Integration Requirement Catalog
REQ-007 Security and Privacy Requirement Catalog
REQ-008 Accessibility Requirement Catalog
REQ-009 Audit and Evidence Requirement Catalog
REQ-010 Acceptance and Verification Matrix
REQ-011 Requirements Traceability Matrix
REQ-012 Requirements Issue and Conflict Record
REQ-013 Requirements Validation Record
REQ-014 Requirements Handoff
```

Logical artifacts are mandatory according to applicability; physical files depend on P-profile.

---

# 204. REQ-001 — System Requirements Specification

Human-readable approved baseline view covering the applicable requirement families and context.

---

# 205. REQ-002 — Requirement Catalog and Index

Machine/human-readable index of all requirement IDs, types, statuses, owners, releases, and links.

---

# 206. REQ-003 — Functional Requirement Catalog

Functional behavior organized by product domain/capability, including state, exception, and recovery relationships.

---

# 207. REQ-004 — Non-Functional Requirement Catalog

Measurable quality requirements and their verification profiles.

---

# 208. REQ-005 — Data Requirement Catalog

Data semantics, quality, lifecycle, ownership, classification, retention, residency, migration, and privacy-related data obligations.

---

# 209. REQ-006 — Integration Requirement Catalog

External interaction outcomes, boundaries, timing, failures, reconciliation, security, and observability obligations.

---

# 210. REQ-007 — Security and Privacy Requirement Catalog

Identity, access, session, isolation, protection, privacy, abuse prevention, secure recovery, and security-event obligations.

---

# 211. REQ-008 — Accessibility Requirement Catalog

Platform/journey/document/third-party accessibility requirements linked to adopted standards and `GOV-009`.

---

# 212. REQ-009 — Audit and Evidence Requirement Catalog

Audit events, accountability information, evidence retention/access, and control-proof obligations.

---

# 213. REQ-010 — Acceptance and Verification Matrix

Maps:

```text
Requirement
→ Acceptance Criteria
→ Verification Method
→ Verification Level
→ Evidence Expectation
→ Downstream Test/Evidence IDs when created
```

---

# 214. REQ-011 — Requirements Traceability Matrix

Bidirectional map across sources, business/product objects, requirements, downstream specifications, tests, and evidence.

`REQ-011` is a requirements-focused view of canonical `GOV-008 Traceability Graph`.

---

# 215. REQ-012 — Requirements Issue and Conflict Record

Tracks:

```text
TBD/TBC
Conflicts
Duplicates
Upstream gaps
Feasibility concerns
Scope-change candidates
Unresolved applicability/derivation issues
```

Canonical decisions and questions remain linked to `GOV-003` and `GOV-006`.

---

# 216. REQ-013 — Requirements Validation Record

Records review coverage, participants, dispositions, conditions, unresolved non-blocking issues, and approval evidence.

---

# 217. REQ-014 — Requirements Handoff

Machine-oriented handoff to Experience, Design, Architecture, Engineering Readiness, andVerification.

---

# 218. Artifact Ownership Rule

Requirements are canonically owned by the requirement catalogs/baseline.

Do not maintain conflicting copies in:

```text
BRD
Product Definition
UX document
Architecture document
Backlog
Test plan
```

Downstream artifacts reference IDs and record refinements.

---

# 219. Governance Registers Updated

Phase 04 updates:

```text
GOV-003 Decision Log
GOV-004 Risk Register
GOV-005 Assumption Register
GOV-006 Open Question Register
GOV-007 Change Register
GOV-008 Traceability Graph
GOV-009 Standards & Compliance Applicability Matrix
```

Phase 04 adds to `GOV-009`:

```text
Derived FR/NFR/DR/INT/SEC/ACC/AUD IDs
Approved no-requirement rationale where applicable
Acceptance Criteria Links
Verification Methods and Evidence Expectations
Downstream Experience/Design/Architecture/Test Ownership
Requirement-Level Reopen Conditions
Requirements Baseline Version
G3B Status
```

---

# 220. Delivery Profile Principle

The project-selected Product OS profile controls depth and artifact packaging:

```text
P1 — Lean
P2 — Standard
P3 — Comprehensive
```

The same logical requirement contract applies to all profiles.

No profile may drop an applicable requirement family or mandatory obligation.

---

# 221. Domain-Level Depth Override

A project may use higher depth for one domain without changing the entire project profile.

Example:

```yaml
default_profile: P1

domain_depth_overrides:
  security: P3
  accessibility: P2
  payments: P3
```

This is a depth/packaging override، وليس profile naming system جديدًا.

---

# 222. P1 — Lean Behavior

P1 may use one composite:

```text
REQ-000 — Requirements Pack
```

containing:

```text
Scope and sources
Functional requirements
Applicable NFR/DR/INT/SEC/ACC/AUD requirements
Acceptance criteria
Priority/release
Traceability
Open issues
GOV-009 derivation coverage
G3B record
Handoff
```

P1 may group low-risk related requirements if they remain unambiguous and independently verifiable.

P1 does not permit generic `secure/accessibile/fast` statements or missing traceability.

---

# 223. P2 — Standard Behavior

Recommended independent artifacts:

```text
REQ-001 SRS
REQ-002 Requirement Catalog
REQ-003 Functional Requirements
REQ-004 NFRs
REQ-005 Data Requirements
REQ-006 Integration Requirements
REQ-007 Security and Privacy Requirements
REQ-008 Accessibility Requirements
REQ-009 Audit and Evidence Requirements
REQ-010 Acceptance and Verification Matrix
REQ-011 Traceability Matrix
REQ-013 Validation Record
REQ-014 Handoff
```

Inactive type catalogs are omitted with applicability rationale.

---

# 224. P3 — Comprehensive Behavior

P3 adds as applicable:

```text
Domain-level requirement files
Formal derivation records
Clause-level standards linkage
Formal decision tables/state matrices
Independent security/privacy/accessibility/data/integration reviews
Quantitative NFR verification profiles
Formal conflict and exception management
Versioned machine-readable requirement objects
Independent approvers
Full release-by-release baseline
Full traceability to design, architecture, tasks, tests, and evidence
Formal change impact analysis
```

---

# 225. Profile Escalation Triggers

A domain should consider deeper treatment when triggered by:

```text
Safety
Financial transaction
Regulated/sensitive data
High-impact automated decision
Multi-country operation
Enterprise contractual obligation
Complex integration
Offline/concurrency complexity
Generated legal/financial documents
Accessibility-critical journey
High availability/recovery need
Multiple delivery teams
```

---

# 225A. Requirements Behavior by Product State

Phase 04 adapts its analysis to the Product State دون تغيير requirement quality contract.

## S0 — Early Idea

Phase 04 may not activate yet. If it does, it baselines only the smallest validated system behavior needed for an approved experiment or release, with assumptions visible.

## S1 — New Product

Derive target requirements from approved business/product baselines. No current-system behavior is assumed.

## S2 — Business Transformation

Focus on target processes, roles, controls, decisions, information, exceptions, operational continuity, and migration from manual/existing work.

## S3 — Existing Product

Use a delta model:

```text
CURRENT OBSERVED BEHAVIOR
        ↓ compare
APPROVED CURRENT REQUIREMENT BASELINE where available
        ↓
TARGET REQUIREMENT
        ↓
KEEP / CHANGE / ADD / RETIRE / UNKNOWN
```

Running code or screen behavior is evidence, not automatic product intent.

## S4 — Implementation in Progress

Reconcile approved requirements, design, architecture, backlog, code, configuration, and tests. Record divergence rather than rewriting requirements to match implementation silently.

## S5 — Recovery

Immediate safety, containment, data integrity, security, continuity, and recovery requirements may be baselined first. Full normal specification may follow after stabilization.

## S6 — Evolution

Use delta requirements and formal impact analysis. Unaffected baselined requirements remain active; changed scope receives new versions and downstream review.

---

# 226. Requirements Validation

Validation asks:

> **If implemented exactly as written, will this baseline satisfy the approved business and product responsibilities safely and completely?**

Validation is not grammar review.

---

# 227. Validation Subjects

Review at least:

```text
Scope coverage
Capability coverage
User/role coverage
Process/journey coverage
State and exception coverage
Data coverage
Integration coverage
NFR coverage
Security/privacy coverage
Accessibility coverage
Audit/evidence coverage
Standards derivation coverage
Acceptance/testability
Priority/release integrity
Traceability
Change governance
```

---

# 228. Coverage Matrix

Suggested logical matrix:

| Upstream Object | Disposition | Derived Requirements | Release | Coverage Status |
|---|---|---|---|---|
| `PCAP-001` | `DERIVED` | `FR-001`, `FR-002`, `NFR-001` | `R1` | `COVERED` |
| `BR-004` | `DERIVED` | `FR-008`, `AUD-003` | `R1` | `COVERED` |
| `GOV-009-ENTRY-A11Y` | `DERIVED` | `ACC-001`–`ACC-012` | `R1` | `COVERED` |

---

# 229. Coverage Status

```text
NOT_REVIEWED
PARTIAL
COVERED
COVERED_WITH_CONDITION
NO_SYSTEM_REQUIREMENT_NEEDED
OUT_OF_SCOPE
BLOCKED
```

`NO_SYSTEM_REQUIREMENT_NEEDED` requires rationale and approval when upstream expects derivation.

---

# 230. Critical Journey Coverage

Every critical journey must cover as applicable:

```text
Entry
Happy path
Alternative path
Error/recovery
Authorization
Data
Integration
Performance/reliability
Accessibility
Audit
Exit/outcome
```

This is logical coverage before detailed Experience Architecture.

---

# 231. Role and Permission Coverage

For each protected capability/action:

```text
Who may initiate?
Who may view?
Who may change?
Who may approve?
Who may reverse/correct?
What scope applies?
What separation/delegation constraints apply?
What is audited?
```

Detailed authorization model may be Phase 07 artifact, but required behavior belongs here.

---

# 232. State Coverage

Every critical state should have disposition for:

```text
Creation
Entry
Exit
Allowed transitions
Invalid transition
Expiry
Cancellation
Correction/reversal
Archive/delete
Audit
```

---

# 233. Error and Recovery Coverage

Every critical behavior/integration must identify material error classes and safe recovery outcome.

Generic:

```text
Show an error message.
```

is not sufficient.

---

# 234. Data Coverage

For each critical information object:

```text
Meaning
Required data
Owner/source of truth
Validation
Classification
Access
Lifecycle
Retention/deletion
Audit
Integration/migration
```

only where applicable.

---

# 235. Standards Coverage

`GOV-009` coverage matrix must show:

```text
Applicable Entry
Business Links
Product Links
Required Requirement Types
Derived Requirement IDs
Acceptance/Verification Links
Downstream Owners
Coverage Status
```

---

# 236. Orphan Requirement

Requirement with no upstream justification:

```text
ORPHAN_REQUIREMENT
```

Disposition:

```text
Link valid source
Escalate upstream gap/change
Reject
```

It cannot be baselined because it seems useful.

---

# 237. Orphan Upstream Obligation

Business/product/standard obligation with no system disposition:

```text
UNREALIZED_OBLIGATION
```

It requires requirement IDs or approved no-system-requirement rationale.

---

# 238. Unaccepted Requirement

Requirement without acceptance criteria or verification method:

```text
UNVERIFIABLE_REQUIREMENT
```

It blocks G3B if material.

---

# 239. Hidden Design Constraint

Requirement that specifies technology without authoritative constraint:

```text
ARCHITECTURE_LEAKAGE
```

Route to:

```text
Restate observable need
or
Record imposed constraint with source
```

---

# 240. Requirement Readiness Status

```text
DRAFT
NEEDS_SOURCE
NEEDS_CLARIFICATION
NEEDS_FEASIBILITY
NEEDS_ACCEPTANCE
READY_FOR_REVIEW
APPROVED
BASELINED
BLOCKED
```

Readiness status may be derived from field completeness and validation.

---

# 241. G3B — Requirements Baseline Gate

Purpose:

> Determine whether the system requirements are complete, coherent, traceable, testable, and approved enough for Experience Architecture, Product Design, Solution Architecture, Engineering Readiness, andVerification to proceed without inventing system behavior or quality obligations.

---

# 242. G3B Required Checks

G3B evaluates the following checks at the selected P-profile depth.

---

# 243. G3B-01 Baseline Scope

SRS scope, product boundary, release scope, and source baseline versions are explicit and consistent with G3A.

---

# 244. G3B-02 Upstream Derivation Coverage

Business requirements/rules/controls and product capabilities/policies/states/integrations have system disposition.

---

# 245. G3B-03 Requirement Quality

Baselined requirements are sufficiently atomic, unambiguous, consistent, feasible, and implementation-independent.

---

# 246. G3B-04 Functional Coverage

Critical capabilities, processes, states, journeys, decisions, rules, controls, exceptions, and recovery behaviors have functional coverage.

---

# 247. G3B-05 Non-Functional Coverage

Applicable quality attributes have measurable requirements with defined scope and verification intent.

---

# 248. G3B-06 Data Coverage

Critical data semantics, ownership, quality, classification, lifecycle, retention, residency, migration, and privacy obligations are covered where applicable.

---

# 249. G3B-07 Integration Coverage

Every in-scope product integration has behavior, boundary, error, recovery/reconciliation, security, and observable outcome requirements as applicable.

---

# 250. G3B-08 Security and Privacy Coverage

Critical users/actions/data/journeys/integrations have traceable security/privacy requirements and no unresolved blocking risk-treatment gap.

---

# 251. G3B-09 Accessibility Coverage

Applicable platforms, journeys, states, documents, languages/directions, and third parties have atomic `ACC` requirements linked to the adopted baseline.

---

# 252. G3B-10 Audit and Evidence Coverage

Critical controls, decisions, approvals, administrative actions, sensitive events, and evidence obligations have `AUD` or linked requirement coverage.

---

# 253. G3B-11 Acceptance and Testability

Every baselined Requirement has acceptance criteria, verification method, and expected verification level/evidence class.

---

# 254. G3B-12 Traceability

Bidirectional upstream/downstream traceability is complete enough to detect orphans and impact.

---

# 255. G3B-13 Priority and Release Integrity

Requirement priority, criticality, and release allocation are explicit and consistent with MVP/release integrity.

---

# 256. G3B-14 Dependencies and Feasibility

Blocking dependencies and feasibility concerns are resolved or governed as non-blocking conditions.

---

# 257. G3B-15 Conflict and Duplicate Control

No unresolved material requirement conflict, semantic duplicate, or contradictory source interpretation remains.

---

# 258. G3B-16 Open Questions and Decisions

```text
Blocking Requirement Questions = 0
Blocking Requirement Decisions = 0
```

---

# 259. G3B-17 Standards Derivation Coverage

G3B verifies:

```text
Every applicable GOV-009 entry has required-type disposition.
Every required FR/NFR/DR/INT/SEC/ACC/AUD obligation has derived requirement IDs or approved rationale.
Requirement scope matches approved platforms, markets, languages, journeys, documents, third parties, and release boundaries.
Source criteria/clauses remain traceable.
Acceptance and verification expectations exist.
GOV-009 contains derived IDs, owners, status, and reopen conditions.
No applicable standard is represented only by a generic compliance statement.
Blocking derivation gaps equal zero.
```

---

# 260. G3B-18 Downstream Readiness

Experience, Design, Architecture, Engineering Readiness, andVerification can identify their obligations and inputs without reinterpreting requirement intent.

---

# 261. G3B-19 Change Governance

Baseline version, owners, approval, change route, and impact rules are explicit.

---

# 262. G3B Outcomes

```text
PASS
PASS_WITH_CONDITIONS
HOLD
REJECT
```

---

# 263. G3B PASS

Requirements Baseline is usable and no blocking gap remains.

---

# 264. G3B PASS_WITH_CONDITIONS

Allowed when unresolved items are:

```text
Non-blocking
Explicit
Owned
Time-bound
Limited in downstream impact
Not weakening mandatory scope/control/standard
```

Example:

```text
Final performance target for a future-release analytics workload remains due before Phase 08 and does not affect Release 1 architecture decisions.
```

---

# 265. G3B HOLD

Examples:

```text
Critical product capability has no functional behavior baseline.
Authorization responsibility remains contradictory.
Payment unknown-outcome recovery is undefined.
Required accessibility scope has generic wording only.
Critical NFR has no measurable target or source.
GOV-009 contains a blocking derivation gap.
Release scope excludes a mandatory control for an included journey.
```

---

# 266. G3B REJECT

Used when:

```text
Approved Product Baseline has been withdrawn.
Initiative is cancelled or split.
System responsibility is transferred outside this product.
Upstream rebaseline makes this requirements scope invalid.
```

`REJECT` is not a quality score for a draft.

---

# 267. G3B Evidence Record

```yaml
gate_id: G3B

outcome: PASS_WITH_CONDITIONS

baseline:
  id: REQUIREMENTS-BASELINE-1.0
  artifact: REQ-001
  product_baseline: PRODUCT-BASELINE-1.0

checks:
  scope: PASS
  upstream_derivation: PASS
  requirement_quality: PASS
  functional_coverage: PASS
  nfr_coverage: PASS
  data_coverage: PASS
  integration_coverage: PASS
  security_privacy_coverage: PASS
  accessibility_coverage: PASS
  audit_evidence_coverage: PASS
  acceptance_testability: PASS
  traceability: PASS
  priority_release_integrity: PASS
  feasibility: PASS
  conflicts_duplicates: PASS
  blocking_questions: PASS
  standards_derivation: PASS
  downstream_readiness: PASS
  change_governance: PASS

conditions:
  - id: COND-G3B-001
    statement: "Future-release analytics capacity target remains unallocated."
    owner: PRODUCT_OWNER
    due_phase: PHASE-08
    affected_release: FUTURE

evidence:
  - REQ-001
  - REQ-010
  - REQ-011
  - REQ-013
  - GOV-008
  - GOV-009

approved_by:
  - PRODUCT_OWNER
  - BUSINESS_AUTHORITY
  - REQUIREMENTS_LEAD
```

---

# 268. Phase Handoff Contract

Phase 04 handoff must provide:

```text
Requirements Baseline ID and Version
System/Product Scope and Release Scope
Source Baseline Versions
Actors and Product Roles
Functional Requirements
State / Exception / Error / Recovery Requirements
Non-Functional Requirements
Data Requirements
Integration Requirements
Security and Privacy Requirements
Accessibility Requirements
Audit and Evidence Requirements
Localization and Generated-Document Requirements
Acceptance Criteria
Verification Methods and Evidence Expectations
Priority / Criticality / Release Allocation
Requirement Dependencies
Assumptions and Risks
Approved Conditions
Open Non-Blocking Questions
GOV-009 Derived Requirement IDs and Coverage
Traceability Graph / Matrix
Downstream Allocation
G3B Outcome
Change and Reopen Rules
```

---

# 269. Machine-Readable Handoff — Conceptual

```yaml
phase_handoff:

  from_phase: PHASE-04

  requirements_baseline:
    id: REQUIREMENTS-BASELINE-1.0
    status: APPROVED
    srs: REQ-001
    product_baseline: PRODUCT-BASELINE-1.0

  scope:
    product: PROD-002
    releases:
      - RELEASE-1

  catalogs:
    index: REQ-002
    functional: REQ-003
    non_functional: REQ-004
    data: REQ-005
    integrations: REQ-006
    security_privacy: REQ-007
    accessibility: REQ-008
    audit_evidence: REQ-009

  acceptance:
    matrix: REQ-010
    blocking_gaps: 0

  traceability:
    matrix: REQ-011
    graph: GOV-008
    upstream_orphans: 0
    requirement_orphans: 0

  standards:
    applicability_matrix: GOV-009
    derivation_status: COMPLETE
    applicable_entries:
      - GOV-009-ENTRY-A11Y
    derived_requirements:
      - ACC-NAV-001
      - ACC-FORM-001
      - SEC-AUTH-001
      - DR-DOC-001
    blocking_gaps: 0

  downstream_allocation:
    experience:
      required: true
      requirement_ids:
        - FR-AUTH-001
        - ACC-NAV-001
    design:
      required: true
      requirement_ids:
        - ACC-VIS-001
    architecture:
      required: true
      requirement_ids:
        - NFR-PERF-001
        - SEC-SESS-001
        - INT-PAY-001
    verification:
      required: true
      acceptance_matrix: REQ-010

  conditions:
    - COND-G3B-001

  open_questions:
    blocking: []
    downstream:
      - OQ-REQ-019

  gate:
    id: G3B
    outcome: PASS_WITH_CONDITIONS

  next_route:
    phase: PHASE-05
    mode: EXPERIENCE_ARCHITECTURE
```

هذا schema conceptual. الـmachine-readable schema النهائي يثبت في schema workstream مع الحفاظ على هذا logical contract.

---

# 270. Downstream Allocation Principle

Requirement may feed multiple downstream artifacts.

```text
One canonical requirement
       ├── Experience implication
       ├── Design implication
       ├── Architecture implication
       ├── Engineering implication
       └── Verification implication
```

Downstream ownership does not create requirement copies.

---

# 271. Phase 05 — Experience Architecture Handoff

Phase 05 primarily receives requirements affecting:

```text
Actors and goals
Journeys and scenarios
Workflow sequence
States
Permissions visible in experience
Information needs
Errors and recovery
Notifications
Accessibility interaction
Localization / RTL
Cross-channel continuity
```

Phase 05 may refine interaction behavior butcannot change business/product/system obligation silently.

---

# 272. Phase 06 — Product Design Handoff

Phase 06 receives requirements affecting:

```text
Visual states
Components
Content presentation
Responsive behavior
Contrast/focus/touch/reflow
Generated documents
Design-system coverage
Error/empty/loading states
```

---

# 273. Phase 07 — Solution Architecture Handoff

Phase 07 receives all relevant requirements, especially:

```text
NFR
DR
INT
SEC
AUD
Cross-cutting ACC technical implications
State integrity
Concurrency
External ownership
Recovery
Observability
```

Architecture records how the requirements will be realized through ADRs and technical specifications.

---

# 274. Phase 08 — Engineering Readiness Handoff

Phase 08 checks that requirements have adequate:

```text
Experience/design coverage
Architecture coverage
Acceptance coverage
Traceability
Dependencies
Owners
Release allocation
No unresolved blocking change
```

---

# 275. Phase 10 — Verification Handoff

Phase 10 receives:

```text
Requirement IDs and versions
Acceptance criteria
Verification methods/levels
Evidence expectations
Risk/criticality
Standards source links
Approved exceptions/conditions
```

Then adds Test Case andEvidence IDs.

---

# 276. Canonical Traceability Graph

```text
SOURCE
  ↓
PRB / OUT / OBJ
  ↓
BREQ / BR / BD / CTRL / POL / INFO / EVID
  ↓
PCAP / PCON / PPOL / PSTATE / PINT / FEAT / RELEASE
  ↓
FR / NFR / DR / INT / SEC / ACC / AUD
  ↓
ACCEPTANCE CRITERIA
  ↓
EXP / DES / ARCH
  ↓
TASK / CODE / CONFIG
  ↓
TEST CASE
  ↓
EVIDENCE
  ↓
RELEASE GATE
```

---

# 277. Standards Traceability Graph

```text
STD / PROFILE / CLAUSE
          ↓
        GOV-009
          ↓
BREQ / BR / CTRL / POL / INFO / EVID
          ↓
PCAP / PCON / PPOL / PLATFORM / JOURNEY / DOCUMENT / THIRD PARTY
          ↓
FR / NFR / DR / INT / SEC / ACC / AUD
          ↓
ACCEPTANCE / VERIFICATION EXPECTATION
          ↓
EXP / DES / ARCH / TASK / TEST / EVIDENCE / RELEASE
```

---

# 278. Mandatory Upstream Links

Minimum rules:

```text
FR  → PCAP/FEAT/PSTATE/BR/PROCESS or approved source
NFR → Product constraint/risk/KPI/standard/critical journey
DR  → INFO/Product Information/Data policy/control/standard
INT → PINT/PDEP/process/data ownership
SEC → CTRL/risk/PPOL/data classification/standard
ACC → GOV-009/product accessibility implication/platform/journey/document
AUD → CTRL/EVID/decision/security event/standard
```

---

# 279. Mandatory Downstream Links

At Phase 04, expected downstream classes must be recorded.

After later phases:

```text
Requirement → Experience/Design/Architecture where applicable
Requirement → Test Case
Requirement → Evidence
Requirement → Release
```

No requirement may become `VERIFIED` without evidence linkage.

---

# 280. Bidirectional Traceability

System must answer both:

```text
Why does this requirement exist?
```

and:

```text
Where was this upstream obligation realized and verified?
```

---

# 281. Traceability Granularity

Use requirement-level links by default.

Grouped links are allowed in P1 only when:

```text
Meaning remains unambiguous
Impact analysis remains reliable
Risk is low
No clause/control-level evidence is required
```

---

# 282. Change Propagation

Example:

```text
BR-014 threshold semantics change
        ↓
FR-APR-014 → REVIEW_REQUIRED
AUD-APR-002 → REVIEW_REQUIRED
Acceptance Criteria → REVIEW_REQUIRED
Experience / Architecture / Tests → IMPACT_REVIEW
Release Baseline → IMPACT_REVIEW
```

---

# 283. Standards Change Propagation

```text
Standard version or activation trigger changes
        ↓
GOV-009 → REOPENED
        ↓
Business/Product implications reviewed
        ↓
Derived requirements → REVIEW_REQUIRED
        ↓
Downstream artifacts/tests/evidence → IMPACT_REVIEW
```

---

# 284. Requirements Change Request

Change request records:

```text
Requested change
Reason/source
Affected requirement IDs
Change type
Business/product impact
Standards impact
Security/privacy/accessibility impact
Release impact
Downstream artifacts
Decision authority
Approval
Baseline version outcome
```

---

# 285. Change Types

```text
EDITORIAL
CLARIFICATION
BEHAVIOR_CHANGE
QUALITY_TARGET_CHANGE
SCOPE_CHANGE
PRIORITY_CHANGE
RELEASE_CHANGE
APPLICABILITY_CHANGE
SOURCE_CHANGE
DELETION / RETIREMENT
```

---

# 286. Baseline Impact Rule

After G3B:

```text
No material requirement change without GOV-007 Change Record and impact analysis.
```

If business/product responsibility changes, Phase 02 or03 must be reopened before requirement rebaseline.

## Requirement Exception or Waiver

An exception does not delete or weaken the canonical requirement.

It records:

```text
Requirement ID and version
Exact affected scope
Reason
Risk and impact
Compensating control where applicable
Decision owner and approval
Start and expiry/review condition
Evidence
Downstream release/operations visibility
```

Expired or triggered exceptions become `REVIEW_REQUIRED`.

---

# 287. Reopening Phase 04

Triggers include:

```text
Business rule/control change
Product scope/boundary/capability change
New user/role
New platform/channel
New market/language/direction
New data classification or regulated data
New payment or high-risk capability
New generated document
New user-facing third party
Integration contract responsibility change
NFR target change
Security/privacy/accessibility standard change
GOV-009 applicability change
Release boundary change
Defect reveals requirement ambiguity/gap
Architecture feasibility invalidates an assumption
Test evidence contradicts acceptance semantics
```

---

# 288. Reopen States

```text
REQUIREMENT_REVIEW_REQUIRED
PARTIAL_REQUIREMENTS_REBASELINE
FULL_REQUIREMENTS_REBASELINE
```

---

# 289. AI Responsibilities

AI MAY:

- parse approved business/product artifacts;
- build derivation inventories;
- propose atomic requirement statements;
- classify requirement type and tags;
- detect ambiguity;
- detect compound requirements;
- detect duplicates and overlap;
- detect conflicts across sources;
- propose acceptance criteria;
- propose verification methods;
- identify edge/error/recovery gaps;
- map states and transitions;
- propose cross-cutting requirement coverage;
- analyze NFR measurability;
- identify missing source or owner;
- build traceability;
- detect orphan requirements and upstream obligations;
- analyze `GOV-009` derivation obligations;
- propose `FR/NFR/DR/INT/SEC/ACC/AUD` requirements linked to standards;
- identify requirement changes that reopen business/product/applicability decisions;
- generate SRS, catalogs, matrices, and handoff drafts.

---

# 290. AI Must Label

AI-generated content uses status such as:

```text
PROPOSED
INFERRED
SUPPORTED
VALIDATED
APPROVED
```

AI cannot label its own proposal `APPROVED`.

---

# 291. AI Prohibitions

AI MUST NOT:

- invent product scope or behavior;
- invent business rule or control;
- invent performance/capacity numbers;
- invent legal or regulatory interpretation;
- invent standards applicability;
- mark a `GOV-009` entry `NOT_APPLICABLE` without authorized evidence;
- convert a feature candidate directly into approved requirements;
- promote an inference to fact;
- hide unknowns in generic wording;
- choose architecture, vendor, framework, protocol, database, or cloud without authoritative constraint;
- remove security/accessibility/audit/data obligations to simplify MVP;
- copy standards wholesale as a competing canonical specification;
- write `secure`, `accessible`, `scalable`, or`user-friendly` as sufficient requirement;
- resolve stakeholder/source conflict silently;
- approve requirements;
- close G3B without required evidence;
- claim testability when acceptance criteria are absent;
- generate fake traceability links;
- delete superseded requirement history.

---

# 292. Human Responsibilities

Humans remain responsible for:

```text
Business intent confirmation
Product scope and priority
Domain correctness
Rule/control interpretation
Risk acceptance
Security/privacy interpretation
Accessibility baseline interpretation
Standards/compliance applicability and exceptions
Feasibility commitment
Requirement approval
Release commitment
Conflict resolution
G3B approval
```

---

# 293. Requirements Lead Responsibility

Responsible for:

```text
Requirement model integrity
Derivation discipline
Writing quality
Atomicity
Consistency
Acceptance completeness
Traceability
Baseline/version control
Review orchestration
G3B evidence
```

---

# 294. Product Owner Responsibility

Confirms:

```text
Product intent
Scope
Capability/feature interpretation
Priority
Release allocation
Acceptance relevance
Product-level tradeoffs
```

---

# 295. Business Authority Responsibility

Confirms:

```text
Business requirement/rule/control meaning
Operational correctness
Outcome integrity
Exception legitimacy
Business acceptance
```

---

# 296. Domain Owner Responsibility

Confirms:

```text
Terminology
Process reality
State/exception behavior
Data meaning
Operational constraints
```

---

# 297. UX Lead Responsibility

During Phase 04, UX Lead reviews:

```text
User/actor clarity
Journey plausibility
Error/recovery completeness
Information needs
Accessibility interaction implications
Cross-channel contradictions
```

without designing screens as requirements.

---

# 298. Solution Architect Responsibility

During Phase 04, Architect reviews:

```text
Feasibility
System boundary
Quality measurability
Integration responsibility
Data/security/recovery implications
Architecture-driving requirements
```

without weakening approved behavior fortechnical convenience.

---

# 299. Security / Privacy / Compliance Responsibility

Authorized reviewers confirm:

```text
Risk/control coverage
Data protection obligations
Identity/access expectations
Applicable standards/profiles
Exceptions/waivers
Evidence expectations
```

---

# 300. Accessibility Reviewer Responsibility

Confirms:

```text
Adopted baseline
Platform/journey/document scope
Atomic requirement coverage
Acceptance methods
Third-party continuity
No conflict with security or product policy
```

---

# 301. Data and Integration Owner Responsibility

Confirms:

```text
Source of truth
Business semantics
Ownership boundary
Quality/lifecycle
Exchange responsibility
Failure/reconciliation
Operational evidence
```

---

# 302. QA / Verification Responsibility

During Phase 04, QA reviews testability and acceptance coverage.

QA does not invent missing requirements during test execution; gaps reopen the baseline.

---

# 303. Validation Rules

The following rules apply regardless of P-profile.

---

# 304. VAL-04-001

Every baselined Requirement must have at least one authoritative upstream source or approved derivation rationale.

---

# 305. VAL-04-002

Every normative statement must use explicit obligation language and identify observable behavior or measurable quality.

---

# 306. VAL-04-003

A requirement containing independently changeable obligations must be split or formally modeled as a parent with atomic children.

---

# 307. VAL-04-004

Feature Candidate status does not grant requirement approval.

---

# 308. VAL-04-005

Every Requirement must have acceptance criteria and verification method before baseline.

---

# 309. VAL-04-006

Every quantitative target must identify source, unit, scope, and measurement context.

---

# 310. VAL-04-007

Implementation technology must not appear as requirement unless it is an approved imposed constraint with source and rationale.

---

# 311. VAL-04-008

Every critical state transition must define authorization, preconditions, outcome, and invalid-transition behavior.

---

# 312. VAL-04-009

Every critical journey must include material error and recovery coverage.

---

# 313. VAL-04-010

Unknown must not be converted automatically to `NOT_APPLICABLE` or hidden in ambiguous wording.

---

# 314. VAL-04-011

Every `TBD/TBC/PENDING` item must have owner, impact, blocking status, and resolution route.

---

# 315. VAL-04-012

Every requirement must have priority/release disposition before baseline.

---

# 316. VAL-04-013

Every material dependency must be explicit and owned.

---

# 317. VAL-04-014

No material semantic duplicate or conflict may remain unresolved at G3B.

---

# 318. VAL-04-015

Every business/product obligation must have system disposition; `NO_SYSTEM_REQUIREMENT_NEEDED` requires rationale.

---

# 319. VAL-04-016

Every baselined requirement must have upstream traceability and expected downstream verification ownership.

---

# 320. VAL-04-017

Security/privacy requirement must not rely on UI concealment as enforcement.

---

# 321. VAL-04-018

Data requirement must not use physical schema as a substitute for business/system semantics.

---

# 322. VAL-04-019

Integration requirement must define safe behavior for material failure or unknown outcome.

---

# 323. VAL-04-020

NFR with adjectives butno measure/verification contract cannot be baselined.

---

# 324. VAL-04-021

Accessibility requirement must link to applicable platform/journey/document scope and source obligation.

---

# 325. VAL-04-022

Automated accessibility testing alone cannot satisfy manual/assistive-technology acceptance obligations.

---

# 326. VAL-04-023

Audit requirement must avoid unnecessary sensitive data and identify access/retention expectations where material.

---

# 327. VAL-04-024

Every `GOV-009` required derivation type must have requirement IDs or approved no-requirement rationale.

---

# 328. VAL-04-025

Standards-derived requirements must preserve source criterion/clause lineage and must not create a competing copy of the standard.

---

# 329. VAL-04-026

P1 Lean orMVP scope cannot weaken a constitutional, universal, security, privacy, accessibility, or mandatory control obligation for included scope.

---

# 330. VAL-04-027

Change to baselined meaning requires change record, impact analysis, and version outcome.

---

# 331. VAL-04-028

G3B cannot pass with a blocking open requirement question, decision, feasibility issue, or standards derivation gap.

---

# 332. Requirements Anti-Patterns

The following patterns invalidate requirements quality.

---

# 333. AP-04-01 — Feature List as SRS

```text
Login
Dashboard
Reports
AI
```

No behavior, constraints, acceptance, or traceability.

---

# 334. AP-04-02 — Screen-Driven Requirements

Defining scope by imagined screens before journeys, behavior, information, and states are specified.

---

# 335. AP-04-03 — User Story Is Enough

Using a story as the complete contract while rules, exceptions, authorization, data, audit, and acceptance remain missing.

---

# 336. AP-04-04 — Compound Requirement

One long sentence contains several independently testable behaviors.

---

# 337. AP-04-05 — Adjective NFR

```text
Fast
Secure
Scalable
Reliable
Easy
```

without measure or verification contract.

---

# 338. AP-04-06 — Architecture in Disguise

Writing database, framework, vendor, queue, cloud, or protocol choices as requirements without imposed source.

---

# 339. AP-04-07 — Happy Path Only

Errors, invalid states, dependency failures, and recovery are absent.

---

# 340. AP-04-08 — CRUD Completeness Illusion

Assuming create/read/update/delete covers business lifecycle and controls.

---

# 341. AP-04-09 — NFR Boilerplate

Copying generic targets from another project without load, risk, business, or source evidence.

---

# 342. AP-04-10 — Security Footer

```text
The system must be secure and follow best practices.
```

instead of atomic security/privacy requirements.

---

# 343. AP-04-11 — Accessibility at QA

Accessibility appears only as a final test checklist rather than `ACC` requirements derived from `GOV-009`.

---

# 344. AP-04-12 — Audit Everything

Logging every field/value without purpose, classification, privacy, access, or retention discipline.

---

# 345. AP-04-13 — API-First Specification

Endpoint/payload design defines behavior before system responsibility and integration outcomes are baselined.

---

# 346. AP-04-14 — Database as Data Requirements

Tables and columns replace data meaning, ownership, quality, lifecycle, and privacy obligations.

---

# 347. AP-04-15 — Acceptance = Works

```text
System works as expected.
```

is not acceptance criteria.

---

# 348. AP-04-16 — Priority by Volume

Most-requested feature automatically becomes MUST without outcome/control/release rationale.

---

# 349. AP-04-17 — MVP Quality Removal

Removing security, accessibility, audit, integrity, or recovery obligations to call a release lean.

---

# 350. AP-04-18 — Silent Scope Expansion

Adding product capability during detailed requirements and calling it clarification.

---

# 351. AP-04-19 — Traceability After Writing

Creating hundreds of requirements then trying to guess their sources at the end.

---

# 352. AP-04-20 — Standards Copy-Paste

Copying an entire standard into SRS without product-specific applicability, scope, derivation, or verification mapping.

---

# 353. AP-04-21 — Test Case Becomes Requirement

Specific test data/steps accidentally narrow or change canonical behavior.

---

# 354. AP-04-22 — Admin Bypass

Generic admin can bypass rules/controls because exception requirements were not modeled.

---

# 355. AP-04-23 — Unknown Outcome Ignored

Integration timeout treated as failure or success without reconciliation semantics.

---

# 356. AP-04-24 — N/A as Missing Information

Using `N/A` to hide unreviewed requirement family or scope dimension.

---

# 357. AP-04-25 — Baseline Without Change Control

Requirements are called approved while anyone can edit meaning without version or impact review.

---

# 358. Phase Quality Measures

Product OS may track:

```text
Upstream Derivation Coverage
Requirement Orphan Rate
Upstream Obligation Orphan Rate
Atomicity Defect Rate
Ambiguity Defect Rate
Duplicate / Overlap Rate
Conflict Closure Rate
Acceptance Criteria Coverage
Verification Method Coverage
Critical Journey Coverage
State / Exception / Recovery Coverage
NFR Measurement Coverage
Security / Privacy Coverage
Accessibility Requirement Coverage
Audit / Evidence Coverage
GOV-009 Derivation Coverage
Requirement-to-Test Traceability Readiness
TBD/TBC Age
Requirement Reopen Rate
Downstream Clarification Rate
Requirement Change After Implementation Start
Defects Caused by Requirement Ambiguity
```

---

# 359. Important Quality Metric — Requirement Invention Rate

```text
REQUIREMENT INVENTION RATE
```

> How many requirements had to be invented because Business Architecture orProduct Definition did not establish the needed responsibility?

High rate should trigger upstream methodology review.

---

# 360. Important Quality Metric — Downstream Clarification Rate

```text
DOWNSTREAM CLARIFICATION RATE
```

> How often must UX, Design, Architecture, Engineering, orQA ask Phase 04 to define behavior that should already be in the baseline?

---

# 361. Important Quality Metric — Invalid Requirement Rate

```text
DOWNSTREAM INVALID REQUIREMENT RATE
```

Requirement later removed because source, scope, rule, or product responsibility was wrong.

This metric is different from healthy controlled change.

---

# 362. Important Quality Metric — Standards Derivation Gap

```text
APPLICABLE STANDARD WITHOUT VERIFIED REQUIREMENT CHAIN
```

Target before G3B PASS:

```text
0 blocking gaps
```

---

# 363. Requirements Completion Contract

Phase 04 is complete only when the following contract is satisfied.

---

# 364. Required Inputs

```text
G2-approved Business Baseline
G3A-approved Product Baseline
Product Scope and Boundary
Product Capabilities / Policies / States / Integrations
MVP and Release Scope
Business Rules / Controls / Information / Evidence Obligations
Risks / Assumptions / Decisions / Open Questions
GOV-009 Standards & Compliance Applicability Matrix
Applicable Universal Standards
Activated Conditional Profiles
Phase 04 Requirement-Derivation Types and Source Links
```

---

# 365. Required Questions

Phase 04 must answer:

```text
What exactly shall the system do?

For which actors, scopes, platforms, markets, languages, journeys, states, documents, and third parties?

Which business rules, decisions, controls, and product policies govern behavior?

What are the valid states and transitions?

What happens for errors, exceptions, conflicts, timeouts, and unknown outcomes?

What information must the system capture, validate, retain, protect, exchange, and delete?

Which integrations exist and what observable outcomes and failure behavior are required?

What performance, capacity, availability, reliability, recovery, compatibility, maintainability, supportability, and observability levels apply?

What authentication, authorization, isolation, privacy, and security behaviors apply?

What accessibility requirements apply to each platform, critical journey, state, document, and third party?

What audit and evidence must exist?

How will each requirement be accepted and verified?

What is the priority, criticality, and release allocation?

What dependencies and assumptions remain?

Which upstream obligations have no system requirement and why?

Which `GOV-009` derivation obligations produced which requirement IDs?

What downstream artifact classes must realize each requirement?

What changes reopen the Requirements Baseline?
```

---

# 366. Required Decisions

At minimum:

```text
SRS Scope and Structure
Requirement Type and ID Model
Functional Requirement Baseline
Non-Functional Requirement Baseline
Data Requirement Baseline
Integration Requirement Baseline
Security and Privacy Requirement Baseline
Accessibility Requirement Baseline
Audit and Evidence Requirement Baseline
State / Exception / Recovery Baseline
Acceptance and Verification Intent
Priority / Criticality / Release Allocation
Requirement Conflict Disposition
Upstream Obligation Disposition
GOV-009 Requirements Derivation Update
Requirements Baseline Version
G3B Outcome
Downstream Handoff
```

---

# 367. Exit Criteria

Phase 04 complete when:

1. SRS scope and source baselines are explicit.
2. Every material upstream business/product obligation has system disposition.
3. Functional requirements cover critical capabilities, rules, states, exceptions, and recovery.
4. Applicable NFRs are measurable and owned.
5. Applicable Data Requirements are defined without premature physical design.
6. Integration boundaries, outcomes, failures, and reconciliation are covered.
7. Security andPrivacy requirements are derived from risks, controls, classifications, and standards.
8. Accessibility requirements cover applicable platforms, journeys, documents, states, and third parties.
9. Audit andEvidence requirements cover material controls, decisions, and actions.
10. Every baselined requirement is sufficiently atomic, unambiguous, feasible, and implementation-independent.
11. Every baselined requirement has acceptance criteria and verification method.
12. Priority, criticality, and release allocation are explicit.
13. Material dependencies and assumptions are linked.
14. Blocking conflicts and semantic duplicates are resolved.
15. Blocking questions, decisions, feasibility issues, andTBDs = 0.
16. Bidirectional traceability is operational.
17. Requirement orphans and unrealized upstream obligations = 0 for blocking scope.
18. Every applicable `GOV-009` derivation obligation has requirement IDs or approved rationale.
19. `GOV-009` contains derived IDs, acceptance/verification expectations, owners, baseline version, and reopen conditions.
20. Downstream Experience/Design/Architecture/Verification allocations are explicit.
21. Requirements Baseline is versioned and approved.
22. G3B evaluated with all required checks.
23. Requirements Handoff generated.

---

# 368. Final Transformation

Phase 04 transforms:

```text
APPROVED BUSINESS BASELINE
+
APPROVED PRODUCT BASELINE
+
STANDARDS-DERIVATION CONTRACT
```

into:

```text
SYSTEM REQUIREMENTS SPECIFICATION
+
FR / NFR / DR / INT / SEC / ACC / AUD
+
STATE / EXCEPTION / ERROR / RECOVERY BEHAVIOR
+
ACCEPTANCE CRITERIA
+
VERIFICATION INTENT
+
PRIORITY / CRITICALITY / RELEASE ALLOCATION
+
BIDIRECTIONAL TRACEABILITY
+
GOV-009 DERIVED REQUIREMENT LINKS
+
VERSIONED REQUIREMENTS BASELINE
```

---

# 369. Final Methodology Principle

```text
Requirements Engineering must specify what the system must do
and how success will be proven,
without inventing why the product exists,
what it owns,
or how the solution will be built.
```

---

# 370. Phase 04 Output

```text
APPROVED PRODUCT BASELINE
        ↓
REQUIREMENTS ENGINEERING
        ↓
ATOMIC + TESTABLE + TRACEABLE SYSTEM REQUIREMENTS
        ↓
STANDARDS-LINKED REQUIREMENTS BASELINE
        ↓
G3B — REQUIREMENTS BASELINE
        ↓
EXPERIENCE + DESIGN + ARCHITECTURE + VERIFICATION
```

**Phase 00 ensured we entered the correct project.**

**Phase 01 ensured we understood the correct problem.**

**Phase 02 ensured the business logic was defined.**

**Phase 03 ensured the product responsibility and scope were defined.**

**Phase 04 ensures every approved responsibility becomes a precise, verifiable, and traceable system contract before downstream teams design or build the solution.**
