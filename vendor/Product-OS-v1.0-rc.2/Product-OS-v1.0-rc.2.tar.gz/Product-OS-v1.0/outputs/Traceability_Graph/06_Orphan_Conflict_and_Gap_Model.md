# Product OS v1.0 — Orphan, Conflict, and Gap Model

~~~yaml
document_id: FRAMEWORK-TRACE-ORPHAN-CONFLICT-GAP
version: 0.1.0
status: WORKING_DRAFT
completion_state: ORPHAN_CONFLICT_GAP_MODEL_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
orphan_status_count: 7
gap_status_count: 7
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification makes missing and unreliable traceability first-class governed information.

It prevents Product OS from hiding uncertainty through:

- arbitrary links;
- empty N/A labels;
- broad epic or file references;
- optimistic coverage percentages;
- silently selected sources;
- deleted invalidated history;
- AI-guessed relationships.

---

# 2. Missing Relationship Terms

| Term | Definition |
|---|---|
| Orphan | A node that lacks one or more relationships required by its type, scope, state, phase, gate, profile, or obligation |
| Gap | A specific unsatisfied relationship obligation, missing endpoint, missing evidence, or invalid coverage partition |
| Broken reference | A node or edge locator that cannot resolve to the bound identity |
| Conflict | Two or more sourced assertions cannot all be true for overlapping scope and time |
| Stale relationship | Relationship support may no longer be relied upon because source, version, scope, evidence, validity, or context changed |
| Invalid relationship | Edge violates semantic, type, direction, scope, evidence, authority, or lifecycle rules |
| Unknown relationship | Product OS cannot yet establish whether or how the required relation exists |

An orphan may produce multiple gaps. A gap may affect multiple nodes.

---

# 3. Orphan Status

~~~text
ORPHAN_CONFIRMED
LINK_MISSING
SOURCE_MISSING
DOWNSTREAM_MISSING
INTENTIONALLY_STANDALONE
NOT_APPLICABLE
RESOLVED
~~~

| Status | Use |
|---|---|
| ORPHAN_CONFIRMED | Required relationship is absent after review |
| LINK_MISSING | Endpoint objects exist but the canonical relationship record is missing |
| SOURCE_MISSING | Legitimate upstream source or authority cannot be established |
| DOWNSTREAM_MISSING | Required realization, allocation, verification, release, live, or disposition path is absent |
| INTENTIONALLY_STANDALONE | Authorized review confirms no relationship obligation exists beyond the recorded standalone purpose |
| NOT_APPLICABLE | Authorized N/A decision satisfies the exact relationship obligation |
| RESOLVED | Required relation or valid disposition now exists and history is preserved |

---

# 4. Common Orphan Classes

| Orphan | Missing relationship |
|---|---|
| Source with no captured item or explicit archive disposition | CAPTURED_FROM inverse reach |
| Fact with no source | CAPTURED_FROM or SUPPORTED_BY |
| Assumption with dependents but no owner or validation | ASSUMES inverse plus verification route |
| Question marked resolved without an answer or decision | ANSWERS inverse or DECIDES |
| Decision with no subject | DECIDES |
| Risk with no affected scope, treatment, or monitoring | APPLIES_TO, SATISFIES, MEASURED_BY |
| Exception with no original obligation | WAIVED_BY inverse |
| Evidence with no claim or target | EVIDENCED_BY inverse |
| GOV-009 applicable item with no downstream chain | APPLIES_TO and required standard path |
| Business objective with no product/KPI/disposition | DERIVED_FROM or relevant downstream edge |
| Product capability with no requirement/disposition | DERIVED_FROM inverse or explicit exclusion |
| Requirement with no legitimate origin | DERIVED_FROM |
| User-affecting requirement with no experience disposition | REALIZES inverse or authorized direct disposition |
| Experience view or state with no journey/requirement purpose | REFINES, REALIZES, DERIVED_FROM |
| Design screen or component with no intended consumer or adoption | REALIZES, IMPLEMENTED_BY, INCLUDED_IN |
| ADR with no driver or affected mechanism | DERIVED_FROM, SATISFIES, APPLIES_TO |
| Readiness work with no approved allocation | ALLOCATED_TO inverse |
| Implementation object with no work, defect, control, or change source | IMPLEMENTED_BY inverse |
| Verification case with no obligation, risk, defect, or charter purpose | VERIFIED_BY inverse |
| Verification result with no exact candidate or evidence | DERIVED_FROM, EVIDENCED_BY |
| Release member outside accepted VBL or waiver | RELEASED_AS, VERIFIED_BY, WAIVED_BY |
| Live service with no release or brownfield origin | OPERATES_AS inverse |
| Alert with no SLO, control, risk, user outcome, or response purpose | MEASURED_BY or OBSERVED_BY inverse |
| Evolution candidate with no signal, insight, decision, or route | DERIVED_FROM, DECIDES, REOPENS |
| Retirement with no user, data, integration, access, or evidence path | APPLIES_TO, MIGRATED_BY, VERIFIED_BY, EVIDENCED_BY |

---

# 5. Gap Status

~~~text
OPEN
TRIAGED
IN_REMEDIATION
BLOCKED
ACCEPTED_TEMPORARILY
RESOLVED
SUPERSEDED
~~~

`ACCEPTED_TEMPORARILY` requires valid authority, risk treatment, expiry, restrictions, and a due event. It is not confirmed coverage.

---

# 6. Gap Types

~~~text
MISSING_NODE
MISSING_EDGE
BROKEN_REFERENCE
INVALID_DIRECTION
INVALID_DOMAIN_RANGE
CARDINALITY_SHORTFALL
SCOPE_GAP
VERSION_GAP
SOURCE_GAP
EVIDENCE_GAP
AUTHORITY_GAP
CONFIDENCE_GAP
CONFLICT_GAP
STALE_RELATIONSHIP
INVALIDATED_COVERAGE
UNRESOLVED_NA
HISTORY_GAP
TOOL_SYNC_GAP
~~~

One finding may have multiple gap types but one primary type for ownership and reporting.

---

# 7. Gap Record

~~~yaml
trace_gap_id:
primary_gap_type:
secondary_gap_types: []
relationship_obligation_ref:
affected_node_refs: []
affected_trace_refs: []
expected_edge_type:
expected_domain:
expected_range:
evaluated_scope:
graph_revision:
detected_at:
detected_by:
source_refs: []
evidence_refs: []
criticality:
profile_and_overrides:
affected_artifacts: []
affected_gates: []
affected_releases: []
affected_live_scope: []
owner:
triage_authority:
status:
risk_ref:
exception_ref:
temporary_restrictions: []
required_actions: []
due_event:
resolution_trace_refs: []
resolution_decision_ref:
resolved_at:
reopen_triggers: []
~~~

---

# 8. Orphan Record

~~~yaml
orphan_record_id:
node_ref:
node_class:
qualified_object_type:
evaluated_scope:
expected_relationship_obligations: []
missing_relationship_obligations: []
gap_refs: []
orphan_status:
reason:
owner:
reviewer:
reviewed_at:
decision_ref:
valid_until:
reopen_triggers: []
resolved_by_trace_refs: []
~~~

---

# 9. Conflict Types

~~~text
SOURCE_CONFLICT
SEMANTIC_CONFLICT
VERSION_CONFLICT
SCOPE_CONFLICT
AUTHORITY_CONFLICT
APPLICABILITY_CONFLICT
STATUS_CONFLICT
EVIDENCE_CONFLICT
TOOL_OWNERSHIP_CONFLICT
TEMPORAL_CONFLICT
~~~

Conflict is evaluated only for overlapping semantic scope and time. Two different market or version assertions may both be valid.

---

# 10. Conflict Resolution

~~~text
1. Preserve every sourced assertion and its provenance.
2. Identify overlap in object, version, scope, and valid time.
3. Classify conflict type and materiality candidate.
4. Identify affected paths, gates, release, live scope, and evidence.
5. Route the exact decision question to valid authority.
6. Prevent conflicting edges from counting as confirmed coverage.
7. Record resolution decision and effective time.
8. Confirm, invalidate, or supersede affected assertions.
9. Preserve the complete conflict history.
10. Trigger impact discovery when material current meaning changes.
~~~

Source precedence is applied only when an authorized rule actually governs the conflicting sources. It is not invented during triage.

---

# 11. Intentional Standalone Decision

`INTENTIONALLY_STANDALONE` is permitted only when:

- the node has a legitimate independent purpose;
- no active relationship obligation applies;
- exact scope is defined;
- rationale and source exist;
- authorized reviewer confirms the decision;
- validity and reopen triggers exist;
- downstream consumers are not misled.

Examples may include an external reference retained for watchlist purposes or a reusable design token with no current product adoption. The graph must not report active adoption or delivery coverage.

---

# 12. N/A vs Missing

| Situation | Correct treatment |
|---|---|
| Obligation does not apply under authorized exact-scope decision | NOT_APPLICABLE edge and N/A decision |
| Team has not investigated applicability | PENDING applicability plus gap |
| Required node exists but edge was not recorded | LINK_MISSING |
| Upstream source cannot be established | SOURCE_MISSING |
| Downstream work has not occurred but is not due | NOT_YET_REQUIRED coverage |
| Downstream work is due and absent | DOWNSTREAM_MISSING or UNCOVERED |
| Source or evidence changed after prior coverage | INVALIDATED coverage |

Missing is never converted to N/A for reporting convenience.

---

# 13. Severity and Gate Effect

The graph imports criticality and risk from canonical owners and reports candidate effect.

| Finding | Graph output |
|---|---|
| Gate-critical missing source or decision | Blocking gap candidate |
| Critical obligation without implementation or verification | Blocking coverage gap candidate |
| Conflicted release candidate identity | G7 blocker candidate |
| Live service without ownership or origin | G8 critical gap candidate |
| Low-risk optional view missing a derived link | Non-blocking remediation candidate |

Only Gate Specifications and authorized decision owners determine actual gate outcome.

---

# 14. Gap Detection

Detection sources include:

- relationship-obligation evaluation;
- domain/range and cardinality validation;
- source-system synchronization;
- graph revision comparison;
- evidence freshness review;
- gate-pack generation;
- incident and operational review;
- standards applicability change;
- source, repository, design, release, or runtime drift;
- manual challenge.

Automated detection records the rule and graph revision. It does not self-resolve semantic findings.

---

# 15. Gap Triage

Triage determines:

1. real missing relationship versus sync or query defect;
2. exact affected scope and versions;
3. applicable profile and overrides;
4. source, evidence, and authority availability;
5. gate, release, live, standard, and lifecycle relevance;
6. owner and due event;
7. immediate restriction or escalation;
8. whether impact discovery is required.

Triage does not create the missing relationship without valid source.

---

# 16. Resolution Types

~~~text
EDGE_CONFIRMED
NODE_REGISTERED
REFERENCE_REPAIRED
SCOPE_PARTITIONED
SOURCE_ESTABLISHED
EVIDENCE_REPLACED
CONFLICT_DECIDED
NA_AUTHORIZED
STANDALONE_AUTHORIZED
OBLIGATION_SUPERSEDED
TOOL_SYNC_RESTORED
~~~

Resolution links the exact node, trace, evidence, and decision. Closing a ticket alone does not resolve the graph gap.

---

# 17. Ageing and Review

Gap age is measured from detection and from the due event.

Review prioritizes:

- gate-critical or release-critical findings;
- severe live harm or unknown ownership;
- applicable standards and control gaps;
- critical requirement-to-verification gaps;
- stale evidence supporting current decisions;
- source and authority gaps;
- ageing temporary acceptance;
- unresolved conflicts affecting current baselines.

Age alone does not determine criticality, but ageing increases escalation and validity review.

---

# 18. Historical Gap Preservation

Resolved gaps remain queryable with:

- original detection;
- evaluated graph revision;
- original missing obligation;
- affected decisions and restrictions;
- resolution evidence;
- time to triage and resolution;
- recurrence links.

Deleting resolved gaps prevents audit and process learning.

---

# 19. Orphan and Gap Validation Rules

~~~text
GAP-VAL-001  Every activated relationship obligation without eligible coverage creates a gap or valid disposition.
GAP-VAL-002  Every orphan record identifies the exact missing relationship obligation.
GAP-VAL-003  Missing and pending are never represented as N/A.
GAP-VAL-004  Intentional standalone status has purpose, scope, authority, validity, and reopen triggers.
GAP-VAL-005  Conflicting assertions remain preserved and excluded from confirmed coverage.
GAP-VAL-006  Conflict resolution identifies overlap, authority, effective time, and resulting assertions.
GAP-VAL-007  Every temporary gap acceptance has risk, authority, restrictions, due event, and expiry.
GAP-VAL-008  Every gap binds graph revision and evaluated scope.
GAP-VAL-009  Tool-sync failure is not misreported as semantic absence without triage.
GAP-VAL-010  A closed work item cannot close a gap without resolving or dispositioning the graph obligation.
GAP-VAL-011  Resolved gaps preserve history and resolution evidence.
GAP-VAL-012  AI-discovered candidate edges do not close orphan or gap findings automatically.
~~~

---

# 20. Final Gap Principle

> **A trustworthy graph shows what it cannot prove as clearly as what it can; an explicit gap is stronger than a convenient link whose meaning, source, scope, or authority is false.**
