# Product OS v1.0 — Edge Domain, Range, and Cardinality

~~~yaml
document_id: FRAMEWORK-TRACE-EDGE-CONSTRAINTS
version: 0.1.0
status: WORKING_DRAFT
completion_state: EDGE_CONSTRAINTS_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
edge_constraint_count: 40
type_set_count: 16
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification defines allowed endpoint classes and aggregate multiplicity for every canonical edge type.

It distinguishes:

- the binary shape of one edge record;
- default aggregate multiplicity across many records;
- relationship obligations that activate minimum cardinality for exact scope;
- structural cycle and endpoint constraints.

---

# 2. Cardinality Notation

| Notation | Meaning |
|---|---|
| 0..1 | Optional and at most one in the evaluated scope |
| 1 | Exactly one in the evaluated scope |
| 0..* | Optional and unbounded |
| 1..* | At least one |

`Outbound` counts to-nodes per exact from-node version and scope. `Inbound` counts from-nodes per exact to-node version and scope.

Every individual edge record remains one from-node to one to-node.

---

# 3. Controlled Type Sets

| Type set | Exact members |
|---|---|
| TS-ALL | ARTIFACT, SOURCE, FACT, ASSUMPTION, QUESTION, DECISION, RISK, EXCEPTION, EVIDENCE, STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |
| TS-GOVERNED | ARTIFACT, FACT, ASSUMPTION, QUESTION, DECISION, RISK, EXCEPTION, STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |
| TS-CLAIM | FACT, ASSUMPTION, DECISION, RISK, EXCEPTION, STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |
| TS-SUPPORT | SOURCE, FACT, EVIDENCE, STANDARD, DECISION, VERIFICATION, OPERATION |
| TS-OBLIGATION | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, RISK |
| TS-REALIZER | PRODUCT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION |
| TS-CONSTRAINT | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, DECISION, RISK, EXCEPTION, ARCHITECTURE |
| TS-CONTAINER | ARTIFACT, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |
| TS-BASELINE | ARTIFACT, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, OPERATION |
| TS-IMPLEMENTABLE | REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, RISK, EXCEPTION, VERIFICATION, EVOLUTION |
| TS-VERIFIABLE | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, RISK, EXCEPTION, RELEASE, OPERATION |
| TS-ACTION | DECISION, EXCEPTION, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |
| TS-TRIGGER | SOURCE, FACT, ASSUMPTION, QUESTION, DECISION, RISK, EXCEPTION, EVIDENCE, STANDARD, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |
| TS-LIVE | IMPLEMENTATION, RELEASE, OPERATION |
| TS-FAILURE | VERIFICATION, OPERATION, FACT, EVIDENCE, RISK |
| TS-LIFECYCLE-TARGET | ARTIFACT, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE |

An edge constraint may list an explicit class outside a type set. The resolved set is the exact union shown in the row.

---

# 4. Aggregate Edge Constraints

| ID | Edge | From domain | To range | Outbound | Inbound | Structural rule | Minimum-cardinality activation |
|---|---|---|---|---|---|---|---|
| EC-001 | CAPTURED_FROM | TS-GOVERNED excluding ARTIFACT and STANDARD | SOURCE, ARTIFACT | 1..* | 0..* | Direct assertion; no self-edge | Mandatory for every item whose origin is external or artifact-derived |
| EC-002 | SUPPORTED_BY | TS-CLAIM | TS-SUPPORT | 0..* | 0..* | Support cannot target the same node version | At least one for claims requiring evidence at a gate or decision |
| EC-003 | CONTRADICTS | TS-ALL | TS-ALL | 0..* | 0..* | Symmetric, deterministic storage order, no self-edge | Mandatory when a material unresolved incompatibility is known |
| EC-004 | ASSUMES | TS-GOVERNED | ASSUMPTION | 0..* | 0..* | Dependency on explicit assumption; no self-edge | At least one when current meaning relies on unverified belief |
| EC-005 | ANSWERS | FACT, DECISION, EVIDENCE, STANDARD, BUSINESS, PRODUCT, REQUIREMENT, VERIFICATION, OPERATION | QUESTION | 0..* | 0..* | Answer must bind exact question version | At least one inbound answer before a question is resolved |
| EC-006 | DECIDES | DECISION | TS-GOVERNED excluding DECISION | 1..* | 0..* | Decision scope and validity required | Every approved decision has at least one decided subject or route |
| EC-007 | DERIVED_FROM | TS-GOVERNED | TS-ALL | 1..* | 0..* | Acyclic within derivation lineage; no self-edge | Mandatory for approved downstream meaning unless it is an authorized origin |
| EC-008 | REFINES | BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, EVOLUTION, LIFECYCLE | Same class or an approved adjacent upstream class | 0..* | 0..* | Acyclic refinement hierarchy | At least one when object is declared as a refinement |
| EC-009 | DECOMPOSES_TO | TS-CONTAINER excluding ARTIFACT | Same class or approved child class | 1..* | 0..1 | Acyclic parent-to-child hierarchy per decomposition scheme | Mandatory when an aggregate claims governed children |
| EC-010 | BOUNDS | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, DECISION, ARCHITECTURE, LIFECYCLE | TS-GOVERNED | 1..* | 0..* | Boundary dimension and included/excluded semantics required | Mandatory when the from-node defines scope or responsibility limits |
| EC-011 | SATISFIES | TS-REALIZER | TS-OBLIGATION | 0..* | 0..* | Coverage extent and evidence rule required for confirmed status | At least one for every activated obligation claiming realized satisfaction |
| EC-012 | REALIZES | PRODUCT, EXPERIENCE, DESIGN | BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE | 1..* | 0..* | Adjacent-level or explicitly justified skip; no circular realization | Mandatory for baselined downstream product, experience, and design objects |
| EC-013 | ALLOCATED_TO | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, RISK, EXCEPTION, EVOLUTION | READINESS | 1..* | 0..* | Exact owner, due event, and scope required | Mandatory for every in-scope implementable obligation before G5B |
| EC-014 | IMPLEMENTED_BY | TS-IMPLEMENTABLE | IMPLEMENTATION | 1..* | 0..* | Exact revision and implementation extent required | Mandatory for in-scope release obligations before G6A |
| EC-015 | CONFIGURED_BY | PRODUCT, REQUIREMENT, ARCHITECTURE, IMPLEMENTATION, RELEASE, OPERATION | IMPLEMENTATION | 0..* | 0..* | Target must be configuration, flag, policy, key reference, or environment revision | Mandatory when effective behavior varies by configuration |
| EC-016 | MIGRATED_BY | BUSINESS, PRODUCT, REQUIREMENT, ARCHITECTURE, IMPLEMENTATION, OPERATION, LIFECYCLE | READINESS, IMPLEMENTATION, RELEASE | 0..* | 0..* | Population, source, target, reconciliation, and rollback scope required | Mandatory when state, data, users, interfaces, or ownership migrate |
| EC-017 | VERIFIED_BY | TS-VERIFIABLE | VERIFICATION | 1..* | 0..* | Exact method, candidate, environment, and variant scope required | Mandatory for every activated verifiable obligation before G6B |
| EC-018 | EVIDENCED_BY | TS-CLAIM | EVIDENCE | 1..* | 0..* | Claim, target, method, time, period, integrity, and review required | Mandatory for gate-critical or live-control claims |
| EC-019 | FAILED_BY | TS-VERIFIABLE | TS-FAILURE | 0..* | 0..* | Exact failed scope and expected behavior required | Mandatory when a known failure defeats or limits an obligation |
| EC-020 | WAIVED_BY | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, VERIFICATION, RELEASE, OPERATION | EXCEPTION | 0..* | 1..* | Original obligation preserved; authority and expiry required | Every waiver or exception has at least one inbound original obligation |
| EC-021 | DEPENDS_ON | TS-GOVERNED | TS-ALL | 0..* | 0..* | No self-edge; cycles allowed only with explicit strongly-connected-component treatment | Mandatory for material external, timing, data, platform, or decision dependencies |
| EC-022 | CONSTRAINED_BY | TS-GOVERNED | TS-CONSTRAINT | 0..* | 0..* | Constraint effect and scope required | Mandatory for material constitutional, standard, policy, risk, or architecture constraints |
| EC-023 | GOVERNED_BY | TS-GOVERNED | ARTIFACT, STANDARD, DECISION, BUSINESS | 1..* | 0..* | No governance cycle that causes mutual authority | Mandatory at artifact, baseline, release, and live-scope level |
| EC-024 | APPLIES_TO | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, DECISION, RISK, EXCEPTION | TS-GOVERNED | 1..* | 0..* | Positive applicability authority and scope required | Every applicable GOV-009 or policy object has at least one target |
| EC-025 | NOT_APPLICABLE_TO | STANDARD, BUSINESS, PRODUCT, REQUIREMENT, DECISION | TS-GOVERNED | 1..* | 0..* | Reason, authority, evidence, validity, and reopen required | Every authorized N/A decision has at least one exact target |
| EC-026 | INCLUDED_IN | TS-GOVERNED excluding ARTIFACT when target is its owning artifact | TS-CONTAINER | 1..* | 0..* | Acyclic containment per container scheme; exact container version required | Every governed owned object is included in an artifact; every release member is included in release scope |
| EC-027 | EXCLUDED_FROM | TS-GOVERNED | TS-CONTAINER | 1..* | 0..* | Exclusion rationale and disposition required | Mandatory for every object explicitly excluded from a proposed container or release |
| EC-028 | BASELINED_IN | BUSINESS, PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, OPERATION | TS-BASELINE | 1..* | 0..* | Exact version, approval, and baseline scope; no containment cycle | Mandatory for every accepted baseline object |
| EC-029 | AUTHORIZED_BY | EXCEPTION, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE | DECISION | 1..* | 0..* | Decision must be current and cover exact action scope | Mandatory before governed release, exception, transfer, sunset, and restricted operational action |
| EC-030 | RELEASED_AS | PRODUCT, REQUIREMENT, EXPERIENCE, DESIGN, ARCHITECTURE, READINESS, IMPLEMENTATION, VERIFICATION, EVOLUTION | RELEASE | 0..* | 1..* | Release membership must align with candidate and VBL | Every release scope has at least one inbound released object or explicit empty-release decision |
| EC-031 | DEPLOYED_TO | IMPLEMENTATION, RELEASE | OPERATION | 1..* | 0..* | Exact target, region, slot, version, time, and execution required | Every successful release execution has at least one deployment target |
| EC-032 | OPERATES_AS | IMPLEMENTATION, RELEASE | OPERATION | 1..* | 1..* | Live identity and effective period required | Every deployed release has a live identity; every governed live identity has a release or brownfield origin |
| EC-033 | MEASURED_BY | BUSINESS, PRODUCT, REQUIREMENT, ARCHITECTURE, RELEASE, OPERATION, EVOLUTION | OPERATION, EVIDENCE | 1..* | 0..* | Metric definition, population, period, and quality required | Mandatory for every claimed objective, SLO, control-health, or realized outcome |
| EC-034 | OBSERVED_BY | BUSINESS, PRODUCT, REQUIREMENT, ARCHITECTURE, RISK, RELEASE, OPERATION, EVOLUTION, LIFECYCLE | FACT, EVIDENCE, OPERATION, EVOLUTION | 0..* | 0..* | Observation does not prove causation | Mandatory when an operational or outcome claim cites a signal, feedback, incident, or fact |
| EC-035 | TRIGGERED_BY | QUESTION, DECISION, RISK, EXCEPTION, READINESS, IMPLEMENTATION, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE | TS-TRIGGER | 1..* | 0..* | Trigger time and exact activation effect required | Every incident response, change review, evolution route, and lifecycle action has a trigger |
| EC-036 | REOPENS | DECISION, EVIDENCE, VERIFICATION, OPERATION, EVOLUTION, LIFECYCLE | TS-LIFECYCLE-TARGET | 1..* | 0..* | Trigger relation; no automatic invalidation or approval | Every authorized reopen decision identifies at least one exact target |
| EC-037 | INVALIDATES | FACT, DECISION, EVIDENCE, VERIFICATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE | TS-LIFECYCLE-TARGET | 1..* | 0..* | Invalidating reason, valid time, and replacement route required | Every invalidation event identifies at least one exact invalidated node |
| EC-038 | SUPERSEDES | TS-LIFECYCLE-TARGET | Same semantic identity class or approved replacement class | 0..* | 0..* | Acyclic in valid-time order; merge/split mode explicit | Mandatory when a new node replaces prior current meaning |
| EC-039 | RETIRES | DECISION, LIFECYCLE | TS-LIFECYCLE-TARGET | 1..* | 0..1 per retirement scope | Authority, effective time, residual obligations, and evidence required | Every retirement action identifies the retired scope |
| EC-040 | TRANSFERRED_TO | BUSINESS, PRODUCT, REQUIREMENT, ARCHITECTURE, READINESS, IMPLEMENTATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE | BUSINESS, PRODUCT, ARCHITECTURE, READINESS, IMPLEMENTATION, RELEASE, OPERATION, EVOLUTION, LIFECYCLE | 1..* | 0..* | Successor identity, responsibility, effective time, and acceptance required | Every transfer identifies at least one successor and acknowledgement |

---

# 5. Same-Class and Adjacent-Class Rules

`Same class or approved adjacent class` is controlled as follows:

| From class | Allowed adjacent target classes for REFINES or DECOMPOSES_TO |
|---|---|
| BUSINESS | BUSINESS |
| PRODUCT | PRODUCT, BUSINESS |
| REQUIREMENT | REQUIREMENT, PRODUCT, BUSINESS |
| EXPERIENCE | EXPERIENCE, REQUIREMENT, PRODUCT |
| DESIGN | DESIGN, EXPERIENCE, REQUIREMENT |
| ARCHITECTURE | ARCHITECTURE, REQUIREMENT, PRODUCT |
| READINESS | READINESS, ARCHITECTURE, DESIGN, REQUIREMENT |
| IMPLEMENTATION | IMPLEMENTATION, READINESS, ARCHITECTURE, DESIGN |
| VERIFICATION | VERIFICATION, REQUIREMENT, RISK, ARCHITECTURE |
| EVOLUTION | EVOLUTION, OPERATION, PRODUCT, EXPERIENCE |
| LIFECYCLE | LIFECYCLE, OPERATION, PRODUCT |

Using a distant class requires an explicit relationship rationale and cannot replace the missing intermediate required path.

---

# 6. Mandatory Relationship Obligations

Default minimum cardinality becomes active only when its trigger is true.

Examples:

~~~text
Requirement is included in RBL
→ DERIVED_FROM minimum 1
→ INCLUDED_IN owning artifact minimum 1
→ BASELINED_IN RBL minimum 1
→ verification intent activates VERIFIED_BY minimum 1 before G6B

Release execution is successful
→ AUTHORIZED_BY minimum 1
→ DEPLOYED_TO minimum 1
→ OPERATES_AS minimum 1

Artifact is governed NOT_APPLICABLE
→ ARTIFACT node exists
→ NOT_APPLICABLE_TO minimum 1 for the owning obligation or decision
~~~

No global rule forces every object through every edge type.

---

# 7. Cardinality Scope

Cardinality is evaluated over:

~~~yaml
cardinality_scope:
  namespace:
  source_node_version:
  edge_type:
  release_or_baseline:
  platform_market_locale:
  environment_or_target:
  standards_profile:
  valid_time:
~~~

Splitting scope to avoid a minimum is prohibited. Legitimate partitions retain explicit parent scope and coverage aggregation.

---

# 8. Cycle Rules

## 8.1 Strictly acyclic

The following are acyclic within a semantic lineage and valid-time order:

~~~text
DERIVED_FROM
REFINES
DECOMPOSES_TO
INCLUDED_IN within one containment scheme
BASELINED_IN
SUPERSEDES
~~~

## 8.2 Cycles allowed with review

`DEPENDS_ON` may form a strongly connected component when the real system is mutually dependent. The component requires:

- explicit members;
- operational and delivery consequence;
- break-glass or failure treatment;
- ownership;
- visibility in gate and impact views.

## 8.3 Lifecycle return paths

`REOPENS`, `TRIGGERED_BY`, and evolution paths intentionally return to earlier lifecycle nodes. They are not derivation cycles.

---

# 9. Transitive Closure Rule

No canonical edge type is automatically materialized as a transitive relationship.

Queries may compute transitive closure for:

- derivation ancestry;
- refinement ancestry;
- containment ancestry;
- dependency reachability;
- supersession lineage;
- change-impact discovery.

A computed path does not become a direct confirmed edge unless its direct semantic claim is separately asserted and reviewed.

---

# 10. Endpoint Constraint Findings

Invalid endpoint handling:

~~~yaml
constraint_finding_id:
trace_id:
edge_type:
from_class:
to_class:
expected_domain:
expected_range:
scope:
severity:
detected_at:
detected_by:
owner:
resolution:
replacement_trace_refs: []
~~~

Invalid edges do not count as coverage. They remain visible until corrected, rejected, or migrated.

---

# 11. Constraint Validation Rules

~~~text
EC-VAL-001  Every canonical edge resolves to exactly one EC-001 through EC-040 constraint.
EC-VAL-002  Every from-node belongs to the allowed domain set.
EC-VAL-003  Every to-node belongs to the allowed range set.
EC-VAL-004  Cardinality is evaluated by exact namespace, node version, scope, and valid time.
EC-VAL-005  Activated minimum cardinality cannot be bypassed by profile or physical packaging.
EC-VAL-006  Acyclic edge families contain no directed cycle.
EC-VAL-007  Dependency cycles have explicit strongly-connected-component treatment.
EC-VAL-008  Lifecycle return paths are not misclassified as derivation cycles.
EC-VAL-009  Transitive query results do not become direct confirmed edges automatically.
EC-VAL-010  Invalid endpoint edges remain visible and never count as coverage.
EC-VAL-011  Scope partitioning does not hide uncovered parent scope.
EC-VAL-012  Merge and split supersession record mode and migration explicitly.
~~~

---

# 12. Final Constraint Principle

> **Cardinality is meaningful only after type, direction, scope, version, time, and activation are exact; otherwise a required link count is only arithmetic around an undefined relationship.**
