# Product OS v1.0 — Node Taxonomy and Identity

~~~yaml
document_id: FRAMEWORK-TRACE-NODE-TAXONOMY
version: 0.1.0
status: WORKING_DRAFT
completion_state: NODE_TAXONOMY_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
semantic_node_class_count: 23
legacy_classes_retained: 22
new_class: ARTIFACT
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification defines what may become a canonical GOV-008 node, how its identity is formed, and how the 281 project artifacts coexist with the finer-grained objects they own.

It prevents:

- artifact containers from being confused with their content;
- two tools from creating competing identities for the same object;
- generic names from replacing exact repositories, designs, releases, or live services;
- mutable labels from masquerading as stable node keys;
- a screenshot, file, branch, test, or dashboard from proving semantic meaning by existence.

---

# 2. Node Dimensions

Every node has separate dimensions:

| Dimension | Purpose |
|---|---|
| Operating layer | Framework, project, external source, evidence, or representation boundary |
| Semantic node class | One of the 23 controlled classes in this specification |
| Qualified object type | Precise type owned by an artifact or source contract |
| Canonical local ID | Stable ID within the project or source namespace |
| Version or revision | Exact immutable semantic or technical revision |
| Namespace | Organization, Product OS instance, project/product, and optional partition |
| Scope | Release, platform, market, locale, environment, profile, population, or lifecycle partition |
| Lifecycle status | Current state of the node version under its owning contract |
| Applicability | APPLICABLE, NOT_APPLICABLE, or PENDING under the owning authority |
| Source locator | Exact canonical location without copying full source truth |
| Owner and authority | Accountable source owner and required approver or reviewer |

No one dimension may be inferred from another.

---

# 3. Canonical Node Key

~~~yaml
node_key:
  organization_id:
  product_os_instance_id:
  project_or_product_id:
  semantic_class:
  qualified_object_type:
  canonical_local_id:
  version_or_revision:
~~~

Canonical string form:

~~~text
urn:product-os:<organization>:<instance>:<project-or-product>:<class>:<object-type>:<local-id>@<version>
~~~

Example:

~~~text
urn:product-os:acme:pos-01:checkout:REQUIREMENT:FUNCTIONAL_REQUIREMENT:REQ-FR-021@RBL-2026-04
~~~

The display title is not part of identity. Renaming a title without changing meaning does not create a new semantic node version; changing meaning does.

---

# 4. Semantic Node Classes

| Class | Canonical meaning | Typical qualified object types | Canonical owner |
|---|---|---|---|
| ARTIFACT | GOV-002 registered artifact container and version | PRODUCT_CONSTITUTION, BRD, SRS, DESIGN_HANDOFF, VBL, OBL | GOV-002 plus artifact owner |
| SOURCE | Raw or authoritative origin outside the derived claim | INTERVIEW, CONTRACT, POLICY_SOURCE, REPOSITORY, DESIGN_FILE, DATASET, LOG_STREAM | Source authority and intake owner |
| FACT | Evidence-backed observation stated without unapproved interpretation | OBSERVATION, MEASURED_FACT, CURRENT_STATE_FACT, CONSTRAINT_FACT | Owning analysis artifact |
| ASSUMPTION | Provisional belief used before confirmation | MARKET_ASSUMPTION, TECHNICAL_ASSUMPTION, CAPACITY_ASSUMPTION | GOV-005 and dependent owner |
| QUESTION | Open information or decision need | DISCOVERY_QUESTION, DECISION_QUESTION, BLOCKING_QUESTION | GOV-006 or owning artifact |
| DECISION | Accountable choice, outcome, rationale, authority, and validity | GATE_DECISION, ADR, RELEASE_DECISION, APPLICABILITY_DECISION | GOV-003 or specialized decision artifact |
| RISK | Potential adverse event or condition with exposure and treatment | PRODUCT_RISK, SECURITY_RISK, DELIVERY_RISK, OPERATIONAL_RISK | GOV-004 |
| EXCEPTION | Authorized deviation, waiver, or time-bound exception | WAIVER, CONTROL_EXCEPTION, STANDARD_EXCEPTION, RELEASE_EXCEPTION | Authorized exception owner |
| EVIDENCE | Reviewable support for a claim | TEST_EVIDENCE, RESEARCH_EVIDENCE, ATTESTATION, LOG_EVIDENCE | Evidence owner and store |
| STANDARD | Constitution rule, standard, profile, clause, criterion, or control obligation source | CONSTITUTION_RULE, STANDARD_PROFILE, CLAUSE, CRITERION | GOV-001 or GOV-009 source owner |
| BUSINESS | Business objective, capability, process, rule, control, policy, information, or KPI | BUSINESS_OBJECTIVE, CAPABILITY, PROCESS, BUSINESS_RULE, CONTROL | BUS family owner |
| PRODUCT | Product objective, boundary, capability, module, candidate, policy, or state | PRODUCT_CAPABILITY, MODULE, FEATURE_CANDIDATE, PRODUCT_POLICY | PROD family owner |
| REQUIREMENT | Atomic functional or quality obligation with acceptance and verification intent | FR, NFR, SEC, ACC, AUD, DR, INT, DATA_REQUIREMENT | REQ family owner |
| EXPERIENCE | Actor, journey, flow, IA, view, state, interaction, content, or recovery responsibility | JOURNEY, FLOW, VIEW, STATE, EXPERIENCE_RULE | EXP family owner |
| DESIGN | Token, component, pattern, screen, variant, content design, asset, or prototype | TOKEN, COMPONENT, PATTERN, SCREEN, PROTOTYPE | DES family or canonical design source owner |
| ARCHITECTURE | Driver, scenario, ADR, domain, data, interface, control, topology, or technical mechanism | ADR, QAS, DATA_MODEL, API_CONTRACT, CONTROL_MECHANISM | ARC family owner |
| READINESS | Engineering allocation and readiness object | SLICE, WORK_ITEM, DOR_RESULT, REPOSITORY_MAPPING, EVIDENCE_PLAN | ENG family owner |
| IMPLEMENTATION | Exact implemented change, source, schema, config, infrastructure, build, or candidate | COMMIT, BUILD_ARTIFACT, SCHEMA_REVISION, CONFIG_REVISION, CANDIDATE | IMP family and source owner |
| VERIFICATION | Verification scope, method, case, run, result, defect, coverage, waiver disposition, or VBL | TEST_CASE, TEST_RUN, RESULT, DEFECT, COVERAGE_SET, VBL | VRL verification owner |
| RELEASE | Release scope, candidate binding, target, authorization, execution, rollout, rollback, or handoff | RELEASE_SCOPE, RDEC, RELEASE_EXECUTION, ROLLOUT_STAGE | VRL release owner |
| OPERATION | Live identity, signal, SLI, SLO, incident, support, control health, recovery, cost, or period evidence | LIVE_SERVICE, SLI, SLO, INCIDENT, CONTROL_HEALTH | OPS owner |
| EVOLUTION | Signal interpretation, insight, experiment, candidate, decision, portfolio item, or route | INSIGHT, EXPERIMENT, EVOLUTION_CANDIDATE, ROUTE | OPS evolution owner |
| LIFECYCLE | Deprecation, migration, transfer, sunset, archival, or retirement object | DEPRECATION, SUNSET_PLAN, TRANSFER, RETIREMENT | Lifecycle authority |

---

# 5. Why ARTIFACT Is a Separate Class

The inherited 22-class vocabulary represented semantic content but lacked a truthful class for artifact containers.

Example:

~~~text
REQ-001 SRS artifact container       → ARTIFACT
REQ-FR-021 owned requirement object  → REQUIREMENT
REQ-AC-021 acceptance object         → REQUIREMENT
REQ-VM-021 verification intent       → REQUIREMENT
~~~

The owned objects link to their artifact through `INCLUDED_IN`. The artifact links to GOV-002 identity through its node metadata and may link to its baseline through `BASELINED_IN`.

This addition does not create another project artifact. It makes existing artifact identities representable.

---

# 6. Artifact Container Rule

For every project artifact instance or governed N/A disposition:

~~~yaml
semantic_class: ARTIFACT
qualified_object_type: <catalog artifact name normalized to controlled type>
canonical_local_id: <GOV, INIT, DISC, BUS, PROD, REQ, EXP, DES, ARC, ENG, IMP, VRL, or OPS ID>
version_or_revision: <artifact version or N/A decision version>
gov_002_entry_ref: <required>
owned_object_refs: []
~~~

Composite P1 packaging creates one physical file locator but preserves multiple ARTIFACT node identities.

---

# 7. Artifact Family to Semantic Content Mapping

| Family | Container class | Primary owned semantic classes | Common secondary classes |
|---|---|---|---|
| GOV | ARTIFACT | STANDARD, DECISION, RISK, ASSUMPTION, QUESTION, EXCEPTION | EVIDENCE, LIFECYCLE, ARTIFACT |
| INIT | ARTIFACT | SOURCE, FACT, ASSUMPTION, QUESTION, DECISION | RISK, STANDARD, EVIDENCE |
| DISC | ARTIFACT | FACT, QUESTION, DECISION, EVIDENCE | ASSUMPTION, RISK, BUSINESS |
| BUS | ARTIFACT | BUSINESS | DECISION, RISK, STANDARD, EVIDENCE |
| PROD | ARTIFACT | PRODUCT | BUSINESS, DECISION, RISK, STANDARD |
| REQ | ARTIFACT | REQUIREMENT | DECISION, RISK, STANDARD, EVIDENCE |
| EXP | ARTIFACT | EXPERIENCE | REQUIREMENT, DECISION, EVIDENCE |
| DES | ARTIFACT | DESIGN | EXPERIENCE, REQUIREMENT, EVIDENCE |
| ARC | ARTIFACT | ARCHITECTURE | REQUIREMENT, DECISION, RISK, STANDARD, EVIDENCE |
| ENG | ARTIFACT | READINESS | ARCHITECTURE, REQUIREMENT, RISK, EVIDENCE |
| IMP | ARTIFACT | IMPLEMENTATION | READINESS, EXCEPTION, EVIDENCE |
| VRL | ARTIFACT | VERIFICATION, RELEASE | EVIDENCE, EXCEPTION, RISK, DECISION |
| OPS | ARTIFACT | OPERATION, EVOLUTION, LIFECYCLE | EVIDENCE, DECISION, RISK, EXCEPTION |

This table controls defaults, not forced classification. Qualified object meaning and Classification Rules determine the exact class.

---

# 8. Qualified Object Type Registry

Each semantic class may define qualified object types under an approved owning contract.

Qualified types use:

~~~text
UPPER_SNAKE_CASE
~~~

Registration requires:

~~~yaml
object_type:
semantic_class:
definition:
owning_contract:
identity_rule:
version_rule:
minimum_scope:
required_edges: []
prohibited_edges: []
compatibility:
approved_by:
effective_version:
~~~

A project may not create an unregistered synonym to evade an existing object type or edge constraint.

---

# 9. Canonical Local ID

The local ID must be:

- unique inside the namespace and object type;
- stable across title or locator changes;
- generated or assigned by the canonical owner;
- addressable without a display label;
- preserved after supersession and retirement;
- free from embedded secrets or personal data.

Tool-generated opaque IDs are allowed when the source system guarantees stability. A human-readable alias may be added separately.

---

# 10. Version and Revision Identity

Use the strongest available immutable identity:

| Source type | Required version identity |
|---|---|
| Controlled Product OS artifact | Artifact version and baseline reference |
| Git source | Repository identity plus commit SHA; path when object scope requires it |
| Build artifact | Registry, immutable digest, provenance, and build identity |
| Figma object | File key, canonical node ID, branch or version where available, and library source |
| Requirement or architecture system | Object ID plus approved revision or baseline |
| CI/test result | Run ID, candidate digest, environment, tool version, and timestamp |
| Release | Release decision, candidate digest, target, scope, window, and execution identity |
| Runtime | Organization, project, service, environment, region, version, config, flags, and effective period |
| Evidence | Evidence ID, target identity, production time, period, integrity reference, and review state |

`latest`, mutable branch names, generic environments, and file names alone do not satisfy version identity.

---

# 11. Node Record

~~~yaml
node_id:
node_key:
namespace:
  organization_id:
  product_os_instance_id:
  project_or_product_id:
  tenant_or_portfolio_id:
  environment_partition:
semantic_class:
qualified_object_type:
canonical_local_id:
title:
version_or_revision:
baseline_ref:
gov_002_entry_ref:
owning_artifact_ref:
source_system:
source_locator:
scope:
  release:
  platform:
  market_country_locale:
  role_tenant_cohort:
  environment_region_target:
  data_boundary:
  standards_profile:
  feature_flag_or_config:
  lifecycle_state:
applicability:
lifecycle_status:
owner:
authority_refs: []
classification_refs: []
access_class:
retention_class:
content_integrity_ref:
valid_from:
valid_until:
recorded_at:
recorded_by:
supersedes_node_refs: []
superseded_by_node_refs: []
tombstone_reason:
~~~

Fields with no applicable value are omitted or explicitly N/A under the future physical schema. They are not populated with invented defaults.

---

# 12. Node Equality

Two records represent the same canonical node version only when every node-key field matches.

Same local ID with a different version represents a different node version.

Same source content mirrored in another tool remains one canonical node plus representation locators when semantic ownership is unchanged.

Two genuinely independent sources remain separate nodes even when their titles and content are similar.

---

# 13. Duplicate and Alias Handling

| Situation | Required treatment |
|---|---|
| Display-name variation | One node with aliases |
| Tool mirror of the same canonical object | One node with multiple representation locators |
| Imported copy with independent lifecycle | Separate node linked by `DERIVED_FROM` or `SUPERSEDES` as applicable |
| Semantically duplicate requirement or decision | Separate nodes plus duplicate/conflict finding until authority resolves |
| Merged objects | New node version or object plus explicit supersession mode |
| Split object | New child objects with `DECOMPOSES_TO`, `REFINES`, and supersession history as appropriate |

Similarity detection does not authorize merge.

---

# 14. Source Locator Contract

A locator identifies the canonical source without storing credentials.

~~~yaml
source_locator:
  system_type:
  system_identity:
  organization_or_workspace:
  project_or_file:
  object_path_or_id:
  revision:
  environment:
  resolver_hint:
~~~

Generic `backend`, `frontend`, `mobile`, `database`, `design`, `production`, or `test` labels are prohibited when the real canonical identity can be resolved.

---

# 15. Baseline, Candidate, Release, and Live Nodes

These are qualified object types, not extra semantic classes:

| Object | Semantic class |
|---|---|
| ICB, DSBL, BBL, PBL, RBL, EBL, DBL, ABL, ERBL artifact or index | ARTIFACT and the owned semantic objects |
| IBL implementation snapshot or verification candidate | IMPLEMENTATION |
| VBL | VERIFICATION or ARTIFACT container, depending node granularity |
| Release scope, decision, and execution | RELEASE |
| Operational baseline artifact | ARTIFACT |
| Live service, config, cohort, and evidence period | OPERATION |

The node record states which granularity it represents.

---

# 16. External Source Nodes

External sources preserve:

- origin system and authority;
- creator or publisher where known;
- version, date, and retrieval identity;
- exact excerpt or structured-item locator when needed;
- license, confidentiality, and access constraints;
- reliability and freshness classification owned by the [Source / Evidence Model](../Source_Evidence_Model/Source_Evidence_Model_Index.md);
- derived atomic items through `CAPTURED_FROM`.

The graph does not convert an external source into approved Product OS meaning.

---

# 17. Evidence Nodes

Evidence nodes identify proof while content custody remains external.

They bind:

- claim or result supported;
- exact target version and scope;
- producer and method;
- environment or population;
- production time and evidence period;
- integrity reference;
- reviewer and review status;
- access and retention;
- invalidation triggers.

Evidence existence does not prove that the edge meaning is correct or sufficient.

---

# 18. Derived-View Identity

A derived view may be registered as an ARTIFACT node when it is a catalog artifact. Its rows are not new canonical semantic nodes unless they identify existing nodes or own unique governed objects.

Every view binds its graph revision and query definition. Manual edits that change relationship truth must write governed graph transactions or be rejected.

---

# 19. Node Lifecycle

Node lifecycle follows the owning artifact or object contract. At minimum:

~~~text
PROPOSED
ACTIVE
BASELINED
STALE
SUPERSEDED
RETIRED
INVALIDATED
~~~

This vocabulary is a graph interoperability layer. The canonical owner may use a richer lifecycle and must provide an explicit mapping.

An edge cannot make a stale node current.

---

# 20. Tombstone Contract

When a node can no longer be resolved or retained, preserve a tombstone with:

- node key;
- last known owner and locator class;
- last valid version and time;
- reason for unavailability;
- authority;
- affected edges;
- replacement or archival reference;
- retention decision.

Deletion without a tombstone is prohibited when historical decisions, evidence, release, compliance, incident, or lifecycle records depend on the node.

---

# 21. Node Validation Rules

~~~text
NODE-VAL-001  Every project artifact instance or governed N/A disposition has one ARTIFACT node per version.
NODE-VAL-002  Every ARTIFACT node resolves to exactly one GOV-002 entry.
NODE-VAL-003  Every node uses one of the 23 semantic classes.
NODE-VAL-004  Every qualified object type resolves to an owning contract and semantic class.
NODE-VAL-005  Every node key is unique inside the assembled graph revision.
NODE-VAL-006  Every node version is immutable after confirmation.
NODE-VAL-007  Display title is never used as canonical identity.
NODE-VAL-008  Every source locator resolves or has an explicit unresolved-state record.
NODE-VAL-009  Composite packaging preserves each logical ARTIFACT node identity.
NODE-VAL-010  Tool mirrors do not create competing canonical semantic nodes.
NODE-VAL-011  Exact repository, design, candidate, release, and runtime identities replace generic labels.
NODE-VAL-012  Evidence nodes bind exact target, method, producer, time, period, and integrity.
NODE-VAL-013  Superseded and retired nodes remain historically resolvable.
NODE-VAL-014  Restricted nodes remain visible as authorized redacted identities rather than disappearing from coverage.
NODE-VAL-015  AI similarity does not authorize node merge, promotion, adoption, or approval.
~~~

---

# 22. Change Control

Adding, renaming, merging, or removing a semantic class requires:

- problem and use cases;
- affected qualified object types;
- edge domain and range impact;
- cardinality and required-path impact;
- existing node migration;
- coverage and gate impact;
- source, evidence, tool, schema, and exchange impact;
- compatibility treatment;
- Product OS approval and version change.

Qualified object-type changes follow the same analysis at their narrower scope.

---

# 23. Final Node Principle

> **A node is valid when it identifies one exact governed thing without confusing its container, content, representation, title, version, scope, or authority.**
