# Product OS v1.0 — Trace Record and Temporal Versioning

~~~yaml
document_id: FRAMEWORK-TRACE-RECORD-TEMPORAL
version: 0.1.0
status: WORKING_DRAFT
completion_state: TRACE_RECORD_AND_TEMPORAL_MODEL_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
temporal_model: BITEMPORAL
edge_storage_model: BINARY_VERSIONED_ASSERTION
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification defines the canonical logical record for GOV-008 relationships and the history required to reconstruct what was believed, approved, valid, released, and live at any material decision time.

It is a logical contract. The later Schemas & Repository Standard will define physical JSON, YAML, database, API, and repository representations.

---

# 2. Trace Identity

Each edge assertion has a stable `trace_id` and immutable assertion versions.

~~~text
Trace logical identity  → TRACE-000001
Trace assertion v1     → TRACE-000001@1
Trace assertion v2     → TRACE-000001@2
~~~

Create a new logical `trace_id` when the from-node, edge type, to-node, or fundamental relationship scope changes meaning.

Create a new assertion version when governance metadata, evidence, status, confidence, validity, or review changes while the relationship identity remains the same.

---

# 3. Canonical Trace Record

~~~yaml
trace_id:
assertion_version:
namespace:
  organization_id:
  product_os_instance_id:
  project_or_product_id:
from:
  node_id:
  node_key:
  semantic_class:
  qualified_object_type:
  canonical_local_id:
  version_or_revision:
  gov_002_entry_ref:
edge_type:
to:
  node_id:
  node_key:
  semantic_class:
  qualified_object_type:
  canonical_local_id:
  version_or_revision:
  gov_002_entry_ref:
relationship_group_id:
scope:
  project_or_product:
  capability_or_module:
  release_or_increment:
  platform_or_client:
  market_country_locale_direction:
  role_tenant_cohort_population:
  environment_region_target:
  data_boundary:
  standards_profile_or_criterion:
  feature_flag_or_configuration:
  evidence_period:
  lifecycle_state:
coverage_extent:
  value:
  covered_scope:
  excluded_scope:
  remaining_obligation_refs: []
edge_status:
relationship_confidence:
relationship_obligation_refs: []
assertion_source_refs: []
evidence_refs: []
owner:
contributors: []
reviewers: []
authority_refs: []
conflict_refs: []
exception_refs: []
condition_refs: []
valid_time:
  valid_from:
  valid_until:
system_time:
  recorded_at:
  recorded_by:
  superseded_at:
review:
  reviewed_at:
  review_due_at:
  review_event:
integrity:
  source_integrity_refs: []
  evidence_integrity_refs: []
  assertion_integrity_ref:
supersession:
  supersedes_trace_refs: []
  superseded_by_trace_refs: []
  mode:
invalidation:
  invalidated_by_node_refs: []
  invalidated_at:
  reason:
  replacement_trace_refs: []
provenance:
  ingestion_method:
  tool_identity:
  tool_version:
  model_identity:
  human_confirmation_required:
notes:
~~~

`notes` clarify relationship context and never replace required structured fields.

---

# 4. Endpoint Binding

Every endpoint binds:

1. node ID;
2. complete node key;
3. semantic class;
4. qualified object type;
5. local ID;
6. version or immutable revision;
7. GOV-002 entry where the endpoint is a project artifact;
8. source-system resolution through the node record.

An endpoint reference to `current`, `latest`, a mutable branch, display title, generic environment, or unversioned URL is not sufficient for confirmed coverage.

---

# 5. Relationship Group

`relationship_group_id` binds multiple binary edges that collectively represent one many-to-many allocation, realization, verification, release, or migration statement.

Example:

~~~text
One accessibility requirement
→ three platform implementations
→ four verification cases
→ two release scopes
~~~

Each relationship remains independently reviewable. The group cannot hide a failed member or uncovered partition.

---

# 6. Scope Record

Scope fields use controlled IDs, not narrative labels.

Rules:

- omitted dimension means the owning contract proves it is irrelevant or inherited from a referenced scope object;
- wildcard scope is prohibited for confirmed gate-critical edges unless the wildcard resolves to a versioned closed set;
- scope inheritance identifies the parent record and inherited dimensions;
- child partitions must aggregate to the declared parent scope or expose a coverage gap;
- one edge may not combine incompatible environments, versions, evidence periods, or applicability decisions.

---

# 7. Coverage Extent

~~~text
FULL
PARTIAL
NONE
NOT_APPLICABLE
UNKNOWN
~~~

`FULL` means full coverage only for the edge’s bound scope. It does not mean the full target node, product, platform set, release, or standard is covered outside that scope.

`PARTIAL` requires covered, excluded, and remaining scopes.

---

# 8. Bitemporal Model

The graph preserves two time axes.

## 8.1 Valid time

When the relationship is true in the product, project, release, or operating world.

~~~yaml
valid_from:
valid_until:
~~~

## 8.2 System time

When Product OS recorded and knew the assertion.

~~~yaml
recorded_at:
superseded_at:
~~~

This enables questions such as:

~~~text
What relationship was valid during release execution?
What did the G7 authority know when it authorized release?
When did the graph learn that prior evidence was invalid?
Which relationship was backfilled after an incident?
~~~

Backfilled records preserve actual valid time and later recorded time.

---

# 9. Graph Revision

A graph revision identifies a reproducible assembled state.

~~~yaml
graph_revision:
  revision_id:
  namespace:
  parent_revision_refs: []
  transaction_refs: []
  valid_time_cutoff:
  system_time_cutoff:
  vocabulary_version:
  node_taxonomy_version:
  constraint_version:
  source_snapshot_refs: []
  generated_at:
  generated_by:
  integrity_ref:
~~~

Gate packs, coverage reports, and impact-discovery results bind one graph revision.

---

# 10. Graph Transaction

A graph mutation is applied through a governed transaction:

~~~yaml
graph_transaction_id:
transaction_type:
  - ADD_NODE
  - ADD_EDGE
  - REVISE_EDGE_ASSERTION
  - CONFIRM_EDGE
  - CONFLICT_EDGE
  - INVALIDATE_NODE
  - INVALIDATE_EDGE
  - SUPERSEDE_NODE
  - SUPERSEDE_EDGE
  - RETIRE_NODE
  - RETIRE_EDGE
  - RECORD_NA
  - CORRECT_METADATA
requested_by:
reason:
source_refs: []
affected_node_refs: []
affected_trace_refs: []
scope:
preconditions: []
validation_results: []
authority_refs: []
applied_by:
applied_at:
resulting_graph_revision:
rollback_or_compensation_ref:
~~~

Physical transactions may be implemented differently, but semantic atomicity and auditability remain.

---

# 11. Edge Status Transitions

Allowed primary transitions:

~~~text
PROPOSED → ACTIVE
PROPOSED → CONFIRMED
PROPOSED → CONFLICTED
PROPOSED → INVALIDATED

ACTIVE → CONFIRMED
ACTIVE → CONFLICTED
ACTIVE → INVALIDATED
ACTIVE → SUPERSEDED
ACTIVE → RETIRED

CONFIRMED → CONFLICTED
CONFIRMED → INVALIDATED
CONFIRMED → SUPERSEDED
CONFIRMED → RETIRED

CONFLICTED → ACTIVE
CONFLICTED → CONFIRMED
CONFLICTED → INVALIDATED
CONFLICTED → SUPERSEDED

NOT_APPLICABLE → INVALIDATED
NOT_APPLICABLE → SUPERSEDED
NOT_APPLICABLE → RETIRED
~~~

Historical statuses are not moved backward by editing. A new assertion version records the new status and authority.

---

# 12. Confidence Transitions

Confidence may strengthen or weaken when support changes.

~~~text
UNKNOWN → ASSUMED → INFERRED → SUPPORTED → CONFIRMED
CONFIRMED → SUPPORTED / INFERRED / UNKNOWN after invalidation or source loss
~~~

The actual transition need not follow every intermediate value.

A confidence change does not change edge status automatically. Both dimensions are reviewed.

---

# 13. Confirmation Record

~~~yaml
confirmation:
  trace_ref:
  evaluated_scope:
  evaluated_graph_revision:
  source_fitness_result:
  evidence_fitness_result:
  semantic_result:
  cardinality_result:
  conflict_result:
  reviewer:
  reviewer_role:
  independence:
  conflict_of_interest:
  authority_ref:
  decided_at:
  valid_until:
  resulting_status:
  resulting_confidence:
  conditions: []
~~~

Confirmation is a governed review, not a contributor-set flag.

---

# 14. N/A Assertion Record

`NOT_APPLICABLE_TO` uses a normal trace record plus:

~~~yaml
n_a_decision:
  reason_code:
  rationale:
  alternatives_considered: []
  evidence_refs: []
  deciding_authority:
  decided_at:
  valid_until:
  reopen_triggers: []
~~~

Its edge status is `NOT_APPLICABLE` and coverage extent is `NOT_APPLICABLE`.

---

# 15. Conflict Record

~~~yaml
trace_conflict_id:
subject_scope:
conflicting_trace_refs: []
conflicting_node_refs: []
conflict_type:
source_refs: []
evidence_refs: []
materiality_candidate:
affected_obligations: []
affected_gates: []
owner:
decision_question_ref:
due_event:
status:
resolution_decision_ref:
resolved_at:
resulting_trace_refs: []
~~~

The conflict record does not overwrite either assertion.

---

# 16. Invalidation Record

Invalidation identifies:

- invalidating event or source;
- exact invalidated node or edge assertion;
- scope and effective time;
- reason;
- evidence or decision;
- current-use restriction;
- candidate affected graph set;
- replacement or reopen route;
- authority where required.

Evidence invalidation marks that evidence no longer supports the claim. It does not delete the evidence node.

---

# 17. Supersession Modes

~~~text
ONE_TO_ONE
MERGE_MANY_TO_ONE
SPLIT_ONE_TO_MANY
PARTIAL_REPLACEMENT
SEMANTIC_RECLASSIFICATION
TOOL_MIGRATION_ONLY
~~~

Rules:

- new node points to old node with `SUPERSEDES`;
- old node retains `superseded_by` references;
- partial replacement states retained and replaced scope;
- merge and split preserve every predecessor and successor;
- tool-only migration cannot change semantic node identity;
- current queries choose the valid successor by scope and time rather than last-write order.

---

# 18. Concurrent Assertions

Concurrent assertions for the same endpoints and edge type are allowed only when they differ by:

- scope;
- valid time;
- source and confidence;
- proposal versus confirmed state;
- explicit conflict.

Duplicate equivalent assertions are consolidated under one logical trace identity or linked as tool mirrors.

Conflicting concurrent assertions remain separate and linked to a conflict record.

---

# 19. Provenance

Provenance distinguishes:

~~~text
HUMAN_ASSERTED
SOURCE_IMPORTED
TOOL_SYNCHRONIZED
RULE_DERIVED
AI_PROPOSED
BACKFILLED
MIGRATED
~~~

Imported, derived, synchronized, AI-proposed, and backfilled provenance does not establish confirmation.

`model_identity` is recorded when AI proposes or transforms a relationship. Prompts or reasoning content are retained only when policy and confidentiality allow and when required for reproducibility.

---

# 20. Integrity

Integrity references may bind:

- canonical node content;
- source snapshot;
- evidence content;
- edge assertion serialization;
- graph revision manifest;
- exported view.

Hash algorithms, signatures, attestations, and custody rules belong to later schema and Source / Evidence Model workstreams. The logical fields and requirement to prevent undetected substitution are established here.

---

# 21. Retention and Redaction

Retention is determined by the strongest applicable artifact, evidence, legal, contractual, security, privacy, audit, release, incident, and lifecycle obligation.

A redacted graph view preserves:

- stable node and trace identity where authorized;
- semantic class and edge type when disclosure permits;
- existence of restricted relationships;
- coverage and gap effect;
- access route and owning authority.

Redaction cannot make a required relationship appear absent or satisfied.

---

# 22. Migration and Compatibility

Graph migrations classify change as:

~~~text
BACKWARD_COMPATIBLE
REQUIRES_REINDEX
REQUIRES_ASSERTION_MIGRATION
BREAKING_SEMANTIC_CHANGE
~~~

Migration records vocabulary, node, edge, constraint, scope, status, confidence, time, projection, and tool impact.

A breaking semantic change requires a new framework version and explicit old-to-new mapping. Existing edge names are never silently reinterpreted.

---

# 23. Temporal Validation Rules

~~~text
TIME-VAL-001  Every material trace has stable logical identity and immutable assertion versions.
TIME-VAL-002  Every endpoint binds exact node version or immutable revision.
TIME-VAL-003  Every confirmed edge has valid time and system time sufficient for reconstruction.
TIME-VAL-004  Backfilled records preserve later recorded time and actual claimed valid time.
TIME-VAL-005  Every gate pack and coverage result binds one graph revision.
TIME-VAL-006  Material graph mutations occur through auditable transactions.
TIME-VAL-007  Status and confidence changes create new assertion versions.
TIME-VAL-008  N/A records preserve authority, validity, and reopen triggers.
TIME-VAL-009  Conflicts preserve every sourced assertion.
TIME-VAL-010  Invalidation preserves evidence and historical relationship state.
TIME-VAL-011  Merge, split, partial, reclassification, and tool-migration supersession modes are explicit.
TIME-VAL-012  Redaction preserves authorized gap and coverage meaning.
TIME-VAL-013  Graph migration never silently changes an existing edge meaning.
~~~

---

# 24. Final Temporal Principle

> **Traceability history is complete when Product OS can reconstruct both what was valid and what was known at the time of every material decision, without rewriting later knowledge into the past.**
