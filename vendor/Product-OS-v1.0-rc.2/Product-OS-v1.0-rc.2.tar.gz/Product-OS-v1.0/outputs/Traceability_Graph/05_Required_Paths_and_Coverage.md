# Product OS v1.0 — Required Paths and Coverage

~~~yaml
document_id: FRAMEWORK-TRACE-REQUIRED-PATHS-COVERAGE
version: 0.1.0
status: WORKING_DRAFT
completion_state: REQUIRED_PATHS_AND_COVERAGE_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
artifact_family_count: 13
gate_count: 13
coverage_status_count: 7
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification defines the relationship obligations that make cross-phase traceability complete for exact scope.

Coverage is not the number of links present. It is the result of evaluating activated relationship obligations against eligible graph edges.

---

# 2. Core Lifecycle Spine

~~~text
SOURCE
→ FACT / ASSUMPTION / QUESTION
→ DECISION / STANDARD / RISK / EXCEPTION
→ BUSINESS
→ PRODUCT
→ REQUIREMENT
→ EXPERIENCE
→ DESIGN
→ ARCHITECTURE
→ READINESS
→ IMPLEMENTATION
→ VERIFICATION / EVIDENCE
→ RELEASE
→ OPERATION
→ EVOLUTION / LIFECYCLE
→ earliest affected governed object or baseline
~~~

The spine describes required semantic reachability. It does not require one node in every class for every obligation. Direct allocation is allowed only when the owning methodology explicitly permits it and the skipped phase has an explicit disposition.

---

# 3. Minimum Cross-Phase Path Patterns

| Path ID | Required path | Activation |
|---|---|---|
| PATH-001 | ARTIFACT `GOVERNED_BY` GOV-001 or authorized governing artifact | Every project artifact instance |
| PATH-002 | Governed object `INCLUDED_IN` owning ARTIFACT | Every addressable owned object |
| PATH-003 | Downstream object `DERIVED_FROM` legitimate upstream source or authorized origin decision | Every approved non-origin object |
| PATH-004 | Accepted semantic object `BASELINED_IN` exact baseline | Every object claimed as baselined |
| PATH-005 | Business objective or capability → product responsibility or explicit disposition | Every in-scope business objective and capability |
| PATH-006 | Product capability or candidate → requirement set or explicit deferral/rejection | Every included product capability and candidate |
| PATH-007 | Requirement → acceptance and verification intent | Every approved requirement |
| PATH-008 | User-affecting requirement → experience object or approved direct/no-experience disposition | Every user-affecting requirement |
| PATH-009 | Experience object → design realization or approved no-visual-design disposition | Every baselined experience object |
| PATH-010 | Design object → implementation mapping and verification disposition | Every design subject intended for delivery |
| PATH-011 | Requirement, QAS, control, or risk → architecture satisfaction or explicit no-architecture disposition | Every architecture-relevant obligation |
| PATH-012 | Obligation, design, architecture, risk, exception, or change `ALLOCATED_TO` readiness | Every implementation-scope obligation before G5B |
| PATH-013 | In-scope obligation `IMPLEMENTED_BY` exact implementation | Every implementation-scope obligation before G6A |
| PATH-014 | Verifiable obligation `VERIFIED_BY` verification object | Every activated verification obligation before G6B |
| PATH-015 | Material result or decision `EVIDENCED_BY` reviewable evidence | Every gate-critical or live-control claim |
| PATH-016 | Release member `RELEASED_AS` release scope and release action `AUTHORIZED_BY` G7 decision | Every G7 release scope |
| PATH-017 | Release execution `DEPLOYED_TO` target and `OPERATES_AS` live identity | Every successful production release |
| PATH-018 | Live objective, control, or service `MEASURED_BY` or `OBSERVED_BY` period signal | Every claimed live outcome, SLO, or control-health state |
| PATH-019 | Incident, failure, insight, or lifecycle trigger → decision/route → `REOPENS`, `RETIRES`, or `TRANSFERRED_TO` target | Every material operational learning or lifecycle action |
| PATH-020 | Applicable standard → GOV-009 decision → phase obligations → verification/evidence → release/live scope | Every applicable GOV-009 entry |

---

# 4. Artifact-Family Relationship Obligations

| Family | Mandatory container relation | Required upstream reach | Required downstream or disposition reach |
|---|---|---|---|
| GOV | Every owned record `INCLUDED_IN` its GOV artifact | Constitution, source, question, authority, or governed trigger as applicable | Affected artifact, obligation, gate, evidence, or lifecycle scope |
| INIT | Every source and atomic item `INCLUDED_IN` INIT owner | External or authoritative source through `CAPTURED_FROM` | Discovery route, GOV-009 entry, decision, risk, or explicit disposition |
| DISC | Every finding, problem, outcome, and evidence object `INCLUDED_IN` DISC owner | ICB, source, fact, assumption, and question | Business object, product question, decision, or explicit no-action disposition |
| BUS | Every business object `INCLUDED_IN` BUS owner and accepted object `BASELINED_IN` BBL | Discovery outcome, source, standard, decision | Product responsibility, requirement source, KPI, manual/external disposition |
| PROD | Every product object `INCLUDED_IN` PROD owner and accepted object `BASELINED_IN` PBL | Business object, decision, user need, standard | Requirement set, experience implication, integration, release disposition |
| REQ | Every requirement and acceptance object `INCLUDED_IN` REQ owner and `BASELINED_IN` RBL | Business/product/standard/risk/decision origin | Experience, architecture, readiness, implementation, verification, release disposition |
| EXP | Every experience object `INCLUDED_IN` EXP owner and `BASELINED_IN` EBL | Product and requirement intent | Design realization, architecture implication, validation, or approved no-design disposition |
| DES | Every design object `INCLUDED_IN` DES owner and `BASELINED_IN` DBL | Experience, requirement, product policy | Architecture implication, readiness mapping, implementation adoption, verification |
| ARC | Every architecture object `INCLUDED_IN` ARC owner and accepted object `BASELINED_IN` ABL | Drivers, requirements, design constraints, risks, standards | Readiness allocation, implementation mechanism, fitness verification, operational control |
| ENG | Every readiness object `INCLUDED_IN` ENG owner and accepted scope `BASELINED_IN` ERBL | Approved obligations, design, architecture, risk, dependency | Implementation owner, repository/module, verification/evidence allocation, handoff |
| IMP | Every implementation object `INCLUDED_IN` IMP owner and accepted candidate `BASELINED_IN` IBL | Readiness allocation, requirement, design, architecture, defect, approved change | Verification candidate, cases, evidence, release candidate, operational handoff |
| VRL | Every verification/release object `INCLUDED_IN` VRL owner | Exact candidate, obligation, risk, control, target, environment | Result/evidence, defect/waiver, VBL, release decision, execution, live identity |
| OPS | Every live/evolution/lifecycle object `INCLUDED_IN` OPS owner and live state anchored in OBL | Actual release/brownfield origin, SLO/control obligation, evidence period | Insight, remediation/evolution route, reopen, transfer, retirement, outcome evidence |

This table applies to all 281 artifact identities through their family. It does not duplicate the Master Artifact Catalog rows.

---

# 5. Decision Path

Every material decision reaches:

~~~text
QUESTION or TRIGGER
← ANSWERS / TRIGGERED_BY
DECISION
→ DECIDES governed subject
→ AUTHORIZED_BY action where permission is granted
→ affected artifacts, baselines, gates, conditions, exceptions, risks, and evidence
→ validity and reopen path
~~~

A decision log entry with no decided subject is incomplete.

---

# 6. Assumption Path

~~~text
Source or reason
→ ASSUMPTION
← ASSUMES dependent objects
→ RISK if false
→ verification method or QUESTION
→ result / evidence
→ DECISION
→ affected gate and baseline
~~~

An expired assumption with active dependents creates a gap and impact-discovery trigger.

---

# 7. Risk and Exception Paths

Risk path:

~~~text
Source / fact / assumption
→ RISK
→ affected objectives, obligations, assets, users, and live scope through APPLIES_TO
← SATISFIES controls or mechanisms
→ MEASURED_BY / OBSERVED_BY detection
→ DECISION and evidence
~~~

Exception path:

~~~text
Original obligation
→ WAIVED_BY EXCEPTION
→ CONSTRAINED_BY compensating control or restriction
→ MEASURED_BY monitoring
→ AUTHORIZED_BY decision
→ EVIDENCED_BY support
→ validity, expiry, closure, or reopen
~~~

The original obligation remains current unless separately superseded or retired.

---

# 8. Defect and Incident Paths

Defect:

~~~text
Obligation or expected result
→ FAILED_BY defect / failed verification
→ decision and owning baseline
→ ALLOCATED_TO remediation
→ IMPLEMENTED_BY fix
→ VERIFIED_BY retest and regression
→ EVIDENCED_BY closure evidence
→ RELEASED_AS release
→ OBSERVED_BY live result
~~~

Incident:

~~~text
Live service or control
→ OBSERVED_BY incident / signal / evidence
→ impact and containment decision
→ root cause or contributing condition
→ REOPENS candidate affected baseline
→ authorized remediation route
→ implementation, verification, release, and recurrence monitoring
~~~

Incident-to-fix alone is insufficient because it loses affected baseline and control meaning.

---

# 9. Evolution and Lifecycle Paths

Evolution:

~~~text
Signal / feedback / outcome / incident
→ FACT and EVIDENCE
→ EVOLUTION insight
→ evolution candidate
→ DECISION
→ route
→ REOPENS earliest affected scope
→ changed baseline and delivery chain
→ live outcome validation
~~~

Sunset or transfer:

~~~text
Lifecycle trigger
→ DECISION
→ LIFECYCLE action
→ affected users, obligations, data, integrations, access, assets, and cost
→ migration / replacement / communication / support
→ VERIFIED_BY closure checks
→ EVIDENCED_BY retirement or transfer evidence
→ RETIRES old scope or TRANSFERRED_TO successor
~~~

---

# 10. Coverage Status

| Status | Meaning |
|---|---|
| COVERED | All activated relationship obligations for exact scope have eligible confirmed edges |
| PARTIALLY_COVERED | Some but not all required scope or obligations are covered |
| UNCOVERED | No eligible edge satisfies one or more active relationship obligations |
| CONFLICTED | Relationship evidence or authority conflicts prevent confirmed coverage |
| NOT_APPLICABLE | Authorized N/A disposition satisfies the obligation for exact scope |
| NOT_YET_REQUIRED | Trigger or due event has not activated the relationship obligation |
| INVALIDATED | Prior coverage exists historically but no longer supports current scope |

Coverage status is computed per obligation and scope. It is not manually set to improve reporting.

---

# 11. Coverage Eligibility Algorithm

~~~text
1. Select exact graph revision and evaluated valid time.
2. Resolve project namespace and evaluated scope.
3. Determine active relationship obligations from artifact, phase, gate, profile, domain override, and GOV-009.
4. Resolve expected from-class, edge type, to-class, and cardinality.
5. Find candidate edge records.
6. Validate endpoint identity, version, direction, domain, range, and scope.
7. Validate status, confidence, source, evidence, authority, validity, and conflicts.
8. Evaluate cardinality and coverage extent.
9. Apply governed N/A or not-yet-required disposition where valid.
10. Emit status, gap references, evidence, graph revision, and review time.
~~~

---

# 12. Coverage Record

~~~yaml
coverage_result_id:
relationship_obligation_ref:
graph_revision:
evaluated_valid_time:
evaluated_scope:
profile_and_overrides:
required_edge_type:
required_from_set:
required_to_set:
minimum_cardinality:
candidate_trace_refs: []
eligible_trace_refs: []
ineligible_trace_refs: []
status:
covered_scope:
uncovered_scope:
gap_refs: []
conflict_refs: []
n_a_decision_ref:
evidence_refs: []
evaluated_by:
evaluated_at:
reviewer:
review_status:
valid_until:
~~~

---

# 13. Coverage Dimensions

Required reporting separates:

~~~text
Artifact registration coverage
Source and decision coverage
Business-to-product coverage
Product-to-requirement coverage
Requirement and acceptance coverage
Experience and state coverage
Design and adoption coverage
Architecture and control coverage
Engineering allocation coverage
Implementation coverage
Verification and evidence coverage
Release and candidate coverage
Live identity and operational coverage
Evolution and lifecycle coverage
Standards and control coverage
~~~

A total percentage never hides a critical uncovered dimension.

---

# 14. Criticality and Threshold Rule

Gate Specifications determine whether uncovered scope blocks a gate.

The graph reports:

- criticality and profile from canonical sources;
- uncovered and conflicted obligations;
- stale or invalid evidence;
- N/A decisions;
- affected gates and conditions.

The graph does not convert a numeric threshold into approval.

---

# 15. Direct Allocation and Skipped Phase

A direct edge across non-adjacent lifecycle classes is accepted only when:

1. the owning methodology permits direct treatment;
2. the skipped phase has no applicable semantic obligation or has an explicit disposition;
3. exact rationale and authority exist;
4. required gates and review are not bypassed;
5. coverage views show the direct path distinctly;
6. downstream consumers can identify what was not produced and why.

Direct allocation cannot conceal missing experience, design, architecture, security, accessibility, data, verification, or evidence work.

---

# 16. Historical Coverage

Coverage results bind graph revision and time.

After change:

- prior coverage remains historically valid for its original decision if it was valid then;
- current coverage may become invalidated;
- a new result evaluates the new scope and graph revision;
- old percentages are not reused as current evidence;
- superseded and retired paths remain queryable.

---

# 17. Path and Coverage Validation Rules

~~~text
PATH-VAL-001  Every project artifact instance has an ARTIFACT node and governing relation.
PATH-VAL-002  Every governed object is included in one canonical owning artifact.
PATH-VAL-003  Every approved non-origin object reaches a legitimate upstream source or origin decision.
PATH-VAL-004  Every accepted semantic object reaches its exact baseline.
PATH-VAL-005  Every activated relationship obligation has a coverage result.
PATH-VAL-006  Coverage uses eligible edges rather than raw links.
PATH-VAL-007  Partial scope preserves uncovered remainder and owner.
PATH-VAL-008  N/A and not-yet-required remain distinct from missing.
PATH-VAL-009  Every release scope reaches candidate, VBL, G7 authorization, execution, target, and live identity.
PATH-VAL-010  Every applicable GOV-009 entry reaches live evidence or a visible gap.
PATH-VAL-011  Defects and incidents retain baseline, remediation, retest, release, and live-result lineage.
PATH-VAL-012  Evolution and lifecycle paths return to authorized Product OS routes.
PATH-VAL-013  Direct allocation cannot bypass applicable phase or gate obligations.
PATH-VAL-014  Historical coverage remains bound to its graph revision and decision time.
PATH-VAL-015  A total percentage cannot override a critical uncovered, conflicted, or invalidated obligation.
~~~

---

# 18. Final Coverage Principle

> **Coverage exists when every activated relationship obligation has exact, eligible, evidence-aware lineage or an authorized explicit disposition—not when every row contains a link.**
