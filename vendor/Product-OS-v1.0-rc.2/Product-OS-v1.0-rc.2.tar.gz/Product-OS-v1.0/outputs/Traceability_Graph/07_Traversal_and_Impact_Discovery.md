# Product OS v1.0 — Traversal and Impact Discovery

~~~yaml
document_id: FRAMEWORK-TRACE-TRAVERSAL-IMPACT-DISCOVERY
version: 0.1.0
status: WORKING_DRAFT
completion_state: TRAVERSAL_AND_IMPACT_DISCOVERY_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
downstream_boundary: CHANGE_IMPACT_RULES
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification defines reproducible traversal of GOV-008 and generation of candidate impact sets.

It answers where relationships lead. It does not decide whether a discovered object is materially affected, still valid, invalid, or approved for no action.

---

# 2. Traversal Types

| Traversal | Question |
|---|---|
| Upstream lineage | Why does this object exist and which source, obligation, decision, or evidence supports it? |
| Downstream realization | Where is this object refined, realized, allocated, implemented, verified, released, operated, and measured? |
| Governance | Which rules, standards, risks, exceptions, decisions, and authorities govern this scope? |
| Coverage | Which activated relationship obligations have eligible edges or gaps? |
| Supersession | Which prior and successor versions represent the object over time? |
| Release-to-live | Which exact candidate, decision, target, execution, and live identity correspond? |
| Live-to-origin | Which released obligations and baselines explain the live behavior? |
| Evolution return | Which live signal, insight, decision, route, and earlier lifecycle point form the feedback loop? |
| Impact discovery | Which nodes, edges, evidence, gates, releases, and live scopes are candidates for review after change? |

---

# 3. Traversal Request

~~~yaml
traversal_request_id:
purpose:
graph_revision:
as_of_valid_time:
as_of_recorded_time:
start_node_refs: []
start_trace_refs: []
namespace:
scope_filter:
direction:
edge_type_allowlist: []
edge_type_denylist: []
node_class_allowlist: []
status_policy:
confidence_policy:
coverage_policy:
include_invalidated_history:
include_superseded_history:
include_conflicts:
maximum_depth:
stop_conditions: []
requested_by:
requested_at:
~~~

`maximum_depth` protects execution. It cannot be used to claim complete impact when valid paths were truncated.

---

# 4. Traversal Eligibility Policies

~~~text
CONFIRMED_CURRENT
ACTIVE_AND_CONFIRMED
DISCOVERY_INCLUSIVE
HISTORICAL_AS_OF
CONFLICT_ANALYSIS
~~~

| Policy | Included edges |
|---|---|
| CONFIRMED_CURRENT | Current `CONFIRMED` status, `CONFIRMED` confidence, valid support, exact current scope |
| ACTIVE_AND_CONFIRMED | Current ACTIVE or CONFIRMED edges with confidence and support exposed |
| DISCOVERY_INCLUSIVE | Proposed, active, confirmed, conflicted, inferred, assumed, and unknown candidates with labels preserved |
| HISTORICAL_AS_OF | Edges valid and known at requested valid and recorded time |
| CONFLICT_ANALYSIS | All overlapping assertions relevant to the conflict, including invalidated and superseded history |

Gate coverage normally uses `CONFIRMED_CURRENT`. Impact discovery uses `DISCOVERY_INCLUSIVE` plus a separate confirmed-path result so uncertainty is not hidden.

---

# 5. Upstream Edge Orientation

Upstream traversal follows relationship meaning toward origin, obligation, governance, or support.

Common stored directions traversed forward:

~~~text
CAPTURED_FROM
SUPPORTED_BY
ASSUMES
DERIVED_FROM
REFINES
SATISFIES
REALIZES
DEPENDS_ON
CONSTRAINED_BY
GOVERNED_BY
BASELINED_IN
AUTHORIZED_BY
EVIDENCED_BY
~~~

Common stored directions traversed in inverse query direction:

~~~text
DECOMPOSES_TO
ALLOCATED_TO
IMPLEMENTED_BY
VERIFIED_BY
RELEASED_AS
DEPLOYED_TO
OPERATES_AS
MEASURED_BY
OBSERVED_BY
~~~

Direction choice is query behavior and never creates inverse stored edges.

---

# 6. Downstream Edge Orientation

Downstream traversal moves toward decomposition, realization, delivery, verification, release, live behavior, or lifecycle effect.

It normally uses the inverse of origin-pointing edges and the forward direction of:

~~~text
DECOMPOSES_TO
ALLOCATED_TO
IMPLEMENTED_BY
VERIFIED_BY
EVIDENCED_BY when moving from claim to proof
RELEASED_AS
DEPLOYED_TO
OPERATES_AS
MEASURED_BY
OBSERVED_BY
REOPENS
INVALIDATES
SUPERSEDES
RETIRES
TRANSFERRED_TO
~~~

The traversal record preserves whether each hop used stored or inverse query orientation.

---

# 7. Path Record

~~~yaml
trace_path_id:
traversal_request_ref:
graph_revision:
start_node_ref:
end_node_ref:
hops:
  - sequence:
    trace_ref:
    stored_from_node_ref:
    stored_edge_type:
    stored_to_node_ref:
    query_orientation:
    traversed_from_node_ref:
    traversed_to_node_ref:
    edge_status:
    relationship_confidence:
    scope_intersection:
    valid_time_intersection:
path_scope:
path_valid_time:
path_status:
minimum_confidence:
contains_conflict:
contains_gap:
contains_invalidated_history:
computed_at:
computed_by:
~~~

Path confidence cannot exceed the weakest required hop.

---

# 8. Scope Intersection

Each hop narrows the current traversal scope to the intersection of:

- request scope;
- from-node scope;
- edge scope;
- to-node scope;
- valid-time interval;
- applicability and profile partition.

When intersection is empty, the path stops for that branch.

When only part intersects, the path records partial scope and preserves the untraversed remainder as a candidate gap or separate branch.

---

# 9. Cycle Handling

Traversal maintains visited state by:

~~~text
node key + edge family + scope partition + valid-time interval
~~~

Rules:

- cycles in acyclic edge families are validation findings;
- dependency strongly-connected components are condensed into one traversal component while retaining members;
- lifecycle return paths are allowed and labeled;
- repeated visits with narrower scope are allowed when they add distinct meaning;
- traversal terminates when no new scoped state is discovered.

Cycle breaking cannot discard members from the result.

---

# 10. Stop Conditions

Valid stop conditions include:

- exact target node reached;
- owning artifact or phase boundary reached;
- approved baseline or gate decision reached;
- source, evidence, release, live, or lifecycle class reached;
- scope intersection becomes empty;
- configured depth or resource limit reached;
- access restriction prevents further resolution;
- unresolved node or edge prevents continuation.

Depth, access, resource, or unresolved stops mark the traversal incomplete for affected branches.

---

# 11. Impact Discovery Trigger

Impact discovery activates for material candidate changes to:

- node content, identity, version, scope, owner, status, or applicability;
- edge meaning, status, confidence, scope, evidence, or validity;
- baseline, candidate, target, configuration, standard, exception, or release;
- source authority or evidence fitness;
- live identity, incident, control health, outcome, vendor, or lifecycle state;
- vocabulary, constraints, schema, repository, or tool mapping.

The trigger may be proposed before materiality is decided.

---

# 12. Impact Discovery Algorithm

~~~text
1. Bind changed node or edge assertions and old/new versions.
2. Bind exact namespace, scope, valid time, and graph revision.
3. Identify directly attached relationships, obligations, gaps, conflicts, and evidence.
4. Traverse downstream realization, allocation, implementation, verification, release, live, and lifecycle paths.
5. Traverse governing, dependency, applicability, exception, and condition paths.
6. Include inverse dependents and relationship-group members.
7. Detect invalidated support and stale evidence.
8. Partition results by artifact, phase, gate, release, target, live scope, and profile override.
9. Identify candidate earliest affected lifecycle points from owning artifacts and baselines.
10. Preserve uncertain, access-blocked, missing, conflicting, and truncated branches.
11. Emit the candidate impact set with path evidence.
12. Hand off to Change Impact Rules for materiality, disposition, action, authority, and closure.
~~~

---

# 13. Candidate Impact Status

Graph discovery uses non-decisional statuses:

~~~text
DISCOVERED_DIRECT
DISCOVERED_TRANSITIVE
DISCOVERED_DEPENDENCY
DISCOVERED_GOVERNANCE
DISCOVERED_SCOPE_OVERLAP
UNCERTAIN_MISSING_PATH
UNCERTAIN_CONFLICT
UNRESOLVED_ACCESS
TRUNCATED
~~~

These do not mean affected, unaffected, partial, invalid, no impact, or approved remediation.

---

# 14. Impact Discovery Record

~~~yaml
impact_discovery_id:
trigger_ref:
change_ref:
old_node_or_trace_refs: []
new_node_or_trace_refs: []
graph_revision:
evaluated_scope:
as_of_valid_time:
traversal_policy:
confirmed_candidate_nodes: []
uncertain_candidate_nodes: []
candidate_trace_refs: []
candidate_artifacts: []
candidate_phases: []
candidate_baselines: []
candidate_gates: []
candidate_evidence: []
candidate_conditions_exceptions_risks: []
candidate_releases_targets: []
candidate_live_scope: []
candidate_earliest_phase:
gap_refs: []
conflict_refs: []
access_blockers: []
truncated_branches: []
path_refs: []
generated_by:
generated_at:
review_required:
change_impact_handoff_ref:
~~~

---

# 15. Candidate Earliest Phase

The graph computes the earliest candidate phase by:

1. resolving owning artifact and baseline for each discovered node;
2. excluding purely historical paths outside changed scope;
3. preserving uncertain branches;
4. ordering Phase 00 through Phase 11;
5. selecting the earliest phase with a current candidate dependency;
6. recording every supporting path and competing candidate.

Change Impact Rules and authorized owners decide the actual earliest affected phase.

---

# 16. Missing Edge Guardrail

Absence of a discovered path is not proof of no impact.

If a required relationship is missing, the impact set includes:

- the gap;
- the object whose dependency is unknown;
- candidate downstream family or scope from the relationship obligation;
- review owner;
- restriction on no-impact claims.

`NO_IMPACT` cannot be generated by this specification.

---

# 17. Evidence and Validity Propagation

When support changes, traversal includes:

- claims `SUPPORTED_BY` or `EVIDENCED_BY` the source;
- decisions and baselines relying on those claims;
- verification and release claims using the evidence;
- live control or outcome claims covering the evidence period;
- conditions, exceptions, and risks whose authority depends on it.

Evidence freshness rules come from the owning claim and [Source / Evidence Model](../Source_Evidence_Model/Source_Evidence_Model_Index.md).

---

# 18. Change Examples

## 18.1 Requirement meaning change

~~~text
Changed REQUIREMENT
→ EXPERIENCE and DESIGN realizations
→ ARCHITECTURE satisfaction and constraints
→ READINESS allocations
→ IMPLEMENTATION objects
→ VERIFICATION cases/results/evidence
→ RELEASE scopes and decisions
→ OPERATION live scope and measures
~~~

## 18.2 Design token correction

~~~text
Changed DESIGN token
→ dependent components and screens
→ implementation adoption
→ visual/accessibility verification
→ affected release and live variants
~~~

Upstream requirement or product baselines appear only when actual paths or uncertain gaps indicate possible semantic impact.

## 18.3 Vendor end-of-life

~~~text
OPERATION vendor signal
→ dependent architecture and product boundary
→ requirements and standards obligations where affected
→ readiness, implementation, verification, release, and migration
→ transfer or retirement route
~~~

---

# 19. Traversal Result Integrity

Every result records:

- graph revision;
- exact request;
- algorithm and rule version;
- status/confidence policy;
- filters;
- path set;
- access and truncation limits;
- execution tool and version;
- generation time;
- integrity reference where required.

Two reviewers using the same graph revision and request must receive equivalent semantic results.

---

# 20. AI and Automation

AI may rank, summarize, cluster, and explain candidate impact paths after deterministic graph results are preserved.

AI-proposed semantic paths remain candidates and do not merge with confirmed traversal silently.

Automation may compute reachability, scope intersection, strongly-connected components, stale support, and candidate earliest phase. It cannot decide materiality, no impact, risk acceptance, gate reopen, or closure.

---

# 21. Traversal Validation Rules

~~~text
TRAV-VAL-001  Every traversal binds graph revision, valid time, namespace, scope, and eligibility policy.
TRAV-VAL-002  Every path records stored edge direction and query orientation.
TRAV-VAL-003  Path scope equals the valid intersection of every hop.
TRAV-VAL-004  Path confidence does not exceed its weakest required hop.
TRAV-VAL-005  Cycles in acyclic edge families create findings.
TRAV-VAL-006  Dependency components preserve all members and consequences.
TRAV-VAL-007  Truncated, access-blocked, missing, and conflicting branches remain explicit.
TRAV-VAL-008  Impact discovery includes direct, transitive, dependency, governance, evidence, release, and live paths as applicable.
TRAV-VAL-009  Missing paths prohibit automatic no-impact claims.
TRAV-VAL-010  Candidate earliest phase retains supporting and competing paths.
TRAV-VAL-011  Impact discovery statuses are not final impact dispositions.
TRAV-VAL-012  Change Impact Rules receive exact candidate sets and path evidence.
TRAV-VAL-013  AI-proposed paths remain distinguishable from confirmed graph traversal.
~~~

---

# 22. Final Traversal Principle

> **Traversal is complete when every reachable and uncertain branch is reproducible for exact scope, while the graph remains honest that discovering a path is not the same as deciding its material impact.**
