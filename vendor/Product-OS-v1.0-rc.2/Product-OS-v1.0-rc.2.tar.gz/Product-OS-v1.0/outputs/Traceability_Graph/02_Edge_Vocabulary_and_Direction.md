# Product OS v1.0 — Edge Vocabulary and Direction

~~~yaml
document_id: FRAMEWORK-TRACE-EDGE-VOCABULARY
version: 0.1.0
status: WORKING_DRAFT
completion_state: EDGE_VOCABULARY_COMPLETE
inherits: SHARED-TRACEABILITY-GRAPH-CONTRACT@0.1.0
canonical_edge_type_count: 40
renamed_legacy_edges: 0
removed_legacy_edges: 0
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This specification freezes the meaning and stored direction of the 40 canonical Product OS trace edge types.

Each edge type represents one relationship. Similar wording, inverse display labels, and tool-specific link types do not create additional canonical meanings.

---

# 2. Canonical Direction Rule

Canonical notation:

~~~text
FROM_NODE  EDGE_TYPE  TO_NODE
~~~

The edge sentence must read truthfully in that direction.

Example:

~~~text
REQ-FR-021  VERIFIED_BY  VCASE-090
~~~

The verification tool may display:

~~~text
VCASE-090  VERIFIES  REQ-FR-021
~~~

`VERIFIES` is a query label, not another stored edge type.

---

# 3. Vocabulary Register

| ID | Edge type | Canonical relationship | Allowed inverse display | Exact meaning |
|---|---|---|---|---|
| EDGE-001 | CAPTURED_FROM | Atomic or governed item → source | SOURCE_OF_CAPTURE | The from-node was extracted, observed, or registered from the exact source without implying approval or support quality. |
| EDGE-002 | SUPPORTED_BY | Claim-bearing node → source, fact, or evidence | SUPPORTS | The to-node provides relevant support for the from-node’s claim; sufficiency and authority remain separately evaluated. |
| EDGE-003 | CONTRADICTS | Deterministically ordered assertion → conflicting assertion | CONTRADICTS | The two nodes assert materially incompatible meaning for overlapping scope; stored direction follows the deterministic ordering rule because the relation is symmetric. |
| EDGE-004 | ASSUMES | Dependent node → assumption | ASSUMED_BY | The from-node’s current meaning or feasibility depends on the to-assumption being true. |
| EDGE-005 | ANSWERS | Answer, fact, evidence, or decision → question | ANSWERED_BY | The from-node supplies a governed answer or resolution to the to-question. |
| EDGE-006 | DECIDES | Decision → governed subject or route | DECIDED_BY | The from-decision selects, rejects, authorizes, constrains, or dispositions the to-subject for exact scope. |
| EDGE-007 | DERIVED_FROM | Derived or downstream node → source or upstream node | DERIVES | The from-node’s meaning was produced from the to-node through an accountable derivation. |
| EDGE-008 | REFINES | More specific node → broader node | REFINED_BY | The from-node narrows, elaborates, or makes the to-node more precise without changing its approved intent silently. |
| EDGE-009 | DECOMPOSES_TO | Parent or aggregate node → child node | PART_OF_DECOMPOSITION | The to-node is a governed part of the from-node’s decomposition. |
| EDGE-010 | BOUNDS | Boundary, scope, rule, or decision → bounded node | BOUNDED_BY | The from-node defines an inclusion, exclusion, limit, responsibility, time, population, or state boundary on the to-node. |
| EDGE-011 | SATISFIES | Mechanism, decision, or realization → obligation or quality target | SATISFIED_BY | The from-node contributes evidence-backed satisfaction of the to-obligation for exact scope; partial contribution is recorded explicitly. |
| EDGE-012 | REALIZES | Downstream experience, design, or product object → upstream intent | REALIZED_BY | The from-node expresses the to-node in a more concrete product, experience, or design form. |
| EDGE-013 | ALLOCATED_TO | Obligation, risk, control, or change → readiness object | RECEIVES_ALLOCATION | The from-node has accountable planned work or evidence responsibility in the to-readiness object. |
| EDGE-014 | IMPLEMENTED_BY | Obligation, design, architecture, defect, or change → implementation object | IMPLEMENTS | The to-node is the exact source, schema, configuration, infrastructure, artifact, or candidate implementation of the from-node. |
| EDGE-015 | CONFIGURED_BY | Behavior, implementation, release, or live node → configuration node | CONFIGURES | The from-node’s effective behavior depends on the exact to-configuration or feature-flag revision. |
| EDGE-016 | MIGRATED_BY | Data, interface, product, implementation, or lifecycle scope → migration implementation | MIGRATES | The to-node performs or governs migration of the from-node’s affected state or population. |
| EDGE-017 | VERIFIED_BY | Obligation, risk, control, change, or acceptance object → verification object | VERIFIES | The to-node defines or executes verification of the from-node for exact target and scope. |
| EDGE-018 | EVIDENCED_BY | Claim, result, decision, control, release, or operation → evidence | EVIDENCES | The to-node is reviewable evidence for the exact claim represented by the from-node. |
| EDGE-019 | FAILED_BY | Obligation, control, verification target, or expected outcome → failure object | FAILS | The to-node records a defect, failed result, incident, or harmful signal showing that the from-node was not satisfied for exact scope. |
| EDGE-020 | WAIVED_BY | Obligation, check, control, or requirement → exception or waiver | WAIVES | The to-node authorizes a scoped departure while preserving the original from-obligation. |
| EDGE-021 | DEPENDS_ON | Dependent node → dependency node | REQUIRED_BY | The from-node requires the to-node’s availability, behavior, decision, data, timing, or capability. |
| EDGE-022 | CONSTRAINED_BY | Governed node → constraint, standard, rule, decision, risk treatment, or architecture boundary | CONSTRAINS | The to-node limits the valid choices or behavior of the from-node. |
| EDGE-023 | GOVERNED_BY | Node or artifact → governing rule, artifact, authority decision, or policy | GOVERNS | The to-node supplies the controlling governance contract for the from-node. |
| EDGE-024 | APPLIES_TO | Standard, obligation, decision, risk, exception, or policy → target node | HAS_APPLICABLE | The from-node is applicable to the to-node for the bound scope under valid authority. |
| EDGE-025 | NOT_APPLICABLE_TO | Standard, obligation, control, or decision subject → target node | HAS_NA | An authorized decision states that the from-node does not apply to the exact to-scope and records why and when to reopen. |
| EDGE-026 | INCLUDED_IN | Member node → artifact, baseline, scope, candidate, release, or portfolio container | INCLUDES | The from-node is explicitly part of the to-container for the bound version and scope. |
| EDGE-027 | EXCLUDED_FROM | Candidate member or obligation → artifact, baseline, scope, candidate, release, or portfolio container | EXCLUDES | The from-node is explicitly outside the to-container with a governed disposition. |
| EDGE-028 | BASELINED_IN | Approved semantic node → baseline artifact or baseline object | BASELINES | The from-node’s exact version is accepted as part of the to-baseline. |
| EDGE-029 | AUTHORIZED_BY | Action, release, exception, change, transfer, or operational route → decision | AUTHORIZES | The to-decision grants valid authority for the from-node’s exact action and scope. |
| EDGE-030 | RELEASED_AS | Product, requirement, change, defect fix, or implementation object → release object | RELEASES | The from-node is represented in the exact to-release scope or execution identity. |
| EDGE-031 | DEPLOYED_TO | Release execution or deployable implementation → operational target | RECEIVES_DEPLOYMENT | The from-node was deployed to the exact to-environment, service, region, slot, cohort, or target. |
| EDGE-032 | OPERATES_AS | Release execution, deployed artifact, or implementation revision → live operational identity | RUNS_FROM | The from-node is the technical origin of the to-live identity during the bound period. |
| EDGE-033 | MEASURED_BY | Objective, obligation, control, service, or outcome → metric, SLI, SLO, or measurement object | MEASURES | The to-node measures behavior or outcome of the from-node under an explicit definition and period. |
| EDGE-034 | OBSERVED_BY | Behavior, outcome, risk, control, or live object → fact, evidence, signal, feedback, or incident | OBSERVES | The to-node records an observation about the from-node without automatically proving cause. |
| EDGE-035 | TRIGGERED_BY | Question, decision, review, change, response, route, or lifecycle action → triggering node | TRIGGERS | The to-node caused the from-node’s workflow, review, or decision need to activate. |
| EDGE-036 | REOPENS | Incident, evidence, decision, evolution route, or lifecycle trigger → affected baseline, gate decision, or governed object | REOPENED_BY | The from-node requires authorized re-evaluation of the to-node for exact scope; the edge records the trigger, not the final impact disposition. |
| EDGE-037 | INVALIDATES | New fact, evidence, decision, failure, release, operation, or lifecycle event → invalidated node | INVALIDATED_BY | The from-node makes the to-node or its current claim unusable for the bound scope and time. |
| EDGE-038 | SUPERSEDES | New node version or replacement node → prior node | SUPERSEDED_BY | The from-node replaces the to-node’s current role while preserving historical identity and migration semantics. |
| EDGE-039 | RETIRES | Lifecycle decision or retirement action → retired node | RETIRED_BY | The from-node ends active use or support of the to-node for exact scope under authority. |
| EDGE-040 | TRANSFERRED_TO | Transferred product, service, obligation, asset, or ownership scope → successor node | RECEIVES_TRANSFER | Responsibility or custody for the from-node moves to the to-node under a governed transfer. |

---

# 4. Symmetric Edge Rule

`CONTRADICTS` is the only symmetric relationship in version 0.1.0.

Store one record using this deterministic endpoint order:

~~~text
normalized node key with lower lexical byte order
→ CONTRADICTS
normalized node key with higher lexical byte order
~~~

The ordering has no semantic priority. Query results display the relationship symmetrically.

`DEPENDS_ON` is not symmetric. Mutual dependency requires two directed edges and triggers cycle analysis.

---

# 5. Hierarchy Edge Separation

| Edge | Use when | Do not use when |
|---|---|---|
| REFINES | Child adds precision to parent meaning | Child is merely a part or implementation |
| DECOMPOSES_TO | Parent is partitioned into governed children | Child changes semantic level through realization |
| INCLUDED_IN | Object is a member of a container, baseline, scope, or release | Object derives meaning from the container |
| BASELINED_IN | Exact approved object version belongs to a baseline | Object is only proposed or physically located in a file |
| DERIVED_FROM | Meaning was produced from an upstream source or object | Relationship is only membership or dependency |

A child may require more than one of these relationships when each meaning is independently true.

---

# 6. Realization Edge Separation

| Edge | Canonical from-node | Canonical to-node | Claim strength |
|---|---|---|---|
| REALIZES | Product, experience, or design realization | Upstream intent | Concrete expression of intent |
| SATISFIES | Mechanism or approved realization | Obligation or quality target | Evidence-backed satisfaction contribution |
| IMPLEMENTED_BY | Obligation or design/architecture target | Exact implementation object | Technical implementation identity |
| VERIFIED_BY | Obligation, risk, or control | Verification object | Verification allocation or execution |
| EVIDENCED_BY | Claim or result | Evidence item | Support for the exact claim |

`REALIZES` does not prove full satisfaction. `IMPLEMENTED_BY` does not prove verification. `VERIFIED_BY` does not prove a passing result unless the target verification result and evidence say so.

---

# 7. Governance Edge Separation

| Edge | Meaning |
|---|---|
| GOVERNED_BY | Identifies the controlling rule, policy, artifact, or authority contract |
| CONSTRAINED_BY | Identifies a limit on valid choices or behavior |
| APPLIES_TO | Records positive applicability to exact scope |
| NOT_APPLICABLE_TO | Records authorized negative applicability to exact scope |
| WAIVED_BY | Records an approved departure while retaining the original obligation |
| AUTHORIZED_BY | Records permission for an action, release, exception, or route |

These edges cannot substitute for one another.

---

# 8. Release and Operation Separation

~~~text
Product, requirement, change, fix, or implementation
  RELEASED_AS
Release scope or execution
  DEPLOYED_TO
Operational target

Release execution or deployed artifact
  OPERATES_AS
Live service identity

Live service or outcome
  MEASURED_BY / OBSERVED_BY
Metric, signal, evidence, incident, or feedback
~~~

Release inclusion, deployment, live operation, health, and realized outcome remain different claims.

---

# 9. Change and Lifecycle Separation

| Edge | Change meaning |
|---|---|
| TRIGGERED_BY | Explains why a review, question, action, or route began |
| REOPENS | Identifies a target that requires re-evaluation |
| INVALIDATES | States that prior current meaning is no longer usable for exact scope |
| SUPERSEDES | Replaces prior meaning with a governed new identity |
| RETIRES | Ends active use or support under authority |
| TRANSFERRED_TO | Moves responsibility or custody to a successor |

`REOPENS` does not mean `INVALIDATES`. Review may confirm that the target remains valid.

---

# 10. Partial Relationship Contract

When a relationship covers only part of the target obligation, the edge records:

~~~yaml
coverage_extent: PARTIAL
covered_scope:
excluded_scope:
remaining_obligation_refs: []
completion_owner:
due_event:
~~~

Partial coverage cannot be represented by an unqualified full-scope edge.

---

# 11. Negative Relationship Contract

`NOT_APPLICABLE_TO` and `EXCLUDED_FROM` are not missing positive edges.

Both require:

- exact source and target;
- scope;
- reason;
- decision authority;
- evidence where required;
- validity;
- reopen triggers;
- historical preservation.

`EXCLUDED_FROM` says the object is outside a container or release. `NOT_APPLICABLE_TO` says an obligation or standard does not apply.

---

# 12. Edge Synonym Policy

Tool-specific relationships map to one canonical type.

Examples:

| Tool relationship | Canonical mapping |
|---|---|
| implements, implemented in, source for | IMPLEMENTED_BY in canonical direction |
| tested by, covered by test | VERIFIED_BY |
| proof, attachment, evidence link | EVIDENCED_BY when semantic support is valid |
| parent, child | REFINES, DECOMPOSES_TO, or INCLUDED_IN after meaning review |
| blocks, needs | DEPENDS_ON when dependency semantics are exact |
| affects | No direct mapping; choose an exact edge or record an unresolved candidate impact |
| related to | No direct mapping; relationship meaning must be classified |

Generic `related_to`, `linked_to`, `maps_to`, `affects`, and `associated_with` are prohibited as canonical edges.

---

# 13. Edge Extension Rule

A new edge type is allowed only when none of the 40 types expresses the required relationship without semantic distortion.

The proposal includes:

~~~yaml
proposed_edge_type:
definition:
canonical_sentence:
inverse_display:
domain_type_set:
range_type_set:
cardinality:
symmetry:
transitivity:
acyclicity:
required_sources:
coverage_behavior:
existing_edge_comparison: []
migration_impact:
approving_authority:
~~~

Project-local synonyms are not extensions.

---

# 14. Edge Vocabulary Validation Rules

~~~text
EDGE-VAL-001  Every stored edge uses one of the 40 canonical edge types.
EDGE-VAL-002  Every edge sentence is true in canonical direction.
EDGE-VAL-003  Query inverse labels never create duplicate stored relationship truth.
EDGE-VAL-004  CONTRADICTS uses deterministic storage order and symmetric query behavior.
EDGE-VAL-005  Generic related, mapped, associated, or affected links do not enter canonical coverage.
EDGE-VAL-006  REALIZES, SATISFIES, IMPLEMENTED_BY, VERIFIED_BY, and EVIDENCED_BY remain separate claims.
EDGE-VAL-007  GOVERNED_BY, CONSTRAINED_BY, APPLIES_TO, NOT_APPLICABLE_TO, WAIVED_BY, and AUTHORIZED_BY remain separate claims.
EDGE-VAL-008  RELEASED_AS, DEPLOYED_TO, OPERATES_AS, MEASURED_BY, and OBSERVED_BY remain separate claims.
EDGE-VAL-009  REOPENS does not imply INVALIDATES.
EDGE-VAL-010  Partial relationships bind covered and remaining scope explicitly.
EDGE-VAL-011  Negative relationships carry decision, scope, evidence, validity, and reopen data.
EDGE-VAL-012  A project cannot change an edge meaning through a tool label or local convention.
~~~

---

# 15. Final Edge Principle

> **An edge earns canonical status only when its verb states one exact relationship in one exact direction and cannot be mistaken for approval, satisfaction, implementation, verification, release, or impact that did not actually occur.**
