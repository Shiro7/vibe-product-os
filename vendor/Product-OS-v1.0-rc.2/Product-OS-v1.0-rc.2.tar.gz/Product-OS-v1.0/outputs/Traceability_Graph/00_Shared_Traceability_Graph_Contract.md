# Product OS v1.0 — Shared Traceability Graph Contract

~~~yaml
contract_id: SHARED-TRACEABILITY-GRAPH-CONTRACT
contract_version: 0.1.0
contract_status: WORKING_DRAFT
completion_state: SHARED_GRAPH_CONTRACT_COMPLETE
asset_class: PRODUCT_OS_FRAMEWORK_ASSET
governed_project_artifact: GOV-008
project_artifact_count_impact: NONE
node_taxonomy: NODE-TAXONOMY@0.1.0
edge_vocabulary: EDGE-VOCABULARY@0.1.0
approval_state: PRODUCT_OS_AUTHORITY_APPROVAL_PENDING
baseline_state: NOT_BASELINED
last_reconciled: 2026-08-12
~~~

---

# 1. Purpose

This contract defines the obligations inherited by every Product OS `GOV-008` graph implementation, node, edge, projection, traversal, coverage result, and graph-integrity review.

It standardizes:

- graph authority and source-of-truth boundaries;
- canonical identity and namespaces;
- node and edge registration;
- endpoint, scope, version, time, and provenance binding;
- status, confidence, applicability, disposition, and coverage separation;
- contribution, review, confirmation, conflict, invalidation, and supersession;
- graph ownership and segregation;
- reproducible views and federated storage;
- profiles, domain overrides, brownfield intake, and emergency reconciliation;
- AI, automation, and tool authority boundaries;
- validation, history, portability, and change control.

---

# 2. Graph Definition

The Product OS Traceability Graph is the canonical, version-aware relationship system for registered project artifacts and governed objects.

It answers:

~~~text
What exact object is this?
Which version and scope does it represent?
Where did it come from?
Which decision and authority support it?
What does it refine, realize, satisfy, implement, verify, release, operate, or retire?
Which evidence supports the relationship?
Which relationship is missing, uncertain, conflicted, invalidated, or superseded?
What candidate impact set follows from a change?
Can the graph state at a prior decision time be reconstructed?
~~~

The graph is not the canonical content store for every object. It stores stable references, typed relationships, and relationship governance.

---

# 3. Operating-Layer Model

| Layer | Graph role | Authority boundary |
|---|---|---|
| Framework asset | Defines node classes, edge types, constraints, validation, and profiles | Product OS framework authority |
| Project artifact | `GOV-008` owns the project graph records and integrity state | Project governance authority |
| Artifact container | Represents one GOV-002 artifact identity and version | Artifact owner and GOV-002 |
| Governed object | Represents an addressable object owned inside an artifact or source system | Canonical object owner |
| External source | Represents a source outside Product OS with stable origin identity | Source authority plus intake owner |
| Tool resource | Resolves a canonical object to its exact external locator | Tool-of-record owner |
| Evidence item | Represents reviewable support while custody remains in the evidence store | Evidence owner and reviewer |
| Derived projection | Presents a filtered graph view without changing graph truth | View owner |

Layer, node class, object type, artifact class, tool representation, and lifecycle status are independent dimensions.

---

# 4. Core Graph Invariants

1. One canonical node identity represents one exact object version in one exact namespace.
2. Every project artifact container resolves to one GOV-002 identity.
3. Every edge uses one controlled edge type in canonical direction.
4. Every endpoint resolves to an existing governed node version.
5. Every material edge binds exact scope and time.
6. Every relationship has an accountable owner.
7. Required confirmation has a reviewer or authority distinct from automated inference.
8. Missing relationships remain visible.
9. N/A is an explicit governed relationship disposition, not absence.
10. Conflicts coexist until resolved; one source is not silently chosen.
11. Invalidated and superseded records remain historical.
12. Derived views preserve query, filters, graph revision, and provenance.
13. Link count never substitutes for semantic coverage.
14. A graph relationship never copies or replaces the canonical source content.
15. AI or automation cannot create approval, adoption, satisfaction, compliance, release, or operational truth from inference.

---

# 5. Graph Activation

`GOV-008` is a persistent cross-phase project artifact.

Graph obligations activate when:

- an artifact is registered in GOV-002;
- a governed object receives a stable ID;
- a source, assumption, question, decision, risk, exception, or standard affects project meaning;
- a baseline, gate, handoff, candidate, verification, release, live identity, evolution, transfer, or retirement claim is made;
- applicability is decided or remains blocking pending;
- evidence is used to support a material claim;
- change impact, coverage, compliance lineage, or operational learning is claimed.

The graph exists throughout the lifecycle. It is not created only before a gate or audit.

---

# 6. Applicability and N/A

Every activated artifact has an `ARTIFACT` node even when its project applicability is `NOT_APPLICABLE`.

N/A requires:

~~~yaml
decision_id:
source_obligation_ref:
target_scope_ref:
reason_code:
rationale:
evidence_refs: []
deciding_authority:
decided_at:
valid_until:
reopen_triggers: []
trace_edge_type: NOT_APPLICABLE_TO
~~~

Absence, missing data, small scope, P1, time pressure, or lack of requested documentation cannot create N/A.

`PENDING` applicability is represented by the owning GOV-009 or artifact decision and linked to affected graph scope. It is not an edge status and cannot be hidden as missing.

---

# 7. Namespace Contract

Every node belongs to a canonical namespace:

~~~yaml
namespace:
  organization_id:
  product_os_instance_id:
  project_or_product_id:
  tenant_or_portfolio_id:
  environment_partition:
~~~

`organization_id`, `product_os_instance_id`, and `project_or_product_id` are mandatory unless a framework-owned cross-project source is explicitly governed.

The namespace prevents collisions when different projects use the same local artifact or object ID.

---

# 8. Exact Scope Contract

Material nodes and edges bind applicable dimensions:

~~~text
Project or product
Capability or module
Release or increment
Platform or client
Market, country, locale, script, or direction
Role, tenant, cohort, or population
Environment, region, target, or deployment slot
Data category or information boundary
Standards profile or criterion
Feature flag or configuration state
Evidence period
Lifecycle state
~~~

Scope dimensions are partitioned. A relationship confirmed for web in one locale cannot silently cover mobile, generated documents, or another locale.

---

# 9. Canonical Ownership

| Responsibility | Accountable role |
|---|---|
| Graph vocabulary and invariants | Product OS graph authority |
| Project graph integrity | GOV-008 graph owner |
| Artifact identity and lifecycle | GOV-002 owner |
| Node content and version | Canonical object owner |
| Edge assertion | Edge contributor |
| Material-edge confirmation | Authorized reviewer or edge authority |
| Applicability and standards lineage | GOV-009 authority |
| Evidence integrity and access | Evidence owner |
| Gate coverage acceptance | Gate authority |
| Live identity and period evidence | Operations owner |
| Projection reproducibility | View owner |
| Change-response decision | Authority defined by Change Impact Rules |

One person may hold multiple roles where profile and risk permit, but role identity, conflicts, and compensating review remain explicit.

---

# 10. Node Registration Contract

A node is registered only when:

1. canonical owner is known;
2. semantic class and qualified object type are known;
3. stable local ID exists;
4. version or immutable revision exists;
5. source system and locator resolve;
6. scope is exact enough for its claims;
7. lifecycle and applicability are not conflated;
8. confidentiality and access metadata are sufficient for safe reference;
9. supersession or prior version is linked where applicable.

An unknown object may enter as a SOURCE, QUESTION, ASSUMPTION, or provisional node. It cannot be promoted to an approved semantic object by naming alone.

---

# 11. Edge Assertion Contract

An edge assertion includes:

- exact `from` node version;
- controlled edge type;
- exact `to` node version;
- valid domain and range;
- canonical direction;
- scope partition;
- source of the assertion;
- owner;
- status and confidence;
- evidence where required;
- validity and review dates;
- supersession history;
- notes limited to relationship clarification.

Every stored edge is binary. Many-to-many meaning is represented by multiple binary edge records sharing scope or relationship-group identity.

---

# 12. Direction and Inverse Queries

Edges are stored once in canonical direction.

Query tools may display an inverse label, but the inverse is a read-time projection and not a second stored edge.

Example:

~~~text
Stored: REQ-FR-021 VERIFIED_BY VCASE-090
Displayed inverse: VCASE-090 VERIFIES REQ-FR-021
~~~

Storing both creates duplicate relationship truth and is prohibited unless the second edge has a genuinely different controlled meaning.

---

# 13. Edge Status

| Status | Meaning | Counts as confirmed coverage |
|---|---|---|
| PROPOSED | Candidate relationship awaiting authorized review | No |
| ACTIVE | Accepted current relationship without the assurance required for confirmed coverage | No for gate-critical coverage |
| CONFIRMED | Current relationship confirmed with required authority and support | Yes when all eligibility rules pass |
| CONFLICTED | Material sources or authorities disagree about the relationship | No |
| INVALIDATED | The relationship no longer supports current truth for the bound scope | No |
| SUPERSEDED | A governed replacement relationship exists | No for current coverage |
| NOT_APPLICABLE | Explicit authorized non-relationship for exact scope | Counts only as governed disposition |
| RETIRED | Relationship belongs to retired scope and remains historical | No for current coverage |

Edge status is not node lifecycle status, artifact status, applicability, verification result, gate outcome, or change-impact classification.

---

# 14. Relationship Confidence

| Confidence | Meaning |
|---|---|
| CONFIRMED | Approved source and reviewable evidence support the asserted meaning |
| SUPPORTED | Evidence supports the relation while authority or completeness remains pending |
| INFERRED | A reasoned candidate relationship awaits confirmation |
| ASSUMED | A provisional relationship depends on an explicit assumption |
| UNKNOWN | The relationship cannot currently be established |

Confidence describes support for the edge meaning. It does not describe confidence in classification, product success, schedule, or evidence integrity.

---

# 15. Relationship Obligation

A required edge is defined by a relationship obligation:

~~~yaml
relationship_obligation_id:
trigger:
source_type_set:
edge_type:
target_type_set:
scope_rule:
minimum_outbound:
maximum_outbound:
minimum_inbound:
maximum_inbound:
required_status:
required_confidence:
evidence_rule:
authority_rule:
due_gate_or_event:
n_a_allowed:
n_a_authority:
reopen_triggers: []
~~~

Cardinality alone does not create an obligation. The trigger and scope decide when minimum cardinality becomes active.

---

# 16. Coverage Contract

Coverage is evaluated against activated relationship obligations.

~~~text
Required relationship obligations
→ matching eligible edges
→ exact endpoint, scope, version, time, evidence, authority, and conflict review
→ covered, partial, uncovered, conflicted, N/A, not-yet-required, or invalidated result
~~~

The denominator is the set of activated obligations, not all possible edges and not all rows in a tool.

---

# 17. Contribution and Confirmation

1. A contributor proposes or activates an edge within assigned authority.
2. Automated validation checks type, endpoint, scope, version, and record shape.
3. Required source and evidence are attached.
4. Authorized review evaluates semantic truth.
5. Conflicts and gaps remain visible.
6. The reviewer confirms, conflicts, invalidates, or rejects the assertion.
7. Gate-critical coverage uses only eligible confirmed edges.

The edge author cannot satisfy independent-confirmation requirements by changing the status field.

---

# 18. Conflict of Interest and Segregation

Independent confirmation is required when mandated by:

- P3 or a domain override;
- legal, regulatory, contractual, security, privacy, accessibility, safety, financial, or audit obligations;
- gate-specific independence;
- risk or exception authority;
- evidence produced by the same party making the material claim;
- release or live-operation decisions.

Conflict of interest, substitution, and compensating review are recorded on the relationship review.

---

# 19. History and Immutability

Confirmed, invalidated, superseded, N/A, and retired edges are not rewritten in place to represent new meaning.

A material change creates:

- a new node version, edge version, or both;
- `supersedes` references where meaning continues;
- invalidation references where prior support no longer holds;
- preserved recorded and valid time;
- graph revision identity;
- impact-discovery trigger where required.

Correction of a non-semantic display error may use an auditable correction event without creating a new relationship meaning.

---

# 20. Conflict Preservation

When sources disagree:

1. preserve each sourced assertion;
2. mark affected relationships `CONFLICTED` or retain separate statuses with a conflict record;
3. identify exact scope and versions;
4. link the question, decision need, owners, evidence, and due event;
5. prevent the relationship from counting as confirmed coverage;
6. resolve through valid authority;
7. preserve losing and superseded assertions historically.

Graph density must not hide unresolved contradiction.

---

# 21. Projection Contract

Every derived projection records:

~~~yaml
view_id:
view_type:
graph_revision:
as_of_valid_time:
as_of_recorded_time:
namespace_filter:
scope_filter:
node_filters: []
edge_filters: []
status_filters: []
confidence_filters: []
coverage_policy:
query_definition_ref:
generated_by:
generated_at:
source_graph_ref:
integrity_ref:
~~~

A projection cannot approve, edit, or replace canonical nodes or edges unless the tool operation writes a governed graph transaction back to GOV-008.

---

# 22. Federated Graph Contract

Physical graph data may remain in multiple systems when:

- canonical node keys are globally resolvable;
- each edge has one authoritative owner;
- cross-system locators are stable;
- synchronization status and delay are visible;
- conflicts and failed sync remain visible;
- a reproducible graph revision can be assembled;
- historical and authorization data are preserved;
- tool migration does not change semantic meaning.

Federation is not permission to keep competing manual matrices with unclear ownership.

---

# 23. Access, Security, and Privacy

Traceability metadata may expose sensitive architecture, identity, customer, vulnerability, legal, personnel, or evidence information.

Graph implementations must support:

- least-privilege read and write access;
- field or node-level restriction where needed;
- redacted projections that preserve stable identity and gap visibility;
- audit of material reads, writes, confirmations, and exports;
- secrets exclusion;
- personal-data minimization;
- retention and legal-hold integration;
- safe deletion or tombstone behavior consistent with historical obligations;
- external sharing rules.

Restricted evidence may be referenced through a protected locator without copying its content into the graph.

---

# 24. Profile Behavior

## 24.1 P1

- one normalized graph index or compact matrix may represent critical paths;
- exact node IDs, edge types, scope, versions, evidence, decisions, and history remain addressable;
- manual confirmation is allowed when ownership is explicit;
- unstructured narrative alone is insufficient.

## 24.2 P2

- typed node and edge records are structured;
- phase and gate projections are reproducible;
- automated integrity and coverage checks run at lifecycle events;
- material change traversal is recorded.

## 24.3 P3

- bitemporal history, stronger evidence integrity, formal review, segregation, access control, retention, and continuous drift checks apply;
- clause-level and control-level lineage is preserved where required;
- graph changes may require signed attestations or equivalent controlled approval.

---

# 25. Domain Overrides

A domain override attaches to exact node, edge, path, evidence, and view scope.

The highest applicable treatment governs:

- confirmation authority;
- evidence depth;
- graph review frequency;
- retention;
- segregation;
- path completeness;
- allowed tool and exchange behavior.

An override cannot be neutralized by placing the same edge in a P1 projection.

---

# 26. Brownfield Intake

Brownfield graph activation proceeds in this order:

1. register actual artifacts, repositories, design sources, deployments, data, interfaces, owners, and live services;
2. bind exact current revisions and environments;
3. distinguish verified, unverified, contradicted, stale, inferred, and unknown relationships;
4. record missing upstream baselines rather than fabricate them;
5. connect actual release and live identities;
6. identify critical required paths and gaps;
7. find candidate earliest affected lifecycle points;
8. route impact decisions through authorized governance.

Backfilled lineage records original discovery and confirmation time. It does not pretend the relationship was governed earlier.

---

# 27. Emergency and Recovery Handling

During urgent containment or recovery, the minimum graph record preserves:

- triggering signal or incident;
- exact affected live scope;
- evidence location;
- containment or emergency decision;
- changed implementation, configuration, release, or operational objects;
- temporary risk, exception, or restriction;
- owner and authority;
- required retrospective reconciliation time.

Emergency work does not erase graph obligations. Missing detail is reconciled after stabilization under an owned due event.

---

# 28. AI Authority Boundary

The complete identity, instruction, action-class, authority, human-control, execution, evidence, and incident semantics are defined by the [AI Operating Specification](../AI_Operating_Specification/AI_Operating_Specification_Index.md). This section preserves graph-specific permissions and prohibitions.

AI may:

- discover candidate nodes and edges;
- classify objects and sources;
- identify duplicates, cycles, orphans, conflicts, and stale references;
- propose scope partitions and cardinality violations;
- traverse eligible edges;
- generate projections and candidate impact sets;
- compare graph state with source systems;
- draft review packages.

AI may not:

- invent canonical identity, source, approval, adoption, satisfaction, implementation, verification, compliance, release, or live truth;
- promote inferred or assumed edges to confirmed;
- accept N/A, exception, waiver, risk, or change impact;
- approve gate coverage;
- resolve conflicts without valid authority;
- delete historical relationships;
- treat semantic similarity as proof of lineage.

---

# 29. Automation Boundary

Automation may enforce syntax, schema, type, direction, cardinality, existence, version, scope, freshness, cycle, and policy checks.

Automated results record:

- rule version;
- graph revision;
- evaluated scope;
- input sources;
- result and findings;
- execution time;
- tool version;
- override authority;
- evidence location.

An automated check cannot supply human authority where semantic judgment or approval is required.

---

# 30. Tool Boundary

The graph contract is tool-neutral.

No repository, Figma file, issue tracker, test tool, CI system, release platform, observability platform, spreadsheet, or graph database becomes authoritative merely because it contains links.

Tool Mapping and Schemas & Repository Standard will later bind physical systems and formats. Until then, implementations preserve the logical contract and stable locators.

---

# 31. Gate Boundary

The graph provides each gate with a reproducible coverage and lineage pack.

The gate authority decides whether the pack is sufficient for the exact gate scope. GOV-008 does not issue gate outcomes.

Gate conditions, risks, exceptions, evidence, decision, baseline, and handoff remain linked as separate objects.

---

# 32. Change Impact Boundary

The graph may:

- identify a changed node or edge;
- traverse governed relationships;
- generate candidate affected nodes, baselines, gates, evidence, releases, and live scopes;
- mark uncertainty, conflicts, missing paths, and invalid support;
- propose candidate earliest affected lifecycle points.

The graph may not:

- decide materiality;
- authorize `NO_IMPACT`;
- accept residual uncertainty;
- approve remediation scope;
- reopen or close a gate without valid authority.

Those decisions belong to Change Impact Rules and the owning governance authorities.

---

# 33. Review Cadence

Review graph integrity:

- before every gate;
- after a baseline, candidate, configuration, target, applicability, or evidence change;
- before G7;
- after release execution;
- after a material incident or control failure;
- during G8;
- before deprecation, transfer, sunset, or retirement;
- during source-system or graph-tool migration;
- at the cadence required by risk, profile, and applicable standards.

---

# 34. Shared Exit Criteria

A graph scope is operationally usable when:

1. required node identities resolve;
2. activated relationship obligations are known;
3. required edge records are valid or visibly dispositioned;
4. gate-critical coverage uses eligible edges only;
5. gaps, conflicts, N/A, invalidation, and supersession remain explicit;
6. graph revision and query are reproducible;
7. source and evidence references resolve;
8. ownership and authority are valid;
9. history is reconstructable;
10. profile and domain overrides are satisfied;
11. required views and handoffs exist;
12. no critical unknown is hidden by a coverage percentage.

Graph usability is scope- and time-bound. It is not a permanent certification of the entire product.

---

# 35. Change Control

Changing this contract requires:

- proposed version and reason;
- affected node classes, edge types, constraints, status, confidence, or coverage rules;
- compatibility classification;
- affected graph records and migration;
- artifact, gate, profile, standards, evidence, repository, tool, and schema impact;
- Change Impact Rules implications;
- pilot implications;
- Product OS approving authority;
- updated closure review and change history.

Removing or changing an edge meaning requires explicit migration. Reusing an existing edge name with a different meaning is prohibited.

---

# 36. Final Shared Principle

> **A traceability graph is governed truth about relationships, not a decorative web of links: every relationship must be exact enough to challenge, confirm, invalidate, traverse, reproduce, and preserve through change.**
